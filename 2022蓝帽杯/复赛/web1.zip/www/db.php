<?php

$dbms="mysql";
$host = "127.0.0.1";
$username = "root";
$password = "root";
$dbName = "fish";
$conn=new PDO("$dbms:host=$host;dbname=$dbName", $username, $password);
function waf($s){
  if (preg_match("/select|flag|union|\\\\$|\'|\"|--|#|\\0|into|alert|img|prompt|set/is",$s)||strlen($s)>1000){
    header("Location: /");
    die();
  }
}

foreach ($_GET as $key => $value) {
    waf($value);
}

foreach ($_POST as $key => $value) {
    waf($value);
}

foreach ($_SERVER as $key => $value) {
    waf($value);
}

?>
