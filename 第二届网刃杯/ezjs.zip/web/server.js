const randomize = require('randomatic')
const fs = require('fs')
const lodash = require('lodash')
const session = require('express-session')
const express = require('express')
const bodyParser = require('body-parser')

var blacklist = [] //There are some secrets that you can't see
let filter = (req, res, next)=>{
	r = JSON.stringify(req.body)
	console.log(r)
	if(r.length > 220){
		console.log(r)
		next("<script>alert('You are too lang')</script>")
	}
	blacklist.forEach(function(v,i){
		if(r.indexOf(v)!=-1){
			console.log(r)
		    	next("<script>alert('Go away')</script>")
		}
	})    
	next()
}
const app = express()
app.use('/static', express.static('static'))
app.set('views','./views')
app.set('view engine', 'ejs')
app.use(bodyParser.urlencoded({extended: true})).use(bodyParser.json())
app.use(session({
    name: 'funjs.session',
    secret: randomize('cat', 32),
    resave: false,
    saveUninitialized: false
}))

app.engine('ejs', function (fpth, xz, rev) {

    fs.readFile(fpth, (ERROR, content) => {
        if (!ERROR){
            let drawer = lodash.template(content)
            let drawrend = drawer({...xz})
            return rev(null, drawrend)
        }
        else{
            return rev(new Error(ERROR))
        }
    })
})

app.all('/', filter,(req, res) => {
    let info = req.session.info || 
    		{ctf: [], character: []}

    if (req.method == 'POST') {
        info = lodash.merge(info, req.body)
        console.log(info)
        req.session.info = info
    }
    var script = ""
    res.render('index.ejs', {
    	   script: "<script>alert('Bad,Choice >_<!!')</script>",
        ctf: info.ctf, 
        character: info.character
    })
    
    //res.write("<script>alert('Bad,choice >_<!!')</script>")
})

app.listen(3000, () => console.log(`Example app listening on port 3000!`))
