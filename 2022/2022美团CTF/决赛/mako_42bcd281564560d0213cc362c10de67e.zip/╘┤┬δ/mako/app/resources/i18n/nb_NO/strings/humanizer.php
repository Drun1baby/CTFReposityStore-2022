<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => 'i går',
	'today'       => 'i dag',
	'tomorrow'    => 'i morgen',
	'minute_ago'  => 'et minutt siden',
	'minutes_ago' => '%u minutter siden',
	'in_minute'   => 'om et minutt',
	'in_minutes'  => 'om %u minutter',
];
