<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => 'yesterday',
	'today'       => 'today',
	'tomorrow'    => 'tomorrow',
	'minute_ago'  => 'a minute ago',
	'minutes_ago' => '%u minutes ago',
	'in_minute'   => 'in a minute',
	'in_minutes'  => 'in %u minutes',
];
