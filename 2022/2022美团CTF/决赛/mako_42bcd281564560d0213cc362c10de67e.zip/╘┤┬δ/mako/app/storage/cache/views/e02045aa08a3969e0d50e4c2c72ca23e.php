<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="<?php echo $this->escapeHTML($__charset__, $__charset__); ?>">
		<title>Mako <?php echo $this->escapeHTML(mako\Mako::VERSION, $__charset__); ?></title>
		<style>
			body
			{
				background: #eee;
				font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
				font-weight: bold;
				padding:0px;
				margin:0px;
			}
			a
			{
				color: #03C5A0;
				text-decoration: none;
			}
			a:hover
			{
				color: #067761;
			}
			.welcome
			{
				text-align: center;
				top: 50%;
				left: 50%;
				position: absolute;
				transform: translate(-50%, -50%);
			}
			.mako
			{
				font-size: 200px;
			}
		</style>
	</head>
	<body>
		<div class="welcome">
			<span class="mako"><a title="Head over to the documentation" href="https://makoframework.com/docs">MAKO</a></span>
		</div>
	</body>
</html>