<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
	<title>Mako ImageMagick</title>
	<!-- Font Awesome -->
	<link
		href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
		rel="stylesheet"
	/>
	<!-- Google Fonts -->
	<link
		href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
		rel="stylesheet"
	/>
	<!-- MDB -->
	<link
		href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.4.0/mdb.min.css"
		rel="stylesheet"
	/>
</head>
<body>
<div id="main" style="width:50%;margin:0 auto;text-align:center">
	<br>
	<h4>文件名: <?php echo $this->escapeHTML($fileName, $__charset__); ?></h4>
	<br><br>
	<h5>
	宽度：<?php echo $this->escapeHTML($dimensions['width'], $__charset__); ?>
	</h5>
	<br>
	<h5>
	高度：<?php echo $this->escapeHTML($dimensions['height'], $__charset__); ?>
	</h5>
	<br>
	<form action="/index.php/edit" method="post" enctype="multipart/form-data">
		<div class="form-outline">
				<input type="text" id="rotate" name="degrees" class="form-control" />
				<input hidden="true" name="filename" value="<?php echo $this->escapeHTML($fileName, $__charset__); ?>"/>
				<label class="form-label" for="rotate">旋转度数</label>
		</div>
		<br>
		(其他功能正在开发中)
		<br>
		<br>
		<button type="submit" class="btn btn-primary">提交</button>
	</form>

</div>


<script
	type="text/javascript"
	src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.4.0/mdb.min.js"
></script>
</body>
</html>