from random import getrandbits

FLAG = b'DASCTF{xxxxxxxxx}'
class lfsr():
    def __init__(self, seed, mask, length):
        self.length_mask = 2 ** length - 1
        self.mask = mask & self.length_mask
        self.state = seed & self.length_mask
        print(self.state, self.mask)

    def next(self):
        next_state = (self.state << 1) & self.length_mask
        i = self.state & self.mask & self.length_mask
        output = 0
        while i != 0:
            output ^= (i & 1)
            i = i >> 1
        next_state ^= output
        self.state = next_state
        return output

    def getrandbit(self, nbit):
        output = 0
        for _ in range(nbit):
            output = (output << 1) ^ self.next()
        return output

seed = getrandbits(32)
mask = getrandbits(32)

box = lfsr(seed, mask, 32)

s = []

for i in FLAG:
    s.append(box.getrandbit(8) ^ i)

print(s)
# [189, 81, 22, 153, 205, 197, 241, 3, 18, 128, 36, 253, 5, 200, 170, 131, 25, 71, 9, 196, 164, 161, 9, 0, 7, 123, 149, 121, 32, 122, 149, 131, 170, 252, 189, 68, 162, 164, 153, 67]
