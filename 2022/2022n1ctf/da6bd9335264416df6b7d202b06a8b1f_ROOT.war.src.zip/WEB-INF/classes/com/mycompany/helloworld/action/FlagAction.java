/*    */ package classes.com.mycompany.helloworld.action;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Paths;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlagAction extends ActionSupport
/*    */ {
/*    */   private String flag;
/*    */   
/*    */   public String getFlag() {
/* 19 */     return this.flag;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String execute() throws Exception {
/* 25 */     List<String> lines = Files.readAllLines(Paths.get("/flag", new String[0]));
/* 26 */     this.flag = String.join(System.lineSeparator(), (Iterable)lines);
/* 27 */     return "success";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\classes\com\mycompany\helloworld\action\FlagAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */