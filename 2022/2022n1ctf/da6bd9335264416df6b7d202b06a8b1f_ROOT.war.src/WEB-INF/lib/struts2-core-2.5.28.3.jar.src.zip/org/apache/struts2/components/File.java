/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "file", tldTagClass = "org.apache.struts2.views.jsp.ui.FileTag", description = "Render a file input field", allowDynamicAttributes = true)
/*     */ public class File
/*     */   extends UIBean
/*     */ {
/*  51 */   private static final Logger LOG = LogManager.getLogger(File.class);
/*     */   
/*     */   public static final String TEMPLATE = "file";
/*     */   
/*     */   protected String accept;
/*     */   protected String size;
/*     */   
/*     */   public File(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  59 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  63 */     return "file";
/*     */   }
/*     */   
/*     */   public void evaluateParams() {
/*  67 */     super.evaluateParams();
/*     */     
/*  69 */     Form form = (Form)findAncestor(Form.class);
/*  70 */     if (form != null) {
/*  71 */       String encType = (String)form.getParameters().get("enctype");
/*  72 */       if (!"multipart/form-data".equals(encType))
/*     */       {
/*  74 */         LOG.warn("Struts has detected a file upload UI tag (s:file) being used without a form set to enctype 'multipart/form-data'. This is probably an error!");
/*     */       }
/*     */       
/*  77 */       String method = (String)form.getParameters().get("method");
/*  78 */       if (!"post".equalsIgnoreCase(method))
/*     */       {
/*  80 */         LOG.warn("Struts has detected a file upload UI tag (s:file) being used without a form set to method 'POST'. This is probably an error!");
/*     */       }
/*     */     } 
/*     */     
/*  84 */     if (this.accept != null) {
/*  85 */       addParameter("accept", findString(this.accept));
/*     */     }
/*     */     
/*  88 */     if (this.size != null) {
/*  89 */       addParameter("size", findString(this.size));
/*     */     }
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML accept attribute to indicate accepted file mimetypes")
/*     */   public void setAccept(String accept) {
/*  95 */     this.accept = accept;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML size attribute", required = false, type = "Integer")
/*     */   public void setSize(String size) {
/* 100 */     this.size = size;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\File.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */