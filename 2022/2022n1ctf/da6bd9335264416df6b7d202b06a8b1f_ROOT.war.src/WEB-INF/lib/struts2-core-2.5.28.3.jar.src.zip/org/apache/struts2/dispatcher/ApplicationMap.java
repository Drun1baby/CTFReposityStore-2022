/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationMap
/*     */   extends AbstractMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 9136809763083228202L;
/*     */   private ServletContext context;
/*     */   private Set<Object> entries;
/*     */   
/*     */   public ApplicationMap(ServletContext ctx) {
/*  45 */     this.context = ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  53 */     this.entries = null;
/*     */     
/*  55 */     Enumeration<E> e = this.context.getAttributeNames();
/*     */     
/*  57 */     while (e.hasMoreElements()) {
/*  58 */       this.context.removeAttribute(e.nextElement().toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/*  68 */     if (this.entries == null) {
/*  69 */       this.entries = new HashSet();
/*     */ 
/*     */       
/*  72 */       Enumeration<E> enumeration = this.context.getAttributeNames();
/*     */       
/*  74 */       while (enumeration.hasMoreElements()) {
/*  75 */         final String key = enumeration.nextElement().toString();
/*  76 */         final Object value = this.context.getAttribute(key);
/*  77 */         this.entries.add(new Map.Entry<Object, Object>() {
/*     */               public boolean equals(Object obj) {
/*  79 */                 if (!(obj instanceof Map.Entry)) {
/*  80 */                   return false;
/*     */                 }
/*  82 */                 Map.Entry entry = (Map.Entry)obj;
/*     */                 
/*  84 */                 if ((key == null) ? (entry.getKey() == null) : key.equals(entry.getKey())) if ((value == null) ? (entry.getValue() == null) : value.equals(entry.getValue()));  return false;
/*     */               }
/*     */               
/*     */               public int hashCode() {
/*  88 */                 return ((key == null) ? 0 : key.hashCode()) ^ ((value == null) ? 0 : value.hashCode());
/*     */               }
/*     */               
/*     */               public Object getKey() {
/*  92 */                 return key;
/*     */               }
/*     */               
/*     */               public Object getValue() {
/*  96 */                 return value;
/*     */               }
/*     */               
/*     */               public Object setValue(Object obj) {
/* 100 */                 ApplicationMap.this.context.setAttribute(key, obj);
/*     */                 
/* 102 */                 return value;
/*     */               }
/*     */             });
/*     */       } 
/*     */ 
/*     */       
/* 108 */       enumeration = this.context.getInitParameterNames();
/*     */       
/* 110 */       while (enumeration.hasMoreElements()) {
/* 111 */         final String key = enumeration.nextElement().toString();
/* 112 */         final Object value = this.context.getInitParameter(key);
/* 113 */         this.entries.add(new Map.Entry<Object, Object>() {
/*     */               public boolean equals(Object obj) {
/* 115 */                 if (!(obj instanceof Map.Entry)) {
/* 116 */                   return false;
/*     */                 }
/* 118 */                 Map.Entry entry = (Map.Entry)obj;
/*     */                 
/* 120 */                 if ((key == null) ? (entry.getKey() == null) : key.equals(entry.getKey())) if ((value == null) ? (entry.getValue() == null) : value.equals(entry.getValue()));  return false;
/*     */               }
/*     */               
/*     */               public int hashCode() {
/* 124 */                 return ((key == null) ? 0 : key.hashCode()) ^ ((value == null) ? 0 : value.hashCode());
/*     */               }
/*     */               
/*     */               public Object getKey() {
/* 128 */                 return key;
/*     */               }
/*     */               
/*     */               public Object getValue() {
/* 132 */                 return value;
/*     */               }
/*     */               
/*     */               public Object setValue(Object obj) {
/* 136 */                 ApplicationMap.this.context.setAttribute(key, obj);
/*     */                 
/* 138 */                 return value;
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 157 */     String keyString = key.toString();
/* 158 */     Object value = this.context.getAttribute(keyString);
/*     */     
/* 160 */     return (value == null) ? this.context.getInitParameter(keyString) : value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 171 */     Object oldValue = get(key);
/* 172 */     this.entries = null;
/* 173 */     this.context.setAttribute(key.toString(), value);
/* 174 */     return oldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 184 */     this.entries = null;
/*     */     
/* 186 */     Object value = get(key);
/* 187 */     this.context.removeAttribute(key.toString());
/*     */     
/* 189 */     return value;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\ApplicationMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */