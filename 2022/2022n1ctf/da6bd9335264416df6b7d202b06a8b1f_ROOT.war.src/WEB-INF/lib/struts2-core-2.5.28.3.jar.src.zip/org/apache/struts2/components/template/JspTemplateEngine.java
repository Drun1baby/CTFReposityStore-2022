/*    */ package org.apache.struts2.components.template;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts2.components.Include;
/*    */ import org.apache.struts2.components.UIBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JspTemplateEngine
/*    */   extends BaseTemplateEngine
/*    */ {
/* 38 */   private static final Logger LOG = LogManager.getLogger(JspTemplateEngine.class);
/*    */   
/*    */   String encoding;
/*    */   
/*    */   @Inject("struts.i18n.encoding")
/*    */   public void setEncoding(String encoding) {
/* 44 */     this.encoding = encoding;
/*    */   }
/*    */   
/*    */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception {
/* 48 */     Template template = templateContext.getTemplate();
/*    */     
/* 50 */     LOG.debug("Trying to render template [{}], repeating through parents until we succeed", template);
/* 51 */     UIBean tag = templateContext.getTag();
/* 52 */     ValueStack stack = templateContext.getStack();
/* 53 */     stack.push(tag);
/* 54 */     PageContext pageContext = (PageContext)stack.getContext().get("com.opensymphony.xwork2.dispatcher.PageContext");
/* 55 */     List<Template> templates = template.getPossibleTemplates(this);
/* 56 */     Exception exception = null;
/* 57 */     boolean success = false;
/* 58 */     for (Template t : templates) {
/*    */       try {
/* 60 */         Include.include(getFinalTemplateName(t), (Writer)pageContext.getOut(), pageContext.getRequest(), (HttpServletResponse)pageContext.getResponse(), this.encoding);
/*    */         
/* 62 */         success = true;
/*    */         break;
/* 64 */       } catch (Exception e) {
/* 65 */         if (exception == null) {
/* 66 */           exception = e;
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 71 */     if (!success) {
/* 72 */       LOG.error("Could not render JSP template {}", templateContext.getTemplate());
/*    */       
/* 74 */       if (exception != null) {
/* 75 */         throw exception;
/*    */       }
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 81 */     stack.pop();
/*    */   }
/*    */   
/*    */   protected String getSuffix() {
/* 85 */     return "jsp";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\JspTemplateEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */