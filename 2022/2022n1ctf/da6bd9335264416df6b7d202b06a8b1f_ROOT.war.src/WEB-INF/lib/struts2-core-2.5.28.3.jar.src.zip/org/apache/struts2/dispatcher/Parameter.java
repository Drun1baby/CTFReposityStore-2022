/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Parameter
/*     */ {
/*     */   String getName();
/*     */   
/*     */   String getValue();
/*     */   
/*     */   boolean isDefined();
/*     */   
/*     */   boolean isMultiple();
/*     */   
/*     */   String[] getMultipleValues();
/*     */   
/*     */   Object getObject();
/*     */   
/*     */   public static class Request
/*     */     implements Parameter
/*     */   {
/*  43 */     private static final Logger LOG = LogManager.getLogger(Request.class);
/*     */     
/*     */     private final String name;
/*     */     private final Object value;
/*     */     
/*     */     public Request(String name, Object value) {
/*  49 */       this.name = name;
/*  50 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/*  55 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/*  60 */       String[] values = toStringArray();
/*  61 */       return (values != null && values.length > 0) ? values[0] : null;
/*     */     }
/*     */     
/*     */     private String[] toStringArray() {
/*  65 */       if (this.value == null) {
/*  66 */         LOG.trace("The value is null, empty array of string will be returned!");
/*  67 */         return new String[0];
/*  68 */       }  if (this.value.getClass().isArray()) {
/*  69 */         LOG.trace("Converting value {} to array of strings", this.value);
/*     */         
/*  71 */         Object[] values = (Object[])this.value;
/*  72 */         String[] strValues = new String[values.length];
/*  73 */         int i = 0;
/*  74 */         for (Object v : values) {
/*  75 */           strValues[i] = Objects.toString(v, null);
/*  76 */           i++;
/*     */         } 
/*  78 */         return strValues;
/*     */       } 
/*  80 */       LOG.trace("Converting value {} to simple string", this.value);
/*  81 */       return new String[] { this.value.toString() };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDefined() {
/*  87 */       return (this.value != null && (toStringArray()).length > 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMultiple() {
/*  92 */       return (isDefined() && (toStringArray()).length > 1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getMultipleValues() {
/*  97 */       return toStringArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getObject() {
/* 102 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 107 */       return StringEscapeUtils.escapeHtml4(getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class File
/*     */     extends Request {
/*     */     public File(String name, Object value) {
/* 114 */       super(name, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 119 */       return "File{name='" + getName() + '\'' + '}';
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Empty
/*     */     implements Parameter
/*     */   {
/*     */     private String name;
/*     */     
/*     */     public Empty(String name) {
/* 130 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 135 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValue() {
/* 140 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDefined() {
/* 145 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMultiple() {
/* 150 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getMultipleValues() {
/* 155 */       return new String[0];
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getObject() {
/* 160 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 165 */       return "Empty{name='" + this.name + '\'' + '}';
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\Parameter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */