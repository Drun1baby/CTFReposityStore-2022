/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.LocalizedMessage;
/*     */ import org.apache.struts2.dispatcher.StrutsRequestWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiPartRequestWrapper
/*     */   extends StrutsRequestWrapper
/*     */ {
/*  56 */   protected static final Logger LOG = LogManager.getLogger(MultiPartRequestWrapper.class);
/*     */   
/*     */   private Collection<LocalizedMessage> errors;
/*     */   private MultiPartRequest multi;
/*  60 */   private Locale defaultLocale = Locale.ENGLISH;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiPartRequestWrapper(MultiPartRequest multiPartRequest, HttpServletRequest request, String saveDir, LocaleProvider provider, boolean disableRequestAttributeValueStackLookup) {
/*  74 */     super(request, disableRequestAttributeValueStackLookup);
/*  75 */     this.errors = new ArrayList<>();
/*  76 */     this.multi = multiPartRequest;
/*  77 */     this.defaultLocale = provider.getLocale();
/*  78 */     setLocale(request);
/*     */     try {
/*  80 */       this.multi.parse(request, saveDir);
/*  81 */       for (LocalizedMessage error : this.multi.getErrors()) {
/*  82 */         addError(error);
/*     */       }
/*  84 */     } catch (IOException e) {
/*  85 */       LOG.warn(e.getMessage(), e);
/*  86 */       addError(buildErrorMessage(e, new Object[] { e.getMessage() }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public MultiPartRequestWrapper(MultiPartRequest multiPartRequest, HttpServletRequest request, String saveDir, LocaleProvider provider) {
/*  91 */     this(multiPartRequest, request, saveDir, provider, false);
/*     */   }
/*     */   
/*     */   protected void setLocale(HttpServletRequest request) {
/*  95 */     if (this.defaultLocale == null) {
/*  96 */       this.defaultLocale = request.getLocale();
/*     */     }
/*     */   }
/*     */   
/*     */   protected LocalizedMessage buildErrorMessage(Throwable e, Object[] args) {
/* 101 */     String errorKey = "struts.messages.upload.error." + e.getClass().getSimpleName();
/* 102 */     LOG.debug("Preparing error message for key: [{}]", errorKey);
/* 103 */     return new LocalizedMessage(getClass(), errorKey, e.getMessage(), args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getFileParameterNames() {
/* 112 */     if (this.multi == null) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     return this.multi.getFileParameterNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getContentTypes(String name) {
/* 127 */     if (this.multi == null) {
/* 128 */       return null;
/*     */     }
/*     */     
/* 131 */     return this.multi.getContentType(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UploadedFile[] getFiles(String fieldName) {
/* 141 */     if (this.multi == null) {
/* 142 */       return null;
/*     */     }
/*     */     
/* 145 */     return this.multi.getFile(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFileNames(String fieldName) {
/* 155 */     if (this.multi == null) {
/* 156 */       return null;
/*     */     }
/*     */     
/* 159 */     return this.multi.getFileNames(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFileSystemNames(String fieldName) {
/* 171 */     if (this.multi == null) {
/* 172 */       return null;
/*     */     }
/*     */     
/* 175 */     return this.multi.getFilesystemName(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 182 */     return (this.multi == null || this.multi.getParameter(name) == null) ? super.getParameter(name) : this.multi.getParameter(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getParameterMap() {
/* 189 */     Map<String, String[]> map = (Map)new HashMap<>();
/* 190 */     Enumeration<String> enumeration = getParameterNames();
/*     */     
/* 192 */     while (enumeration.hasMoreElements()) {
/* 193 */       String name = enumeration.nextElement();
/* 194 */       map.put(name, getParameterValues(name));
/*     */     } 
/*     */     
/* 197 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration getParameterNames() {
/* 204 */     if (this.multi == null) {
/* 205 */       return super.getParameterNames();
/*     */     }
/* 207 */     return mergeParams(this.multi.getParameterNames(), super.getParameterNames());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 215 */     return (this.multi == null || this.multi.getParameterValues(name) == null) ? super.getParameterValues(name) : this.multi.getParameterValues(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 224 */     return !this.errors.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<LocalizedMessage> getErrors() {
/* 233 */     return this.errors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addError(LocalizedMessage anErrorMessage) {
/* 242 */     if (!this.errors.contains(anErrorMessage)) {
/* 243 */       this.errors.add(anErrorMessage);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Enumeration mergeParams(Enumeration params1, Enumeration params2) {
/* 255 */     Vector temp = new Vector();
/*     */     
/* 257 */     while (params1.hasMoreElements()) {
/* 258 */       temp.add(params1.nextElement());
/*     */     }
/*     */     
/* 261 */     while (params2.hasMoreElements()) {
/* 262 */       temp.add(params2.nextElement());
/*     */     }
/*     */     
/* 265 */     return temp.elements();
/*     */   }
/*     */   
/*     */   public void cleanUp() {
/* 269 */     if (this.multi != null)
/* 270 */       this.multi.cleanUp(); 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\multipart\MultiPartRequestWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */