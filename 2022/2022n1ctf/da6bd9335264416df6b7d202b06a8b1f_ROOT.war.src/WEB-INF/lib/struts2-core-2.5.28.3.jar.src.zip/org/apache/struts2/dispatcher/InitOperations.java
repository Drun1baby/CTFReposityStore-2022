/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitOperations
/*     */ {
/*     */   @Deprecated
/*     */   public void initLogging(HostConfig filterConfig) {
/*  45 */     String factoryName = filterConfig.getInitParameter("loggerFactory");
/*  46 */     if (factoryName != null) {
/*     */       try {
/*  48 */         Class<LoggerFactory> cls = ClassLoaderUtil.loadClass(factoryName, getClass());
/*  49 */         LoggerFactory fac = cls.newInstance();
/*  50 */         LoggerFactory.setLoggerFactory(fac);
/*  51 */       } catch (InstantiationException e) {
/*  52 */         System.err.println("Unable to instantiate logger factory: " + factoryName + ", using default");
/*  53 */         e.printStackTrace();
/*  54 */       } catch (IllegalAccessException e) {
/*  55 */         System.err.println("Unable to access logger factory: " + factoryName + ", using default");
/*  56 */         e.printStackTrace();
/*  57 */       } catch (ClassNotFoundException e) {
/*  58 */         System.err.println("Unable to locate logger factory class: " + factoryName + ", using default");
/*  59 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dispatcher initDispatcher(HostConfig filterConfig) {
/*  72 */     Dispatcher dispatcher = createDispatcher(filterConfig);
/*  73 */     dispatcher.init();
/*  74 */     return dispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StaticContentLoader initStaticContentLoader(HostConfig filterConfig, Dispatcher dispatcher) {
/*  85 */     StaticContentLoader loader = (StaticContentLoader)dispatcher.getContainer().getInstance(StaticContentLoader.class);
/*  86 */     loader.setHostConfig(filterConfig);
/*  87 */     return loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dispatcher findDispatcherOnThread() {
/*  96 */     Dispatcher dispatcher = Dispatcher.getInstance();
/*  97 */     if (dispatcher == null) {
/*  98 */       throw new IllegalStateException("Must have the StrutsPrepareFilter execute before this one");
/*     */     }
/* 100 */     return dispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Dispatcher createDispatcher(HostConfig filterConfig) {
/* 111 */     Map<String, String> params = new HashMap<>();
/* 112 */     for (Iterator<String> e = filterConfig.getInitParameterNames(); e.hasNext(); ) {
/* 113 */       String name = e.next();
/* 114 */       String value = filterConfig.getInitParameter(name);
/* 115 */       params.put(name, value);
/*     */     } 
/* 117 */     return new Dispatcher(filterConfig.getServletContext(), params);
/*     */   }
/*     */   
/*     */   public void cleanup() {
/* 121 */     ActionContext.setContext(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Pattern> buildExcludedPatternsList(Dispatcher dispatcher) {
/* 134 */     return buildExcludedPatternsList((String)dispatcher.getContainer().getInstance(String.class, "struts.action.excludePattern"));
/*     */   }
/*     */   
/*     */   private List<Pattern> buildExcludedPatternsList(String patterns) {
/* 138 */     if (null != patterns && patterns.trim().length() != 0) {
/* 139 */       List<Pattern> list = new ArrayList<>();
/* 140 */       String[] tokens = patterns.split(",");
/* 141 */       for (String token : tokens) {
/* 142 */         list.add(Pattern.compile(token.trim()));
/*     */       }
/* 144 */       return Collections.unmodifiableList(list);
/*     */     } 
/* 146 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\InitOperations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */