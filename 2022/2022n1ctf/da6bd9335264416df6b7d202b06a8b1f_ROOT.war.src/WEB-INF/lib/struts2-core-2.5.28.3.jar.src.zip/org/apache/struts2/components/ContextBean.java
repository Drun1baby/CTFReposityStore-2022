/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextBean
/*    */   extends Component
/*    */ {
/*    */   protected String var;
/*    */   
/*    */   public ContextBean(ValueStack stack) {
/* 32 */     super(stack);
/*    */   }
/*    */   
/*    */   protected void putInContext(Object value) {
/* 36 */     if (StringUtils.isNotBlank(this.var)) {
/* 37 */       this.stack.getContext().put(this.var, value);
/*    */     }
/*    */   }
/*    */   
/*    */   @StrutsTagAttribute(description = "Name used to reference the value pushed into the Value Stack")
/*    */   public void setVar(String var) {
/* 43 */     if (var != null) {
/* 44 */       this.var = findString(var);
/*    */     }
/*    */   }
/*    */   
/*    */   protected String getVar() {
/* 49 */     return this.var;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ContextBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */