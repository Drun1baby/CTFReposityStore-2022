/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Currency;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "number", tldBodyContent = "empty", tldTagClass = "org.apache.struts2.views.jsp.NumberTag", description = "Render a formatted number.")
/*     */ public class Number
/*     */   extends ContextBean
/*     */ {
/* 111 */   private static final Logger LOG = LogManager.getLogger(Number.class);
/*     */ 
/*     */   
/*     */   public static final String NUMBERTAG_PROPERTY = "struts.number.format";
/*     */   
/*     */   private String name;
/*     */   
/*     */   private String currency;
/*     */   
/*     */   private String type;
/*     */   
/*     */   private Boolean groupingUsed;
/*     */   
/*     */   private Integer maximumFractionDigits;
/*     */   
/*     */   private Integer maximumIntegerDigits;
/*     */   
/*     */   private Integer minimumFractionDigits;
/*     */   
/*     */   private Integer minimumIntegerDigits;
/*     */   
/*     */   private Boolean parseIntegerOnly;
/*     */   
/*     */   private String roundingMode;
/*     */ 
/*     */   
/*     */   public Number(ValueStack stack) {
/* 138 */     super(stack);
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 142 */     java.lang.Number number = findNumberName();
/*     */     
/* 144 */     if (number != null) {
/*     */       
/* 146 */       NumberFormat format = getNumberFormat();
/* 147 */       findCurrency(format);
/* 148 */       setNumberFormatParameters(format);
/* 149 */       setRoundingMode(format);
/*     */       
/* 151 */       String msg = format.format(number);
/*     */       try {
/* 153 */         if (getVar() == null) {
/* 154 */           writer.write(msg);
/*     */         } else {
/* 156 */           putInContext(msg);
/*     */         } 
/* 158 */       } catch (IOException e) {
/* 159 */         LOG.error("Could not write out Number tag", e);
/*     */       } 
/*     */     } 
/* 162 */     return super.end(writer, "");
/*     */   }
/*     */ 
/*     */   
/*     */   private void findCurrency(NumberFormat format) {
/* 167 */     if (this.currency != null) {
/* 168 */       Object currencyValue = findValue(this.currency);
/* 169 */       if (currencyValue != null) {
/* 170 */         this.currency = currencyValue.toString();
/*     */       }
/*     */       try {
/* 173 */         format.setCurrency(Currency.getInstance(this.currency));
/* 174 */       } catch (IllegalArgumentException iae) {
/* 175 */         LOG.error("Could not recognise a currency of [" + this.currency + "]");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setNumberFormatParameters(NumberFormat format) {
/* 181 */     if (this.groupingUsed != null) {
/* 182 */       format.setGroupingUsed(this.groupingUsed.booleanValue());
/*     */     }
/* 184 */     if (this.maximumFractionDigits != null) {
/* 185 */       format.setMaximumFractionDigits(this.maximumFractionDigits.intValue());
/*     */     }
/* 187 */     if (this.maximumIntegerDigits != null) {
/* 188 */       format.setMaximumIntegerDigits(this.maximumIntegerDigits.intValue());
/*     */     }
/* 190 */     if (this.minimumFractionDigits != null) {
/* 191 */       format.setMinimumFractionDigits(this.minimumFractionDigits.intValue());
/*     */     }
/* 193 */     if (this.minimumIntegerDigits != null) {
/* 194 */       format.setMinimumIntegerDigits(this.minimumIntegerDigits.intValue());
/*     */     }
/* 196 */     if (this.parseIntegerOnly != null) {
/* 197 */       format.setParseIntegerOnly(this.parseIntegerOnly.booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private java.lang.Number findNumberName() {
/* 202 */     java.lang.Number number = null;
/*     */ 
/*     */     
/*     */     try {
/* 206 */       Object numberObject = findValue(this.name);
/* 207 */       if (numberObject instanceof java.lang.Number) {
/* 208 */         number = (java.lang.Number)numberObject;
/*     */       }
/* 210 */     } catch (Exception e) {
/* 211 */       LOG.error("Could not convert object with key [" + this.name + "] to a java.lang.Number instance");
/*     */     } 
/* 213 */     return number;
/*     */   }
/*     */   
/*     */   private void setRoundingMode(NumberFormat format) {
/* 217 */     if (this.roundingMode != null) {
/* 218 */       this.roundingMode = findString(this.roundingMode);
/* 219 */       if ("ceiling".equals(this.roundingMode)) {
/* 220 */         format.setRoundingMode(RoundingMode.CEILING);
/* 221 */       } else if ("down".equals(this.roundingMode)) {
/* 222 */         format.setRoundingMode(RoundingMode.DOWN);
/* 223 */       } else if ("floor".equals(this.roundingMode)) {
/* 224 */         format.setRoundingMode(RoundingMode.FLOOR);
/* 225 */       } else if ("half-down".equals(this.roundingMode)) {
/* 226 */         format.setRoundingMode(RoundingMode.HALF_DOWN);
/* 227 */       } else if ("half-even".equals(this.roundingMode)) {
/* 228 */         format.setRoundingMode(RoundingMode.HALF_EVEN);
/* 229 */       } else if ("half-up".equals(this.roundingMode)) {
/* 230 */         format.setRoundingMode(RoundingMode.HALF_UP);
/* 231 */       } else if ("unnecessary".equals(this.roundingMode)) {
/* 232 */         format.setRoundingMode(RoundingMode.UNNECESSARY);
/* 233 */       } else if ("up".equals(this.roundingMode)) {
/* 234 */         format.setRoundingMode(RoundingMode.UP);
/*     */       } else {
/* 236 */         LOG.error("Could not recognise a roundingMode of [" + this.roundingMode + "]");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private NumberFormat getNumberFormat() {
/* 242 */     NumberFormat format = null;
/* 243 */     if (this.type == null) {
/*     */       try {
/* 245 */         this.type = findString("struts.number.format");
/* 246 */       } catch (Exception e) {
/* 247 */         LOG.error("Could not find [struts.number.format] on the stack!", e);
/*     */       } 
/*     */     }
/* 250 */     if (this.type != null) {
/* 251 */       this.type = findString(this.type);
/* 252 */       if ("currency".equals(this.type)) {
/* 253 */         format = NumberFormat.getCurrencyInstance(ActionContext.getContext().getLocale());
/* 254 */       } else if ("integer".equals(this.type)) {
/* 255 */         format = NumberFormat.getIntegerInstance(ActionContext.getContext().getLocale());
/* 256 */       } else if ("number".equals(this.type)) {
/* 257 */         format = NumberFormat.getNumberInstance(ActionContext.getContext().getLocale());
/* 258 */       } else if ("percent".equals(this.type)) {
/* 259 */         format = NumberFormat.getPercentInstance(ActionContext.getContext().getLocale());
/*     */       } 
/*     */     } 
/* 262 */     if (format == null) {
/* 263 */       format = NumberFormat.getInstance(ActionContext.getContext().getLocale());
/*     */     }
/* 265 */     return format;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Type of number formatter (currency, integer, number or percent, default is number)")
/*     */   public void setType(String type) {
/* 270 */     this.type = type;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The currency to use for a currency format")
/*     */   public void setCurrency(String currency) {
/* 275 */     this.currency = currency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 282 */     return this.name;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The number value to format", required = true)
/*     */   public void setName(String name) {
/* 287 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 294 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrency() {
/* 301 */     return this.currency;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether grouping is used", type = "Boolean")
/*     */   public void setGroupingUsed(Boolean groupingUsed) {
/* 306 */     this.groupingUsed = groupingUsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isGroupingUsed() {
/* 313 */     return this.groupingUsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMaximumFractionDigits() {
/* 320 */     return this.maximumFractionDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Maximum fraction digits", type = "Integer")
/*     */   public void setMaximumFractionDigits(Integer maximumFractionDigits) {
/* 328 */     this.maximumFractionDigits = maximumFractionDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMaximumIntegerDigits() {
/* 335 */     return this.maximumIntegerDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Maximum integer digits", type = "Integer")
/*     */   public void setMaximumIntegerDigits(Integer maximumIntegerDigits) {
/* 343 */     this.maximumIntegerDigits = maximumIntegerDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMinimumFractionDigits() {
/* 350 */     return this.minimumFractionDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Minimum fraction digits", type = "Integer")
/*     */   public void setMinimumFractionDigits(Integer minimumFractionDigits) {
/* 358 */     this.minimumFractionDigits = minimumFractionDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMinimumIntegerDigits() {
/* 365 */     return this.minimumIntegerDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Maximum integer digits", type = "Integer")
/*     */   public void setMinimumIntegerDigits(Integer minimumIntegerDigits) {
/* 373 */     this.minimumIntegerDigits = minimumIntegerDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isParseIntegerOnly() {
/* 380 */     return this.parseIntegerOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Parse integer only", type = "Boolean")
/*     */   public void setParseIntegerOnly(Boolean parseIntegerOnly) {
/* 388 */     this.parseIntegerOnly = parseIntegerOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRoundingMode() {
/* 395 */     return this.roundingMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "The rounding mode to use, possible values: ceiling, down, floor, half-down, half-even, half-up, unnecessary, up")
/*     */   public void setRoundingMode(String roundingMode) {
/* 403 */     this.roundingMode = roundingMode;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Number.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */