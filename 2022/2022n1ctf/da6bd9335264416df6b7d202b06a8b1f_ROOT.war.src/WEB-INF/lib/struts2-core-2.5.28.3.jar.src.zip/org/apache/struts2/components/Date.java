/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "date", tldBodyContent = "empty", tldTagClass = "org.apache.struts2.views.jsp.DateTag", description = "Render a formatted date.")
/*     */ public class Date
/*     */   extends ContextBean
/*     */ {
/* 150 */   private static final Logger LOG = LogManager.getLogger(Date.class);
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY = "struts.date.format";
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY_PAST = "struts.date.format.past";
/*     */ 
/*     */   
/*     */   private static final String DATETAG_DEFAULT_PAST = "{0} ago";
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY_FUTURE = "struts.date.format.future";
/*     */ 
/*     */   
/*     */   private static final String DATETAG_DEFAULT_FUTURE = "in {0}";
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY_SECONDS = "struts.date.format.seconds";
/*     */ 
/*     */   
/*     */   private static final String DATETAG_DEFAULT_SECONDS = "an instant";
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY_MINUTES = "struts.date.format.minutes";
/*     */ 
/*     */   
/*     */   private static final String DATETAG_DEFAULT_MINUTES = "{0,choice,1#one minute|1<{0} minutes}";
/*     */ 
/*     */   
/*     */   public static final String DATETAG_PROPERTY_HOURS = "struts.date.format.hours";
/*     */ 
/*     */   
/*     */   private static final String DATETAG_DEFAULT_HOURS = "{0,choice,1#one hour|1<{0} hours}{1,choice,0#|1#, one minute|1<, {1} minutes}";
/*     */   
/*     */   public static final String DATETAG_PROPERTY_DAYS = "struts.date.format.days";
/*     */   
/*     */   private static final String DATETAG_DEFAULT_DAYS = "{0,choice,1#one day|1<{0} days}{1,choice,0#|1#, one hour|1<, {1} hours}";
/*     */   
/*     */   public static final String DATETAG_PROPERTY_YEARS = "struts.date.format.years";
/*     */   
/*     */   private static final String DATETAG_DEFAULT_YEARS = "{0,choice,1#one year|1<{0} years}{1,choice,0#|1#, one day|1<, {1} days}";
/*     */   
/*     */   private String name;
/*     */   
/*     */   private String format;
/*     */   
/*     */   private boolean nice;
/*     */   
/*     */   private String timezone;
/*     */ 
/*     */   
/*     */   public Date(ValueStack stack) {
/* 203 */     super(stack);
/*     */   }
/*     */   
/*     */   private TextProvider findProviderInStack() {
/* 207 */     for (Object o : getStack().getRoot()) {
/* 208 */       if (o instanceof TextProvider) {
/* 209 */         return (TextProvider)o;
/*     */       }
/*     */     } 
/* 212 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String formatTime(TextProvider tp, java.util.Date date) {
/* 224 */     java.util.Date now = new java.util.Date();
/* 225 */     StringBuilder sb = new StringBuilder();
/* 226 */     List<Integer> args = new ArrayList();
/* 227 */     long secs = Math.abs((now.getTime() - date.getTime()) / 1000L);
/* 228 */     long mins = secs / 60L;
/* 229 */     long sec = secs % 60L;
/* 230 */     int min = (int)mins % 60;
/* 231 */     long hours = mins / 60L;
/* 232 */     int hour = (int)hours % 24;
/* 233 */     int days = (int)hours / 24;
/* 234 */     int day = days % 365;
/* 235 */     int years = days / 365;
/*     */     
/* 237 */     if (years > 0) {
/* 238 */       args.add(Integer.valueOf(years));
/* 239 */       args.add(Integer.valueOf(day));
/* 240 */       args.add(sb);
/* 241 */       args.add(null);
/* 242 */       sb.append(tp.getText("struts.date.format.years", "{0,choice,1#one year|1<{0} years}{1,choice,0#|1#, one day|1<, {1} days}", args));
/* 243 */     } else if (day > 0) {
/* 244 */       args.add(Integer.valueOf(day));
/* 245 */       args.add(Integer.valueOf(hour));
/* 246 */       args.add(sb);
/* 247 */       args.add(null);
/* 248 */       sb.append(tp.getText("struts.date.format.days", "{0,choice,1#one day|1<{0} days}{1,choice,0#|1#, one hour|1<, {1} hours}", args));
/* 249 */     } else if (hour > 0) {
/* 250 */       args.add(Integer.valueOf(hour));
/* 251 */       args.add(Integer.valueOf(min));
/* 252 */       args.add(sb);
/* 253 */       args.add(null);
/* 254 */       sb.append(tp.getText("struts.date.format.hours", "{0,choice,1#one hour|1<{0} hours}{1,choice,0#|1#, one minute|1<, {1} minutes}", args));
/* 255 */     } else if (min > 0) {
/* 256 */       args.add(Integer.valueOf(min));
/* 257 */       args.add(Long.valueOf(sec));
/* 258 */       args.add(sb);
/* 259 */       args.add(null);
/* 260 */       sb.append(tp.getText("struts.date.format.minutes", "{0,choice,1#one minute|1<{0} minutes}", args));
/*     */     } else {
/* 262 */       args.add(Long.valueOf(sec));
/* 263 */       args.add(sb);
/* 264 */       args.add(null);
/* 265 */       sb.append(tp.getText("struts.date.format.seconds", "an instant", args));
/*     */     } 
/*     */     
/* 268 */     args.clear();
/* 269 */     args.add(sb.toString());
/* 270 */     if (date.before(now))
/*     */     {
/* 272 */       return tp.getText("struts.date.format.past", "{0} ago", args);
/*     */     }
/* 274 */     return tp.getText("struts.date.format.future", "in {0}", args);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 280 */     java.util.Date date = null;
/*     */ 
/*     */     
/*     */     try {
/* 284 */       Object dateObject = findValue(this.name);
/* 285 */       if (dateObject instanceof java.util.Date) {
/* 286 */         date = (java.util.Date)dateObject;
/* 287 */       } else if (dateObject instanceof Calendar) {
/* 288 */         date = ((Calendar)dateObject).getTime();
/* 289 */       } else if (dateObject instanceof Long) {
/* 290 */         date = new java.util.Date(((Long)dateObject).longValue());
/*     */       }
/* 292 */       else if (this.devMode) {
/* 293 */         TextProvider tp = findProviderInStack();
/* 294 */         String developerNotification = "";
/* 295 */         if (tp != null) {
/* 296 */           developerNotification = findProviderInStack().getText("devmode.notification", "Developer Notification:\n{0}", new String[] { "Expression [" + this.name + "] passed to <s:date/> tag which was evaluated to [" + dateObject + "](" + ((dateObject != null) ? (String)dateObject.getClass() : "null") + ") isn't instance of java.util.Date nor java.util.Calendar nor long!" });
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 305 */         LOG.warn(developerNotification);
/*     */       } else {
/* 307 */         LOG.debug("Expression [{}] passed to <s:date/> tag which was evaluated to [{}]({}) isn't instance of java.util.Date nor java.util.Calendar nor long!", this.name, dateObject, (dateObject != null) ? dateObject.getClass() : "null");
/*     */       }
/*     */     
/*     */     }
/* 311 */     catch (Exception e) {
/* 312 */       LOG.error("Could not convert object with key '{}' to a java.util.Date instance", this.name);
/*     */     } 
/*     */ 
/*     */     
/* 316 */     if (this.format != null) {
/* 317 */       this.format = findString(this.format);
/*     */     }
/* 319 */     if (date != null) {
/* 320 */       TextProvider tp = findProviderInStack();
/* 321 */       if (tp != null) {
/* 322 */         String msg; if (this.nice) {
/* 323 */           msg = formatTime(tp, date);
/*     */         } else {
/* 325 */           TimeZone tz = getTimeZone();
/* 326 */           if (this.format == null) {
/* 327 */             String globalFormat = null;
/*     */ 
/*     */ 
/*     */             
/* 331 */             globalFormat = tp.getText("struts.date.format");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 336 */             if (globalFormat != null && !"struts.date.format".equals(globalFormat)) {
/*     */               
/* 338 */               SimpleDateFormat sdf = new SimpleDateFormat(globalFormat, ActionContext.getContext().getLocale());
/*     */               
/* 340 */               sdf.setTimeZone(tz);
/* 341 */               msg = sdf.format(date);
/*     */             } else {
/* 343 */               DateFormat df = DateFormat.getDateTimeInstance(2, 2, ActionContext.getContext().getLocale());
/*     */ 
/*     */               
/* 346 */               df.setTimeZone(tz);
/* 347 */               msg = df.format(date);
/*     */             } 
/*     */           } else {
/* 350 */             SimpleDateFormat sdf = new SimpleDateFormat(this.format, ActionContext.getContext().getLocale());
/*     */             
/* 352 */             sdf.setTimeZone(tz);
/* 353 */             msg = sdf.format(date);
/*     */           } 
/*     */         } 
/* 356 */         if (msg != null) {
/*     */           try {
/* 358 */             if (getVar() == null) {
/* 359 */               writer.write(msg);
/*     */             } else {
/* 361 */               putInContext(msg);
/*     */             } 
/* 363 */           } catch (IOException e) {
/* 364 */             LOG.error("Could not write out Date tag", e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 369 */     return super.end(writer, "");
/*     */   }
/*     */   
/*     */   private TimeZone getTimeZone() {
/* 373 */     TimeZone tz = TimeZone.getDefault();
/* 374 */     if (this.timezone != null) {
/* 375 */       this.timezone = stripExpressionIfAltSyntax(this.timezone);
/* 376 */       String actualTimezone = (String)getStack().findValue(this.timezone, String.class);
/* 377 */       if (actualTimezone != null) {
/* 378 */         this.timezone = actualTimezone;
/*     */       }
/* 380 */       tz = TimeZone.getTimeZone(this.timezone);
/*     */     } 
/* 382 */     return tz;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Date or DateTime format pattern", rtexprvalue = false)
/*     */   public void setFormat(String format) {
/* 387 */     this.format = format;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to print out the date nicely", type = "Boolean", defaultValue = "false")
/*     */   public void setNice(boolean nice) {
/* 392 */     this.nice = nice;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The specific timezone in which to format the date", required = false)
/*     */   public void setTimezone(String timezone) {
/* 397 */     this.timezone = timezone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 404 */     return this.name;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The date value to format", required = true)
/*     */   public void setName(String name) {
/* 409 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 416 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNice() {
/* 423 */     return this.nice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTimezone() {
/* 430 */     return this.timezone;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Date.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */