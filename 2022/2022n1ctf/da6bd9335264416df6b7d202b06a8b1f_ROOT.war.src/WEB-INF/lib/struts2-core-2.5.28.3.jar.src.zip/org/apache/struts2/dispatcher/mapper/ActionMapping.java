/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionMapping
/*     */ {
/*     */   private String name;
/*     */   private String namespace;
/*     */   private String method;
/*     */   private String extension;
/*     */   private Map<String, Object> params;
/*     */   private Result result;
/*     */   
/*     */   public ActionMapping() {
/*  46 */     this.params = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping(Result result) {
/*  55 */     this.result = result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping(String name, String namespace, String method, Map<String, Object> params) {
/*  67 */     this.name = name;
/*  68 */     this.namespace = namespace;
/*  69 */     this.method = method;
/*  70 */     this.params = params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  77 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  84 */     return this.namespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getParams() {
/*  91 */     return this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethod() {
/*  98 */     if (null != this.method && "".equals(this.method)) {
/*  99 */       return null;
/*     */     }
/* 101 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result getResult() {
/* 109 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtension() {
/* 116 */     return this.extension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResult(Result result) {
/* 123 */     this.result = result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 130 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespace(String namespace) {
/* 137 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethod(String method) {
/* 144 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParams(Map<String, Object> params) {
/* 151 */     this.params = params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtension(String extension) {
/* 158 */     this.extension = extension;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 163 */     return "ActionMapping{name='" + this.name + '\'' + ", namespace='" + this.namespace + '\'' + ", method='" + this.method + '\'' + ", extension='" + this.extension + '\'' + ", params=" + this.params + ", result=" + ((this.result != null) ? this.result.getClass().getName() : "null") + '}';
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\ActionMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */