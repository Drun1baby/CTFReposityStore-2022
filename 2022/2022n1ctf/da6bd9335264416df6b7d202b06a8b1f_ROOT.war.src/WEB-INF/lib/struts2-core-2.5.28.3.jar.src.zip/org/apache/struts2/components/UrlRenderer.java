package org.apache.struts2.components;

import java.io.Writer;
import org.apache.struts2.dispatcher.mapper.ActionMapper;

public interface UrlRenderer {
  void beforeRenderUrl(UrlProvider paramUrlProvider);
  
  void renderUrl(Writer paramWriter, UrlProvider paramUrlProvider);
  
  void renderFormUrl(Form paramForm);
  
  void setActionMapper(ActionMapper paramActionMapper);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\UrlRenderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */