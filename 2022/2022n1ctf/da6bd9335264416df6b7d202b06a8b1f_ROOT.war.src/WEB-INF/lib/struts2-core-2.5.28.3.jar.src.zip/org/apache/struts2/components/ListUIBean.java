/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.util.ContainUtil;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListUIBean
/*     */   extends UIBean
/*     */ {
/*     */   protected Object list;
/*     */   protected String listKey;
/*     */   protected String listValueKey;
/*     */   protected String listValue;
/*     */   protected String listLabelKey;
/*     */   protected String listCssClass;
/*     */   protected String listCssStyle;
/*     */   protected String listTitle;
/*     */   protected boolean throwExceptionOnNullValueAttribute = false;
/*     */   
/*     */   protected ListUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  61 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/*  65 */     Object value = null;
/*     */     
/*  67 */     if (this.list == null) {
/*  68 */       this.list = this.parameters.get("list");
/*     */     }
/*     */     
/*  71 */     if (this.list instanceof String) {
/*  72 */       value = findValue((String)this.list);
/*  73 */     } else if (this.list instanceof Collection) {
/*  74 */       value = this.list;
/*  75 */     } else if (MakeIterator.isIterable(this.list)) {
/*  76 */       value = MakeIterator.convert(this.list);
/*     */     } 
/*  78 */     if (value == null) {
/*  79 */       if (this.throwExceptionOnNullValueAttribute) {
/*     */         
/*  81 */         value = findValue((this.list == null) ? (String)this.list : this.list.toString(), "list", "The requested list key '" + this.list + "' could not be resolved as a collection/array/map/enumeration/iterator type. " + "Example: people or people.{name}");
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/*  87 */         value = findValue((this.list == null) ? (String)this.list : this.list.toString());
/*     */       } 
/*     */     }
/*     */     
/*  91 */     if (value instanceof Collection) {
/*  92 */       addParameter("list", value);
/*     */     } else {
/*  94 */       addParameter("list", MakeIterator.convert(value));
/*     */     } 
/*     */     
/*  97 */     if (value instanceof Collection) {
/*  98 */       addParameter("listSize", Integer.valueOf(((Collection)value).size()));
/*  99 */     } else if (value instanceof Map) {
/* 100 */       addParameter("listSize", Integer.valueOf(((Map)value).size()));
/* 101 */     } else if (value != null && value.getClass().isArray()) {
/* 102 */       addParameter("listSize", Integer.valueOf(Array.getLength(value)));
/*     */     } 
/*     */     
/* 105 */     if (this.listKey != null) {
/* 106 */       this.listKey = stripExpressionIfAltSyntax(this.listKey);
/* 107 */       addParameter("listKey", this.listKey);
/* 108 */     } else if (value instanceof Map) {
/* 109 */       addParameter("listKey", "key");
/*     */     } 
/*     */     
/* 112 */     if (this.listValueKey != null) {
/* 113 */       this.listValueKey = stripExpressionIfAltSyntax(this.listValueKey);
/* 114 */       addParameter("listValueKey", this.listValueKey);
/*     */     } 
/*     */     
/* 117 */     if (this.listValue != null) {
/* 118 */       this.listValue = stripExpressionIfAltSyntax(this.listValue);
/* 119 */       addParameter("listValue", this.listValue);
/* 120 */     } else if (value instanceof Map) {
/* 121 */       addParameter("listValue", "value");
/*     */     } 
/*     */     
/* 124 */     if (this.listLabelKey != null) {
/* 125 */       this.listLabelKey = stripExpressionIfAltSyntax(this.listLabelKey);
/* 126 */       addParameter("listLabelKey", this.listLabelKey);
/*     */     } 
/*     */     
/* 129 */     if (StringUtils.isNotBlank(this.listCssClass)) {
/* 130 */       addParameter("listCssClass", this.listCssClass);
/*     */     }
/*     */     
/* 133 */     if (StringUtils.isNotBlank(this.listCssStyle)) {
/* 134 */       addParameter("listCssStyle", this.listCssStyle);
/*     */     }
/*     */     
/* 137 */     if (StringUtils.isNotBlank(this.listTitle)) {
/* 138 */       addParameter("listTitle", this.listTitle);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean contains(Object obj1, Object obj2) {
/* 143 */     return ContainUtil.contains(obj1, obj2);
/*     */   }
/*     */   
/*     */   protected Class getValueClassType() {
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Iterable source to populate from. If the list is a Map (key, value), the Map key will become the option 'value' parameter and the Map value will become the option body.", required = true)
/*     */   public void setList(Object list) {
/* 153 */     this.list = list;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get field value from")
/*     */   public void setListKey(String listKey) {
/* 158 */     this.listKey = listKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get field value label from")
/*     */   public void setListValueKey(String listValueKey) {
/* 163 */     this.listValueKey = listValueKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get field content from")
/*     */   public void setListValue(String listValue) {
/* 168 */     this.listValue = listValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to be used to lookup for localised version of field label")
/*     */   public void setListLabelKey(String listLabelKey) {
/* 173 */     this.listLabelKey = listLabelKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get css class from")
/*     */   public void setListCssClass(String listCssClass) {
/* 178 */     this.listCssClass = listCssClass;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get css style from")
/*     */   public void setListCssStyle(String listCssStyle) {
/* 183 */     this.listCssStyle = listCssStyle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get title from")
/*     */   public void setListTitle(String listTitle) {
/* 188 */     this.listTitle = listTitle;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setThrowExceptionOnNullValueAttribute(boolean throwExceptionOnNullValueAttribute) {
/* 193 */     this.throwExceptionOnNullValueAttribute = throwExceptionOnNullValueAttribute;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ListUIBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */