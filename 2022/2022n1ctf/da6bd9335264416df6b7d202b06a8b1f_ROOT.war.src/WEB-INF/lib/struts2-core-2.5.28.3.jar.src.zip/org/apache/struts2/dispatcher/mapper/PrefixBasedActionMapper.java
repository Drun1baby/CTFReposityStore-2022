/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixBasedActionMapper
/*     */   extends DefaultActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  63 */   private static final Logger LOG = LogManager.getLogger(PrefixBasedActionMapper.class);
/*     */   
/*     */   protected Container container;
/*  66 */   protected Map<String, ActionMapper> actionMappers = new HashMap<>();
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  70 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject("struts.mapper.prefixMapping")
/*     */   public void setPrefixBasedActionMappers(String list) {
/*  75 */     String[] mappers = StringUtils.split(StringUtils.trimToEmpty(list), ",");
/*  76 */     for (String mapper : mappers) {
/*  77 */       String[] thisMapper = mapper.split(":");
/*  78 */       if (thisMapper.length == 2) {
/*  79 */         String mapperPrefix = thisMapper[0].trim();
/*  80 */         String mapperName = thisMapper[1].trim();
/*  81 */         Object obj = this.container.getInstance(ActionMapper.class, mapperName);
/*  82 */         if (obj != null) {
/*  83 */           this.actionMappers.put(mapperPrefix, (ActionMapper)obj);
/*     */         } else {
/*  85 */           LOG.debug("invalid PrefixBasedActionMapper config entry: [{}]", mapper);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager) {
/*  94 */     String uri = RequestUtils.getUri(request); int lastIndex;
/*  95 */     for (lastIndex = uri.lastIndexOf('/'); lastIndex > -1; lastIndex = uri.lastIndexOf('/', lastIndex - 1)) {
/*  96 */       ActionMapper actionMapper = this.actionMappers.get(uri.substring(0, lastIndex));
/*  97 */       if (actionMapper != null) {
/*  98 */         ActionMapping actionMapping = actionMapper.getMapping(request, configManager);
/*  99 */         LOG.debug("Using ActionMapper [{}]", actionMapper);
/* 100 */         if (actionMapping != null) {
/* 101 */           if (LOG.isDebugEnabled() && 
/* 102 */             actionMapping.getParams() != null) {
/* 103 */             LOG.debug("ActionMapper found mapping. Parameters: [{}]", actionMapping.getParams().toString());
/* 104 */             for (Map.Entry<String, Object> mappingParameterEntry : actionMapping.getParams().entrySet()) {
/* 105 */               Object paramValue = mappingParameterEntry.getValue();
/* 106 */               if (paramValue == null) {
/* 107 */                 LOG.debug("[{}] : null!", mappingParameterEntry.getKey()); continue;
/* 108 */               }  if (paramValue instanceof String[]) {
/* 109 */                 LOG.debug("[{}] : (String[]) {}", mappingParameterEntry.getKey(), Arrays.toString((Object[])paramValue)); continue;
/* 110 */               }  if (paramValue instanceof String) {
/* 111 */                 LOG.debug("[{}] : (String) [{}]", mappingParameterEntry.getKey(), paramValue.toString()); continue;
/*     */               } 
/* 113 */               LOG.debug("[{}] : (Object) [{}]", mappingParameterEntry.getKey(), paramValue.toString());
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 118 */           return actionMapping;
/*     */         } 
/* 120 */         LOG.debug("ActionMapper [{}] failed to return an ActionMapping", actionMapper);
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     LOG.debug("No ActionMapper found");
/* 125 */     return null;
/*     */   }
/*     */   
/*     */   public String getUriFromActionMapping(ActionMapping mapping) {
/* 129 */     String namespace = mapping.getNamespace();
/* 130 */     for (int lastIndex = namespace.length(); lastIndex > -1; lastIndex = namespace.lastIndexOf('/', lastIndex - 1)) {
/* 131 */       ActionMapper actionMapper = this.actionMappers.get(namespace.substring(0, lastIndex));
/* 132 */       if (actionMapper != null) {
/* 133 */         String uri = actionMapper.getUriFromActionMapping(mapping);
/* 134 */         LOG.debug("Using ActionMapper [{}]", actionMapper);
/* 135 */         if (uri != null)
/* 136 */           return uri; 
/* 137 */         if (LOG.isDebugEnabled()) {
/* 138 */           LOG.debug("ActionMapper [{}] failed to return an ActionMapping (null)", actionMapper);
/*     */         }
/*     */       } 
/*     */     } 
/* 142 */     LOG.debug("ActionMapper failed to return a uri");
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\PrefixBasedActionMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */