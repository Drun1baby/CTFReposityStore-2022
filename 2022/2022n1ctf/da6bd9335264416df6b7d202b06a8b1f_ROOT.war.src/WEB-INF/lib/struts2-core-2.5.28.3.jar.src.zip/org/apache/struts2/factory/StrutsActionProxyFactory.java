/*    */ package org.apache.struts2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.ActionProxy;
/*    */ import com.opensymphony.xwork2.DefaultActionProxyFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsActionProxyFactory
/*    */   extends DefaultActionProxyFactory
/*    */ {
/*    */   public ActionProxy createActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext) {
/* 30 */     StrutsActionProxy proxy = new StrutsActionProxy(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/* 31 */     this.container.inject(proxy);
/* 32 */     proxy.prepare();
/* 33 */     return (ActionProxy)proxy;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\factory\StrutsActionProxyFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */