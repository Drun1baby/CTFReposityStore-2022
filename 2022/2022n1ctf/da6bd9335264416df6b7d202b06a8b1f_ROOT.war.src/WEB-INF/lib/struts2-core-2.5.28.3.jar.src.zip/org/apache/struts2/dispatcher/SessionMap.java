/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionMap<K, V>
/*     */   extends AbstractMap<K, V>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4678843241638046854L;
/*     */   protected HttpSession session;
/*     */   protected Set<Map.Entry<K, V>> entries;
/*     */   protected HttpServletRequest request;
/*     */   
/*     */   public SessionMap(HttpServletRequest request) {
/*  50 */     this.request = request;
/*  51 */     this.session = request.getSession(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidate() {
/*  58 */     if (this.session == null) {
/*     */       return;
/*     */     }
/*     */     
/*  62 */     synchronized (this.session.getId().intern()) {
/*  63 */       this.session.invalidate();
/*  64 */       this.session = null;
/*  65 */       this.entries = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  75 */     if (this.session == null) {
/*     */       return;
/*     */     }
/*     */     
/*  79 */     synchronized (this.session.getId().intern()) {
/*  80 */       this.entries = null;
/*  81 */       Enumeration<String> attributeNamesEnum = this.session.getAttributeNames();
/*  82 */       while (attributeNamesEnum.hasMoreElements()) {
/*  83 */         this.session.removeAttribute(attributeNamesEnum.nextElement());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/*  96 */     if (this.session == null) {
/*  97 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 100 */     synchronized (this.session.getId().intern()) {
/* 101 */       if (this.entries == null) {
/* 102 */         this.entries = new HashSet<>();
/*     */         
/* 104 */         Enumeration<?> enumeration = this.session.getAttributeNames();
/*     */         
/* 106 */         while (enumeration.hasMoreElements()) {
/* 107 */           final String key = enumeration.nextElement().toString();
/* 108 */           final Object value = this.session.getAttribute(key);
/* 109 */           this.entries.add(new Map.Entry<K, V>() {
/*     */                 public boolean equals(Object obj) {
/* 111 */                   if (!(obj instanceof Map.Entry)) {
/* 112 */                     return false;
/*     */                   }
/* 114 */                   Map.Entry<K, V> entry = (Map.Entry<K, V>)obj;
/*     */                   
/* 116 */                   if ((key == null) ? (entry.getKey() == null) : key.equals(entry.getKey())) if ((value == null) ? (entry.getValue() == null) : value.equals(entry.getValue()));  return false;
/*     */                 }
/*     */                 
/*     */                 public int hashCode() {
/* 120 */                   return ((key == null) ? 0 : key.hashCode()) ^ ((value == null) ? 0 : value.hashCode());
/*     */                 }
/*     */                 
/*     */                 public K getKey() {
/* 124 */                   return (K)key;
/*     */                 }
/*     */                 
/*     */                 public V getValue() {
/* 128 */                   return (V)value;
/*     */                 }
/*     */                 
/*     */                 public V setValue(Object obj) {
/* 132 */                   SessionMap.this.session.setAttribute(key, obj);
/*     */                   
/* 134 */                   return (V)value;
/*     */                 }
/*     */               });
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 141 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 152 */     if (this.session == null) {
/* 153 */       return null;
/*     */     }
/*     */     
/* 156 */     synchronized (this.session.getId().intern()) {
/* 157 */       return (V)this.session.getAttribute(key.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 169 */     synchronized (this) {
/* 170 */       if (this.session == null) {
/* 171 */         this.session = this.request.getSession(true);
/*     */       }
/*     */     } 
/* 174 */     synchronized (this.session.getId().intern()) {
/* 175 */       V oldValue = get(key);
/* 176 */       this.entries = null;
/* 177 */       this.session.setAttribute(key.toString(), value);
/* 178 */       return oldValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 189 */     if (this.session == null) {
/* 190 */       return null;
/*     */     }
/*     */     
/* 193 */     synchronized (this.session.getId().intern()) {
/* 194 */       this.entries = null;
/*     */       
/* 196 */       V value = get(key);
/* 197 */       this.session.removeAttribute(key.toString());
/*     */       
/* 199 */       return value;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 211 */     if (this.session == null) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     synchronized (this.session.getId().intern()) {
/* 216 */       return (this.session.getAttribute(key.toString()) != null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\SessionMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */