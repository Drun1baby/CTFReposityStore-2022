/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrutsRequestWrapper
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*     */   private static final String REQUEST_WRAPPER_GET_ATTRIBUTE = "__requestWrapper.getAttribute";
/*     */   private final boolean disableRequestAttributeValueStackLookup;
/*     */   
/*     */   public StrutsRequestWrapper(HttpServletRequest req) {
/*  51 */     this(req, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StrutsRequestWrapper(HttpServletRequest req, boolean disableRequestAttributeValueStackLookup) {
/*  60 */     super(req);
/*  61 */     this.disableRequestAttributeValueStackLookup = disableRequestAttributeValueStackLookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String key) {
/*  70 */     if (key == null) {
/*  71 */       throw new NullPointerException("You must specify a key value");
/*     */     }
/*     */     
/*  74 */     if (this.disableRequestAttributeValueStackLookup || key.startsWith("javax.servlet"))
/*     */     {
/*     */       
/*  77 */       return super.getAttribute(key);
/*     */     }
/*     */     
/*  80 */     ActionContext ctx = ActionContext.getContext();
/*  81 */     Object attribute = super.getAttribute(key);
/*     */     
/*  83 */     if (ctx != null && attribute == null) {
/*  84 */       boolean alreadyIn = BooleanUtils.isTrue((Boolean)ctx.get("__requestWrapper.getAttribute"));
/*     */ 
/*     */ 
/*     */       
/*  88 */       if (!alreadyIn && !key.contains("#")) {
/*     */         
/*     */         try {
/*  91 */           ctx.put("__requestWrapper.getAttribute", Boolean.TRUE);
/*  92 */           ValueStack stack = ctx.getValueStack();
/*  93 */           if (stack != null) {
/*  94 */             attribute = stack.findValue(key);
/*     */           }
/*     */         } finally {
/*  97 */           ctx.put("__requestWrapper.getAttribute", Boolean.FALSE);
/*     */         } 
/*     */       }
/*     */     } 
/* 101 */     return attribute;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\StrutsRequestWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */