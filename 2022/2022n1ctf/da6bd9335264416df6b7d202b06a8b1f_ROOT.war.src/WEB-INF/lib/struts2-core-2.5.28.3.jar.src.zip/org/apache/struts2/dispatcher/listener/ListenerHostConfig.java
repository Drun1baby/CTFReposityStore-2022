/*    */ package org.apache.struts2.dispatcher.listener;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.HostConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListenerHostConfig
/*    */   implements HostConfig
/*    */ {
/*    */   private ServletContext servletContext;
/*    */   
/*    */   public ListenerHostConfig(ServletContext servletContext) {
/* 34 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */   public String getInitParameter(String key) {
/* 38 */     return null;
/*    */   }
/*    */   
/*    */   public Iterator<String> getInitParameterNames() {
/* 42 */     return Collections.<String>emptyList().iterator();
/*    */   }
/*    */   
/*    */   public ServletContext getServletContext() {
/* 46 */     return this.servletContext;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\listener\ListenerHostConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */