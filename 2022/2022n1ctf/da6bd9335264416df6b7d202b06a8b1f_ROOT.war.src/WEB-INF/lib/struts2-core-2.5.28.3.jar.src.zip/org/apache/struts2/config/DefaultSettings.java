/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.location.Location;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSettings
/*    */   implements Settings
/*    */ {
/* 38 */   private static final Logger LOG = LogManager.getLogger(DefaultSettings.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Settings delegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultSettings() {
/* 56 */     ArrayList<Settings> list = new ArrayList<>();
/*    */ 
/*    */     
/*    */     try {
/* 60 */       list.add(new PropertiesSettings("struts"));
/* 61 */     } catch (Exception e) {
/* 62 */       LOG.warn("DefaultSettings: Could not find or error in struts.properties", e);
/*    */     } 
/*    */     
/* 65 */     this.delegate = new DelegatingSettings(list);
/*    */ 
/*    */     
/* 68 */     String files = this.delegate.get("struts.custom.properties");
/* 69 */     if (files != null) {
/* 70 */       StringTokenizer customProperties = new StringTokenizer(files, ",");
/*    */       
/* 72 */       while (customProperties.hasMoreTokens()) {
/* 73 */         String name = customProperties.nextToken();
/*    */         try {
/* 75 */           list.add(new PropertiesSettings(name));
/* 76 */         } catch (Exception e) {
/* 77 */           LOG.error("DefaultSettings: Could not find {}.properties. Skipping.", name);
/*    */         } 
/*    */       } 
/*    */       
/* 81 */       this.delegate = new DelegatingSettings(list);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Location getLocation(String name) {
/* 86 */     return this.delegate.getLocation(name);
/*    */   }
/*    */   
/*    */   public String get(String aName) throws IllegalArgumentException {
/* 90 */     return this.delegate.get(aName);
/*    */   }
/*    */   
/*    */   public Iterator list() {
/* 94 */     return this.delegate.list();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\DefaultSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */