/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.util.URLDecoderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RestfulActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  38 */   protected static final Logger LOG = LogManager.getLogger(RestfulActionMapper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager) {
/*  44 */     String uri = RequestUtils.getServletPath(request);
/*     */     
/*  46 */     int nextSlash = uri.indexOf('/', 1);
/*  47 */     if (nextSlash == -1) {
/*  48 */       return null;
/*     */     }
/*     */     
/*  51 */     String actionName = uri.substring(1, nextSlash);
/*  52 */     Map<String, Object> parameters = new HashMap<>();
/*     */     try {
/*  54 */       StringTokenizer st = new StringTokenizer(uri.substring(nextSlash), "/");
/*  55 */       boolean isNameTok = true;
/*  56 */       String paramName = null;
/*     */ 
/*     */ 
/*     */       
/*  60 */       if (st.countTokens() % 2 != 0) {
/*  61 */         isNameTok = false;
/*  62 */         paramName = actionName + "Id";
/*     */       } 
/*     */       
/*  65 */       while (st.hasMoreTokens()) {
/*  66 */         if (isNameTok) {
/*  67 */           paramName = URLDecoderUtil.decode(st.nextToken(), "UTF-8");
/*  68 */           isNameTok = false; continue;
/*     */         } 
/*  70 */         String paramValue = URLDecoderUtil.decode(st.nextToken(), "UTF-8");
/*     */         
/*  72 */         if (paramName != null && paramName.length() > 0) {
/*  73 */           parameters.put(paramName, paramValue);
/*     */         }
/*     */         
/*  76 */         isNameTok = true;
/*     */       }
/*     */     
/*  79 */     } catch (Exception e) {
/*  80 */       LOG.warn("Cannot determine url parameters", e);
/*     */     } 
/*     */     
/*  83 */     return new ActionMapping(actionName, "", "", parameters);
/*     */   }
/*     */   
/*     */   public ActionMapping getMappingFromActionName(String actionName) {
/*  87 */     return new ActionMapping(actionName, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUriFromActionMapping(ActionMapping mapping) {
/*  94 */     StringBuilder retVal = new StringBuilder();
/*  95 */     retVal.append(mapping.getNamespace());
/*  96 */     retVal.append(mapping.getName());
/*  97 */     Object value = mapping.getParams().get(mapping.getName() + "Id");
/*  98 */     if (value != null) {
/*  99 */       retVal.append("/");
/* 100 */       retVal.append(value);
/*     */     } 
/*     */     
/* 103 */     return retVal.toString();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\RestfulActionMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */