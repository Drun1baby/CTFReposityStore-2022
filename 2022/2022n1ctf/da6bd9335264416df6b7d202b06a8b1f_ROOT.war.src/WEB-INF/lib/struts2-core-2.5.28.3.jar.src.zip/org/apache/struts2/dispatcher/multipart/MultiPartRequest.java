package org.apache.struts2.dispatcher.multipart;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.dispatcher.LocalizedMessage;

public interface MultiPartRequest {
  void parse(HttpServletRequest paramHttpServletRequest, String paramString) throws IOException;
  
  Enumeration<String> getFileParameterNames();
  
  String[] getContentType(String paramString);
  
  UploadedFile[] getFile(String paramString);
  
  String[] getFileNames(String paramString);
  
  String[] getFilesystemName(String paramString);
  
  String getParameter(String paramString);
  
  Enumeration<String> getParameterNames();
  
  String[] getParameterValues(String paramString);
  
  List<LocalizedMessage> getErrors();
  
  void cleanUp();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\multipart\MultiPartRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */