/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.Parameter;
/*     */ import org.apache.struts2.dispatcher.PrepareOperations;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebuggingInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -3097324155953078783L;
/*  93 */   private static final Logger LOG = LogManager.getLogger(DebuggingInterceptor.class);
/*     */   
/*  95 */   private String[] ignorePrefixes = new String[] { "org.apache.struts.", "com.opensymphony.xwork2.", "xwork." };
/*     */   
/*  97 */   private String[] _ignoreKeys = new String[] { "application", "session", "parameters", "request" };
/*     */   
/*  99 */   private HashSet<String> ignoreKeys = new HashSet<>(Arrays.asList(this._ignoreKeys));
/*     */   
/*     */   private static final String XML_MODE = "xml";
/*     */   
/*     */   private static final String CONSOLE_MODE = "console";
/*     */   
/*     */   private static final String COMMAND_MODE = "command";
/*     */   
/*     */   private static final String BROWSER_MODE = "browser";
/*     */   
/*     */   private static final String SESSION_KEY = "org.apache.struts2.interceptor.debugging.VALUE_STACK";
/*     */   
/*     */   private static final String DEBUG_PARAM = "debug";
/*     */   private static final String OBJECT_PARAM = "object";
/*     */   private static final String EXPRESSION_PARAM = "expression";
/*     */   private static final String DECORATE_PARAM = "decorate";
/*     */   private boolean enableXmlWithConsole = false;
/*     */   private boolean devMode;
/*     */   private FreemarkerManager freemarkerManager;
/*     */   private boolean consoleEnabled = false;
/*     */   private ReflectionProvider reflectionProvider;
/*     */   
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode) {
/* 123 */     this.devMode = "true".equals(mode);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager mgr) {
/* 128 */     this.freemarkerManager = mgr;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 133 */     this.reflectionProvider = reflectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation inv) throws Exception {
/* 142 */     boolean actionOnly = false;
/* 143 */     boolean cont = true;
/* 144 */     Boolean devModeOverride = PrepareOperations.getDevModeOverride();
/* 145 */     boolean devMode = (devModeOverride != null) ? devModeOverride.booleanValue() : this.devMode;
/* 146 */     if (devMode) {
/* 147 */       final ActionContext ctx = ActionContext.getContext();
/* 148 */       String type = getParameter("debug");
/* 149 */       ctx.getParameters().remove("debug");
/* 150 */       if ("xml".equals(type)) {
/* 151 */         inv.addPreResultListener(new PreResultListener()
/*     */             {
/*     */               public void beforeResult(ActionInvocation inv, String result) {
/* 154 */                 DebuggingInterceptor.this.printContext();
/*     */               }
/*     */             });
/* 157 */       } else if ("console".equals(type)) {
/* 158 */         this.consoleEnabled = true;
/* 159 */         inv.addPreResultListener(new PreResultListener()
/*     */             {
/*     */               public void beforeResult(ActionInvocation inv, String actionResult) {
/* 162 */                 String xml = "";
/* 163 */                 if (DebuggingInterceptor.this.enableXmlWithConsole) {
/* 164 */                   StringWriter writer = new StringWriter();
/* 165 */                   DebuggingInterceptor.this.printContext(new PrettyPrintWriter(writer));
/* 166 */                   xml = writer.toString();
/* 167 */                   xml = xml.replaceAll("&", "&amp;");
/* 168 */                   xml = xml.replaceAll(">", "&gt;");
/* 169 */                   xml = xml.replaceAll("<", "&lt;");
/*     */                 } 
/* 171 */                 ActionContext.getContext().put("debugXML", xml);
/*     */                 
/* 173 */                 FreemarkerResult result = new FreemarkerResult();
/* 174 */                 result.setFreemarkerManager(DebuggingInterceptor.this.freemarkerManager);
/* 175 */                 result.setContentType("text/html");
/* 176 */                 result.setLocation("/org/apache/struts2/interceptor/debugging/console.ftl");
/* 177 */                 result.setParse(false);
/*     */                 try {
/* 179 */                   result.execute(inv);
/* 180 */                 } catch (Exception ex) {
/* 181 */                   DebuggingInterceptor.LOG.error("Unable to create debugging console", ex);
/*     */                 }
/*     */               
/*     */               }
/*     */             });
/* 186 */       } else if ("command".equals(type)) {
/* 187 */         ValueStack stack = (ValueStack)ctx.getSession().get("org.apache.struts2.interceptor.debugging.VALUE_STACK");
/* 188 */         if (stack == null) {
/*     */           
/* 190 */           stack = (ValueStack)ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 191 */           ctx.getSession().put("org.apache.struts2.interceptor.debugging.VALUE_STACK", stack);
/*     */         } 
/* 193 */         String cmd = getParameter("expression");
/*     */         
/* 195 */         ServletActionContext.getRequest().setAttribute("decorator", "none");
/* 196 */         HttpServletResponse res = ServletActionContext.getResponse();
/* 197 */         res.setContentType("text/plain");
/*     */         
/* 199 */         try (PrintWriter writer = ServletActionContext.getResponse().getWriter()) {
/*     */           
/* 201 */           writer.print(stack.findValue(cmd));
/* 202 */         } catch (IOException ex) {
/* 203 */           ex.printStackTrace();
/*     */         } 
/* 205 */         cont = false;
/* 206 */       } else if ("browser".equals(type)) {
/* 207 */         actionOnly = true;
/* 208 */         inv.addPreResultListener(new PreResultListener()
/*     */             {
/*     */               public void beforeResult(ActionInvocation inv, String actionResult) {
/* 211 */                 String rootObjectExpression = DebuggingInterceptor.this.getParameter("object");
/* 212 */                 if (rootObjectExpression == null)
/* 213 */                   rootObjectExpression = "#context"; 
/* 214 */                 String decorate = DebuggingInterceptor.this.getParameter("decorate");
/* 215 */                 ValueStack stack = (ValueStack)ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 216 */                 Object rootObject = stack.findValue(rootObjectExpression);
/*     */                 
/* 218 */                 try (StringWriter writer = new StringWriter()) {
/* 219 */                   ObjectToHTMLWriter htmlWriter = new ObjectToHTMLWriter(writer);
/* 220 */                   htmlWriter.write(DebuggingInterceptor.this.reflectionProvider, rootObject, rootObjectExpression);
/* 221 */                   String html = writer.toString();
/* 222 */                   writer.close();
/*     */                   
/* 224 */                   stack.set("debugHtml", html);
/*     */ 
/*     */ 
/*     */                   
/* 228 */                   if ("false".equals(decorate)) {
/* 229 */                     ServletActionContext.getRequest().setAttribute("decorator", "none");
/*     */                   }
/* 231 */                   FreemarkerResult result = new FreemarkerResult();
/* 232 */                   result.setFreemarkerManager(DebuggingInterceptor.this.freemarkerManager);
/* 233 */                   result.setContentType("text/html");
/* 234 */                   result.setLocation("/org/apache/struts2/interceptor/debugging/browser.ftl");
/* 235 */                   result.execute(inv);
/* 236 */                 } catch (Exception ex) {
/* 237 */                   DebuggingInterceptor.LOG.error("Unable to create debugging console", ex);
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */     
/* 244 */     if (cont) {
/*     */       try {
/* 246 */         if (actionOnly) {
/* 247 */           inv.invokeActionOnly();
/* 248 */           return null;
/*     */         } 
/* 250 */         return inv.invoke();
/*     */       } finally {
/*     */         
/* 253 */         if (devMode && this.consoleEnabled) {
/* 254 */           final ActionContext ctx = ActionContext.getContext();
/* 255 */           ctx.getSession().put("org.apache.struts2.interceptor.debugging.VALUE_STACK", ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack"));
/*     */         } 
/*     */       } 
/*     */     }
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getParameter(String key) {
/* 270 */     Parameter parameter = ActionContext.getContext().getParameters().get(key);
/* 271 */     return parameter.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printContext() {
/* 278 */     HttpServletResponse res = ServletActionContext.getResponse();
/* 279 */     res.setContentType("text/xml");
/*     */     
/*     */     try {
/* 282 */       PrettyPrintWriter writer = new PrettyPrintWriter(ServletActionContext.getResponse().getWriter());
/*     */       
/* 284 */       printContext(writer);
/* 285 */       writer.close();
/* 286 */     } catch (IOException ex) {
/* 287 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printContext(PrettyPrintWriter writer) {
/* 297 */     ActionContext ctx = ActionContext.getContext();
/* 298 */     writer.startNode("debug");
/* 299 */     serializeIt(ctx.getParameters(), "parameters", writer, new ArrayList());
/* 300 */     writer.startNode("context");
/*     */     
/* 302 */     Map ctxMap = ctx.getContextMap();
/* 303 */     for (Object o : ctxMap.keySet()) {
/* 304 */       String key = o.toString();
/* 305 */       boolean print = !this.ignoreKeys.contains(key);
/*     */       
/* 307 */       for (String ignorePrefixe : this.ignorePrefixes) {
/* 308 */         if (key.startsWith(ignorePrefixe)) {
/* 309 */           print = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 313 */       if (print) {
/* 314 */         serializeIt(ctxMap.get(key), key, writer, new ArrayList());
/*     */       }
/*     */     } 
/* 317 */     writer.endNode();
/* 318 */     Map requestMap = (Map)ctx.get("request");
/* 319 */     serializeIt(requestMap, "request", writer, filterValueStack(requestMap));
/* 320 */     serializeIt(ctx.getSession(), "session", writer, new ArrayList());
/*     */     
/* 322 */     ValueStack stack = (ValueStack)ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 323 */     serializeIt(stack.getRoot(), "valueStack", writer, new ArrayList());
/* 324 */     writer.endNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serializeIt(Object bean, String name, PrettyPrintWriter writer, List<Object> stack) {
/* 342 */     writer.flush();
/*     */     
/* 344 */     if (bean != null && stack.contains(bean)) {
/* 345 */       LOG.info("Circular reference detected, not serializing object: {}", name); return;
/*     */     } 
/* 347 */     if (bean != null)
/*     */     {
/*     */       
/* 350 */       stack.add(bean);
/*     */     }
/* 352 */     if (bean == null) {
/*     */       return;
/*     */     }
/* 355 */     String clsName = bean.getClass().getName();
/*     */     
/* 357 */     writer.startNode(name);
/*     */ 
/*     */     
/* 360 */     if (bean instanceof Collection) {
/* 361 */       Collection col = (Collection)bean;
/*     */ 
/*     */ 
/*     */       
/* 365 */       for (Object aCol : col) {
/* 366 */         serializeIt(aCol, "value", writer, stack);
/*     */       }
/* 368 */     } else if (bean instanceof Map) {
/*     */       
/* 370 */       Map<Object, Object> map = (Map<Object, Object>)bean;
/*     */ 
/*     */       
/* 373 */       for (Map.Entry<Object, Object> entry : map.entrySet()) {
/* 374 */         Object objValue = entry.getValue();
/* 375 */         serializeIt(objValue, entry.getKey().toString(), writer, stack);
/*     */       } 
/* 377 */     } else if (bean.getClass().isArray()) {
/*     */       
/* 379 */       for (int i = 0; i < Array.getLength(bean); i++) {
/* 380 */         serializeIt(Array.get(bean, i), "arrayitem", writer, stack);
/*     */       }
/*     */     }
/* 383 */     else if (clsName.startsWith("java.lang")) {
/* 384 */       writer.setValue(bean.toString());
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 389 */         BeanInfo info = Introspector.getBeanInfo(bean.getClass());
/* 390 */         PropertyDescriptor[] props = info.getPropertyDescriptors();
/*     */         
/* 392 */         for (PropertyDescriptor prop : props) {
/* 393 */           String n = prop.getName();
/* 394 */           Method m = prop.getReadMethod();
/*     */ 
/*     */ 
/*     */           
/* 398 */           if (m != null) {
/* 399 */             serializeIt(m.invoke(bean, new Object[0]), n, writer, stack);
/*     */           }
/*     */         } 
/* 402 */       } catch (Exception e) {
/* 403 */         LOG.error(e.toString(), e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 408 */     writer.endNode();
/*     */ 
/*     */     
/* 411 */     stack.remove(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableXmlWithConsole(boolean enableXmlWithConsole) {
/* 418 */     this.enableXmlWithConsole = enableXmlWithConsole;
/*     */   }
/*     */   
/*     */   private List<Object> filterValueStack(Map requestMap) {
/* 422 */     List<Object> filter = new ArrayList();
/* 423 */     Object valueStack = requestMap.get("struts.valueStack");
/* 424 */     if (valueStack != null) {
/* 425 */       filter.add(valueStack);
/*     */     }
/* 427 */     return filter;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\interceptor\debugging\DebuggingInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */