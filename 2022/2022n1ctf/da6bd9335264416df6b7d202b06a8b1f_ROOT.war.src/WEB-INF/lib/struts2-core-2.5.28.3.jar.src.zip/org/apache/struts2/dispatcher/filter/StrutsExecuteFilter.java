/*    */ package org.apache.struts2.dispatcher.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.StrutsStatics;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.ExecuteOperations;
/*    */ import org.apache.struts2.dispatcher.InitOperations;
/*    */ import org.apache.struts2.dispatcher.PrepareOperations;
/*    */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsExecuteFilter
/*    */   implements StrutsStatics, Filter
/*    */ {
/*    */   protected PrepareOperations prepare;
/*    */   protected ExecuteOperations execute;
/*    */   protected FilterConfig filterConfig;
/*    */   
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 44 */     this.filterConfig = filterConfig;
/*    */   }
/*    */   
/*    */   protected synchronized void lazyInit() {
/* 48 */     if (this.execute == null) {
/* 49 */       InitOperations init = new InitOperations();
/* 50 */       Dispatcher dispatcher = init.findDispatcherOnThread();
/* 51 */       init.initStaticContentLoader(new FilterHostConfig(this.filterConfig), dispatcher);
/*    */       
/* 53 */       this.prepare = new PrepareOperations(dispatcher);
/* 54 */       this.execute = new ExecuteOperations(dispatcher);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/* 61 */     HttpServletRequest request = (HttpServletRequest)req;
/* 62 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */     
/* 64 */     if (excludeUrl(request)) {
/* 65 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 70 */     if (this.execute == null) {
/* 71 */       lazyInit();
/*    */     }
/*    */     
/* 74 */     ActionMapping mapping = this.prepare.findActionMapping(request, response);
/*    */ 
/*    */ 
/*    */     
/* 78 */     Integer recursionCounter = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*    */     
/* 80 */     if (mapping == null || recursionCounter.intValue() > 1) {
/* 81 */       boolean handled = this.execute.executeStaticResourceRequest(request, response);
/* 82 */       if (!handled) {
/* 83 */         chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */       }
/*    */     } else {
/* 86 */       this.execute.executeAction(request, response, mapping);
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean excludeUrl(HttpServletRequest request) {
/* 91 */     return (request.getAttribute(StrutsPrepareFilter.REQUEST_EXCLUDED_FROM_ACTION_MAPPING) != null);
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 95 */     this.prepare = null;
/* 96 */     this.execute = null;
/* 97 */     this.filterConfig = null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\filter\StrutsExecuteFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */