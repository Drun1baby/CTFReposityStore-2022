/*    */ package org.apache.struts2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.DefaultActionProxy;
/*    */ import java.util.Locale;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsActionProxy
/*    */   extends DefaultActionProxy
/*    */ {
/*    */   private static final long serialVersionUID = -2434901249671934080L;
/*    */   
/*    */   public StrutsActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext) {
/* 34 */     super(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/*    */   }
/*    */   
/*    */   public String execute() throws Exception {
/* 38 */     ActionContext previous = ActionContext.getContext();
/* 39 */     ActionContext.setContext(this.invocation.getInvocationContext());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 48 */       return this.invocation.invoke();
/*    */     } finally {
/* 50 */       if (this.cleanupContext) {
/* 51 */         ActionContext.setContext(previous);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void prepare() {
/* 57 */     super.prepare();
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getErrorMessage() {
/* 62 */     if (this.namespace != null && this.namespace.trim().length() > 0) {
/* 63 */       String contextPath = ServletActionContext.getRequest().getContextPath();
/* 64 */       return this.localizedTextProvider.findDefaultText("struts.exception.missing-package-action.with-context", Locale.getDefault(), (Object[])new String[] { this.namespace, this.actionName, contextPath });
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     return super.getErrorMessage();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\factory\StrutsActionProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */