/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.LocalizedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMultiPartRequest
/*     */   implements MultiPartRequest
/*     */ {
/*  39 */   private static final Logger LOG = LogManager.getLogger(AbstractMultiPartRequest.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int BUFFER_SIZE = 10240;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   protected List<LocalizedMessage> errors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected long maxSize;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean maxSizeProvided;
/*     */ 
/*     */   
/*  60 */   protected int bufferSize = 10240;
/*     */ 
/*     */ 
/*     */   
/*     */   protected String defaultEncoding;
/*     */ 
/*     */   
/*  67 */   protected Locale defaultLocale = Locale.ENGLISH;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(value = "struts.multipart.bufferSize", required = false)
/*     */   public void setBufferSize(String bufferSize) {
/*  74 */     this.bufferSize = Integer.parseInt(bufferSize);
/*     */   }
/*     */   
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String enc) {
/*  79 */     this.defaultEncoding = enc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.multipart.maxSize")
/*     */   public void setMaxSize(String maxSize) {
/*  87 */     this.maxSizeProvided = true;
/*  88 */     this.maxSize = Long.parseLong(maxSize);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocaleProviderFactory(LocaleProviderFactory localeProviderFactory) {
/*  93 */     this.defaultLocale = localeProviderFactory.createLocaleProvider().getLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLocale(HttpServletRequest request) {
/* 101 */     if (this.defaultLocale == null) {
/* 102 */       this.defaultLocale = request.getLocale();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LocalizedMessage buildErrorMessage(Throwable e, Object[] args) {
/* 114 */     String errorKey = "struts.messages.upload.error." + e.getClass().getSimpleName();
/* 115 */     LOG.debug("Preparing error message for key: [{}]", errorKey);
/*     */     
/* 117 */     return new LocalizedMessage(getClass(), errorKey, e.getMessage(), args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LocalizedMessage> getErrors() {
/* 124 */     return this.errors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getCanonicalName(String originalFileName) {
/* 132 */     String fileName = originalFileName;
/*     */     
/* 134 */     int forwardSlash = fileName.lastIndexOf('/');
/* 135 */     int backwardSlash = fileName.lastIndexOf('\\');
/* 136 */     if (forwardSlash != -1 && forwardSlash > backwardSlash) {
/* 137 */       fileName = fileName.substring(forwardSlash + 1, fileName.length());
/*     */     } else {
/* 139 */       fileName = fileName.substring(backwardSlash + 1, fileName.length());
/*     */     } 
/* 141 */     return fileName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\multipart\AbstractMultiPartRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */