/*    */ package org.apache.struts2.conversion;
/*    */ 
/*    */ import com.opensymphony.xwork2.conversion.impl.DefaultTypeConverter;
/*    */ import java.io.File;
/*    */ import java.lang.reflect.Array;
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts2.dispatcher.multipart.UploadedFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UploadedFileConverter
/*    */   extends DefaultTypeConverter
/*    */ {
/* 33 */   private static final Logger LOG = LogManager.getLogger(UploadedFileConverter.class);
/*    */ 
/*    */   
/*    */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class toType) {
/* 37 */     if (File.class.equals(toType)) {
/* 38 */       Object obj; LOG.debug("Converting {} into {}, consider switching to {} and do not access {} directly!", File.class.getName(), UploadedFile.class.getName(), UploadedFile.class.getName(), File.class.getName());
/*    */ 
/*    */ 
/*    */       
/* 42 */       if (value.getClass().isArray() && Array.getLength(value) == 1) {
/* 43 */         obj = Array.get(value, 0);
/*    */       } else {
/* 45 */         obj = value;
/*    */       } 
/*    */       
/* 48 */       if (obj instanceof UploadedFile) {
/* 49 */         UploadedFile file = (UploadedFile)obj;
/* 50 */         if (file.getContent() instanceof File) {
/* 51 */           return file.getContent();
/*    */         }
/* 53 */         return new File(file.getAbsolutePath());
/*    */       } 
/*    */     } 
/*    */     
/* 57 */     return super.convertValue(context, target, member, propertyName, value, toType);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\conversion\UploadedFileConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */