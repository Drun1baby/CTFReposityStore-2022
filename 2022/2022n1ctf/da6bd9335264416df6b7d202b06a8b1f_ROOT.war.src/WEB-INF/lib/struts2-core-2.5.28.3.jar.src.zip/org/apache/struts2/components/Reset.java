/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "reset", tldTagClass = "org.apache.struts2.views.jsp.ui.ResetTag", description = "Render a reset button", allowDynamicAttributes = true)
/*     */ public class Reset
/*     */   extends FormButton
/*     */ {
/*     */   public static final String TEMPLATE = "reset";
/*     */   protected String src;
/*     */   
/*     */   public Reset(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  67 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   public String getDefaultOpenTemplate() {
/*  71 */     return "empty";
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  75 */     return "reset";
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/*  79 */     super.evaluateExtraParams();
/*  80 */     if (this.src != null)
/*  81 */       addParameter("src", findString(this.src)); 
/*     */   }
/*     */   
/*     */   public void evaluateParams() {
/*  85 */     if (this.value == null) {
/*  86 */       this.value = (this.key != null) ? ("%{getText('" + this.key + "')}") : "Reset";
/*     */     }
/*  88 */     super.evaluateParams();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsImageType() {
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Supply a reset button text apart from reset value. Will have no effect for <i>input</i> type reset, since button text will always be the value parameter.")
/*     */   public void setLabel(String label) {
/* 103 */     super.setLabel(label);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Supply an image src for <i>image</i> type reset button. Will have no effect for types <i>input</i> and <i>button</i>.")
/*     */   public void setSrc(String src) {
/* 108 */     this.src = src;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Reset.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */