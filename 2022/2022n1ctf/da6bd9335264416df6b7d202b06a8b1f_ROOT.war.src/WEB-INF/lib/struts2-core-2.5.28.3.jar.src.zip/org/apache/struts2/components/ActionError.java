/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "actionerror", tldBodyContent = "empty", tldTagClass = "org.apache.struts2.views.jsp.ui.ActionErrorTag", description = "Render action errors if they exists")
/*    */ public class ActionError
/*    */   extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "actionerror";
/*    */   private boolean escape = true;
/*    */   
/*    */   public ActionError(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 61 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 65 */     return "actionerror";
/*    */   }
/*    */   
/*    */   protected void evaluateExtraParams() {
/* 69 */     boolean isEmptyList = true;
/* 70 */     Collection<String> actionMessages = (List)findValue("actionErrors");
/* 71 */     if (actionMessages != null) {
/* 72 */       for (String message : actionMessages) {
/* 73 */         if (StringUtils.isNotBlank(message)) {
/* 74 */           isEmptyList = false;
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     }
/* 80 */     addParameter("isEmptyList", Boolean.valueOf(isEmptyList));
/* 81 */     addParameter("escape", Boolean.valueOf(this.escape));
/*    */   }
/*    */   
/*    */   @StrutsTagAttribute(description = " Whether to escape HTML", type = "Boolean", defaultValue = "true")
/*    */   public void setEscape(boolean escape) {
/* 86 */     this.escape = escape;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ActionError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */