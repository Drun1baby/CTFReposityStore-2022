/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "property", tldBodyContent = "empty", tldTagClass = "org.apache.struts2.views.jsp.PropertyTag", description = "Print out expression which evaluates against the stack")
/*     */ public class Property
/*     */   extends Component
/*     */ {
/*     */   private String defaultValue;
/*     */   private String value;
/*     */   private boolean escapeHtml;
/*     */   private boolean escapeJavaScript;
/*     */   private boolean escapeXml;
/*     */   private boolean escapeCsv;
/*  87 */   private static final Logger LOG = LogManager.getLogger(Property.class);
/*     */   
/*     */   public Property(ValueStack stack) {
/*  90 */     super(stack);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.escapeHtml = true;
/*  96 */     this.escapeJavaScript = false;
/*  97 */     this.escapeXml = false;
/*  98 */     this.escapeCsv = false;
/*     */   }
/*     */   @StrutsTagAttribute(description = "The default value to be used if <u>value</u> attribute is null")
/*     */   public void setDefault(String defaultValue) {
/* 102 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape HTML", type = "Boolean", defaultValue = "true")
/*     */   public void setEscapeHtml(boolean escape) {
/* 107 */     this.escapeHtml = escape;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape Javascript", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeJavaScript(boolean escapeJavaScript) {
/* 112 */     this.escapeJavaScript = escapeJavaScript;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Value to be displayed", type = "Object", defaultValue = "&lt;top of stack&gt;")
/*     */   public void setValue(String value) {
/* 117 */     this.value = value;
/*     */   }
/*     */   
/*     */   public void setDefaultValue(String defaultValue) {
/* 121 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape CSV (useful to escape a value for a column)", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeCsv(boolean escapeCsv) {
/* 126 */     this.escapeCsv = escapeCsv;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape XML", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeXml(boolean escapeXml) {
/* 131 */     this.escapeXml = escapeXml;
/*     */   }
/*     */   
/*     */   public boolean start(Writer writer) {
/* 135 */     boolean result = super.start(writer);
/*     */     
/* 137 */     String actualValue = null;
/*     */     
/* 139 */     if (this.value == null) {
/* 140 */       this.value = "top";
/*     */     } else {
/*     */       
/* 143 */       this.value = stripExpressionIfAltSyntax(this.value);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     actualValue = (String)getStack().findValue(this.value, String.class, this.throwExceptionOnELFailure);
/*     */     
/*     */     try {
/* 152 */       if (actualValue != null) {
/* 153 */         writer.write(prepare(actualValue));
/* 154 */       } else if (this.defaultValue != null) {
/* 155 */         writer.write(prepare(this.defaultValue));
/*     */       } 
/* 157 */     } catch (IOException e) {
/* 158 */       LOG.info("Could not print out value '{}'", this.value, e);
/*     */     } 
/*     */     
/* 161 */     return result;
/*     */   }
/*     */   
/*     */   private String prepare(String value) {
/* 165 */     String result = value;
/* 166 */     if (this.escapeHtml) {
/* 167 */       result = StringEscapeUtils.escapeHtml4(result);
/*     */     }
/* 169 */     if (this.escapeJavaScript) {
/* 170 */       result = StringEscapeUtils.escapeEcmaScript(result);
/*     */     }
/* 172 */     if (this.escapeXml) {
/* 173 */       result = StringEscapeUtils.escapeXml(result);
/*     */     }
/* 175 */     if (this.escapeCsv) {
/* 176 */       result = StringEscapeUtils.escapeCsv(result);
/*     */     }
/*     */     
/* 179 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Property.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */