/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Context;
/*     */ import com.opensymphony.xwork2.inject.Factory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrutsXmlConfigurationProvider
/*     */   extends XmlConfigurationProvider
/*     */ {
/*  43 */   private static final Logger LOG = LogManager.getLogger(StrutsXmlConfigurationProvider.class);
/*  44 */   private File baseDir = null;
/*     */ 
/*     */   
/*     */   private String filename;
/*     */   
/*     */   private String reloadKey;
/*     */   
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   
/*     */   public StrutsXmlConfigurationProvider(boolean errorIfMissing) {
/*  55 */     this("struts.xml", errorIfMissing, (ServletContext)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StrutsXmlConfigurationProvider(String filename, @Deprecated boolean errorIfMissing, ServletContext ctx) {
/*  66 */     super(filename, errorIfMissing);
/*  67 */     this.servletContext = ctx;
/*  68 */     this.filename = filename;
/*  69 */     this.reloadKey = "configurationReload-" + filename;
/*  70 */     Map<String, String> dtdMappings = new HashMap<>(getDtdMappings());
/*  71 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.0//EN", "struts-2.0.dtd");
/*  72 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.1//EN", "struts-2.1.dtd");
/*  73 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.1.7//EN", "struts-2.1.7.dtd");
/*  74 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.3//EN", "struts-2.3.dtd");
/*  75 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.5//EN", "struts-2.5.dtd");
/*  76 */     setDtdMappings(dtdMappings);
/*  77 */     File file = new File(filename);
/*  78 */     if (file.getParent() != null) {
/*  79 */       this.baseDir = file.getParentFile();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(ContainerBuilder containerBuilder, LocatableProperties props) throws ConfigurationException {
/*  88 */     if (this.servletContext != null && !containerBuilder.contains(ServletContext.class)) {
/*  89 */       containerBuilder.factory(ServletContext.class, new Factory<ServletContext>() {
/*     */             public ServletContext create(Context context) throws Exception {
/*  91 */               return StrutsXmlConfigurationProvider.this.servletContext;
/*     */             }
/*     */             public Class<? extends ServletContext> type() {
/*  94 */               return (Class)StrutsXmlConfigurationProvider.this.servletContext.getClass();
/*     */             }
/*     */           });
/*     */     }
/*  98 */     super.register(containerBuilder, props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadPackages() {
/* 106 */     ActionContext ctx = ActionContext.getContext();
/* 107 */     ctx.put(this.reloadKey, Boolean.TRUE);
/* 108 */     super.loadPackages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Iterator<URL> getConfigurationUrls(String fileName) throws IOException {
/* 119 */     URL url = null;
/* 120 */     if (this.baseDir != null) {
/* 121 */       url = findInFileSystem(fileName);
/* 122 */       if (url == null) {
/* 123 */         return super.getConfigurationUrls(fileName);
/*     */       }
/*     */     } 
/* 126 */     if (url != null) {
/* 127 */       List<URL> list = new ArrayList<>();
/* 128 */       list.add(url);
/* 129 */       return list.iterator();
/*     */     } 
/* 131 */     return super.getConfigurationUrls(fileName);
/*     */   }
/*     */ 
/*     */   
/*     */   protected URL findInFileSystem(String fileName) throws IOException {
/* 136 */     URL url = null;
/* 137 */     File file = new File(fileName);
/* 138 */     LOG.debug("Trying to load file: {}", file);
/*     */ 
/*     */     
/* 141 */     if (!file.exists()) {
/* 142 */       file = new File(this.baseDir, fileName);
/*     */     }
/* 144 */     if (file.exists()) {
/*     */       try {
/* 146 */         url = file.toURI().toURL();
/* 147 */       } catch (MalformedURLException e) {
/* 148 */         throw new IOException("Unable to convert " + file + " to a URL");
/*     */       } 
/*     */     }
/* 151 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needsReload() {
/* 159 */     ActionContext ctx = ActionContext.getContext();
/* 160 */     if (ctx != null) {
/* 161 */       return (ctx.get(this.reloadKey) == null && super.needsReload());
/*     */     }
/* 163 */     return super.needsReload();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return "Struts XML configuration provider (" + this.filename + ")";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\StrutsXmlConfigurationProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */