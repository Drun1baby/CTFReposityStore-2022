/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DelegatingSettings
/*     */   implements Settings
/*     */ {
/*     */   List<Settings> delegates;
/*     */   
/*     */   public DelegatingSettings(List<Settings> delegates) {
/*  51 */     this.delegates = delegates;
/*     */   }
/*     */   
/*     */   public String get(String name) throws IllegalArgumentException {
/*  55 */     for (Settings delegate : this.delegates) {
/*  56 */       String value = delegate.get(name);
/*  57 */       if (value != null) {
/*  58 */         return value;
/*     */       }
/*     */     } 
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator list() {
/*  66 */     boolean workedAtAll = false;
/*     */     
/*  68 */     Set<Object> settingList = new HashSet();
/*  69 */     UnsupportedOperationException e = null;
/*     */     
/*  71 */     for (Settings delegate : this.delegates) {
/*     */       try {
/*  73 */         Iterator list = delegate.list();
/*     */         
/*  75 */         while (list.hasNext()) {
/*  76 */           settingList.add(list.next());
/*     */         }
/*     */         
/*  79 */         workedAtAll = true;
/*  80 */       } catch (UnsupportedOperationException ex) {
/*  81 */         e = ex;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if (!workedAtAll) {
/*  87 */       throw (e == null) ? new UnsupportedOperationException() : e;
/*     */     }
/*  89 */     return settingList.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Location getLocation(String name) {
/*  94 */     for (Settings delegate : this.delegates) {
/*  95 */       Location loc = delegate.getLocation(name);
/*  96 */       if (loc != null) {
/*  97 */         return loc;
/*     */       }
/*     */     } 
/* 100 */     return Location.UNKNOWN;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\DelegatingSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */