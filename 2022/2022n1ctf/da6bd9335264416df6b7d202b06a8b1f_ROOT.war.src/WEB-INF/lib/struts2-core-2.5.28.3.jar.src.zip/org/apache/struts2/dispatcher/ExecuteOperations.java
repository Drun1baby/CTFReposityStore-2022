/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.RequestUtils;
/*    */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecuteOperations
/*    */ {
/*    */   private Dispatcher dispatcher;
/*    */   
/*    */   public ExecuteOperations(Dispatcher dispatcher) {
/* 37 */     this.dispatcher = dispatcher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean executeStaticResourceRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/* 51 */     String resourcePath = RequestUtils.getServletPath(request);
/*    */     
/* 53 */     if ("".equals(resourcePath) && null != request.getPathInfo()) {
/* 54 */       resourcePath = request.getPathInfo();
/*    */     }
/*    */     
/* 57 */     StaticContentLoader staticResourceLoader = (StaticContentLoader)this.dispatcher.getContainer().getInstance(StaticContentLoader.class);
/* 58 */     if (staticResourceLoader.canHandle(resourcePath)) {
/* 59 */       staticResourceLoader.findStaticResource(resourcePath, request, response);
/*    */       
/* 61 */       return true;
/*    */     } 
/*    */ 
/*    */     
/* 65 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void executeAction(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) throws ServletException {
/* 79 */     this.dispatcher.serviceAction(request, response, mapping);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\ExecuteOperations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */