/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "checkboxlist", tldTagClass = "org.apache.struts2.views.jsp.ui.CheckboxListTag", description = "Render a list of checkboxes", allowDynamicAttributes = true)
/*    */ public class CheckboxList
/*    */   extends ListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "checkboxlist";
/*    */   
/*    */   public CheckboxList(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 53 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 57 */     return "checkboxlist";
/*    */   }
/*    */   
/*    */   public void evaluateExtraParams() {
/* 61 */     super.evaluateExtraParams();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\CheckboxList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */