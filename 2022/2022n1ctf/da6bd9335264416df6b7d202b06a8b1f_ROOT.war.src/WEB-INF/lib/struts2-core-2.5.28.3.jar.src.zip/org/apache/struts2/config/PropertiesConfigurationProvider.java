/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesConfigurationProvider
/*    */   implements ConfigurationProvider
/*    */ {
/*    */   public void destroy() {}
/*    */   
/*    */   public void init(Configuration configuration) throws ConfigurationException {}
/*    */   
/*    */   public void loadPackages() throws ConfigurationException {}
/*    */   
/*    */   public boolean needsReload() {
/* 41 */     return false;
/*    */   }
/*    */   
/*    */   public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 45 */     DefaultSettings settings = new DefaultSettings();
/* 46 */     loadSettings(props, settings);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void loadSettings(LocatableProperties props, Settings settings) {
/* 54 */     for (Iterator<String> i = settings.list(); i.hasNext(); ) {
/* 55 */       String name = i.next();
/* 56 */       props.setProperty(name, settings.get(name), settings.getLocation(name));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\PropertiesConfigurationProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */