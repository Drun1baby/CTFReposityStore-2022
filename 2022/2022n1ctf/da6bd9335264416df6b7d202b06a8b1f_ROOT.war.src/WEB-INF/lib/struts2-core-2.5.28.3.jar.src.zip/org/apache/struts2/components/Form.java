/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptorUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.validator.ActionValidatorManager;
/*     */ import com.opensymphony.xwork2.validator.FieldValidator;
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import com.opensymphony.xwork2.validator.ValidationInterceptor;
/*     */ import com.opensymphony.xwork2.validator.Validator;
/*     */ import com.opensymphony.xwork2.validator.ValidatorContext;
/*     */ import com.opensymphony.xwork2.validator.validators.VisitorFieldValidator;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "form", tldTagClass = "org.apache.struts2.views.jsp.ui.FormTag", description = "Renders an input form", allowDynamicAttributes = true)
/*     */ public class Form
/*     */   extends ClosingUIBean
/*     */ {
/*     */   public static final String OPEN_TEMPLATE = "form";
/*     */   public static final String TEMPLATE = "form-close";
/*  98 */   private int sequence = 0;
/*     */   
/*     */   protected String onsubmit;
/*     */   
/*     */   protected String onreset;
/*     */   protected String action;
/*     */   protected String target;
/*     */   protected String enctype;
/*     */   protected String method;
/*     */   protected String namespace;
/*     */   protected String validate;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String acceptcharset;
/*     */   protected boolean includeContext = true;
/*     */   protected String focusElement;
/*     */   protected Configuration configuration;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected UrlRenderer urlRenderer;
/*     */   protected ActionValidatorManager actionValidatorManager;
/*     */   
/*     */   public Form(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 120 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean evaluateNameValue() {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultOpenTemplate() {
/* 130 */     return "form";
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDefaultTemplate() {
/* 135 */     return "form-close";
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setConfiguration(Configuration configuration) {
/* 140 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 145 */     this.objectFactory = objectFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 150 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setActionValidatorManager(ActionValidatorManager mgr) {
/* 155 */     this.actionValidatorManager = mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluateExtraParams() {
/* 165 */     super.evaluateExtraParams();
/* 166 */     if (this.validate != null) {
/* 167 */       addParameter("validate", findValue(this.validate, Boolean.class));
/*     */     }
/*     */     
/* 170 */     if (this.name == null) {
/*     */       
/* 172 */       String id = (String)getParameters().get("id");
/* 173 */       if (StringUtils.isNotEmpty(id)) {
/* 174 */         addParameter("name", id);
/*     */       }
/*     */     } 
/*     */     
/* 178 */     if (this.onsubmit != null) {
/* 179 */       addParameter("onsubmit", findString(this.onsubmit));
/*     */     }
/*     */     
/* 182 */     if (this.onreset != null) {
/* 183 */       addParameter("onreset", findString(this.onreset));
/*     */     }
/*     */     
/* 186 */     if (this.target != null) {
/* 187 */       addParameter("target", findString(this.target));
/*     */     }
/*     */     
/* 190 */     if (this.enctype != null) {
/* 191 */       addParameter("enctype", findString(this.enctype));
/*     */     }
/*     */     
/* 194 */     if (this.method != null) {
/* 195 */       addParameter("method", findString(this.method));
/*     */     }
/*     */     
/* 198 */     if (this.acceptcharset != null) {
/* 199 */       addParameter("acceptcharset", findString(this.acceptcharset));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (!this.parameters.containsKey("tagNames"))
/*     */     {
/* 206 */       addParameter("tagNames", new ArrayList());
/*     */     }
/*     */     
/* 209 */     if (this.focusElement != null) {
/* 210 */       addParameter("focusElement", findString(this.focusElement));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void populateComponentHtmlId(Form form) {
/* 223 */     if (this.id != null) {
/* 224 */       super.populateComponentHtmlId((Form)null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 229 */     this.urlRenderer.renderFormUrl(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluateClientSideJsEnablement(String actionName, String namespace, String actionMethod) {
/* 241 */     Boolean validate = (Boolean)getParameters().get("validate");
/* 242 */     if (validate != null && validate.booleanValue()) {
/*     */       
/* 244 */       addParameter("performValidation", Boolean.FALSE);
/*     */       
/* 246 */       RuntimeConfiguration runtimeConfiguration = this.configuration.getRuntimeConfiguration();
/* 247 */       ActionConfig actionConfig = runtimeConfiguration.getActionConfig(namespace, actionName);
/*     */       
/* 249 */       if (actionConfig != null) {
/* 250 */         List<InterceptorMapping> interceptors = actionConfig.getInterceptors();
/* 251 */         for (InterceptorMapping interceptorMapping : interceptors) {
/* 252 */           if (ValidationInterceptor.class.isInstance(interceptorMapping.getInterceptor())) {
/* 253 */             ValidationInterceptor validationInterceptor = (ValidationInterceptor)interceptorMapping.getInterceptor();
/*     */             
/* 255 */             Set excludeMethods = validationInterceptor.getExcludeMethodsSet();
/* 256 */             Set includeMethods = validationInterceptor.getIncludeMethodsSet();
/*     */             
/* 258 */             if (MethodFilterInterceptorUtil.applyMethod(excludeMethods, includeMethods, actionMethod)) {
/* 259 */               addParameter("performValidation", Boolean.TRUE);
/*     */             }
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public List getValidators(String name) {
/* 269 */     Class actionClass = (Class)getParameters().get("actionClass");
/* 270 */     if (actionClass == null) {
/* 271 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 274 */     String formActionValue = findString(this.action);
/* 275 */     ActionMapping mapping = this.actionMapper.getMappingFromActionName(formActionValue);
/*     */     
/* 277 */     if (mapping == null) {
/* 278 */       mapping = this.actionMapper.getMappingFromActionName((String)getParameters().get("actionName"));
/*     */     }
/*     */     
/* 281 */     if (mapping == null) {
/* 282 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 285 */     String actionName = mapping.getName();
/*     */     
/* 287 */     String methodName = null;
/* 288 */     if (isValidateAnnotatedMethodOnly(actionName)) {
/* 289 */       methodName = mapping.getMethod();
/*     */     }
/*     */     
/* 292 */     List<Validator> actionValidators = this.actionValidatorManager.getValidators(actionClass, actionName, methodName);
/* 293 */     List<Validator> validators = new ArrayList<>();
/*     */     
/* 295 */     findFieldValidators(name, actionClass, actionName, actionValidators, validators, "");
/*     */     
/* 297 */     return validators;
/*     */   }
/*     */   
/*     */   private boolean isValidateAnnotatedMethodOnly(String actionName) {
/* 301 */     RuntimeConfiguration runtimeConfiguration = this.configuration.getRuntimeConfiguration();
/* 302 */     String actionNamespace = TagUtils.buildNamespace(this.actionMapper, this.stack, this.request);
/* 303 */     ActionConfig actionConfig = runtimeConfiguration.getActionConfig(actionNamespace, actionName);
/*     */     
/* 305 */     if (actionConfig != null) {
/* 306 */       List<InterceptorMapping> interceptors = actionConfig.getInterceptors();
/* 307 */       for (InterceptorMapping interceptorMapping : interceptors) {
/* 308 */         if (ValidationInterceptor.class.isInstance(interceptorMapping.getInterceptor())) {
/* 309 */           ValidationInterceptor validationInterceptor = (ValidationInterceptor)interceptorMapping.getInterceptor();
/* 310 */           return validationInterceptor.isValidateAnnotatedMethodOnly();
/*     */         } 
/*     */       } 
/*     */     } 
/* 314 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void findFieldValidators(String name, Class actionClass, String actionName, List<Validator> validatorList, List<Validator> resultValidators, String prefix) {
/* 320 */     for (Validator validator : validatorList) {
/* 321 */       if (validator instanceof FieldValidator) {
/* 322 */         FieldValidator fieldValidator = (FieldValidator)validator;
/*     */         
/* 324 */         if (validator instanceof VisitorFieldValidator) {
/* 325 */           VisitorFieldValidator vfValidator = (VisitorFieldValidator)fieldValidator;
/* 326 */           Class clazz = getVisitorReturnType(actionClass, vfValidator.getFieldName());
/* 327 */           if (clazz == null) {
/*     */             continue;
/*     */           }
/*     */           
/* 331 */           List<Validator> visitorValidators = this.actionValidatorManager.getValidators(clazz, actionName);
/* 332 */           String vPrefix = prefix + (vfValidator.isAppendPrefix() ? (vfValidator.getFieldName() + ".") : "");
/* 333 */           findFieldValidators(name, clazz, actionName, visitorValidators, resultValidators, vPrefix); continue;
/* 334 */         }  if ((prefix + fieldValidator.getFieldName()).equals(name)) {
/* 335 */           if (StringUtils.isNotBlank(prefix)) {
/*     */             
/* 337 */             FieldVisitorValidatorWrapper wrap = new FieldVisitorValidatorWrapper(fieldValidator, prefix);
/* 338 */             resultValidators.add(wrap); continue;
/*     */           } 
/* 340 */           resultValidators.add(fieldValidator);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FieldVisitorValidatorWrapper
/*     */     implements FieldValidator
/*     */   {
/*     */     private FieldValidator fieldValidator;
/*     */ 
/*     */     
/*     */     private String namePrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldVisitorValidatorWrapper(FieldValidator fv, String namePrefix) {
/* 359 */       this.fieldValidator = fv;
/* 360 */       this.namePrefix = namePrefix;
/*     */     }
/*     */     public String getValidatorType() {
/* 363 */       return "field-visitor";
/*     */     }
/*     */     public String getFieldName() {
/* 366 */       return this.namePrefix + this.fieldValidator.getFieldName();
/*     */     }
/*     */     public FieldValidator getFieldValidator() {
/* 369 */       return this.fieldValidator;
/*     */     }
/*     */     public void setFieldValidator(FieldValidator fieldValidator) {
/* 372 */       this.fieldValidator = fieldValidator;
/*     */     }
/*     */     public String getDefaultMessage() {
/* 375 */       return this.fieldValidator.getDefaultMessage();
/*     */     }
/*     */     public String getMessage(Object object) {
/* 378 */       return this.fieldValidator.getMessage(object);
/*     */     }
/*     */     public String getMessageKey() {
/* 381 */       return this.fieldValidator.getMessageKey();
/*     */     }
/*     */     public String[] getMessageParameters() {
/* 384 */       return this.fieldValidator.getMessageParameters();
/*     */     }
/*     */     public ValidatorContext getValidatorContext() {
/* 387 */       return this.fieldValidator.getValidatorContext();
/*     */     }
/*     */     public void setDefaultMessage(String message) {
/* 390 */       this.fieldValidator.setDefaultMessage(message);
/*     */     }
/*     */     public void setFieldName(String fieldName) {
/* 393 */       this.fieldValidator.setFieldName(fieldName);
/*     */     }
/*     */     public void setMessageKey(String key) {
/* 396 */       this.fieldValidator.setMessageKey(key);
/*     */     }
/*     */     public void setMessageParameters(String[] messageParameters) {
/* 399 */       this.fieldValidator.setMessageParameters(messageParameters);
/*     */     }
/*     */     public void setValidatorContext(ValidatorContext validatorContext) {
/* 402 */       this.fieldValidator.setValidatorContext(validatorContext);
/*     */     }
/*     */     public void setValidatorType(String type) {
/* 405 */       this.fieldValidator.setValidatorType(type);
/*     */     }
/*     */     public void setValueStack(ValueStack stack) {
/* 408 */       this.fieldValidator.setValueStack(stack);
/*     */     }
/*     */     public void validate(Object object) throws ValidationException {
/* 411 */       this.fieldValidator.validate(object);
/*     */     }
/*     */     public String getNamePrefix() {
/* 414 */       return this.namePrefix;
/*     */     }
/*     */     public void setNamePrefix(String namePrefix) {
/* 417 */       this.namePrefix = namePrefix;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class getVisitorReturnType(Class actionClass, String visitorFieldName) {
/* 430 */     if (visitorFieldName == null) {
/* 431 */       return null;
/*     */     }
/* 433 */     String methodName = "get" + StringUtils.capitalize(visitorFieldName);
/*     */     try {
/* 435 */       Method method = actionClass.getMethod(methodName, new Class[0]);
/* 436 */       return method.getReturnType();
/* 437 */     } catch (NoSuchMethodException e) {
/* 438 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSequence() {
/* 451 */     return this.sequence++;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML onsubmit attribute")
/*     */   public void setOnsubmit(String onsubmit) {
/* 456 */     this.onsubmit = onsubmit;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML onreset attribute")
/*     */   public void setOnreset(String onreset) {
/* 461 */     this.onreset = onreset;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set action name to submit to, without .action suffix", defaultValue = "current action")
/*     */   public void setAction(String action) {
/* 466 */     this.action = action;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML form target attribute")
/*     */   public void setTarget(String target) {
/* 471 */     this.target = target;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML form enctype attribute")
/*     */   public void setEnctype(String enctype) {
/* 476 */     this.enctype = enctype;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML form method attribute")
/*     */   public void setMethod(String method) {
/* 481 */     this.method = method;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Namespace for action to submit to", defaultValue = "current namespace")
/*     */   public void setNamespace(String namespace) {
/* 486 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether client side/remote validation should be performed. Only useful with theme xhtml/ajax", type = "Boolean", defaultValue = "false")
/*     */   public void setValidate(String validate) {
/* 492 */     this.validate = validate;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The portlet mode to display after the form submit")
/*     */   public void setPortletMode(String portletMode) {
/* 497 */     this.portletMode = portletMode;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The window state to display after the form submit")
/*     */   public void setWindowState(String windowState) {
/* 502 */     this.windowState = windowState;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The accepted charsets for this form. The values may be comma or blank delimited.")
/*     */   public void setAcceptcharset(String acceptcharset) {
/* 507 */     this.acceptcharset = acceptcharset;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Id of element that will receive the focus when page loads.")
/*     */   public void setFocusElement(String focusElement) {
/* 512 */     this.focusElement = focusElement;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether actual context should be included in URL", type = "Boolean", defaultValue = "true")
/*     */   public void setIncludeContext(boolean includeContext) {
/* 517 */     this.includeContext = includeContext;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Form.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */