/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "a", tldTagClass = "org.apache.struts2.views.jsp.ui.AnchorTag", description = "Render a HTML href element", allowDynamicAttributes = true)
/*     */ public class Anchor
/*     */   extends ClosingUIBean
/*     */ {
/*  62 */   private static final Logger LOG = LogManager.getLogger(Anchor.class);
/*     */   
/*     */   public static final String OPEN_TEMPLATE = "a";
/*     */   public static final String TEMPLATE = "a-close";
/*  66 */   public static final String COMPONENT_NAME = Anchor.class.getName();
/*     */   
/*     */   protected String href;
/*     */   
/*     */   protected UrlProvider urlProvider;
/*     */   
/*     */   protected UrlRenderer urlRenderer;
/*     */   protected boolean processingTagBody = false;
/*  74 */   protected Map urlParameters = new LinkedHashMap<>();
/*     */   
/*     */   public Anchor(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  77 */     super(stack, request, response);
/*  78 */     this.urlProvider = new ComponentUrlProvider(this, this.urlParameters);
/*  79 */     this.urlProvider.setHttpServletRequest(request);
/*  80 */     this.urlProvider.setHttpServletResponse(response);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultOpenTemplate() {
/*  85 */     return "a";
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  90 */     return "a-close";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usesBody() {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void evaluateExtraParams() {
/* 100 */     super.evaluateExtraParams();
/*     */     
/* 102 */     if (this.href != null) {
/* 103 */       addParameter("href", ensureAttributeSafelyNotEscaped(findString(this.href)));
/*     */     } else {
/*     */       
/* 106 */       StringWriter sw = new StringWriter();
/* 107 */       this.urlRenderer.beforeRenderUrl(this.urlProvider);
/* 108 */       this.urlRenderer.renderUrl(sw, this.urlProvider);
/* 109 */       String builtHref = sw.toString();
/* 110 */       if (StringUtils.isNotEmpty(builtHref)) {
/* 111 */         addParameter("href", ensureAttributeSafelyNotEscaped(builtHref));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject("struts.url.includeParams")
/*     */   public void setUrlIncludeParams(String urlIncludeParams) {
/* 118 */     this.urlProvider.setUrlIncludeParams(urlIncludeParams);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 123 */     this.urlProvider.setUrlRenderer(urlRenderer);
/* 124 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */   
/*     */   @Inject(required = false)
/*     */   public void setExtraParameterProvider(ExtraParameterProvider provider) {
/* 129 */     this.urlProvider.setExtraParameterProvider(provider);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean start(Writer writer) {
/* 134 */     boolean result = super.start(writer);
/* 135 */     this.processingTagBody = true;
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 144 */     this.processingTagBody = false;
/* 145 */     evaluateParams();
/*     */     try {
/* 147 */       addParameter("body", body);
/* 148 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/* 149 */     } catch (Exception e) {
/* 150 */       LOG.error("error when rendering", e);
/*     */     } finally {
/* 152 */       popComponentStack();
/*     */     } 
/*     */     
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String key, Object value) {
/* 165 */     if (this.processingTagBody) {
/* 166 */       this.urlParameters.put(key, value);
/*     */     } else {
/* 168 */       super.addParameter(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAllParameters(Map params) {
/* 179 */     if (this.processingTagBody) {
/* 180 */       this.urlParameters.putAll(params);
/*     */     } else {
/* 182 */       super.addAllParameters(params);
/*     */     } 
/*     */   }
/*     */   
/*     */   public UrlProvider getUrlProvider() {
/* 187 */     return this.urlProvider;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The URL.")
/*     */   public void setHref(String href) {
/* 192 */     this.href = href;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The includeParams attribute may have the value 'none', 'get' or 'all'", defaultValue = "none")
/*     */   public void setIncludeParams(String includeParams) {
/* 197 */     this.urlProvider.setIncludeParams(includeParams);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set scheme attribute")
/*     */   public void setScheme(String scheme) {
/* 202 */     this.urlProvider.setScheme(scheme);
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "The target value to use, if not using action")
/*     */   public void setValue(String value) {
/* 208 */     this.urlProvider.setValue(value);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The action to generate the URL for, if not using value")
/*     */   public void setAction(String action) {
/* 213 */     this.urlProvider.setAction(action);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The namespace to use")
/*     */   public void setNamespace(String namespace) {
/* 218 */     this.urlProvider.setNamespace(namespace);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The method of action to use")
/*     */   public void setMethod(String method) {
/* 223 */     this.urlProvider.setMethod(method);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to encode parameters", type = "Boolean", defaultValue = "true")
/*     */   public void setEncode(boolean encode) {
/* 228 */     this.urlProvider.setEncode(encode);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether actual context should be included in URL", type = "Boolean", defaultValue = "true")
/*     */   public void setIncludeContext(boolean includeContext) {
/* 233 */     this.urlProvider.setIncludeContext(includeContext);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The resulting portlet mode")
/*     */   public void setPortletMode(String portletMode) {
/* 238 */     this.urlProvider.setPortletMode(portletMode);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The resulting portlet window state")
/*     */   public void setWindowState(String windowState) {
/* 243 */     this.urlProvider.setWindowState(windowState);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Specifies if this should be a portlet render or action URL. Default is \"render\". To create an action URL, use \"action\".")
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 248 */     this.urlProvider.setPortletUrlType(portletUrlType);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The anchor for this URL")
/*     */   public void setAnchor(String anchor) {
/* 253 */     this.urlProvider.setAnchor(anchor);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Specifies whether to escape ampersand (&amp;) to (&amp;amp;) or not", type = "Boolean", defaultValue = "true")
/*     */   public void setEscapeAmp(boolean escapeAmp) {
/* 258 */     this.urlProvider.setEscapeAmp(escapeAmp);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Specifies whether to force the addition of scheme, host and port or not", type = "Boolean", defaultValue = "false")
/*     */   public void setForceAddSchemeHostAndPort(boolean forceAddSchemeHostAndPort) {
/* 263 */     this.urlProvider.setForceAddSchemeHostAndPort(forceAddSchemeHostAndPort);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Anchor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */