/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateEngineManager
/*     */ {
/*     */   public static final String DEFAULT_TEMPLATE_TYPE = "ftl";
/*  43 */   Map<String, EngineFactory> templateEngines = new HashMap<>();
/*     */   Container container;
/*     */   String defaultTemplateType;
/*     */   
/*     */   @Inject("struts.ui.templateSuffix")
/*     */   public void setDefaultTemplateType(String type) {
/*  49 */     this.defaultTemplateType = type;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  54 */     this.container = container;
/*  55 */     Map<String, EngineFactory> map = new HashMap<>();
/*  56 */     Set<String> prefixes = container.getInstanceNames(TemplateEngine.class);
/*  57 */     for (String prefix : prefixes) {
/*  58 */       map.put(prefix, new LazyEngineFactory(prefix));
/*     */     }
/*  60 */     this.templateEngines = Collections.unmodifiableMap(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerTemplateEngine(String templateExtension, final TemplateEngine templateEngine) {
/*  76 */     this.templateEngines.put(templateExtension, new EngineFactory() {
/*     */           public TemplateEngine create() {
/*  78 */             return templateEngine;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateEngine getTemplateEngine(Template template, String templateTypeOverride) {
/*  96 */     String templateType = "ftl";
/*  97 */     String templateName = template.toString();
/*  98 */     if (StringUtils.contains(templateName, ".")) {
/*  99 */       templateType = StringUtils.substring(templateName, StringUtils.indexOf(templateName, ".") + 1);
/* 100 */     } else if (StringUtils.isNotBlank(templateTypeOverride)) {
/* 101 */       templateType = templateTypeOverride;
/*     */     } else {
/* 103 */       String type = this.defaultTemplateType;
/* 104 */       if (type != null) {
/* 105 */         templateType = type;
/*     */       }
/*     */     } 
/* 108 */     return ((EngineFactory)this.templateEngines.get(templateType)).create();
/*     */   }
/*     */ 
/*     */   
/*     */   static interface EngineFactory
/*     */   {
/*     */     TemplateEngine create();
/*     */   }
/*     */   
/*     */   class LazyEngineFactory
/*     */     implements EngineFactory
/*     */   {
/*     */     private String name;
/*     */     
/*     */     public LazyEngineFactory(String name) {
/* 123 */       this.name = name;
/*     */     }
/*     */     public TemplateEngine create() {
/* 126 */       TemplateEngine engine = (TemplateEngine)TemplateEngineManager.this.container.getInstance(TemplateEngine.class, this.name);
/* 127 */       if (engine == null) {
/* 128 */         throw new ConfigurationException("Unable to locate template engine: " + this.name);
/*     */       }
/* 130 */       return engine;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\TemplateEngineManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */