/*    */ package org.apache.struts2.dispatcher.listener;
/*    */ 
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.InitOperations;
/*    */ import org.apache.struts2.dispatcher.PrepareOperations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   private PrepareOperations prepare;
/*    */   
/*    */   public void contextInitialized(ServletContextEvent sce) {
/* 39 */     InitOperations init = new InitOperations();
/* 40 */     Dispatcher dispatcher = null;
/*    */     try {
/* 42 */       ListenerHostConfig config = new ListenerHostConfig(sce.getServletContext());
/* 43 */       init.initLogging(config);
/* 44 */       dispatcher = init.initDispatcher(config);
/* 45 */       init.initStaticContentLoader(config, dispatcher);
/*    */       
/* 47 */       this.prepare = new PrepareOperations(dispatcher);
/* 48 */       sce.getServletContext().setAttribute("com.opensymphony.xwork2.dispatcher.ServletDispatcher", dispatcher);
/*    */     } finally {
/* 50 */       if (dispatcher != null) {
/* 51 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 53 */       init.cleanup();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 58 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\listener\StrutsListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */