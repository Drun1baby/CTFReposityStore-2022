/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.velocity.VelocityManager;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VelocityTemplateEngine
/*     */   extends BaseTemplateEngine
/*     */ {
/*  41 */   private static final Logger LOG = LogManager.getLogger(VelocityTemplateEngine.class);
/*     */   
/*     */   private VelocityManager velocityManager;
/*     */   
/*     */   @Inject
/*     */   public void setVelocityManager(VelocityManager mgr) {
/*  47 */     this.velocityManager = mgr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception {
/*  52 */     Map actionContext = templateContext.getStack().getContext();
/*  53 */     ServletContext servletContext = (ServletContext)actionContext.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/*  54 */     HttpServletRequest req = (HttpServletRequest)actionContext.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  55 */     HttpServletResponse res = (HttpServletResponse)actionContext.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*     */     
/*  58 */     this.velocityManager.init(servletContext);
/*  59 */     VelocityEngine velocityEngine = this.velocityManager.getVelocityEngine();
/*     */ 
/*     */     
/*  62 */     List<Template> templates = templateContext.getTemplate().getPossibleTemplates(this);
/*     */ 
/*     */     
/*  65 */     Template template = null;
/*  66 */     String templateName = null;
/*  67 */     Exception exception = null;
/*  68 */     for (Template t : templates) {
/*  69 */       templateName = getFinalTemplateName(t);
/*     */       
/*     */       try {
/*  72 */         template = velocityEngine.getTemplate(templateName);
/*     */         break;
/*  74 */       } catch (Exception e) {
/*  75 */         if (exception == null) {
/*  76 */           exception = e;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     if (template == null) {
/*  82 */       LOG.error("Could not load template {}", templateContext.getTemplate());
/*  83 */       if (exception != null) {
/*  84 */         throw exception;
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  90 */     LOG.debug("Rendering template {}", templateName);
/*     */     
/*  92 */     Context context = this.velocityManager.createContext(templateContext.getStack(), req, res);
/*     */     
/*  94 */     Writer outputWriter = templateContext.getWriter();
/*  95 */     context.put("tag", templateContext.getTag());
/*  96 */     context.put("parameters", templateContext.getParameters());
/*     */     
/*  98 */     template.merge(context, outputWriter);
/*     */   }
/*     */   
/*     */   protected String getSuffix() {
/* 102 */     return "vm";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\VelocityTemplateEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */