/*      */ package org.apache.struts2.components;
/*      */ 
/*      */ import com.opensymphony.xwork2.config.ConfigurationException;
/*      */ import com.opensymphony.xwork2.inject.Inject;
/*      */ import com.opensymphony.xwork2.util.ValueStack;
/*      */ import java.io.Writer;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.commons.lang3.StringUtils;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ import org.apache.struts2.StrutsException;
/*      */ import org.apache.struts2.components.template.Template;
/*      */ import org.apache.struts2.components.template.TemplateEngine;
/*      */ import org.apache.struts2.components.template.TemplateEngineManager;
/*      */ import org.apache.struts2.components.template.TemplateRenderingContext;
/*      */ import org.apache.struts2.util.TextProviderHelper;
/*      */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*      */ import org.apache.struts2.views.util.ContextUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class UIBean
/*      */   extends Component
/*      */ {
/*  434 */   private static final Logger LOG = LogManager.getLogger(UIBean.class); protected HttpServletRequest request; protected HttpServletResponse response; protected String templateSuffix; protected String template; protected String templateDir; protected String theme; protected String key; protected String id; protected String cssClass; protected String cssStyle; protected String cssErrorClass; protected String cssErrorStyle; protected String disabled; protected String label; protected String labelPosition; protected String labelSeparator; protected String requiredPosition; protected String errorPosition; protected String name; protected String requiredLabel; protected String tabindex;
/*      */   protected String value;
/*      */   protected String title;
/*      */   protected String onclick;
/*      */   
/*      */   public UIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  440 */     super(stack);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  504 */     this.dynamicAttributes = new HashMap<>();
/*      */     this.request = request;
/*      */     this.response = response;
/*      */     this.templateSuffix = ContextUtil.getTemplateSuffix(stack.getContext());
/*      */   }
/*      */   protected String ondblclick; protected String onmousedown; protected String onmouseup; protected String onmouseover; protected String onmousemove; protected String onmouseout; protected String onfocus; protected String onblur; protected String onkeypress; protected String onkeydown; protected String onkeyup; protected String onselect; protected String onchange; protected String accesskey; protected String tooltip; protected String tooltipConfig; protected String javascriptTooltip; protected String tooltipDelay; protected String tooltipCssClass; protected String tooltipIconPath; protected Map<String, Object> dynamicAttributes; protected String defaultTemplateDir; protected String defaultUITheme; protected String uiThemeExpansionToken; protected TemplateEngineManager templateEngineManager;
/*      */   
/*      */   @Inject("struts.ui.templateDir")
/*      */   public void setDefaultTemplateDir(String dir) {
/*  513 */     this.defaultTemplateDir = dir;
/*      */   }
/*      */   
/*      */   @Inject("struts.ui.theme")
/*      */   public void setDefaultUITheme(String theme) {
/*  518 */     this.defaultUITheme = theme;
/*      */   }
/*      */   
/*      */   @Inject("struts.ui.theme.expansion.token")
/*      */   public void setUIThemeExpansionToken(String uiThemeExpansionToken) {
/*  523 */     this.uiThemeExpansionToken = uiThemeExpansionToken;
/*      */   }
/*      */   
/*      */   @Inject
/*      */   public void setTemplateEngineManager(TemplateEngineManager mgr) {
/*  528 */     this.templateEngineManager = mgr;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean end(Writer writer, String body) {
/*  533 */     evaluateParams();
/*      */     try {
/*  535 */       end(writer, body, false);
/*  536 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/*  537 */     } catch (Exception e) {
/*  538 */       throw new StrutsException(e);
/*      */     } finally {
/*      */       
/*  541 */       popComponentStack();
/*      */     } 
/*      */     
/*  544 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract String getDefaultTemplate();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Template buildTemplateName(String myTemplate, String myDefaultTemplate) {
/*  558 */     String template = myDefaultTemplate;
/*      */     
/*  560 */     if (myTemplate != null) {
/*  561 */       template = findString(myTemplate);
/*      */     }
/*      */     
/*  564 */     String templateDir = getTemplateDir();
/*  565 */     String theme = getTheme();
/*      */     
/*  567 */     return new Template(templateDir, theme, template);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void mergeTemplate(Writer writer, Template template) throws Exception {
/*  572 */     TemplateEngine engine = this.templateEngineManager.getTemplateEngine(template, this.templateSuffix);
/*  573 */     if (engine == null) {
/*  574 */       throw new ConfigurationException("Unable to find a TemplateEngine for template " + template);
/*      */     }
/*      */     
/*  577 */     LOG.debug("Rendering template {}", template);
/*      */     
/*  579 */     TemplateRenderingContext context = new TemplateRenderingContext(template, writer, getStack(), getParameters(), this);
/*  580 */     engine.renderTemplate(context);
/*      */   }
/*      */   
/*      */   public String getTemplateDir() {
/*  584 */     String templateDir = null;
/*      */     
/*  586 */     if (this.templateDir != null) {
/*  587 */       templateDir = findString(this.templateDir);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  592 */     if (StringUtils.isBlank(templateDir)) {
/*  593 */       templateDir = this.stack.findString("#attr.templateDir");
/*      */     }
/*      */ 
/*      */     
/*  597 */     if (StringUtils.isBlank(templateDir)) {
/*  598 */       templateDir = this.defaultTemplateDir;
/*      */     }
/*      */ 
/*      */     
/*  602 */     if (StringUtils.isBlank(templateDir)) {
/*  603 */       templateDir = "template";
/*      */     }
/*      */     
/*  606 */     return templateDir;
/*      */   }
/*      */   
/*      */   public String getTheme() {
/*  610 */     String theme = null;
/*      */     
/*  612 */     if (this.theme != null) {
/*  613 */       theme = findString(this.theme);
/*      */     }
/*      */     
/*  616 */     if (StringUtils.isBlank(theme)) {
/*  617 */       Form form = (Form)findAncestor(Form.class);
/*  618 */       if (form != null) {
/*  619 */         theme = form.getTheme();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  625 */     if (StringUtils.isBlank(theme)) {
/*  626 */       theme = this.stack.findString("#attr.theme");
/*      */     }
/*      */ 
/*      */     
/*  630 */     if (StringUtils.isBlank(theme)) {
/*  631 */       theme = this.defaultUITheme;
/*      */     }
/*      */     
/*  634 */     return theme;
/*      */   }
/*      */   
/*      */   public void evaluateParams() {
/*  638 */     String templateDir = getTemplateDir();
/*  639 */     String theme = getTheme();
/*      */     
/*  641 */     addParameter("templateDir", templateDir);
/*  642 */     addParameter("theme", theme);
/*  643 */     addParameter("template", (this.template != null) ? findString(this.template) : getDefaultTemplate());
/*  644 */     addParameter("dynamicAttributes", this.dynamicAttributes);
/*  645 */     addParameter("themeExpansionToken", this.uiThemeExpansionToken);
/*  646 */     addParameter("expandTheme", this.uiThemeExpansionToken + theme);
/*      */     
/*  648 */     String name = null;
/*  649 */     String providedLabel = null;
/*      */     
/*  651 */     if (this.key != null) {
/*      */       
/*  653 */       if (this.name == null) {
/*  654 */         this.name = this.key;
/*      */       }
/*      */       
/*  657 */       if (this.label == null)
/*      */       {
/*  659 */         providedLabel = TextProviderHelper.getText(this.key, this.key, this.stack);
/*      */       }
/*      */     } 
/*      */     
/*  663 */     if (this.name != null) {
/*  664 */       name = findString(this.name);
/*  665 */       addParameter("name", name);
/*      */     } 
/*      */     
/*  668 */     if (this.label != null) {
/*  669 */       addParameter("label", findString(this.label));
/*      */     }
/*  671 */     else if (providedLabel != null) {
/*      */       
/*  673 */       addParameter("label", providedLabel);
/*      */     } 
/*      */ 
/*      */     
/*  677 */     if (this.labelSeparator != null) {
/*  678 */       addParameter("labelseparator", findString(this.labelSeparator));
/*      */     }
/*      */     
/*  681 */     if (this.labelPosition != null) {
/*  682 */       String labelPosition = findString(this.labelPosition);
/*  683 */       addParameter("labelposition", labelPosition);
/*  684 */       addParameter("labelPosition", labelPosition);
/*      */     } 
/*      */     
/*  687 */     if (this.requiredPosition != null) {
/*  688 */       addParameter("requiredPosition", findString(this.requiredPosition));
/*      */     }
/*      */     
/*  691 */     if (this.errorPosition != null) {
/*  692 */       addParameter("errorposition", findString(this.errorPosition));
/*      */     }
/*      */     
/*  695 */     if (this.requiredLabel != null) {
/*  696 */       addParameter("required", findValue(this.requiredLabel, Boolean.class));
/*      */     }
/*      */     
/*  699 */     if (this.disabled != null) {
/*  700 */       addParameter("disabled", findValue(this.disabled, Boolean.class));
/*      */     }
/*      */     
/*  703 */     if (this.tabindex != null) {
/*  704 */       addParameter("tabindex", findString(this.tabindex));
/*      */     }
/*      */     
/*  707 */     if (this.onclick != null) {
/*  708 */       addParameter("onclick", findString(this.onclick));
/*      */     }
/*      */     
/*  711 */     if (this.ondblclick != null) {
/*  712 */       addParameter("ondblclick", findString(this.ondblclick));
/*      */     }
/*      */     
/*  715 */     if (this.onmousedown != null) {
/*  716 */       addParameter("onmousedown", findString(this.onmousedown));
/*      */     }
/*      */     
/*  719 */     if (this.onmouseup != null) {
/*  720 */       addParameter("onmouseup", findString(this.onmouseup));
/*      */     }
/*      */     
/*  723 */     if (this.onmouseover != null) {
/*  724 */       addParameter("onmouseover", findString(this.onmouseover));
/*      */     }
/*      */     
/*  727 */     if (this.onmousemove != null) {
/*  728 */       addParameter("onmousemove", findString(this.onmousemove));
/*      */     }
/*      */     
/*  731 */     if (this.onmouseout != null) {
/*  732 */       addParameter("onmouseout", findString(this.onmouseout));
/*      */     }
/*      */     
/*  735 */     if (this.onfocus != null) {
/*  736 */       addParameter("onfocus", findString(this.onfocus));
/*      */     }
/*      */     
/*  739 */     if (this.onblur != null) {
/*  740 */       addParameter("onblur", findString(this.onblur));
/*      */     }
/*      */     
/*  743 */     if (this.onkeypress != null) {
/*  744 */       addParameter("onkeypress", findString(this.onkeypress));
/*      */     }
/*      */     
/*  747 */     if (this.onkeydown != null) {
/*  748 */       addParameter("onkeydown", findString(this.onkeydown));
/*      */     }
/*      */     
/*  751 */     if (this.onkeyup != null) {
/*  752 */       addParameter("onkeyup", findString(this.onkeyup));
/*      */     }
/*      */     
/*  755 */     if (this.onselect != null) {
/*  756 */       addParameter("onselect", findString(this.onselect));
/*      */     }
/*      */     
/*  759 */     if (this.onchange != null) {
/*  760 */       addParameter("onchange", findString(this.onchange));
/*      */     }
/*      */     
/*  763 */     if (this.accesskey != null) {
/*  764 */       addParameter("accesskey", findString(this.accesskey));
/*      */     }
/*      */     
/*  767 */     if (this.cssClass != null) {
/*  768 */       addParameter("cssClass", findString(this.cssClass));
/*      */     }
/*      */     
/*  771 */     if (this.cssStyle != null) {
/*  772 */       addParameter("cssStyle", findString(this.cssStyle));
/*      */     }
/*      */     
/*  775 */     if (this.cssErrorClass != null) {
/*  776 */       addParameter("cssErrorClass", findString(this.cssErrorClass));
/*      */     }
/*      */     
/*  779 */     if (this.cssErrorStyle != null) {
/*  780 */       addParameter("cssErrorStyle", findString(this.cssErrorStyle));
/*      */     }
/*      */     
/*  783 */     if (this.title != null) {
/*  784 */       addParameter("title", findString(this.title));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  789 */     if (this.parameters.containsKey("value")) {
/*  790 */       this.parameters.put("nameValue", this.parameters.get("value"));
/*      */     }
/*  792 */     else if (evaluateNameValue()) {
/*  793 */       Class valueClazz = getValueClassType();
/*      */       
/*  795 */       if (valueClazz != null) {
/*  796 */         if (this.value != null) {
/*  797 */           addParameter("nameValue", findValue(this.value, valueClazz));
/*  798 */         } else if (name != null) {
/*  799 */           String expr = completeExpressionIfAltSyntax(name);
/*  800 */           if (recursion(name)) {
/*  801 */             addParameter("nameValue", expr);
/*      */           } else {
/*  803 */             addParameter("nameValue", findValue(expr, valueClazz));
/*      */           }
/*      */         
/*      */         } 
/*  807 */       } else if (this.value != null) {
/*  808 */         addParameter("nameValue", findValue(this.value));
/*  809 */       } else if (name != null) {
/*  810 */         addParameter("nameValue", findValue(name));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  816 */     Form form = (Form)findAncestor(Form.class);
/*      */ 
/*      */     
/*  819 */     populateComponentHtmlId(form);
/*      */     
/*  821 */     if (form != null) {
/*  822 */       addParameter("form", form.getParameters());
/*      */       
/*  824 */       if (name != null) {
/*      */         
/*  826 */         List<String> tags = (List<String>)form.getParameters().get("tagNames");
/*  827 */         tags.add(name);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  833 */     if (this.tooltipConfig != null) {
/*  834 */       addParameter("tooltipConfig", findValue(this.tooltipConfig));
/*      */     }
/*  836 */     if (this.tooltip != null) {
/*  837 */       addParameter("tooltip", findString(this.tooltip));
/*      */       
/*  839 */       Map tooltipConfigMap = getTooltipConfig(this);
/*      */       
/*  841 */       if (form != null) {
/*  842 */         form.addParameter("hasTooltip", Boolean.TRUE);
/*      */ 
/*      */ 
/*      */         
/*  846 */         Map overallTooltipConfigMap = getTooltipConfig(form);
/*  847 */         overallTooltipConfigMap.putAll(tooltipConfigMap);
/*      */         
/*  849 */         for (Object o : overallTooltipConfigMap.entrySet()) {
/*  850 */           Map.Entry entry = (Map.Entry)o;
/*  851 */           addParameter((String)entry.getKey(), entry.getValue());
/*      */         } 
/*      */       } else {
/*      */         
/*  855 */         LOG.warn("No ancestor Form found, javascript based tooltip will not work, however standard HTML tooltip using alt and title attribute will still work");
/*      */       } 
/*      */ 
/*      */       
/*  859 */       String jsTooltipEnabled = (String)getParameters().get("jsTooltipEnabled");
/*  860 */       if (jsTooltipEnabled != null) {
/*  861 */         this.javascriptTooltip = jsTooltipEnabled;
/*      */       }
/*      */       
/*  864 */       String tooltipIcon = (String)getParameters().get("tooltipIcon");
/*  865 */       if (tooltipIcon != null)
/*  866 */         addParameter("tooltipIconPath", tooltipIcon); 
/*  867 */       if (this.tooltipIconPath != null) {
/*  868 */         addParameter("tooltipIconPath", findString(this.tooltipIconPath));
/*      */       }
/*      */       
/*  871 */       String tooltipDelayParam = (String)getParameters().get("tooltipDelay");
/*  872 */       if (tooltipDelayParam != null)
/*  873 */         addParameter("tooltipDelay", tooltipDelayParam); 
/*  874 */       if (this.tooltipDelay != null) {
/*  875 */         addParameter("tooltipDelay", findString(this.tooltipDelay));
/*      */       }
/*  877 */       if (this.javascriptTooltip != null) {
/*  878 */         Boolean jsTooltips = (Boolean)findValue(this.javascriptTooltip, Boolean.class);
/*      */         
/*  880 */         addParameter("jsTooltipEnabled", jsTooltips.toString());
/*      */         
/*  882 */         if (form != null)
/*  883 */           form.addParameter("hasTooltip", jsTooltips); 
/*  884 */         if (this.tooltipCssClass != null) {
/*  885 */           addParameter("tooltipCssClass", findString(this.tooltipCssClass));
/*      */         }
/*      */       } 
/*      */     } 
/*  889 */     evaluateExtraParams();
/*      */   }
/*      */ 
/*      */   
/*      */   protected String escape(String name) {
/*  894 */     if (name != null) {
/*  895 */       return name.replaceAll("[\\/\\.\\[\\]]", "_");
/*      */     }
/*  897 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String ensureAttributeSafelyNotEscaped(String val) {
/*  908 */     if (val != null) {
/*  909 */       return val.replaceAll("\"", "&#34;");
/*      */     }
/*  911 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void evaluateExtraParams() {}
/*      */ 
/*      */   
/*      */   protected boolean evaluateNameValue() {
/*  919 */     return true;
/*      */   }
/*      */   
/*      */   protected Class getValueClassType() {
/*  923 */     return String.class;
/*      */   }
/*      */   
/*      */   public void addFormParameter(String key, Object value) {
/*  927 */     Form form = (Form)findAncestor(Form.class);
/*  928 */     if (form != null) {
/*  929 */       form.addParameter(key, value);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void enableAncestorFormCustomOnsubmit() {
/*  934 */     Form form = (Form)findAncestor(Form.class);
/*  935 */     if (form != null) {
/*  936 */       form.addParameter("customOnsubmitEnabled", Boolean.TRUE);
/*      */     }
/*  938 */     else if (LOG.isWarnEnabled()) {
/*  939 */       LOG.warn("Cannot find an Ancestor form, custom onsubmit is NOT enabled");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map getTooltipConfig(UIBean component) {
/*  945 */     Object tooltipConfigObj = component.getParameters().get("tooltipConfig");
/*  946 */     Map<String, String> tooltipConfig = new LinkedHashMap<>();
/*      */     
/*  948 */     if (tooltipConfigObj instanceof Map) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  953 */       tooltipConfig = new LinkedHashMap<>((Map<? extends String, ? extends String>)tooltipConfigObj);
/*  954 */     } else if (tooltipConfigObj instanceof String) {
/*      */ 
/*      */ 
/*      */       
/*  958 */       String tooltipConfigStr = (String)tooltipConfigObj;
/*  959 */       String[] tooltipConfigArray = tooltipConfigStr.split("\\|");
/*      */       
/*  961 */       for (String aTooltipConfigArray : tooltipConfigArray) {
/*  962 */         String[] configEntry = aTooltipConfigArray.trim().split("=");
/*  963 */         String key = configEntry[0].trim();
/*      */         
/*  965 */         if (configEntry.length > 1) {
/*  966 */           String value = configEntry[1].trim();
/*  967 */           tooltipConfig.put(key, value);
/*      */         } else {
/*  969 */           LOG.warn("component {} tooltip config param {} has no value defined, skipped", component, key);
/*      */         } 
/*      */       } 
/*      */     } 
/*  973 */     if (component.javascriptTooltip != null)
/*  974 */       tooltipConfig.put("jsTooltipEnabled", component.javascriptTooltip); 
/*  975 */     if (component.tooltipIconPath != null)
/*  976 */       tooltipConfig.put("tooltipIcon", component.tooltipIconPath); 
/*  977 */     if (component.tooltipDelay != null)
/*  978 */       tooltipConfig.put("tooltipDelay", component.tooltipDelay); 
/*  979 */     return tooltipConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void populateComponentHtmlId(Form form) {
/*      */     String tryId;
/*  999 */     if (this.id != null)
/*      */     
/* 1001 */     { tryId = findStringIfAltSyntax(this.id); }
/* 1002 */     else { String generatedId; if (null == (generatedId = escape((this.name != null) ? findString(this.name) : null))) {
/* 1003 */         LOG.debug("Cannot determine id attribute for [{}], consider defining id, name or key attribute!", this);
/* 1004 */         tryId = null;
/* 1005 */       } else if (form != null) {
/* 1006 */         tryId = (new StringBuilder()).append(form.getParameters().get("id")).append("_").append(generatedId).toString();
/*      */       } else {
/* 1008 */         tryId = generatedId;
/*      */       }  }
/*      */ 
/*      */ 
/*      */     
/* 1013 */     if (tryId != null) {
/* 1014 */       addParameter("id", tryId);
/* 1015 */       addParameter("escapedId", escape(tryId));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getId() {
/* 1024 */     return this.id;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "HTML id attribute")
/*      */   public void setId(String id) {
/* 1029 */     this.id = id;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The template directory.")
/*      */   public void setTemplateDir(String templateDir) {
/* 1034 */     this.templateDir = templateDir;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The theme (other than default) to use for rendering the element")
/*      */   public void setTheme(String theme) {
/* 1039 */     this.theme = theme;
/*      */   }
/*      */   
/*      */   public String getTemplate() {
/* 1043 */     return this.template;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The template (other than default) to use for rendering the element")
/*      */   public void setTemplate(String template) {
/* 1048 */     this.template = template;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The css class to use for element")
/*      */   public void setCssClass(String cssClass) {
/* 1053 */     this.cssClass = cssClass;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   @StrutsTagAttribute(description = "(Deprecated) The css class to use for element - it's an alias of cssClass attribute.")
/*      */   public void setClass(String cssClass) {
/* 1059 */     this.cssClass = cssClass;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The css style definitions for element to use")
/*      */   public void setCssStyle(String cssStyle) {
/* 1064 */     this.cssStyle = cssStyle;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The css style definitions for element to use - it's an alias of cssStyle attribute.")
/*      */   public void setStyle(String cssStyle) {
/* 1069 */     this.cssStyle = cssStyle;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The css error class to use for element")
/*      */   public void setCssErrorClass(String cssErrorClass) {
/* 1074 */     this.cssErrorClass = cssErrorClass;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The css error style definitions for element to use")
/*      */   public void setCssErrorStyle(String cssErrorStyle) {
/* 1079 */     this.cssErrorStyle = cssErrorStyle;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html title attribute on rendered html element")
/*      */   public void setTitle(String title) {
/* 1084 */     this.title = title;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html disabled attribute on rendered html element")
/*      */   public void setDisabled(String disabled) {
/* 1089 */     this.disabled = disabled;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Label expression used for rendering an element specific label")
/*      */   public void setLabel(String label) {
/* 1094 */     this.label = label;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "String that will be appended to the label", defaultValue = ":")
/*      */   public void setLabelSeparator(String labelseparator) {
/* 1099 */     this.labelSeparator = labelseparator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @StrutsTagAttribute(description = "(Deprecated) Define label position of form element (top/left)")
/*      */   @Deprecated
/*      */   public void setLabelposition(String labelPosition) {
/* 1109 */     LOG.warn("\"labelposition\" attribute is deprecated, please use \"labelPosition\" instead!");
/* 1110 */     this.labelPosition = labelPosition;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Define label position of form element (top/left)")
/*      */   public void setLabelPosition(String labelPosition) {
/* 1115 */     this.labelPosition = labelPosition;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Define required position of required form element (left|right)")
/*      */   public void setRequiredPosition(String requiredPosition) {
/* 1120 */     this.requiredPosition = requiredPosition;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Define error position of form element (top|bottom)")
/*      */   public void setErrorPosition(String errorPosition) {
/* 1125 */     this.errorPosition = errorPosition;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "The name to set for element")
/*      */   public void setName(String name) {
/* 1130 */     this.name = name;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "If set to true, the rendered element will indicate that input is required", type = "Boolean", defaultValue = "false")
/*      */   public void setRequiredLabel(String requiredLabel) {
/* 1135 */     this.requiredLabel = requiredLabel;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html tabindex attribute on rendered html element")
/*      */   public void setTabindex(String tabindex) {
/* 1140 */     this.tabindex = tabindex;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Preset the value of input element.")
/*      */   public void setValue(String value) {
/* 1145 */     this.value = value;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onclick attribute on rendered html element")
/*      */   public void setOnclick(String onclick) {
/* 1150 */     this.onclick = onclick;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html ondblclick attribute on rendered html element")
/*      */   public void setOndblclick(String ondblclick) {
/* 1155 */     this.ondblclick = ondblclick;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onmousedown attribute on rendered html element")
/*      */   public void setOnmousedown(String onmousedown) {
/* 1160 */     this.onmousedown = onmousedown;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onmouseup attribute on rendered html element")
/*      */   public void setOnmouseup(String onmouseup) {
/* 1165 */     this.onmouseup = onmouseup;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onmouseover attribute on rendered html element")
/*      */   public void setOnmouseover(String onmouseover) {
/* 1170 */     this.onmouseover = onmouseover;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onmousemove attribute on rendered html element")
/*      */   public void setOnmousemove(String onmousemove) {
/* 1175 */     this.onmousemove = onmousemove;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onmouseout attribute on rendered html element")
/*      */   public void setOnmouseout(String onmouseout) {
/* 1180 */     this.onmouseout = onmouseout;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onfocus attribute on rendered html element")
/*      */   public void setOnfocus(String onfocus) {
/* 1185 */     this.onfocus = onfocus;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = " Set the html onblur attribute on rendered html element")
/*      */   public void setOnblur(String onblur) {
/* 1190 */     this.onblur = onblur;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onkeypress attribute on rendered html element")
/*      */   public void setOnkeypress(String onkeypress) {
/* 1195 */     this.onkeypress = onkeypress;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onkeydown attribute on rendered html element")
/*      */   public void setOnkeydown(String onkeydown) {
/* 1200 */     this.onkeydown = onkeydown;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onkeyup attribute on rendered html element")
/*      */   public void setOnkeyup(String onkeyup) {
/* 1205 */     this.onkeyup = onkeyup;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onselect attribute on rendered html element")
/*      */   public void setOnselect(String onselect) {
/* 1210 */     this.onselect = onselect;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html onchange attribute on rendered html element")
/*      */   public void setOnchange(String onchange) {
/* 1215 */     this.onchange = onchange;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the html accesskey attribute on rendered html element")
/*      */   public void setAccesskey(String accesskey) {
/* 1220 */     this.accesskey = accesskey;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the tooltip of this particular component")
/*      */   public void setTooltip(String tooltip) {
/* 1225 */     this.tooltip = tooltip;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Deprecated. Use individual tooltip configuration attributes instead.")
/*      */   public void setTooltipConfig(String tooltipConfig) {
/* 1230 */     this.tooltipConfig = tooltipConfig;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Set the key (name, value, label) for this particular component")
/*      */   public void setKey(String key) {
/* 1235 */     this.key = key;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Use JavaScript to generate tooltips", type = "Boolean", defaultValue = "false")
/*      */   public void setJavascriptTooltip(String javascriptTooltip) {
/* 1240 */     this.javascriptTooltip = javascriptTooltip;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "CSS class applied to JavaScrip tooltips", defaultValue = "StrutsTTClassic")
/*      */   public void setTooltipCssClass(String tooltipCssClass) {
/* 1245 */     this.tooltipCssClass = tooltipCssClass;
/*      */   }
/*      */ 
/*      */   
/*      */   @StrutsTagAttribute(description = "Delay in milliseconds, before showing JavaScript tooltips ", defaultValue = "Classic")
/*      */   public void setTooltipDelay(String tooltipDelay) {
/* 1251 */     this.tooltipDelay = tooltipDelay;
/*      */   }
/*      */   
/*      */   @StrutsTagAttribute(description = "Icon path used for image that will have the tooltip")
/*      */   public void setTooltipIconPath(String tooltipIconPath) {
/* 1256 */     this.tooltipIconPath = tooltipIconPath;
/*      */   }
/*      */   
/*      */   public void setDynamicAttributes(Map<String, String> tagDynamicAttributes) {
/* 1260 */     for (Map.Entry<String, String> entry : tagDynamicAttributes.entrySet()) {
/* 1261 */       String key = entry.getKey();
/*      */       
/* 1263 */       if (!isValidTagAttribute(key)) {
/* 1264 */         this.dynamicAttributes.put(key, entry.getValue());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyParams(Map params) {
/* 1276 */     super.copyParams(params);
/* 1277 */     for (Object o : params.entrySet()) {
/* 1278 */       Map.Entry entry = (Map.Entry)o;
/* 1279 */       String key = (String)entry.getKey();
/* 1280 */       if (!isValidTagAttribute(key) && !key.equals("dynamicAttributes"))
/* 1281 */         this.dynamicAttributes.put(key, entry.getValue()); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\UIBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */