/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "optiontransferselect", tldTagClass = "org.apache.struts2.views.jsp.ui.OptionTransferSelectTag", description = "Renders an input form")
/*     */ public class OptionTransferSelect
/*     */   extends DoubleListUIBean
/*     */ {
/*  91 */   private static final Logger LOG = LogManager.getLogger(OptionTransferSelect.class);
/*     */   
/*     */   private static final String TEMPLATE = "optiontransferselect";
/*     */   
/*     */   protected String allowAddToLeft;
/*     */   
/*     */   protected String allowAddToRight;
/*     */   
/*     */   protected String allowAddAllToLeft;
/*     */   
/*     */   protected String allowAddAllToRight;
/*     */   
/*     */   protected String allowSelectAll;
/*     */   
/*     */   protected String allowUpDownOnLeft;
/*     */   protected String allowUpDownOnRight;
/*     */   protected String leftTitle;
/*     */   protected String rightTitle;
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addToLeftLabel;
/*     */   protected String addToRightLabel;
/*     */   protected String addAllToLeftLabel;
/*     */   protected String addAllToRightLabel;
/*     */   protected String selectAllLabel;
/*     */   protected String leftUpLabel;
/*     */   protected String leftDownlabel;
/*     */   protected String rightUpLabel;
/*     */   protected String rightDownLabel;
/*     */   protected String addToLeftOnclick;
/*     */   protected String addToRightOnclick;
/*     */   protected String addAllToLeftOnclick;
/*     */   protected String addAllToRightOnclick;
/*     */   protected String selectAllOnclick;
/*     */   protected String upDownOnLeftOnclick;
/*     */   protected String upDownOnRightOnclick;
/*     */   
/*     */   public OptionTransferSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 129 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/* 133 */     return "optiontransferselect";
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluateExtraParams() {
/* 138 */     super.evaluateExtraParams();
/*     */     
/* 140 */     Object doubleValue = null;
/*     */ 
/*     */     
/* 143 */     if (this.doubleList != null) {
/* 144 */       doubleValue = findValue(this.doubleList);
/* 145 */       addParameter("doubleList", doubleValue);
/*     */     } 
/* 147 */     if (StringUtils.isBlank(this.size)) {
/* 148 */       addParameter("size", "15");
/*     */     }
/* 150 */     if (StringUtils.isBlank(this.doubleSize)) {
/* 151 */       addParameter("doubleSize", "15");
/*     */     }
/* 153 */     if (StringUtils.isBlank(this.multiple)) {
/* 154 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/* 156 */     if (StringUtils.isBlank(this.doubleMultiple)) {
/* 157 */       addParameter("doubleMultiple", Boolean.TRUE);
/*     */     }
/*     */ 
/*     */     
/* 161 */     if (StringUtils.isNotBlank(this.buttonCssClass)) {
/* 162 */       addParameter("buttonCssClass", this.buttonCssClass);
/*     */     }
/*     */ 
/*     */     
/* 166 */     if (StringUtils.isNotBlank(this.buttonCssStyle)) {
/* 167 */       addParameter("buttonCssStyle", this.buttonCssStyle);
/*     */     }
/*     */ 
/*     */     
/* 171 */     addParameter("allowSelectAll", (this.allowSelectAll != null) ? findValue(this.allowSelectAll, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 175 */     addParameter("allowAddToLeft", (this.allowAddToLeft != null) ? findValue(this.allowAddToLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 179 */     addParameter("allowAddToRight", (this.allowAddToRight != null) ? findValue(this.allowAddToRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 183 */     addParameter("allowAddAllToLeft", (this.allowAddAllToLeft != null) ? findValue(this.allowAddAllToLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 187 */     addParameter("allowAddAllToRight", (this.allowAddAllToRight != null) ? findValue(this.allowAddAllToRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 191 */     addParameter("allowUpDownOnLeft", (this.allowUpDownOnLeft != null) ? findValue(this.allowUpDownOnLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 195 */     addParameter("allowUpDownOnRight", (this.allowUpDownOnRight != null) ? findValue(this.allowUpDownOnRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     if (this.leftTitle != null) {
/* 201 */       addParameter("leftTitle", findValue(this.leftTitle, String.class));
/*     */     }
/*     */ 
/*     */     
/* 205 */     if (this.rightTitle != null) {
/* 206 */       addParameter("rightTitle", findValue(this.rightTitle, String.class));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 211 */     addParameter("addToLeftLabel", (this.addToLeftLabel != null) ? findValue(this.addToLeftLabel, String.class) : "<-");
/*     */ 
/*     */ 
/*     */     
/* 215 */     addParameter("addToRightLabel", (this.addToRightLabel != null) ? findValue(this.addToRightLabel, String.class) : "->");
/*     */ 
/*     */ 
/*     */     
/* 219 */     addParameter("addAllToLeftLabel", (this.addAllToLeftLabel != null) ? findValue(this.addAllToLeftLabel, String.class) : "<<--");
/*     */ 
/*     */ 
/*     */     
/* 223 */     addParameter("addAllToRightLabel", (this.addAllToRightLabel != null) ? findValue(this.addAllToRightLabel, String.class) : "-->>");
/*     */ 
/*     */ 
/*     */     
/* 227 */     addParameter("selectAllLabel", (this.selectAllLabel != null) ? findValue(this.selectAllLabel, String.class) : "<*>");
/*     */ 
/*     */ 
/*     */     
/* 231 */     addParameter("leftUpLabel", (this.leftUpLabel != null) ? findValue(this.leftUpLabel, String.class) : "^");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     addParameter("leftDownLabel", (this.leftDownlabel != null) ? findValue(this.leftDownlabel, String.class) : "v");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     addParameter("rightUpLabel", (this.rightUpLabel != null) ? findValue(this.rightUpLabel, String.class) : "^");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     addParameter("rightDownLabel", (this.rightDownLabel != null) ? findValue(this.rightDownLabel, String.class) : "v");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     addParameter("selectAllOnclick", (this.selectAllOnclick != null) ? findValue(this.selectAllOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 255 */     addParameter("addToLeftOnclick", (this.addToLeftOnclick != null) ? findValue(this.addToLeftOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 259 */     addParameter("addToRightOnclick", (this.addToRightOnclick != null) ? findValue(this.addToRightOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 263 */     addParameter("addAllToLeftOnclick", (this.addAllToLeftOnclick != null) ? findValue(this.addAllToLeftOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 267 */     addParameter("addAllToRightOnclick", (this.addAllToRightOnclick != null) ? findValue(this.addAllToRightOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 271 */     addParameter("upDownOnLeftOnclick", (this.upDownOnLeftOnclick != null) ? findValue(this.upDownOnLeftOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */     
/* 275 */     addParameter("upDownOnRightOnclick", (this.upDownOnRightOnclick != null) ? findValue(this.upDownOnRightOnclick, String.class) : "");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     Form formAncestor = (Form)findAncestor(Form.class);
/* 283 */     if (formAncestor != null) {
/*     */ 
/*     */       
/* 286 */       enableAncestorFormCustomOnsubmit();
/*     */ 
/*     */ 
/*     */       
/* 290 */       Map<Object, Object> formOptiontransferselectIds = (Map)formAncestor.getParameters().get("optiontransferselectIds");
/* 291 */       Map<Object, Object> formOptiontransferselectDoubleIds = (Map)formAncestor.getParameters().get("optiontransferselectDoubleIds");
/*     */ 
/*     */       
/* 294 */       if (formOptiontransferselectIds == null) {
/* 295 */         formOptiontransferselectIds = new LinkedHashMap<>();
/*     */       }
/* 297 */       if (formOptiontransferselectDoubleIds == null) {
/* 298 */         formOptiontransferselectDoubleIds = new LinkedHashMap<>();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 303 */       String tmpId = (String)getParameters().get("id");
/* 304 */       String tmpHeaderKey = (String)getParameters().get("headerKey");
/* 305 */       if (tmpId != null && !formOptiontransferselectIds.containsKey(tmpId)) {
/* 306 */         formOptiontransferselectIds.put(tmpId, tmpHeaderKey);
/*     */       }
/*     */ 
/*     */       
/* 310 */       String tmpDoubleId = (String)getParameters().get("doubleId");
/* 311 */       String tmpDoubleHeaderKey = (String)getParameters().get("doubleHeaderKey");
/* 312 */       if (tmpDoubleId != null && !formOptiontransferselectDoubleIds.containsKey(tmpDoubleId)) {
/* 313 */         formOptiontransferselectDoubleIds.put(tmpDoubleId, tmpDoubleHeaderKey);
/*     */       }
/*     */       
/* 316 */       formAncestor.getParameters().put("optiontransferselectIds", formOptiontransferselectIds);
/* 317 */       formAncestor.getParameters().put("optiontransferselectDoubleIds", formOptiontransferselectDoubleIds);
/*     */ 
/*     */     
/*     */     }
/* 321 */     else if (LOG.isWarnEnabled()) {
/* 322 */       LOG.warn("form enclosing optiontransferselect " + this + " not found, auto select upon form submit of optiontransferselect will not work");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAddAllToLeftLabel() {
/* 330 */     return this.addAllToLeftLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Add To Left button label")
/*     */   public void setAddAllToLeftLabel(String addAllToLeftLabel) {
/* 335 */     this.addAllToLeftLabel = addAllToLeftLabel;
/*     */   }
/*     */   
/*     */   public String getAddAllToRightLabel() {
/* 339 */     return this.addAllToRightLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Add All To Right button label")
/*     */   public void setAddAllToRightLabel(String addAllToRightLabel) {
/* 344 */     this.addAllToRightLabel = addAllToRightLabel;
/*     */   }
/*     */   
/*     */   public String getAddToLeftLabel() {
/* 348 */     return this.addToLeftLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Add To Left button label")
/*     */   public void setAddToLeftLabel(String addToLeftLabel) {
/* 353 */     this.addToLeftLabel = addToLeftLabel;
/*     */   }
/*     */   
/*     */   public String getAddToRightLabel() {
/* 357 */     return this.addToRightLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Add To Right button label")
/*     */   public void setAddToRightLabel(String addToRightLabel) {
/* 362 */     this.addToRightLabel = addToRightLabel;
/*     */   }
/*     */   
/*     */   public String getAllowAddAllToLeft() {
/* 366 */     return this.allowAddAllToLeft;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable Add All To Left button")
/*     */   public void setAllowAddAllToLeft(String allowAddAllToLeft) {
/* 371 */     this.allowAddAllToLeft = allowAddAllToLeft;
/*     */   }
/*     */   
/*     */   public String getAllowAddAllToRight() {
/* 375 */     return this.allowAddAllToRight;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable Add All To Right button")
/*     */   public void setAllowAddAllToRight(String allowAddAllToRight) {
/* 380 */     this.allowAddAllToRight = allowAddAllToRight;
/*     */   }
/*     */   
/*     */   public String getAllowAddToLeft() {
/* 384 */     return this.allowAddToLeft;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable Add To Left button")
/*     */   public void setAllowAddToLeft(String allowAddToLeft) {
/* 389 */     this.allowAddToLeft = allowAddToLeft;
/*     */   }
/*     */   
/*     */   public String getAllowAddToRight() {
/* 393 */     return this.allowAddToRight;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable Add To Right button")
/*     */   public void setAllowAddToRight(String allowAddToRight) {
/* 398 */     this.allowAddToRight = allowAddToRight;
/*     */   }
/*     */   
/*     */   public String getLeftTitle() {
/* 402 */     return this.leftTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable up / down on the left side")
/*     */   public void setAllowUpDownOnLeft(String allowUpDownOnLeft) {
/* 407 */     this.allowUpDownOnLeft = allowUpDownOnLeft;
/*     */   }
/*     */   
/*     */   public String getAllowUpDownOnLeft() {
/* 411 */     return this.allowUpDownOnLeft;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable up / down on the right side")
/*     */   public void setAllowUpDownOnRight(String allowUpDownOnRight) {
/* 416 */     this.allowUpDownOnRight = allowUpDownOnRight;
/*     */   }
/*     */   
/*     */   public String getAllowUpDownOnRight() {
/* 420 */     return this.allowUpDownOnRight;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Left title")
/*     */   public void setLeftTitle(String leftTitle) {
/* 425 */     this.leftTitle = leftTitle;
/*     */   }
/*     */   
/*     */   public String getRightTitle() {
/* 429 */     return this.rightTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Right title")
/*     */   public void setRightTitle(String rightTitle) {
/* 434 */     this.rightTitle = rightTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Enable Select All button")
/*     */   public void setAllowSelectAll(String allowSelectAll) {
/* 439 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */   
/*     */   public String getAllowSelectAll() {
/* 443 */     return this.allowSelectAll;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set Select All button label")
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 448 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */   
/*     */   public String getSelectAllLabel() {
/* 452 */     return this.selectAllLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set buttons css class")
/*     */   public void setButtonCssClass(String buttonCssClass) {
/* 457 */     this.buttonCssClass = buttonCssClass;
/*     */   }
/*     */   
/*     */   public String getButtonCssClass() {
/* 461 */     return this.buttonCssClass;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set button css style")
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 466 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */   
/*     */   public String getButtonCssStyle() {
/* 470 */     return this.buttonCssStyle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Up label for the left side")
/*     */   public void setLeftUpLabel(String leftUpLabel) {
/* 475 */     this.leftUpLabel = leftUpLabel;
/*     */   }
/*     */   public String getLeftUpLabel() {
/* 478 */     return this.leftUpLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Down label for the left side.")
/*     */   public void setLeftDownLabel(String leftDownLabel) {
/* 483 */     this.leftDownlabel = leftDownLabel;
/*     */   }
/*     */   public String getLeftDownLabel() {
/* 486 */     return this.leftDownlabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Up label for the right side.")
/*     */   public void setRightUpLabel(String rightUpLabel) {
/* 491 */     this.rightUpLabel = rightUpLabel;
/*     */   }
/*     */   public String getRightUpLabel() {
/* 494 */     return this.rightUpLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Down label for the left side.")
/*     */   public void setRightDownLabel(String rightDownlabel) {
/* 499 */     this.rightDownLabel = rightDownlabel;
/*     */   }
/*     */   public String getRightDownLabel() {
/* 502 */     return this.rightDownLabel;
/*     */   }
/*     */   
/*     */   public String getAddAllToLeftOnclick() {
/* 506 */     return this.addAllToLeftOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after Add All To Left button pressed")
/*     */   public void setAddAllToLeftOnclick(String addAllToLeftOnclick) {
/* 511 */     this.addAllToLeftOnclick = addAllToLeftOnclick;
/*     */   }
/*     */   
/*     */   public String getAddAllToRightOnclick() {
/* 515 */     return this.addAllToRightOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after Add All To Right button pressed")
/*     */   public void setAddAllToRightOnclick(String addAllToRightOnclick) {
/* 520 */     this.addAllToRightOnclick = addAllToRightOnclick;
/*     */   }
/*     */   
/*     */   public String getAddToLeftOnclick() {
/* 524 */     return this.addToLeftOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after Add To Left button pressed")
/*     */   public void setAddToLeftOnclick(String addToLeftOnclick) {
/* 529 */     this.addToLeftOnclick = addToLeftOnclick;
/*     */   }
/*     */   
/*     */   public String getAddToRightOnclick() {
/* 533 */     return this.addToRightOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after Add To Right button pressed")
/*     */   public void setAddToRightOnclick(String addToRightOnclick) {
/* 538 */     this.addToRightOnclick = addToRightOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after up / down on the left side buttons pressed")
/*     */   public void setUpDownOnLeftOnclick(String upDownOnLeftOnclick) {
/* 543 */     this.upDownOnLeftOnclick = upDownOnLeftOnclick;
/*     */   }
/*     */   
/*     */   public String getUpDownOnLeftOnclick() {
/* 547 */     return this.upDownOnLeftOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after up / down on the right side buttons pressed")
/*     */   public void setUpDownOnRightOnclick(String upDownOnRightOnclick) {
/* 552 */     this.upDownOnRightOnclick = upDownOnRightOnclick;
/*     */   }
/*     */   
/*     */   public String getUpDownOnRightOnclick() {
/* 556 */     return this.upDownOnRightOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Javascript to run after Select All button pressed")
/*     */   public void setSelectAllOnclick(String selectAllOnclick) {
/* 561 */     this.selectAllOnclick = selectAllOnclick;
/*     */   }
/*     */   
/*     */   public String getSelectAllOnclick() {
/* 565 */     return this.selectAllOnclick;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\OptionTransferSelect.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */