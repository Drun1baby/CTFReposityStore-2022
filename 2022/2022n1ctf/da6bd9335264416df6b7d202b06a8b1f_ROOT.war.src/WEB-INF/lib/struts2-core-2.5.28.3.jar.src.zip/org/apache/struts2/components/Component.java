/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.lang3.reflect.MethodUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.util.ComponentUtils;
/*     */ import org.apache.struts2.util.FastByteArrayOutputStream;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.TagUtils;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Component
/*     */ {
/*  57 */   private static final Logger LOG = LogManager.getLogger(Component.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String COMPONENT_STACK = "__component_stack";
/*     */ 
/*     */   
/*  64 */   protected static ConcurrentMap<Class<?>, Collection<String>> standardAttributesMap = new ConcurrentHashMap<>();
/*     */   
/*     */   protected boolean devMode = false;
/*     */   
/*     */   protected ValueStack stack;
/*     */   
/*     */   protected Map parameters;
/*     */   
/*     */   protected ActionMapper actionMapper;
/*     */   
/*     */   protected boolean throwExceptionOnELFailure;
/*     */   
/*     */   private UrlHelper urlHelper;
/*     */   
/*     */   public Component(ValueStack stack) {
/*  79 */     this.stack = stack;
/*  80 */     this.parameters = new LinkedHashMap<>();
/*  81 */     getComponentStack().push(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getComponentName() {
/*  89 */     Class<?> c = getClass();
/*  90 */     String name = c.getName();
/*  91 */     int dot = name.lastIndexOf('.');
/*     */     
/*  93 */     return name.substring(dot + 1).toLowerCase();
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.devMode", required = false)
/*     */   public void setDevMode(String devMode) {
/*  98 */     this.devMode = BooleanUtils.toBoolean(devMode);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/* 103 */     this.actionMapper = mapper;
/*     */   }
/*     */   
/*     */   @Inject("struts.el.throwExceptionOnFailure")
/*     */   public void setThrowExceptionsOnELFailure(String throwException) {
/* 108 */     this.throwExceptionOnELFailure = BooleanUtils.toBoolean(throwException);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/* 113 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueStack getStack() {
/* 120 */     return this.stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stack<Component> getComponentStack() {
/* 128 */     Stack<Component> componentStack = (Stack<Component>)this.stack.getContext().get("__component_stack");
/* 129 */     if (componentStack == null) {
/* 130 */       componentStack = new Stack<>();
/* 131 */       this.stack.getContext().put("__component_stack", componentStack);
/*     */     } 
/* 133 */     return componentStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean start(Writer writer) {
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 157 */     return end(writer, body, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean end(Writer writer, String body, boolean popComponentStack) {
/* 171 */     assert body != null;
/*     */     
/*     */     try {
/* 174 */       writer.write(body);
/* 175 */     } catch (IOException e) {
/* 176 */       throw new StrutsException("IOError while writing the body: " + e.getMessage(), e);
/*     */     } 
/* 178 */     if (popComponentStack) {
/* 179 */       popComponentStack();
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void popComponentStack() {
/* 188 */     getComponentStack().pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component findAncestor(Class clazz) {
/* 197 */     Stack<Component> componentStack = getComponentStack();
/* 198 */     int currPosition = componentStack.search(this);
/* 199 */     if (currPosition >= 0) {
/* 200 */       int start = componentStack.size() - currPosition - 1;
/*     */ 
/*     */       
/* 203 */       for (int i = start; i >= 0; i--) {
/* 204 */         Component component = componentStack.get(i);
/* 205 */         if (clazz.isAssignableFrom(component.getClass()) && component != this) {
/* 206 */           return component;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String findString(String expr) {
/* 220 */     return (String)findValue(expr, String.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String findString(String expr, String field, String errorMsg) {
/* 236 */     if (expr == null) {
/* 237 */       throw fieldError(field, errorMsg, null);
/*     */     }
/* 239 */     return findString(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StrutsException fieldError(String field, String errorMsg, Exception e) {
/* 254 */     String msg = "tag '" + getComponentName() + "', field '" + field + ((this.parameters != null && this.parameters.containsKey("name")) ? ("', name '" + this.parameters.get("name")) : "") + "': " + errorMsg;
/*     */ 
/*     */     
/* 257 */     throw new StrutsException(msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object findValue(String expr) {
/* 269 */     if (expr == null) {
/* 270 */       return null;
/*     */     }
/*     */     
/* 273 */     expr = stripExpressionIfAltSyntax(expr);
/*     */     
/* 275 */     return getStack().findValue(expr, this.throwExceptionOnELFailure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String stripExpressionIfAltSyntax(String expr) {
/* 285 */     return ComponentUtils.stripExpressionIfAltSyntax(this.stack, expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean altSyntax() {
/* 293 */     return ComponentUtils.altSyntax(this.stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String completeExpressionIfAltSyntax(String expr) {
/* 303 */     if (altSyntax() && !ComponentUtils.containsExpression(expr)) {
/* 304 */       return "%{" + expr + "}";
/*     */     }
/* 306 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String findStringIfAltSyntax(String expr) {
/* 316 */     if (altSyntax()) {
/* 317 */       return findString(expr);
/*     */     }
/* 319 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object findValue(String expr, String field, String errorMsg) {
/* 341 */     if (expr == null) {
/* 342 */       throw fieldError(field, errorMsg, null);
/*     */     }
/* 344 */     Object value = null;
/* 345 */     Exception problem = null;
/*     */     try {
/* 347 */       value = findValue(expr);
/* 348 */     } catch (Exception e) {
/* 349 */       problem = e;
/*     */     } 
/*     */     
/* 352 */     if (value == null) {
/* 353 */       throw fieldError(field, errorMsg, problem);
/*     */     }
/*     */     
/* 356 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object findValue(String expr, Class<String> toType) {
/* 372 */     if (altSyntax() && toType == String.class) {
/* 373 */       if (ComponentUtils.containsExpression(expr)) {
/* 374 */         return TextParseUtil.translateVariables('%', expr, this.stack);
/*     */       }
/* 376 */       return expr;
/*     */     } 
/*     */     
/* 379 */     expr = stripExpressionIfAltSyntax(expr);
/*     */     
/* 381 */     return getStack().findValue(expr, toType, this.throwExceptionOnELFailure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean recursion(String expr) {
/* 391 */     return (ComponentUtils.altSyntax(this.stack) && ComponentUtils.containsExpression(expr));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineActionURL(String action, String namespace, String method, HttpServletRequest req, HttpServletResponse res, Map parameters, String scheme, boolean includeContext, boolean encodeResult, boolean forceAddSchemeHostAndPort, boolean escapeAmp) {
/* 413 */     String finalAction = findString(action);
/* 414 */     String finalMethod = (method != null) ? findString(method) : null;
/* 415 */     String finalNamespace = determineNamespace(namespace, getStack(), req);
/* 416 */     ActionMapping mapping = new ActionMapping(finalAction, finalNamespace, finalMethod, parameters);
/* 417 */     String uri = this.actionMapper.getUriFromActionMapping(mapping);
/* 418 */     return this.urlHelper.buildUrl(uri, req, res, parameters, scheme, includeContext, encodeResult, forceAddSchemeHostAndPort, escapeAmp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String determineNamespace(String namespace, ValueStack stack, HttpServletRequest req) {
/*     */     String result;
/* 431 */     if (namespace == null) {
/* 432 */       result = TagUtils.buildNamespace(this.actionMapper, stack, req);
/*     */     } else {
/* 434 */       result = findString(namespace);
/*     */     } 
/*     */     
/* 437 */     if (result == null) {
/* 438 */       result = "";
/*     */     }
/*     */     
/* 441 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyParams(Map params) {
/* 453 */     this.stack.push(this.parameters);
/* 454 */     this.stack.push(this);
/*     */     try {
/* 456 */       for (Object o : params.entrySet()) {
/* 457 */         Map.Entry entry = (Map.Entry)o;
/* 458 */         String key = (String)entry.getKey();
/*     */         
/* 460 */         if (key.indexOf('-') >= 0) {
/*     */ 
/*     */ 
/*     */           
/* 464 */           this.parameters.put(key, entry.getValue()); continue;
/*     */         } 
/* 466 */         this.stack.setValue(key, entry.getValue());
/*     */       } 
/*     */     } finally {
/*     */       
/* 470 */       this.stack.pop();
/* 471 */       this.stack.pop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toString(Throwable t) {
/* 481 */     try(FastByteArrayOutputStream bout = new FastByteArrayOutputStream(); 
/* 482 */         PrintWriter wrt = new PrintWriter((OutputStream)bout)) {
/* 483 */       t.printStackTrace(wrt);
/* 484 */       return bout.toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getParameters() {
/* 493 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAllParameters(Map params) {
/* 501 */     this.parameters.putAll(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String key, Object value) {
/* 514 */     if (key != null) {
/* 515 */       Map<String, Object> params = getParameters();
/*     */       
/* 517 */       if (value == null) {
/* 518 */         params.remove(key);
/*     */       } else {
/* 520 */         params.put(key, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesBody() {
/* 530 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidTagAttribute(String attrName) {
/* 540 */     return getStandardAttributes().contains(attrName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<String> getStandardAttributes() {
/* 549 */     Class<?> clz = getClass();
/* 550 */     Collection<String> standardAttributes = standardAttributesMap.get(clz);
/* 551 */     if (standardAttributes == null) {
/* 552 */       Collection<Method> methods = MethodUtils.getMethodsListWithAnnotation(clz, StrutsTagAttribute.class, true, true);
/*     */       
/* 554 */       standardAttributes = new HashSet<>(methods.size());
/* 555 */       for (Method m : methods) {
/* 556 */         standardAttributes.add(StringUtils.uncapitalize(m.getName().substring(3)));
/*     */       }
/* 558 */       standardAttributesMap.putIfAbsent(clz, standardAttributes);
/*     */     } 
/* 560 */     return standardAttributes;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Component.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */