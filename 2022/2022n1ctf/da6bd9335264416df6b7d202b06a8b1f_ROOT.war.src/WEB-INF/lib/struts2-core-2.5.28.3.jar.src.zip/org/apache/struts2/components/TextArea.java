/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "textarea", tldTagClass = "org.apache.struts2.views.jsp.ui.TextareaTag", description = "Render HTML textarea tag.", allowDynamicAttributes = true)
/*     */ public class TextArea
/*     */   extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "textarea";
/*     */   protected String cols;
/*     */   protected String readonly;
/*     */   protected String rows;
/*     */   protected String wrap;
/*     */   
/*     */   public TextArea(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  56 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  60 */     return "textarea";
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/*  64 */     super.evaluateExtraParams();
/*     */     
/*  66 */     if (this.readonly != null) {
/*  67 */       addParameter("readonly", findValue(this.readonly, Boolean.class));
/*     */     }
/*     */     
/*  70 */     if (this.cols != null) {
/*  71 */       addParameter("cols", findString(this.cols));
/*     */     }
/*     */     
/*  74 */     if (this.rows != null) {
/*  75 */       addParameter("rows", findString(this.rows));
/*     */     }
/*     */     
/*  78 */     if (this.wrap != null) {
/*  79 */       addParameter("wrap", findString(this.wrap));
/*     */     }
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML cols attribute", type = "Integer")
/*     */   public void setCols(String cols) {
/*  85 */     this.cols = cols;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether the textarea is readonly", type = "Boolean", defaultValue = "false")
/*     */   public void setReadonly(String readonly) {
/*  90 */     this.readonly = readonly;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML rows attribute", type = "Integer")
/*     */   public void setRows(String rows) {
/*  95 */     this.rows = rows;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "HTML wrap attribute")
/*     */   public void setWrap(String wrap) {
/* 100 */     this.wrap = wrap;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\TextArea.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */