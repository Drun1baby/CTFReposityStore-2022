/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.IteratorStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "iterator", tldTagClass = "org.apache.struts2.views.jsp.IteratorTag", description = "Iterate over a iterable value")
/*     */ public class IteratorComponent
/*     */   extends ContextBean
/*     */ {
/* 226 */   private static final Logger LOG = LogManager.getLogger(IteratorComponent.class);
/*     */   
/*     */   protected Iterator iterator;
/*     */   protected IteratorStatus status;
/*     */   protected Object oldStatus;
/*     */   protected IteratorStatus.StatusState statusState;
/*     */   protected String statusAttr;
/*     */   protected String value;
/*     */   protected String beginStr;
/*     */   protected Integer begin;
/*     */   protected String endStr;
/*     */   protected Integer end;
/*     */   protected String stepStr;
/*     */   protected Integer step;
/*     */   
/*     */   public IteratorComponent(ValueStack stack) {
/* 242 */     super(stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean start(Writer writer) {
/* 247 */     if (this.statusAttr != null) {
/* 248 */       this.statusState = new IteratorStatus.StatusState();
/* 249 */       this.status = new IteratorStatus(this.statusState);
/*     */     } 
/*     */     
/* 252 */     if (this.beginStr != null) {
/* 253 */       this.begin = (Integer)findValue(this.beginStr, Integer.class);
/*     */     }
/* 255 */     if (this.endStr != null) {
/* 256 */       this.end = (Integer)findValue(this.endStr, Integer.class);
/*     */     }
/* 258 */     if (this.stepStr != null) {
/* 259 */       this.step = (Integer)findValue(this.stepStr, Integer.class);
/*     */     }
/* 261 */     ValueStack stack = getStack();
/*     */     
/* 263 */     if (this.value == null && this.begin == null && this.end == null) {
/* 264 */       this.value = "top";
/*     */     }
/* 266 */     Object iteratorTarget = findValue(this.value);
/* 267 */     this.iterator = MakeIterator.convert(iteratorTarget);
/*     */     
/* 269 */     if (this.begin != null) {
/*     */       
/* 271 */       if (this.step == null) {
/* 272 */         this.step = Integer.valueOf(1);
/*     */       }
/* 274 */       if (this.iterator == null) {
/*     */         
/* 276 */         this.iterator = new CounterIterator(this.begin, this.end, this.step, null);
/*     */       
/*     */       }
/* 279 */       else if (iteratorTarget.getClass().isArray()) {
/* 280 */         Object[] values = (Object[])iteratorTarget;
/* 281 */         if (this.end == null)
/* 282 */           this.end = Integer.valueOf((this.step.intValue() > 0) ? (values.length - 1) : 0); 
/* 283 */         this.iterator = new CounterIterator(this.begin, this.end, this.step, Arrays.asList(values));
/* 284 */       } else if (iteratorTarget instanceof List) {
/* 285 */         List<Object> values = (List)iteratorTarget;
/* 286 */         if (this.end == null)
/* 287 */           this.end = Integer.valueOf((this.step.intValue() > 0) ? (values.size() - 1) : 0); 
/* 288 */         this.iterator = new CounterIterator(this.begin, this.end, this.step, values);
/*     */       } else {
/*     */         
/* 291 */         LOG.error("Incorrect use of the iterator tag. When 'begin' is set, 'value' must be an Array or a List, or not set at all. 'begin', 'end' and 'step' will be ignored");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     if (this.iterator != null && this.iterator.hasNext()) {
/* 299 */       Object currentValue = this.iterator.next();
/* 300 */       stack.push(currentValue);
/*     */       
/* 302 */       String var = getVar();
/*     */       
/* 304 */       if (var != null) {
/* 305 */         putInContext(currentValue);
/*     */       }
/*     */ 
/*     */       
/* 309 */       if (this.statusAttr != null) {
/* 310 */         this.statusState.setLast(!this.iterator.hasNext());
/* 311 */         this.oldStatus = stack.getContext().get(this.statusAttr);
/* 312 */         stack.getContext().put(this.statusAttr, this.status);
/*     */       } 
/*     */       
/* 315 */       return true;
/*     */     } 
/* 317 */     super.end(writer, "");
/* 318 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 323 */     ValueStack stack = getStack();
/* 324 */     if (this.iterator != null) {
/* 325 */       stack.pop();
/*     */     }
/*     */     
/* 328 */     if (this.iterator != null && this.iterator.hasNext()) {
/* 329 */       Object currentValue = this.iterator.next();
/* 330 */       stack.push(currentValue);
/*     */       
/* 332 */       putInContext(currentValue);
/*     */ 
/*     */       
/* 335 */       if (this.status != null) {
/* 336 */         this.statusState.next();
/* 337 */         this.statusState.setLast(!this.iterator.hasNext());
/*     */       } 
/*     */       
/* 340 */       return true;
/*     */     } 
/*     */     
/* 343 */     if (this.status != null) {
/* 344 */       if (this.oldStatus == null) {
/* 345 */         stack.getContext().put(this.statusAttr, null);
/*     */       } else {
/* 347 */         stack.getContext().put(this.statusAttr, this.oldStatus);
/*     */       } 
/*     */     }
/* 350 */     super.end(writer, "");
/* 351 */     return false;
/*     */   }
/*     */   
/*     */   static class CounterIterator
/*     */     implements Iterator<Object> {
/*     */     private int step;
/*     */     private int end;
/*     */     private int currentIndex;
/*     */     private List<Object> values;
/*     */     
/*     */     CounterIterator(Integer begin, Integer end, Integer step, List<Object> values) {
/* 362 */       this.end = end.intValue();
/* 363 */       if (step != null)
/* 364 */         this.step = step.intValue(); 
/* 365 */       this.currentIndex = begin.intValue() - this.step;
/* 366 */       this.values = values;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 370 */       int next = peekNextIndex();
/* 371 */       return (this.step > 0) ? ((next <= this.end)) : ((next >= this.end));
/*     */     }
/*     */     
/*     */     public Object next() {
/* 375 */       if (hasNext()) {
/* 376 */         int nextIndex = peekNextIndex();
/* 377 */         this.currentIndex += this.step;
/* 378 */         return (this.values != null) ? this.values.get(nextIndex) : Integer.valueOf(nextIndex);
/*     */       } 
/* 380 */       throw new IndexOutOfBoundsException("Index " + (this.currentIndex + this.step) + " must be less than or equal to " + this.end);
/*     */     }
/*     */ 
/*     */     
/*     */     private int peekNextIndex() {
/* 385 */       return this.currentIndex + this.step;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 389 */       throw new UnsupportedOperationException("Values cannot be removed from this iterator");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "If specified, an instanceof IteratorStatus will be pushed into stack upon each iteration", type = "Boolean", defaultValue = "false")
/*     */   public void setStatus(String status) {
/* 396 */     this.statusAttr = status;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the iteratable source to iterate over, else an the object itself will be put into a newly created List")
/*     */   public void setValue(String value) {
/* 401 */     this.value = value;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "if specified the iteration will start on that index", type = "Integer", defaultValue = "0")
/*     */   public void setBegin(String begin) {
/* 406 */     this.beginStr = begin;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "if specified the iteration will end on that index(inclusive)", type = "Integer", defaultValue = "Size of the 'values' List or array, or 0 if 'step' is negative")
/*     */   public void setEnd(String end) {
/* 412 */     this.endStr = end;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "if specified the iteration index will be increased by this value on each iteration. It can be a negative value, in which case 'begin' must be greater than 'end'", type = "Integer", defaultValue = "1")
/*     */   public void setStep(String step) {
/* 418 */     this.stepStr = step;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\IteratorComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */