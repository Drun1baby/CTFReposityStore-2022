/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "inputtransferselect", tldTagClass = "org.apache.struts2.views.jsp.ui.InputTransferSelectTag", description = "Renders an input form")
/*     */ public class InputTransferSelect
/*     */   extends ListUIBean
/*     */ {
/*  69 */   private static final Logger LOG = LogManager.getLogger(InputTransferSelect.class);
/*     */   
/*     */   private static final String TEMPLATE = "inputtransferselect";
/*     */   
/*     */   protected String size;
/*     */   
/*     */   protected String multiple;
/*     */   
/*     */   protected String allowRemoveAll;
/*     */   
/*     */   protected String allowUpDown;
/*     */   
/*     */   protected String leftTitle;
/*     */   
/*     */   protected String rightTitle;
/*     */   
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addLabel;
/*     */   protected String removeLabel;
/*     */   protected String removeAllLabel;
/*     */   protected String upLabel;
/*     */   protected String downLabel;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   
/*     */   public InputTransferSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  96 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/* 100 */     return "inputtransferselect";
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluateExtraParams() {
/* 105 */     super.evaluateExtraParams();
/*     */     
/* 107 */     if (StringUtils.isBlank(this.size)) {
/* 108 */       addParameter("size", "5");
/*     */     }
/*     */     
/* 111 */     if (StringUtils.isBlank(this.multiple)) {
/* 112 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/*     */ 
/*     */     
/* 116 */     addParameter("allowUpDown", (this.allowUpDown != null) ? findValue(this.allowUpDown, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */     
/* 119 */     addParameter("allowRemoveAll", (this.allowRemoveAll != null) ? findValue(this.allowRemoveAll, Boolean.class) : Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (this.leftTitle != null) {
/* 124 */       addParameter("leftTitle", findValue(this.leftTitle, String.class));
/*     */     }
/*     */ 
/*     */     
/* 128 */     if (this.rightTitle != null) {
/* 129 */       addParameter("rightTitle", findValue(this.rightTitle, String.class));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (StringUtils.isNotBlank(this.buttonCssClass)) {
/* 135 */       addParameter("buttonCssClass", this.buttonCssClass);
/*     */     }
/*     */ 
/*     */     
/* 139 */     if (StringUtils.isNotBlank(this.buttonCssStyle)) {
/* 140 */       addParameter("buttonCssStyle", this.buttonCssStyle);
/*     */     }
/*     */ 
/*     */     
/* 144 */     addParameter("addLabel", (this.addLabel != null) ? findValue(this.addLabel, String.class) : "->");
/*     */ 
/*     */     
/* 147 */     addParameter("removeLabel", (this.removeLabel != null) ? findValue(this.removeLabel, String.class) : "<-");
/*     */ 
/*     */     
/* 150 */     addParameter("removeAllLabel", (this.removeAllLabel != null) ? findValue(this.removeAllLabel, String.class) : "<<--");
/*     */ 
/*     */ 
/*     */     
/* 154 */     addParameter("upLabel", (this.upLabel != null) ? findValue(this.upLabel, String.class) : "^");
/*     */ 
/*     */ 
/*     */     
/* 158 */     addParameter("downLabel", (this.downLabel != null) ? findValue(this.downLabel, String.class) : "v");
/*     */     
/* 160 */     if (this.headerKey != null && this.headerValue != null) {
/* 161 */       addParameter("headerKey", findString(this.headerKey));
/* 162 */       addParameter("headerValue", findString(this.headerValue));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     Form formAncestor = (Form)findAncestor(Form.class);
/* 170 */     if (formAncestor != null) {
/*     */ 
/*     */       
/* 173 */       enableAncestorFormCustomOnsubmit();
/*     */ 
/*     */ 
/*     */       
/* 177 */       Map<Object, Object> formInputtransferselectIds = (Map)formAncestor.getParameters().get("inputtransferselectIds");
/*     */ 
/*     */       
/* 180 */       if (formInputtransferselectIds == null) {
/* 181 */         formInputtransferselectIds = new LinkedHashMap<>();
/*     */       }
/*     */ 
/*     */       
/* 185 */       String tmpId = (String)getParameters().get("id");
/* 186 */       String tmpHeaderKey = (String)getParameters().get("headerKey");
/* 187 */       if (tmpId != null && !formInputtransferselectIds.containsKey(tmpId)) {
/* 188 */         formInputtransferselectIds.put(tmpId, tmpHeaderKey);
/*     */       }
/*     */       
/* 191 */       formAncestor.getParameters().put("inputtransferselectIds", formInputtransferselectIds);
/*     */ 
/*     */     
/*     */     }
/* 195 */     else if (LOG.isWarnEnabled()) {
/* 196 */       LOG.warn("form enclosing inputtransferselect " + this + " not found, auto select upon form submit of inputtransferselect will not work");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSize() {
/* 202 */     return this.size;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the size of the select box")
/*     */   public void setSize(String size) {
/* 207 */     this.size = size;
/*     */   }
/*     */   
/*     */   public String getMultiple() {
/* 211 */     return this.multiple;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Determine whether or not multiple entries are shown")
/*     */   public void setMultiple(String multiple) {
/* 216 */     this.multiple = multiple;
/*     */   }
/*     */   
/*     */   public String getAllowRemoveAll() {
/* 220 */     return this.allowRemoveAll;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Determine whether the remove all button will display")
/*     */   public void setAllowRemoveAll(String allowRemoveAll) {
/* 225 */     this.allowRemoveAll = allowRemoveAll;
/*     */   }
/*     */   
/*     */   public String getAllowUpDown() {
/* 229 */     return this.allowUpDown;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Determine whether items in the list can be reordered")
/*     */   public void setAllowUpDown(String allowUpDown) {
/* 234 */     this.allowUpDown = allowUpDown;
/*     */   }
/*     */   
/*     */   public String getLeftTitle() {
/* 238 */     return this.leftTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the left hand title")
/*     */   public void setLeftTitle(String leftTitle) {
/* 243 */     this.leftTitle = leftTitle;
/*     */   }
/*     */   
/*     */   public String getRightTitle() {
/* 247 */     return this.rightTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the right hand title")
/*     */   public void setRightTitle(String rightTitle) {
/* 252 */     this.rightTitle = rightTitle;
/*     */   }
/*     */   
/*     */   public String getButtonCssClass() {
/* 256 */     return this.buttonCssClass;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the css class used for rendering buttons")
/*     */   public void setButtonCssClass(String buttonCssClass) {
/* 261 */     this.buttonCssClass = buttonCssClass;
/*     */   }
/*     */   
/*     */   public String getButtonCssStyle() {
/* 265 */     return this.buttonCssStyle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the css style used for rendering buttons")
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 270 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */   
/*     */   public String getAddLabel() {
/* 274 */     return this.addLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the label used for the add button")
/*     */   public void setAddLabel(String addLabel) {
/* 279 */     this.addLabel = addLabel;
/*     */   }
/*     */   
/*     */   public String getRemoveLabel() {
/* 283 */     return this.removeLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the label used for the remove button")
/*     */   public void setRemoveLabel(String removeLabel) {
/* 288 */     this.removeLabel = removeLabel;
/*     */   }
/*     */   
/*     */   public String getRemoveAllLabel() {
/* 292 */     return this.removeAllLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the label used for the remove all button")
/*     */   public void setRemoveAllLabel(String removeAllLabel) {
/* 297 */     this.removeAllLabel = removeAllLabel;
/*     */   }
/*     */   
/*     */   public String getUpLabel() {
/* 301 */     return this.upLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the label used for the up button")
/*     */   public void setUpLabel(String upLabel) {
/* 306 */     this.upLabel = upLabel;
/*     */   }
/*     */   
/*     */   public String getDownLabel() {
/* 310 */     return this.downLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the label used for the down button")
/*     */   public void setDownLabel(String downLabel) {
/* 315 */     this.downLabel = downLabel;
/*     */   }
/*     */   
/*     */   public String getHeaderKey() {
/* 319 */     return this.headerKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the header key of the select box")
/*     */   public void setHeaderKey(String headerKey) {
/* 324 */     this.headerKey = headerKey;
/*     */   }
/*     */   
/*     */   public String getHeaderValue() {
/* 328 */     return this.headerValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "the header value of the select box")
/*     */   public void setHeaderValue(String headerValue) {
/* 333 */     this.headerValue = headerValue;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\InputTransferSelect.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */