/*    */ package org.apache.struts2.interceptor.servlet;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.interceptor.PrincipalProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletPrincipalProxy
/*    */   implements PrincipalProxy
/*    */ {
/*    */   private HttpServletRequest request;
/*    */   
/*    */   public ServletPrincipalProxy(HttpServletRequest request) {
/* 38 */     this.request = request;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUserInRole(String role) {
/* 48 */     return this.request.isUserInRole(role);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Principal getUserPrincipal() {
/* 57 */     return this.request.getUserPrincipal();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRemoteUser() {
/* 66 */     return this.request.getRemoteUser();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isRequestSecure() {
/* 75 */     return this.request.isSecure();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\interceptor\servlet\ServletPrincipalProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */