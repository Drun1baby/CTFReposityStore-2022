/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*     */ import com.opensymphony.xwork2.config.ContainerProvider;
/*     */ import com.opensymphony.xwork2.config.FileManagerFactoryProvider;
/*     */ import com.opensymphony.xwork2.config.FileManagerProvider;
/*     */ import com.opensymphony.xwork2.config.ServletContextAwareConfigurationProvider;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorStackConfig;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.commons.lang3.LocaleUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.config.DefaultBeanSelectionProvider;
/*     */ import org.apache.struts2.config.DefaultPropertiesProvider;
/*     */ import org.apache.struts2.config.PropertiesConfigurationProvider;
/*     */ import org.apache.struts2.config.StrutsXmlConfigurationProvider;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequest;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ import org.apache.struts2.util.AttributeMap;
/*     */ import org.apache.struts2.util.ObjectFactoryDestroyable;
/*     */ import org.apache.struts2.util.fs.JBossFileManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dispatcher
/*     */ {
/*  81 */   private static final Logger LOG = LogManager.getLogger(Dispatcher.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String REQUEST_POST_METHOD = "POST";
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MULTIPART_FORM_DATA_REGEX = "^multipart/form-data(?:\\s*;\\s*boundary=[0-9a-zA-Z'()+_,\\-./:=?]{1,70})?(?:\\s*;\\s*charset=[a-zA-Z\\-0-9]{3,14})?";
/*     */ 
/*     */ 
/*     */   
/*  93 */   private static ThreadLocal<Dispatcher> instance = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private static List<DispatcherListener> dispatcherListeners = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean devMode;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableRequestAttributeValueStackLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String defaultEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String defaultLocale;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String multipartSaveDir;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String multipartHandlerName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean multipartSupportEnabled = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private Pattern multipartValidationPattern = Pattern.compile("^multipart/form-data(?:\\s*;\\s*boundary=[0-9a-zA-Z'()+_,\\-./:=?]{1,70})?(?:\\s*;\\s*charset=[a-zA-Z\\-0-9]{3,14})?");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_CONFIGURATION_PATHS = "struts-default.xml,struts-plugin.xml,struts.xml";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean paramsWorkaroundEnabled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DispatcherErrorHandler errorHandler;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConfigurationManager configurationManager;
/*     */ 
/*     */ 
/*     */   
/*     */   private ValueStackFactory valueStackFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServletContext servletContext;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> initParams;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Dispatcher getInstance() {
/* 180 */     return instance.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setInstance(Dispatcher instance) {
/* 189 */     Dispatcher.instance.set(instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDispatcherListener(DispatcherListener listener) {
/* 198 */     dispatcherListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeDispatcherListener(DispatcherListener listener) {
/* 207 */     dispatcherListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dispatcher(ServletContext servletContext, Map<String, String> initParams) {
/* 225 */     this.servletContext = servletContext;
/* 226 */     this.initParams = initParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode) {
/* 235 */     this.devMode = Boolean.parseBoolean(mode);
/*     */   }
/*     */   
/*     */   public boolean isDevMode() {
/* 239 */     return this.devMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(value = "struts.disableRequestAttributeValueStackLookup", required = false)
/*     */   public void setDisableRequestAttributeValueStackLookup(String disableRequestAttributeValueStackLookup) {
/* 248 */     this.disableRequestAttributeValueStackLookup = BooleanUtils.toBoolean(disableRequestAttributeValueStackLookup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(value = "struts.locale", required = false)
/*     */   public void setDefaultLocale(String val) {
/* 257 */     this.defaultLocale = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String val) {
/* 266 */     this.defaultEncoding = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.multipart.saveDir")
/*     */   public void setMultipartSaveDir(String val) {
/* 275 */     this.multipartSaveDir = val;
/*     */   }
/*     */   
/*     */   @Inject("struts.multipart.parser")
/*     */   public void setMultipartHandler(String val) {
/* 280 */     this.multipartHandlerName = val;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.multipart.enabled", required = false)
/*     */   public void setMultipartSupportEnabled(String multipartSupportEnabled) {
/* 285 */     this.multipartSupportEnabled = Boolean.parseBoolean(multipartSupportEnabled);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.multipart.validationRegex", required = false)
/*     */   public void setMultipartValidationRegex(String multipartValidationRegex) {
/* 290 */     this.multipartValidationPattern = Pattern.compile(multipartValidationRegex);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 295 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   
/*     */   @Inject("struts.handle.exception")
/*     */   public void setHandleException(String handleException) {
/* 300 */     this.handleException = Boolean.parseBoolean(handleException);
/*     */   }
/*     */   
/*     */   public boolean isHandleException() {
/* 304 */     return this.handleException;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setDispatcherErrorHandler(DispatcherErrorHandler errorHandler) {
/* 309 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 318 */     ObjectFactory objectFactory = (ObjectFactory)getContainer().getInstance(ObjectFactory.class);
/* 319 */     if (objectFactory == null) {
/* 320 */       LOG.warn("Object Factory is null, something is seriously wrong, no clean up will be performed");
/*     */     }
/* 322 */     if (objectFactory instanceof ObjectFactoryDestroyable) {
/*     */       try {
/* 324 */         ((ObjectFactoryDestroyable)objectFactory).destroy();
/*     */       }
/* 326 */       catch (Exception e) {
/*     */         
/* 328 */         LOG.error("Exception occurred while destroying ObjectFactory [{}]", objectFactory.toString(), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 333 */     instance.set(null);
/*     */ 
/*     */     
/* 336 */     if (!dispatcherListeners.isEmpty()) {
/* 337 */       for (DispatcherListener l : dispatcherListeners) {
/* 338 */         l.dispatcherDestroyed(this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 343 */     Set<Interceptor> interceptors = new HashSet<>();
/* 344 */     Collection<PackageConfig> packageConfigs = this.configurationManager.getConfiguration().getPackageConfigs().values();
/* 345 */     for (PackageConfig packageConfig : packageConfigs) {
/* 346 */       for (Object config : packageConfig.getAllInterceptorConfigs().values()) {
/* 347 */         if (config instanceof InterceptorStackConfig) {
/* 348 */           for (InterceptorMapping interceptorMapping : ((InterceptorStackConfig)config).getInterceptors()) {
/* 349 */             interceptors.add(interceptorMapping.getInterceptor());
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 354 */     for (Interceptor interceptor : interceptors) {
/* 355 */       interceptor.destroy();
/*     */     }
/*     */ 
/*     */     
/* 359 */     ContainerHolder.clear();
/*     */ 
/*     */     
/* 362 */     ActionContext.setContext(null);
/*     */ 
/*     */     
/* 365 */     this.configurationManager.destroyConfiguration();
/* 366 */     this.configurationManager = null;
/*     */   }
/*     */   
/*     */   private void init_FileManager() throws ClassNotFoundException {
/* 370 */     if (this.initParams.containsKey("struts.fileManager")) {
/* 371 */       String fileManagerClassName = this.initParams.get("struts.fileManager");
/* 372 */       Class<FileManager> fileManagerClass = (Class)Class.forName(fileManagerClassName);
/* 373 */       LOG.info("Custom FileManager specified: {}", fileManagerClassName);
/* 374 */       this.configurationManager.addContainerProvider((ContainerProvider)new FileManagerProvider(fileManagerClass, fileManagerClass.getSimpleName()));
/*     */     } else {
/*     */       
/* 377 */       this.configurationManager.addContainerProvider((ContainerProvider)new FileManagerProvider(JBossFileManager.class, "jboss"));
/*     */     } 
/* 379 */     if (this.initParams.containsKey("struts.fileManagerFactory")) {
/* 380 */       String fileManagerFactoryClassName = this.initParams.get("struts.fileManagerFactory");
/* 381 */       Class<FileManagerFactory> fileManagerFactoryClass = (Class)Class.forName(fileManagerFactoryClassName);
/* 382 */       LOG.info("Custom FileManagerFactory specified: {}", fileManagerFactoryClassName);
/* 383 */       this.configurationManager.addContainerProvider((ContainerProvider)new FileManagerFactoryProvider(fileManagerFactoryClass));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void init_DefaultProperties() {
/* 388 */     this.configurationManager.addContainerProvider((ContainerProvider)new DefaultPropertiesProvider());
/*     */   }
/*     */   
/*     */   private void init_LegacyStrutsProperties() {
/* 392 */     this.configurationManager.addContainerProvider((ContainerProvider)new PropertiesConfigurationProvider());
/*     */   }
/*     */   
/*     */   private void init_TraditionalXmlConfigurations() {
/* 396 */     String configPaths = this.initParams.get("config");
/* 397 */     if (configPaths == null) {
/* 398 */       configPaths = "struts-default.xml,struts-plugin.xml,struts.xml";
/*     */     }
/* 400 */     String[] files = configPaths.split("\\s*[,]\\s*");
/* 401 */     for (String file : files) {
/* 402 */       if (file.endsWith(".xml")) {
/* 403 */         this.configurationManager.addContainerProvider((ContainerProvider)createStrutsXmlConfigurationProvider(file, false, this.servletContext));
/*     */       } else {
/* 405 */         throw new IllegalArgumentException("Invalid configuration file name");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected XmlConfigurationProvider createStrutsXmlConfigurationProvider(String filename, boolean errorIfMissing, ServletContext ctx) {
/* 411 */     return (XmlConfigurationProvider)new StrutsXmlConfigurationProvider(filename, errorIfMissing, ctx);
/*     */   }
/*     */   
/*     */   private void init_CustomConfigurationProviders() {
/* 415 */     String configProvs = this.initParams.get("configProviders");
/* 416 */     if (configProvs != null) {
/* 417 */       String[] classes = configProvs.split("\\s*[,]\\s*");
/* 418 */       for (String cname : classes) {
/*     */         try {
/* 420 */           Class<ConfigurationProvider> cls = ClassLoaderUtil.loadClass(cname, getClass());
/* 421 */           ConfigurationProvider prov = cls.newInstance();
/* 422 */           if (prov instanceof ServletContextAwareConfigurationProvider) {
/* 423 */             ((ServletContextAwareConfigurationProvider)prov).initWithContext(this.servletContext);
/*     */           }
/* 425 */           this.configurationManager.addContainerProvider((ContainerProvider)prov);
/* 426 */         } catch (InstantiationException e) {
/* 427 */           throw new ConfigurationException("Unable to instantiate provider: " + cname, e);
/* 428 */         } catch (IllegalAccessException e) {
/* 429 */           throw new ConfigurationException("Unable to access provider: " + cname, e);
/* 430 */         } catch (ClassNotFoundException e) {
/* 431 */           throw new ConfigurationException("Unable to locate provider class: " + cname, e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void init_FilterInitParameters() {
/* 438 */     this.configurationManager.addContainerProvider((ContainerProvider)new ConfigurationProvider()
/*     */         {
/*     */           public void destroy() {}
/*     */ 
/*     */           
/*     */           public void init(Configuration configuration) throws ConfigurationException {}
/*     */ 
/*     */           
/*     */           public void loadPackages() throws ConfigurationException {}
/*     */           
/*     */           public boolean needsReload() {
/* 449 */             return false;
/*     */           }
/*     */           
/*     */           public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 453 */             props.putAll(Dispatcher.this.initParams);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void init_AliasStandardObjects() {
/* 459 */     this.configurationManager.addContainerProvider((ContainerProvider)new DefaultBeanSelectionProvider());
/*     */   }
/*     */   
/*     */   private Container init_PreloadConfiguration() {
/* 463 */     return getContainer();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init_CheckWebLogicWorkaround(Container container) {
/* 468 */     if (this.servletContext != null && StringUtils.contains(this.servletContext.getServerInfo(), "WebLogic")) {
/* 469 */       LOG.info("WebLogic server detected. Enabling Struts parameter access work-around.");
/* 470 */       this.paramsWorkaroundEnabled = true;
/*     */     } else {
/* 472 */       this.paramsWorkaroundEnabled = "true".equals(container.getInstance(String.class, "struts.dispatcher.parametersWorkaround"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 483 */     if (this.configurationManager == null) {
/* 484 */       this.configurationManager = createConfigurationManager("default");
/*     */     }
/*     */     
/*     */     try {
/* 488 */       init_FileManager();
/* 489 */       init_DefaultProperties();
/* 490 */       init_TraditionalXmlConfigurations();
/* 491 */       init_LegacyStrutsProperties();
/* 492 */       init_CustomConfigurationProviders();
/* 493 */       init_FilterInitParameters();
/* 494 */       init_AliasStandardObjects();
/*     */       
/* 496 */       Container container = init_PreloadConfiguration();
/* 497 */       container.inject(this);
/* 498 */       init_CheckWebLogicWorkaround(container);
/*     */       
/* 500 */       if (!dispatcherListeners.isEmpty()) {
/* 501 */         for (DispatcherListener l : dispatcherListeners) {
/* 502 */           l.dispatcherInitialized(this);
/*     */         }
/*     */       }
/* 505 */       this.errorHandler.init(this.servletContext);
/*     */     }
/* 507 */     catch (Exception ex) {
/* 508 */       LOG.error("Dispatcher initialization failed", ex);
/* 509 */       throw new StrutsException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ConfigurationManager createConfigurationManager(String name) {
/* 514 */     return new ConfigurationManager(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serviceAction(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) throws ServletException {
/* 542 */     Map<String, Object> extraContext = createContextMap(request, response, mapping);
/*     */ 
/*     */     
/* 545 */     ValueStack stack = (ValueStack)request.getAttribute("struts.valueStack");
/* 546 */     boolean nullStack = (stack == null);
/* 547 */     if (nullStack) {
/* 548 */       ActionContext ctx = ActionContext.getContext();
/* 549 */       if (ctx != null) {
/* 550 */         stack = ctx.getValueStack();
/*     */       }
/*     */     } 
/* 553 */     if (stack != null) {
/* 554 */       extraContext.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", this.valueStackFactory.createValueStack(stack));
/*     */     }
/*     */     
/* 557 */     String timerKey = "Handling request from Dispatcher";
/*     */     try {
/* 559 */       UtilTimerStack.push(timerKey);
/* 560 */       String namespace = mapping.getNamespace();
/* 561 */       String name = mapping.getName();
/* 562 */       String method = mapping.getMethod();
/*     */       
/* 564 */       ActionProxy proxy = ((ActionProxyFactory)getContainer().getInstance(ActionProxyFactory.class)).createActionProxy(namespace, name, method, extraContext, true, false);
/*     */ 
/*     */       
/* 567 */       request.setAttribute("struts.valueStack", proxy.getInvocation().getStack());
/*     */ 
/*     */       
/* 570 */       if (mapping.getResult() != null) {
/* 571 */         Result result = mapping.getResult();
/* 572 */         result.execute(proxy.getInvocation());
/*     */       } else {
/* 574 */         proxy.execute();
/*     */       } 
/*     */ 
/*     */       
/* 578 */       if (!nullStack) {
/* 579 */         request.setAttribute("struts.valueStack", stack);
/*     */       }
/* 581 */     } catch (ConfigurationException e) {
/* 582 */       logConfigurationException(request, e);
/* 583 */       sendError(request, response, 404, (Exception)e);
/* 584 */     } catch (Exception e) {
/* 585 */       if (this.handleException || this.devMode) {
/* 586 */         if (this.devMode) {
/* 587 */           LOG.debug("Dispatcher serviceAction failed", e);
/*     */         }
/* 589 */         sendError(request, response, 500, e);
/*     */       } else {
/* 591 */         throw new ServletException(e);
/*     */       } 
/*     */     } finally {
/* 594 */       UtilTimerStack.pop(timerKey);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logConfigurationException(HttpServletRequest request, ConfigurationException e) {
/* 606 */     String uri = request.getRequestURI();
/* 607 */     if (request.getQueryString() != null) {
/* 608 */       uri = uri + "?" + request.getQueryString();
/*     */     }
/* 610 */     if (this.devMode) {
/* 611 */       LOG.error("Could not find action or result: {}", uri, e);
/* 612 */     } else if (LOG.isWarnEnabled()) {
/* 613 */       LOG.warn("Could not find action or result: {}", uri, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> createContextMap(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
/* 631 */     Map requestMap = new RequestMap(request);
/*     */ 
/*     */     
/* 634 */     HttpParameters params = HttpParameters.create(request.getParameterMap()).build();
/*     */ 
/*     */     
/* 637 */     Map<Object, Object> session = new SessionMap<>(request);
/*     */ 
/*     */     
/* 640 */     Map application = new ApplicationMap(this.servletContext);
/*     */     
/* 642 */     Map<String, Object> extraContext = createContextMap(requestMap, params, session, application, request, response);
/*     */     
/* 644 */     if (mapping != null) {
/* 645 */       extraContext.put("struts.actionMapping", mapping);
/*     */     }
/* 647 */     return extraContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<String, Object> createContextMap(Map requestMap, HttpParameters parameters, Map sessionMap, Map applicationMap, HttpServletRequest request, HttpServletResponse response) {
/* 670 */     HashMap<String, Object> extraContext = new HashMap<>();
/* 671 */     extraContext.put("com.opensymphony.xwork2.ActionContext.parameters", parameters);
/* 672 */     extraContext.put("com.opensymphony.xwork2.ActionContext.session", sessionMap);
/* 673 */     extraContext.put("com.opensymphony.xwork2.ActionContext.application", applicationMap);
/*     */     
/* 675 */     extraContext.put("com.opensymphony.xwork2.ActionContext.locale", getLocale(request));
/*     */     
/* 677 */     extraContext.put("com.opensymphony.xwork2.dispatcher.HttpServletRequest", request);
/* 678 */     extraContext.put("com.opensymphony.xwork2.dispatcher.HttpServletResponse", response);
/* 679 */     extraContext.put("com.opensymphony.xwork2.dispatcher.ServletContext", this.servletContext);
/*     */ 
/*     */     
/* 682 */     extraContext.put("request", requestMap);
/* 683 */     extraContext.put("session", sessionMap);
/* 684 */     extraContext.put("application", applicationMap);
/* 685 */     extraContext.put("parameters", parameters);
/*     */     
/* 687 */     AttributeMap attrMap = new AttributeMap(extraContext);
/* 688 */     extraContext.put("attr", attrMap);
/*     */     
/* 690 */     return extraContext;
/*     */   }
/*     */   
/*     */   protected Locale getLocale(HttpServletRequest request) {
/*     */     Locale locale;
/* 695 */     if (this.defaultLocale != null) {
/*     */       try {
/* 697 */         locale = LocaleUtils.toLocale(this.defaultLocale);
/* 698 */       } catch (IllegalArgumentException e) {
/*     */         try {
/* 700 */           locale = request.getLocale();
/* 701 */           LOG.warn((Message)new ParameterizedMessage("Cannot convert 'struts.locale' = [{}] to proper locale, defaulting to request locale [{}]", this.defaultLocale, locale), e);
/*     */         }
/* 703 */         catch (RuntimeException rex) {
/* 704 */           LOG.warn((Message)new ParameterizedMessage("Cannot convert 'struts.locale' = [{}] to proper locale, and cannot get locale from HTTP Request, falling back to system default locale", this.defaultLocale), rex);
/*     */           
/* 706 */           locale = Locale.getDefault();
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       try {
/* 711 */         locale = request.getLocale();
/* 712 */       } catch (RuntimeException rex) {
/* 713 */         LOG.warn("Cannot get locale from HTTP Request, falling back to system default locale", rex);
/* 714 */         locale = Locale.getDefault();
/*     */       } 
/*     */     } 
/* 717 */     return locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSaveDir() {
/* 726 */     String saveDir = this.multipartSaveDir.trim();
/*     */     
/* 728 */     if (saveDir.equals("")) {
/* 729 */       File tempdir = (File)this.servletContext.getAttribute("javax.servlet.context.tempdir");
/* 730 */       LOG.info("Unable to find 'struts.multipart.saveDir' property setting. Defaulting to javax.servlet.context.tempdir");
/*     */       
/* 732 */       if (tempdir != null) {
/* 733 */         saveDir = tempdir.toString();
/* 734 */         setMultipartSaveDir(saveDir);
/*     */       } 
/*     */     } else {
/* 737 */       File multipartSaveDir = new File(saveDir);
/*     */       
/* 739 */       if (!multipartSaveDir.exists() && 
/* 740 */         !multipartSaveDir.mkdirs()) {
/*     */         String logMessage;
/*     */         try {
/* 743 */           logMessage = "Could not find create multipart save directory '" + multipartSaveDir.getCanonicalPath() + "'.";
/* 744 */         } catch (IOException e) {
/* 745 */           logMessage = "Could not find create multipart save directory '" + multipartSaveDir.toString() + "'.";
/*     */         } 
/* 747 */         if (this.devMode) {
/* 748 */           LOG.error(logMessage);
/*     */         } else {
/* 750 */           LOG.warn(logMessage);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 756 */     LOG.debug("saveDir={}", saveDir);
/*     */     
/* 758 */     return saveDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepare(HttpServletRequest request, HttpServletResponse response) {
/* 768 */     String encoding = null;
/* 769 */     if (this.defaultEncoding != null) {
/* 770 */       encoding = this.defaultEncoding;
/*     */     }
/*     */     
/* 773 */     if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
/* 774 */       encoding = "UTF-8";
/*     */     }
/*     */     
/* 777 */     Locale locale = getLocale(request);
/*     */     
/* 779 */     if (encoding != null) {
/* 780 */       applyEncoding(request, encoding);
/*     */     }
/*     */     
/* 783 */     if (locale != null) {
/* 784 */       response.setLocale(locale);
/*     */     }
/*     */     
/* 787 */     if (this.paramsWorkaroundEnabled) {
/* 788 */       request.getParameter("foo");
/*     */     }
/*     */   }
/*     */   
/*     */   private void applyEncoding(HttpServletRequest request, String encoding) {
/*     */     try {
/* 794 */       if (!encoding.equals(request.getCharacterEncoding()))
/*     */       {
/*     */         
/* 797 */         request.setCharacterEncoding(encoding);
/*     */       }
/* 799 */     } catch (Exception e) {
/* 800 */       LOG.error("Error setting character encoding to '{}' - ignoring.", encoding, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletRequest wrapRequest(HttpServletRequest request) throws IOException {
/*     */     MultiPartRequestWrapper multiPartRequestWrapper;
/*     */     StrutsRequestWrapper strutsRequestWrapper;
/* 825 */     if (request instanceof StrutsRequestWrapper) {
/* 826 */       return request;
/*     */     }
/*     */     
/* 829 */     if (isMultipartSupportEnabled(request) && isMultipartRequest(request)) {
/* 830 */       MultiPartRequest multiPartRequest = getMultiPartRequest();
/* 831 */       LocaleProviderFactory localeProviderFactory = (LocaleProviderFactory)getContainer().getInstance(LocaleProviderFactory.class);
/*     */       
/* 833 */       multiPartRequestWrapper = new MultiPartRequestWrapper(multiPartRequest, request, getSaveDir(), localeProviderFactory.createLocaleProvider(), this.disableRequestAttributeValueStackLookup);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 841 */       strutsRequestWrapper = new StrutsRequestWrapper((HttpServletRequest)multiPartRequestWrapper, this.disableRequestAttributeValueStackLookup);
/*     */     } 
/*     */     
/* 844 */     return (HttpServletRequest)strutsRequestWrapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMultipartSupportEnabled(HttpServletRequest request) {
/* 856 */     return this.multipartSupportEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMultipartRequest(HttpServletRequest request) {
/* 868 */     String httpMethod = request.getMethod();
/* 869 */     String contentType = request.getContentType();
/*     */     
/* 871 */     return ("POST".equalsIgnoreCase(httpMethod) && contentType != null && this.multipartValidationPattern.matcher(contentType.toLowerCase(Locale.ENGLISH)).matches());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultiPartRequest getMultiPartRequest() {
/* 883 */     MultiPartRequest mpr = null;
/*     */     
/* 885 */     Set<String> multiNames = getContainer().getInstanceNames(MultiPartRequest.class);
/* 886 */     for (String multiName : multiNames) {
/* 887 */       if (multiName.equals(this.multipartHandlerName)) {
/* 888 */         mpr = (MultiPartRequest)getContainer().getInstance(MultiPartRequest.class, multiName);
/*     */       }
/*     */     } 
/* 891 */     if (mpr == null) {
/* 892 */       mpr = (MultiPartRequest)getContainer().getInstance(MultiPartRequest.class);
/*     */     }
/* 894 */     return mpr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpRequest(HttpServletRequest request) {
/* 904 */     ContainerHolder.clear();
/* 905 */     if (!(request instanceof MultiPartRequestWrapper)) {
/*     */       return;
/*     */     }
/* 908 */     MultiPartRequestWrapper multiWrapper = (MultiPartRequestWrapper)request;
/* 909 */     multiWrapper.cleanUp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendError(HttpServletRequest request, HttpServletResponse response, int code, Exception e) {
/* 923 */     this.errorHandler.handleError(request, response, code, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpAfterInit() {
/* 930 */     if (LOG.isDebugEnabled()) {
/* 931 */       LOG.debug("Cleaning up resources used to init Dispatcher");
/*     */     }
/* 933 */     ContainerHolder.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Locator
/*     */   {
/*     */     public Location getLocation(Object obj) {
/* 941 */       Location loc = LocationUtils.getLocation(obj);
/* 942 */       if (loc == null) {
/* 943 */         return Location.UNKNOWN;
/*     */       }
/* 945 */       return loc;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigurationManager getConfigurationManager() {
/* 955 */     return this.configurationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/* 963 */     if (ContainerHolder.get() != null) {
/* 964 */       return ContainerHolder.get();
/*     */     }
/* 966 */     ConfigurationManager mgr = getConfigurationManager();
/* 967 */     if (mgr == null) {
/* 968 */       throw new IllegalStateException("The configuration manager shouldn't be null");
/*     */     }
/* 970 */     Configuration config = mgr.getConfiguration();
/* 971 */     if (config == null) {
/* 972 */       throw new IllegalStateException("Unable to load configuration");
/*     */     }
/* 974 */     Container container = config.getContainer();
/* 975 */     ContainerHolder.store(container);
/* 976 */     return container;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\Dispatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */