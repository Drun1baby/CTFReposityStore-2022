/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalizedMessage
/*    */ {
/*    */   private final Class clazz;
/*    */   private final String textKey;
/*    */   private final String defaultMessage;
/*    */   private final Object[] args;
/*    */   
/*    */   public LocalizedMessage(Class clazz, String textKey, String defaultMessage, Object[] args) {
/* 30 */     this.clazz = clazz;
/* 31 */     this.textKey = textKey;
/* 32 */     this.defaultMessage = defaultMessage;
/* 33 */     this.args = args;
/*    */   }
/*    */   
/*    */   public Class getClazz() {
/* 37 */     return this.clazz;
/*    */   }
/*    */   
/*    */   public String getTextKey() {
/* 41 */     return this.textKey;
/*    */   }
/*    */   
/*    */   public String getDefaultMessage() {
/* 45 */     return this.defaultMessage;
/*    */   }
/*    */   
/*    */   public Object[] getArgs() {
/* 49 */     return this.args;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     int prime = 31;
/* 55 */     int result = 1;
/* 56 */     result = 31 * result + Arrays.hashCode(this.args);
/* 57 */     result = 31 * result + ((this.clazz == null) ? 0 : this.clazz.hashCode());
/* 58 */     result = 31 * result + ((this.defaultMessage == null) ? 0 : this.defaultMessage.hashCode());
/* 59 */     result = 31 * result + ((this.textKey == null) ? 0 : this.textKey.hashCode());
/* 60 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 65 */     if (this == obj) {
/* 66 */       return true;
/*    */     }
/* 68 */     if (obj == null) {
/* 69 */       return false;
/*    */     }
/* 71 */     if (getClass() != obj.getClass()) {
/* 72 */       return false;
/*    */     }
/* 74 */     LocalizedMessage other = (LocalizedMessage)obj;
/* 75 */     if (!Arrays.equals(this.args, other.args)) {
/* 76 */       return false;
/*    */     }
/* 78 */     if (this.clazz == null) {
/* 79 */       if (other.clazz != null) {
/* 80 */         return false;
/*    */       }
/* 82 */     } else if (!this.clazz.equals(other.clazz)) {
/* 83 */       return false;
/*    */     } 
/* 85 */     if (this.defaultMessage == null) {
/* 86 */       if (other.defaultMessage != null) {
/* 87 */         return false;
/*    */       }
/* 89 */     } else if (!this.defaultMessage.equals(other.defaultMessage)) {
/* 90 */       return false;
/*    */     } 
/* 92 */     if (this.textKey == null) {
/* 93 */       if (other.textKey != null) {
/* 94 */         return false;
/*    */       }
/* 96 */     } else if (!this.textKey.equals(other.textKey)) {
/* 97 */       return false;
/*    */     } 
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\LocalizedMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */