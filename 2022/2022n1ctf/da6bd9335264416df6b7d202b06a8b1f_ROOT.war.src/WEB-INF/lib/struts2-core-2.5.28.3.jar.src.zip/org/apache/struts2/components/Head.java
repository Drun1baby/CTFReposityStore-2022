/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "head", tldBodyContent = "empty", tldTagClass = "org.apache.struts2.views.jsp.ui.HeadTag", description = "Render a chunk of HEAD for your HTML file", allowDynamicAttributes = true)
/*    */ public class Head
/*    */   extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "head";
/*    */   private String encoding;
/*    */   
/*    */   public Head(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 58 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 62 */     return "head";
/*    */   }
/*    */   
/*    */   @Inject("struts.i18n.encoding")
/*    */   public void setEncoding(String encoding) {
/* 67 */     this.encoding = encoding;
/*    */   }
/*    */   
/*    */   public void evaluateParams() {
/* 71 */     super.evaluateParams();
/*    */     
/* 73 */     addParameter("encoding", this.encoding);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Head.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */