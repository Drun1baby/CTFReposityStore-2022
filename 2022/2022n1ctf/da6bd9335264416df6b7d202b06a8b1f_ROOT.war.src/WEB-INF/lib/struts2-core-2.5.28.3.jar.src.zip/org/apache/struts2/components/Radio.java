/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "radio", tldTagClass = "org.apache.struts2.views.jsp.ui.RadioTag", description = "Renders a radio button input field", allowDynamicAttributes = true)
/*    */ public class Radio
/*    */   extends ListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "radiomap";
/*    */   
/*    */   public Radio(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 62 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 66 */     return "radiomap";
/*    */   }
/*    */   
/*    */   public void evaluateExtraParams() {
/* 70 */     super.evaluateExtraParams();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Radio.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */