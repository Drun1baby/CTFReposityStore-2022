/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Template
/*     */   implements Cloneable
/*     */ {
/*     */   String dir;
/*     */   String theme;
/*     */   String name;
/*     */   
/*     */   public Template(String dir, String theme, String name) {
/*  43 */     this.dir = dir;
/*  44 */     this.theme = theme;
/*  45 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getDir() {
/*  49 */     return this.dir;
/*     */   }
/*     */   
/*     */   public String getTheme() {
/*  53 */     return this.theme;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  57 */     return this.name;
/*     */   }
/*     */   
/*     */   public List<Template> getPossibleTemplates(TemplateEngine engine) {
/*  61 */     List<Template> list = new ArrayList<>(3);
/*  62 */     Template template = this;
/*     */     
/*  64 */     list.add(template); String parentTheme;
/*  65 */     while ((parentTheme = (String)engine.getThemeProps(template).get("parent")) != null) {
/*     */       try {
/*  67 */         template = (Template)template.clone();
/*  68 */         template.theme = parentTheme;
/*  69 */         list.add(template);
/*  70 */       } catch (CloneNotSupportedException cloneNotSupportedException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  75 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  83 */     return "/" + this.dir + "/" + this.theme + "/" + this.name;
/*     */   }
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  87 */     return super.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  92 */     if (this == o) return true; 
/*  93 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/*  95 */     Template template = (Template)o;
/*     */     
/*  97 */     if ((this.dir != null) ? !this.dir.equals(template.dir) : (template.dir != null)) return false; 
/*  98 */     if ((this.name != null) ? !this.name.equals(template.name) : (template.name != null)) return false; 
/*  99 */     if ((this.theme != null) ? !this.theme.equals(template.theme) : (template.theme != null)) return false;
/*     */     
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     int result = (this.dir != null) ? this.dir.hashCode() : 0;
/* 107 */     result = 31 * result + ((this.theme != null) ? this.theme.hashCode() : 0);
/* 108 */     result = 31 * result + ((this.name != null) ? this.name.hashCode() : 0);
/* 109 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\Template.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */