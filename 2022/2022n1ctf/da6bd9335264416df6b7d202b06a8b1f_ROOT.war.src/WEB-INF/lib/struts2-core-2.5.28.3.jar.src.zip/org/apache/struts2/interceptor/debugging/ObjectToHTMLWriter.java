/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ObjectToHTMLWriter
/*     */ {
/*     */   private PrettyPrintWriter prettyWriter;
/*     */   
/*     */   ObjectToHTMLWriter(Writer writer) {
/*  39 */     this.prettyWriter = new PrettyPrintWriter(writer);
/*  40 */     this.prettyWriter.setEscape(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ReflectionProvider reflectionProvider, Object root, String expr) throws IntrospectionException, ReflectionException {
/*  46 */     this.prettyWriter.startNode("table");
/*  47 */     this.prettyWriter.addAttribute("class", "debugTable");
/*     */     
/*  49 */     if (root instanceof Map) {
/*  50 */       for (Object next : ((Map)root).entrySet()) {
/*  51 */         Map.Entry property = (Map.Entry)next;
/*  52 */         String key = property.getKey().toString();
/*  53 */         Object value = property.getValue();
/*  54 */         writeProperty(key, value, expr);
/*     */       } 
/*  56 */     } else if (root instanceof List) {
/*  57 */       List list = (List)root;
/*  58 */       for (int i = 0; i < list.size(); i++) {
/*  59 */         Object element = list.get(i);
/*  60 */         writeProperty(String.valueOf(i), element, expr);
/*     */       } 
/*  62 */     } else if (root instanceof Set) {
/*  63 */       Set set = (Set)root;
/*  64 */       for (Object next : set) {
/*  65 */         writeProperty("", next, expr);
/*     */       }
/*  67 */     } else if (root.getClass().isArray()) {
/*  68 */       Object[] objects = (Object[])root;
/*  69 */       for (int i = 0; i < objects.length; i++) {
/*  70 */         writeProperty(String.valueOf(i), objects[i], expr);
/*     */       }
/*     */     } else {
/*     */       
/*  74 */       Map<String, Object> properties = reflectionProvider.getBeanMap(root);
/*  75 */       for (Map.Entry<String, Object> property : properties.entrySet()) {
/*  76 */         String name = property.getKey();
/*  77 */         Object value = property.getValue();
/*     */         
/*  79 */         if ("class".equals(name)) {
/*     */           continue;
/*     */         }
/*     */         
/*  83 */         writeProperty(name, value, expr);
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     this.prettyWriter.endNode();
/*     */   }
/*     */   
/*     */   private void writeProperty(String name, Object value, String expr) {
/*  91 */     this.prettyWriter.startNode("tr");
/*     */ 
/*     */     
/*  94 */     this.prettyWriter.startNode("td");
/*  95 */     this.prettyWriter.addAttribute("class", "nameColumn");
/*  96 */     this.prettyWriter.setValue(name);
/*  97 */     this.prettyWriter.endNode();
/*     */ 
/*     */     
/* 100 */     this.prettyWriter.startNode("td");
/* 101 */     if (value != null) {
/*     */       
/* 103 */       if (isEmptyCollection(value) || isEmptyMap(value) || (value.getClass().isArray() && ((Object[])value).length == 0)) {
/*     */         
/* 105 */         this.prettyWriter.addAttribute("class", "emptyCollection");
/* 106 */         this.prettyWriter.setValue("empty");
/*     */       } else {
/* 108 */         this.prettyWriter.addAttribute("class", "valueColumn");
/* 109 */         writeValue(name, value, expr);
/*     */       } 
/*     */     } else {
/* 112 */       this.prettyWriter.addAttribute("class", "nullValue");
/* 113 */       this.prettyWriter.setValue("null");
/*     */     } 
/* 115 */     this.prettyWriter.endNode();
/*     */ 
/*     */     
/* 118 */     this.prettyWriter.startNode("td");
/* 119 */     if (value != null) {
/* 120 */       this.prettyWriter.addAttribute("class", "typeColumn");
/* 121 */       Class<?> clazz = value.getClass();
/* 122 */       this.prettyWriter.setValue(clazz.getName());
/*     */     } else {
/* 124 */       this.prettyWriter.addAttribute("class", "nullValue");
/* 125 */       this.prettyWriter.setValue("unknown");
/*     */     } 
/* 127 */     this.prettyWriter.endNode();
/*     */ 
/*     */     
/* 130 */     this.prettyWriter.endNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEmptyMap(Object value) {
/*     */     try {
/* 138 */       return (value instanceof Map && ((Map)value).isEmpty());
/* 139 */     } catch (Exception e) {
/* 140 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEmptyCollection(Object value) {
/*     */     try {
/* 149 */       return (value instanceof Collection && ((Collection)value).isEmpty());
/* 150 */     } catch (Exception e) {
/* 151 */       return true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeValue(String name, Object value, String expr) {
/* 156 */     Class<?> clazz = value.getClass();
/* 157 */     if (clazz.isPrimitive() || Number.class.isAssignableFrom(clazz) || clazz.equals(String.class) || Boolean.class.equals(clazz)) {
/*     */       
/* 159 */       this.prettyWriter.setValue(String.valueOf(value));
/*     */     } else {
/* 161 */       this.prettyWriter.startNode("a");
/* 162 */       String path = expr.replaceAll("#", "%23") + "[\"" + name.replaceAll("#", "%23") + "\"]";
/*     */       
/* 164 */       this.prettyWriter.addAttribute("onclick", "expand(this, '" + path + "')");
/* 165 */       this.prettyWriter.addAttribute("href", "javascript://nop/");
/* 166 */       this.prettyWriter.setValue("Expand");
/* 167 */       this.prettyWriter.endNode();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\interceptor\debugging\ObjectToHTMLWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */