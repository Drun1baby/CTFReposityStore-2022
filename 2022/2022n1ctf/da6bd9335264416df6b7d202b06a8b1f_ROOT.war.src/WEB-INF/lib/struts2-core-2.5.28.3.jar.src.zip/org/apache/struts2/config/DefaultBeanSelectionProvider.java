/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.LocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.UnknownHandlerManager;
/*     */ import com.opensymphony.xwork2.conversion.ConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionFileProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionPropertiesProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import com.opensymphony.xwork2.conversion.impl.ArrayConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.CollectionConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.DateConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.NumberConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.StringConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.factory.ActionFactory;
/*     */ import com.opensymphony.xwork2.factory.ConverterFactory;
/*     */ import com.opensymphony.xwork2.factory.InterceptorFactory;
/*     */ import com.opensymphony.xwork2.factory.ResultFactory;
/*     */ import com.opensymphony.xwork2.factory.UnknownHandlerFactory;
/*     */ import com.opensymphony.xwork2.factory.ValidatorFactory;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.security.AcceptedPatternsChecker;
/*     */ import com.opensymphony.xwork2.security.ExcludedPatternsChecker;
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import com.opensymphony.xwork2.util.TextParser;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import com.opensymphony.xwork2.validator.ActionValidatorManager;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.components.UrlRenderer;
/*     */ import org.apache.struts2.dispatcher.DispatcherErrorHandler;
/*     */ import org.apache.struts2.dispatcher.StaticContentLoader;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequest;
/*     */ import org.apache.struts2.util.ContentTypeMatcher;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ import org.apache.struts2.views.velocity.VelocityManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultBeanSelectionProvider
/*     */   extends AbstractBeanSelectionProvider
/*     */ {
/* 371 */   private static final Logger LOG = LogManager.getLogger(DefaultBeanSelectionProvider.class);
/*     */   
/*     */   public void register(ContainerBuilder builder, LocatableProperties props) {
/* 374 */     alias(ObjectFactory.class, "struts.objectFactory", builder, (Properties)props);
/* 375 */     alias(ActionFactory.class, "struts.objectFactory.actionFactory", builder, (Properties)props);
/* 376 */     alias(ResultFactory.class, "struts.objectFactory.resultFactory", builder, (Properties)props);
/* 377 */     alias(ConverterFactory.class, "struts.objectFactory.converterFactory", builder, (Properties)props);
/* 378 */     alias(InterceptorFactory.class, "struts.objectFactory.interceptorFactory", builder, (Properties)props);
/* 379 */     alias(ValidatorFactory.class, "struts.objectFactory.validatorFactory", builder, (Properties)props);
/* 380 */     alias(UnknownHandlerFactory.class, "struts.objectFactory.unknownHandlerFactory", builder, (Properties)props);
/*     */     
/* 382 */     alias(FileManagerFactory.class, "struts.fileManagerFactory", builder, (Properties)props, Scope.SINGLETON);
/*     */     
/* 384 */     alias(XWorkConverter.class, "struts.xworkConverter", builder, (Properties)props);
/* 385 */     alias(CollectionConverter.class, "struts.converter.collection", builder, (Properties)props);
/* 386 */     alias(ArrayConverter.class, "struts.converter.array", builder, (Properties)props);
/* 387 */     alias(DateConverter.class, "struts.converter.date", builder, (Properties)props);
/* 388 */     alias(NumberConverter.class, "struts.converter.number", builder, (Properties)props);
/* 389 */     alias(StringConverter.class, "struts.converter.string", builder, (Properties)props);
/*     */     
/* 391 */     alias(ConversionPropertiesProcessor.class, "struts.converter.properties.processor", builder, (Properties)props);
/* 392 */     alias(ConversionFileProcessor.class, "struts.converter.file.processor", builder, (Properties)props);
/* 393 */     alias(ConversionAnnotationProcessor.class, "struts.converter.annotation.processor", builder, (Properties)props);
/* 394 */     alias(TypeConverterCreator.class, "struts.converter.creator", builder, (Properties)props);
/* 395 */     alias(TypeConverterHolder.class, "struts..converter.holder", builder, (Properties)props);
/*     */     
/* 397 */     alias(TextProvider.class, "struts.xworkTextProvider", builder, (Properties)props, Scope.PROTOTYPE);
/* 398 */     alias(TextProvider.class, "struts.textProvider", builder, (Properties)props, Scope.PROTOTYPE);
/* 399 */     alias(TextProviderFactory.class, "struts.textProviderFactory", builder, (Properties)props, Scope.PROTOTYPE);
/* 400 */     alias(LocaleProviderFactory.class, "struts.localeProviderFactory", builder, (Properties)props);
/* 401 */     alias(LocalizedTextProvider.class, "struts.localizedTextProvider", builder, (Properties)props);
/*     */     
/* 403 */     alias(ActionProxyFactory.class, "struts.actionProxyFactory", builder, (Properties)props);
/* 404 */     alias(ObjectTypeDeterminer.class, "struts.objectTypeDeterminer", builder, (Properties)props);
/* 405 */     alias(ActionMapper.class, "struts.mapper.class", builder, (Properties)props);
/* 406 */     alias(MultiPartRequest.class, "struts.multipart.parser", builder, (Properties)props, Scope.PROTOTYPE);
/* 407 */     alias(FreemarkerManager.class, "struts.freemarker.manager.classname", builder, (Properties)props);
/* 408 */     alias(VelocityManager.class, "struts.velocity.manager.classname", builder, (Properties)props);
/* 409 */     alias(UrlRenderer.class, "struts.urlRenderer", builder, (Properties)props);
/* 410 */     alias(ActionValidatorManager.class, "struts.actionValidatorManager", builder, (Properties)props);
/* 411 */     alias(ValueStackFactory.class, "struts.valueStackFactory", builder, (Properties)props);
/* 412 */     alias(ReflectionProvider.class, "struts.reflectionProvider", builder, (Properties)props);
/* 413 */     alias(ReflectionContextFactory.class, "struts.reflectionContextFactory", builder, (Properties)props);
/* 414 */     alias(PatternMatcher.class, "struts.patternMatcher", builder, (Properties)props);
/* 415 */     alias(ContentTypeMatcher.class, "struts.contentTypeMatcher", builder, (Properties)props);
/* 416 */     alias(StaticContentLoader.class, "struts.staticContentLoader", builder, (Properties)props);
/* 417 */     alias(UnknownHandlerManager.class, "struts.unknownHandlerManager", builder, (Properties)props);
/* 418 */     alias(UrlHelper.class, "struts.view.urlHelper", builder, (Properties)props);
/*     */     
/* 420 */     alias(TextParser.class, "struts.expression.parser", builder, (Properties)props);
/*     */     
/* 422 */     alias(DispatcherErrorHandler.class, "struts.dispatcher.errorHandler", builder, (Properties)props);
/*     */ 
/*     */     
/* 425 */     alias(ExcludedPatternsChecker.class, "struts.excludedPatterns.checker", builder, (Properties)props, Scope.PROTOTYPE);
/* 426 */     alias(AcceptedPatternsChecker.class, "struts.acceptedPatterns.checker", builder, (Properties)props, Scope.PROTOTYPE);
/*     */     
/* 428 */     switchDevMode(props);
/*     */ 
/*     */     
/* 431 */     convertIfExist(props, "struts.ognl.logMissingProperties", "logMissingProperties");
/* 432 */     convertIfExist(props, "struts.ognl.enableExpressionCache", "enableOGNLExpressionCache");
/* 433 */     convertIfExist(props, "struts.ognl.enableOGNLEvalExpression", "enableOGNLEvalExpression");
/* 434 */     convertIfExist(props, "struts.ognl.allowStaticMethodAccess", "allowStaticMethodAccess");
/* 435 */     convertIfExist(props, "struts.configuration.xml.reload", "reloadXmlConfiguration");
/*     */     
/* 437 */     convertIfExist(props, "struts.excludedClasses", "ognlExcludedClasses");
/* 438 */     convertIfExist(props, "struts.excludedPackageNamePatterns", "ognlExcludedPackageNamePatterns");
/* 439 */     convertIfExist(props, "struts.excludedPackageNames", "ognlExcludedPackageNames");
/*     */     
/* 441 */     convertIfExist(props, "struts.additional.excludedPatterns", "additionalExcludedPatterns");
/* 442 */     convertIfExist(props, "struts.additional.acceptedPatterns", "additionalAcceptedPatterns");
/* 443 */     convertIfExist(props, "struts.override.excludedPatterns", "overrideExcludedPatterns");
/* 444 */     convertIfExist(props, "struts.override.acceptedPatterns", "overrideAcceptedPatterns");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchDevMode(LocatableProperties props) {
/* 453 */     if ("true".equalsIgnoreCase(props.getProperty("struts.devMode"))) {
/* 454 */       if (props.getProperty("struts.i18n.reload") == null) {
/* 455 */         props.setProperty("struts.i18n.reload", "true");
/*     */       }
/* 457 */       if (props.getProperty("struts.configuration.xml.reload") == null) {
/* 458 */         props.setProperty("struts.configuration.xml.reload", "true");
/*     */       }
/* 460 */       if (props.getProperty("struts.freemarker.templatesCache.updateDelay") == null) {
/* 461 */         props.setProperty("struts.freemarker.templatesCache.updateDelay", "0");
/*     */       }
/*     */       
/* 464 */       props.setProperty("devMode", "true");
/*     */     } else {
/* 466 */       props.setProperty("devMode", "false");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\DefaultBeanSelectionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */