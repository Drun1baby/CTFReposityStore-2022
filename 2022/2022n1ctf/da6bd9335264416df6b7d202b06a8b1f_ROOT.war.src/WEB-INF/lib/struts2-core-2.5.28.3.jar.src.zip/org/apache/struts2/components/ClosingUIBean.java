/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClosingUIBean
/*    */   extends UIBean
/*    */ {
/* 34 */   private static final Logger LOG = LogManager.getLogger(ClosingUIBean.class);
/*    */   
/*    */   protected ClosingUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 37 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   String openTemplate;
/*    */   
/*    */   public abstract String getDefaultOpenTemplate();
/*    */   
/*    */   @StrutsTagAttribute(description = "Set template to use for opening the rendered html.")
/*    */   public void setOpenTemplate(String openTemplate) {
/* 46 */     this.openTemplate = openTemplate;
/*    */   }
/*    */   
/*    */   public boolean start(Writer writer) {
/* 50 */     boolean result = super.start(writer);
/*    */     try {
/* 52 */       evaluateParams();
/*    */       
/* 54 */       mergeTemplate(writer, buildTemplateName(this.openTemplate, getDefaultOpenTemplate()));
/* 55 */     } catch (Exception e) {
/* 56 */       LOG.error("Could not open template", e);
/*    */     } 
/*    */     
/* 59 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ClosingUIBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */