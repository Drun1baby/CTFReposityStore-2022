/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FormButton
/*     */   extends ClosingUIBean
/*     */ {
/*     */   static final String BUTTONTYPE_INPUT = "input";
/*     */   static final String BUTTONTYPE_BUTTON = "button";
/*     */   static final String BUTTONTYPE_IMAGE = "image";
/*     */   protected String action;
/*     */   protected String method;
/*     */   protected String type;
/*     */   
/*     */   public FormButton(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  45 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluateExtraParams() {
/*  50 */     super.evaluateExtraParams();
/*     */     
/*  52 */     String submitType = "input";
/*  53 */     if (this.type != null && ("button".equalsIgnoreCase(this.type) || (supportsImageType() && "image".equalsIgnoreCase(this.type))))
/*     */     {
/*  55 */       submitType = this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  60 */     addParameter("type", submitType);
/*     */     
/*  62 */     if (!"input".equals(submitType) && this.label == null) {
/*  63 */       addParameter("label", getParameters().get("nameValue"));
/*     */     }
/*     */     
/*  66 */     if (this.action != null || this.method != null) {
/*     */       String name;
/*     */       
/*  69 */       if (this.action != null) {
/*  70 */         ActionMapping mapping = new ActionMapping();
/*  71 */         mapping.setName(findString(this.action));
/*  72 */         if (this.method != null) {
/*  73 */           mapping.setMethod(findString(this.method));
/*     */         }
/*  75 */         mapping.setExtension("");
/*  76 */         name = "action:" + this.actionMapper.getUriFromActionMapping(mapping);
/*     */       } else {
/*  78 */         name = "method:" + findString(this.method);
/*     */       } 
/*     */       
/*  81 */       addParameter("name", name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void populateComponentHtmlId(Form form) {
/* 101 */     String _tmp_id = "";
/* 102 */     if (this.id != null) {
/*     */       
/* 104 */       _tmp_id = findStringIfAltSyntax(this.id);
/*     */     } else {
/*     */       
/* 107 */       if (form != null && form.getParameters().get("id") != null) {
/* 108 */         _tmp_id = _tmp_id + form.getParameters().get("id").toString() + "_";
/*     */       }
/* 110 */       if (this.name != null) {
/* 111 */         _tmp_id = _tmp_id + escape(this.name);
/* 112 */       } else if (this.action != null || this.method != null) {
/* 113 */         if (this.action != null) {
/* 114 */           _tmp_id = _tmp_id + escape(this.action);
/*     */         }
/* 116 */         if (this.method != null) {
/* 117 */           _tmp_id = _tmp_id + "_" + escape(this.method);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 122 */       else if (form != null) {
/* 123 */         _tmp_id = _tmp_id + form.getSequence();
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     addParameter("id", _tmp_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean supportsImageType();
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/* 139 */     this.actionMapper = mapper;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set action attribute.")
/*     */   public void setAction(String action) {
/* 144 */     this.action = action;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set method attribute.")
/*     */   public void setMethod(String method) {
/* 149 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "The type of submit to use. Valid values are <i>input</i>, <i>button</i> and <i>image</i>.", defaultValue = "input")
/*     */   public void setType(String type) {
/* 156 */     this.type = type;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\FormButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */