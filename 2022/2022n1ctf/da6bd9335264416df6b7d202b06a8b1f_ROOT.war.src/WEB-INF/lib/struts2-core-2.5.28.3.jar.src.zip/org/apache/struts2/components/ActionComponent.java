/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ import org.apache.struts2.dispatcher.RequestMap;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "action", tldTagClass = "org.apache.struts2.views.jsp.ActionTag", description = "Execute an action from within a view")
/*     */ public class ActionComponent
/*     */   extends ContextBean
/*     */ {
/* 118 */   private static final Logger LOG = LogManager.getLogger(ActionComponent.class);
/*     */   
/*     */   protected HttpServletResponse res;
/*     */   
/*     */   protected HttpServletRequest req;
/*     */   protected ValueStackFactory valueStackFactory;
/*     */   protected ActionProxyFactory actionProxyFactory;
/*     */   protected ActionProxy proxy;
/*     */   protected String name;
/*     */   protected String namespace;
/*     */   protected boolean executeResult;
/*     */   protected boolean ignoreContextParams;
/*     */   protected boolean flush = true;
/*     */   protected boolean rethrowException;
/*     */   
/*     */   public ActionComponent(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 134 */     super(stack);
/* 135 */     this.req = req;
/* 136 */     this.res = res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   public void setActionProxyFactory(ActionProxyFactory actionProxyFactory) {
/* 144 */     this.actionProxyFactory = actionProxyFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 149 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/* 154 */     this.actionMapper = mapper;
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 158 */     boolean end = end(writer, "", false);
/*     */     try {
/* 160 */       if (this.flush) {
/*     */         try {
/* 162 */           writer.flush();
/* 163 */         } catch (IOException e) {
/* 164 */           LOG.warn("error while trying to flush writer ", e);
/*     */         } 
/*     */       }
/* 167 */       executeAction();
/*     */       
/* 169 */       if (getVar() != null && this.proxy != null) {
/* 170 */         getStack().setValue("#attr['" + getVar() + "']", this.proxy.getAction());
/*     */       }
/*     */     } finally {
/* 173 */       popComponentStack();
/*     */     } 
/* 175 */     return end;
/*     */   }
/*     */   
/*     */   protected Map createExtraContext() {
/* 179 */     HttpParameters newParams = createParametersForContext();
/*     */     
/* 181 */     ActionContext ctx = new ActionContext(this.stack.getContext());
/* 182 */     PageContext pageContext = (PageContext)ctx.get("com.opensymphony.xwork2.dispatcher.PageContext");
/* 183 */     Map session = ctx.getSession();
/* 184 */     Map application = ctx.getApplication();
/*     */     
/* 186 */     Dispatcher du = Dispatcher.getInstance();
/* 187 */     Map<String, Object> extraContext = du.createContextMap((Map)new RequestMap(this.req), newParams, session, application, this.req, this.res);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     ValueStack newStack = this.valueStackFactory.createValueStack(this.stack);
/* 195 */     extraContext.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", newStack);
/*     */ 
/*     */     
/* 198 */     extraContext.put("com.opensymphony.xwork2.dispatcher.PageContext", pageContext);
/*     */     
/* 200 */     return extraContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpParameters createParametersForContext() {
/* 210 */     HttpParameters parentParams = null;
/*     */     
/* 212 */     if (!this.ignoreContextParams) {
/* 213 */       parentParams = (new ActionContext(getStack().getContext())).getParameters();
/*     */     }
/*     */     
/* 216 */     HttpParameters.Builder builder = HttpParameters.create();
/* 217 */     if (parentParams != null) {
/* 218 */       builder = builder.withParent(parentParams);
/*     */     }
/*     */     
/* 221 */     if (this.parameters != null) {
/* 222 */       Map<String, String[]> params = (Map)new HashMap<>();
/* 223 */       for (Object o : this.parameters.entrySet()) {
/* 224 */         Map.Entry entry = (Map.Entry)o;
/* 225 */         String key = (String)entry.getKey();
/* 226 */         Object val = entry.getValue();
/* 227 */         if (val.getClass().isArray() && String.class == val.getClass().getComponentType()) {
/* 228 */           params.put(key, (String[])val); continue;
/*     */         } 
/* 230 */         params.put(key, new String[] { val.toString() });
/*     */       } 
/*     */       
/* 233 */       builder = builder.withExtraParams(params);
/*     */     } 
/* 235 */     return builder.build();
/*     */   }
/*     */   
/*     */   public ActionProxy getProxy() {
/* 239 */     return this.proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void executeAction() {
/* 251 */     String namespace, actualName = findString(this.name, "name", "Action name is required. Example: updatePerson");
/*     */     
/* 253 */     if (actualName == null) {
/* 254 */       throw new StrutsException("Unable to find value for name " + this.name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     ActionMapping mapping = this.actionMapper.getMappingFromActionName(actualName);
/* 262 */     String actionName = mapping.getName();
/* 263 */     String methodName = mapping.getMethod();
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (this.namespace == null) {
/* 268 */       namespace = TagUtils.buildNamespace(this.actionMapper, getStack(), this.req);
/*     */     } else {
/* 270 */       namespace = findString(this.namespace);
/*     */     } 
/*     */ 
/*     */     
/* 274 */     ValueStack stack = getStack();
/*     */     
/* 276 */     ActionInvocation inv = ActionContext.getContext().getActionInvocation();
/*     */     
/*     */     try {
/* 279 */       this.proxy = this.actionProxyFactory.createActionProxy(namespace, actionName, methodName, createExtraContext(), this.executeResult, true);
/*     */       
/* 281 */       this.req.setAttribute("struts.valueStack", this.proxy.getInvocation().getStack());
/* 282 */       this.req.setAttribute("struts.actiontag.invocation", Boolean.TRUE);
/* 283 */       this.proxy.execute();
/*     */     }
/* 285 */     catch (Exception e) {
/* 286 */       String message = "Could not execute action: " + namespace + "/" + actualName;
/* 287 */       LOG.error(message, e);
/* 288 */       if (this.rethrowException) {
/* 289 */         throw new StrutsException(message, e);
/*     */       }
/*     */     } finally {
/* 292 */       this.req.removeAttribute("struts.actiontag.invocation");
/*     */       
/* 294 */       this.req.setAttribute("struts.valueStack", stack);
/* 295 */       if (inv != null) {
/* 296 */         ActionContext.getContext().setActionInvocation(inv);
/*     */       }
/*     */     } 
/*     */     
/* 300 */     if (getVar() != null && this.proxy != null) {
/* 301 */       putInContext(this.proxy.getAction());
/*     */     }
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(required = true, description = "Name of the action to be executed (without the extension suffix eg. .action)")
/*     */   public void setName(String name) {
/* 307 */     this.name = name;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Namespace for action to call", defaultValue = "namespace from where tag is used")
/*     */   public void setNamespace(String namespace) {
/* 312 */     this.namespace = namespace;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether the result of this action (probably a view) should be executed/rendered", type = "Boolean", defaultValue = "false")
/*     */   public void setExecuteResult(boolean executeResult) {
/* 317 */     this.executeResult = executeResult;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether the request parameters are to be included when the action is invoked", type = "Boolean", defaultValue = "false")
/*     */   public void setIgnoreContextParams(boolean ignoreContextParams) {
/* 322 */     this.ignoreContextParams = ignoreContextParams;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether the writer should be flush upon end of action component tag, default to true", type = "Boolean", defaultValue = "true")
/*     */   public void setFlush(boolean flush) {
/* 327 */     this.flush = flush;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether an exception should be rethrown, if the target action throws an exception", type = "Boolean", defaultValue = "false")
/*     */   public void setRethrowException(boolean rethrowException) {
/* 332 */     this.rethrowException = rethrowException;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ActionComponent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */