/*     */ package org.apache.struts2.dispatcher.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.ExecuteOperations;
/*     */ import org.apache.struts2.dispatcher.InitOperations;
/*     */ import org.apache.struts2.dispatcher.PrepareOperations;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrutsPrepareAndExecuteFilter
/*     */   implements StrutsStatics, Filter
/*     */ {
/*  49 */   private static final Logger LOG = LogManager.getLogger(StrutsPrepareAndExecuteFilter.class);
/*     */   
/*     */   protected PrepareOperations prepare;
/*     */   protected ExecuteOperations execute;
/*  53 */   protected List<Pattern> excludedPatterns = null;
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  56 */     InitOperations init = createInitOperations();
/*  57 */     Dispatcher dispatcher = null;
/*     */     try {
/*  59 */       FilterHostConfig config = new FilterHostConfig(filterConfig);
/*  60 */       init.initLogging(config);
/*  61 */       dispatcher = init.initDispatcher(config);
/*  62 */       init.initStaticContentLoader(config, dispatcher);
/*     */       
/*  64 */       this.prepare = createPrepareOperations(dispatcher);
/*  65 */       this.execute = createExecuteOperations(dispatcher);
/*  66 */       this.excludedPatterns = init.buildExcludedPatternsList(dispatcher);
/*     */       
/*  68 */       postInit(dispatcher, filterConfig);
/*     */     } finally {
/*  70 */       if (dispatcher != null) {
/*  71 */         dispatcher.cleanUpAfterInit();
/*     */       }
/*  73 */       init.cleanup();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InitOperations createInitOperations() {
/*  84 */     return new InitOperations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrepareOperations createPrepareOperations(Dispatcher dispatcher) {
/*  94 */     return new PrepareOperations(dispatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ExecuteOperations createExecuteOperations(Dispatcher dispatcher) {
/* 104 */     return new ExecuteOperations(dispatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postInit(Dispatcher dispatcher, FilterConfig filterConfig) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/* 118 */     HttpServletRequest request = (HttpServletRequest)req;
/* 119 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */     
/*     */     try {
/* 122 */       String uri = RequestUtils.getUri(request);
/* 123 */       if (this.excludedPatterns != null && this.prepare.isUrlExcluded(request, this.excludedPatterns)) {
/* 124 */         LOG.trace("Request {} is excluded from handling by Struts, passing request to other filters", uri);
/* 125 */         chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */       } else {
/* 127 */         LOG.trace("Checking if {} is a static resource", uri);
/* 128 */         boolean handled = this.execute.executeStaticResourceRequest(request, response);
/* 129 */         if (!handled) {
/* 130 */           LOG.trace("Assuming uri {} as a normal action", uri);
/* 131 */           this.prepare.setEncodingAndLocale(request, response);
/* 132 */           this.prepare.createActionContext(request, response);
/* 133 */           this.prepare.assignDispatcherToThread();
/* 134 */           request = this.prepare.wrapRequest(request);
/* 135 */           ActionMapping mapping = this.prepare.findActionMapping(request, response, true);
/* 136 */           if (mapping == null) {
/* 137 */             LOG.trace("Cannot find mapping for {}, passing to other filters", uri);
/* 138 */             chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */           } else {
/* 140 */             LOG.trace("Found mapping {} for {}", mapping, uri);
/* 141 */             this.execute.executeAction(request, response, mapping);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 146 */       this.prepare.cleanupRequest(request);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 151 */     this.prepare.cleanupDispatcher();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\filter\StrutsPrepareAndExecuteFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */