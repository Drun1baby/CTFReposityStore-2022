/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "push", tldTagClass = "org.apache.struts2.views.jsp.PushTag", description = "Push value on stack for simplified usage.")
/*     */ public class Push
/*     */   extends Component
/*     */ {
/*     */   protected String value;
/*     */   protected boolean pushed;
/*     */   
/*     */   public Push(ValueStack stack) {
/* 116 */     super(stack);
/*     */   }
/*     */   
/*     */   public boolean start(Writer writer) {
/* 120 */     boolean result = super.start(writer);
/*     */     
/* 122 */     ValueStack stack = getStack();
/*     */     
/* 124 */     if (stack != null) {
/* 125 */       stack.push(findValue(this.value, "value", "You must specify a value to push on the stack. Example: person"));
/* 126 */       this.pushed = true;
/*     */     } else {
/* 128 */       this.pushed = false;
/*     */     } 
/*     */     
/* 131 */     return result;
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 135 */     ValueStack stack = getStack();
/*     */     
/* 137 */     if (this.pushed && stack != null) {
/* 138 */       stack.pop();
/*     */     }
/*     */     
/* 141 */     return super.end(writer, body);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Value to push on stack", required = true)
/*     */   public void setValue(String value) {
/* 146 */     this.value = value;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Push.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */