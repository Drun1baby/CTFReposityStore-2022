/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "doubleselect", tldTagClass = "org.apache.struts2.views.jsp.ui.DoubleSelectTag", description = "Renders two HTML select elements with second one changing displayed values depending on selected entry of first one.")
/*    */ public class DoubleSelect
/*    */   extends DoubleListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "doubleselect";
/*    */   
/*    */   public DoubleSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 50 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 54 */     return "doubleselect";
/*    */   }
/*    */   
/*    */   public void evaluateExtraParams() {
/* 58 */     super.evaluateExtraParams();
/* 59 */     StringBuilder onchangeParam = new StringBuilder();
/* 60 */     onchangeParam.append(getParameters().get("id")).append("Redirect(this.selectedIndex)");
/* 61 */     if (StringUtils.isNotEmpty(this.onchange)) {
/* 62 */       onchangeParam.append(";").append(this.onchange);
/*    */     }
/*    */     
/* 65 */     addParameter("onchange", onchangeParam.toString());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\DoubleSelect.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */