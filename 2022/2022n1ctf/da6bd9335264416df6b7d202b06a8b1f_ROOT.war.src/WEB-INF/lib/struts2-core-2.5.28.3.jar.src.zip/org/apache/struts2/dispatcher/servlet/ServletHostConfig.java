/*    */ package org.apache.struts2.dispatcher.servlet;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.HostConfig;
/*    */ import org.apache.struts2.util.MakeIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletHostConfig
/*    */   implements HostConfig
/*    */ {
/*    */   private ServletConfig config;
/*    */   
/*    */   public ServletHostConfig(ServletConfig config) {
/* 36 */     this.config = config;
/*    */   }
/*    */   public String getInitParameter(String key) {
/* 39 */     return this.config.getInitParameter(key);
/*    */   }
/*    */   
/*    */   public Iterator<String> getInitParameterNames() {
/* 43 */     return MakeIterator.convert(this.config.getInitParameterNames());
/*    */   }
/*    */   
/*    */   public ServletContext getServletContext() {
/* 47 */     return this.config.getServletContext();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\servlet\ServletHostConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */