package org.apache.struts2.dispatcher;

import java.util.Iterator;
import javax.servlet.ServletContext;

public interface HostConfig {
  String getInitParameter(String paramString);
  
  Iterator<String> getInitParameterNames();
  
  ServletContext getServletContext();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\HostConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */