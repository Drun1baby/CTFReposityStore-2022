/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "optgroup", tldTagClass = "org.apache.struts2.views.jsp.ui.OptGroupTag", description = "Renders a Select Tag's OptGroup Tag")
/*     */ public class OptGroup
/*     */   extends Component
/*     */ {
/*     */   public static final String INTERNAL_LIST_UI_BEAN_LIST_PARAMETER_KEY = "optGroupInternalListUiBeanList";
/*  76 */   private static Logger LOG = LogManager.getLogger(OptGroup.class);
/*     */   
/*     */   protected HttpServletRequest req;
/*     */   
/*     */   protected HttpServletResponse res;
/*     */   protected ListUIBean internalUiBean;
/*     */   
/*     */   public OptGroup(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/*  84 */     super(stack);
/*  85 */     this.req = req;
/*  86 */     this.res = res;
/*  87 */     this.internalUiBean = new ListUIBean(stack, req, res) {
/*     */         protected String getDefaultTemplate() {
/*  89 */           return "empty";
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  96 */     container.inject(this.internalUiBean);
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 100 */     Select select = (Select)findAncestor(Select.class);
/* 101 */     if (select == null) {
/* 102 */       LOG.error("incorrect use of OptGroup component, this component must be used within a Select component", new IllegalStateException("incorrect use of OptGroup component, this component must be used within a Select component"));
/*     */       
/* 104 */       return false;
/*     */     } 
/* 106 */     this.internalUiBean.start(writer);
/* 107 */     this.internalUiBean.end(writer, body);
/*     */     
/* 109 */     List<ListUIBean> listUiBeans = (List)select.getParameters().get("optGroupInternalListUiBeanList");
/* 110 */     if (listUiBeans == null) {
/* 111 */       listUiBeans = new ArrayList();
/*     */     }
/* 113 */     listUiBeans.add(this.internalUiBean);
/* 114 */     select.addParameter("optGroupInternalListUiBeanList", listUiBeans);
/*     */     
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the label attribute")
/*     */   public void setLabel(String label) {
/* 121 */     this.internalUiBean.setLabel(label);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the disable attribute.")
/*     */   public void setDisabled(String disabled) {
/* 126 */     this.internalUiBean.setDisabled(disabled);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the list attribute.")
/*     */   public void setList(String list) {
/* 131 */     this.internalUiBean.setList(list);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the listKey attribute.")
/*     */   public void setListKey(String listKey) {
/* 136 */     this.internalUiBean.setListKey(listKey);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the listValue attribute.")
/*     */   public void setListValue(String listValue) {
/* 141 */     this.internalUiBean.setListValue(listValue);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get css class from")
/*     */   public void setListCssClass(String listCssClass) {
/* 146 */     this.internalUiBean.setListCssClass(listCssClass);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get css style from")
/*     */   public void setListCssStyle(String listCssStyle) {
/* 151 */     this.internalUiBean.setListCssStyle(listCssStyle);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of list objects to get title from")
/*     */   public void setListTitle(String listTitle) {
/* 156 */     this.internalUiBean.setListTitle(listTitle);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\OptGroup.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */