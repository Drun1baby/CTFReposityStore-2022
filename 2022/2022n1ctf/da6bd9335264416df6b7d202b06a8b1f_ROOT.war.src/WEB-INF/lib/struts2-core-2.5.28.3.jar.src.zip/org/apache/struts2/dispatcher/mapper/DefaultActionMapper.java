/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.util.PrefixTrie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultActionMapper
/*     */   implements ActionMapper
/*     */ {
/* 110 */   private static final Logger LOG = LogManager.getLogger(DefaultActionMapper.class);
/*     */   
/*     */   protected static final String METHOD_PREFIX = "method:";
/*     */   
/*     */   protected static final String ACTION_PREFIX = "action:";
/*     */   protected boolean allowDynamicMethodCalls = false;
/*     */   protected boolean allowSlashesInActionNames = false;
/*     */   protected boolean alwaysSelectFullNamespace = false;
/* 118 */   protected PrefixTrie prefixTrie = null;
/*     */   
/* 120 */   protected Pattern allowedNamespaceNames = Pattern.compile("[a-zA-Z0-9._/\\-]*");
/* 121 */   protected String defaultNamespaceName = "/";
/*     */   
/* 123 */   protected Pattern allowedActionNames = Pattern.compile("[a-zA-Z0-9._!/\\-]*");
/* 124 */   protected String defaultActionName = "index";
/*     */   
/* 126 */   protected Pattern allowedMethodNames = Pattern.compile("[a-zA-Z_]*[0-9]*");
/* 127 */   protected String defaultMethodName = "execute";
/*     */   
/*     */   private boolean allowActionPrefix = false;
/*     */   
/*     */   private boolean allowActionCrossNamespaceAccess = false;
/* 132 */   protected List<String> extensions = new ArrayList<String>()
/*     */     {
/*     */     
/*     */     };
/*     */   
/*     */   protected Container container;
/*     */   
/*     */   public DefaultActionMapper() {
/* 140 */     this.prefixTrie = new PrefixTrie()
/*     */       {
/*     */       
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addParameterAction(String prefix, ParameterAction parameterAction) {
/* 190 */     this.prefixTrie.put(prefix, parameterAction);
/*     */   }
/*     */   
/*     */   @Inject("struts.enable.DynamicMethodInvocation")
/*     */   public void setAllowDynamicMethodCalls(String enableDynamicMethodCalls) {
/* 195 */     this.allowDynamicMethodCalls = BooleanUtils.toBoolean(enableDynamicMethodCalls);
/*     */   }
/*     */   
/*     */   @Inject("struts.enable.SlashesInActionNames")
/*     */   public void setSlashesInActionNames(String enableSlashesInActionNames) {
/* 200 */     this.allowSlashesInActionNames = BooleanUtils.toBoolean(enableSlashesInActionNames);
/*     */   }
/*     */   
/*     */   @Inject("struts.mapper.alwaysSelectFullNamespace")
/*     */   public void setAlwaysSelectFullNamespace(String alwaysSelectFullNamespace) {
/* 205 */     this.alwaysSelectFullNamespace = BooleanUtils.toBoolean(alwaysSelectFullNamespace);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.allowed.namespace.names", required = false)
/*     */   public void setAllowedNamespaceNames(String allowedNamespaceNames) {
/* 210 */     this.allowedNamespaceNames = Pattern.compile(allowedNamespaceNames);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.default.namespace.name", required = false)
/*     */   public void setDefaultNamespaceName(String defaultNamespaceName) {
/* 215 */     this.defaultNamespaceName = defaultNamespaceName;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.allowed.action.names", required = false)
/*     */   public void setAllowedActionNames(String allowedActionNames) {
/* 220 */     this.allowedActionNames = Pattern.compile(allowedActionNames);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.default.action.name", required = false)
/*     */   public void setDefaultActionName(String defaultActionName) {
/* 225 */     this.defaultActionName = defaultActionName;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.allowed.method.names", required = false)
/*     */   public void setAllowedMethodNames(String allowedMethodNames) {
/* 230 */     this.allowedMethodNames = Pattern.compile(allowedMethodNames);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.default.method.name", required = false)
/*     */   public void setDefaultMethodName(String defaultMethodName) {
/* 235 */     this.defaultMethodName = defaultMethodName;
/*     */   }
/*     */   
/*     */   @Inject("struts.mapper.action.prefix.enabled")
/*     */   public void setAllowActionPrefix(String allowActionPrefix) {
/* 240 */     this.allowActionPrefix = BooleanUtils.toBoolean(allowActionPrefix);
/*     */   }
/*     */   
/*     */   @Inject("struts.mapper.action.prefix.crossNamespaces")
/*     */   public void setAllowActionCrossNamespaceAccess(String allowActionCrossNamespaceAccess) {
/* 245 */     this.allowActionCrossNamespaceAccess = BooleanUtils.toBoolean(allowActionCrossNamespaceAccess);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 250 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject("struts.action.extension")
/*     */   public void setExtensions(String extensions) {
/* 255 */     if (StringUtils.isNotEmpty(extensions)) {
/* 256 */       List<String> list = new ArrayList<>();
/* 257 */       String[] tokens = extensions.split(",");
/* 258 */       Collections.addAll(list, tokens);
/* 259 */       if (extensions.endsWith(",")) {
/* 260 */         list.add("");
/*     */       }
/* 262 */       this.extensions = Collections.unmodifiableList(list);
/*     */     } else {
/* 264 */       this.extensions = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ActionMapping getMappingFromActionName(String actionName) {
/* 269 */     ActionMapping mapping = new ActionMapping();
/* 270 */     mapping.setName(actionName);
/* 271 */     return parseActionName(mapping);
/*     */   }
/*     */   
/*     */   public boolean isSlashesInActionNames() {
/* 275 */     return this.allowSlashesInActionNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager) {
/* 284 */     ActionMapping mapping = new ActionMapping();
/* 285 */     String uri = RequestUtils.getUri(request);
/*     */     
/* 287 */     int indexOfSemicolon = uri.indexOf(';');
/* 288 */     uri = (indexOfSemicolon > -1) ? uri.substring(0, indexOfSemicolon) : uri;
/*     */     
/* 290 */     uri = dropExtension(uri, mapping);
/* 291 */     if (uri == null) {
/* 292 */       return null;
/*     */     }
/*     */     
/* 295 */     parseNameAndNamespace(uri, mapping, configManager);
/* 296 */     handleSpecialParameters(request, mapping);
/* 297 */     return parseActionName(mapping);
/*     */   }
/*     */   
/*     */   protected ActionMapping parseActionName(ActionMapping mapping) {
/* 301 */     if (mapping.getName() == null) {
/* 302 */       return null;
/*     */     }
/* 304 */     if (this.allowDynamicMethodCalls) {
/*     */       
/* 306 */       String name = mapping.getName();
/* 307 */       int exclamation = name.lastIndexOf('!');
/* 308 */       if (exclamation != -1) {
/* 309 */         mapping.setName(name.substring(0, exclamation));
/*     */         
/* 311 */         mapping.setMethod(name.substring(exclamation + 1));
/*     */       } 
/*     */     } 
/* 314 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleSpecialParameters(HttpServletRequest request, ActionMapping mapping) {
/* 326 */     Set<String> uniqueParameters = new HashSet<>();
/* 327 */     Map parameterMap = request.getParameterMap();
/* 328 */     for (Object o : parameterMap.keySet()) {
/* 329 */       String key = (String)o;
/*     */ 
/*     */       
/* 332 */       if (key.endsWith(".x") || key.endsWith(".y")) {
/* 333 */         key = key.substring(0, key.length() - 2);
/*     */       }
/*     */ 
/*     */       
/* 337 */       if (!uniqueParameters.contains(key)) {
/* 338 */         ParameterAction parameterAction = (ParameterAction)this.prefixTrie.get(key);
/* 339 */         if (parameterAction != null) {
/* 340 */           parameterAction.execute(key, mapping);
/* 341 */           uniqueParameters.add(key);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseNameAndNamespace(String uri, ActionMapping mapping, ConfigurationManager configManager) {
/*     */     String namespace, name;
/* 357 */     int lastSlash = uri.lastIndexOf('/');
/* 358 */     if (lastSlash == -1) {
/* 359 */       namespace = "";
/* 360 */       name = uri;
/* 361 */     } else if (lastSlash == 0) {
/*     */ 
/*     */ 
/*     */       
/* 365 */       namespace = "/";
/* 366 */       name = uri.substring(lastSlash + 1);
/* 367 */     } else if (this.alwaysSelectFullNamespace) {
/*     */       
/* 369 */       namespace = uri.substring(0, lastSlash);
/* 370 */       name = uri.substring(lastSlash + 1);
/*     */     } else {
/*     */       
/* 373 */       Configuration config = configManager.getConfiguration();
/* 374 */       String prefix = uri.substring(0, lastSlash);
/* 375 */       namespace = "";
/* 376 */       boolean rootAvailable = false;
/*     */       
/* 378 */       for (PackageConfig cfg : config.getPackageConfigs().values()) {
/* 379 */         String ns = cfg.getNamespace();
/* 380 */         if (ns != null && prefix.startsWith(ns) && (prefix.length() == ns.length() || prefix.charAt(ns.length()) == '/') && 
/* 381 */           ns.length() > namespace.length()) {
/* 382 */           namespace = ns;
/*     */         }
/*     */         
/* 385 */         if ("/".equals(ns)) {
/* 386 */           rootAvailable = true;
/*     */         }
/*     */       } 
/*     */       
/* 390 */       name = uri.substring(namespace.length() + 1);
/*     */ 
/*     */       
/* 393 */       if (rootAvailable && "".equals(namespace)) {
/* 394 */         namespace = "/";
/*     */       }
/*     */     } 
/*     */     
/* 398 */     if (!this.allowSlashesInActionNames) {
/* 399 */       int pos = name.lastIndexOf('/');
/* 400 */       if (pos > -1 && pos < name.length() - 1) {
/* 401 */         name = name.substring(pos + 1);
/*     */       }
/*     */     } 
/*     */     
/* 405 */     mapping.setNamespace(cleanupNamespaceName(namespace));
/* 406 */     mapping.setName(cleanupActionName(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String cleanupNamespaceName(String rawNamespace) {
/* 416 */     if (this.allowedNamespaceNames.matcher(rawNamespace).matches()) {
/* 417 */       return rawNamespace;
/*     */     }
/* 419 */     LOG.warn("{} did not match allowed namespace names {} - default namespace {} will be used!", rawNamespace, this.allowedNamespaceNames, this.defaultNamespaceName);
/*     */ 
/*     */ 
/*     */     
/* 423 */     return this.defaultNamespaceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String cleanupActionName(String rawActionName) {
/* 434 */     if (this.allowedActionNames.matcher(rawActionName).matches()) {
/* 435 */       return rawActionName;
/*     */     }
/* 437 */     LOG.warn("{} did not match allowed action names {} - default action {} will be used!", rawActionName, this.allowedActionNames, this.defaultActionName);
/* 438 */     return this.defaultActionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String cleanupMethodName(String rawMethodName) {
/* 449 */     if (this.allowedMethodNames.matcher(rawMethodName).matches()) {
/* 450 */       return rawMethodName;
/*     */     }
/* 452 */     LOG.warn("{} did not match allowed method names {} - default method {} will be used!", rawMethodName, this.allowedMethodNames, this.defaultMethodName);
/* 453 */     return this.defaultMethodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String dropExtension(String name, ActionMapping mapping) {
/* 465 */     if (this.extensions == null) {
/* 466 */       return name;
/*     */     }
/* 468 */     for (String ext : this.extensions) {
/* 469 */       if ("".equals(ext)) {
/*     */ 
/*     */ 
/*     */         
/* 473 */         int index = name.lastIndexOf('.');
/* 474 */         if (index == -1 || name.indexOf('/', index) >= 0)
/* 475 */           return name; 
/*     */         continue;
/*     */       } 
/* 478 */       String extension = "." + ext;
/* 479 */       if (name.endsWith(extension)) {
/* 480 */         name = name.substring(0, name.length() - extension.length());
/* 481 */         mapping.setExtension(ext);
/* 482 */         return name;
/*     */       } 
/*     */     } 
/*     */     
/* 486 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDefaultExtension() {
/* 493 */     if (this.extensions == null) {
/* 494 */       return null;
/*     */     }
/* 496 */     return this.extensions.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUriFromActionMapping(ActionMapping mapping) {
/* 506 */     StringBuilder uri = new StringBuilder();
/*     */     
/* 508 */     handleNamespace(mapping, uri);
/* 509 */     handleName(mapping, uri);
/* 510 */     handleDynamicMethod(mapping, uri);
/* 511 */     handleExtension(mapping, uri);
/* 512 */     handleParams(mapping, uri);
/*     */     
/* 514 */     return uri.toString();
/*     */   }
/*     */   
/*     */   protected void handleNamespace(ActionMapping mapping, StringBuilder uri) {
/* 518 */     if (mapping.getNamespace() != null) {
/* 519 */       uri.append(mapping.getNamespace());
/* 520 */       if (!"/".equals(mapping.getNamespace())) {
/* 521 */         uri.append("/");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleName(ActionMapping mapping, StringBuilder uri) {
/* 527 */     String name = mapping.getName();
/* 528 */     if (name.indexOf('?') != -1) {
/* 529 */       name = name.substring(0, name.indexOf('?'));
/*     */     }
/* 531 */     uri.append(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleDynamicMethod(ActionMapping mapping, StringBuilder uri) {
/* 536 */     if (StringUtils.isNotEmpty(mapping.getMethod())) {
/* 537 */       if (this.allowDynamicMethodCalls) {
/*     */         
/* 539 */         String name = mapping.getName();
/* 540 */         if (!name.contains("!"))
/*     */         {
/* 542 */           uri.append("!").append(mapping.getMethod());
/*     */         }
/*     */       } else {
/* 545 */         uri.append("!").append(mapping.getMethod());
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void handleExtension(ActionMapping mapping, StringBuilder uri) {
/* 551 */     String extension = lookupExtension(mapping.getExtension());
/*     */     
/* 553 */     if (extension != null && (
/* 554 */       extension.length() == 0 || (extension.length() > 0 && uri.indexOf('.' + extension) == -1)) && 
/* 555 */       extension.length() > 0) {
/* 556 */       uri.append(".").append(extension);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String lookupExtension(String extension) {
/* 563 */     if (extension == null) {
/*     */       
/* 565 */       ActionContext context = ActionContext.getContext();
/* 566 */       if (context != null) {
/* 567 */         ActionMapping orig = (ActionMapping)context.get("struts.actionMapping");
/* 568 */         if (orig != null) {
/* 569 */           extension = orig.getExtension();
/*     */         }
/*     */       } 
/* 572 */       if (extension == null) {
/* 573 */         extension = getDefaultExtension();
/*     */       }
/*     */     } 
/* 576 */     return extension;
/*     */   }
/*     */   
/*     */   protected void handleParams(ActionMapping mapping, StringBuilder uri) {
/* 580 */     String name = mapping.getName();
/* 581 */     String params = "";
/* 582 */     if (name.indexOf('?') != -1) {
/* 583 */       params = name.substring(name.indexOf('?'));
/*     */     }
/* 585 */     if (params.length() > 0)
/* 586 */       uri.append(params); 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\DefaultActionMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */