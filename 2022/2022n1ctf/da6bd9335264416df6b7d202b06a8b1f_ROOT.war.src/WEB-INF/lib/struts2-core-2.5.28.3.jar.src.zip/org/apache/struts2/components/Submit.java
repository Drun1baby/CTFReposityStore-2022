/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "submit", tldTagClass = "org.apache.struts2.views.jsp.ui.SubmitTag", description = "Render a submit button", allowDynamicAttributes = true)
/*     */ public class Submit
/*     */   extends FormButton
/*     */ {
/*  53 */   private static final Logger LOG = LogManager.getLogger(Submit.class);
/*     */   public static final String OPEN_TEMPLATE = "submit";
/*     */   public static final String TEMPLATE = "submit-close";
/*     */   protected String src;
/*     */   
/*     */   public Submit(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  59 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   public String getDefaultOpenTemplate() {
/*  63 */     return "submit";
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  67 */     return "submit-close";
/*     */   }
/*     */   
/*     */   public void evaluateParams() {
/*  71 */     if (this.key == null && this.value == null) {
/*  72 */       this.value = "Submit";
/*     */     }
/*     */     
/*  75 */     if (this.key != null && this.value == null) {
/*  76 */       this.value = "%{getText('" + this.key + "')}";
/*     */     }
/*     */     
/*  79 */     super.evaluateParams();
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/*  83 */     super.evaluateExtraParams();
/*     */     
/*  85 */     if (this.src != null) {
/*  86 */       addParameter("src", findString(this.src));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean supportsImageType() {
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Supply an image src for <i>image</i> type submit button. Will have no effect for types <i>input</i> and <i>button</i>.")
/*     */   public void setSrc(String src) {
/* 100 */     this.src = src;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesBody() {
/* 106 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 113 */     evaluateParams();
/*     */     try {
/* 115 */       addParameter("body", body);
/*     */       
/* 117 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/* 118 */     } catch (Exception e) {
/* 119 */       LOG.error("error when rendering", e);
/*     */     } finally {
/*     */       
/* 122 */       popComponentStack();
/*     */     } 
/*     */     
/* 125 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Submit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */