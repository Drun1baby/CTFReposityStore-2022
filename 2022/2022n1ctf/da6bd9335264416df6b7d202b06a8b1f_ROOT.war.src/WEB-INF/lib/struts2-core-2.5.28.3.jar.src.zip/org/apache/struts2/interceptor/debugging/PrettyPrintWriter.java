/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrettyPrintWriter
/*     */ {
/*     */   private final PrintWriter writer;
/*  28 */   private final Stack<String> elementStack = new Stack<>();
/*     */   
/*     */   private final char[] lineIndenter;
/*     */   
/*     */   private boolean tagInProgress;
/*     */   private int depth;
/*     */   private boolean readyForNewLine;
/*     */   private boolean tagIsEmpty;
/*     */   private String newLine;
/*     */   private boolean escape = true;
/*  38 */   private static final char[] NULL = "&#x0;".toCharArray();
/*  39 */   private static final char[] AMP = "&amp;".toCharArray();
/*  40 */   private static final char[] LT = "&lt;".toCharArray();
/*  41 */   private static final char[] GT = "&gt;".toCharArray();
/*  42 */   private static final char[] SLASH_R = "&#x0D;".toCharArray();
/*  43 */   private static final char[] QUOT = "&quot;".toCharArray();
/*  44 */   private static final char[] APOS = "&apos;".toCharArray();
/*  45 */   private static final char[] CLOSE = "</".toCharArray();
/*     */   
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter, String newLine) {
/*  48 */     this.writer = new PrintWriter(writer);
/*  49 */     this.lineIndenter = lineIndenter;
/*  50 */     this.newLine = newLine;
/*     */   }
/*     */   
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter) {
/*  54 */     this(writer, lineIndenter, "\n");
/*     */   }
/*     */   
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter, String newLine) {
/*  58 */     this(writer, lineIndenter.toCharArray(), newLine);
/*     */   }
/*     */   
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter) {
/*  62 */     this(writer, lineIndenter.toCharArray());
/*     */   }
/*     */   
/*     */   public PrettyPrintWriter(Writer writer) {
/*  66 */     this(writer, new char[] { ' ', ' ' });
/*     */   }
/*     */   
/*     */   public void startNode(String name) {
/*  70 */     this.tagIsEmpty = false;
/*  71 */     finishTag();
/*  72 */     this.writer.write(60);
/*  73 */     this.writer.write(name);
/*  74 */     this.elementStack.push(name);
/*  75 */     this.tagInProgress = true;
/*  76 */     this.depth++;
/*  77 */     this.readyForNewLine = true;
/*  78 */     this.tagIsEmpty = true;
/*     */   }
/*     */   
/*     */   public void setValue(String text) {
/*  82 */     this.readyForNewLine = false;
/*  83 */     this.tagIsEmpty = false;
/*  84 */     finishTag();
/*     */     
/*  86 */     writeText(this.writer, text);
/*     */   }
/*     */   
/*     */   public void addAttribute(String key, String value) {
/*  90 */     this.writer.write(32);
/*  91 */     this.writer.write(key);
/*  92 */     this.writer.write(61);
/*  93 */     this.writer.write(34);
/*  94 */     writeAttributeValue(this.writer, value);
/*  95 */     this.writer.write(34);
/*     */   }
/*     */   
/*     */   protected void writeAttributeValue(PrintWriter writer, String text) {
/*  99 */     writeText(text);
/*     */   }
/*     */   
/*     */   protected void writeText(PrintWriter writer, String text) {
/* 103 */     writeText(text);
/*     */   }
/*     */   
/*     */   private void writeText(String text) {
/* 107 */     int length = text.length();
/* 108 */     for (int i = 0; i < length; i++) {
/* 109 */       char c = text.charAt(i);
/* 110 */       switch (c) {
/*     */         case '\000':
/* 112 */           this.writer.write(NULL);
/*     */           break;
/*     */         case '&':
/* 115 */           this.writer.write(AMP);
/*     */           break;
/*     */         case '<':
/* 118 */           this.writer.write(LT);
/*     */           break;
/*     */         case '>':
/* 121 */           this.writer.write(GT);
/*     */           break;
/*     */         case '"':
/* 124 */           this.writer.write(QUOT);
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\'':
/* 129 */           if (this.escape) {
/* 130 */             this.writer.write(APOS); break;
/*     */           } 
/* 132 */           this.writer.write(c);
/*     */           break;
/*     */         case '\r':
/* 135 */           this.writer.write(SLASH_R);
/*     */           break;
/*     */         default:
/* 138 */           this.writer.write(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void endNode() {
/* 144 */     this.depth--;
/* 145 */     if (this.tagIsEmpty) {
/* 146 */       this.writer.write(47);
/* 147 */       this.readyForNewLine = false;
/* 148 */       finishTag();
/* 149 */       this.elementStack.pop();
/*     */     } else {
/* 151 */       finishTag();
/* 152 */       this.writer.write(CLOSE);
/* 153 */       this.writer.write(this.elementStack.pop());
/* 154 */       this.writer.write(62);
/*     */     } 
/* 156 */     this.readyForNewLine = true;
/* 157 */     if (this.depth == 0) {
/* 158 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   private void finishTag() {
/* 163 */     if (this.tagInProgress) {
/* 164 */       this.writer.write(62);
/*     */     }
/* 166 */     this.tagInProgress = false;
/* 167 */     if (this.readyForNewLine) {
/* 168 */       endOfLine();
/*     */     }
/* 170 */     this.readyForNewLine = false;
/* 171 */     this.tagIsEmpty = false;
/*     */   }
/*     */   
/*     */   protected void endOfLine() {
/* 175 */     this.writer.write(this.newLine);
/* 176 */     for (int i = 0; i < this.depth; i++) {
/* 177 */       this.writer.write(this.lineIndenter);
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush() {
/* 182 */     this.writer.flush();
/*     */   }
/*     */   
/*     */   public void close() {
/* 186 */     this.writer.close();
/*     */   }
/*     */   
/*     */   public boolean isEscape() {
/* 190 */     return this.escape;
/*     */   }
/*     */   
/*     */   public void setEscape(boolean escape) {
/* 194 */     this.escape = escape;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\interceptor\debugging\PrettyPrintWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */