/*    */ package org.apache.struts2.dispatcher.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.ExecuteOperations;
/*    */ import org.apache.struts2.dispatcher.InitOperations;
/*    */ import org.apache.struts2.dispatcher.PrepareOperations;
/*    */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   private PrepareOperations prepare;
/*    */   private ExecuteOperations execute;
/*    */   
/*    */   public void init(ServletConfig filterConfig) throws ServletException {
/* 48 */     InitOperations init = new InitOperations();
/* 49 */     Dispatcher dispatcher = null;
/*    */     try {
/* 51 */       ServletHostConfig config = new ServletHostConfig(filterConfig);
/* 52 */       init.initLogging(config);
/* 53 */       dispatcher = init.initDispatcher(config);
/* 54 */       init.initStaticContentLoader(config, dispatcher);
/*    */       
/* 56 */       this.prepare = new PrepareOperations(dispatcher);
/* 57 */       this.execute = new ExecuteOperations(dispatcher);
/*    */     } finally {
/* 59 */       if (dispatcher != null) {
/* 60 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 62 */       init.cleanup();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
/*    */     try {
/* 70 */       this.prepare.createActionContext(request, response);
/* 71 */       this.prepare.assignDispatcherToThread();
/* 72 */       this.prepare.setEncodingAndLocale(request, response);
/* 73 */       request = this.prepare.wrapRequest(request);
/* 74 */       ActionMapping mapping = this.prepare.findActionMapping(request, response);
/* 75 */       if (mapping == null) {
/* 76 */         boolean handled = this.execute.executeStaticResourceRequest(request, response);
/* 77 */         if (!handled)
/* 78 */           throw new ServletException("Resource loading not supported, use the StrutsPrepareAndExecuteFilter instead."); 
/*    */       } else {
/* 80 */         this.execute.executeAction(request, response, mapping);
/*    */       } 
/*    */     } finally {
/* 83 */       this.prepare.cleanupRequest(request);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 89 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\servlet\StrutsServlet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */