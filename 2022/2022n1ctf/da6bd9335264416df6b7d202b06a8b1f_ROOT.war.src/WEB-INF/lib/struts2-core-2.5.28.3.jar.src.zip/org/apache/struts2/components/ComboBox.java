/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "combobox", tldTagClass = "org.apache.struts2.views.jsp.ui.ComboBoxTag", description = "Widget that fills a text box from a select")
/*     */ public class ComboBox
/*     */   extends TextField
/*     */ {
/*     */   public static final String TEMPLATE = "combobox";
/*     */   protected String list;
/*     */   protected String listKey;
/*     */   protected String listValue;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   protected String emptyOption;
/*     */   
/*     */   public ComboBox(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 106 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/* 110 */     return "combobox";
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/* 114 */     super.evaluateExtraParams();
/*     */     
/* 116 */     Object value = findListValue();
/*     */     
/* 118 */     if (this.headerKey != null) {
/* 119 */       addParameter("headerKey", findString(this.headerKey));
/*     */     }
/* 121 */     if (this.headerValue != null) {
/* 122 */       addParameter("headerValue", findString(this.headerValue));
/*     */     }
/* 124 */     if (this.emptyOption != null) {
/* 125 */       addParameter("emptyOption", findValue(this.emptyOption, Boolean.class));
/*     */     }
/*     */     
/* 128 */     if (value != null) {
/* 129 */       if (value instanceof Collection) {
/* 130 */         Collection tmp = (Collection)value;
/* 131 */         addParameter("list", tmp);
/* 132 */         if (this.listKey != null) {
/* 133 */           addParameter("listKey", this.listKey);
/*     */         }
/* 135 */         if (this.listValue != null) {
/* 136 */           addParameter("listValue", this.listValue);
/*     */         }
/* 138 */       } else if (value instanceof Map) {
/* 139 */         Map tmp = (Map)value;
/* 140 */         addParameter("list", MakeIterator.convert(tmp));
/* 141 */         addParameter("listKey", "key");
/* 142 */         addParameter("listValue", "value");
/*     */       } else {
/* 144 */         Iterator i = MakeIterator.convert(value);
/* 145 */         addParameter("list", i);
/* 146 */         if (this.listKey != null) {
/* 147 */           addParameter("listKey", this.listKey);
/*     */         }
/* 149 */         if (this.listValue != null) {
/* 150 */           addParameter("listValue", this.listValue);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object findListValue() {
/* 157 */     return findValue(this.list, "list", "You must specify a collection/array/map/enumeration/iterator. Example: people or people.{name}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Iterable source to populate from. If this is missing, the select widget is simply not displayed.", required = true)
/*     */   public void setList(String list) {
/* 165 */     this.list = list;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Decide if an empty option is to be inserted. Default false.")
/*     */   public void setEmptyOption(String emptyOption) {
/* 170 */     this.emptyOption = emptyOption;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the header key for the header option.")
/*     */   public void setHeaderKey(String headerKey) {
/* 175 */     this.headerKey = headerKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the header value for the header option.")
/*     */   public void setHeaderValue(String headerValue) {
/* 180 */     this.headerValue = headerValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the key used to retrieve the option key.")
/*     */   public void setListKey(String listKey) {
/* 185 */     this.listKey = listKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the value used to retrieve the option value.")
/*     */   public void setListValue(String listValue) {
/* 190 */     this.listValue = listValue;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ComboBox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */