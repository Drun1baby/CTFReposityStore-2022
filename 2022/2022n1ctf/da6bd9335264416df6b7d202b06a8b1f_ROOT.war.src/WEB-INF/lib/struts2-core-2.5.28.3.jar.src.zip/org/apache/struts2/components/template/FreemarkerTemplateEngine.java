/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import freemarker.core.ParseException;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.Template;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ import org.apache.struts2.views.freemarker.ScopesHashModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FreemarkerTemplateEngine
/*     */   extends BaseTemplateEngine
/*     */ {
/*  46 */   static Class bodyContent = null;
/*     */   protected FreemarkerManager freemarkerManager;
/*     */   
/*     */   static {
/*     */     try {
/*  51 */       bodyContent = ClassLoaderUtil.loadClass("javax.servlet.jsp.tagext.BodyContent", FreemarkerTemplateEngine.class);
/*     */     }
/*  53 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final Logger LOG = LogManager.getLogger(FreemarkerTemplateEngine.class);
/*     */   
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager mgr) {
/*  65 */     this.freemarkerManager = mgr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception {
/*  70 */     ValueStack stack = templateContext.getStack();
/*  71 */     Map context = stack.getContext();
/*  72 */     ServletContext servletContext = (ServletContext)context.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/*  73 */     HttpServletRequest req = (HttpServletRequest)context.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  74 */     HttpServletResponse res = (HttpServletResponse)context.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*     */     
/*  77 */     Configuration config = this.freemarkerManager.getConfiguration(servletContext);
/*     */ 
/*     */     
/*  80 */     List<Template> templates = templateContext.getTemplate().getPossibleTemplates(this);
/*     */ 
/*     */     
/*  83 */     Template template = null;
/*  84 */     String templateName = null;
/*  85 */     Exception exception = null;
/*  86 */     for (Template t : templates) {
/*  87 */       ParseException parseException; templateName = getFinalTemplateName(t);
/*     */       
/*     */       try {
/*  90 */         template = config.getTemplate(templateName);
/*     */         break;
/*  92 */       } catch (ParseException e) {
/*     */         
/*  94 */         parseException = e;
/*     */         break;
/*  96 */       } catch (IOException e) {
/*     */         
/*  98 */         if (parseException == null) {
/*  99 */           exception = e;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     if (template == null) {
/* 105 */       if (LOG.isErrorEnabled()) {
/* 106 */         LOG.error("Could not load the FreeMarker template named '{}':", templateContext.getTemplate().getName());
/* 107 */         for (Template t : templates) {
/* 108 */           LOG.error("Attempted: {}", getFinalTemplateName(t));
/*     */         }
/* 110 */         LOG.error("The TemplateLoader provided by the FreeMarker Configuration was a: {}", config.getTemplateLoader().getClass().getName());
/*     */       } 
/* 112 */       if (exception != null) {
/* 113 */         throw exception;
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 119 */     LOG.debug("Rendering template: {}", templateName);
/*     */     
/* 121 */     ActionInvocation ai = ActionContext.getContext().getActionInvocation();
/*     */     
/* 123 */     Object action = (ai == null) ? null : ai.getAction();
/* 124 */     if (action == null) {
/* 125 */       LOG.warn("Rendering tag {} out of Action scope, accessing directly JSPs is not recommended! Please read https://struts.apache.org/security/#never-expose-jsp-files-directly", templateName);
/*     */     }
/*     */     
/* 128 */     ScopesHashModel scopesHashModel = this.freemarkerManager.buildTemplateModel(stack, action, servletContext, req, res, config.getObjectWrapper());
/*     */     
/* 130 */     scopesHashModel.put("tag", templateContext.getTag());
/* 131 */     scopesHashModel.put("themeProperties", getThemeProps(templateContext.getTemplate()));
/*     */ 
/*     */ 
/*     */     
/* 135 */     Writer writer = templateContext.getWriter();
/* 136 */     final Writer wrapped = writer;
/* 137 */     writer = new Writer() {
/*     */         public void write(char[] cbuf, int off, int len) throws IOException {
/* 139 */           wrapped.write(cbuf, off, len);
/*     */         }
/*     */ 
/*     */         
/*     */         public void flush() throws IOException {}
/*     */ 
/*     */         
/*     */         public void close() throws IOException {
/* 147 */           wrapped.close();
/*     */         }
/*     */       };
/*     */     
/* 151 */     LOG.debug("Puts action on the top of ValueStack, just before the tag");
/* 152 */     action = stack.pop();
/* 153 */     stack.push(templateContext.getTag());
/* 154 */     stack.push(action);
/*     */     try {
/* 156 */       template.process(scopesHashModel, writer);
/*     */     } finally {
/* 158 */       stack.pop();
/* 159 */       stack.pop();
/* 160 */       stack.push(action);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String getSuffix() {
/* 165 */     return "ftl";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\FreemarkerTemplateEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */