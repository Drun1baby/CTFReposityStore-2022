/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.util.AppendIteratorFilter;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "append", tldTagClass = "org.apache.struts2.views.jsp.iterator.AppendIteratorTag", description = "Append the values of a list of iterators to one iterator")
/*     */ public class AppendIterator
/*     */   extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 118 */   private static final Logger LOG = LogManager.getLogger(AppendIterator.class);
/*     */   
/* 120 */   private AppendIteratorFilter appendIteratorFilter = null;
/*     */   private List _parameters;
/*     */   
/*     */   public AppendIterator(ValueStack stack) {
/* 124 */     super(stack);
/*     */   }
/*     */   
/*     */   public boolean start(Writer writer) {
/* 128 */     this._parameters = new ArrayList();
/* 129 */     this.appendIteratorFilter = new AppendIteratorFilter();
/*     */     
/* 131 */     return super.start(writer);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 136 */     for (Iterator paramEntries = this._parameters.iterator(); paramEntries.hasNext(); ) {
/*     */       
/* 138 */       Object iteratorEntryObj = paramEntries.next();
/* 139 */       if (!MakeIterator.isIterable(iteratorEntryObj)) {
/* 140 */         LOG.warn("param with value resolved as {} cannot be make as iterator, it will be ignored and hence will not appear in the merged iterator", iteratorEntryObj);
/*     */         continue;
/*     */       } 
/* 143 */       this.appendIteratorFilter.setSource(MakeIterator.convert(iteratorEntryObj));
/*     */     } 
/*     */     
/* 146 */     this.appendIteratorFilter.execute();
/*     */     
/* 148 */     putInContext(this.appendIteratorFilter);
/*     */     
/* 150 */     this.appendIteratorFilter = null;
/*     */     
/* 152 */     return super.end(writer, body);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParameter(Object value) {
/* 157 */     this._parameters.add(value);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The name of which if supplied will have the resultant appended iterator stored under in the stack's context")
/*     */   public void setVar(String var) {
/* 162 */     super.setVar(var);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\AppendIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */