/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.BeanSelectionProvider;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Context;
/*     */ import com.opensymphony.xwork2.inject.Factory;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBeanSelectionProvider
/*     */   implements BeanSelectionProvider
/*     */ {
/*  38 */   private static final Logger LOG = LogManager.getLogger(AbstractBeanSelectionProvider.class);
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_BEAN_NAME = "struts";
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */   
/*     */   public void loadPackages() throws ConfigurationException {}
/*     */ 
/*     */   
/*     */   public void init(Configuration configuration) throws ConfigurationException {}
/*     */ 
/*     */   
/*     */   public boolean needsReload() {
/*  55 */     return false;
/*     */   }
/*     */   
/*     */   protected void alias(Class type, String key, ContainerBuilder builder, Properties props) {
/*  59 */     alias(type, key, builder, props, Scope.SINGLETON);
/*     */   }
/*     */   
/*     */   protected void alias(Class<ObjectFactory> type, String key, ContainerBuilder builder, Properties props, Scope scope) {
/*  63 */     if (!builder.contains(type, "default")) {
/*  64 */       String foundName = props.getProperty(key, "struts");
/*  65 */       if (builder.contains(type, foundName)) {
/*  66 */         LOG.trace("Choosing bean ({}) for ({})", foundName, type.getName());
/*  67 */         builder.alias(type, foundName, "default");
/*     */       } else {
/*     */         try {
/*  70 */           Class cls = ClassLoaderUtil.loadClass(foundName, getClass());
/*  71 */           LOG.trace("Choosing bean ({}) for ({})", cls.getName(), type.getName());
/*  72 */           builder.factory(type, cls, scope);
/*  73 */         } catch (ClassNotFoundException ex) {
/*     */           
/*  75 */           LOG.trace("Choosing bean ({}) for ({}) to be loaded from the ObjectFactory", foundName, type.getName());
/*  76 */           if (!"struts".equals(foundName))
/*     */           {
/*     */             
/*  79 */             if (ObjectFactory.class != type) {
/*  80 */               builder.factory(type, new ObjectFactoryDelegateFactory(foundName, type), scope);
/*     */             } else {
/*  82 */               throw new ConfigurationException("Cannot locate the chosen ObjectFactory implementation: " + foundName);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*  88 */       LOG.warn("Unable to alias bean type ({}), default mapping already assigned.", type.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void convertIfExist(LocatableProperties props, String fromKey, String toKey) {
/*  93 */     if (props.containsKey(fromKey))
/*  94 */       props.setProperty(toKey, props.getProperty(fromKey)); 
/*     */   }
/*     */   
/*     */   static class ObjectFactoryDelegateFactory
/*     */     implements Factory
/*     */   {
/*     */     String name;
/*     */     Class type;
/*     */     
/*     */     ObjectFactoryDelegateFactory(String name, Class type) {
/* 104 */       this.name = name;
/* 105 */       this.type = type;
/*     */     }
/*     */     
/*     */     public Object create(Context context) throws Exception {
/* 109 */       ObjectFactory objFactory = (ObjectFactory)context.getContainer().getInstance(ObjectFactory.class);
/*     */       try {
/* 111 */         return objFactory.buildBean(this.name, null, true);
/* 112 */       } catch (ClassNotFoundException ex) {
/* 113 */         throw new ConfigurationException("Unable to load bean " + this.type.getName() + " (" + this.name + ")");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Class type() {
/* 119 */       return this.type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\AbstractBeanSelectionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */