/*    */ package org.apache.struts2.components.template;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.components.UIBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateRenderingContext
/*    */ {
/*    */   Template template;
/*    */   ValueStack stack;
/*    */   Map parameters;
/*    */   UIBean tag;
/*    */   Writer writer;
/*    */   
/*    */   public TemplateRenderingContext(Template template, Writer writer, ValueStack stack, Map params, UIBean tag) {
/* 48 */     this.template = template;
/* 49 */     this.writer = writer;
/* 50 */     this.stack = stack;
/* 51 */     this.parameters = params;
/* 52 */     this.tag = tag;
/*    */   }
/*    */   
/*    */   public Template getTemplate() {
/* 56 */     return this.template;
/*    */   }
/*    */   
/*    */   public ValueStack getStack() {
/* 60 */     return this.stack;
/*    */   }
/*    */   
/*    */   public Map getParameters() {
/* 64 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public UIBean getTag() {
/* 68 */     return this.tag;
/*    */   }
/*    */   
/*    */   public Writer getWriter() {
/* 72 */     return this.writer;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\TemplateRenderingContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */