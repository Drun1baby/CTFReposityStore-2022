/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.PrepareOperations;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "debug", tldTagClass = "org.apache.struts2.views.jsp.ui.DebugTag", description = "Prints debugging information (Only if 'struts.devMode' is enabled)")
/*     */ public class Debug
/*     */   extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "debug";
/*     */   protected ReflectionProvider reflectionProvider;
/*     */   
/*     */   public Debug(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  46 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/*  51 */     this.reflectionProvider = prov;
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  55 */     return "debug";
/*     */   }
/*     */   
/*     */   public boolean start(Writer writer) {
/*  59 */     boolean result = super.start(writer);
/*     */     
/*  61 */     if (showDebug()) {
/*  62 */       ValueStack stack = getStack();
/*  63 */       Iterator iter = stack.getRoot().iterator();
/*  64 */       List<DebugMapEntry> stackValues = new ArrayList(stack.getRoot().size());
/*  65 */       while (iter.hasNext()) {
/*  66 */         Map values; Object o = iter.next();
/*     */         
/*     */         try {
/*  69 */           values = this.reflectionProvider.getBeanMap(o);
/*  70 */         } catch (Exception e) {
/*  71 */           throw new StrutsException("Caught an exception while getting the property values of " + o, e);
/*     */         } 
/*  73 */         stackValues.add(new DebugMapEntry(o.getClass().getName(), values));
/*     */       } 
/*     */       
/*  76 */       addParameter("stackValues", stackValues);
/*     */     } 
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/*  83 */     if (showDebug()) {
/*  84 */       return super.end(writer, body);
/*     */     }
/*  86 */     popComponentStack();
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean showDebug() {
/*  92 */     return (this.devMode || Boolean.TRUE == PrepareOperations.getDevModeOverride());
/*     */   }
/*     */   
/*     */   private static class DebugMapEntry implements Map.Entry {
/*     */     private Object key;
/*     */     private Object value;
/*     */     
/*     */     DebugMapEntry(Object key, Object value) {
/* 100 */       this.key = key;
/* 101 */       this.value = value;
/*     */     }
/*     */     
/*     */     public Object getKey() {
/* 105 */       return this.key;
/*     */     }
/*     */     
/*     */     public Object getValue() {
/* 109 */       return this.value;
/*     */     }
/*     */     
/*     */     public Object setValue(Object newVal) {
/* 113 */       Object oldVal = this.value;
/* 114 */       this.value = newVal;
/* 115 */       return oldVal;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Debug.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */