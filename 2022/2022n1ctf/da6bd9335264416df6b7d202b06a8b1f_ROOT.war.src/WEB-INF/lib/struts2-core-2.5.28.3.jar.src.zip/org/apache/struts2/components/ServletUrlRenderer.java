/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletUrlRenderer
/*     */   implements UrlRenderer
/*     */ {
/*  47 */   private static final Logger LOG = LogManager.getLogger(ServletUrlRenderer.class);
/*     */   
/*     */   private ActionMapper actionMapper;
/*     */   private UrlHelper urlHelper;
/*     */   
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/*  54 */     this.actionMapper = mapper;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/*  59 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderUrl(Writer writer, UrlProvider urlComponent) {
/*  66 */     String result, scheme = urlComponent.getHttpServletRequest().getScheme();
/*     */     
/*  68 */     if (urlComponent.getScheme() != null) {
/*  69 */       ValueStack vs = ActionContext.getContext().getValueStack();
/*  70 */       scheme = vs.findString(urlComponent.getScheme());
/*  71 */       if (scheme == null) {
/*  72 */         scheme = urlComponent.getScheme();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  77 */     ActionInvocation ai = (ActionInvocation)ActionContext.getContext().get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/*  78 */     if (urlComponent.getValue() == null && urlComponent.getAction() != null) {
/*  79 */       result = urlComponent.determineActionURL(urlComponent.getAction(), urlComponent.getNamespace(), urlComponent.getMethod(), urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*  80 */     } else if (urlComponent.getValue() == null && urlComponent.getAction() == null && ai != null) {
/*     */ 
/*     */       
/*  83 */       String action = ai.getProxy().getActionName();
/*  84 */       String namespace = ai.getProxy().getNamespace();
/*  85 */       String method = (urlComponent.getMethod() != null || !ai.getProxy().isMethodSpecified()) ? urlComponent.getMethod() : ai.getProxy().getMethod();
/*  86 */       result = urlComponent.determineActionURL(action, namespace, method, urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*     */     } else {
/*  88 */       String _value = urlComponent.getValue();
/*     */ 
/*     */ 
/*     */       
/*  92 */       if (_value != null && _value.indexOf('?') > 0) {
/*  93 */         _value = _value.substring(0, _value.indexOf('?'));
/*     */       }
/*  95 */       result = this.urlHelper.buildUrl(_value, urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*     */     } 
/*  97 */     String anchor = urlComponent.getAnchor();
/*  98 */     if (StringUtils.isNotEmpty(anchor)) {
/*  99 */       result = result + '#' + urlComponent.findString(anchor);
/*     */     }
/*     */     
/* 102 */     if (urlComponent.isPutInContext()) {
/* 103 */       String var = urlComponent.getVar();
/* 104 */       if (StringUtils.isNotEmpty(var)) {
/* 105 */         urlComponent.putInContext(result);
/*     */ 
/*     */         
/* 108 */         urlComponent.getHttpServletRequest().setAttribute(var, result);
/*     */       } else {
/*     */         try {
/* 111 */           writer.write(result);
/* 112 */         } catch (IOException e) {
/* 113 */           throw new StrutsException("IOError: " + e.getMessage(), e);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       try {
/* 118 */         writer.write(result);
/* 119 */       } catch (IOException e) {
/* 120 */         throw new StrutsException("IOError: " + e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderFormUrl(Form formComponent) {
/* 129 */     String action, namespace = formComponent.determineNamespace(formComponent.namespace, formComponent.getStack(), formComponent.request);
/*     */ 
/*     */     
/* 132 */     ValueStack vs = ActionContext.getContext().getValueStack();
/* 133 */     String scheme = vs.findString("scheme");
/*     */     
/* 135 */     if (formComponent.action != null) {
/* 136 */       action = formComponent.findString(formComponent.action);
/*     */     }
/*     */     else {
/*     */       
/* 140 */       ActionInvocation ai = (ActionInvocation)formComponent.getStack().getContext().get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/*     */       
/* 142 */       if (ai != null) {
/* 143 */         action = ai.getProxy().getActionName();
/* 144 */         namespace = ai.getProxy().getNamespace();
/*     */       } else {
/*     */         
/* 147 */         String uri = formComponent.request.getRequestURI();
/* 148 */         action = uri.substring(uri.lastIndexOf('/'));
/*     */       } 
/*     */     } 
/*     */     
/* 152 */     Map actionParams = null;
/* 153 */     if (action != null && action.indexOf('?') > 0) {
/* 154 */       String queryString = action.substring(action.indexOf('?') + 1);
/* 155 */       actionParams = this.urlHelper.parseQueryString(queryString, false);
/* 156 */       action = action.substring(0, action.indexOf('?'));
/*     */     } 
/*     */     
/* 159 */     ActionMapping nameMapping = this.actionMapper.getMappingFromActionName(action);
/* 160 */     String actionName = nameMapping.getName();
/* 161 */     String actionMethod = nameMapping.getMethod();
/*     */     
/* 163 */     ActionConfig actionConfig = formComponent.configuration.getRuntimeConfiguration().getActionConfig(namespace, actionName);
/*     */     
/* 165 */     if (actionConfig != null) {
/*     */       
/* 167 */       ActionMapping mapping = new ActionMapping(actionName, namespace, actionMethod, formComponent.parameters);
/* 168 */       String result = this.urlHelper.buildUrl(formComponent.actionMapper.getUriFromActionMapping(mapping), formComponent.request, formComponent.response, actionParams, scheme, formComponent.includeContext, true, false, false);
/*     */       
/* 170 */       formComponent.addParameter("action", result);
/*     */ 
/*     */ 
/*     */       
/* 174 */       formComponent.addParameter("actionName", actionName);
/*     */       try {
/* 176 */         Class clazz = formComponent.objectFactory.getClassInstance(actionConfig.getClassName());
/* 177 */         formComponent.addParameter("actionClass", clazz);
/* 178 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */       
/* 182 */       formComponent.addParameter("namespace", namespace);
/*     */ 
/*     */       
/* 185 */       if (formComponent.name == null) {
/* 186 */         formComponent.addParameter("name", actionName);
/*     */       }
/*     */ 
/*     */       
/* 190 */       if (formComponent.getId() == null && actionName != null) {
/* 191 */         formComponent.addParameter("id", formComponent.escape(actionName));
/*     */       }
/* 193 */     } else if (action != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       if (namespace != null && LOG.isWarnEnabled()) {
/* 201 */         LOG.warn("No configuration found for the specified action: '{}' in namespace: '{}'. Form action defaulting to 'action' attribute's literal value.", actionName, namespace);
/*     */       }
/*     */       
/* 204 */       String result = this.urlHelper.buildUrl(action, formComponent.request, formComponent.response, actionParams, scheme, formComponent.includeContext, true);
/* 205 */       formComponent.addParameter("action", result);
/*     */ 
/*     */       
/* 208 */       int slash = result.lastIndexOf('/');
/* 209 */       if (slash != -1) {
/* 210 */         formComponent.addParameter("namespace", result.substring(0, slash));
/*     */       } else {
/* 212 */         formComponent.addParameter("namespace", "");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 217 */       String id = formComponent.getId();
/* 218 */       if (id == null) {
/* 219 */         slash = result.lastIndexOf('/');
/* 220 */         int dot = result.indexOf('.', slash);
/* 221 */         if (dot != -1) {
/* 222 */           id = result.substring(slash + 1, dot);
/*     */         } else {
/* 224 */           id = result.substring(slash + 1);
/*     */         } 
/* 226 */         formComponent.addParameter("id", formComponent.escape(id));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     formComponent.evaluateClientSideJsEnablement(actionName, namespace, actionMethod);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeRenderUrl(UrlProvider urlComponent) {
/* 238 */     if (urlComponent.getValue() != null) {
/* 239 */       urlComponent.setValue(urlComponent.findString(urlComponent.getValue()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 246 */       String includeParams = (urlComponent.getUrlIncludeParams() != null) ? urlComponent.getUrlIncludeParams().toLowerCase() : "get";
/*     */       
/* 248 */       if (urlComponent.getIncludeParams() != null) {
/* 249 */         includeParams = urlComponent.findString(urlComponent.getIncludeParams());
/*     */       }
/*     */       
/* 252 */       if ("none".equalsIgnoreCase(includeParams)) {
/* 253 */         mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), Collections.emptyMap());
/* 254 */       } else if ("all".equalsIgnoreCase(includeParams)) {
/* 255 */         mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), urlComponent.getHttpServletRequest().getParameterMap());
/*     */ 
/*     */         
/* 258 */         includeGetParameters(urlComponent);
/* 259 */         includeExtraParameters(urlComponent);
/* 260 */       } else if ("get".equalsIgnoreCase(includeParams) || (includeParams == null && urlComponent.getValue() == null && urlComponent.getAction() == null)) {
/* 261 */         includeGetParameters(urlComponent);
/* 262 */         includeExtraParameters(urlComponent);
/* 263 */       } else if (includeParams != null) {
/* 264 */         LOG.warn("Unknown value for includeParams parameter to URL tag: {}", includeParams);
/*     */       } 
/* 266 */     } catch (Exception e) {
/* 267 */       LOG.warn("Unable to put request parameters ({}) into parameter map.", urlComponent.getHttpServletRequest().getQueryString(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void includeExtraParameters(UrlProvider urlComponent) {
/* 272 */     if (urlComponent.getExtraParameterProvider() != null) {
/* 273 */       mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), urlComponent.getExtraParameterProvider().getExtraParameters());
/*     */     }
/*     */   }
/*     */   
/*     */   private void includeGetParameters(UrlProvider urlComponent) {
/* 278 */     String query = extractQueryString(urlComponent);
/* 279 */     mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), this.urlHelper.parseQueryString(query, false));
/*     */   }
/*     */ 
/*     */   
/*     */   private String extractQueryString(UrlProvider urlComponent) {
/* 284 */     String query = urlComponent.getHttpServletRequest().getQueryString();
/* 285 */     if (query == null) {
/* 286 */       query = (String)urlComponent.getHttpServletRequest().getAttribute("javax.servlet.forward.query_string");
/*     */     }
/*     */     
/* 289 */     if (query != null) {
/*     */       
/* 291 */       int idx = query.lastIndexOf('#');
/*     */       
/* 293 */       if (idx != -1) {
/* 294 */         query = query.substring(0, idx);
/*     */       }
/*     */     } 
/* 297 */     return query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mergeRequestParameters(String value, Map<String, Object> parameters, Map<String, Object> contextParameters) {
/* 318 */     Map<String, Object> mergedParams = new LinkedHashMap<>(contextParameters);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     if (StringUtils.contains(value, "?")) {
/* 325 */       String queryString = value.substring(value.indexOf('?') + 1);
/*     */       
/* 327 */       mergedParams = this.urlHelper.parseQueryString(queryString, false);
/* 328 */       for (Map.Entry<String, Object> entry : contextParameters.entrySet()) {
/* 329 */         if (!mergedParams.containsKey(entry.getKey())) {
/* 330 */           mergedParams.put(entry.getKey(), entry.getValue());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     for (Map.Entry<String, Object> entry : mergedParams.entrySet()) {
/* 342 */       if (!parameters.containsKey(entry.getKey()))
/* 343 */         parameters.put(entry.getKey(), entry.getValue()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ServletUrlRenderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */