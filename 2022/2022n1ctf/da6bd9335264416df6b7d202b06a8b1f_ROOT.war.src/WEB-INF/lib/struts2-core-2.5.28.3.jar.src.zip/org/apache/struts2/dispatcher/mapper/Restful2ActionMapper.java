/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.HashMap;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.util.URLDecoderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Restful2ActionMapper
/*     */   extends DefaultActionMapper
/*     */ {
/*  39 */   protected static final Logger LOG = LogManager.getLogger(Restful2ActionMapper.class);
/*     */   public static final String HTTP_METHOD_PARAM = "__http_method";
/*  41 */   private String idParameterName = null;
/*     */   
/*     */   public Restful2ActionMapper() {
/*  44 */     setSlashesInActionNames("true");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager) {
/*  53 */     if (!isSlashesInActionNames()) {
/*  54 */       throw new IllegalStateException("This action mapper requires the setting 'slashesInActionNames' to be set to 'true'");
/*     */     }
/*  56 */     ActionMapping mapping = super.getMapping(request, configManager);
/*     */     
/*  58 */     if (mapping == null) {
/*  59 */       return null;
/*     */     }
/*     */     
/*  62 */     String actionName = mapping.getName();
/*  63 */     String id = null;
/*     */ 
/*     */     
/*  66 */     if (StringUtils.isNotBlank(actionName)) {
/*     */       
/*  68 */       int lastSlashPos = actionName.lastIndexOf('/');
/*  69 */       if (lastSlashPos > -1) {
/*  70 */         id = actionName.substring(lastSlashPos + 1);
/*     */       }
/*     */ 
/*     */       
/*  74 */       if (mapping.getMethod() == null) {
/*     */         
/*  76 */         if (lastSlashPos == actionName.length() - 1) {
/*     */ 
/*     */           
/*  79 */           if (isGet(request)) {
/*  80 */             mapping.setMethod("index");
/*     */           
/*     */           }
/*  83 */           else if (isPost(request)) {
/*  84 */             mapping.setMethod("create");
/*     */           }
/*     */         
/*  87 */         } else if (lastSlashPos > -1) {
/*     */           
/*  89 */           if (isGet(request) && "new".equals(id)) {
/*  90 */             mapping.setMethod("editNew");
/*     */           
/*     */           }
/*  93 */           else if (isGet(request)) {
/*  94 */             mapping.setMethod("view");
/*     */           
/*     */           }
/*  97 */           else if (isDelete(request)) {
/*  98 */             mapping.setMethod("remove");
/*     */           
/*     */           }
/* 101 */           else if (isPut(request)) {
/* 102 */             mapping.setMethod("update");
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 107 */         if (this.idParameterName != null && lastSlashPos > -1) {
/* 108 */           actionName = actionName.substring(0, lastSlashPos);
/*     */         }
/*     */       } 
/*     */       
/* 112 */       if (this.idParameterName != null && id != null) {
/* 113 */         if (mapping.getParams() == null) {
/* 114 */           mapping.setParams(new HashMap<>());
/*     */         }
/* 116 */         mapping.getParams().put(this.idParameterName, id);
/*     */       } 
/*     */ 
/*     */       
/* 120 */       int actionSlashPos = actionName.lastIndexOf('/', lastSlashPos - 1);
/* 121 */       if (actionSlashPos > 0 && actionSlashPos < lastSlashPos) {
/* 122 */         String params = actionName.substring(0, actionSlashPos);
/* 123 */         HashMap<String, String> parameters = new HashMap<>();
/*     */         try {
/* 125 */           StringTokenizer st = new StringTokenizer(params, "/");
/* 126 */           boolean isNameTok = true;
/* 127 */           String paramName = null;
/*     */ 
/*     */           
/* 130 */           while (st.hasMoreTokens()) {
/* 131 */             if (isNameTok) {
/* 132 */               paramName = URLDecoderUtil.decode(st.nextToken(), "UTF-8");
/* 133 */               isNameTok = false; continue;
/*     */             } 
/* 135 */             String paramValue = URLDecoderUtil.decode(st.nextToken(), "UTF-8");
/*     */             
/* 137 */             if (paramName != null && paramName.length() > 0) {
/* 138 */               parameters.put(paramName, paramValue);
/*     */             }
/*     */             
/* 141 */             isNameTok = true;
/*     */           } 
/*     */           
/* 144 */           if (parameters.size() > 0) {
/* 145 */             if (mapping.getParams() == null) {
/* 146 */               mapping.setParams(new HashMap<>());
/*     */             }
/* 148 */             mapping.getParams().putAll(parameters);
/*     */           } 
/* 150 */         } catch (Exception e) {
/* 151 */           LOG.warn("Unable to determine parameters from the url", e);
/*     */         } 
/* 153 */         mapping.setName(actionName.substring(actionSlashPos + 1));
/*     */       } 
/*     */     } 
/*     */     
/* 157 */     return mapping;
/*     */   }
/*     */   
/*     */   protected boolean isGet(HttpServletRequest request) {
/* 161 */     return "get".equalsIgnoreCase(request.getMethod());
/*     */   }
/*     */   
/*     */   protected boolean isPost(HttpServletRequest request) {
/* 165 */     return "post".equalsIgnoreCase(request.getMethod());
/*     */   }
/*     */   
/*     */   protected boolean isPut(HttpServletRequest request) {
/* 169 */     if ("put".equalsIgnoreCase(request.getMethod())) {
/* 170 */       return true;
/*     */     }
/* 172 */     return (isPost(request) && "put".equalsIgnoreCase(request.getParameter("__http_method")));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isDelete(HttpServletRequest request) {
/* 177 */     if ("delete".equalsIgnoreCase(request.getMethod())) {
/* 178 */       return true;
/*     */     }
/* 180 */     return (isPost(request) && "delete".equalsIgnoreCase(request.getParameter("__http_method")));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdParameterName() {
/* 185 */     return this.idParameterName;
/*     */   }
/*     */   
/*     */   @Inject(required = false, value = "struts.mapper.idParameterName")
/*     */   public void setIdParameterName(String idParameterName) {
/* 190 */     this.idParameterName = idParameterName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\Restful2ActionMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */