/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemFactory;
/*     */ import org.apache.commons.fileupload.FileUploadBase;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.RequestContext;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.LocalizedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JakartaMultiPartRequest
/*     */   extends AbstractMultiPartRequest
/*     */ {
/*  44 */   static final Logger LOG = LogManager.getLogger(JakartaMultiPartRequest.class);
/*     */ 
/*     */   
/*  47 */   protected Map<String, List<FileItem>> files = new HashMap<>();
/*     */ 
/*     */   
/*  50 */   protected Map<String, List<String>> params = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(HttpServletRequest request, String saveDir) throws IOException {
/*     */     try {
/*  62 */       setLocale(request);
/*  63 */       processUpload(request, saveDir);
/*  64 */     } catch (FileUploadException e) {
/*  65 */       LocalizedMessage errorMessage; LOG.warn("Request exceeded size limit!", (Throwable)e);
/*     */       
/*  67 */       if (e instanceof FileUploadBase.SizeLimitExceededException) {
/*  68 */         FileUploadBase.SizeLimitExceededException ex = (FileUploadBase.SizeLimitExceededException)e;
/*  69 */         errorMessage = buildErrorMessage((Throwable)e, new Object[] { Long.valueOf(ex.getPermittedSize()), Long.valueOf(ex.getActualSize()) });
/*     */       } else {
/*  71 */         errorMessage = buildErrorMessage((Throwable)e, new Object[0]);
/*     */       } 
/*     */       
/*  74 */       if (!this.errors.contains(errorMessage)) {
/*  75 */         this.errors.add(errorMessage);
/*     */       }
/*  77 */     } catch (Exception e) {
/*  78 */       LOG.warn("Unable to parse request", e);
/*  79 */       LocalizedMessage errorMessage = buildErrorMessage(e, new Object[0]);
/*  80 */       if (!this.errors.contains(errorMessage)) {
/*  81 */         this.errors.add(errorMessage);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void processUpload(HttpServletRequest request, String saveDir) throws FileUploadException, UnsupportedEncodingException {
/*  87 */     if (ServletFileUpload.isMultipartContent(request)) {
/*  88 */       for (FileItem item : parseRequest(request, saveDir)) {
/*  89 */         LOG.debug("Found file item: [{}]", item.getFieldName());
/*  90 */         if (item.isFormField()) {
/*  91 */           processNormalFormField(item, request.getCharacterEncoding()); continue;
/*     */         } 
/*  93 */         processFileField(item);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void processFileField(FileItem item) {
/*     */     List<FileItem> values;
/* 100 */     LOG.debug("Item is a file upload");
/*     */ 
/*     */     
/* 103 */     if (item.getName() == null || item.getName().trim().length() < 1) {
/* 104 */       LOG.debug("No file has been uploaded for the field: {}", item.getFieldName());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 109 */     if (this.files.get(item.getFieldName()) != null) {
/* 110 */       values = this.files.get(item.getFieldName());
/*     */     } else {
/* 112 */       values = new ArrayList<>();
/*     */     } 
/*     */     
/* 115 */     values.add(item);
/* 116 */     this.files.put(item.getFieldName(), values);
/*     */   }
/*     */   protected void processNormalFormField(FileItem item, String charset) throws UnsupportedEncodingException {
/*     */     List<String> values;
/* 120 */     LOG.debug("Item is a normal form field");
/*     */ 
/*     */     
/* 123 */     if (this.params.get(item.getFieldName()) != null) {
/* 124 */       values = this.params.get(item.getFieldName());
/*     */     } else {
/* 126 */       values = new ArrayList<>();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (charset != null) {
/* 134 */       values.add(item.getString(charset));
/*     */     } else {
/* 136 */       values.add(item.getString());
/*     */     } 
/* 138 */     this.params.put(item.getFieldName(), values);
/* 139 */     item.delete();
/*     */   }
/*     */   
/*     */   protected List<FileItem> parseRequest(HttpServletRequest servletRequest, String saveDir) throws FileUploadException {
/* 143 */     DiskFileItemFactory fac = createDiskFileItemFactory(saveDir);
/* 144 */     ServletFileUpload upload = createServletFileUpload(fac);
/* 145 */     return upload.parseRequest(createRequestContext(servletRequest));
/*     */   }
/*     */   
/*     */   protected ServletFileUpload createServletFileUpload(DiskFileItemFactory fac) {
/* 149 */     ServletFileUpload upload = new ServletFileUpload((FileItemFactory)fac);
/* 150 */     upload.setSizeMax(this.maxSize);
/* 151 */     return upload;
/*     */   }
/*     */   
/*     */   protected DiskFileItemFactory createDiskFileItemFactory(String saveDir) {
/* 155 */     DiskFileItemFactory fac = new DiskFileItemFactory();
/*     */     
/* 157 */     fac.setSizeThreshold(0);
/* 158 */     if (saveDir != null) {
/* 159 */       fac.setRepository(new File(saveDir));
/*     */     }
/* 161 */     return fac;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getFileParameterNames() {
/* 168 */     return Collections.enumeration(this.files.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getContentType(String fieldName) {
/* 175 */     List<FileItem> items = this.files.get(fieldName);
/*     */     
/* 177 */     if (items == null) {
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     List<String> contentTypes = new ArrayList<>(items.size());
/* 182 */     for (FileItem fileItem : items) {
/* 183 */       contentTypes.add(fileItem.getContentType());
/*     */     }
/*     */     
/* 186 */     return contentTypes.<String>toArray(new String[contentTypes.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UploadedFile[] getFile(String fieldName) {
/* 193 */     List<FileItem> items = this.files.get(fieldName);
/*     */     
/* 195 */     if (items == null) {
/* 196 */       return null;
/*     */     }
/*     */     
/* 199 */     List<UploadedFile> fileList = new ArrayList<>(items.size());
/* 200 */     for (FileItem fileItem : items) {
/* 201 */       File storeLocation = ((DiskFileItem)fileItem).getStoreLocation();
/* 202 */       if (fileItem.isInMemory() && storeLocation != null && !storeLocation.exists()) {
/*     */         try {
/* 204 */           storeLocation.createNewFile();
/* 205 */         } catch (IOException e) {
/* 206 */           LOG.error("Cannot write uploaded empty file to disk: {}", storeLocation.getAbsolutePath(), e);
/*     */         } 
/*     */       }
/* 209 */       fileList.add(new StrutsUploadedFile(storeLocation));
/*     */     } 
/*     */     
/* 212 */     return fileList.<UploadedFile>toArray(new UploadedFile[fileList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFileNames(String fieldName) {
/* 219 */     List<FileItem> items = this.files.get(fieldName);
/*     */     
/* 221 */     if (items == null) {
/* 222 */       return null;
/*     */     }
/*     */     
/* 225 */     List<String> fileNames = new ArrayList<>(items.size());
/* 226 */     for (FileItem fileItem : items) {
/* 227 */       fileNames.add(getCanonicalName(fileItem.getName()));
/*     */     }
/*     */     
/* 230 */     return fileNames.<String>toArray(new String[fileNames.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFilesystemName(String fieldName) {
/* 237 */     List<FileItem> items = this.files.get(fieldName);
/*     */     
/* 239 */     if (items == null) {
/* 240 */       return null;
/*     */     }
/*     */     
/* 243 */     List<String> fileNames = new ArrayList<>(items.size());
/* 244 */     for (FileItem fileItem : items) {
/* 245 */       fileNames.add(((DiskFileItem)fileItem).getStoreLocation().getName());
/*     */     }
/*     */     
/* 248 */     return fileNames.<String>toArray(new String[fileNames.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 255 */     List<String> v = this.params.get(name);
/* 256 */     if (v != null && v.size() > 0) {
/* 257 */       return v.get(0);
/*     */     }
/*     */     
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getParameterNames() {
/* 267 */     return Collections.enumeration(this.params.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 274 */     List<String> v = this.params.get(name);
/* 275 */     if (v != null && v.size() > 0) {
/* 276 */       return v.<String>toArray(new String[v.size()]);
/*     */     }
/*     */     
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RequestContext createRequestContext(final HttpServletRequest req) {
/* 289 */     return new RequestContext() {
/*     */         public String getCharacterEncoding() {
/* 291 */           return req.getCharacterEncoding();
/*     */         }
/*     */         
/*     */         public String getContentType() {
/* 295 */           return req.getContentType();
/*     */         }
/*     */         
/*     */         public int getContentLength() {
/* 299 */           return req.getContentLength();
/*     */         }
/*     */         
/*     */         public InputStream getInputStream() throws IOException {
/* 303 */           ServletInputStream servletInputStream = req.getInputStream();
/* 304 */           if (servletInputStream == null) {
/* 305 */             throw new IOException("Missing content in the request");
/*     */           }
/* 307 */           return (InputStream)req.getInputStream();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 316 */     Set<String> names = this.files.keySet();
/* 317 */     for (String name : names) {
/* 318 */       List<FileItem> items = this.files.get(name);
/* 319 */       for (FileItem item : items) {
/* 320 */         LOG.debug("Removing file {} {}", name, item);
/* 321 */         if (!item.isInMemory())
/* 322 */           item.delete(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\multipart\JakartaMultiPartRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */