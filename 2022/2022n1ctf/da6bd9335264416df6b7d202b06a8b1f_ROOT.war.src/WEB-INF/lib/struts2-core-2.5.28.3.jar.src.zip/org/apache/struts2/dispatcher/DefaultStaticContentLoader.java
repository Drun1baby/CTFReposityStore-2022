/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultStaticContentLoader
/*     */   implements StaticContentLoader
/*     */ {
/*  71 */   private Logger LOG = LogManager.getLogger(DefaultStaticContentLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> pathPrefixes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean serveStatic;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean serveStaticBrowserCache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   protected final Calendar lastModifiedCal = Calendar.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean devMode;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.serve.static")
/*     */   public void setServeStaticContent(String serveStaticContent) {
/* 108 */     this.serveStatic = BooleanUtils.toBoolean(serveStaticContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.serve.static.browserCache")
/*     */   public void setServeStaticBrowserCache(String serveStaticBrowserCache) {
/* 120 */     this.serveStaticBrowserCache = BooleanUtils.toBoolean(serveStaticBrowserCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setEncoding(String encoding) {
/* 129 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String devMode) {
/* 134 */     this.devMode = Boolean.parseBoolean(devMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHostConfig(HostConfig filterConfig) {
/* 143 */     String param = filterConfig.getInitParameter("packages");
/* 144 */     String packages = getAdditionalPackages();
/* 145 */     if (param != null) {
/* 146 */       packages = param + " " + packages;
/*     */     }
/* 148 */     this.pathPrefixes = parse(packages);
/*     */   }
/*     */   
/*     */   protected String getAdditionalPackages() {
/* 152 */     List<String> packages = new LinkedList<>();
/* 153 */     packages.add("org.apache.struts2.static");
/* 154 */     packages.add("template");
/* 155 */     packages.add("static");
/*     */     
/* 157 */     if (this.devMode) {
/* 158 */       packages.add("org.apache.struts2.interceptor.debugging");
/*     */     }
/*     */     
/* 161 */     return StringUtils.join(packages.iterator(), ' ');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> parse(String packages) {
/* 172 */     if (packages == null) {
/* 173 */       return Collections.emptyList();
/*     */     }
/* 175 */     List<String> pathPrefixes = new ArrayList<>();
/*     */     
/* 177 */     StringTokenizer st = new StringTokenizer(packages, ", \n\t");
/* 178 */     while (st.hasMoreTokens()) {
/* 179 */       String pathPrefix = st.nextToken().replace('.', '/');
/* 180 */       if (!pathPrefix.endsWith("/")) {
/* 181 */         pathPrefix = pathPrefix + "/";
/*     */       }
/* 183 */       pathPrefixes.add(pathPrefix);
/*     */     } 
/*     */     
/* 186 */     return pathPrefixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findStaticResource(String path, HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 198 */     String name = cleanupPath(path);
/* 199 */     for (String pathPrefix : this.pathPrefixes) {
/* 200 */       URL resourceUrl = findResource(buildPath(name, pathPrefix));
/* 201 */       if (resourceUrl != null) {
/* 202 */         InputStream is = null;
/*     */         
/*     */         try {
/* 205 */           String pathEnding = buildPath(name, pathPrefix);
/* 206 */           if (resourceUrl.getFile().endsWith(pathEnding))
/* 207 */             is = resourceUrl.openStream(); 
/* 208 */         } catch (IOException ex) {
/*     */           continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 214 */         if (is != null) {
/* 215 */           process(is, path, request, response);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     try {
/* 222 */       response.sendError(404);
/* 223 */     } catch (IOException e1) {
/*     */       
/* 225 */       this.LOG.warn("Unable to send error response, code: {};", Integer.valueOf(404), e1);
/* 226 */     } catch (IllegalStateException ise) {
/*     */       
/* 228 */       this.LOG.warn("Unable to send error response, code: {}; isCommited: {};", Integer.valueOf(404), Boolean.valueOf(response.isCommitted()), ise);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void process(InputStream is, String path, HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 233 */     if (is != null) {
/* 234 */       Calendar cal = Calendar.getInstance();
/*     */ 
/*     */       
/* 237 */       long ifModifiedSince = 0L;
/*     */       try {
/* 239 */         ifModifiedSince = request.getDateHeader("If-Modified-Since");
/* 240 */       } catch (Exception e) {
/* 241 */         this.LOG.warn("Invalid If-Modified-Since header value: '{}', ignoring", request.getHeader("If-Modified-Since"));
/*     */       } 
/* 243 */       long lastModifiedMillis = this.lastModifiedCal.getTimeInMillis();
/* 244 */       long now = cal.getTimeInMillis();
/* 245 */       cal.add(5, 1);
/* 246 */       long expires = cal.getTimeInMillis();
/*     */       
/* 248 */       if (ifModifiedSince > 0L && ifModifiedSince <= lastModifiedMillis) {
/*     */ 
/*     */         
/* 251 */         response.setDateHeader("Expires", expires);
/* 252 */         response.setStatus(304);
/* 253 */         is.close();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 258 */       String contentType = getContentType(path);
/* 259 */       if (contentType != null) {
/* 260 */         response.setContentType(contentType);
/*     */       }
/*     */       
/* 263 */       if (this.serveStaticBrowserCache) {
/*     */         
/* 265 */         response.setDateHeader("Date", now);
/* 266 */         response.setDateHeader("Expires", expires);
/* 267 */         response.setDateHeader("Retry-After", expires);
/* 268 */         response.setHeader("Cache-Control", "public");
/* 269 */         response.setDateHeader("Last-Modified", lastModifiedMillis);
/*     */       } else {
/* 271 */         response.setHeader("Cache-Control", "no-cache");
/* 272 */         response.setHeader("Pragma", "no-cache");
/* 273 */         response.setHeader("Expires", "-1");
/*     */       } 
/*     */       
/*     */       try {
/* 277 */         copy(is, (OutputStream)response.getOutputStream());
/*     */       } finally {
/* 279 */         is.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URL findResource(String path) throws IOException {
/* 292 */     return ClassLoaderUtil.getResource(path, getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildPath(String name, String packagePrefix) throws UnsupportedEncodingException {
/*     */     String resourcePath;
/* 303 */     if (packagePrefix.endsWith("/") && name.startsWith("/")) {
/* 304 */       resourcePath = packagePrefix + name.substring(1);
/*     */     } else {
/* 306 */       resourcePath = packagePrefix + name;
/*     */     } 
/*     */     
/* 309 */     return URLDecoder.decode(resourcePath, this.encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getContentType(String name) {
/* 323 */     if (name.endsWith(".js"))
/* 324 */       return "text/javascript"; 
/* 325 */     if (name.endsWith(".css"))
/* 326 */       return "text/css"; 
/* 327 */     if (name.endsWith(".html"))
/* 328 */       return "text/html"; 
/* 329 */     if (name.endsWith(".txt"))
/* 330 */       return "text/plain"; 
/* 331 */     if (name.endsWith(".gif"))
/* 332 */       return "image/gif"; 
/* 333 */     if (name.endsWith(".jpg") || name.endsWith(".jpeg"))
/* 334 */       return "image/jpeg"; 
/* 335 */     if (name.endsWith(".png")) {
/* 336 */       return "image/png";
/*     */     }
/* 338 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copy(InputStream input, OutputStream output) throws IOException {
/* 353 */     byte[] buffer = new byte[4096];
/*     */     int n;
/* 355 */     while (-1 != (n = input.read(buffer))) {
/* 356 */       output.write(buffer, 0, n);
/*     */     }
/* 358 */     output.flush();
/*     */   }
/*     */   
/*     */   public boolean canHandle(String resourcePath) {
/* 362 */     return (this.serveStatic && (resourcePath.startsWith("/struts/") || resourcePath.startsWith("/static/")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String cleanupPath(String path) {
/* 371 */     return path.substring(7);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\DefaultStaticContentLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */