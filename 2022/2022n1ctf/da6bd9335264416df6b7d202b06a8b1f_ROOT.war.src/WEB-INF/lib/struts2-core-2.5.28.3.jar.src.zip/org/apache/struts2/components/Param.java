/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "param", tldTagClass = "org.apache.struts2.views.jsp.ParamTag", description = "Parametrize other tags")
/*     */ public class Param
/*     */   extends Component
/*     */ {
/*     */   protected String name;
/*     */   protected String value;
/*     */   protected boolean suppressEmptyParameters;
/*     */   
/*     */   public Param(ValueStack stack) {
/* 119 */     super(stack);
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 123 */     Component component = findAncestor(Component.class);
/* 124 */     if (this.value != null) {
/* 125 */       if (component instanceof UnnamedParametric) {
/* 126 */         ((UnnamedParametric)component).addParameter(findValue(this.value));
/*     */       } else {
/* 128 */         String name = findString(this.name);
/*     */         
/* 130 */         if (name == null) {
/* 131 */           throw new StrutsException("No name found for following expression: " + this.name);
/*     */         }
/*     */         
/* 134 */         Object value = findValue(this.value);
/* 135 */         if (this.suppressEmptyParameters) {
/* 136 */           if (value != null && StringUtils.isNotBlank(value.toString())) {
/* 137 */             component.addParameter(name, value);
/*     */           } else {
/* 139 */             component.addParameter(name, null);
/*     */           } 
/* 141 */         } else if (value == null || StringUtils.isBlank(value.toString())) {
/* 142 */           component.addParameter(name, "");
/*     */         } else {
/* 144 */           component.addParameter(name, value);
/*     */         }
/*     */       
/*     */       } 
/* 148 */     } else if (component instanceof UnnamedParametric) {
/* 149 */       ((UnnamedParametric)component).addParameter(body);
/*     */     }
/* 151 */     else if (!this.suppressEmptyParameters || !StringUtils.isBlank(body)) {
/* 152 */       component.addParameter(findString(this.name), body);
/*     */     } else {
/* 154 */       component.addParameter(findString(this.name), null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 159 */     return super.end(writer, "");
/*     */   }
/*     */   
/*     */   public boolean usesBody() {
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Name of Parameter to set")
/*     */   public void setName(String name) {
/* 168 */     this.name = name;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Value expression for Parameter to set", defaultValue = "The value of evaluating provided name against stack")
/*     */   public void setValue(String value) {
/* 173 */     this.value = value;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to suppress empty parameters", type = "Boolean", defaultValue = "false")
/*     */   public void setSuppressEmptyParameters(boolean suppressEmptyParameters) {
/* 178 */     this.suppressEmptyParameters = suppressEmptyParameters;
/*     */   }
/*     */   
/*     */   public static interface UnnamedParametric {
/*     */     void addParameter(Object param1Object);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Param.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */