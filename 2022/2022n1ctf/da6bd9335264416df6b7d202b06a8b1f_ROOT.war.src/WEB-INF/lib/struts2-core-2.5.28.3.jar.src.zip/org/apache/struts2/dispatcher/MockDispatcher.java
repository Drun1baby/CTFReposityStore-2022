/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MockDispatcher
/*    */   extends Dispatcher
/*    */ {
/*    */   private final ConfigurationManager copyConfigurationManager;
/*    */   
/*    */   public MockDispatcher(ServletContext servletContext, Map<String, String> context, ConfigurationManager configurationManager) {
/* 32 */     super(servletContext, context);
/* 33 */     this.copyConfigurationManager = configurationManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public void init() {
/* 38 */     super.init();
/* 39 */     ContainerHolder.clear();
/* 40 */     this.configurationManager = this.copyConfigurationManager;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\MockDispatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */