/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultActionSupport
/*    */   extends ActionSupport
/*    */ {
/*    */   private static final long serialVersionUID = -2426166391283746095L;
/*    */   private String successResultValue;
/*    */   
/*    */   public String execute() throws Exception {
/* 48 */     HttpServletRequest request = ServletActionContext.getRequest();
/* 49 */     String requestedUrl = request.getPathInfo();
/* 50 */     if (this.successResultValue == null) this.successResultValue = requestedUrl; 
/* 51 */     return "success";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSuccessResultValue() {
/* 58 */     return this.successResultValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSuccessResultValue(String successResultValue) {
/* 65 */     this.successResultValue = successResultValue;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\DefaultActionSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */