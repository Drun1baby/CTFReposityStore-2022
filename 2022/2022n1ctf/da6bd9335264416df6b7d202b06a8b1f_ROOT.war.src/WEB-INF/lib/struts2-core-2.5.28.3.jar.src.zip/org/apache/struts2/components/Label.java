/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.util.TextProviderHelper;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "label", tldTagClass = "org.apache.struts2.views.jsp.ui.LabelTag", description = "Render a label that displays read-only information", allowDynamicAttributes = true)
/*    */ public class Label
/*    */   extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "label";
/*    */   protected String forAttr;
/*    */   
/*    */   public Label(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 66 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 70 */     return "label";
/*    */   }
/*    */   
/*    */   protected void evaluateExtraParams() {
/* 74 */     super.evaluateExtraParams();
/*    */     
/* 76 */     if (this.forAttr != null) {
/* 77 */       addParameter("for", findString(this.forAttr));
/*    */     }
/*    */ 
/*    */     
/* 81 */     if (this.value != null) {
/* 82 */       addParameter("nameValue", findString(this.value));
/* 83 */     } else if (this.key != null) {
/* 84 */       Object nameValue = this.parameters.get("nameValue");
/* 85 */       if (nameValue == null || nameValue.toString().length() == 0) {
/*    */         
/* 87 */         String providedLabel = TextProviderHelper.getText(this.key, this.key, this.stack);
/* 88 */         addParameter("nameValue", providedLabel);
/*    */       } 
/* 90 */     } else if (this.name != null) {
/* 91 */       String expr = completeExpressionIfAltSyntax(this.name);
/* 92 */       addParameter("nameValue", findString(expr));
/*    */     } 
/*    */   }
/*    */   
/*    */   @StrutsTagAttribute(description = " HTML for attribute")
/*    */   public void setFor(String forAttr) {
/* 98 */     this.forAttr = forAttr;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Label.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */