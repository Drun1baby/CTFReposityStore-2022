/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.struts2.interceptor.ParameterAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpParameters
/*     */   implements Map<String, Parameter>, Cloneable
/*     */ {
/*     */   private Map<String, Parameter> parameters;
/*     */   
/*     */   private HttpParameters(Map<String, Parameter> parameters) {
/*  39 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public static Builder create(Map<String, ?> requestParameterMap) {
/*  43 */     return new Builder(requestParameterMap);
/*     */   }
/*     */   
/*     */   public static Builder create() {
/*  47 */     return new Builder(new HashMap<>());
/*     */   }
/*     */   
/*     */   public HttpParameters remove(Set<String> paramsToRemove) {
/*  51 */     for (String paramName : paramsToRemove) {
/*  52 */       this.parameters.remove(paramName);
/*     */     }
/*  54 */     return this;
/*     */   }
/*     */   
/*     */   public HttpParameters remove(final String paramToRemove) {
/*  58 */     return remove(new HashSet<String>() {
/*     */         
/*     */         });
/*     */   }
/*     */   
/*     */   public boolean contains(String name) {
/*  64 */     return this.parameters.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Map<String, String[]> toMap() {
/*  74 */     Map<String, String[]> result = (Map)new HashMap<>(this.parameters.size());
/*  75 */     for (Map.Entry<String, Parameter> entry : this.parameters.entrySet()) {
/*  76 */       result.put(entry.getKey(), ((Parameter)entry.getValue()).getMultipleValues());
/*     */     }
/*  78 */     return result;
/*     */   }
/*     */   
/*     */   public HttpParameters appendAll(Map<String, Parameter> newParams) {
/*  82 */     this.parameters.putAll(newParams);
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public void applyParameters(ParameterAware parameterAware) {
/*  87 */     parameterAware.setParameters(toMap());
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  92 */     return this.parameters.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  97 */     return this.parameters.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 102 */     return this.parameters.containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 107 */     return this.parameters.containsValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Parameter get(Object key) {
/* 112 */     if (this.parameters.containsKey(key)) {
/* 113 */       return this.parameters.get(key);
/*     */     }
/* 115 */     return new Parameter.Empty(String.valueOf(key));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Parameter put(String key, Parameter value) {
/* 121 */     throw new IllegalAccessError("HttpParameters are immutable, you cannot put value directly!");
/*     */   }
/*     */ 
/*     */   
/*     */   public Parameter remove(Object key) {
/* 126 */     throw new IllegalAccessError("HttpParameters are immutable, you cannot remove object directly!");
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends Parameter> m) {
/* 131 */     throw new IllegalAccessError("HttpParameters are immutable, you cannot put values directly!");
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 136 */     throw new IllegalAccessError("HttpParameters are immutable, you cannot clear values directly!");
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 141 */     return Collections.unmodifiableSet(new TreeSet<>(this.parameters.keySet()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Parameter> values() {
/* 146 */     return Collections.unmodifiableCollection(this.parameters.values());
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Parameter>> entrySet() {
/* 151 */     return Collections.unmodifiableSet(this.parameters.entrySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 156 */     return this.parameters.toString();
/*     */   }
/*     */   
/*     */   public static class Builder {
/*     */     private Map<String, Object> requestParameterMap;
/*     */     private HttpParameters parent;
/*     */     
/*     */     protected Builder(Map<String, ?> requestParameterMap) {
/* 164 */       this.requestParameterMap = new HashMap<>();
/* 165 */       this.requestParameterMap.putAll(requestParameterMap);
/*     */     }
/*     */     
/*     */     public Builder withParent(HttpParameters parentParams) {
/* 169 */       if (parentParams != null) {
/* 170 */         this.parent = parentParams;
/*     */       }
/* 172 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withExtraParams(Map<String, ?> params) {
/* 176 */       if (params != null) {
/* 177 */         this.requestParameterMap.putAll(params);
/*     */       }
/* 179 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withComparator(Comparator<String> orderedComparator) {
/* 183 */       this.requestParameterMap = new TreeMap<>(orderedComparator);
/* 184 */       return this;
/*     */     }
/*     */     
/*     */     public HttpParameters build() {
/* 188 */       Map<String, Parameter> parameters = (this.parent == null) ? new HashMap<>() : new HashMap<>(this.parent.parameters);
/*     */ 
/*     */ 
/*     */       
/* 192 */       for (Map.Entry<String, Object> entry : this.requestParameterMap.entrySet()) {
/* 193 */         String name = entry.getKey();
/* 194 */         Object value = entry.getValue();
/* 195 */         if (value instanceof Parameter) {
/* 196 */           parameters.put(name, (Parameter)value); continue;
/*     */         } 
/* 198 */         parameters.put(name, new Parameter.Request(name, value));
/*     */       } 
/*     */ 
/*     */       
/* 202 */       return new HttpParameters(parameters);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public HttpParameters buildNoNestedWrapping() {
/* 212 */       Map<String, Parameter> parameters = (this.parent == null) ? new HashMap<>() : new HashMap<>(this.parent.parameters);
/*     */ 
/*     */ 
/*     */       
/* 216 */       for (Map.Entry<String, Object> entry : this.requestParameterMap.entrySet()) {
/* 217 */         String name = entry.getKey();
/* 218 */         Object value = entry.getValue();
/* 219 */         Parameter parameterValue = (value instanceof Parameter) ? (Parameter)value : new Parameter.Request(name, value);
/*     */ 
/*     */         
/* 222 */         parameters.put(name, parameterValue);
/*     */       } 
/*     */       
/* 225 */       return new HttpParameters(parameters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\HttpParameters.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */