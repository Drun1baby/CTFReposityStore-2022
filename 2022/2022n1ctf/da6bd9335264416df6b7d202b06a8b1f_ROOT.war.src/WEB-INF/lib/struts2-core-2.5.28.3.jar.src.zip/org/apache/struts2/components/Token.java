/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.TokenHelper;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "token", tldTagClass = "org.apache.struts2.views.jsp.ui.TokenTag", description = "Stop double-submission of forms")
/*     */ public class Token
/*     */   extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "token";
/*     */   
/*     */   public Token(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  59 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  63 */     return "token";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluateExtraParams() {
/*     */     String tokenName;
/*  73 */     super.evaluateExtraParams();
/*     */ 
/*     */     
/*  76 */     Map parameters = getParameters();
/*     */     
/*  78 */     if (parameters.containsKey("name")) {
/*  79 */       tokenName = (String)parameters.get("name");
/*     */     } else {
/*  81 */       if (this.name == null) {
/*  82 */         tokenName = "token";
/*     */       } else {
/*  84 */         tokenName = findString(this.name);
/*     */         
/*  86 */         if (tokenName == null) {
/*  87 */           tokenName = this.name;
/*     */         }
/*     */       } 
/*     */       
/*  91 */       addParameter("name", tokenName);
/*     */     } 
/*     */     
/*  94 */     String token = buildToken(tokenName);
/*  95 */     addParameter("token", token);
/*  96 */     addParameter("tokenNameField", "struts.token.name");
/*     */   }
/*     */   
/*     */   private String buildToken(String name) {
/* 100 */     Map<String, Object> context = this.stack.getContext();
/* 101 */     Object myToken = context.get(name);
/*     */     
/* 103 */     if (myToken == null) {
/* 104 */       myToken = TokenHelper.setToken(name);
/* 105 */       context.put(name, myToken);
/*     */     } 
/*     */     
/* 108 */     return myToken.toString();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Token.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */