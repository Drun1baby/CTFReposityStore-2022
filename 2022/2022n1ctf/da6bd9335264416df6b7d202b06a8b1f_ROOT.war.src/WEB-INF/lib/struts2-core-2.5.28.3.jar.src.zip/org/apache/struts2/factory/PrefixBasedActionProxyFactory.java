/*     */ package org.apache.struts2.factory;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Initializable;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixBasedActionProxyFactory
/*     */   extends StrutsActionProxyFactory
/*     */   implements Initializable
/*     */ {
/*  64 */   private static final Logger LOG = LogManager.getLogger(PrefixBasedActionProxyFactory.class);
/*     */   
/*  66 */   private Map<String, ActionProxyFactory> actionProxyFactories = new HashMap<>();
/*  67 */   private Set<String> prefixes = new HashSet<>();
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  71 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject("struts.mapper.prefixMapping")
/*     */   public void setPrefixBasedActionProxyFactories(String list) {
/*  76 */     if (list != null) {
/*  77 */       this.prefixes = new HashSet<>(Arrays.asList(list.split(",")));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  83 */     for (String factory : this.prefixes) {
/*  84 */       String[] thisFactory = factory.split(":");
/*  85 */       if (thisFactory.length == 2) {
/*  86 */         String factoryPrefix = thisFactory[0].trim();
/*  87 */         String factoryName = thisFactory[1].trim();
/*  88 */         ActionProxyFactory obj = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class, factoryName);
/*  89 */         if (obj != null) {
/*  90 */           this.actionProxyFactories.put(factoryPrefix, obj); continue;
/*     */         } 
/*  92 */         LOG.warn("Invalid PrefixBasedActionProxyFactory config entry: [{}]", factory);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionProxy createActionProxy(String namespace, String actionName, String methodName, Map<String, Object> extraContext, boolean executeResult, boolean cleanupContext) {
/* 101 */     String uri = namespace + (namespace.endsWith("/") ? actionName : ("/" + actionName)); int lastIndex;
/* 102 */     for (lastIndex = uri.lastIndexOf('/'); lastIndex > -1; lastIndex = uri.lastIndexOf('/', lastIndex - 1)) {
/* 103 */       String key = uri.substring(0, lastIndex);
/* 104 */       ActionProxyFactory actionProxyFactory = this.actionProxyFactories.get(key);
/* 105 */       if (actionProxyFactory != null) {
/* 106 */         LOG.debug("Using ActionProxyFactory [{}] for prefix [{}]", actionProxyFactory, key);
/* 107 */         return actionProxyFactory.createActionProxy(namespace, actionName, methodName, extraContext, executeResult, cleanupContext);
/*     */       } 
/* 109 */       LOG.debug("No ActionProxyFactory defined for [{}]", key);
/*     */     } 
/*     */     
/* 112 */     LOG.debug("Cannot find any matching ActionProxyFactory, falling back to [{}]", getClass().getName());
/* 113 */     return super.createActionProxy(namespace, actionName, methodName, extraContext, executeResult, cleanupContext);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\factory\PrefixBasedActionProxyFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */