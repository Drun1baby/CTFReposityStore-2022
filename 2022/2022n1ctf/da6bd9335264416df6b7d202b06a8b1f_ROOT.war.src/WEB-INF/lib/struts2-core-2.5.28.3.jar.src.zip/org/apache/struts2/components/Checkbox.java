/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "checkbox", tldTagClass = "org.apache.struts2.views.jsp.ui.CheckboxTag", description = "Render a checkbox input field", allowDynamicAttributes = true)
/*     */ public class Checkbox
/*     */   extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "checkbox";
/*     */   protected String fieldValue;
/*     */   
/*     */   public Checkbox(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  62 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   protected String getDefaultTemplate() {
/*  66 */     return "checkbox";
/*     */   }
/*     */   
/*     */   protected void evaluateExtraParams() {
/*  70 */     if (this.fieldValue != null) {
/*  71 */       addParameter("fieldValue", findString(this.fieldValue));
/*     */     } else {
/*  73 */       addParameter("fieldValue", "true");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Class getValueClassType() {
/*  78 */     return Boolean.class;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The actual HTML value attribute of the checkbox.", defaultValue = "true")
/*     */   public void setFieldValue(String fieldValue) {
/*  83 */     this.fieldValue = fieldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @StrutsTagAttribute(description = "(Deprecated) Define label position of form element (top/left), also 'right' is supported when using 'xhtml' theme")
/*     */   public void setLabelposition(String labelPosition) {
/*  94 */     super.setLabelposition(labelPosition);
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Define label position of form element (top/left), also 'right' is supported when using 'xhtml' theme")
/*     */   public void setLabelPosition(String labelPosition) {
/* 100 */     super.setLabelPosition(labelPosition);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Checkbox.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */