/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DoubleListUIBean
/*     */   extends ListUIBean
/*     */ {
/*     */   protected String emptyOption;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   protected String multiple;
/*     */   protected String size;
/*     */   protected String doubleList;
/*     */   protected String doubleListKey;
/*     */   protected String doubleListValue;
/*     */   protected String doubleListCssClass;
/*     */   protected String doubleListCssStyle;
/*     */   protected String doubleListTitle;
/*     */   protected String doubleName;
/*     */   protected String doubleValue;
/*     */   protected String formName;
/*     */   protected String doubleId;
/*     */   protected String doubleDisabled;
/*     */   protected String doubleMultiple;
/*     */   protected String doubleSize;
/*     */   protected String doubleHeaderKey;
/*     */   protected String doubleHeaderValue;
/*     */   protected String doubleEmptyOption;
/*     */   protected String doubleCssClass;
/*     */   protected String doubleCssStyle;
/*     */   protected String doubleOnclick;
/*     */   protected String doubleOndblclick;
/*     */   protected String doubleOnmousedown;
/*     */   protected String doubleOnmouseup;
/*     */   protected String doubleOnmouseover;
/*     */   protected String doubleOnmousemove;
/*     */   protected String doubleOnmouseout;
/*     */   protected String doubleOnfocus;
/*     */   protected String doubleOnblur;
/*     */   protected String doubleOnkeypress;
/*     */   protected String doubleOnkeydown;
/*     */   protected String doubleOnkeyup;
/*     */   protected String doubleOnselect;
/*     */   protected String doubleOnchange;
/*     */   protected String doubleAccesskey;
/*     */   
/*     */   public DoubleListUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  91 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   public void evaluateExtraParams() {
/*  95 */     super.evaluateExtraParams();
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (this.emptyOption != null) {
/* 100 */       addParameter("emptyOption", findValue(this.emptyOption, Boolean.class));
/*     */     }
/*     */     
/* 103 */     if (this.multiple != null) {
/* 104 */       addParameter("multiple", findValue(this.multiple, Boolean.class));
/*     */     }
/*     */     
/* 107 */     if (this.size != null) {
/* 108 */       addParameter("size", findString(this.size));
/*     */     }
/*     */     
/* 111 */     if (this.headerKey != null && this.headerValue != null) {
/* 112 */       addParameter("headerKey", findString(this.headerKey));
/* 113 */       addParameter("headerValue", findString(this.headerValue));
/*     */     } 
/*     */ 
/*     */     
/* 117 */     if (this.doubleMultiple != null) {
/* 118 */       addParameter("doubleMultiple", findValue(this.doubleMultiple, Boolean.class));
/*     */     }
/*     */     
/* 121 */     if (this.doubleSize != null) {
/* 122 */       addParameter("doubleSize", findString(this.doubleSize));
/*     */     }
/*     */     
/* 125 */     if (this.doubleDisabled != null) {
/* 126 */       addParameter("doubleDisabled", findValue(this.doubleDisabled, Boolean.class));
/*     */     }
/*     */     
/* 129 */     if (this.doubleName != null) {
/* 130 */       addParameter("doubleName", findString(this.doubleName));
/*     */     }
/*     */     
/* 133 */     if (this.doubleList != null) {
/* 134 */       addParameter("doubleList", this.doubleList);
/*     */     }
/*     */     
/* 137 */     Object tmpDoubleList = findValue(this.doubleList);
/* 138 */     if (this.doubleListKey != null) {
/* 139 */       addParameter("doubleListKey", this.doubleListKey);
/* 140 */     } else if (tmpDoubleList instanceof java.util.Map) {
/* 141 */       addParameter("doubleListKey", "key");
/*     */     } 
/*     */     
/* 144 */     if (this.doubleListValue != null) {
/* 145 */       this.doubleListValue = stripExpressionIfAltSyntax(this.doubleListValue);
/*     */       
/* 147 */       addParameter("doubleListValue", this.doubleListValue);
/* 148 */     } else if (tmpDoubleList instanceof java.util.Map) {
/* 149 */       addParameter("doubleListValue", "value");
/*     */     } 
/* 151 */     if (this.doubleListCssClass != null) {
/* 152 */       addParameter("doubleListCssClass", findString(this.doubleListCssClass));
/*     */     }
/* 154 */     if (this.doubleListCssStyle != null) {
/* 155 */       addParameter("doubleListCssStyle", findString(this.doubleListCssStyle));
/*     */     }
/* 157 */     if (this.doubleListTitle != null) {
/* 158 */       addParameter("doubleListTitle", findString(this.doubleListTitle));
/*     */     }
/*     */ 
/*     */     
/* 162 */     if (this.formName != null) {
/* 163 */       addParameter("formName", findString(this.formName));
/*     */     } else {
/*     */       
/* 166 */       Component component = findAncestor(Form.class);
/* 167 */       if (component != null) {
/* 168 */         addParameter("formName", component.getParameters().get("name"));
/*     */       }
/*     */     } 
/*     */     
/* 172 */     Class valueClazz = getValueClassType();
/*     */     
/* 174 */     if (valueClazz != null) {
/* 175 */       if (this.doubleValue != null) {
/* 176 */         addParameter("doubleNameValue", findValue(this.doubleValue, valueClazz));
/* 177 */       } else if (this.doubleName != null) {
/* 178 */         addParameter("doubleNameValue", findValue(this.doubleName, valueClazz));
/*     */       }
/*     */     
/* 181 */     } else if (this.doubleValue != null) {
/* 182 */       addParameter("doubleNameValue", findValue(this.doubleValue));
/* 183 */     } else if (this.doubleName != null) {
/* 184 */       addParameter("doubleNameValue", findValue(this.doubleName));
/*     */     } 
/*     */ 
/*     */     
/* 188 */     Form form = (Form)findAncestor(Form.class);
/* 189 */     if (this.doubleId != null) {
/*     */       
/* 191 */       addParameter("doubleId", findStringIfAltSyntax(this.doubleId));
/* 192 */     } else if (form != null) {
/* 193 */       addParameter("doubleId", (new StringBuilder()).append(form.getParameters().get("id")).append("_").append(escape((this.doubleName != null) ? findString(this.doubleName) : null)).toString());
/*     */     } else {
/* 195 */       addParameter("doubleId", escape((this.doubleName != null) ? findString(this.doubleName) : null));
/*     */     } 
/*     */     
/* 198 */     if (this.doubleOnclick != null) {
/* 199 */       addParameter("doubleOnclick", findString(this.doubleOnclick));
/*     */     }
/*     */     
/* 202 */     if (this.doubleOndblclick != null) {
/* 203 */       addParameter("doubleOndblclick", findString(this.doubleOndblclick));
/*     */     }
/*     */     
/* 206 */     if (this.doubleOnmousedown != null) {
/* 207 */       addParameter("doubleOnmousedown", findString(this.doubleOnmousedown));
/*     */     }
/*     */     
/* 210 */     if (this.doubleOnmouseup != null) {
/* 211 */       addParameter("doubleOnmouseup", findString(this.doubleOnmouseup));
/*     */     }
/*     */     
/* 214 */     if (this.doubleOnmouseover != null) {
/* 215 */       addParameter("doubleOnmouseover", findString(this.doubleOnmouseover));
/*     */     }
/*     */     
/* 218 */     if (this.doubleOnmousemove != null) {
/* 219 */       addParameter("doubleOnmousemove", findString(this.doubleOnmousemove));
/*     */     }
/*     */     
/* 222 */     if (this.doubleOnmouseout != null) {
/* 223 */       addParameter("doubleOnmouseout", findString(this.doubleOnmouseout));
/*     */     }
/*     */     
/* 226 */     if (this.doubleOnfocus != null) {
/* 227 */       addParameter("doubleOnfocus", findString(this.doubleOnfocus));
/*     */     }
/*     */     
/* 230 */     if (this.doubleOnblur != null) {
/* 231 */       addParameter("doubleOnblur", findString(this.doubleOnblur));
/*     */     }
/*     */     
/* 234 */     if (this.doubleOnkeypress != null) {
/* 235 */       addParameter("doubleOnkeypress", findString(this.doubleOnkeypress));
/*     */     }
/*     */     
/* 238 */     if (this.doubleOnkeydown != null) {
/* 239 */       addParameter("doubleOnkeydown", findString(this.doubleOnkeydown));
/*     */     }
/*     */     
/* 242 */     if (this.doubleOnselect != null) {
/* 243 */       addParameter("doubleOnselect", findString(this.doubleOnselect));
/*     */     }
/*     */     
/* 246 */     if (this.doubleOnchange != null) {
/* 247 */       addParameter("doubleOnchange", findString(this.doubleOnchange));
/*     */     }
/*     */     
/* 250 */     if (this.doubleCssClass != null) {
/* 251 */       addParameter("doubleCss", findString(this.doubleCssClass));
/*     */     }
/*     */     
/* 254 */     if (this.doubleCssStyle != null) {
/* 255 */       addParameter("doubleStyle", findString(this.doubleCssStyle));
/*     */     }
/*     */     
/* 258 */     if (this.doubleHeaderKey != null && this.doubleHeaderValue != null) {
/* 259 */       addParameter("doubleHeaderKey", findString(this.doubleHeaderKey));
/* 260 */       addParameter("doubleHeaderValue", findString(this.doubleHeaderValue));
/*     */     } 
/*     */     
/* 263 */     if (this.doubleEmptyOption != null) {
/* 264 */       addParameter("doubleEmptyOption", findValue(this.doubleEmptyOption, Boolean.class));
/*     */     }
/*     */     
/* 267 */     if (this.doubleAccesskey != null) {
/* 268 */       addParameter("doubleAccesskey", findString(this.doubleAccesskey));
/*     */     }
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The second iterable source to populate from.", required = true)
/*     */   public void setDoubleList(String doubleList) {
/* 274 */     this.doubleList = doubleList;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The key expression to use for second list")
/*     */   public void setDoubleListKey(String doubleListKey) {
/* 279 */     this.doubleListKey = doubleListKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The value expression to use for second list")
/*     */   public void setDoubleListValue(String doubleListValue) {
/* 284 */     this.doubleListValue = doubleListValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of second list objects to get css class from")
/*     */   public void setDoubleListCssClass(String doubleListCssClass) {
/* 289 */     this.doubleListCssClass = doubleListCssClass;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of second list objects to get css style from")
/*     */   public void setDoubleListCssStyle(String doubleListCssStyle) {
/* 294 */     this.doubleListCssStyle = doubleListCssStyle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Property of second list objects to get title from")
/*     */   public void setDoubleListTitle(String doubleListTitle) {
/* 299 */     this.doubleListTitle = doubleListTitle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The name for complete component", required = true)
/*     */   public void setDoubleName(String doubleName) {
/* 304 */     this.doubleName = doubleName;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The value expression for complete component")
/*     */   public void setDoubleValue(String doubleValue) {
/* 309 */     this.doubleValue = doubleValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The form name this component resides in and populates to")
/*     */   public void setFormName(String formName) {
/* 314 */     this.formName = formName;
/*     */   }
/*     */   
/*     */   public String getFormName() {
/* 318 */     return this.formName;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The css class for the second list")
/*     */   public void setDoubleCssClass(String doubleCssClass) {
/* 323 */     this.doubleCssClass = doubleCssClass;
/*     */   }
/*     */   
/*     */   public String getDoubleCssClass() {
/* 327 */     return this.doubleCssClass;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The css style for the second list")
/*     */   public void setDoubleCssStyle(String doubleCssStyle) {
/* 332 */     this.doubleCssStyle = doubleCssStyle;
/*     */   }
/*     */   
/*     */   public String getDoubleCssStyle() {
/* 336 */     return this.doubleCssStyle;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The header key for the second list")
/*     */   public void setDoubleHeaderKey(String doubleHeaderKey) {
/* 341 */     this.doubleHeaderKey = doubleHeaderKey;
/*     */   }
/*     */   
/*     */   public String getDoubleHeaderKey() {
/* 345 */     return this.doubleHeaderKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The header value for the second list")
/*     */   public void setDoubleHeaderValue(String doubleHeaderValue) {
/* 350 */     this.doubleHeaderValue = doubleHeaderValue;
/*     */   }
/*     */   
/*     */   public String getDoubleHeaderValue() {
/* 354 */     return this.doubleHeaderValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Decides if the second list will add an empty option")
/*     */   public void setDoubleEmptyOption(String doubleEmptyOption) {
/* 359 */     this.doubleEmptyOption = doubleEmptyOption;
/*     */   }
/*     */   
/*     */   public String getDoubleEmptyOption() {
/* 363 */     return this.doubleEmptyOption;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDoubleDisabled() {
/* 368 */     return this.doubleDisabled;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Decides if a disable attribute should be added to the second list")
/*     */   public void setDoubleDisabled(String doubleDisabled) {
/* 373 */     this.doubleDisabled = doubleDisabled;
/*     */   }
/*     */   
/*     */   public String getDoubleId() {
/* 377 */     return this.doubleId;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The id of the second list")
/*     */   public void setDoubleId(String doubleId) {
/* 382 */     this.doubleId = doubleId;
/*     */   }
/*     */   
/*     */   public String getDoubleMultiple() {
/* 386 */     return this.doubleMultiple;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = " Decides if multiple attribute should be set on the second list")
/*     */   public void setDoubleMultiple(String doubleMultiple) {
/* 391 */     this.doubleMultiple = doubleMultiple;
/*     */   }
/*     */   
/*     */   public String getDoubleOnblur() {
/* 395 */     return this.doubleOnblur;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onblur attribute of the second list")
/*     */   public void setDoubleOnblur(String doubleOnblur) {
/* 400 */     this.doubleOnblur = doubleOnblur;
/*     */   }
/*     */   
/*     */   public String getDoubleOnchange() {
/* 404 */     return this.doubleOnchange;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onchange attribute of the second list")
/*     */   public void setDoubleOnchange(String doubleOnchange) {
/* 409 */     this.doubleOnchange = doubleOnchange;
/*     */   }
/*     */   
/*     */   public String getDoubleOnclick() {
/* 413 */     return this.doubleOnclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onclick attribute of the second list")
/*     */   public void setDoubleOnclick(String doubleOnclick) {
/* 418 */     this.doubleOnclick = doubleOnclick;
/*     */   }
/*     */   
/*     */   public String getDoubleOndblclick() {
/* 422 */     return this.doubleOndblclick;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the ondbclick attribute of the second list")
/*     */   public void setDoubleOndblclick(String doubleOndblclick) {
/* 427 */     this.doubleOndblclick = doubleOndblclick;
/*     */   }
/*     */   
/*     */   public String getDoubleOnfocus() {
/* 431 */     return this.doubleOnfocus;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onfocus attribute of the second list")
/*     */   public void setDoubleOnfocus(String doubleOnfocus) {
/* 436 */     this.doubleOnfocus = doubleOnfocus;
/*     */   }
/*     */   
/*     */   public String getDoubleOnkeydown() {
/* 440 */     return this.doubleOnkeydown;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onkeydown attribute of the second list")
/*     */   public void setDoubleOnkeydown(String doubleOnkeydown) {
/* 445 */     this.doubleOnkeydown = doubleOnkeydown;
/*     */   }
/*     */   
/*     */   public String getDoubleOnkeypress() {
/* 449 */     return this.doubleOnkeypress;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onkeypress attribute of the second list")
/*     */   public void setDoubleOnkeypress(String doubleOnkeypress) {
/* 454 */     this.doubleOnkeypress = doubleOnkeypress;
/*     */   }
/*     */   
/*     */   public String getDoubleOnkeyup() {
/* 458 */     return this.doubleOnkeyup;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onkeyup attribute of the second list")
/*     */   public void setDoubleOnkeyup(String doubleOnkeyup) {
/* 463 */     this.doubleOnkeyup = doubleOnkeyup;
/*     */   }
/*     */   
/*     */   public String getDoubleOnmousedown() {
/* 467 */     return this.doubleOnmousedown;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onmousedown attribute of the second list")
/*     */   public void setDoubleOnmousedown(String doubleOnmousedown) {
/* 472 */     this.doubleOnmousedown = doubleOnmousedown;
/*     */   }
/*     */   
/*     */   public String getDoubleOnmousemove() {
/* 476 */     return this.doubleOnmousemove;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onmousemove attribute of the second list")
/*     */   public void setDoubleOnmousemove(String doubleOnmousemove) {
/* 481 */     this.doubleOnmousemove = doubleOnmousemove;
/*     */   }
/*     */   
/*     */   public String getDoubleOnmouseout() {
/* 485 */     return this.doubleOnmouseout;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onmouseout attribute of the second list")
/*     */   public void setDoubleOnmouseout(String doubleOnmouseout) {
/* 490 */     this.doubleOnmouseout = doubleOnmouseout;
/*     */   }
/*     */   
/*     */   public String getDoubleOnmouseover() {
/* 494 */     return this.doubleOnmouseover;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onmouseover attribute of the second list")
/*     */   public void setDoubleOnmouseover(String doubleOnmouseover) {
/* 499 */     this.doubleOnmouseover = doubleOnmouseover;
/*     */   }
/*     */   
/*     */   public String getDoubleOnmouseup() {
/* 503 */     return this.doubleOnmouseup;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onmouseup attribute of the second list")
/*     */   public void setDoubleOnmouseup(String doubleOnmouseup) {
/* 508 */     this.doubleOnmouseup = doubleOnmouseup;
/*     */   }
/*     */   
/*     */   public String getDoubleOnselect() {
/* 512 */     return this.doubleOnselect;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the onselect attribute of the second list")
/*     */   public void setDoubleOnselect(String doubleOnselect) {
/* 517 */     this.doubleOnselect = doubleOnselect;
/*     */   }
/*     */   
/*     */   public String getDoubleSize() {
/* 521 */     return this.doubleSize;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the size attribute of the second list")
/*     */   public void setDoubleSize(String doubleSize) {
/* 526 */     this.doubleSize = doubleSize;
/*     */   }
/*     */   
/*     */   public String getDoubleList() {
/* 530 */     return this.doubleList;
/*     */   }
/*     */   
/*     */   public String getDoubleListKey() {
/* 534 */     return this.doubleListKey;
/*     */   }
/*     */   
/*     */   public String getDoubleListValue() {
/* 538 */     return this.doubleListValue;
/*     */   }
/*     */   
/*     */   public String getDoubleName() {
/* 542 */     return this.doubleName;
/*     */   }
/*     */   
/*     */   public String getDoubleValue() {
/* 546 */     return this.doubleValue;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Decides of an empty option is to be inserted in the second list", type = "Boolean", defaultValue = "false")
/*     */   public void setEmptyOption(String emptyOption) {
/* 551 */     this.emptyOption = emptyOption;
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the header key of the second list. Must not be empty! '-1' and '' is correct, '' is bad.")
/*     */   public void setHeaderKey(String headerKey) {
/* 557 */     this.headerKey = headerKey;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = " Set the header value of the second list")
/*     */   public void setHeaderValue(String headerValue) {
/* 562 */     this.headerValue = headerValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "Creates a multiple select. The tag will pre-select multiple values if the values are passed as an Array (of appropriate types) via the value attribute.")
/*     */   public void setMultiple(String multiple) {
/* 570 */     this.multiple = multiple;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Size of the element box (# of elements to show)", type = "Integer")
/*     */   public void setSize(String size) {
/* 575 */     this.size = size;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set the html accesskey attribute.")
/*     */   public void setDoubleAccesskey(String doubleAccesskey) {
/* 580 */     this.doubleAccesskey = doubleAccesskey;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\DoubleListUIBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */