/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "fielderror", tldTagClass = "org.apache.struts2.views.jsp.ui.FieldErrorTag", description = "Render field error (all or partial depending on param tag nested)if they exists")
/*     */ public class FieldError
/*     */   extends UIBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/*  90 */   private List<String> errorFieldNames = new ArrayList<>();
/*     */   private boolean escape = true;
/*     */   
/*     */   public FieldError(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  94 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   private static final String TEMPLATE = "fielderror";
/*     */   
/*     */   protected String getDefaultTemplate() {
/* 100 */     return "fielderror";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void evaluateExtraParams() {
/* 105 */     super.evaluateExtraParams();
/*     */     
/* 107 */     if (this.errorFieldNames != null) {
/* 108 */       addParameter("errorFieldNames", this.errorFieldNames);
/*     */     }
/* 110 */     addParameter("escape", Boolean.valueOf(this.escape));
/*     */   }
/*     */   
/*     */   public void addParameter(Object value) {
/* 114 */     if (value != null) {
/* 115 */       this.errorFieldNames.add(value.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public List<String> getFieldErrorFieldNames() {
/* 120 */     return this.errorFieldNames;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Field name for single field attribute usage", type = "String")
/*     */   public void setFieldName(String fieldName) {
/* 125 */     addParameter(fieldName);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = " Whether to escape HTML", type = "Boolean", defaultValue = "true")
/*     */   public void setEscape(boolean escape) {
/* 130 */     this.escape = escape;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\FieldError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */