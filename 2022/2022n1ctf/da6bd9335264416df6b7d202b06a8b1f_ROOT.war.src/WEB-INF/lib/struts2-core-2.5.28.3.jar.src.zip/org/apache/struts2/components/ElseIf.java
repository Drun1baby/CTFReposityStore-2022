/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "elseif", tldTagClass = "org.apache.struts2.views.jsp.ElseIfTag", description = "Elseif tag")
/*     */ public class ElseIf
/*     */   extends Component
/*     */ {
/*     */   protected Boolean answer;
/*     */   protected String test;
/*     */   
/*     */   public ElseIf(ValueStack stack) {
/*  65 */     super(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean start(Writer writer) {
/*  72 */     Boolean ifResult = (Boolean)this.stack.getContext().get("struts.if.answer");
/*     */     
/*  74 */     if (ifResult == null || ifResult.booleanValue()) {
/*  75 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  79 */     this.answer = (Boolean)findValue(this.test, Boolean.class);
/*     */     
/*  81 */     if (this.answer == null) {
/*  82 */       this.answer = Boolean.FALSE;
/*     */     }
/*  84 */     if (this.answer.booleanValue()) {
/*  85 */       this.stack.getContext().put("struts.if.answer", this.answer);
/*     */     }
/*  87 */     return this.answer.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/*  91 */     if (this.answer == null) {
/*  92 */       this.answer = Boolean.FALSE;
/*     */     }
/*  94 */     if (this.answer.booleanValue()) {
/*  95 */       this.stack.getContext().put("struts.if.answer", this.answer);
/*     */     }
/*  97 */     return super.end(writer, "");
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Expression to determine if body of tag is to be displayed", type = "Boolean", required = true)
/*     */   public void setTest(String test) {
/* 102 */     this.test = test;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\ElseIf.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */