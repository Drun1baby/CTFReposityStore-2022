/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.util.MergeIteratorFilter;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "merge", tldTagClass = "org.apache.struts2.views.jsp.iterator.MergeIteratorTag", description = "Merge the values of a list of iterators into one iterator")
/*     */ public class MergeIterator
/*     */   extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 131 */   private static final Logger LOG = LogManager.getLogger(MergeIterator.class);
/*     */   
/* 133 */   private MergeIteratorFilter mergeIteratorFilter = null;
/*     */   private List _parameters;
/*     */   
/*     */   public MergeIterator(ValueStack stack) {
/* 137 */     super(stack);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean start(Writer writer) {
/* 142 */     this.mergeIteratorFilter = new MergeIteratorFilter();
/* 143 */     this._parameters = new ArrayList();
/*     */     
/* 145 */     return super.start(writer);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 150 */     for (Object iteratorEntryObj : this._parameters) {
/* 151 */       if (!MakeIterator.isIterable(iteratorEntryObj)) {
/* 152 */         LOG.warn("param with value resolved as {} cannot be make as iterator, it will be ignored and hence will not appear in the merged iterator", iteratorEntryObj);
/*     */         continue;
/*     */       } 
/* 155 */       this.mergeIteratorFilter.setSource(MakeIterator.convert(iteratorEntryObj));
/*     */     } 
/*     */     
/* 158 */     this.mergeIteratorFilter.execute();
/*     */ 
/*     */     
/* 161 */     putInContext(this.mergeIteratorFilter);
/*     */     
/* 163 */     this.mergeIteratorFilter = null;
/*     */     
/* 165 */     return super.end(writer, body);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The name where the resultant merged iterator will be stored in the stack's context")
/*     */   public void setVar(String var) {
/* 170 */     super.setVar(var);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addParameter(Object value) {
/* 175 */     this._parameters.add(value);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\MergeIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */