/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  48 */   private static final Logger LOG = LogManager.getLogger(CompositeActionMapper.class);
/*     */   
/*  50 */   protected List<ActionMapper> actionMappers = new LinkedList<>();
/*     */ 
/*     */   
/*     */   @Inject
/*     */   public CompositeActionMapper(Container container, @Inject("struts.mapper.composite") String list) {
/*  55 */     String[] arr = StringUtils.split(StringUtils.trimToEmpty(list), ",");
/*  56 */     for (String name : arr) {
/*  57 */       Object obj = container.getInstance(ActionMapper.class, name);
/*  58 */       if (obj != null) {
/*  59 */         this.actionMappers.add((ActionMapper)obj);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager) {
/*  66 */     for (ActionMapper actionMapper : this.actionMappers) {
/*  67 */       ActionMapping actionMapping = actionMapper.getMapping(request, configManager);
/*  68 */       LOG.debug("Using ActionMapper: {}", actionMapper);
/*  69 */       if (actionMapping == null) {
/*  70 */         LOG.debug("ActionMapper {} failed to return an ActionMapping (null)", actionMapper);
/*     */         continue;
/*     */       } 
/*  73 */       return actionMapping;
/*     */     } 
/*     */     
/*  76 */     LOG.debug("exhausted from ActionMapper that could return an ActionMapping");
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ActionMapping getMappingFromActionName(String actionName) {
/*  82 */     for (ActionMapper actionMapper : this.actionMappers) {
/*  83 */       ActionMapping actionMapping = actionMapper.getMappingFromActionName(actionName);
/*  84 */       LOG.debug("Using ActionMapper: {}", actionMapper);
/*  85 */       if (actionMapping == null) {
/*  86 */         LOG.debug("ActionMapper {} failed to return an ActionMapping (null)", actionMapper);
/*     */         continue;
/*     */       } 
/*  89 */       return actionMapping;
/*     */     } 
/*     */     
/*  92 */     LOG.debug("exhausted from ActionMapper that could return an ActionMapping");
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUriFromActionMapping(ActionMapping mapping) {
/*  98 */     for (ActionMapper actionMapper : this.actionMappers) {
/*  99 */       String uri = actionMapper.getUriFromActionMapping(mapping);
/* 100 */       LOG.debug("Using ActionMapper: {}", actionMapper);
/* 101 */       if (uri == null) {
/* 102 */         LOG.debug("ActionMapper {} failed to return an ActionMapping (null)", actionMapper);
/*     */         continue;
/*     */       } 
/* 105 */       return uri;
/*     */     } 
/*     */     
/* 108 */     LOG.debug("exhausted from ActionMapper that could return an ActionMapping");
/* 109 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\mapper\CompositeActionMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */