/*    */ package org.apache.struts2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.Result;
/*    */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*    */ import com.opensymphony.xwork2.factory.ResultFactory;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.result.ParamNameAwareResult;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionExceptionHandler;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsResultFactory
/*    */   implements ResultFactory
/*    */ {
/*    */   protected ObjectFactory objectFactory;
/*    */   protected ReflectionProvider reflectionProvider;
/*    */   
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 43 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider provider) {
/* 48 */     this.reflectionProvider = provider;
/*    */   }
/*    */   
/*    */   public Result buildResult(ResultConfig resultConfig, Map<String, Object> extraContext) throws Exception {
/* 52 */     String resultClassName = resultConfig.getClassName();
/* 53 */     Result result = null;
/*    */     
/* 55 */     if (resultClassName != null) {
/* 56 */       result = (Result)this.objectFactory.buildBean(resultClassName, extraContext);
/* 57 */       Map<String, String> params = resultConfig.getParams();
/* 58 */       if (params != null) {
/* 59 */         setParameters(extraContext, result, params);
/*    */       }
/*    */     } 
/* 62 */     return result;
/*    */   }
/*    */   
/*    */   protected void setParameters(Map<String, Object> extraContext, Result result, Map<String, String> params) {
/* 66 */     for (Map.Entry<String, String> paramEntry : params.entrySet()) {
/*    */       try {
/* 68 */         String name = paramEntry.getKey();
/* 69 */         String value = paramEntry.getValue();
/* 70 */         setParameter(result, name, value, extraContext);
/* 71 */       } catch (ReflectionException ex) {
/* 72 */         if (result instanceof ReflectionExceptionHandler) {
/* 73 */           ((ReflectionExceptionHandler)result).handle(ex);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void setParameter(Result result, String name, String value, Map<String, Object> extraContext) {
/* 80 */     if (result instanceof ParamNameAwareResult) {
/* 81 */       if (((ParamNameAwareResult)result).acceptableParameterName(name, value)) {
/* 82 */         this.reflectionProvider.setProperty(name, value, result, extraContext, true);
/*    */       }
/*    */     } else {
/* 85 */       this.reflectionProvider.setProperty(name, value, result, extraContext, true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\factory\StrutsResultFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */