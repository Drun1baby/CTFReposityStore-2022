/*    */ package org.apache.struts2.interceptor.validation;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.validator.ValidationInterceptor;
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.commons.lang3.reflect.MethodUtils;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationValidationInterceptor
/*    */   extends ValidationInterceptor
/*    */ {
/* 36 */   private static final Logger LOG = LogManager.getLogger(AnnotationValidationInterceptor.class);
/*    */ 
/*    */   
/*    */   protected String doIntercept(ActionInvocation invocation) throws Exception {
/* 40 */     Object action = invocation.getAction();
/* 41 */     if (action != null) {
/* 42 */       Method method = getActionMethod(action.getClass(), invocation.getProxy().getMethod());
/*    */       
/* 44 */       if (null != MethodUtils.getAnnotation(method, SkipValidation.class, true, true)) {
/* 45 */         return invocation.invoke();
/*    */       }
/*    */     } 
/*    */     
/* 49 */     return super.doIntercept(invocation);
/*    */   }
/*    */   
/*    */   protected Method getActionMethod(Class<?> actionClass, String methodName) {
/*    */     try {
/* 54 */       return actionClass.getMethod(methodName, new Class[0]);
/* 55 */     } catch (NoSuchMethodException e) {
/* 56 */       throw new ConfigurationException("Wrong method was defined as an action method: " + methodName, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\interceptor\validation\AnnotationValidationInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */