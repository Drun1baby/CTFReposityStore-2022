/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "else", tldTagClass = "org.apache.struts2.views.jsp.ElseTag", description = "Else tag")
/*    */ public class Else
/*    */   extends Component
/*    */ {
/*    */   public Else(ValueStack stack) {
/* 60 */     super(stack);
/*    */   }
/*    */   
/*    */   public boolean start(Writer writer) {
/* 64 */     Map context = this.stack.getContext();
/* 65 */     Boolean ifResult = (Boolean)context.get("struts.if.answer");
/*    */     
/* 67 */     context.remove("struts.if.answer");
/*    */     
/* 69 */     return (ifResult != null && !ifResult.booleanValue());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Else.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */