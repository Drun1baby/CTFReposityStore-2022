/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseTemplateEngine
/*     */   implements TemplateEngine
/*     */ {
/*  37 */   private static final Logger LOG = LogManager.getLogger(BaseTemplateEngine.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_THEME_PROPERTIES_FILE_NAME = "theme.properties";
/*     */ 
/*     */   
/*  44 */   private final Map<String, Properties> themeProps = new ConcurrentHashMap<>();
/*     */   
/*     */   public Map getThemeProps(Template template) {
/*  47 */     Properties props = this.themeProps.get(template.getTheme());
/*  48 */     if (props == null) {
/*  49 */       synchronized (this.themeProps) {
/*  50 */         props = readNewProperties(template);
/*  51 */         this.themeProps.put(template.getTheme(), props);
/*     */       } 
/*     */     }
/*  54 */     return props;
/*     */   }
/*     */   
/*     */   private Properties readNewProperties(Template template) {
/*  58 */     String propName = buildPropertyFilename(template);
/*  59 */     return loadProperties(propName);
/*     */   }
/*     */   
/*     */   private Properties loadProperties(String propName) {
/*  63 */     InputStream is = readProperty(propName);
/*  64 */     Properties props = new Properties();
/*  65 */     if (is != null) {
/*  66 */       tryToLoadPropertiesFromStream(props, propName, is);
/*     */     }
/*  68 */     return props;
/*     */   }
/*     */   
/*     */   private InputStream readProperty(String propName) {
/*  72 */     InputStream is = tryReadingPropertyFileFromFileSystem(propName);
/*  73 */     if (is == null) {
/*  74 */       is = readPropertyFromClasspath(propName);
/*     */     }
/*  76 */     if (is == null) {
/*  77 */       is = readPropertyUsingServletContext(propName);
/*     */     }
/*  79 */     return is;
/*     */   }
/*     */   
/*     */   private InputStream readPropertyUsingServletContext(String propName) {
/*  83 */     ServletContext servletContext = ServletActionContext.getServletContext();
/*  84 */     String path = propName.startsWith("/") ? propName : ("/" + propName);
/*  85 */     if (servletContext != null) {
/*  86 */       return servletContext.getResourceAsStream(path);
/*     */     }
/*  88 */     LOG.warn("ServletContext is null, cannot obtain {}", path);
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream readPropertyFromClasspath(String propName) {
/*  97 */     return ClassLoaderUtil.getResourceAsStream(propName, getClass());
/*     */   }
/*     */   
/*     */   private void tryToLoadPropertiesFromStream(Properties props, String propName, InputStream is) {
/*     */     try {
/* 102 */       props.load(is);
/* 103 */     } catch (IOException e) {
/* 104 */       LOG.error("Could not load property with name: {}", propName, e);
/*     */     } finally {
/* 106 */       tryCloseStream(is);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tryCloseStream(InputStream is) {
/*     */     try {
/* 112 */       is.close();
/* 113 */     } catch (IOException io) {
/* 114 */       LOG.warn("Unable to close input stream", io);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String buildPropertyFilename(Template template) {
/* 119 */     return template.getDir() + "/" + template.getTheme() + "/" + getThemePropertiesFileName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream tryReadingPropertyFileFromFileSystem(String propName) {
/* 126 */     File propFile = new File(propName);
/*     */     try {
/* 128 */       return createFileInputStream(propFile);
/* 129 */     } catch (FileNotFoundException e) {
/* 130 */       LOG.warn("Unable to find file in filesystem [{}]", propFile.getAbsolutePath());
/* 131 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private InputStream createFileInputStream(File propFile) throws FileNotFoundException {
/* 136 */     InputStream is = null;
/* 137 */     if (propFile.exists()) {
/* 138 */       is = new FileInputStream(propFile);
/*     */     }
/* 140 */     return is;
/*     */   }
/*     */   
/*     */   protected String getFinalTemplateName(Template template) {
/* 144 */     String t = template.toString();
/* 145 */     if (t.indexOf('.') <= 0) {
/* 146 */       return t + "." + getSuffix();
/*     */     }
/* 148 */     return t;
/*     */   }
/*     */   
/*     */   protected String getThemePropertiesFileName() {
/* 152 */     return "theme.properties";
/*     */   }
/*     */   
/*     */   protected abstract String getSuffix();
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\template\BaseTemplateEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */