/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.util.FastByteArrayOutputStream;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "include", tldTagClass = "org.apache.struts2.views.jsp.IncludeTag", description = "Include a servlet's output (result of servlet or a JSP page)")
/*     */ public class Include
/*     */   extends Component
/*     */ {
/*  93 */   private static final Logger LOG = LogManager.getLogger(Include.class);
/*     */   
/*  95 */   private static final String systemEncoding = System.getProperty("file.encoding");
/*     */   
/*     */   protected String value;
/*     */   private HttpServletRequest req;
/*     */   private HttpServletResponse res;
/*     */   private String defaultEncoding;
/*     */   private boolean useResponseEncoding;
/*     */   
/*     */   public Include(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 104 */     super(stack);
/* 105 */     this.req = req;
/* 106 */     this.res = res;
/* 107 */     this.useResponseEncoding = false;
/*     */   }
/*     */   
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String encoding) {
/* 112 */     this.defaultEncoding = encoding;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.tag.includetag.useResponseEncoding", required = false)
/*     */   public void setUseResponseEncoding(String useEncoding) {
/* 117 */     this.useResponseEncoding = Boolean.parseBoolean(useEncoding);
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 121 */     String encodingForInclude, page = findString(this.value, "value", "You must specify the URL to include. Example: /foo.jsp");
/* 122 */     StringBuilder urlBuf = new StringBuilder();
/*     */ 
/*     */     
/* 125 */     if (this.useResponseEncoding) {
/* 126 */       encodingForInclude = this.res.getCharacterEncoding();
/* 127 */       if (encodingForInclude == null || encodingForInclude.length() == 0) {
/* 128 */         encodingForInclude = this.defaultEncoding;
/*     */       }
/*     */     } else {
/*     */       
/* 132 */       encodingForInclude = this.defaultEncoding;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     urlBuf.append(page);
/*     */ 
/*     */     
/* 139 */     if (this.parameters.size() > 0) {
/* 140 */       urlBuf.append('?');
/*     */       
/* 142 */       String concat = "";
/*     */ 
/*     */       
/* 145 */       for (Object next : this.parameters.entrySet()) {
/* 146 */         Map.Entry entry = (Map.Entry)next;
/* 147 */         Object name = entry.getKey();
/* 148 */         List values = (List)entry.getValue();
/*     */         
/* 150 */         for (Object value : values) {
/* 151 */           urlBuf.append(concat);
/* 152 */           urlBuf.append(name);
/* 153 */           urlBuf.append('=');
/*     */           
/*     */           try {
/* 156 */             urlBuf.append(URLEncoder.encode(value.toString(), "UTF-8"));
/* 157 */           } catch (UnsupportedEncodingException e) {
/* 158 */             LOG.warn("Unable to url-encode {}, it will be ignored", value);
/*     */           } 
/*     */           
/* 161 */           concat = "&";
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     String result = urlBuf.toString();
/*     */ 
/*     */     
/*     */     try {
/* 170 */       include(result, writer, (ServletRequest)this.req, this.res, encodingForInclude);
/* 171 */     } catch (ServletException|IOException e) {
/* 172 */       LOG.warn("Exception thrown during include of {}", result, e);
/*     */     } 
/*     */     
/* 175 */     return super.end(writer, body);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The jsp/servlet output to include", required = true)
/*     */   public void setValue(String value) {
/* 180 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getContextRelativePath(ServletRequest request, String relativePath) {
/*     */     String returnValue;
/* 186 */     if (relativePath.startsWith("/")) {
/* 187 */       returnValue = relativePath;
/* 188 */     } else if (!(request instanceof HttpServletRequest)) {
/* 189 */       returnValue = relativePath;
/*     */     } else {
/* 191 */       HttpServletRequest hrequest = (HttpServletRequest)request;
/* 192 */       String uri = (String)request.getAttribute("javax.servlet.include.servlet_path");
/*     */       
/* 194 */       if (uri == null) {
/* 195 */         uri = RequestUtils.getServletPath(hrequest);
/*     */       }
/*     */       
/* 198 */       returnValue = uri.substring(0, uri.lastIndexOf('/')) + '/' + relativePath;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 203 */     if (returnValue.contains("..")) {
/* 204 */       Stack<String> stack = new Stack();
/* 205 */       StringTokenizer pathParts = new StringTokenizer(returnValue.replace('\\', '/'), "/");
/*     */       
/* 207 */       while (pathParts.hasMoreTokens()) {
/* 208 */         String part = pathParts.nextToken();
/*     */         
/* 210 */         if (!part.equals(".")) {
/* 211 */           if (part.equals("..")) {
/* 212 */             stack.pop(); continue;
/*     */           } 
/* 214 */           stack.push(part);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 219 */       StringBuilder flatPathBuffer = new StringBuilder();
/*     */       
/* 221 */       for (int i = 0; i < stack.size(); i++) {
/* 222 */         flatPathBuffer.append("/").append(stack.elementAt(i));
/*     */       }
/*     */       
/* 225 */       returnValue = flatPathBuffer.toString();
/*     */     } 
/*     */     
/* 228 */     return returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String key, Object value) {
/* 235 */     if (value != null) {
/* 236 */       List<Object> currentValues = (List)this.parameters.get(key);
/*     */       
/* 238 */       if (currentValues == null) {
/* 239 */         currentValues = new ArrayList();
/* 240 */         this.parameters.put(key, currentValues);
/*     */       } 
/*     */       
/* 243 */       currentValues.add(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void include(String relativePath, Writer writer, ServletRequest request, HttpServletResponse response, String encoding) throws ServletException, IOException {
/* 263 */     String resourcePath = getContextRelativePath(request, relativePath);
/* 264 */     RequestDispatcher rd = request.getRequestDispatcher(resourcePath);
/*     */     
/* 266 */     if (rd == null) {
/* 267 */       throw new ServletException("Not a valid resource path:" + resourcePath);
/*     */     }
/*     */     
/* 270 */     PageResponse pageResponse = new PageResponse(response);
/*     */ 
/*     */     
/* 273 */     rd.include(request, (ServletResponse)pageResponse);
/*     */     
/* 275 */     if (encoding != null) {
/*     */       
/* 277 */       pageResponse.getContent().writeTo(writer, encoding);
/*     */     } else {
/*     */       
/* 280 */       pageResponse.getContent().writeTo(writer, systemEncoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PageOutputStream
/*     */     extends ServletOutputStream
/*     */   {
/* 297 */     private FastByteArrayOutputStream buffer = new FastByteArrayOutputStream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FastByteArrayOutputStream getBuffer() throws IOException {
/* 305 */       flush();
/*     */       
/* 307 */       return this.buffer;
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 311 */       this.buffer.close();
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 315 */       this.buffer.flush();
/*     */     }
/*     */     
/*     */     public void write(byte[] b, int o, int l) throws IOException {
/* 319 */       this.buffer.write(b, o, l);
/*     */     }
/*     */     
/*     */     public void write(int i) throws IOException {
/* 323 */       this.buffer.write(i);
/*     */     }
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 327 */       this.buffer.write(b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class PageResponse
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     protected PrintWriter pagePrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ServletOutputStream outputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     private Include.PageOutputStream pageOutputStream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PageResponse(HttpServletResponse response) {
/* 361 */       super(response);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FastByteArrayOutputStream getContent() throws IOException {
/* 375 */       if (this.pagePrintWriter != null) {
/* 376 */         this.pagePrintWriter.flush();
/*     */       }
/*     */       
/* 379 */       return ((Include.PageOutputStream)getOutputStream()).getBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ServletOutputStream getOutputStream() throws IOException {
/* 387 */       if (this.pageOutputStream == null) {
/* 388 */         this.pageOutputStream = new Include.PageOutputStream();
/*     */       }
/*     */       
/* 391 */       return this.pageOutputStream;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PrintWriter getWriter() throws IOException {
/* 398 */       if (this.pagePrintWriter == null) {
/* 399 */         this.pagePrintWriter = new PrintWriter(new OutputStreamWriter((OutputStream)getOutputStream(), getCharacterEncoding()));
/*     */       }
/*     */       
/* 402 */       return this.pagePrintWriter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Include.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */