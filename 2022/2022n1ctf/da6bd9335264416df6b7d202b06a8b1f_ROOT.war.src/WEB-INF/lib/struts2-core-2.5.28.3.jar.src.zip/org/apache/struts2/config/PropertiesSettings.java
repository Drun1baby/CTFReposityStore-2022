/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ import com.opensymphony.xwork2.util.location.Location;
/*    */ import com.opensymphony.xwork2.util.location.LocationImpl;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Iterator;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.struts2.StrutsException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertiesSettings
/*    */   implements Settings
/*    */ {
/* 39 */   private static final Logger LOG = LogManager.getLogger(PropertiesSettings.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private LocatableProperties settings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PropertiesSettings(String name) {
/* 52 */     URL settingsUrl = ClassLoaderUtil.getResource(name + ".properties", getClass());
/*    */     
/* 54 */     if (settingsUrl == null) {
/* 55 */       LOG.debug("{}.properties missing", name);
/* 56 */       this.settings = new LocatableProperties();
/*    */       
/*    */       return;
/*    */     } 
/* 60 */     this.settings = new LocatableProperties((Location)new LocationImpl(null, settingsUrl.toString()));
/*    */ 
/*    */     
/* 63 */     try (InputStream in = settingsUrl.openStream()) {
/* 64 */       this.settings.load(in);
/* 65 */     } catch (IOException e) {
/* 66 */       throw new StrutsException("Could not load " + name + ".properties: " + e, e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String get(String aName) throws IllegalArgumentException {
/* 77 */     return this.settings.getProperty(aName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Location getLocation(String aName) throws IllegalArgumentException {
/* 86 */     return this.settings.getPropertyLocation(aName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator list() {
/* 95 */     return this.settings.keySet().iterator();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\config\PropertiesSettings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */