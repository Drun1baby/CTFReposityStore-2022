/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrepareOperations
/*     */ {
/*  45 */   private static final Logger LOG = LogManager.getLogger(PrepareOperations.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private static ThreadLocal<Boolean> devModeOverride = new InheritableThreadLocal<>();
/*     */   
/*     */   private Dispatcher dispatcher;
/*     */   
/*     */   private static final String STRUTS_ACTION_MAPPING_KEY = "struts.actionMapping";
/*     */   public static final String CLEANUP_RECURSION_COUNTER = "__cleanup_recursion_counter";
/*     */   
/*     */   public PrepareOperations(Dispatcher dispatcher) {
/*  58 */     this.dispatcher = dispatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionContext createActionContext(HttpServletRequest request, HttpServletResponse response) {
/*     */     ActionContext ctx;
/*  71 */     Integer counter = Integer.valueOf(1);
/*  72 */     Integer oldCounter = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*  73 */     if (oldCounter != null) {
/*  74 */       counter = Integer.valueOf(oldCounter.intValue() + 1);
/*     */     }
/*     */     
/*  77 */     ActionContext oldContext = ActionContext.getContext();
/*  78 */     if (oldContext != null) {
/*     */       
/*  80 */       ctx = new ActionContext(new HashMap<>(oldContext.getContextMap()));
/*     */     } else {
/*  82 */       ValueStack stack = ((ValueStackFactory)this.dispatcher.getContainer().getInstance(ValueStackFactory.class)).createValueStack();
/*  83 */       stack.getContext().putAll(this.dispatcher.createContextMap(request, response, null));
/*  84 */       ctx = new ActionContext(stack.getContext());
/*     */     } 
/*  86 */     request.setAttribute("__cleanup_recursion_counter", counter);
/*  87 */     ActionContext.setContext(ctx);
/*  88 */     return ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanupRequest(HttpServletRequest request) {
/*  97 */     Integer counterVal = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*  98 */     if (counterVal != null) {
/*  99 */       counterVal = Integer.valueOf(counterVal.intValue() - 1);
/* 100 */       request.setAttribute("__cleanup_recursion_counter", counterVal);
/* 101 */       if (counterVal.intValue() > 0) {
/* 102 */         LOG.debug("skipping cleanup counter={}", counterVal);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     try {
/* 108 */       this.dispatcher.cleanUpRequest(request);
/*     */     } finally {
/* 110 */       ActionContext.setContext(null);
/* 111 */       Dispatcher.setInstance(null);
/* 112 */       devModeOverride.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignDispatcherToThread() {
/* 120 */     Dispatcher.setInstance(this.dispatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodingAndLocale(HttpServletRequest request, HttpServletResponse response) {
/* 130 */     this.dispatcher.prepare(request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpServletRequest wrapRequest(HttpServletRequest oldRequest) throws ServletException {
/* 142 */     HttpServletRequest request = oldRequest;
/*     */ 
/*     */     
/*     */     try {
/* 146 */       request = this.dispatcher.wrapRequest(request);
/* 147 */       ServletActionContext.setRequest(request);
/* 148 */     } catch (IOException e) {
/* 149 */       throw new ServletException("Could not wrap servlet request with MultipartRequestWrapper!", e);
/*     */     } 
/* 151 */     return request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping findActionMapping(HttpServletRequest request, HttpServletResponse response) {
/* 165 */     return findActionMapping(request, response, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionMapping findActionMapping(HttpServletRequest request, HttpServletResponse response, boolean forceLookup) {
/* 181 */     ActionMapping mapping = (ActionMapping)request.getAttribute("struts.actionMapping");
/* 182 */     if (mapping == null || forceLookup) {
/*     */       try {
/* 184 */         mapping = ((ActionMapper)this.dispatcher.getContainer().getInstance(ActionMapper.class)).getMapping(request, this.dispatcher.getConfigurationManager());
/* 185 */         if (mapping != null) {
/* 186 */           request.setAttribute("struts.actionMapping", mapping);
/*     */         }
/* 188 */       } catch (Exception ex) {
/* 189 */         if (this.dispatcher.isHandleException() || this.dispatcher.isDevMode()) {
/* 190 */           this.dispatcher.sendError(request, response, 500, ex);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 195 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanupDispatcher() {
/* 202 */     if (this.dispatcher == null) {
/* 203 */       throw new StrutsException("Something is seriously wrong, Dispatcher is not initialized (null) ");
/*     */     }
/*     */     try {
/* 206 */       this.dispatcher.cleanup();
/*     */     } finally {
/* 208 */       ActionContext.setContext(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUrlExcluded(HttpServletRequest request, List<Pattern> excludedPatterns) {
/* 222 */     if (excludedPatterns != null) {
/* 223 */       String uri = RequestUtils.getUri(request);
/* 224 */       for (Pattern pattern : excludedPatterns) {
/* 225 */         if (pattern.matcher(uri).matches()) {
/* 226 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 230 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void overrideDevMode(boolean devMode) {
/* 241 */     devModeOverride.set(Boolean.valueOf(devMode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean getDevModeOverride() {
/* 249 */     return devModeOverride.get();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\PrepareOperations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */