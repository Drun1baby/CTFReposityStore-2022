package org.apache.struts2.components;

import com.opensymphony.xwork2.util.ValueStack;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface UrlProvider {
  public static final String NONE = "none";
  
  public static final String GET = "get";
  
  public static final String ALL = "all";
  
  boolean isPutInContext();
  
  String getVar();
  
  String getValue();
  
  String findString(String paramString);
  
  void setValue(String paramString);
  
  String getUrlIncludeParams();
  
  String getIncludeParams();
  
  Map getParameters();
  
  HttpServletRequest getHttpServletRequest();
  
  String getAction();
  
  ExtraParameterProvider getExtraParameterProvider();
  
  String getScheme();
  
  String getNamespace();
  
  String getMethod();
  
  HttpServletResponse getHttpServletResponse();
  
  boolean isIncludeContext();
  
  boolean isEncode();
  
  boolean isForceAddSchemeHostAndPort();
  
  boolean isEscapeAmp();
  
  String getPortletMode();
  
  String getWindowState();
  
  String determineActionURL(String paramString1, String paramString2, String paramString3, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map paramMap, String paramString4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  String determineNamespace(String paramString, ValueStack paramValueStack, HttpServletRequest paramHttpServletRequest);
  
  String getAnchor();
  
  String getPortletUrlType();
  
  ValueStack getStack();
  
  void setUrlIncludeParams(String paramString);
  
  void setHttpServletRequest(HttpServletRequest paramHttpServletRequest);
  
  void setHttpServletResponse(HttpServletResponse paramHttpServletResponse);
  
  void setUrlRenderer(UrlRenderer paramUrlRenderer);
  
  void setExtraParameterProvider(ExtraParameterProvider paramExtraParameterProvider);
  
  void setIncludeParams(String paramString);
  
  void setScheme(String paramString);
  
  void setAction(String paramString);
  
  void setPortletMode(String paramString);
  
  void setNamespace(String paramString);
  
  void setMethod(String paramString);
  
  void setEncode(boolean paramBoolean);
  
  void setIncludeContext(boolean paramBoolean);
  
  void setWindowState(String paramString);
  
  void setPortletUrlType(String paramString);
  
  void setAnchor(String paramString);
  
  void setEscapeAmp(boolean paramBoolean);
  
  void setForceAddSchemeHostAndPort(boolean paramBoolean);
  
  void putInContext(String paramString);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\UrlProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */