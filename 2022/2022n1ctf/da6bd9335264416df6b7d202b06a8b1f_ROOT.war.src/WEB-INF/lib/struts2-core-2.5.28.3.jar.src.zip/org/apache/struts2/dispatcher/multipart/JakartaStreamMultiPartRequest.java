/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.fileupload.FileItemIterator;
/*     */ import org.apache.commons.fileupload.FileItemStream;
/*     */ import org.apache.commons.fileupload.FileUploadBase;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.commons.fileupload.util.Streams;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.LocalizedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JakartaStreamMultiPartRequest
/*     */   extends AbstractMultiPartRequest
/*     */ {
/*  46 */   static final Logger LOG = LogManager.getLogger(JakartaStreamMultiPartRequest.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected Map<String, List<FileInfo>> fileInfos = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected Map<String, List<String>> parameters = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/*  62 */     LOG.debug("Performing File Upload temporary storage cleanup.");
/*  63 */     for (List<FileInfo> fileInfoList : this.fileInfos.values()) {
/*  64 */       for (FileInfo fileInfo : fileInfoList) {
/*  65 */         File file = fileInfo.getFile();
/*  66 */         LOG.debug("Deleting file '{}'.", file.getName());
/*  67 */         if (!file.delete()) {
/*  68 */           LOG.warn("There was a problem attempting to delete file '{}'.", file.getName());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getContentType(String fieldName) {
/*  78 */     List<FileInfo> infos = this.fileInfos.get(fieldName);
/*  79 */     if (infos == null) {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     List<String> types = new ArrayList<>(infos.size());
/*  84 */     for (FileInfo fileInfo : infos) {
/*  85 */       types.add(fileInfo.getContentType());
/*     */     }
/*     */     
/*  88 */     return types.<String>toArray(new String[types.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UploadedFile[] getFile(String fieldName) {
/*  95 */     List<FileInfo> infos = this.fileInfos.get(fieldName);
/*  96 */     if (infos == null) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     List<UploadedFile> files = new ArrayList<>(infos.size());
/* 101 */     for (FileInfo fileInfo : infos) {
/* 102 */       files.add(new StrutsUploadedFile(fileInfo.getFile()));
/*     */     }
/*     */     
/* 105 */     return files.<UploadedFile>toArray(new UploadedFile[files.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFileNames(String fieldName) {
/* 112 */     List<FileInfo> infos = this.fileInfos.get(fieldName);
/* 113 */     if (infos == null) {
/* 114 */       return null;
/*     */     }
/*     */     
/* 117 */     List<String> names = new ArrayList<>(infos.size());
/* 118 */     for (FileInfo fileInfo : infos) {
/* 119 */       names.add(getCanonicalName(fileInfo.getOriginalName()));
/*     */     }
/*     */     
/* 122 */     return names.<String>toArray(new String[names.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getFileParameterNames() {
/* 129 */     return Collections.enumeration(this.fileInfos.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFilesystemName(String fieldName) {
/* 136 */     List<FileInfo> infos = this.fileInfos.get(fieldName);
/* 137 */     if (infos == null) {
/* 138 */       return null;
/*     */     }
/*     */     
/* 141 */     List<String> names = new ArrayList<>(infos.size());
/* 142 */     for (FileInfo fileInfo : infos) {
/* 143 */       names.add(fileInfo.getFile().getName());
/*     */     }
/*     */     
/* 146 */     return names.<String>toArray(new String[names.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 153 */     List<String> values = this.parameters.get(name);
/* 154 */     if (values != null && values.size() > 0) {
/* 155 */       return values.get(0);
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getParameterNames() {
/* 164 */     return Collections.enumeration(this.parameters.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParameterValues(String name) {
/* 171 */     List<String> values = this.parameters.get(name);
/* 172 */     if (values != null && values.size() > 0) {
/* 173 */       return values.<String>toArray(new String[values.size()]);
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(HttpServletRequest request, String saveDir) throws IOException {
/*     */     try {
/* 183 */       setLocale(request);
/* 184 */       processUpload(request, saveDir);
/* 185 */     } catch (Exception e) {
/* 186 */       LOG.warn("Error occurred during parsing of multi part request", e);
/* 187 */       LocalizedMessage errorMessage = buildErrorMessage(e, new Object[0]);
/* 188 */       if (!this.errors.contains(errorMessage)) {
/* 189 */         this.errors.add(errorMessage);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processUpload(HttpServletRequest request, String saveDir) throws Exception {
/* 204 */     if (ServletFileUpload.isMultipartContent(request)) {
/*     */ 
/*     */       
/* 207 */       boolean requestSizePermitted = isRequestSizePermitted(request);
/*     */ 
/*     */ 
/*     */       
/* 211 */       ServletFileUpload servletFileUpload = new ServletFileUpload();
/* 212 */       if (this.maxSizeProvided) {
/* 213 */         servletFileUpload.setSizeMax(this.maxSize);
/*     */       }
/* 215 */       FileItemIterator i = servletFileUpload.getItemIterator(request);
/*     */ 
/*     */       
/* 218 */       while (i.hasNext()) {
/*     */         try {
/* 220 */           FileItemStream itemStream = i.next();
/*     */ 
/*     */ 
/*     */           
/* 224 */           if (itemStream.isFormField()) {
/* 225 */             processFileItemStreamAsFormField(itemStream);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 236 */           if (!requestSizePermitted) {
/* 237 */             addFileSkippedError(itemStream.getName(), request);
/* 238 */             LOG.warn("Skipped stream '{}', request maximum size ({}) exceeded.", itemStream.getName(), Long.valueOf(this.maxSize));
/*     */             
/*     */             continue;
/*     */           } 
/* 242 */           processFileItemStreamAsFileField(itemStream, saveDir);
/*     */         }
/* 244 */         catch (IOException e) {
/* 245 */           LOG.warn("Error occurred during process upload", e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isRequestSizePermitted(HttpServletRequest request) {
/* 261 */     if (this.maxSize == -1L || request == null) {
/* 262 */       return true;
/*     */     }
/*     */     
/* 265 */     return (request.getContentLength() < this.maxSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getRequestSize(HttpServletRequest request) {
/* 273 */     long requestSize = 0L;
/* 274 */     if (request != null) {
/* 275 */       requestSize = request.getContentLength();
/*     */     }
/*     */     
/* 278 */     return requestSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addFileSkippedError(String fileName, HttpServletRequest request) {
/* 288 */     String exceptionMessage = "Skipped file " + fileName + "; request size limit exceeded.";
/* 289 */     FileUploadBase.FileSizeLimitExceededException exception = new FileUploadBase.FileSizeLimitExceededException(exceptionMessage, getRequestSize(request), this.maxSize);
/* 290 */     LocalizedMessage message = buildErrorMessage((Throwable)exception, new Object[] { fileName, Long.valueOf(getRequestSize(request)), Long.valueOf(this.maxSize) });
/* 291 */     if (!this.errors.contains(message)) {
/* 292 */       this.errors.add(message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processFileItemStreamAsFormField(FileItemStream itemStream) {
/* 302 */     String fieldName = itemStream.getFieldName();
/*     */     try {
/*     */       List<String> values;
/* 305 */       String fieldValue = Streams.asString(itemStream.openStream());
/* 306 */       if (!this.parameters.containsKey(fieldName)) {
/* 307 */         values = new ArrayList<>();
/* 308 */         this.parameters.put(fieldName, values);
/*     */       } else {
/* 310 */         values = this.parameters.get(fieldName);
/*     */       } 
/* 312 */       values.add(fieldValue);
/* 313 */     } catch (IOException e) {
/* 314 */       LOG.warn("Failed to handle form field '{}'.", fieldName, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processFileItemStreamAsFileField(FileItemStream itemStream, String location) {
/* 326 */     if (itemStream.getName() == null || itemStream.getName().trim().length() < 1) {
/* 327 */       LOG.debug("No file has been uploaded for the field: {}", itemStream.getFieldName());
/*     */       
/*     */       return;
/*     */     } 
/* 331 */     File file = null;
/*     */     
/*     */     try {
/* 334 */       file = createTemporaryFile(itemStream.getName(), location);
/*     */       
/* 336 */       if (streamFileToDisk(itemStream, file)) {
/* 337 */         createFileInfoFromItemStream(itemStream, file);
/*     */       }
/* 339 */     } catch (IOException e) {
/* 340 */       if (file != null) {
/*     */         try {
/* 342 */           file.delete();
/* 343 */         } catch (SecurityException se) {
/* 344 */           LOG.warn("Failed to delete '{}' due to security exception above.", file.getName(), se);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File createTemporaryFile(String fileName, String location) throws IOException {
/* 359 */     String name = fileName.substring(fileName.lastIndexOf('/') + 1).substring(fileName.lastIndexOf('\\') + 1);
/*     */ 
/*     */ 
/*     */     
/* 363 */     String prefix = name;
/* 364 */     String suffix = "";
/*     */     
/* 366 */     if (name.contains(".")) {
/* 367 */       prefix = name.substring(0, name.lastIndexOf('.'));
/* 368 */       suffix = name.substring(name.lastIndexOf('.'));
/*     */     } 
/*     */     
/* 371 */     if (prefix.length() < 3) {
/* 372 */       prefix = UUID.randomUUID().toString();
/*     */     }
/*     */     
/* 375 */     File file = File.createTempFile(prefix + "_", suffix, new File(location));
/* 376 */     LOG.debug("Creating temporary file '{}' (originally '{}').", file.getName(), fileName);
/* 377 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean streamFileToDisk(FileItemStream itemStream, File file) throws IOException {
/* 389 */     boolean result = false;
/* 390 */     try(InputStream input = itemStream.openStream(); 
/* 391 */         OutputStream output = new BufferedOutputStream(new FileOutputStream(file), this.bufferSize)) {
/* 392 */       byte[] buffer = new byte[this.bufferSize];
/* 393 */       LOG.debug("Streaming file using buffer size {}.", Integer.valueOf(this.bufferSize));
/* 394 */       for (int length = 0; (length = input.read(buffer)) > 0;) {
/* 395 */         output.write(buffer, 0, length);
/*     */       }
/* 397 */       result = true;
/*     */     } 
/* 399 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createFileInfoFromItemStream(FileItemStream itemStream, File file) {
/* 412 */     String fileName = itemStream.getName();
/* 413 */     String fieldName = itemStream.getFieldName();
/*     */     
/* 415 */     FileInfo fileInfo = new FileInfo(file, itemStream.getContentType(), fileName);
/*     */     
/* 417 */     if (!this.fileInfos.containsKey(fieldName)) {
/* 418 */       List<FileInfo> infos = new ArrayList<>();
/* 419 */       infos.add(fileInfo);
/* 420 */       this.fileInfos.put(fieldName, infos);
/*     */     } else {
/* 422 */       ((List<FileInfo>)this.fileInfos.get(fieldName)).add(fileInfo);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FileInfo
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1083158552766906037L;
/*     */ 
/*     */ 
/*     */     
/*     */     private File file;
/*     */ 
/*     */ 
/*     */     
/*     */     private String contentType;
/*     */ 
/*     */     
/*     */     private String originalName;
/*     */ 
/*     */ 
/*     */     
/*     */     public FileInfo(File file, String contentType, String originalName) {
/* 448 */       this.file = file;
/* 449 */       this.contentType = contentType;
/* 450 */       this.originalName = originalName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public File getFile() {
/* 457 */       return this.file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 464 */       return this.contentType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOriginalName() {
/* 471 */       return this.originalName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\multipart\JakartaStreamMultiPartRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */