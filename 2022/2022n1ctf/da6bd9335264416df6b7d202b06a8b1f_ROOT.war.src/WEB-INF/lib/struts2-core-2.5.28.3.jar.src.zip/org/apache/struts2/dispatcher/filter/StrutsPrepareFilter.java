/*    */ package org.apache.struts2.dispatcher.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.StrutsStatics;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.InitOperations;
/*    */ import org.apache.struts2.dispatcher.PrepareOperations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsPrepareFilter
/*    */   implements StrutsStatics, Filter
/*    */ {
/* 43 */   protected static final String REQUEST_EXCLUDED_FROM_ACTION_MAPPING = StrutsPrepareFilter.class.getName() + ".REQUEST_EXCLUDED_FROM_ACTION_MAPPING";
/*    */   
/*    */   protected PrepareOperations prepare;
/* 46 */   protected List<Pattern> excludedPatterns = null;
/*    */   
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 49 */     InitOperations init = new InitOperations();
/* 50 */     Dispatcher dispatcher = null;
/*    */     try {
/* 52 */       FilterHostConfig config = new FilterHostConfig(filterConfig);
/* 53 */       init.initLogging(config);
/* 54 */       dispatcher = init.initDispatcher(config);
/*    */       
/* 56 */       this.prepare = new PrepareOperations(dispatcher);
/* 57 */       this.excludedPatterns = init.buildExcludedPatternsList(dispatcher);
/*    */       
/* 59 */       postInit(dispatcher, filterConfig);
/*    */     } finally {
/* 61 */       if (dispatcher != null) {
/* 62 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 64 */       init.cleanup();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void postInit(Dispatcher dispatcher, FilterConfig filterConfig) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
/* 79 */     HttpServletRequest request = (HttpServletRequest)req;
/* 80 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */     
/*    */     try {
/* 83 */       if (this.excludedPatterns != null && this.prepare.isUrlExcluded(request, this.excludedPatterns)) {
/* 84 */         request.setAttribute(REQUEST_EXCLUDED_FROM_ACTION_MAPPING, new Object());
/*    */       } else {
/* 86 */         this.prepare.setEncodingAndLocale(request, response);
/* 87 */         this.prepare.createActionContext(request, response);
/* 88 */         this.prepare.assignDispatcherToThread();
/* 89 */         request = this.prepare.wrapRequest(request);
/* 90 */         this.prepare.findActionMapping(request, response);
/*    */       } 
/* 92 */       chain.doFilter((ServletRequest)request, (ServletResponse)response);
/*    */     } finally {
/* 94 */       this.prepare.cleanupRequest(request);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void destroy() {
/* 99 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\filter\StrutsPrepareFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */