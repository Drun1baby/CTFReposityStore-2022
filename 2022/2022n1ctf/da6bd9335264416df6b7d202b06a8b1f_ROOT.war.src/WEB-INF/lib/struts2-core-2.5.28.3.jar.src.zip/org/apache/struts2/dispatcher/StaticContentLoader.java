package org.apache.struts2.dispatcher;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface StaticContentLoader {
  boolean canHandle(String paramString);
  
  void setHostConfig(HostConfig paramHostConfig);
  
  void findStaticResource(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws IOException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\StaticContentLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */