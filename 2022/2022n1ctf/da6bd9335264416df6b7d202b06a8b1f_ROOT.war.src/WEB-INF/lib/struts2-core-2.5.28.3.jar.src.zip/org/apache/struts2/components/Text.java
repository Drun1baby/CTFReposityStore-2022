/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.util.TextProviderHelper;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "text", tldTagClass = "org.apache.struts2.views.jsp.TextTag", description = "Render a I18n text message")
/*     */ public class Text
/*     */   extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 121 */   private static final Logger LOG = LogManager.getLogger(Text.class);
/*     */   
/* 123 */   protected List<Object> values = Collections.emptyList();
/*     */   protected String actualName;
/*     */   protected String name;
/*     */   @Deprecated
/*     */   protected String searchStack;
/*     */   private boolean escapeHtml = false;
/*     */   private boolean escapeJavaScript = false;
/*     */   private boolean escapeXml = false;
/*     */   private boolean escapeCsv = false;
/*     */   
/*     */   public Text(ValueStack stack) {
/* 134 */     super(stack);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Name of resource property to fetch", required = true)
/*     */   public void setName(String name) {
/* 139 */     this.name = name;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @StrutsTagAttribute(description = "Search the stack if property is not found on resources", type = "Boolean", defaultValue = "false")
/*     */   public void setSearchValueStack(String searchStack) {
/* 145 */     this.searchStack = searchStack;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape HTML", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeHtml(boolean escape) {
/* 150 */     this.escapeHtml = escape;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape Javascript", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeJavaScript(boolean escapeJavaScript) {
/* 155 */     this.escapeJavaScript = escapeJavaScript;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape XML", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeXml(boolean escapeXml) {
/* 160 */     this.escapeXml = escapeXml;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether to escape CSV (useful to escape a value for a column)", type = "Boolean", defaultValue = "false")
/*     */   public void setEscapeCsv(boolean escapeCsv) {
/* 165 */     this.escapeCsv = escapeCsv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesBody() {
/* 172 */     return true;
/*     */   }
/*     */   public boolean end(Writer writer, String body) {
/*     */     String defaultMessage;
/* 176 */     this.actualName = findString(this.name, "name", "You must specify the i18n key. Example: welcome.header");
/*     */     
/* 178 */     if (StringUtils.isNotEmpty(body)) {
/* 179 */       defaultMessage = body;
/*     */     } else {
/* 181 */       defaultMessage = this.actualName;
/*     */     } 
/*     */     
/* 184 */     Boolean doSearchStack = Boolean.valueOf(false);
/* 185 */     if (this.searchStack != null) {
/* 186 */       Object value = findValue(this.searchStack, Boolean.class);
/* 187 */       doSearchStack = Boolean.valueOf((value != null) ? ((Boolean)value).booleanValue() : false);
/*     */     } 
/*     */     
/* 190 */     String msg = TextProviderHelper.getText(this.actualName, defaultMessage, this.values, getStack(), doSearchStack.booleanValue());
/*     */     
/* 192 */     if (msg != null) {
/*     */       try {
/* 194 */         if (getVar() == null) {
/* 195 */           writer.write(prepare(msg));
/*     */         } else {
/* 197 */           putInContext(msg);
/*     */         } 
/* 199 */       } catch (IOException e) {
/* 200 */         LOG.error("Could not write out Text tag", e);
/*     */       } 
/*     */     }
/*     */     
/* 204 */     return super.end(writer, "");
/*     */   }
/*     */   
/*     */   public void addParameter(String key, Object value) {
/* 208 */     addParameter(value);
/*     */   }
/*     */   
/*     */   public void addParameter(Object value) {
/* 212 */     if (this.values.isEmpty()) {
/* 213 */       this.values = new ArrayList(4);
/*     */     }
/*     */     
/* 216 */     this.values.add(value);
/*     */   }
/*     */   
/*     */   private String prepare(String value) {
/* 220 */     String result = value;
/* 221 */     if (this.escapeHtml) {
/* 222 */       result = StringEscapeUtils.escapeHtml4(result);
/*     */     }
/* 224 */     if (this.escapeJavaScript) {
/* 225 */       result = StringEscapeUtils.escapeEcmaScript(result);
/*     */     }
/* 227 */     if (this.escapeXml) {
/* 228 */       result = StringEscapeUtils.escapeXml(result);
/*     */     }
/* 230 */     if (this.escapeCsv) {
/* 231 */       result = StringEscapeUtils.escapeCsv(result);
/*     */     }
/*     */     
/* 234 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Text.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */