/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "set", tldBodyContent = "JSP", tldTagClass = "org.apache.struts2.views.jsp.SetTag", description = "Assigns a value to a variable in a specified scope")
/*     */ public class Set
/*     */   extends ContextBean
/*     */ {
/*     */   protected String scope;
/*     */   protected String value;
/*     */   protected boolean trimBody = true;
/*     */   
/*     */   public Set(ValueStack stack) {
/*  88 */     super(stack);
/*     */   }
/*     */   public boolean end(Writer writer, String body) {
/*     */     Object o;
/*  92 */     ValueStack stack = getStack();
/*     */ 
/*     */     
/*  95 */     if (this.value == null) {
/*  96 */       if (body == null) {
/*  97 */         o = findValue("top");
/*     */       } else {
/*  99 */         o = body;
/*     */       } 
/*     */     } else {
/* 102 */       o = findValue(this.value);
/*     */     } 
/*     */     
/* 105 */     body = "";
/*     */     
/* 107 */     if ("application".equalsIgnoreCase(this.scope)) {
/* 108 */       stack.setValue("#application['" + getVar() + "']", o);
/* 109 */     } else if ("session".equalsIgnoreCase(this.scope)) {
/* 110 */       stack.setValue("#session['" + getVar() + "']", o);
/* 111 */     } else if ("request".equalsIgnoreCase(this.scope)) {
/* 112 */       stack.setValue("#request['" + getVar() + "']", o);
/* 113 */     } else if ("page".equalsIgnoreCase(this.scope)) {
/* 114 */       stack.setValue("#attr['" + getVar() + "']", o, false);
/*     */     } else {
/* 116 */       stack.getContext().put(getVar(), o);
/* 117 */       stack.setValue("#attr['" + getVar() + "']", o, false);
/*     */     } 
/*     */     
/* 120 */     return super.end(writer, body);
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(required = true, description = "Name used to reference the value pushed into the Value Stack")
/*     */   public void setVar(String var) {
/* 125 */     super.setVar(var);
/*     */   }
/*     */ 
/*     */   
/*     */   @StrutsTagAttribute(description = "The scope in which to assign the variable. Can be <b>application</b>, <b>session</b>, <b>request</b>, <b>page</b>, or <b>action</b>.", defaultValue = "action")
/*     */   public void setScope(String scope) {
/* 131 */     this.scope = scope;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The value that is assigned to the variable named <i>name</i>")
/*     */   public void setValue(String value) {
/* 136 */     this.value = value;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Set to false to prevent the default whitespace-trim of this tag's body content", type = "Boolean", defaultValue = "true")
/*     */   public void setTrimBody(boolean trimBody) {
/* 141 */     this.trimBody = trimBody;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usesBody() {
/* 146 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Set.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */