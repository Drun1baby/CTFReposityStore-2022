/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "updownselect", tldTagClass = "org.apache.struts2.views.jsp.ui.UpDownSelectTag", description = "Create a Select component with buttons to move the elements in the select component up and down")
/*     */ public class UpDownSelect
/*     */   extends Select
/*     */ {
/*  77 */   private static final Logger LOG = LogManager.getLogger(UpDownSelect.class);
/*     */   
/*     */   public static final String TEMPLATE = "updownselect";
/*     */   
/*     */   protected String allowMoveUp;
/*     */   
/*     */   protected String allowMoveDown;
/*     */   
/*     */   protected String allowSelectAll;
/*     */   
/*     */   protected String moveUpLabel;
/*     */   protected String moveDownLabel;
/*     */   protected String selectAllLabel;
/*     */   
/*     */   public String getDefaultTemplate() {
/*  92 */     return "updownselect";
/*     */   }
/*     */   
/*     */   public UpDownSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  96 */     super(stack, request, response);
/*     */   }
/*     */   
/*     */   public void evaluateParams() {
/* 100 */     super.evaluateParams();
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (StringUtils.isBlank(this.size)) {
/* 105 */       addParameter("size", "5");
/*     */     }
/* 107 */     if (StringUtils.isBlank(this.multiple)) {
/* 108 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/*     */     
/* 111 */     if (this.allowMoveUp != null) {
/* 112 */       addParameter("allowMoveUp", findValue(this.allowMoveUp, Boolean.class));
/*     */     }
/* 114 */     if (this.allowMoveDown != null) {
/* 115 */       addParameter("allowMoveDown", findValue(this.allowMoveDown, Boolean.class));
/*     */     }
/* 117 */     if (this.allowSelectAll != null) {
/* 118 */       addParameter("allowSelectAll", findValue(this.allowSelectAll, Boolean.class));
/*     */     }
/*     */     
/* 121 */     if (this.moveUpLabel != null) {
/* 122 */       addParameter("moveUpLabel", findString(this.moveUpLabel));
/*     */     }
/* 124 */     if (this.moveDownLabel != null) {
/* 125 */       addParameter("moveDownLabel", findString(this.moveDownLabel));
/*     */     }
/* 127 */     if (this.selectAllLabel != null) {
/* 128 */       addParameter("selectAllLabel", findString(this.selectAllLabel));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 133 */     Form ancestorForm = (Form)findAncestor(Form.class);
/* 134 */     if (ancestorForm != null) {
/*     */ 
/*     */       
/* 137 */       enableAncestorFormCustomOnsubmit();
/*     */       
/* 139 */       Map<Object, Object> m = (Map)ancestorForm.getParameters().get("updownselectIds");
/* 140 */       if (m == null)
/*     */       {
/* 142 */         m = new LinkedHashMap<>();
/*     */       }
/* 144 */       m.put(getParameters().get("id"), getParameters().get("headerKey"));
/* 145 */       ancestorForm.getParameters().put("updownselectIds", m);
/*     */     
/*     */     }
/* 148 */     else if (LOG.isWarnEnabled()) {
/* 149 */       LOG.warn("no ancestor form found for updownselect " + this + ", therefore autoselect of all elements upon form submission will not work ");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllowMoveUp() {
/* 156 */     return this.allowMoveUp;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether move up button should be displayed", type = "Boolean", defaultValue = "true")
/*     */   public void setAllowMoveUp(String allowMoveUp) {
/* 161 */     this.allowMoveUp = allowMoveUp;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllowMoveDown() {
/* 167 */     return this.allowMoveDown;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether move down button should be displayed", type = "Boolean", defaultValue = "true")
/*     */   public void setAllowMoveDown(String allowMoveDown) {
/* 172 */     this.allowMoveDown = allowMoveDown;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllowSelectAll() {
/* 178 */     return this.allowSelectAll;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Whether or not select all button should be displayed", type = "Boolean", defaultValue = "true")
/*     */   public void setAllowSelectAll(String allowSelectAll) {
/* 183 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMoveUpLabel() {
/* 188 */     return this.moveUpLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Text to display on the move up button", defaultValue = "^")
/*     */   public void setMoveUpLabel(String moveUpLabel) {
/* 193 */     this.moveUpLabel = moveUpLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMoveDownLabel() {
/* 199 */     return this.moveDownLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Text to display on the move down button", defaultValue = "v")
/*     */   public void setMoveDownLabel(String moveDownLabel) {
/* 204 */     this.moveDownLabel = moveDownLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSelectAllLabel() {
/* 210 */     return this.selectAllLabel;
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "Text to display on the select all button", defaultValue = "*")
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 215 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\UpDownSelect.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */