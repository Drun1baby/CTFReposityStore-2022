/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.io.Writer;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @StrutsTag(name = "bean", tldTagClass = "org.apache.struts2.views.jsp.BeanTag", description = "Instantiate a JavaBean and place it in the context")
/*     */ public class Bean
/*     */   extends ContextBean
/*     */ {
/*  95 */   protected static final Logger LOG = LogManager.getLogger(Bean.class);
/*     */   
/*     */   protected Object bean;
/*     */   protected String name;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected ReflectionProvider reflectionProvider;
/*     */   
/*     */   public Bean(ValueStack stack) {
/* 103 */     super(stack);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 108 */     this.objectFactory = objectFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/* 113 */     this.reflectionProvider = prov;
/*     */   }
/*     */   
/*     */   public boolean start(Writer writer) {
/* 117 */     boolean result = super.start(writer);
/*     */     
/* 119 */     ValueStack stack = getStack();
/*     */     
/*     */     try {
/* 122 */       String beanName = findString(this.name, "name", "Bean name is required. Example: com.acme.FooBean or proper Spring bean ID");
/* 123 */       this.bean = this.objectFactory.buildBean(beanName, stack.getContext(), false);
/* 124 */     } catch (Exception e) {
/* 125 */       LOG.error("Could not instantiate bean", e);
/* 126 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     stack.push(this.bean);
/*     */ 
/*     */     
/* 133 */     putInContext(this.bean);
/*     */     
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public boolean end(Writer writer, String body) {
/* 139 */     ValueStack stack = getStack();
/* 140 */     stack.pop();
/*     */     
/* 142 */     return super.end(writer, body);
/*     */   }
/*     */   
/*     */   public void addParameter(String key, Object value) {
/* 146 */     this.reflectionProvider.setProperty(key, value, this.bean, getStack().getContext());
/*     */   }
/*     */   
/*     */   @StrutsTagAttribute(description = "The class name of the bean to be instantiated (must respect JavaBean specification)", required = true)
/*     */   public void setName(String name) {
/* 151 */     this.name = name;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\Bean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */