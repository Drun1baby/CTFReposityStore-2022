/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.Template;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDispatcherErrorHandler
/*     */   implements DispatcherErrorHandler
/*     */ {
/*  48 */   private static final Logger LOG = LogManager.getLogger(DefaultDispatcherErrorHandler.class);
/*     */   
/*     */   private FreemarkerManager freemarkerManager;
/*     */   private boolean devMode;
/*     */   private Template template;
/*     */   
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager freemarkerManager) {
/*  56 */     this.freemarkerManager = freemarkerManager;
/*     */   }
/*     */   
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String devMode) {
/*  61 */     this.devMode = BooleanUtils.toBoolean(devMode);
/*     */   }
/*     */   
/*     */   public void init(ServletContext ctx) {
/*     */     try {
/*  66 */       Configuration config = this.freemarkerManager.getConfiguration(ctx);
/*  67 */       this.template = config.getTemplate("/org/apache/struts2/dispatcher/error.ftl");
/*  68 */     } catch (IOException e) {
/*  69 */       throw new StrutsException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleError(HttpServletRequest request, HttpServletResponse response, int code, Exception e) {
/*  74 */     Boolean devModeOverride = PrepareOperations.getDevModeOverride();
/*  75 */     if ((devModeOverride != null) ? devModeOverride.booleanValue() : this.devMode) {
/*  76 */       handleErrorInDevMode(response, code, e);
/*     */     } else {
/*  78 */       sendErrorResponse(request, response, code, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sendErrorResponse(HttpServletRequest request, HttpServletResponse response, int code, Exception e) {
/*     */     try {
/*  85 */       if (code == 500) {
/*     */         
/*  87 */         LOG.error("Exception occurred during processing request: {}", e.getMessage(), e);
/*     */ 
/*     */         
/*  90 */         request.setAttribute("javax.servlet.error.exception", e);
/*     */ 
/*     */         
/*  93 */         request.setAttribute("javax.servlet.jsp.jspException", e);
/*     */       } 
/*     */ 
/*     */       
/*  97 */       response.sendError(code, e.getMessage());
/*  98 */     } catch (IOException e1) {
/*     */       
/* 100 */       LOG.warn("Unable to send error response, code: {};", Integer.valueOf(code), e1);
/* 101 */     } catch (IllegalStateException ise) {
/*     */       
/* 103 */       LOG.warn("Unable to send error response, code: {}; isCommited: {};", Integer.valueOf(code), Boolean.valueOf(response.isCommitted()), ise);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleErrorInDevMode(HttpServletResponse response, int code, Exception e) {
/* 108 */     LOG.debug("Exception occurred during processing request: {}", e.getMessage(), e);
/*     */     try {
/* 110 */       List<Throwable> chain = new ArrayList<>();
/* 111 */       Throwable cur = e;
/* 112 */       chain.add(cur);
/* 113 */       while ((cur = cur.getCause()) != null) {
/* 114 */         chain.add(cur);
/*     */       }
/*     */       
/* 117 */       Writer writer = new StringWriter();
/* 118 */       this.template.process(createReportData(e, chain), writer);
/*     */       
/* 120 */       response.setContentType("text/html");
/* 121 */       response.getWriter().write(writer.toString());
/* 122 */       response.getWriter().close();
/* 123 */     } catch (Exception exp) {
/*     */       try {
/* 125 */         LOG.debug("Cannot show problem report!", exp);
/* 126 */         response.sendError(code, "Unable to show problem report:\n" + exp + "\n\n" + LocationUtils.getLocation(exp));
/* 127 */       } catch (IOException ex) {
/*     */         
/* 129 */         LOG.warn("Unable to send error response, code: {};", Integer.valueOf(code), ex);
/* 130 */       } catch (IllegalStateException ise) {
/*     */         
/* 132 */         LOG.warn("Unable to send error response, code: {}; isCommited: {};", Integer.valueOf(code), Boolean.valueOf(response.isCommitted()), ise);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected HashMap<String, Object> createReportData(Exception e, List<Throwable> chain) {
/* 138 */     HashMap<String, Object> data = new HashMap<>();
/* 139 */     data.put("exception", e);
/* 140 */     data.put("unknown", Location.UNKNOWN);
/* 141 */     data.put("chain", chain);
/* 142 */     data.put("locator", new Dispatcher.Locator());
/* 143 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\DefaultDispatcherErrorHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */