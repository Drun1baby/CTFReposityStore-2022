/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestMap
/*     */   extends AbstractMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7675640869293787926L;
/*     */   private Set<Object> entries;
/*     */   private HttpServletRequest request;
/*     */   
/*     */   public RequestMap(HttpServletRequest request) {
/*  44 */     this.request = request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  52 */     this.entries = null;
/*  53 */     Enumeration<String> keys = this.request.getAttributeNames();
/*     */     
/*  55 */     while (keys.hasMoreElements()) {
/*  56 */       String key = keys.nextElement();
/*  57 */       this.request.removeAttribute(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/*  67 */     if (this.entries == null) {
/*  68 */       this.entries = new HashSet();
/*     */       
/*  70 */       Enumeration<E> enumeration = this.request.getAttributeNames();
/*     */       
/*  72 */       while (enumeration.hasMoreElements()) {
/*  73 */         final String key = enumeration.nextElement().toString();
/*  74 */         final Object value = this.request.getAttribute(key);
/*  75 */         this.entries.add(new Map.Entry<Object, Object>() {
/*     */               public boolean equals(Object obj) {
/*  77 */                 if (!(obj instanceof Map.Entry)) {
/*  78 */                   return false;
/*     */                 }
/*  80 */                 Map.Entry entry = (Map.Entry)obj;
/*     */                 
/*  82 */                 if ((key == null) ? (entry.getKey() == null) : key.equals(entry.getKey())) if ((value == null) ? (entry.getValue() == null) : value.equals(entry.getValue()));  return false;
/*     */               }
/*     */               
/*     */               public int hashCode() {
/*  86 */                 return ((key == null) ? 0 : key.hashCode()) ^ ((value == null) ? 0 : value.hashCode());
/*     */               }
/*     */               
/*     */               public Object getKey() {
/*  90 */                 return key;
/*     */               }
/*     */               
/*     */               public Object getValue() {
/*  94 */                 return value;
/*     */               }
/*     */               
/*     */               public Object setValue(Object obj) {
/*  98 */                 RequestMap.this.request.setAttribute(key, obj);
/*     */                 
/* 100 */                 return value;
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */     
/* 106 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 116 */     return this.request.getAttribute(key.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 127 */     Object oldValue = get(key);
/* 128 */     this.entries = null;
/* 129 */     this.request.setAttribute(key.toString(), value);
/* 130 */     return oldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 140 */     this.entries = null;
/*     */     
/* 142 */     Object value = get(key);
/* 143 */     this.request.removeAttribute(key.toString());
/*     */     
/* 145 */     return value;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\dispatcher\RequestMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */