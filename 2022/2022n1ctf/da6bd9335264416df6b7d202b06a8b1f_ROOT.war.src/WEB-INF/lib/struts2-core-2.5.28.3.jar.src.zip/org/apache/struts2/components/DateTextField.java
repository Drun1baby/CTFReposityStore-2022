/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @StrutsTag(name = "datetextfield", tldTagClass = "org.apache.struts2.views.jsp.ui.DateTextFieldTag", description = "Render an HTML input fields with the date time", allowDynamicAttributes = true)
/*    */ public class DateTextField
/*    */   extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "datetextfield";
/*    */   protected String format;
/*    */   
/*    */   public DateTextField(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 43 */     super(stack, request, response);
/*    */   }
/*    */   
/*    */   protected String getDefaultTemplate() {
/* 47 */     return "datetextfield";
/*    */   }
/*    */   
/*    */   protected void evaluateExtraParams() {
/* 51 */     super.evaluateExtraParams();
/*    */     
/* 53 */     if (this.format != null) {
/* 54 */       addParameter("format", findValue(this.format, String.class));
/*    */     }
/*    */   }
/*    */   
/*    */   @StrutsTagAttribute(description = "Date format attribute", required = true, type = "String")
/*    */   public void setFormat(String format) {
/* 60 */     this.format = format;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class getValueClassType() {
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\org\apache\struts2\components\DateTextField.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */