/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   public static final String DEFAULT_METHOD = "execute";
/*     */   public static final String WILDCARD = "*";
/*     */   public static final String DEFAULT_METHOD_REGEX = "([A-Za-z0-9_$]*)";
/*     */   protected List<InterceptorMapping> interceptors;
/*     */   protected Map<String, String> params;
/*     */   protected Map<String, ResultConfig> results;
/*     */   protected List<ExceptionMappingConfig> exceptionMappings;
/*     */   protected String className;
/*     */   protected String methodName;
/*     */   protected String packageName;
/*     */   protected String name;
/*     */   protected boolean strictMethodInvocation = true;
/*     */   protected AllowedMethods allowedMethods;
/*     */   
/*     */   protected ActionConfig(String packageName, String name, String className) {
/*  63 */     this.packageName = packageName;
/*  64 */     this.name = name;
/*  65 */     this.className = className;
/*  66 */     this.params = new LinkedHashMap<>();
/*  67 */     this.results = new LinkedHashMap<>();
/*  68 */     this.interceptors = new ArrayList<>();
/*  69 */     this.exceptionMappings = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ActionConfig(ActionConfig orig) {
/*  78 */     this.name = orig.name;
/*  79 */     this.className = orig.className;
/*  80 */     this.methodName = orig.methodName;
/*  81 */     this.packageName = orig.packageName;
/*  82 */     this.params = new LinkedHashMap<>(orig.params);
/*  83 */     this.interceptors = new ArrayList<>(orig.interceptors);
/*  84 */     this.results = new LinkedHashMap<>(orig.results);
/*  85 */     this.exceptionMappings = new ArrayList<>(orig.exceptionMappings);
/*  86 */     this.allowedMethods = orig.allowedMethods;
/*  87 */     this.location = orig.location;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  91 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  95 */     return this.className;
/*     */   }
/*     */   
/*     */   public List<ExceptionMappingConfig> getExceptionMappings() {
/*  99 */     return this.exceptionMappings;
/*     */   }
/*     */   
/*     */   public List<InterceptorMapping> getInterceptors() {
/* 103 */     return this.interceptors;
/*     */   }
/*     */   
/*     */   public Set<String> getAllowedMethods() {
/* 107 */     return this.allowedMethods.list();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName() {
/* 116 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/* 123 */     return this.packageName;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParams() {
/* 127 */     return this.params;
/*     */   }
/*     */   
/*     */   public Map<String, ResultConfig> getResults() {
/* 131 */     return this.results;
/*     */   }
/*     */   
/*     */   public boolean isAllowedMethod(String method) {
/* 135 */     return (method.equals((this.methodName != null) ? this.methodName : "execute") || this.allowedMethods.isAllowed(method));
/*     */   }
/*     */   
/*     */   public boolean isStrictMethodInvocation() {
/* 139 */     return this.strictMethodInvocation;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 143 */     if (this == o) {
/* 144 */       return true;
/*     */     }
/*     */     
/* 147 */     if (!(o instanceof ActionConfig)) {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     ActionConfig actionConfig = (ActionConfig)o;
/*     */     
/* 153 */     if ((this.className != null) ? !this.className.equals(actionConfig.className) : (actionConfig.className != null)) {
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     if ((this.name != null) ? !this.name.equals(actionConfig.name) : (actionConfig.name != null)) {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     if ((this.interceptors != null) ? !this.interceptors.equals(actionConfig.interceptors) : (actionConfig.interceptors != null))
/*     */     {
/* 163 */       return false;
/*     */     }
/*     */     
/* 166 */     if ((this.methodName != null) ? !this.methodName.equals(actionConfig.methodName) : (actionConfig.methodName != null)) {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     if ((this.params != null) ? !this.params.equals(actionConfig.params) : (actionConfig.params != null)) {
/* 171 */       return false;
/*     */     }
/*     */     
/* 174 */     if ((this.results != null) ? !this.results.equals(actionConfig.results) : (actionConfig.results != null)) {
/* 175 */       return false;
/*     */     }
/*     */     
/* 178 */     if ((this.allowedMethods != null) ? !this.allowedMethods.equals(actionConfig.allowedMethods) : (actionConfig.allowedMethods != null)) {
/* 179 */       return false;
/*     */     }
/*     */     
/* 182 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 187 */     int result = (this.interceptors != null) ? this.interceptors.hashCode() : 0;
/* 188 */     result = 31 * result + ((this.params != null) ? this.params.hashCode() : 0);
/* 189 */     result = 31 * result + ((this.results != null) ? this.results.hashCode() : 0);
/* 190 */     result = 31 * result + ((this.exceptionMappings != null) ? this.exceptionMappings.hashCode() : 0);
/* 191 */     result = 31 * result + ((this.className != null) ? this.className.hashCode() : 0);
/* 192 */     result = 31 * result + ((this.methodName != null) ? this.methodName.hashCode() : 0);
/* 193 */     result = 31 * result + ((this.packageName != null) ? this.packageName.hashCode() : 0);
/* 194 */     result = 31 * result + ((this.name != null) ? this.name.hashCode() : 0);
/* 195 */     result = 31 * result + ((this.allowedMethods != null) ? this.allowedMethods.hashCode() : 0);
/* 196 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 200 */     StringBuilder sb = new StringBuilder();
/* 201 */     sb.append("{ActionConfig ");
/* 202 */     sb.append(this.name).append(" (");
/* 203 */     sb.append(this.className);
/* 204 */     if (this.methodName != null) {
/* 205 */       sb.append(".").append(this.methodName).append("()");
/*     */     }
/* 207 */     sb.append(")");
/* 208 */     sb.append(" - ").append(this.location);
/* 209 */     sb.append(" - ").append(this.allowedMethods);
/* 210 */     sb.append("}");
/* 211 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     implements InterceptorListHolder
/*     */   {
/*     */     protected ActionConfig target;
/*     */     
/*     */     protected Set<String> allowedMethods;
/*     */     
/*     */     private String methodRegex;
/*     */ 
/*     */     
/*     */     public Builder(ActionConfig toClone) {
/* 226 */       this.target = new ActionConfig(toClone);
/* 227 */       this.allowedMethods = toClone.getAllowedMethods();
/*     */     }
/*     */     
/*     */     public Builder(String packageName, String name, String className) {
/* 231 */       this.target = new ActionConfig(packageName, name, className);
/* 232 */       this.allowedMethods = new HashSet<>();
/*     */     }
/*     */     
/*     */     public Builder packageName(String name) {
/* 236 */       this.target.packageName = name;
/* 237 */       return this;
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 241 */       this.target.name = name;
/* 242 */       return this;
/*     */     }
/*     */     
/*     */     public Builder className(String name) {
/* 246 */       this.target.className = name;
/* 247 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultClassName(String name) {
/* 251 */       if (StringUtils.isEmpty(this.target.className)) {
/* 252 */         this.target.className = name;
/*     */       }
/* 254 */       return this;
/*     */     }
/*     */     
/*     */     public Builder methodName(String method) {
/* 258 */       this.target.methodName = method;
/* 259 */       addAllowedMethod(method);
/* 260 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExceptionMapping(ExceptionMappingConfig exceptionMapping) {
/* 264 */       this.target.exceptionMappings.add(exceptionMapping);
/* 265 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExceptionMappings(Collection<? extends ExceptionMappingConfig> mappings) {
/* 269 */       this.target.exceptionMappings.addAll(mappings);
/* 270 */       return this;
/*     */     }
/*     */     
/*     */     public Builder exceptionMappings(Collection<? extends ExceptionMappingConfig> mappings) {
/* 274 */       this.target.exceptionMappings.clear();
/* 275 */       this.target.exceptionMappings.addAll(mappings);
/* 276 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addInterceptor(InterceptorMapping interceptor) {
/* 280 */       this.target.interceptors.add(interceptor);
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addInterceptors(List<InterceptorMapping> interceptors) {
/* 285 */       this.target.interceptors.addAll(interceptors);
/* 286 */       return this;
/*     */     }
/*     */     
/*     */     public Builder interceptors(List<InterceptorMapping> interceptors) {
/* 290 */       this.target.interceptors.clear();
/* 291 */       this.target.interceptors.addAll(interceptors);
/* 292 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, String value) {
/* 296 */       this.target.params.put(name, value);
/* 297 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, String> params) {
/* 301 */       this.target.params.putAll(params);
/* 302 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addResultConfig(ResultConfig resultConfig) {
/* 306 */       this.target.results.put(resultConfig.getName(), resultConfig);
/* 307 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addResultConfigs(Collection<ResultConfig> configs) {
/* 311 */       for (ResultConfig rc : configs) {
/* 312 */         this.target.results.put(rc.getName(), rc);
/*     */       }
/* 314 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addResultConfigs(Map<String, ResultConfig> configs) {
/* 318 */       this.target.results.putAll(configs);
/* 319 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllowedMethod(String methodName) {
/* 323 */       if (methodName != null) {
/* 324 */         this.allowedMethods.add(methodName);
/*     */       }
/* 326 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addAllowedMethod(Collection<String> methods) {
/* 330 */       this.allowedMethods.addAll(methods);
/* 331 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 335 */       this.target.location = loc;
/* 336 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setStrictMethodInvocation(boolean strictMethodInvocation) {
/* 340 */       this.target.strictMethodInvocation = strictMethodInvocation;
/* 341 */       return this;
/*     */     }
/*     */     
/*     */     public Builder setDefaultMethodRegex(String methodRegex) {
/* 345 */       this.methodRegex = methodRegex;
/* 346 */       return this;
/*     */     }
/*     */     
/*     */     public ActionConfig build() {
/* 350 */       this.target.params = Collections.unmodifiableMap(this.target.params);
/* 351 */       this.target.results = Collections.unmodifiableMap(this.target.results);
/* 352 */       this.target.interceptors = Collections.unmodifiableList(this.target.interceptors);
/* 353 */       this.target.exceptionMappings = Collections.unmodifiableList(this.target.exceptionMappings);
/* 354 */       this.target.allowedMethods = AllowedMethods.build(this.target.strictMethodInvocation, this.allowedMethods, (this.methodRegex != null) ? this.methodRegex : "([A-Za-z0-9_$]*)");
/*     */       
/* 356 */       ActionConfig result = this.target;
/* 357 */       this.target = new ActionConfig(this.target);
/* 358 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\ActionConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */