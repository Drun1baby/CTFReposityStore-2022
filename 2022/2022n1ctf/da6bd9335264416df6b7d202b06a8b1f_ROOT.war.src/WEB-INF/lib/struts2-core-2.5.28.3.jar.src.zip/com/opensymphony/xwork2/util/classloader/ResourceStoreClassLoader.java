/*    */ package com.opensymphony.xwork2.util.classloader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceStoreClassLoader
/*    */   extends ClassLoader
/*    */ {
/*    */   private final ResourceStore[] stores;
/*    */   
/*    */   public ResourceStoreClassLoader(ClassLoader pParent, ResourceStore[] pStores) {
/* 29 */     super(pParent);
/*    */     
/* 31 */     this.stores = new ResourceStore[pStores.length];
/* 32 */     System.arraycopy(pStores, 0, this.stores, 0, this.stores.length);
/*    */   }
/*    */ 
/*    */   
/*    */   private Class fastFindClass(String name) {
/* 37 */     if (this.stores != null) {
/* 38 */       String fileName = name.replace('.', '/') + ".class";
/* 39 */       for (ResourceStore store : this.stores) {
/* 40 */         byte[] clazzBytes = store.read(fileName);
/* 41 */         if (clazzBytes != null) {
/* 42 */           definePackage(name);
/* 43 */           return defineClass(name, clazzBytes, 0, clazzBytes.length);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   protected synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 52 */     Class<?> clazz = findLoadedClass(name);
/*    */     
/* 54 */     if (clazz == null) {
/* 55 */       clazz = fastFindClass(name);
/*    */       
/* 57 */       if (clazz == null) {
/* 58 */         ClassLoader parent = getParent();
/* 59 */         if (parent != null) {
/* 60 */           clazz = parent.loadClass(name);
/*    */         } else {
/* 62 */           throw new ClassNotFoundException(name);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     if (resolve) {
/* 68 */       resolveClass(clazz);
/*    */     }
/*    */     
/* 71 */     return clazz;
/*    */   }
/*    */   
/*    */   protected Class findClass(String name) throws ClassNotFoundException {
/* 75 */     Class clazz = fastFindClass(name);
/* 76 */     if (clazz == null) {
/* 77 */       throw new ClassNotFoundException(name);
/*    */     }
/* 79 */     return clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void definePackage(String className) {
/* 89 */     int classIndex = className.lastIndexOf('.');
/* 90 */     if (classIndex == -1) {
/*    */       return;
/*    */     }
/* 93 */     String packageName = className.substring(0, classIndex);
/* 94 */     if (getPackage(packageName) != null) {
/*    */       return;
/*    */     }
/* 97 */     definePackage(packageName, null, null, null, null, null, null, null);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\classloader\ResourceStoreClassLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */