/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.conversion.ConversionFileProcessor;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConversionFileProcessor
/*     */   implements ConversionFileProcessor
/*     */ {
/*  40 */   private static final Logger LOG = LogManager.getLogger(DefaultConversionFileProcessor.class);
/*     */   
/*     */   private FileManager fileManager;
/*     */   private TypeConverterCreator converterCreator;
/*     */   
/*     */   @Inject
/*     */   public void setFileManagerFactory(FileManagerFactory factory) {
/*  47 */     this.fileManager = factory.getFileManager();
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterCreator(TypeConverterCreator converterCreator) {
/*  52 */     this.converterCreator = converterCreator;
/*     */   }
/*     */   
/*     */   public void process(Map<String, Object> mapping, Class clazz, String converterFilename) {
/*     */     try {
/*  57 */       InputStream is = this.fileManager.loadFile(ClassLoaderUtil.getResource(converterFilename, clazz));
/*     */       
/*  59 */       if (is != null) {
/*  60 */         LOG.debug("Processing conversion file [{}] for class [{}]", converterFilename, clazz);
/*     */         
/*  62 */         Properties prop = new Properties();
/*  63 */         prop.load(is);
/*     */         
/*  65 */         for (Map.Entry<Object, Object> entry : prop.entrySet()) {
/*  66 */           String key = (String)entry.getKey();
/*     */           
/*  68 */           if (mapping.containsKey(key)) {
/*     */             break;
/*     */           }
/*     */           
/*  72 */           if (key.startsWith("KeyProperty_") || key.startsWith("CreateIfNull_")) {
/*     */             
/*  74 */             LOG.debug("\t{}:{} [treated as String]", key, entry.getValue());
/*  75 */             mapping.put(key, entry.getValue());
/*     */             continue;
/*     */           } 
/*  78 */           if (!key.startsWith("Element_") && !key.startsWith("Key_") && !key.startsWith("Collection_")) {
/*     */ 
/*     */ 
/*     */             
/*  82 */             TypeConverter _typeConverter = this.converterCreator.createTypeConverter((String)entry.getValue());
/*  83 */             LOG.debug("\t{}:{} [treated as TypeConverter {}]", key, entry.getValue(), _typeConverter);
/*  84 */             mapping.put(key, _typeConverter);
/*     */             continue;
/*     */           } 
/*  87 */           if (key.startsWith("Key_")) {
/*     */             
/*  89 */             Class converterClass = ClassLoaderUtil.loadClass((String)entry.getValue(), getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  94 */             if (converterClass.isAssignableFrom(TypeConverter.class)) {
/*  95 */               TypeConverter _typeConverter = this.converterCreator.createTypeConverter((String)entry.getValue());
/*  96 */               LOG.debug("\t{}:{} [treated as TypeConverter {}]", key, entry.getValue(), _typeConverter);
/*  97 */               mapping.put(key, _typeConverter); continue;
/*     */             } 
/*  99 */             LOG.debug("\t{}:{} [treated as Class {}]", key, entry.getValue(), converterClass);
/* 100 */             mapping.put(key, converterClass);
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 105 */           Class _c = ClassLoaderUtil.loadClass((String)entry.getValue(), getClass());
/* 106 */           LOG.debug("\t{}:{} [treated as Class {}]", key, entry.getValue(), _c);
/* 107 */           mapping.put(key, _c);
/*     */         }
/*     */       
/*     */       } 
/* 111 */     } catch (Exception ex) {
/* 112 */       LOG.error("Problem loading properties for {}", clazz.getName(), ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultConversionFileProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */