/*    */ package com.opensymphony.xwork2.validator.validators;
/*    */ 
/*    */ import com.opensymphony.xwork2.validator.ValidationException;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionValidator
/*    */   extends ValidatorSupport
/*    */ {
/* 52 */   private static final Logger LOG = LogManager.getLogger(ExpressionValidator.class);
/*    */   
/*    */   private String expression;
/*    */   
/*    */   public void setExpression(String expression) {
/* 57 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public String getExpression() {
/* 61 */     return this.expression;
/*    */   }
/*    */   
/*    */   public void validate(Object object) throws ValidationException {
/* 65 */     Boolean answer = Boolean.FALSE;
/* 66 */     Object obj = null;
/*    */     
/*    */     try {
/* 69 */       obj = getFieldValue(this.expression, object);
/* 70 */     } catch (ValidationException e) {
/* 71 */       throw e;
/* 72 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */     
/* 76 */     if (obj != null && obj instanceof Boolean) {
/* 77 */       answer = (Boolean)obj;
/*    */     } else {
/* 79 */       LOG.warn("Got result of [{}] when trying to get Boolean.", obj);
/*    */     } 
/*    */     
/* 82 */     if (!answer.booleanValue()) {
/* 83 */       LOG.debug("Validation failed on expression [{}] with validated object [{}]", this.expression, object);
/* 84 */       addActionError(object);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\ExpressionValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */