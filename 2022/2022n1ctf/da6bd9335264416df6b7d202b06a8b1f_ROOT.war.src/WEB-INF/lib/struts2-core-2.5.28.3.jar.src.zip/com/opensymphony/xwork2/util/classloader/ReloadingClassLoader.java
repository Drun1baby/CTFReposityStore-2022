/*     */ package com.opensymphony.xwork2.util.classloader;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReloadingClassLoader
/*     */   extends ClassLoader
/*     */ {
/*  51 */   private static final Logger LOG = LogManager.getLogger(ReloadingClassLoader.class);
/*     */   
/*     */   private final ClassLoader parent;
/*     */   private ResourceStore[] stores;
/*     */   private ClassLoader delegate;
/*  56 */   private Set<Pattern> acceptClasses = Collections.emptySet();
/*     */   
/*     */   public ReloadingClassLoader(ClassLoader pParent) {
/*  59 */     super(pParent);
/*  60 */     this.parent = pParent;
/*  61 */     URL parentRoot = pParent.getResource("");
/*  62 */     FileManager fileManager = ((FileManagerFactory)ActionContext.getContext().getInstance(FileManagerFactory.class)).getFileManager();
/*  63 */     URL root = fileManager.normalizeToFileProtocol(parentRoot);
/*  64 */     root = (URL)ObjectUtils.defaultIfNull(root, parentRoot);
/*     */     try {
/*  66 */       if (root != null) {
/*  67 */         this.stores = new ResourceStore[] { new FileResourceStore(new File(root.toURI())) };
/*     */       } else {
/*  69 */         throw new XWorkException("Unable to start the reloadable class loader, consider setting 'struts.convention.classes.reload' to false");
/*     */       } 
/*  71 */     } catch (URISyntaxException e) {
/*  72 */       throw new XWorkException("Unable to start the reloadable class loader, consider setting 'struts.convention.classes.reload' to false", e);
/*  73 */     } catch (RuntimeException e) {
/*     */ 
/*     */       
/*  76 */       if (root != null) {
/*  77 */         LOG.error("Exception while trying to build the ResourceStore for URL [{}]", root.toString(), e);
/*     */       } else {
/*     */         
/*  80 */         LOG.error("Exception while trying to get root resource from class loader", e);
/*     */       } 
/*  82 */       LOG.error("Consider setting struts.convention.classes.reload=false");
/*  83 */       throw e;
/*     */     } 
/*     */     
/*  86 */     this.delegate = new ResourceStoreClassLoader(this.parent, this.stores);
/*     */   }
/*     */   
/*     */   public boolean addResourceStore(ResourceStore pStore) {
/*     */     try {
/*  91 */       int n = this.stores.length;
/*  92 */       ResourceStore[] newStores = new ResourceStore[n + 1];
/*  93 */       System.arraycopy(this.stores, 0, newStores, 1, n);
/*  94 */       newStores[0] = pStore;
/*  95 */       this.stores = newStores;
/*  96 */       this.delegate = new ResourceStoreClassLoader(this.parent, this.stores);
/*  97 */       return true;
/*  98 */     } catch (RuntimeException e) {
/*  99 */       LOG.error("Could not add resource store", e);
/*     */       
/* 101 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean removeResourceStore(ResourceStore pStore) {
/* 106 */     int n = this.stores.length;
/* 107 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/* 111 */     while (i < n && this.stores[i] != pStore) {
/* 112 */       i++;
/*     */     }
/*     */ 
/*     */     
/* 116 */     if (i == n) {
/* 117 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 121 */     ResourceStore[] newStores = new ResourceStore[n - 1];
/* 122 */     if (i > 0) {
/* 123 */       System.arraycopy(this.stores, 0, newStores, 0, i);
/*     */     }
/* 125 */     if (i < n - 1) {
/* 126 */       System.arraycopy(this.stores, i + 1, newStores, i, n - i - 1);
/*     */     }
/*     */     
/* 129 */     this.stores = newStores;
/* 130 */     this.delegate = new ResourceStoreClassLoader(this.parent, this.stores);
/* 131 */     return true;
/*     */   }
/*     */   
/*     */   public void reload() {
/* 135 */     LOG.trace("Reloading class loader");
/* 136 */     this.delegate = new ResourceStoreClassLoader(this.parent, this.stores);
/*     */   }
/*     */   
/*     */   public void clearAssertionStatus() {
/* 140 */     this.delegate.clearAssertionStatus();
/*     */   }
/*     */   
/*     */   public URL getResource(String name) {
/* 144 */     return this.delegate.getResource(name);
/*     */   }
/*     */   
/*     */   public InputStream getResourceAsStream(String name) {
/* 148 */     return this.delegate.getResourceAsStream(name);
/*     */   }
/*     */   
/*     */   public Class loadClass(String name) throws ClassNotFoundException {
/* 152 */     return isAccepted(name) ? this.delegate.loadClass(name) : this.parent.loadClass(name);
/*     */   }
/*     */   
/*     */   public void setClassAssertionStatus(String className, boolean enabled) {
/* 156 */     this.delegate.setClassAssertionStatus(className, enabled);
/*     */   }
/*     */   
/*     */   public void setDefaultAssertionStatus(boolean enabled) {
/* 160 */     this.delegate.setDefaultAssertionStatus(enabled);
/*     */   }
/*     */   
/*     */   public void setPackageAssertionStatus(String packageName, boolean enabled) {
/* 164 */     this.delegate.setPackageAssertionStatus(packageName, enabled);
/*     */   }
/*     */   
/*     */   public void setAccepClasses(Set<Pattern> acceptClasses) {
/* 168 */     this.acceptClasses = acceptClasses;
/*     */   }
/*     */   
/*     */   protected boolean isAccepted(String className) {
/* 172 */     if (!this.acceptClasses.isEmpty()) {
/* 173 */       for (Pattern pattern : this.acceptClasses) {
/* 174 */         Matcher matcher = pattern.matcher(className);
/* 175 */         if (matcher.matches()) {
/* 176 */           return true;
/*     */         }
/*     */       } 
/* 179 */       return false;
/*     */     } 
/* 181 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\classloader\ReloadingClassLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */