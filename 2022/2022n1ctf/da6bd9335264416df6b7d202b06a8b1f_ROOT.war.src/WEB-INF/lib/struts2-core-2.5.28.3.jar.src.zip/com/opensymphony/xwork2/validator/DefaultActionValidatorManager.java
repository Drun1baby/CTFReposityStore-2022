/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultActionValidatorManager
/*     */   implements ActionValidatorManager
/*     */ {
/*  56 */   private static final Logger LOG = LogManager.getLogger(DefaultActionValidatorManager.class);
/*     */ 
/*     */   
/*     */   protected static final String VALIDATION_CONFIG_SUFFIX = "-validation.xml";
/*     */   
/*  61 */   private final Map<String, List<ValidatorConfig>> validatorCache = Collections.synchronizedMap(new HashMap<>());
/*  62 */   private final Map<String, List<ValidatorConfig>> validatorFileCache = Collections.synchronizedMap(new HashMap<>());
/*     */   
/*     */   private ValidatorFactory validatorFactory;
/*     */   private ValidatorFileParser validatorFileParser;
/*     */   private FileManager fileManager;
/*     */   private boolean reloadingConfigs;
/*     */   private TextProviderFactory textProviderFactory;
/*     */   
/*     */   @Inject
/*     */   public void setValidatorFileParser(ValidatorFileParser parser) {
/*  72 */     this.validatorFileParser = parser;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValidatorFactory(ValidatorFactory fac) {
/*  77 */     this.validatorFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/*  82 */     this.fileManager = fileManagerFactory.getFileManager();
/*     */   }
/*     */   
/*     */   @Inject(value = "reloadXmlConfiguration", required = false)
/*     */   public void setReloadingConfigs(String reloadingConfigs) {
/*  87 */     this.reloadingConfigs = Boolean.parseBoolean(reloadingConfigs);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTextProviderFactory(TextProviderFactory textProviderFactory) {
/*  92 */     this.textProviderFactory = textProviderFactory;
/*     */   }
/*     */   
/*     */   public synchronized List<Validator> getValidators(Class clazz, String context) {
/*  96 */     return getValidators(clazz, context, null);
/*     */   }
/*     */   
/*     */   public synchronized List<Validator> getValidators(Class clazz, String context, String method) {
/* 100 */     String validatorKey = buildValidatorKey(clazz, context);
/*     */     
/* 102 */     if (this.validatorCache.containsKey(validatorKey)) {
/* 103 */       if (this.reloadingConfigs) {
/* 104 */         this.validatorCache.put(validatorKey, buildValidatorConfigs(clazz, context, true, null));
/*     */       }
/*     */     } else {
/* 107 */       this.validatorCache.put(validatorKey, buildValidatorConfigs(clazz, context, false, null));
/*     */     } 
/* 109 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/*     */     
/* 112 */     List<ValidatorConfig> cfgs = this.validatorCache.get(validatorKey);
/*     */ 
/*     */     
/* 115 */     ArrayList<Validator> validators = new ArrayList<>(cfgs.size());
/* 116 */     for (ValidatorConfig cfg : cfgs) {
/* 117 */       if (method == null || method.equals(cfg.getParams().get("methodName"))) {
/* 118 */         Validator validator = this.validatorFactory.getValidator(cfg);
/* 119 */         validator.setValidatorType(cfg.getType());
/* 120 */         validator.setValueStack(stack);
/* 121 */         validators.add(validator);
/*     */       } 
/*     */     } 
/* 124 */     return validators;
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context) throws ValidationException {
/* 128 */     validate(object, context, (String)null);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, String method) throws ValidationException {
/* 132 */     ValidatorContext validatorContext = new DelegatingValidatorContext(object, this.textProviderFactory);
/* 133 */     validate(object, context, validatorContext, method);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, ValidatorContext validatorContext) throws ValidationException {
/* 137 */     validate(object, context, validatorContext, null);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, ValidatorContext validatorContext, String method) throws ValidationException {
/* 141 */     List<Validator> validators = getValidators(object.getClass(), context, method);
/* 142 */     Set<String> shortcircuitedFields = null;
/*     */     
/* 144 */     for (Validator validator : validators) {
/*     */       
/* 146 */       try { validator.setValidatorContext(validatorContext);
/*     */         
/* 148 */         LOG.debug("Running validator: {} for object {} and method {}", validator, object, method);
/*     */         
/* 150 */         FieldValidator fValidator = null;
/* 151 */         String fullFieldName = null;
/*     */         
/* 153 */         if (validator instanceof FieldValidator)
/* 154 */         { fValidator = (FieldValidator)validator;
/* 155 */           fullFieldName = fValidator.getValidatorContext().getFullFieldName(fValidator.getFieldName());
/*     */           
/* 157 */           if (shortcircuitedFields != null && shortcircuitedFields.contains(fullFieldName))
/* 158 */           { LOG.debug("Short-circuited, skipping");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 213 */             validator.setValidatorContext(null); continue; }  }  if (validator instanceof ShortCircuitableValidator && ((ShortCircuitableValidator)validator).isShortCircuit()) { List<String> errs = null; if (fValidator != null) { if (validatorContext.hasFieldErrors()) { Collection<String> fieldErrors = (Collection<String>)validatorContext.getFieldErrors().get(fullFieldName); if (fieldErrors != null) errs = new ArrayList<>(fieldErrors);  }  } else if (validatorContext.hasActionErrors()) { Collection<String> actionErrors = validatorContext.getActionErrors(); if (actionErrors != null) errs = new ArrayList<>(actionErrors);  }  validator.validate(object); if (fValidator != null) { if (validatorContext.hasFieldErrors()) { Collection<String> errCol = (Collection<String>)validatorContext.getFieldErrors().get(fullFieldName); if (errCol != null && !errCol.equals(errs)) { LOG.debug("Short-circuiting on field validation"); if (shortcircuitedFields == null) shortcircuitedFields = new TreeSet<>();  shortcircuitedFields.add(fullFieldName); }  }  } else if (validatorContext.hasActionErrors()) { Collection<String> errCol = validatorContext.getActionErrors(); if (errCol != null && !errCol.equals(errs)) { LOG.debug("Short-circuiting"); validator.setValidatorContext(null); break; }  }  validator.setValidatorContext(null); continue; }  validator.validate(object); } finally { validator.setValidatorContext(null); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String buildValidatorKey(Class clazz, String context) {
/* 226 */     StringBuilder sb = new StringBuilder(clazz.getName());
/* 227 */     sb.append("/");
/* 228 */     sb.append(context);
/* 229 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private List<ValidatorConfig> buildAliasValidatorConfigs(Class aClass, String context, boolean checkFile) {
/* 233 */     String fileName = aClass.getName().replace('.', '/') + "-" + context + "-validation.xml";
/*     */     
/* 235 */     return loadFile(fileName, aClass, checkFile);
/*     */   }
/*     */   
/*     */   private List<ValidatorConfig> buildClassValidatorConfigs(Class aClass, boolean checkFile) {
/* 239 */     String fileName = aClass.getName().replace('.', '/') + "-validation.xml";
/*     */     
/* 241 */     return loadFile(fileName, aClass, checkFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ValidatorConfig> buildValidatorConfigs(Class clazz, String context, boolean checkFile, Set<String> checked) {
/* 287 */     List<ValidatorConfig> validatorConfigs = new ArrayList<>();
/*     */     
/* 289 */     if (checked == null) {
/* 290 */       checked = new TreeSet<>();
/* 291 */     } else if (checked.contains(clazz.getName())) {
/* 292 */       return validatorConfigs;
/*     */     } 
/*     */     
/* 295 */     if (clazz.isInterface()) {
/* 296 */       for (Class<?> anInterface : clazz.getInterfaces()) {
/* 297 */         validatorConfigs.addAll(buildValidatorConfigs(anInterface, context, checkFile, checked));
/*     */       }
/*     */     }
/* 300 */     else if (!clazz.equals(Object.class)) {
/* 301 */       validatorConfigs.addAll(buildValidatorConfigs(clazz.getSuperclass(), context, checkFile, checked));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 306 */     for (Class<?> anInterface1 : clazz.getInterfaces()) {
/* 307 */       if (!checked.contains(anInterface1.getName())) {
/*     */ 
/*     */ 
/*     */         
/* 311 */         validatorConfigs.addAll(buildClassValidatorConfigs(anInterface1, checkFile));
/*     */         
/* 313 */         if (context != null) {
/* 314 */           validatorConfigs.addAll(buildAliasValidatorConfigs(anInterface1, context, checkFile));
/*     */         }
/*     */         
/* 317 */         checked.add(anInterface1.getName());
/*     */       } 
/*     */     } 
/* 320 */     validatorConfigs.addAll(buildClassValidatorConfigs(clazz, checkFile));
/*     */     
/* 322 */     if (context != null) {
/* 323 */       validatorConfigs.addAll(buildAliasValidatorConfigs(clazz, context, checkFile));
/*     */     }
/*     */     
/* 326 */     checked.add(clazz.getName());
/*     */     
/* 328 */     return validatorConfigs;
/*     */   }
/*     */   
/*     */   private List<ValidatorConfig> loadFile(String fileName, Class clazz, boolean checkFile) {
/* 332 */     List<ValidatorConfig> retList = Collections.emptyList();
/* 333 */     URL fileUrl = ClassLoaderUtil.getResource(fileName, clazz);
/* 334 */     if ((checkFile && this.fileManager.fileNeedsReloading(fileUrl)) || !this.validatorFileCache.containsKey(fileName)) {
/* 335 */       try (InputStream is = this.fileManager.loadFile(fileUrl)) {
/* 336 */         if (is != null) {
/* 337 */           retList = new ArrayList<>(this.validatorFileParser.parseActionValidatorConfigs(this.validatorFactory, is, fileName));
/*     */         }
/* 339 */       } catch (IOException e) {
/* 340 */         LOG.error("Caught exception while loading file {}", fileName, e);
/*     */       } 
/*     */       
/* 343 */       this.validatorFileCache.put(fileName, retList);
/*     */     } else {
/* 345 */       retList = this.validatorFileCache.get(fileName);
/*     */     } 
/*     */     
/* 348 */     return retList;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\DefaultActionValidatorManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */