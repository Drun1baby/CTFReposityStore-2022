package com.opensymphony.xwork2.util;

public interface ClearableValueStack {
  void clearContextValues();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ClearableValueStack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */