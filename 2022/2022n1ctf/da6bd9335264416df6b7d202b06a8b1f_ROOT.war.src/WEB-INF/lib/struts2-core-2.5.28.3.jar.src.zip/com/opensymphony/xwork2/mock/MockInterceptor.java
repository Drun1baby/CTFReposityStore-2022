/*     */ package com.opensymphony.xwork2.mock;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import org.junit.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MockInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 2692551676567227756L;
/*     */   public static final String DEFAULT_FOO_VALUE = "fooDefault";
/*  37 */   private String expectedFoo = "fooDefault";
/*  38 */   private String foo = "fooDefault";
/*     */   
/*     */   private boolean executed = false;
/*     */   
/*     */   public boolean isExecuted() {
/*  43 */     return this.executed;
/*     */   }
/*     */   
/*     */   public void setExpectedFoo(String expectedFoo) {
/*  47 */     this.expectedFoo = expectedFoo;
/*     */   }
/*     */   
/*     */   public String getExpectedFoo() {
/*  51 */     return this.expectedFoo;
/*     */   }
/*     */   
/*     */   public void setFoo(String foo) {
/*  55 */     this.foo = foo;
/*     */   }
/*     */   
/*     */   public String getFoo() {
/*  59 */     return this.foo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  64 */     if (this == o) {
/*  65 */       return true;
/*     */     }
/*     */     
/*  68 */     if (!(o instanceof MockInterceptor)) {
/*  69 */       return false;
/*     */     }
/*     */     
/*  72 */     MockInterceptor testInterceptor = (MockInterceptor)o;
/*     */     
/*  74 */     if (this.executed != testInterceptor.executed) {
/*  75 */       return false;
/*     */     }
/*     */     
/*  78 */     if ((this.expectedFoo != null) ? !this.expectedFoo.equals(testInterceptor.expectedFoo) : (testInterceptor.expectedFoo != null))
/*     */     {
/*  80 */       return false;
/*     */     }
/*     */     
/*  83 */     if ((this.foo != null) ? !this.foo.equals(testInterceptor.foo) : (testInterceptor.foo != null)) {
/*  84 */       return false;
/*     */     }
/*     */     
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  93 */     int result = (this.expectedFoo != null) ? this.expectedFoo.hashCode() : 0;
/*  94 */     result = 29 * result + ((this.foo != null) ? this.foo.hashCode() : 0);
/*  95 */     result = 29 * result + (this.executed ? 1 : 0);
/*     */     
/*  97 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 105 */     this.executed = true;
/* 106 */     Assert.assertNotSame("fooDefault", this.foo);
/* 107 */     Assert.assertEquals(this.expectedFoo, this.foo);
/*     */     
/* 109 */     return invocation.invoke();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */