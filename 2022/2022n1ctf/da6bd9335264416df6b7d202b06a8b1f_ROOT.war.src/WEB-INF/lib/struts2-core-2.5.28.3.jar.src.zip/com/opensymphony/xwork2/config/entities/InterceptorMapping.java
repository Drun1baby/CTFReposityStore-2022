/*    */ package com.opensymphony.xwork2.config.entities;
/*    */ 
/*    */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterceptorMapping
/*    */   implements Serializable
/*    */ {
/*    */   private String name;
/*    */   private Interceptor interceptor;
/*    */   private final Map<String, String> params;
/*    */   
/*    */   public InterceptorMapping(String name, Interceptor interceptor) {
/* 40 */     this(name, interceptor, new HashMap<>());
/*    */   }
/*    */   
/*    */   public InterceptorMapping(String name, Interceptor interceptor, Map<String, String> params) {
/* 44 */     this.name = name;
/* 45 */     this.interceptor = interceptor;
/* 46 */     this.params = params;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public Interceptor getInterceptor() {
/* 54 */     return this.interceptor;
/*    */   }
/*    */   
/*    */   public Map<String, String> getParams() {
/* 58 */     return this.params;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 63 */     if (this == o) return true; 
/* 64 */     if (o == null || getClass() != o.getClass()) return false;
/*    */     
/* 66 */     InterceptorMapping that = (InterceptorMapping)o;
/*    */     
/* 68 */     if ((this.name != null) ? !this.name.equals(that.name) : (that.name != null)) return false;
/*    */     
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 76 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 77 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "InterceptorMapping: [" + this.name + "] => [" + this.interceptor.getClass().getName() + "] with params [" + this.params + "]";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\InterceptorMapping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */