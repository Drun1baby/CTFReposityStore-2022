/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptorStackConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2897260918170270343L;
/*     */   protected List<InterceptorMapping> interceptors;
/*     */   protected String name;
/*     */   
/*     */   protected InterceptorStackConfig() {
/*  55 */     this.interceptors = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InterceptorStackConfig(InterceptorStackConfig orig) {
/*  64 */     this.name = orig.name;
/*  65 */     this.interceptors = new ArrayList<>(orig.interceptors);
/*  66 */     this.location = orig.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<InterceptorMapping> getInterceptors() {
/*  76 */     return this.interceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  85 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 101 */     if (this == o) {
/* 102 */       return true;
/*     */     }
/*     */     
/* 105 */     if (!(o instanceof InterceptorStackConfig)) {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     InterceptorStackConfig interceptorStackConfig = (InterceptorStackConfig)o;
/*     */     
/* 111 */     if ((this.interceptors != null) ? !this.interceptors.equals(interceptorStackConfig.interceptors) : (interceptorStackConfig.interceptors != null)) {
/* 112 */       return false;
/*     */     }
/*     */     
/* 115 */     if ((this.name != null) ? !this.name.equals(interceptorStackConfig.name) : (interceptorStackConfig.name != null)) {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 130 */     result = 29 * result + ((this.interceptors != null) ? this.interceptors.hashCode() : 0);
/*     */     
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     return "InterceptorStackConfig: [" + this.name + "] contains " + this.interceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     implements InterceptorListHolder
/*     */   {
/*     */     protected InterceptorStackConfig target;
/*     */ 
/*     */     
/*     */     public Builder(String name) {
/* 149 */       this.target = new InterceptorStackConfig();
/* 150 */       this.target.name = name;
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 154 */       this.target.name = name;
/* 155 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addInterceptor(InterceptorMapping interceptor) {
/* 166 */       this.target.interceptors.add(interceptor);
/* 167 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addInterceptors(List<InterceptorMapping> interceptors) {
/* 178 */       this.target.interceptors.addAll(interceptors);
/* 179 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 183 */       this.target.location = loc;
/* 184 */       return this;
/*     */     }
/*     */     
/*     */     public InterceptorStackConfig build() {
/* 188 */       embalmTarget();
/* 189 */       InterceptorStackConfig result = this.target;
/* 190 */       this.target = new InterceptorStackConfig(this.target);
/* 191 */       return result;
/*     */     }
/*     */     
/*     */     protected void embalmTarget() {
/* 195 */       this.target.interceptors = Collections.unmodifiableList(this.target.interceptors);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\InterceptorStackConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */