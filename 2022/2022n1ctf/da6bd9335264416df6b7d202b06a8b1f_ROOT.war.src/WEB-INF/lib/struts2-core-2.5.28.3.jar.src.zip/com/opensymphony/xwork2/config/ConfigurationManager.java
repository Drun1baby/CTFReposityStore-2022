/*     */ package com.opensymphony.xwork2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.impl.DefaultConfiguration;
/*     */ import com.opensymphony.xwork2.config.providers.XWorkConfigurationProvider;
/*     */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationManager
/*     */ {
/*  44 */   protected static final Logger LOG = LogManager.getLogger(ConfigurationManager.class);
/*     */   protected Configuration configuration;
/*  46 */   protected Lock providerLock = new ReentrantLock();
/*  47 */   private List<ContainerProvider> containerProviders = new CopyOnWriteArrayList<>();
/*  48 */   private List<PackageProvider> packageProviders = new CopyOnWriteArrayList<>();
/*     */   protected String defaultFrameworkBeanName;
/*     */   private boolean providersChanged = false;
/*     */   private boolean reloadConfigs = true;
/*     */   
/*     */   public ConfigurationManager(String name) {
/*  54 */     this.defaultFrameworkBeanName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Configuration getConfiguration() {
/*  63 */     if (this.configuration == null) {
/*  64 */       setConfiguration(createConfiguration(this.defaultFrameworkBeanName));
/*     */       try {
/*  66 */         this.configuration.reloadContainer(getContainerProviders());
/*  67 */       } catch (ConfigurationException e) {
/*  68 */         setConfiguration(null);
/*  69 */         throw new ConfigurationException("Unable to load configuration.", e);
/*     */       } 
/*     */     } else {
/*  72 */       conditionalReload();
/*     */     } 
/*     */     
/*  75 */     return this.configuration;
/*     */   }
/*     */   
/*     */   protected Configuration createConfiguration(String beanName) {
/*  79 */     return (Configuration)new DefaultConfiguration(beanName);
/*     */   }
/*     */   
/*     */   public synchronized void setConfiguration(Configuration configuration) {
/*  83 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ContainerProvider> getContainerProviders() {
/* 101 */     this.providerLock.lock();
/*     */     try {
/* 103 */       if (this.containerProviders.size() == 0) {
/* 104 */         this.containerProviders.add(new XWorkConfigurationProvider());
/* 105 */         this.containerProviders.add(new XmlConfigurationProvider("xwork.xml", false));
/*     */       } 
/*     */       
/* 108 */       return this.containerProviders;
/*     */     } finally {
/* 110 */       this.providerLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerProviders(List<ContainerProvider> containerProviders) {
/* 120 */     this.providerLock.lock();
/*     */     try {
/* 122 */       this.containerProviders = new CopyOnWriteArrayList<>(containerProviders);
/* 123 */       this.providersChanged = true;
/*     */     } finally {
/* 125 */       this.providerLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContainerProvider(ContainerProvider provider) {
/* 136 */     if (!this.containerProviders.contains(provider)) {
/* 137 */       this.containerProviders.add(provider);
/* 138 */       this.providersChanged = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearContainerProviders() {
/* 143 */     for (ContainerProvider containerProvider : this.containerProviders) {
/* 144 */       clearContainerProvider(containerProvider);
/*     */     }
/* 146 */     this.containerProviders.clear();
/* 147 */     this.providersChanged = true;
/*     */   }
/*     */   
/*     */   private void clearContainerProvider(ContainerProvider containerProvider) {
/*     */     try {
/* 152 */       containerProvider.destroy();
/* 153 */     } catch (Exception e) {
/* 154 */       LOG.warn("Error while destroying container provider [{}]", containerProvider.toString(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void destroyConfiguration() {
/* 162 */     clearContainerProviders();
/* 163 */     this.containerProviders = new CopyOnWriteArrayList<>();
/* 164 */     if (this.configuration != null)
/* 165 */       this.configuration.destroy(); 
/* 166 */     this.configuration = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void conditionalReload() {
/* 174 */     if (this.reloadConfigs || this.providersChanged) {
/* 175 */       LOG.debug("Checking ConfigurationProviders for reload.");
/* 176 */       List<ContainerProvider> providers = getContainerProviders();
/* 177 */       boolean reload = needReloadContainerProviders(providers);
/* 178 */       if (!reload) {
/* 179 */         reload = needReloadPackageProviders();
/*     */       }
/* 181 */       if (reload) {
/* 182 */         reloadProviders(providers);
/*     */       }
/* 184 */       updateReloadConfigsFlag();
/* 185 */       this.providersChanged = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateReloadConfigsFlag() {
/* 190 */     this.reloadConfigs = Boolean.parseBoolean((String)this.configuration.getContainer().getInstance(String.class, "reloadXmlConfiguration"));
/* 191 */     if (LOG.isDebugEnabled()) {
/* 192 */       LOG.debug("Updating [{}], current value is [{}], new value [{}]", "reloadXmlConfiguration", String.valueOf(this.reloadConfigs), String.valueOf(this.reloadConfigs));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean needReloadPackageProviders() {
/* 198 */     if (this.packageProviders != null) {
/* 199 */       for (PackageProvider provider : this.packageProviders) {
/* 200 */         if (provider.needsReload()) {
/* 201 */           LOG.info("Detected package provider [{}] needs to be reloaded. Reloading all providers.", provider);
/* 202 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/* 206 */     return false;
/*     */   }
/*     */   
/*     */   private boolean needReloadContainerProviders(List<ContainerProvider> providers) {
/* 210 */     for (ContainerProvider provider : providers) {
/* 211 */       if (provider.needsReload()) {
/* 212 */         LOG.info("Detected container provider [{}] needs to be reloaded. Reloading all providers.", provider);
/* 213 */         return true;
/*     */       } 
/*     */     } 
/* 216 */     return false;
/*     */   }
/*     */   
/*     */   private void reloadProviders(List<ContainerProvider> providers) {
/* 220 */     for (ContainerProvider containerProvider : this.containerProviders) {
/*     */       try {
/* 222 */         containerProvider.destroy();
/* 223 */       } catch (Exception e) {
/* 224 */         LOG.warn("error while destroying configuration provider [{}]", containerProvider, e);
/*     */       } 
/*     */     } 
/* 227 */     this.packageProviders = this.configuration.reloadContainer(providers);
/*     */   }
/*     */   
/*     */   public synchronized void reload() {
/* 231 */     this.packageProviders = getConfiguration().reloadContainer(getContainerProviders());
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\ConfigurationManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */