/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationAttributes;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DomHelper
/*     */ {
/*  50 */   private static final Logger LOG = LogManager.getLogger(DomHelper.class);
/*     */   
/*     */   public static final String XMLNS_URI = "http://www.w3.org/2000/xmlns/";
/*     */   
/*     */   public static Location getLocationObject(Element element) {
/*  55 */     return LocationAttributes.getLocation(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(InputSource inputSource) {
/*  69 */     return parse(inputSource, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document parse(InputSource inputSource, Map<String, String> dtdMappings) {
/*     */     SAXParser parser;
/*  85 */     SAXParserFactory factory = null;
/*  86 */     String parserProp = System.getProperty("xwork.saxParserFactory");
/*  87 */     if (parserProp != null) {
/*     */       try {
/*  89 */         ObjectFactory objectFactory = (ObjectFactory)ActionContext.getContext().getContainer().getInstance(ObjectFactory.class);
/*  90 */         Class<SAXParserFactory> clazz = objectFactory.getClassInstance(parserProp);
/*  91 */         factory = clazz.newInstance();
/*  92 */       } catch (Exception e) {
/*  93 */         LOG.error("Unable to load saxParserFactory set by system property 'xwork.saxParserFactory': {}", parserProp, e);
/*     */       } 
/*     */     }
/*     */     
/*  97 */     if (factory == null) {
/*  98 */       factory = SAXParserFactory.newInstance();
/*     */     }
/*     */     
/* 101 */     factory.setValidating((dtdMappings != null));
/* 102 */     factory.setNamespaceAware(true);
/*     */ 
/*     */     
/*     */     try {
/* 106 */       parser = factory.newSAXParser();
/* 107 */     } catch (Exception ex) {
/* 108 */       throw new XWorkException("Unable to create SAX parser", ex);
/*     */     } 
/*     */ 
/*     */     
/* 112 */     DOMBuilder builder = new DOMBuilder();
/*     */ 
/*     */     
/* 115 */     LocationAttributes.Pipe pipe = new LocationAttributes.Pipe(builder);
/*     */     
/*     */     try {
/* 118 */       parser.parse(inputSource, new StartHandler((ContentHandler)pipe, dtdMappings));
/* 119 */     } catch (Exception ex) {
/* 120 */       throw new XWorkException(ex);
/*     */     } 
/*     */     
/* 123 */     return builder.getDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DOMBuilder
/*     */     implements ContentHandler
/*     */   {
/*     */     protected static SAXTransformerFactory FACTORY;
/*     */ 
/*     */     
/*     */     protected SAXTransformerFactory factory;
/*     */ 
/*     */     
/*     */     protected DOMResult result;
/*     */ 
/*     */     
/*     */     protected Node parentNode;
/*     */ 
/*     */     
/*     */     protected ContentHandler nextHandler;
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 149 */       String parserProp = System.getProperty("xwork.saxTransformerFactory");
/* 150 */       if (parserProp != null) {
/*     */         try {
/* 152 */           ObjectFactory objectFactory = (ObjectFactory)ActionContext.getContext().getContainer().getInstance(ObjectFactory.class);
/* 153 */           Class<SAXTransformerFactory> clazz = objectFactory.getClassInstance(parserProp);
/* 154 */           FACTORY = clazz.newInstance();
/* 155 */         } catch (Exception e) {
/* 156 */           DomHelper.LOG.error("Unable to load SAXTransformerFactory set by system property 'xwork.saxTransformerFactory': {}", parserProp, e);
/*     */         } 
/*     */       }
/*     */       
/* 160 */       if (FACTORY == null) {
/* 161 */         FACTORY = (SAXTransformerFactory)TransformerFactory.newInstance();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DOMBuilder() {
/* 169 */       this((Node)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DOMBuilder(SAXTransformerFactory factory) {
/* 177 */       this(factory, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DOMBuilder(Node parentNode) {
/* 186 */       this(null, parentNode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DOMBuilder(SAXTransformerFactory factory, Node parentNode) {
/* 196 */       this.factory = (factory == null) ? FACTORY : factory;
/* 197 */       this.parentNode = parentNode;
/* 198 */       setup();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setup() {
/*     */       try {
/* 206 */         TransformerHandler handler = this.factory.newTransformerHandler();
/* 207 */         this.nextHandler = handler;
/* 208 */         if (this.parentNode != null) {
/* 209 */           this.result = new DOMResult(this.parentNode);
/*     */         } else {
/* 211 */           this.result = new DOMResult();
/*     */         } 
/* 213 */         handler.setResult(this.result);
/* 214 */       } catch (TransformerException local) {
/* 215 */         throw new XWorkException("Fatal-Error: Unable to get transformer handler", local);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Document getDocument() {
/* 225 */       if (this.result == null || this.result.getNode() == null)
/* 226 */         return null; 
/* 227 */       if (this.result.getNode().getNodeType() == 9) {
/* 228 */         return (Document)this.result.getNode();
/*     */       }
/* 230 */       return this.result.getNode().getOwnerDocument();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setDocumentLocator(Locator locator) {
/* 235 */       this.nextHandler.setDocumentLocator(locator);
/*     */     }
/*     */     
/*     */     public void startDocument() throws SAXException {
/* 239 */       this.nextHandler.startDocument();
/*     */     }
/*     */     
/*     */     public void endDocument() throws SAXException {
/* 243 */       this.nextHandler.endDocument();
/*     */     }
/*     */     
/*     */     public void startElement(String uri, String loc, String raw, Attributes attrs) throws SAXException {
/* 247 */       this.nextHandler.startElement(uri, loc, raw, attrs);
/*     */     }
/*     */     
/*     */     public void endElement(String arg0, String arg1, String arg2) throws SAXException {
/* 251 */       this.nextHandler.endElement(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void startPrefixMapping(String arg0, String arg1) throws SAXException {
/* 255 */       this.nextHandler.startPrefixMapping(arg0, arg1);
/*     */     }
/*     */     
/*     */     public void endPrefixMapping(String arg0) throws SAXException {
/* 259 */       this.nextHandler.endPrefixMapping(arg0);
/*     */     }
/*     */     
/*     */     public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
/* 263 */       this.nextHandler.characters(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void ignorableWhitespace(char[] arg0, int arg1, int arg2) throws SAXException {
/* 267 */       this.nextHandler.ignorableWhitespace(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void processingInstruction(String arg0, String arg1) throws SAXException {
/* 271 */       this.nextHandler.processingInstruction(arg0, arg1);
/*     */     }
/*     */     
/*     */     public void skippedEntity(String arg0) throws SAXException {
/* 275 */       this.nextHandler.skippedEntity(arg0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StartHandler
/*     */     extends DefaultHandler
/*     */   {
/*     */     private ContentHandler nextHandler;
/*     */     
/*     */     private Map<String, String> dtdMappings;
/*     */ 
/*     */     
/*     */     public StartHandler(ContentHandler next, Map<String, String> dtdMappings) {
/* 290 */       this.nextHandler = next;
/* 291 */       this.dtdMappings = dtdMappings;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setDocumentLocator(Locator locator) {
/* 296 */       this.nextHandler.setDocumentLocator(locator);
/*     */     }
/*     */ 
/*     */     
/*     */     public void startDocument() throws SAXException {
/* 301 */       this.nextHandler.startDocument();
/*     */     }
/*     */ 
/*     */     
/*     */     public void endDocument() throws SAXException {
/* 306 */       this.nextHandler.endDocument();
/*     */     }
/*     */ 
/*     */     
/*     */     public void startElement(String uri, String loc, String raw, Attributes attrs) throws SAXException {
/* 311 */       this.nextHandler.startElement(uri, loc, raw, attrs);
/*     */     }
/*     */ 
/*     */     
/*     */     public void endElement(String arg0, String arg1, String arg2) throws SAXException {
/* 316 */       this.nextHandler.endElement(arg0, arg1, arg2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void startPrefixMapping(String arg0, String arg1) throws SAXException {
/* 321 */       this.nextHandler.startPrefixMapping(arg0, arg1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void endPrefixMapping(String arg0) throws SAXException {
/* 326 */       this.nextHandler.endPrefixMapping(arg0);
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
/* 331 */       this.nextHandler.characters(arg0, arg1, arg2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void ignorableWhitespace(char[] arg0, int arg1, int arg2) throws SAXException {
/* 336 */       this.nextHandler.ignorableWhitespace(arg0, arg1, arg2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void processingInstruction(String arg0, String arg1) throws SAXException {
/* 341 */       this.nextHandler.processingInstruction(arg0, arg1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void skippedEntity(String arg0) throws SAXException {
/* 346 */       this.nextHandler.skippedEntity(arg0);
/*     */     }
/*     */ 
/*     */     
/*     */     public InputSource resolveEntity(String publicId, String systemId) {
/* 351 */       if (this.dtdMappings != null && this.dtdMappings.containsKey(publicId)) {
/* 352 */         String dtdFile = this.dtdMappings.get(publicId);
/* 353 */         return new InputSource(ClassLoaderUtil.getResourceAsStream(dtdFile, DomHelper.class));
/*     */       } 
/* 355 */       DomHelper.LOG.warn("Local DTD is missing for publicID: {} - defined mappings: {}", publicId, this.dtdMappings);
/*     */       
/* 357 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void warning(SAXParseException exception) {}
/*     */ 
/*     */     
/*     */     public void error(SAXParseException exception) throws SAXException {
/* 366 */       DomHelper.LOG.error("{} at ({}:{}:{})", exception.getMessage(), exception.getPublicId(), Integer.valueOf(exception.getLineNumber()), Integer.valueOf(exception.getColumnNumber()), exception);
/* 367 */       throw exception;
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatalError(SAXParseException exception) throws SAXException {
/* 372 */       DomHelper.LOG.fatal("{} at ({}:{}:{})", exception.getMessage(), exception.getPublicId(), Integer.valueOf(exception.getLineNumber()), Integer.valueOf(exception.getColumnNumber()), exception);
/* 373 */       throw exception;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\DomHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */