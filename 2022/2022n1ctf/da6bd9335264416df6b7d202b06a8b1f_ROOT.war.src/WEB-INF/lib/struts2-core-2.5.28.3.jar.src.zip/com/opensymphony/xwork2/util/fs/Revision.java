/*    */ package com.opensymphony.xwork2.util.fs;
/*    */ 
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Revision
/*    */ {
/*    */   public boolean needsReloading() {
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public static Revision build(URL fileUrl) {
/* 36 */     return new Revision();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\Revision.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */