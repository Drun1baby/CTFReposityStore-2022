/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptorConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   protected Map<String, String> params;
/*     */   protected String className;
/*     */   protected String name;
/*     */   
/*     */   protected InterceptorConfig(String name, String className) {
/*  45 */     this.params = new LinkedHashMap<>();
/*  46 */     this.name = name;
/*  47 */     this.className = className;
/*     */   }
/*     */   
/*     */   protected InterceptorConfig(InterceptorConfig orig) {
/*  51 */     this.name = orig.name;
/*  52 */     this.className = orig.className;
/*  53 */     this.params = new LinkedHashMap<>(orig.params);
/*  54 */     this.location = orig.location;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  58 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParams() {
/*  66 */     return this.params;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  71 */     if (this == o) {
/*  72 */       return true;
/*     */     }
/*     */     
/*  75 */     if (!(o instanceof InterceptorConfig)) {
/*  76 */       return false;
/*     */     }
/*     */     
/*  79 */     InterceptorConfig interceptorConfig = (InterceptorConfig)o;
/*     */     
/*  81 */     if ((this.className != null) ? !this.className.equals(interceptorConfig.className) : (interceptorConfig.className != null)) {
/*  82 */       return false;
/*     */     }
/*     */     
/*  85 */     if ((this.name != null) ? !this.name.equals(interceptorConfig.name) : (interceptorConfig.name != null)) {
/*  86 */       return false;
/*     */     }
/*     */     
/*  89 */     if ((this.params != null) ? !this.params.equals(interceptorConfig.params) : (interceptorConfig.params != null)) {
/*  90 */       return false;
/*     */     }
/*     */     
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  99 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 100 */     result = 29 * result + ((this.className != null) ? this.className.hashCode() : 0);
/* 101 */     result = 29 * result + ((this.params != null) ? this.params.hashCode() : 0);
/*     */     
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return "InterceptorConfig: [" + this.name + "] => [" + this.className + "] with params " + this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     protected InterceptorConfig target;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(String name, String className) {
/* 120 */       this.target = new InterceptorConfig(name, className);
/*     */     }
/*     */     
/*     */     public Builder(InterceptorConfig orig) {
/* 124 */       this.target = new InterceptorConfig(orig);
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 128 */       this.target.name = name;
/* 129 */       return this;
/*     */     }
/*     */     
/*     */     public Builder className(String name) {
/* 133 */       this.target.className = name;
/* 134 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, String value) {
/* 138 */       this.target.params.put(name, value);
/* 139 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, String> params) {
/* 143 */       this.target.params.putAll(params);
/* 144 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 148 */       this.target.location = loc;
/* 149 */       return this;
/*     */     }
/*     */     
/*     */     public InterceptorConfig build() {
/* 153 */       embalmTarget();
/* 154 */       InterceptorConfig result = this.target;
/* 155 */       this.target = new InterceptorConfig(this.target);
/* 156 */       return result;
/*     */     }
/*     */     
/*     */     protected void embalmTarget() {
/* 160 */       this.target.params = Collections.unmodifiableMap(this.target.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\InterceptorConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */