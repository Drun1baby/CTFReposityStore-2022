/*    */ package com.opensymphony.xwork2.interceptor;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.Serializable;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionHolder
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Exception exception;
/*    */   
/*    */   public ExceptionHolder(Exception exception) {
/* 47 */     this.exception = exception;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Exception getException() {
/* 56 */     return this.exception;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getExceptionStack() {
/* 65 */     String exceptionStack = null;
/*    */     
/* 67 */     if (getException() != null) {
/* 68 */       try(StringWriter sw = new StringWriter(); 
/* 69 */           PrintWriter pw = new PrintWriter(sw)) {
/* 70 */         getException().printStackTrace(pw);
/* 71 */         exceptionStack = sw.toString();
/* 72 */       } catch (IOException iOException) {}
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 77 */     return exceptionStack;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ExceptionHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */