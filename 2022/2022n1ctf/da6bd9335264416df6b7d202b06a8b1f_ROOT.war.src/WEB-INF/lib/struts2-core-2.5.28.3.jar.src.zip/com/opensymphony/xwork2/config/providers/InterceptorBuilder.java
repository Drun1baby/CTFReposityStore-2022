/*     */ package com.opensymphony.xwork2.config.providers;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorLocator;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorStackConfig;
/*     */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptorBuilder
/*     */ {
/*  48 */   private static final Logger LOG = LogManager.getLogger(InterceptorBuilder.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<InterceptorMapping> constructInterceptorReference(InterceptorLocator interceptorLocator, String refName, Map<String, String> refParams, Location location, ObjectFactory objectFactory) throws ConfigurationException {
/*  63 */     Object referencedConfig = interceptorLocator.getInterceptorConfig(refName);
/*  64 */     List<InterceptorMapping> result = new ArrayList<>();
/*     */     
/*  66 */     if (referencedConfig == null) {
/*  67 */       throw new ConfigurationException("Unable to find interceptor class referenced by ref-name " + refName, location);
/*     */     }
/*  69 */     if (referencedConfig instanceof InterceptorConfig) {
/*  70 */       InterceptorConfig config = (InterceptorConfig)referencedConfig;
/*     */       
/*     */       try {
/*  73 */         Interceptor inter = objectFactory.buildInterceptor(config, refParams);
/*  74 */         result.add(new InterceptorMapping(refName, inter, refParams));
/*  75 */       } catch (ConfigurationException ex) {
/*  76 */         LOG.warn((Message)new ParameterizedMessage("Unable to load config class {} at {} probably due to a missing jar, which might be fine if you never plan to use the {} interceptor", new Object[] { config.getClassName(), ex.getLocation(), config.getName() }), (Throwable)ex);
/*     */       }
/*     */     
/*     */     }
/*  80 */     else if (referencedConfig instanceof InterceptorStackConfig) {
/*  81 */       InterceptorStackConfig stackConfig = (InterceptorStackConfig)referencedConfig;
/*     */       
/*  83 */       if (refParams != null && refParams.size() > 0) {
/*  84 */         result = constructParameterizedInterceptorReferences(interceptorLocator, stackConfig, refParams, objectFactory);
/*     */       } else {
/*  86 */         result.addAll(stackConfig.getInterceptors());
/*     */       } 
/*     */     } else {
/*     */       
/*  90 */       LOG.error("Got unexpected type for interceptor {}. Got {}", refName, referencedConfig);
/*     */     } 
/*     */ 
/*     */     
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<InterceptorMapping> constructParameterizedInterceptorReferences(InterceptorLocator interceptorLocator, InterceptorStackConfig stackConfig, Map<String, String> refParams, ObjectFactory objectFactory) {
/* 110 */     Map<String, Map<String, String>> params = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     for (Map.Entry<String, String> entry : refParams.entrySet()) {
/* 134 */       String key = entry.getKey();
/*     */       try {
/*     */         Map<String, String> map;
/* 137 */         String name = key.substring(0, key.indexOf('.'));
/* 138 */         key = key.substring(key.indexOf('.') + 1);
/*     */ 
/*     */         
/* 141 */         if (params.containsKey(name)) {
/* 142 */           map = params.get(name);
/*     */         } else {
/* 144 */           map = new LinkedHashMap<>();
/*     */         } 
/*     */         
/* 147 */         map.put(key, entry.getValue());
/* 148 */         params.put(name, map);
/*     */       }
/* 150 */       catch (Exception e) {
/* 151 */         LOG.warn("No interceptor found for name = {}", key);
/*     */       } 
/*     */     } 
/*     */     
/* 155 */     List<InterceptorMapping> result = new ArrayList<>(stackConfig.getInterceptors());
/*     */     
/* 157 */     for (Map.Entry<String, Map<String, String>> entry : params.entrySet()) {
/* 158 */       String key = entry.getKey();
/* 159 */       Map<String, String> map = entry.getValue();
/*     */ 
/*     */       
/* 162 */       Object interceptorCfgObj = interceptorLocator.getInterceptorConfig(key);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       if (interceptorCfgObj instanceof InterceptorConfig) {
/* 181 */         InterceptorConfig cfg = (InterceptorConfig)interceptorCfgObj;
/* 182 */         Interceptor interceptor = objectFactory.buildInterceptor(cfg, map);
/*     */         
/* 184 */         InterceptorMapping mapping = new InterceptorMapping(key, interceptor);
/* 185 */         if (result.contains(mapping)) {
/* 186 */           for (int index = 0; index < result.size(); index++) {
/* 187 */             InterceptorMapping interceptorMapping = result.get(index);
/* 188 */             if (interceptorMapping.getName().equals(key)) {
/* 189 */               LOG.debug("Overriding interceptor config [{}] with new mapping {} using new params {}", key, interceptorMapping, map);
/* 190 */               result.set(index, mapping);
/*     */             } 
/*     */           }  continue;
/*     */         } 
/* 194 */         result.add(mapping);
/*     */         continue;
/*     */       } 
/* 197 */       if (interceptorCfgObj instanceof InterceptorStackConfig) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         InterceptorStackConfig stackCfg = (InterceptorStackConfig)interceptorCfgObj;
/* 204 */         List<InterceptorMapping> tmpResult = constructParameterizedInterceptorReferences(interceptorLocator, stackCfg, map, objectFactory);
/* 205 */         for (InterceptorMapping tmpInterceptorMapping : tmpResult) {
/* 206 */           if (result.contains(tmpInterceptorMapping)) {
/* 207 */             int index = result.indexOf(tmpInterceptorMapping);
/* 208 */             result.set(index, tmpInterceptorMapping); continue;
/*     */           } 
/* 210 */           result.add(tmpInterceptorMapping);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 216 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\InterceptorBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */