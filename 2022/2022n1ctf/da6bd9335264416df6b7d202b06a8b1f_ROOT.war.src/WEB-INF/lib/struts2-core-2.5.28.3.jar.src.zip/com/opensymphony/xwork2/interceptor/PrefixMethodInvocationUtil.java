/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixMethodInvocationUtil
/*     */ {
/*  69 */   private static final Logger LOG = LogManager.getLogger(PrefixMethodInvocationUtil.class);
/*     */   
/*     */   private static final String DEFAULT_INVOCATION_METHODNAME = "execute";
/*     */   
/*  73 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokePrefixMethod(ActionInvocation actionInvocation, String[] prefixes) throws InvocationTargetException, IllegalAccessException {
/* 121 */     Object action = actionInvocation.getAction();
/*     */     
/* 123 */     String methodName = actionInvocation.getProxy().getMethod();
/*     */     
/* 125 */     if (methodName == null)
/*     */     {
/* 127 */       methodName = "execute";
/*     */     }
/*     */     
/* 130 */     Method method = getPrefixedMethod(prefixes, methodName, action);
/* 131 */     if (method != null) {
/* 132 */       method.invoke(action, new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getPrefixedMethod(String[] prefixes, String methodName, Object action) {
/* 151 */     assert prefixes != null;
/* 152 */     String capitalizedMethodName = capitalizeMethodName(methodName);
/* 153 */     for (String prefixe : prefixes) {
/* 154 */       String prefixedMethodName = prefixe + capitalizedMethodName;
/*     */       try {
/* 156 */         return action.getClass().getMethod(prefixedMethodName, EMPTY_CLASS_ARRAY);
/*     */       }
/* 158 */       catch (NoSuchMethodException e) {
/*     */         
/* 160 */         LOG.debug("Cannot find method [{}] in action [{}]", prefixedMethodName, action);
/*     */       } 
/*     */     } 
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String capitalizeMethodName(String methodName) {
/* 177 */     assert methodName != null;
/* 178 */     return methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\PrefixMethodInvocationUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */