/*     */ package com.opensymphony.xwork2.config.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.ContainerProvider;
/*     */ import com.opensymphony.xwork2.config.PackageProvider;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.UnknownHandlerConfig;
/*     */ import com.opensymphony.xwork2.config.providers.XWorkConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MockConfiguration
/*     */   implements Configuration
/*     */ {
/*  40 */   private Map<String, PackageConfig> packages = new HashMap<>();
/*  41 */   private Set<String> loadedFiles = new HashSet<>();
/*     */   private Container container;
/*     */   protected List<UnknownHandlerConfig> unknownHandlerStack;
/*     */   private ContainerBuilder builder;
/*     */   
/*     */   public MockConfiguration() {
/*  47 */     this.builder = new ContainerBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public void selfRegister() {
/*  52 */     this.builder.factory(Configuration.class, MockConfiguration.class, Scope.SINGLETON);
/*  53 */     LocatableProperties props = new LocatableProperties();
/*  54 */     (new XWorkConfigurationProvider()).register(this.builder, props);
/*  55 */     this.builder.constant("devMode", "false");
/*  56 */     this.builder.constant("reloadXmlConfiguration", "true");
/*  57 */     this.builder.constant("enableOGNLExpressionCache", "true");
/*  58 */     this.builder.constant("struts.enable.DynamicMethodInvocation", "false");
/*  59 */     this.container = this.builder.create(true);
/*     */   }
/*     */   
/*     */   public PackageConfig getPackageConfig(String name) {
/*  63 */     return this.packages.get(name);
/*     */   }
/*     */   
/*     */   public Set<String> getPackageConfigNames() {
/*  67 */     return this.packages.keySet();
/*     */   }
/*     */   
/*     */   public Map<String, PackageConfig> getPackageConfigs() {
/*  71 */     return this.packages;
/*     */   }
/*     */   
/*     */   public RuntimeConfiguration getRuntimeConfiguration() {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void addPackageConfig(String name, PackageConfig packageContext) {
/*  79 */     this.packages.put(name, packageContext);
/*     */   }
/*     */   
/*     */   public void buildRuntimeConfiguration() {
/*  83 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void destroy() {
/*  87 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void rebuildRuntimeConfiguration() {
/*  91 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PackageConfig removePackageConfig(String name) {
/*  95 */     return this.packages.remove(name);
/*     */   }
/*     */   
/*     */   public Container getContainer() {
/*  99 */     return this.container;
/*     */   }
/*     */   
/*     */   public Set<String> getLoadedFileNames() {
/* 103 */     return this.loadedFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PackageProvider> reloadContainer(List<ContainerProvider> containerProviders) throws ConfigurationException {
/* 109 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public List<UnknownHandlerConfig> getUnknownHandlerStack() {
/* 113 */     return this.unknownHandlerStack;
/*     */   }
/*     */   
/*     */   public void setUnknownHandlerStack(List<UnknownHandlerConfig> unknownHandlerStack) {
/* 117 */     this.unknownHandlerStack = unknownHandlerStack;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\MockConfiguration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */