package com.opensymphony.xwork2.inject;

import java.io.Serializable;
import java.util.Set;

public interface Container extends Serializable {
  public static final String DEFAULT_NAME = "default";
  
  void inject(Object paramObject);
  
  <T> T inject(Class<T> paramClass);
  
  <T> T getInstance(Class<T> paramClass, String paramString);
  
  <T> T getInstance(Class<T> paramClass);
  
  Set<String> getInstanceNames(Class<?> paramClass);
  
  void setScopeStrategy(Scope.Strategy paramStrategy);
  
  void removeScopeStrategy();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\Container.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */