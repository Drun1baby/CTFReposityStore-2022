/*    */ package com.opensymphony.xwork2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.StringTokenizer;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationUtil
/*    */ {
/* 38 */   private static final Logger LOG = LogManager.getLogger(ConfigurationUtil.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<PackageConfig> buildParentsFromString(Configuration configuration, String parent) {
/* 50 */     List<String> parentPackageNames = buildParentListFromString(parent);
/* 51 */     List<PackageConfig> parentPackageConfigs = new ArrayList<>();
/* 52 */     for (String parentPackageName : parentPackageNames) {
/* 53 */       PackageConfig parentPackageContext = configuration.getPackageConfig(parentPackageName);
/*    */       
/* 55 */       if (parentPackageContext != null) {
/* 56 */         parentPackageConfigs.add(parentPackageContext);
/*    */       }
/*    */     } 
/*    */     
/* 60 */     return parentPackageConfigs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<String> buildParentListFromString(String parent) {
/* 69 */     if (StringUtils.isEmpty(parent)) {
/* 70 */       return Collections.emptyList();
/*    */     }
/*    */     
/* 73 */     StringTokenizer tokenizer = new StringTokenizer(parent, ",");
/* 74 */     List<String> parents = new ArrayList<>();
/*    */     
/* 76 */     while (tokenizer.hasMoreTokens()) {
/* 77 */       String parentName = tokenizer.nextToken().trim();
/*    */       
/* 79 */       if (StringUtils.isNotEmpty(parentName)) {
/* 80 */         parents.add(parentName);
/*    */       }
/*    */     } 
/*    */     
/* 84 */     return parents;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\ConfigurationUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */