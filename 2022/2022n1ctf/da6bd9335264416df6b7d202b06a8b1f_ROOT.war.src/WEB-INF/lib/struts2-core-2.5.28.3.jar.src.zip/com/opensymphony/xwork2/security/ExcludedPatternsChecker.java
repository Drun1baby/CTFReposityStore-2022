/*    */ package com.opensymphony.xwork2.security;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ExcludedPatternsChecker
/*    */ {
/*    */   IsExcluded isExcluded(String paramString);
/*    */   
/*    */   void setExcludedPatterns(String paramString);
/*    */   
/*    */   void setExcludedPatterns(String[] paramArrayOfString);
/*    */   
/*    */   void setExcludedPatterns(Set<String> paramSet);
/*    */   
/*    */   Set<Pattern> getExcludedPatterns();
/*    */   
/*    */   public static final class IsExcluded
/*    */   {
/*    */     private final boolean excluded;
/*    */     private final String excludedPattern;
/*    */     
/*    */     public static IsExcluded yes(Pattern excludedPattern) {
/* 71 */       return new IsExcluded(true, excludedPattern.pattern());
/*    */     }
/*    */     
/*    */     public static IsExcluded no(Set<Pattern> excludedPatterns) {
/* 75 */       return new IsExcluded(false, excludedPatterns.toString());
/*    */     }
/*    */     
/*    */     private IsExcluded(boolean excluded, String excludedPattern) {
/* 79 */       this.excluded = excluded;
/* 80 */       this.excludedPattern = excludedPattern;
/*    */     }
/*    */     
/*    */     public boolean isExcluded() {
/* 84 */       return this.excluded;
/*    */     }
/*    */     
/*    */     public String getExcludedPattern() {
/* 88 */       return this.excludedPattern;
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 93 */       return "IsExcluded { excluded=" + this.excluded + ", excludedPattern=" + this.excludedPattern + " }";
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\security\ExcludedPatternsChecker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */