/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassPathFinder
/*     */ {
/*     */   private String pattern;
/*     */   private int[] compiledPattern;
/*  54 */   private PatternMatcher<int[]> patternMatcher = new WildcardHelper();
/*     */   
/*  56 */   private Vector<String> compared = new Vector<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/*  62 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern) {
/*  69 */     this.pattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector<String> findMatches() {
/*  80 */     Vector<String> matches = new Vector<>();
/*  81 */     URL[] parentUrls = getClassLoaderURLs();
/*  82 */     this.compiledPattern = this.patternMatcher.compilePattern(this.pattern);
/*  83 */     for (URL url : parentUrls) {
/*  84 */       if ("file".equals(url.getProtocol())) {
/*     */         URI entryURI;
/*     */ 
/*     */         
/*     */         try {
/*  89 */           entryURI = url.toURI();
/*  90 */         } catch (URISyntaxException e) {}
/*     */ 
/*     */         
/*  93 */         File entry = new File(entryURI);
/*  94 */         if (entry.isFile() && entry.toString().endsWith(".jar")) {
/*     */           try {
/*  96 */             ZipInputStream zip = new ZipInputStream(new FileInputStream(entry));
/*  97 */             for (ZipEntry zipEntry = zip.getNextEntry(); zipEntry != null; zipEntry = zip.getNextEntry()) {
/*  98 */               boolean doesMatch = this.patternMatcher.match(new HashMap<>(), zipEntry.getName(), this.compiledPattern);
/*  99 */               if (doesMatch) {
/* 100 */                 matches.add(zipEntry.getName());
/*     */               }
/*     */             } 
/* 103 */           } catch (IOException e) {
/* 104 */             e.printStackTrace();
/*     */           } 
/*     */         } else {
/* 107 */           Vector<String> results = checkEntries(entry.list(), entry, "");
/* 108 */           if (results != null)
/* 109 */             matches.addAll(results); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 113 */     return matches;
/*     */   }
/*     */ 
/*     */   
/*     */   private Vector<String> checkEntries(String[] entries, File parent, String prefix) {
/* 118 */     if (entries == null) {
/* 119 */       return null;
/*     */     }
/*     */     
/* 122 */     Vector<String> matches = new Vector<>();
/* 123 */     for (String listEntry : entries) {
/*     */       File tempFile;
/* 125 */       if (!"".equals(prefix)) {
/* 126 */         tempFile = new File(parent, prefix + "/" + listEntry);
/*     */       } else {
/*     */         
/* 129 */         tempFile = new File(parent, listEntry);
/*     */       } 
/* 131 */       if (tempFile.isDirectory() && !".".equals(listEntry) && !"..".equals(listEntry)) {
/*     */         
/* 133 */         if (!"".equals(prefix)) {
/* 134 */           matches.addAll(checkEntries(tempFile.list(), parent, prefix + "/" + listEntry));
/*     */         } else {
/*     */           
/* 137 */           matches.addAll(checkEntries(tempFile.list(), parent, listEntry));
/*     */         } 
/*     */       } else {
/*     */         String entryToCheck;
/*     */ 
/*     */         
/* 143 */         if ("".equals(prefix)) {
/* 144 */           entryToCheck = listEntry;
/*     */         } else {
/*     */           
/* 147 */           entryToCheck = prefix + "/" + listEntry;
/*     */         } 
/*     */         
/* 150 */         if (!this.compared.contains(entryToCheck)) {
/*     */ 
/*     */ 
/*     */           
/* 154 */           this.compared.add(entryToCheck);
/*     */ 
/*     */           
/* 157 */           boolean doesMatch = this.patternMatcher.match(new HashMap<>(), entryToCheck, this.compiledPattern);
/* 158 */           if (doesMatch)
/* 159 */             matches.add(entryToCheck); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 163 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternMatcher(PatternMatcher<int[]> patternMatcher) {
/* 170 */     this.patternMatcher = patternMatcher;
/*     */   }
/*     */   
/*     */   private URL[] getClassLoaderURLs() {
/*     */     URL[] urls;
/* 175 */     ClassLoader loader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 177 */     if (!(loader instanceof URLClassLoader)) {
/* 178 */       loader = ClassPathFinder.class.getClassLoader();
/*     */     }
/*     */     
/* 181 */     if (loader instanceof URLClassLoader) {
/* 182 */       urls = ((URLClassLoader)loader).getURLs();
/*     */     } else {
/*     */       try {
/* 185 */         urls = (URL[])Collections.<URL>list(loader.getResources("")).toArray((Object[])new URL[0]);
/* 186 */       } catch (IOException e) {
/* 187 */         throw new XWorkException("unable to get ClassLoader URLs", e);
/*     */       } 
/*     */     } 
/*     */     
/* 191 */     return urls;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ClassPathFinder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */