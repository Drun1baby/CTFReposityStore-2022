/*    */ package com.opensymphony.xwork2.util.fs;
/*    */ 
/*    */ import com.opensymphony.xwork2.FileManager;
/*    */ import java.net.URL;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarEntryRevision
/*    */   extends Revision
/*    */ {
/* 34 */   private static Logger LOG = LogManager.getLogger(JarEntryRevision.class);
/*    */   
/*    */   private URL jarFileURL;
/*    */   private long lastModified;
/*    */   
/*    */   public static Revision build(URL fileUrl, FileManager fileManager) {
/* 40 */     try (StrutsJarURLConnection conn = StrutsJarURLConnection.openConnection(fileUrl)) {
/* 41 */       conn.setUseCaches(false);
/* 42 */       URL url = fileManager.normalizeToFileProtocol(fileUrl);
/* 43 */       if (url != null) {
/* 44 */         return new JarEntryRevision(fileUrl, conn.getJarEntry().getTime());
/*    */       }
/* 46 */       return null;
/*    */     }
/* 48 */     catch (Throwable e) {
/* 49 */       LOG.warn("Could not create JarEntryRevision for [{}]!", fileUrl, e);
/* 50 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   private JarEntryRevision(URL jarFileURL, long lastModified) {
/* 55 */     if (jarFileURL == null) {
/* 56 */       throw new IllegalArgumentException("jarFileURL cannot be null");
/*    */     }
/* 58 */     this.jarFileURL = jarFileURL;
/* 59 */     this.lastModified = lastModified;
/*    */   }
/*    */   
/*    */   public boolean needsReloading() {
/* 63 */     long lastLastModified = this.lastModified;
/* 64 */     try (StrutsJarURLConnection conn = StrutsJarURLConnection.openConnection(this.jarFileURL)) {
/* 65 */       conn.setUseCaches(false);
/* 66 */       lastLastModified = conn.getJarEntry().getTime();
/* 67 */     } catch (Throwable e) {
/* 68 */       LOG.warn("Could not check if needsReloading for [{}]!", this.jarFileURL, e);
/*    */     } 
/*    */     
/* 71 */     return (this.lastModified < lastLastModified);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\JarEntryRevision.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */