package com.opensymphony.xwork2.util.finder;

import java.net.URL;
import java.util.Collection;
import java.util.Set;

public interface ClassFinderFactory {
  ClassFinder buildClassFinder(ClassLoaderInterface paramClassLoaderInterface, Collection<URL> paramCollection, boolean paramBoolean, Set<String> paramSet, Test<String> paramTest);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\finder\ClassFinderFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */