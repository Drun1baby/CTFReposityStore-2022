/*    */ package com.opensymphony.xwork2.interceptor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingInterceptor
/*    */   extends AbstractInterceptor
/*    */ {
/* 64 */   private static final Logger LOG = LogManager.getLogger(LoggingInterceptor.class);
/*    */   
/*    */   private static final String FINISH_MESSAGE = "Finishing execution stack for action ";
/*    */   private static final String START_MESSAGE = "Starting execution stack for action ";
/*    */   
/*    */   public String intercept(ActionInvocation invocation) throws Exception {
/* 70 */     logMessage(invocation, "Starting execution stack for action ");
/* 71 */     String result = invocation.invoke();
/* 72 */     logMessage(invocation, "Finishing execution stack for action ");
/* 73 */     return result;
/*    */   }
/*    */   
/*    */   private void logMessage(ActionInvocation invocation, String baseMessage) {
/* 77 */     if (LOG.isInfoEnabled()) {
/* 78 */       StringBuilder message = new StringBuilder(baseMessage);
/* 79 */       String namespace = invocation.getProxy().getNamespace();
/*    */       
/* 81 */       if (namespace != null && namespace.trim().length() > 0) {
/* 82 */         message.append(namespace).append("/");
/*    */       }
/*    */       
/* 85 */       message.append(invocation.getProxy().getActionName());
/* 86 */       LOG.info(message.toString());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\LoggingInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */