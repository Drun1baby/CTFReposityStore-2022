/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.interceptor.ValidationAware;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationAwareSupport
/*     */   implements ValidationAware, Serializable
/*     */ {
/*     */   private Collection<String> actionErrors;
/*     */   private Collection<String> actionMessages;
/*     */   private Map<String, List<String>> fieldErrors;
/*     */   
/*     */   public synchronized void setActionErrors(Collection<String> errorMessages) {
/*  42 */     this.actionErrors = errorMessages;
/*     */   }
/*     */   
/*     */   public synchronized Collection<String> getActionErrors() {
/*  46 */     return new LinkedList<>(internalGetActionErrors());
/*     */   }
/*     */   
/*     */   public synchronized void setActionMessages(Collection<String> messages) {
/*  50 */     this.actionMessages = messages;
/*     */   }
/*     */   
/*     */   public synchronized Collection<String> getActionMessages() {
/*  54 */     return new LinkedList<>(internalGetActionMessages());
/*     */   }
/*     */   
/*     */   public synchronized void setFieldErrors(Map<String, List<String>> errorMap) {
/*  58 */     this.fieldErrors = errorMap;
/*     */   }
/*     */   
/*     */   public synchronized Map<String, List<String>> getFieldErrors() {
/*  62 */     return new LinkedHashMap<>(internalGetFieldErrors());
/*     */   }
/*     */   
/*     */   public synchronized void addActionError(String anErrorMessage) {
/*  66 */     internalGetActionErrors().add(anErrorMessage);
/*     */   }
/*     */   
/*     */   public synchronized void addActionMessage(String aMessage) {
/*  70 */     internalGetActionMessages().add(aMessage);
/*     */   }
/*     */   
/*     */   public synchronized void addFieldError(String fieldName, String errorMessage) {
/*  74 */     Map<String, List<String>> errors = internalGetFieldErrors();
/*  75 */     List<String> thisFieldErrors = errors.get(fieldName);
/*     */     
/*  77 */     if (thisFieldErrors == null) {
/*  78 */       thisFieldErrors = new ArrayList<>();
/*  79 */       errors.put(fieldName, thisFieldErrors);
/*     */     } 
/*     */     
/*  82 */     thisFieldErrors.add(errorMessage);
/*     */   }
/*     */   
/*     */   public synchronized boolean hasActionErrors() {
/*  86 */     return (this.actionErrors != null && !this.actionErrors.isEmpty());
/*     */   }
/*     */   
/*     */   public synchronized boolean hasActionMessages() {
/*  90 */     return (this.actionMessages != null && !this.actionMessages.isEmpty());
/*     */   }
/*     */   
/*     */   public synchronized boolean hasErrors() {
/*  94 */     return (hasActionErrors() || hasFieldErrors());
/*     */   }
/*     */   
/*     */   public synchronized boolean hasFieldErrors() {
/*  98 */     return (this.fieldErrors != null && !this.fieldErrors.isEmpty());
/*     */   }
/*     */   
/*     */   private Collection<String> internalGetActionErrors() {
/* 102 */     if (this.actionErrors == null) {
/* 103 */       this.actionErrors = new ArrayList<>();
/*     */     }
/*     */     
/* 106 */     return this.actionErrors;
/*     */   }
/*     */   
/*     */   private Collection<String> internalGetActionMessages() {
/* 110 */     if (this.actionMessages == null) {
/* 111 */       this.actionMessages = new ArrayList<>();
/*     */     }
/*     */     
/* 114 */     return this.actionMessages;
/*     */   }
/*     */   
/*     */   private Map<String, List<String>> internalGetFieldErrors() {
/* 118 */     if (this.fieldErrors == null) {
/* 119 */       this.fieldErrors = new LinkedHashMap<>();
/*     */     }
/*     */     
/* 122 */     return this.fieldErrors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearFieldErrors() {
/* 133 */     internalGetFieldErrors().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearActionErrors() {
/* 144 */     internalGetActionErrors().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearMessages() {
/* 155 */     internalGetActionMessages().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearErrors() {
/* 167 */     internalGetFieldErrors().clear();
/* 168 */     internalGetActionErrors().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearErrorsAndMessages() {
/* 180 */     internalGetFieldErrors().clear();
/* 181 */     internalGetActionErrors().clear();
/* 182 */     internalGetActionMessages().clear();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ValidationAwareSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */