/*     */ package com.opensymphony.xwork2.ognl;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.accessor.CompoundRootAccessor;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.regex.Pattern;
/*     */ import ognl.ClassResolver;
/*     */ import ognl.MemberAccess;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.SimpleNode;
/*     */ import ognl.TypeConverter;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlUtil
/*     */ {
/*  55 */   private static final Logger LOG = LogManager.getLogger(OgnlUtil.class);
/*     */   
/*  57 */   private final ConcurrentMap<String, Object> expressions = new ConcurrentHashMap<>();
/*  58 */   private final ConcurrentMap<Class, BeanInfo> beanInfoCache = (ConcurrentMap)new ConcurrentHashMap<>();
/*     */   
/*     */   private TypeConverter defaultConverter;
/*     */   
/*     */   private boolean devMode;
/*     */   
/*     */   private boolean enableExpressionCache = true;
/*     */   private boolean enableEvalExpression;
/*     */   private Set<Class<?>> excludedClasses;
/*     */   private Set<Pattern> excludedPackageNamePatterns;
/*     */   private Set<String> excludedPackageNames;
/*     */   private Container container;
/*     */   private boolean allowStaticMethodAccess;
/*     */   private boolean disallowProxyMemberAccess;
/*     */   
/*     */   public OgnlUtil() {
/*  74 */     this.excludedClasses = new HashSet<>();
/*  75 */     this.excludedPackageNamePatterns = new HashSet<>();
/*  76 */     this.excludedPackageNames = new HashSet<>();
/*  77 */     this.excludedClasses = Collections.unmodifiableSet(this.excludedClasses);
/*  78 */     this.excludedPackageNamePatterns = Collections.unmodifiableSet(this.excludedPackageNamePatterns);
/*  79 */     this.excludedPackageNames = Collections.unmodifiableSet(this.excludedPackageNames);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   protected void setXWorkConverter(XWorkConverter conv) {
/*  84 */     this.defaultConverter = new OgnlTypeConverterWrapper((TypeConverter)conv);
/*     */   }
/*     */   
/*     */   @Inject("devMode")
/*     */   protected void setDevMode(String mode) {
/*  89 */     this.devMode = BooleanUtils.toBoolean(mode);
/*     */   }
/*     */   
/*     */   @Inject("enableOGNLExpressionCache")
/*     */   protected void setEnableExpressionCache(String cache) {
/*  94 */     this.enableExpressionCache = BooleanUtils.toBoolean(cache);
/*     */   }
/*     */   
/*     */   @Inject(value = "enableOGNLEvalExpression", required = false)
/*     */   protected void setEnableEvalExpression(String evalExpression) {
/*  99 */     this.enableEvalExpression = BooleanUtils.toBoolean(evalExpression);
/* 100 */     if (this.enableEvalExpression) {
/* 101 */       LOG.warn("Enabling OGNL expression evaluation may introduce security risks (see http://struts.apache.org/release/2.3.x/docs/s2-013.html for further details)");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(value = "ognlExcludedClasses", required = false)
/*     */   protected void setExcludedClasses(String commaDelimitedClasses) {
/* 108 */     Set<Class<?>> excludedClasses = new HashSet<>();
/* 109 */     excludedClasses.addAll(this.excludedClasses);
/* 110 */     excludedClasses.addAll(parseExcludedClasses(commaDelimitedClasses));
/* 111 */     this.excludedClasses = Collections.unmodifiableSet(excludedClasses);
/*     */   }
/*     */   
/*     */   private Set<Class<?>> parseExcludedClasses(String commaDelimitedClasses) {
/* 115 */     Set<String> classNames = TextParseUtil.commaDelimitedStringToSet(commaDelimitedClasses);
/* 116 */     Set<Class<?>> classes = new HashSet<>();
/*     */     
/* 118 */     for (String className : classNames) {
/*     */       try {
/* 120 */         classes.add(Class.forName(className));
/* 121 */       } catch (ClassNotFoundException e) {
/* 122 */         throw new ConfigurationException("Cannot load excluded class: " + className, e);
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     return classes;
/*     */   }
/*     */   
/*     */   @Inject(value = "ognlExcludedPackageNamePatterns", required = false)
/*     */   protected void setExcludedPackageNamePatterns(String commaDelimitedPackagePatterns) {
/* 131 */     Set<Pattern> excludedPackageNamePatterns = new HashSet<>();
/* 132 */     excludedPackageNamePatterns.addAll(this.excludedPackageNamePatterns);
/* 133 */     excludedPackageNamePatterns.addAll(parseExcludedPackageNamePatterns(commaDelimitedPackagePatterns));
/* 134 */     this.excludedPackageNamePatterns = Collections.unmodifiableSet(excludedPackageNamePatterns);
/*     */   }
/*     */   
/*     */   private Set<Pattern> parseExcludedPackageNamePatterns(String commaDelimitedPackagePatterns) {
/* 138 */     Set<String> packagePatterns = TextParseUtil.commaDelimitedStringToSet(commaDelimitedPackagePatterns);
/* 139 */     Set<Pattern> packageNamePatterns = new HashSet<>();
/*     */     
/* 141 */     for (String pattern : packagePatterns) {
/* 142 */       packageNamePatterns.add(Pattern.compile(pattern));
/*     */     }
/*     */     
/* 145 */     return packageNamePatterns;
/*     */   }
/*     */   
/*     */   @Inject(value = "ognlExcludedPackageNames", required = false)
/*     */   protected void setExcludedPackageNames(String commaDelimitedPackageNames) {
/* 150 */     Set<String> excludedPackageNames = new HashSet<>();
/* 151 */     excludedPackageNames.addAll(this.excludedPackageNames);
/* 152 */     excludedPackageNames.addAll(parseExcludedPackageNames(commaDelimitedPackageNames));
/* 153 */     this.excludedPackageNames = Collections.unmodifiableSet(excludedPackageNames);
/*     */   }
/*     */   
/*     */   private Set<String> parseExcludedPackageNames(String commaDelimitedPackageNames) {
/* 157 */     return TextParseUtil.commaDelimitedStringToSet(commaDelimitedPackageNames);
/*     */   }
/*     */   
/*     */   public Set<Class<?>> getExcludedClasses() {
/* 161 */     return this.excludedClasses;
/*     */   }
/*     */   
/*     */   public Set<Pattern> getExcludedPackageNamePatterns() {
/* 165 */     return this.excludedPackageNamePatterns;
/*     */   }
/*     */   
/*     */   public Set<String> getExcludedPackageNames() {
/* 169 */     return this.excludedPackageNames;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   protected void setContainer(Container container) {
/* 174 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject(value = "allowStaticMethodAccess", required = false)
/*     */   protected void setAllowStaticMethodAccess(String allowStaticMethodAccess) {
/* 179 */     this.allowStaticMethodAccess = BooleanUtils.toBoolean(allowStaticMethodAccess);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.disallowProxyMemberAccess", required = false)
/*     */   protected void setDisallowProxyMemberAccess(String disallowProxyMemberAccess) {
/* 184 */     this.disallowProxyMemberAccess = Boolean.parseBoolean(disallowProxyMemberAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject(value = "struts.ognl.expressionMaxLength", required = false)
/*     */   protected void applyExpressionMaxLength(String maxLength) {
/*     */     try {
/* 193 */       if (maxLength == null || maxLength.isEmpty()) {
/*     */         
/* 195 */         Ognl.applyExpressionMaxLength(null);
/*     */       } else {
/* 197 */         Ognl.applyExpressionMaxLength(Integer.valueOf(Integer.parseInt(maxLength)));
/*     */       } 
/* 199 */     } catch (Exception ex) {
/* 200 */       LOG.error("Unable to set OGNL Expression Max Length {}.", maxLength);
/* 201 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isDisallowProxyMemberAccess() {
/* 206 */     return this.disallowProxyMemberAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearRuntimeCache() {
/* 221 */     OgnlRuntime.clearCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearExpressionCache() {
/* 237 */     this.expressions.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int expressionCacheSize() {
/* 248 */     return this.expressions.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearBeanInfoCache() {
/* 265 */     this.beanInfoCache.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int beanInfoCacheSize() {
/* 276 */     return this.beanInfoCache.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Map<String, ?> props, Object o, Map<String, Object> context) {
/* 288 */     setProperties(props, o, context, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Map<String, ?> props, Object o, Map<String, Object> context, boolean throwPropertyExceptions) throws ReflectionException {
/* 301 */     if (props == null) {
/*     */       return;
/*     */     }
/*     */     
/* 305 */     Ognl.setTypeConverter(context, getTypeConverterFromContext(context));
/*     */     
/* 307 */     Object oldRoot = Ognl.getRoot(context);
/* 308 */     Ognl.setRoot(context, o);
/*     */     
/* 310 */     for (Map.Entry<String, ?> entry : props.entrySet()) {
/* 311 */       String expression = entry.getKey();
/* 312 */       internalSetProperty(expression, entry.getValue(), o, context, throwPropertyExceptions);
/*     */     } 
/*     */     
/* 315 */     Ognl.setRoot(context, oldRoot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Map<String, ?> properties, Object o) {
/* 326 */     setProperties(properties, o, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperties(Map<String, ?> properties, Object o, boolean throwPropertyExceptions) {
/* 338 */     Map<String, Object> context = createDefaultContext(o, null);
/* 339 */     setProperties(properties, o, context, throwPropertyExceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value, Object o, Map<String, Object> context) {
/* 352 */     setProperty(name, value, o, context, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value, Object o, Map<String, Object> context, boolean throwPropertyExceptions) {
/* 366 */     Ognl.setTypeConverter(context, getTypeConverterFromContext(context));
/*     */     
/* 368 */     Object oldRoot = Ognl.getRoot(context);
/* 369 */     Ognl.setRoot(context, o);
/*     */     
/* 371 */     internalSetProperty(name, value, o, context, throwPropertyExceptions);
/*     */     
/* 373 */     Ognl.setRoot(context, oldRoot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getRealTarget(String property, Map<String, Object> context, Object root) throws OgnlException {
/* 389 */     if ("top".equals(property)) {
/* 390 */       return root;
/*     */     }
/*     */     
/* 393 */     if (root instanceof CompoundRoot) {
/*     */       
/* 395 */       CompoundRoot cr = (CompoundRoot)root;
/*     */       
/*     */       try {
/* 398 */         for (Object target : cr) {
/* 399 */           if (OgnlRuntime.hasSetProperty((OgnlContext)context, target, property) || OgnlRuntime.hasGetProperty((OgnlContext)context, target, property) || OgnlRuntime.getIndexedPropertyType((OgnlContext)context, target.getClass(), property) != OgnlRuntime.INDEXED_PROPERTY_NONE)
/*     */           {
/*     */ 
/*     */             
/* 403 */             return target;
/*     */           }
/*     */         } 
/* 406 */       } catch (IntrospectionException ex) {
/* 407 */         throw new ReflectionException("Cannot figure out real target class", ex);
/*     */       } 
/*     */       
/* 410 */       return null;
/*     */     } 
/*     */     
/* 413 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String name, final Map<String, Object> context, final Object root, final Object value) throws OgnlException {
/* 428 */     compileAndExecute(name, context, new OgnlTask<Void>() {
/*     */           public Void execute(Object tree) throws OgnlException {
/* 430 */             if (OgnlUtil.this.isEvalExpression(tree, context)) {
/* 431 */               throw new OgnlException("Eval expression/chained expressions cannot be used as parameter name");
/*     */             }
/* 433 */             if (OgnlUtil.this.isArithmeticExpression(tree, context)) {
/* 434 */               throw new OgnlException("Arithmetic expressions cannot be used as parameter name");
/*     */             }
/* 436 */             Ognl.setValue(tree, context, root, value);
/* 437 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private boolean isEvalExpression(Object tree, Map<String, Object> context) throws OgnlException {
/* 443 */     if (tree instanceof SimpleNode) {
/* 444 */       SimpleNode node = (SimpleNode)tree;
/* 445 */       OgnlContext ognlContext = null;
/*     */       
/* 447 */       if (context != null && context instanceof OgnlContext) {
/* 448 */         ognlContext = (OgnlContext)context;
/*     */       }
/* 450 */       return (node.isEvalChain(ognlContext) || node.isSequence(ognlContext));
/*     */     } 
/* 452 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isArithmeticExpression(Object tree, Map<String, Object> context) throws OgnlException {
/* 456 */     if (tree instanceof SimpleNode) {
/* 457 */       SimpleNode node = (SimpleNode)tree;
/* 458 */       OgnlContext ognlContext = null;
/*     */       
/* 460 */       if (context != null && context instanceof OgnlContext) {
/* 461 */         ognlContext = (OgnlContext)context;
/*     */       }
/* 463 */       return node.isOperation(ognlContext);
/*     */     } 
/* 465 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isSimpleMethod(Object tree, Map<String, Object> context) throws OgnlException {
/* 469 */     if (tree instanceof SimpleNode) {
/* 470 */       SimpleNode node = (SimpleNode)tree;
/* 471 */       OgnlContext ognlContext = null;
/*     */       
/* 473 */       if (context != null && context instanceof OgnlContext) {
/* 474 */         ognlContext = (OgnlContext)context;
/*     */       }
/* 476 */       return (node.isSimpleMethod(ognlContext) && !node.isChain(ognlContext));
/*     */     } 
/* 478 */     return false;
/*     */   }
/*     */   
/*     */   public Object getValue(String name, final Map<String, Object> context, final Object root) throws OgnlException {
/* 482 */     return compileAndExecute(name, context, new OgnlTask() {
/*     */           public Object execute(Object tree) throws OgnlException {
/* 484 */             return Ognl.getValue(tree, context, root);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public Object callMethod(String name, final Map<String, Object> context, final Object root) throws OgnlException {
/* 490 */     return compileAndExecuteMethod(name, context, new OgnlTask() {
/*     */           public Object execute(Object tree) throws OgnlException {
/* 492 */             return Ognl.getValue(tree, context, root);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public Object getValue(String name, final Map<String, Object> context, final Object root, final Class resultType) throws OgnlException {
/* 498 */     return compileAndExecute(name, context, new OgnlTask() {
/*     */           public Object execute(Object tree) throws OgnlException {
/* 500 */             return Ognl.getValue(tree, context, root, resultType);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Object compile(String expression) throws OgnlException {
/* 507 */     return compile(expression, null);
/*     */   }
/*     */   
/*     */   private <T> Object compileAndExecute(String expression, Map<String, Object> context, OgnlTask<T> task) throws OgnlException {
/*     */     Object tree;
/* 512 */     if (this.enableExpressionCache) {
/* 513 */       tree = this.expressions.get(expression);
/* 514 */       if (tree == null) {
/* 515 */         tree = Ognl.parseExpression(expression);
/* 516 */         checkEnableEvalExpression(tree, context);
/*     */       } 
/*     */     } else {
/* 519 */       tree = Ognl.parseExpression(expression);
/* 520 */       checkEnableEvalExpression(tree, context);
/*     */     } 
/*     */     
/* 523 */     T exec = task.execute(tree);
/*     */     
/* 525 */     if (this.enableExpressionCache) {
/* 526 */       this.expressions.putIfAbsent(expression, tree);
/*     */     }
/* 528 */     return exec;
/*     */   }
/*     */   
/*     */   private <T> Object compileAndExecuteMethod(String expression, Map<String, Object> context, OgnlTask<T> task) throws OgnlException {
/*     */     Object tree;
/* 533 */     if (this.enableExpressionCache) {
/* 534 */       tree = this.expressions.get(expression);
/* 535 */       if (tree == null) {
/* 536 */         tree = Ognl.parseExpression(expression);
/* 537 */         checkSimpleMethod(tree, context);
/*     */       } 
/*     */     } else {
/* 540 */       tree = Ognl.parseExpression(expression);
/* 541 */       checkSimpleMethod(tree, context);
/*     */     } 
/*     */     
/* 544 */     T exec = task.execute(tree);
/*     */     
/* 546 */     if (this.enableExpressionCache) {
/* 547 */       this.expressions.putIfAbsent(expression, tree);
/*     */     }
/* 549 */     return exec;
/*     */   }
/*     */   
/*     */   public Object compile(String expression, Map<String, Object> context) throws OgnlException {
/* 553 */     return compileAndExecute(expression, context, new OgnlTask() {
/*     */           public Object execute(Object tree) throws OgnlException {
/* 555 */             return tree;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void checkEnableEvalExpression(Object tree, Map<String, Object> context) throws OgnlException {
/* 561 */     if (!this.enableEvalExpression && isEvalExpression(tree, context)) {
/* 562 */       throw new OgnlException("Eval expressions/chained expressions have been disabled!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkSimpleMethod(Object tree, Map<String, Object> context) throws OgnlException {
/* 567 */     if (!isSimpleMethod(tree, context)) {
/* 568 */       throw new OgnlException("It isn't a simple method which can be called!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(Object from, Object to, Map<String, Object> context, Collection<String> exclusions, Collection<String> inclusions) {
/* 585 */     copy(from, to, context, exclusions, inclusions, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(final Object from, final Object to, Map<String, Object> context, Collection<String> exclusions, Collection<String> inclusions, Class<?> editable) {
/*     */     PropertyDescriptor[] fromPds, toPds;
/* 603 */     if (from == null || to == null) {
/* 604 */       LOG.warn("Attempting to copy from or to a null source. This is illegal and is bein skipped. This may be due to an error in an OGNL expression, action chaining, or some other event.");
/*     */       
/*     */       return;
/*     */     } 
/* 608 */     TypeConverter converter = getTypeConverterFromContext(context);
/* 609 */     final Map contextFrom = createDefaultContext(from, null);
/* 610 */     Ognl.setTypeConverter(contextFrom, converter);
/* 611 */     final Map contextTo = createDefaultContext(to, null);
/* 612 */     Ognl.setTypeConverter(contextTo, converter);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 618 */       fromPds = getPropertyDescriptors(from);
/* 619 */       if (editable != null) {
/* 620 */         toPds = getPropertyDescriptors(editable);
/*     */       } else {
/*     */         
/* 623 */         toPds = getPropertyDescriptors(to);
/*     */       } 
/* 625 */     } catch (IntrospectionException e) {
/* 626 */       LOG.error("An error occurred", e);
/*     */       
/*     */       return;
/*     */     } 
/* 630 */     Map<String, PropertyDescriptor> toPdHash = new HashMap<>();
/*     */     
/* 632 */     for (PropertyDescriptor toPd : toPds) {
/* 633 */       toPdHash.put(toPd.getName(), toPd);
/*     */     }
/*     */     
/* 636 */     for (PropertyDescriptor fromPd : fromPds) {
/* 637 */       if (fromPd.getReadMethod() != null) {
/* 638 */         boolean copy = true;
/* 639 */         if (exclusions != null && exclusions.contains(fromPd.getName())) {
/* 640 */           copy = false;
/* 641 */         } else if (inclusions != null && !inclusions.contains(fromPd.getName())) {
/* 642 */           copy = false;
/*     */         } 
/*     */         
/* 645 */         if (copy) {
/* 646 */           PropertyDescriptor toPd = toPdHash.get(fromPd.getName());
/* 647 */           if (toPd != null && toPd.getWriteMethod() != null) {
/*     */             try {
/* 649 */               compileAndExecute(fromPd.getName(), context, new OgnlTask() {
/*     */                     public Void execute(Object expr) throws OgnlException {
/* 651 */                       Object value = Ognl.getValue(expr, contextFrom, from);
/* 652 */                       Ognl.setValue(expr, contextTo, to, value);
/* 653 */                       return null;
/*     */                     }
/*     */                   });
/*     */             }
/* 657 */             catch (OgnlException e) {
/* 658 */               LOG.debug("Got OGNL exception", (Throwable)e);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(Object from, Object to, Map<String, Object> context) {
/* 680 */     copy(from, to, context, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors(Object source) throws IntrospectionException {
/* 691 */     BeanInfo beanInfo = getBeanInfo(source);
/* 692 */     return beanInfo.getPropertyDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors(Class clazz) throws IntrospectionException {
/* 704 */     BeanInfo beanInfo = getBeanInfo(clazz);
/* 705 */     return beanInfo.getPropertyDescriptors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getBeanMap(final Object source) throws IntrospectionException, OgnlException {
/* 721 */     Map<String, Object> beanMap = new HashMap<>();
/* 722 */     final Map sourceMap = createDefaultContext(source, null);
/* 723 */     PropertyDescriptor[] propertyDescriptors = getPropertyDescriptors(source);
/* 724 */     for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
/* 725 */       String propertyName = propertyDescriptor.getDisplayName();
/* 726 */       Method readMethod = propertyDescriptor.getReadMethod();
/* 727 */       if (readMethod != null) {
/* 728 */         Object value = compileAndExecute(propertyName, null, new OgnlTask() {
/*     */               public Object execute(Object expr) throws OgnlException {
/* 730 */                 return Ognl.getValue(expr, sourceMap, source);
/*     */               }
/*     */             });
/* 733 */         beanMap.put(propertyName, value);
/*     */       } else {
/* 735 */         beanMap.put(propertyName, "There is no read method for " + propertyName);
/*     */       } 
/*     */     } 
/* 738 */     return beanMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInfo getBeanInfo(Object from) throws IntrospectionException {
/* 749 */     return getBeanInfo(from.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInfo getBeanInfo(Class<?> clazz) throws IntrospectionException {
/* 761 */     synchronized (this.beanInfoCache) {
/* 762 */       BeanInfo beanInfo = this.beanInfoCache.get(clazz);
/* 763 */       if (beanInfo == null) {
/* 764 */         beanInfo = Introspector.getBeanInfo(clazz, Object.class);
/* 765 */         this.beanInfoCache.putIfAbsent(clazz, beanInfo);
/*     */       } 
/* 767 */       return beanInfo;
/*     */     } 
/*     */   }
/*     */   
/*     */   void internalSetProperty(String name, Object value, Object o, Map<String, Object> context, boolean throwPropertyExceptions) throws ReflectionException {
/*     */     try {
/* 773 */       setValue(name, context, o, value);
/* 774 */     } catch (OgnlException e) {
/* 775 */       Throwable reason = e.getReason();
/* 776 */       if (reason instanceof SecurityException) {
/* 777 */         LOG.warn("Could not evaluate this expression due to security constraints: [{}]", name, e);
/*     */       }
/* 779 */       String msg = "Caught OgnlException while setting property '" + name + "' on type '" + o.getClass().getName() + "'.";
/* 780 */       Throwable exception = (reason == null) ? (Throwable)e : reason;
/*     */       
/* 782 */       if (throwPropertyExceptions)
/* 783 */         throw new ReflectionException(msg, exception); 
/* 784 */       if (this.devMode) {
/* 785 */         LOG.warn(msg, exception);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeConverter getTypeConverterFromContext(Map<String, Object> context) {
/* 799 */     return this.defaultConverter;
/*     */   }
/*     */   
/*     */   protected Map createDefaultContext(Object root) {
/* 803 */     return createDefaultContext(root, null);
/*     */   }
/*     */   
/*     */   protected Map createDefaultContext(Object root, ClassResolver classResolver) {
/* 807 */     ClassResolver resolver = classResolver;
/* 808 */     if (resolver == null) {
/* 809 */       resolver = (ClassResolver)this.container.getInstance(CompoundRootAccessor.class);
/*     */     }
/*     */     
/* 812 */     SecurityMemberAccess memberAccess = new SecurityMemberAccess(this.allowStaticMethodAccess);
/* 813 */     memberAccess.setExcludedClasses(this.excludedClasses);
/* 814 */     memberAccess.setExcludedPackageNamePatterns(this.excludedPackageNamePatterns);
/* 815 */     memberAccess.setExcludedPackageNames(this.excludedPackageNames);
/* 816 */     memberAccess.setDisallowProxyMemberAccess(this.disallowProxyMemberAccess);
/*     */     
/* 818 */     return Ognl.createDefaultContext(root, resolver, this.defaultConverter, (MemberAccess)memberAccess);
/*     */   }
/*     */   
/*     */   private static interface OgnlTask<T> {
/*     */     T execute(Object param1Object) throws OgnlException;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\OgnlUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */