/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ModelDriven;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProviderFactory;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StrutsLocalizedTextProvider
/*     */   extends AbstractLocalizedTextProvider
/*     */ {
/*  41 */   private static final Logger LOG = LogManager.getLogger(StrutsLocalizedTextProvider.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void clearDefaultResourceBundles() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StrutsLocalizedTextProvider() {
/*  54 */     addDefaultResourceBundle("com/opensymphony/xwork2/xwork-messages");
/*  55 */     addDefaultResourceBundle("org/apache/struts2/struts-messages");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Locale localeFromString(String localeStr, Locale defaultLocale) {
/*  70 */     if (localeStr == null || localeStr.trim().length() == 0 || "_".equals(localeStr)) {
/*  71 */       if (defaultLocale != null) {
/*  72 */         return defaultLocale;
/*     */       }
/*  74 */       return Locale.getDefault();
/*     */     } 
/*     */     
/*  77 */     int index = localeStr.indexOf('_');
/*  78 */     if (index < 0) {
/*  79 */       return new Locale(localeStr);
/*     */     }
/*     */     
/*  82 */     String language = localeStr.substring(0, index);
/*  83 */     if (index == localeStr.length()) {
/*  84 */       return new Locale(language);
/*     */     }
/*     */     
/*  87 */     localeStr = localeStr.substring(index + 1);
/*  88 */     index = localeStr.indexOf('_');
/*  89 */     if (index < 0) {
/*  90 */       return new Locale(language, localeStr);
/*     */     }
/*     */     
/*  93 */     String country = localeStr.substring(0, index);
/*  94 */     if (index == localeStr.length()) {
/*  95 */       return new Locale(language, country);
/*     */     }
/*     */     
/*  98 */     localeStr = localeStr.substring(index + 1);
/*  99 */     return new Locale(language, country, localeStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class aClass, String aTextName, Locale locale) {
/* 114 */     return findText(aClass, aTextName, locale, aTextName, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class aClass, String aTextName, Locale locale, String defaultMessage, Object[] args) {
/* 165 */     ValueStack valueStack = ActionContext.getContext().getValueStack();
/* 166 */     return findText(aClass, aTextName, locale, defaultMessage, args, valueStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class<?> aClass, String aTextName, Locale locale, String defaultMessage, Object[] args, ValueStack valueStack) {
/*     */     AbstractLocalizedTextProvider.GetDefaultMessageReturnArg result;
/* 224 */     String indexedTextName = null;
/* 225 */     if (aTextName == null) {
/* 226 */       LOG.warn("Trying to find text with null key!");
/* 227 */       aTextName = "";
/*     */     } 
/*     */     
/* 230 */     if (aTextName.contains("[")) {
/* 231 */       int i = -1;
/*     */       
/* 233 */       indexedTextName = aTextName;
/*     */       
/* 235 */       while ((i = indexedTextName.indexOf('[', i + 1)) != -1) {
/* 236 */         int j = indexedTextName.indexOf(']', i);
/* 237 */         String a = indexedTextName.substring(0, i);
/* 238 */         String b = indexedTextName.substring(j);
/* 239 */         indexedTextName = a + "[*" + b;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 244 */     String msg = findMessage(aClass, aTextName, indexedTextName, locale, args, null, valueStack);
/*     */     
/* 246 */     if (msg != null) {
/* 247 */       return msg;
/*     */     }
/*     */     
/* 250 */     if (ModelDriven.class.isAssignableFrom(aClass)) {
/* 251 */       ActionContext context = ActionContext.getContext();
/*     */       
/* 253 */       ActionInvocation actionInvocation = context.getActionInvocation();
/*     */ 
/*     */       
/* 256 */       if (actionInvocation != null) {
/* 257 */         Object action = actionInvocation.getAction();
/* 258 */         if (action instanceof ModelDriven) {
/* 259 */           Object model = ((ModelDriven)action).getModel();
/* 260 */           if (model != null) {
/* 261 */             msg = findMessage(model.getClass(), aTextName, indexedTextName, locale, args, null, valueStack);
/* 262 */             if (msg != null) {
/* 263 */               return msg;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 271 */     Class<?> clazz = aClass;
/* 272 */     for (; clazz != null && !clazz.equals(Object.class); 
/* 273 */       clazz = clazz.getSuperclass()) {
/*     */       
/* 275 */       String basePackageName = clazz.getName();
/* 276 */       while (basePackageName.lastIndexOf('.') != -1) {
/* 277 */         basePackageName = basePackageName.substring(0, basePackageName.lastIndexOf('.'));
/* 278 */         String packageName = basePackageName + ".package";
/* 279 */         msg = getMessage(packageName, locale, aTextName, valueStack, args);
/*     */         
/* 281 */         if (msg != null) {
/* 282 */           return msg;
/*     */         }
/*     */         
/* 285 */         if (indexedTextName != null) {
/* 286 */           msg = getMessage(packageName, locale, indexedTextName, valueStack, args);
/*     */           
/* 288 */           if (msg != null) {
/* 289 */             return msg;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 296 */     int idx = aTextName.indexOf('.');
/*     */     
/* 298 */     if (idx != -1) {
/* 299 */       String newKey = null;
/* 300 */       String prop = null;
/*     */       
/* 302 */       if (aTextName.startsWith("invalid.fieldvalue.")) {
/* 303 */         idx = aTextName.indexOf('.', "invalid.fieldvalue.".length());
/*     */         
/* 305 */         if (idx != -1) {
/* 306 */           prop = aTextName.substring("invalid.fieldvalue.".length(), idx);
/* 307 */           newKey = "invalid.fieldvalue." + aTextName.substring(idx + 1);
/*     */         } 
/*     */       } else {
/* 310 */         prop = aTextName.substring(0, idx);
/* 311 */         newKey = aTextName.substring(idx + 1);
/*     */       } 
/*     */       
/* 314 */       if (prop != null) {
/* 315 */         Object obj = valueStack.findValue(prop);
/*     */         try {
/* 317 */           Object actionObj = ReflectionProviderFactory.getInstance().getRealTarget(prop, valueStack.getContext(), valueStack.getRoot());
/* 318 */           if (actionObj != null) {
/* 319 */             PropertyDescriptor propertyDescriptor = ReflectionProviderFactory.getInstance().getPropertyDescriptor(actionObj.getClass(), prop);
/*     */             
/* 321 */             if (propertyDescriptor != null) {
/* 322 */               Class<?> clazz1 = propertyDescriptor.getPropertyType();
/*     */               
/* 324 */               if (clazz1 != null) {
/* 325 */                 if (obj != null) {
/* 326 */                   valueStack.push(obj);
/*     */                 }
/* 328 */                 msg = findText(clazz1, newKey, locale, (String)null, args);
/* 329 */                 if (obj != null) {
/* 330 */                   valueStack.pop();
/*     */                 }
/* 332 */                 if (msg != null) {
/* 333 */                   return msg;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 338 */         } catch (Exception e) {
/* 339 */           LOG.debug("unable to find property {}", prop, e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 346 */     if (indexedTextName == null) {
/* 347 */       result = getDefaultMessage(aTextName, locale, valueStack, args, defaultMessage);
/*     */     } else {
/* 349 */       result = getDefaultMessage(aTextName, locale, valueStack, args, null);
/* 350 */       if (result != null && result.message != null) {
/* 351 */         return result.message;
/*     */       }
/* 353 */       result = getDefaultMessage(indexedTextName, locale, valueStack, args, defaultMessage);
/*     */     } 
/*     */ 
/*     */     
/* 357 */     if (unableToFindTextForKey(result) && LOG.isDebugEnabled()) {
/* 358 */       String warn = "Unable to find text for key '" + aTextName + "' ";
/* 359 */       if (indexedTextName != null) {
/* 360 */         warn = warn + " or indexed key '" + indexedTextName + "' ";
/*     */       }
/* 362 */       warn = warn + "in class '" + aClass.getName() + "' and locale '" + locale + "'";
/* 363 */       LOG.debug(warn);
/*     */     } 
/*     */     
/* 366 */     return (result != null) ? result.message : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(ResourceBundle bundle, String aTextName, Locale locale) {
/* 388 */     return findText(bundle, aTextName, locale, aTextName, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(ResourceBundle bundle, String aTextName, Locale locale, String defaultMessage, Object[] args) {
/* 415 */     ValueStack valueStack = ActionContext.getContext().getValueStack();
/* 416 */     return findText(bundle, aTextName, locale, defaultMessage, args, valueStack);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\StrutsLocalizedTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */