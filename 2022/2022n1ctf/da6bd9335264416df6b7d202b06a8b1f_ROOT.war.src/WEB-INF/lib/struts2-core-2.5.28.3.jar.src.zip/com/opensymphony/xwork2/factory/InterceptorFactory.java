package com.opensymphony.xwork2.factory;

import com.opensymphony.xwork2.config.ConfigurationException;
import com.opensymphony.xwork2.config.entities.InterceptorConfig;
import com.opensymphony.xwork2.interceptor.Interceptor;
import java.util.Map;

public interface InterceptorFactory {
  Interceptor buildInterceptor(InterceptorConfig paramInterceptorConfig, Map<String, String> paramMap) throws ConfigurationException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\InterceptorFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */