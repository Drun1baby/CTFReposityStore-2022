/*    */ package com.opensymphony.xwork2.ognl.accessor;
/*    */ 
/*    */ import java.util.Map;
/*    */ import ognl.ObjectPropertyAccessor;
/*    */ import ognl.OgnlException;
/*    */ import org.apache.struts2.dispatcher.HttpParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpParametersPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object oname) throws OgnlException {
/* 32 */     HttpParameters parameters = (HttpParameters)target;
/* 33 */     return parameters.get(String.valueOf(oname)).getObject();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(Map context, Object target, Object oname, Object value) throws OgnlException {
/* 38 */     throw new OgnlException("Access to " + target.getClass().getName() + " is read-only!");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\HttpParametersPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */