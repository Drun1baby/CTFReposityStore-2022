/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversionErrorInterceptor
/*     */   extends MethodFilterInterceptor
/*     */ {
/*     */   public static final String ORIGINAL_PROPERTY_OVERRIDE = "original.property.override";
/*     */   
/*     */   protected Object getOverrideExpr(ActionInvocation invocation, Object value) {
/*  92 */     return escape(value);
/*     */   }
/*     */   
/*     */   protected String escape(Object value) {
/*  96 */     return "\"" + StringEscapeUtils.escapeJava(String.valueOf(value)) + "\"";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String doIntercept(ActionInvocation invocation) throws Exception {
/* 102 */     ActionContext invocationContext = invocation.getInvocationContext();
/* 103 */     Map<String, Object> conversionErrors = invocationContext.getConversionErrors();
/* 104 */     ValueStack stack = invocationContext.getValueStack();
/*     */     
/* 106 */     HashMap<Object, Object> fakie = null;
/*     */     
/* 108 */     for (Map.Entry<String, Object> entry : conversionErrors.entrySet()) {
/* 109 */       String propertyName = entry.getKey();
/* 110 */       Object value = entry.getValue();
/*     */       
/* 112 */       if (shouldAddError(propertyName, value)) {
/* 113 */         String message = XWorkConverter.getConversionErrorMessage(propertyName, stack);
/*     */         
/* 115 */         Object action = invocation.getAction();
/* 116 */         if (action instanceof ValidationAware) {
/* 117 */           ValidationAware va = (ValidationAware)action;
/* 118 */           va.addFieldError(propertyName, message);
/*     */         } 
/*     */         
/* 121 */         if (fakie == null) {
/* 122 */           fakie = new HashMap<>();
/*     */         }
/*     */         
/* 125 */         fakie.put(propertyName, getOverrideExpr(invocation, value));
/*     */       } 
/*     */     } 
/*     */     
/* 129 */     if (fakie != null) {
/*     */       
/* 131 */       stack.getContext().put("original.property.override", fakie);
/* 132 */       invocation.addPreResultListener(new PreResultListener() {
/*     */             public void beforeResult(ActionInvocation invocation, String resultCode) {
/* 134 */               Map<Object, Object> fakie = (Map<Object, Object>)invocation.getInvocationContext().get("original.property.override");
/*     */               
/* 136 */               if (fakie != null) {
/* 137 */                 invocation.getStack().setExprOverrides(fakie);
/*     */               }
/*     */             }
/*     */           });
/*     */     } 
/* 142 */     return invocation.invoke();
/*     */   }
/*     */   
/*     */   protected boolean shouldAddError(String propertyName, Object value) {
/* 146 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ConversionErrorInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */