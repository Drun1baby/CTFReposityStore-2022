package com.opensymphony.xwork2.validator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Validations {
  CustomValidator[] customValidators() default {};
  
  ConversionErrorFieldValidator[] conversionErrorFields() default {};
  
  DateRangeFieldValidator[] dateRangeFields() default {};
  
  EmailValidator[] emails() default {};
  
  CreditCardValidator[] creditCards() default {};
  
  FieldExpressionValidator[] fieldExpressions() default {};
  
  IntRangeFieldValidator[] intRangeFields() default {};
  
  LongRangeFieldValidator[] longRangeFields() default {};
  
  RequiredFieldValidator[] requiredFields() default {};
  
  RequiredStringValidator[] requiredStrings() default {};
  
  StringLengthFieldValidator[] stringLengthFields() default {};
  
  UrlValidator[] urls() default {};
  
  ConditionalVisitorFieldValidator[] conditionalVisitorFields() default {};
  
  VisitorFieldValidator[] visitorFields() default {};
  
  RegexFieldValidator[] regexFields() default {};
  
  ExpressionValidator[] expressions() default {};
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\annotations\Validations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */