/*    */ package com.opensymphony.xwork2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.FileManagerFactory;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileManagerFactoryProvider
/*    */   implements ContainerProvider
/*    */ {
/*    */   private Class<? extends FileManagerFactory> factoryClass;
/*    */   
/*    */   public FileManagerFactoryProvider(Class<? extends FileManagerFactory> factoryClass) {
/* 34 */     this.factoryClass = factoryClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {}
/*    */ 
/*    */   
/*    */   public void init(Configuration configuration) throws ConfigurationException {}
/*    */   
/*    */   public boolean needsReload() {
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 48 */     builder.factory(FileManagerFactory.class, this.factoryClass.getSimpleName(), this.factoryClass, Scope.SINGLETON);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\FileManagerFactoryProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */