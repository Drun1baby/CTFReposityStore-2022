/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.CompositeTextProvider;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.StrutsTextProviderFactory;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.interceptor.ValidationAware;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingValidatorContext
/*     */   implements ValidatorContext
/*     */ {
/*     */   private LocaleProvider localeProvider;
/*     */   private TextProvider textProvider;
/*     */   private ValidationAware validationAware;
/*     */   
/*     */   public DelegatingValidatorContext(ValidationAware validationAware, TextProvider textProvider, LocaleProvider localeProvider) {
/*  51 */     this.textProvider = textProvider;
/*  52 */     this.validationAware = validationAware;
/*  53 */     this.localeProvider = localeProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingValidatorContext(Object object, TextProviderFactory textProviderFactory) {
/*  63 */     this.localeProvider = makeLocaleProvider(object);
/*  64 */     this.validationAware = makeValidationAware(object);
/*  65 */     this.textProvider = makeTextProvider(object, textProviderFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DelegatingValidatorContext(Class clazz) {
/*  78 */     this.localeProvider = new ActionContextLocaleProvider();
/*  79 */     this.textProvider = (new StrutsTextProviderFactory()).createInstance(clazz);
/*  80 */     this.validationAware = new LoggingValidationAware(clazz);
/*     */   }
/*     */   
/*     */   public void setActionErrors(Collection<String> errorMessages) {
/*  84 */     this.validationAware.setActionErrors(errorMessages);
/*     */   }
/*     */   
/*     */   public Collection<String> getActionErrors() {
/*  88 */     return this.validationAware.getActionErrors();
/*     */   }
/*     */   
/*     */   public void setActionMessages(Collection<String> messages) {
/*  92 */     this.validationAware.setActionMessages(messages);
/*     */   }
/*     */   
/*     */   public Collection<String> getActionMessages() {
/*  96 */     return this.validationAware.getActionMessages();
/*     */   }
/*     */   
/*     */   public void setFieldErrors(Map<String, List<String>> errorMap) {
/* 100 */     this.validationAware.setFieldErrors(errorMap);
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> getFieldErrors() {
/* 104 */     return this.validationAware.getFieldErrors();
/*     */   }
/*     */   
/*     */   public String getFullFieldName(String fieldName) {
/* 108 */     return fieldName;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 112 */     return this.localeProvider.getLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidLocaleString(String localeStr) {
/* 117 */     return this.localeProvider.isValidLocaleString(localeStr);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidLocale(Locale locale) {
/* 122 */     return this.localeProvider.isValidLocale(locale);
/*     */   }
/*     */   
/*     */   public boolean hasKey(String key) {
/* 126 */     return this.textProvider.hasKey(key);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName) {
/* 130 */     return this.textProvider.getText(aTextName);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue) {
/* 134 */     return this.textProvider.getText(aTextName, defaultValue);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue, String obj) {
/* 138 */     return this.textProvider.getText(aTextName, defaultValue, obj);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, List<?> args) {
/* 142 */     return this.textProvider.getText(aTextName, args);
/*     */   }
/*     */   
/*     */   public String getText(String key, String[] args) {
/* 146 */     return this.textProvider.getText(key, args);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue, List<?> args) {
/* 150 */     return this.textProvider.getText(aTextName, defaultValue, args);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args) {
/* 154 */     return this.textProvider.getText(key, defaultValue, args);
/*     */   }
/*     */   
/*     */   public ResourceBundle getTexts(String aBundleName) {
/* 158 */     return this.textProvider.getTexts(aBundleName);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args, ValueStack stack) {
/* 162 */     return this.textProvider.getText(key, defaultValue, args, stack);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args, ValueStack stack) {
/* 166 */     return this.textProvider.getText(key, defaultValue, args, stack);
/*     */   }
/*     */   
/*     */   public ResourceBundle getTexts() {
/* 170 */     return this.textProvider.getTexts();
/*     */   }
/*     */   
/*     */   public void addActionError(String anErrorMessage) {
/* 174 */     this.validationAware.addActionError(anErrorMessage);
/*     */   }
/*     */   
/*     */   public void addActionMessage(String aMessage) {
/* 178 */     this.validationAware.addActionMessage(aMessage);
/*     */   }
/*     */   
/*     */   public void addFieldError(String fieldName, String errorMessage) {
/* 182 */     this.validationAware.addFieldError(fieldName, errorMessage);
/*     */   }
/*     */   
/*     */   public boolean hasActionErrors() {
/* 186 */     return this.validationAware.hasActionErrors();
/*     */   }
/*     */   
/*     */   public boolean hasActionMessages() {
/* 190 */     return this.validationAware.hasActionMessages();
/*     */   }
/*     */   
/*     */   public boolean hasErrors() {
/* 194 */     return this.validationAware.hasErrors();
/*     */   }
/*     */   
/*     */   public boolean hasFieldErrors() {
/* 198 */     return this.validationAware.hasFieldErrors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TextProvider makeTextProvider(Object object, TextProviderFactory textProviderFactory) {
/* 204 */     if (object != null && object instanceof DelegatingValidatorContext) {
/* 205 */       return ((DelegatingValidatorContext)object).getTextProvider();
/*     */     }
/*     */     
/* 208 */     if (object != null && object instanceof TextProvider) {
/* 209 */       if (object instanceof CompositeTextProvider) {
/* 210 */         return (TextProvider)object;
/*     */       }
/* 212 */       return (TextProvider)new CompositeTextProvider(new TextProvider[] { (TextProvider)object, textProviderFactory.createInstance(object.getClass()) });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 217 */     return textProviderFactory.createInstance((object != null) ? object.getClass() : DelegatingValidatorContext.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static LocaleProvider makeLocaleProvider(Object object) {
/* 223 */     if (object instanceof LocaleProvider) {
/* 224 */       return (LocaleProvider)object;
/*     */     }
/* 226 */     return new ActionContextLocaleProvider();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static ValidationAware makeValidationAware(Object object) {
/* 231 */     if (object instanceof ValidationAware) {
/* 232 */       return (ValidationAware)object;
/*     */     }
/* 234 */     return new LoggingValidationAware(object);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setTextProvider(TextProvider textProvider) {
/* 239 */     this.textProvider = textProvider;
/*     */   }
/*     */   
/*     */   protected TextProvider getTextProvider() {
/* 243 */     return this.textProvider;
/*     */   }
/*     */   
/*     */   protected void setValidationAware(ValidationAware validationAware) {
/* 247 */     this.validationAware = validationAware;
/*     */   }
/*     */   
/*     */   protected ValidationAware getValidationAware() {
/* 251 */     return this.validationAware;
/*     */   }
/*     */   
/*     */   private static class ActionContextLocaleProvider
/*     */     implements LocaleProvider
/*     */   {
/*     */     private LocaleProvider localeProvider;
/*     */     
/*     */     private ActionContextLocaleProvider() {}
/*     */     
/*     */     private LocaleProvider getLocaleProvider() {
/* 262 */       if (this.localeProvider == null) {
/* 263 */         LocaleProviderFactory localeProviderFactory = (LocaleProviderFactory)ActionContext.getContext().getInstance(LocaleProviderFactory.class);
/* 264 */         this.localeProvider = localeProviderFactory.createLocaleProvider();
/*     */       } 
/* 266 */       return this.localeProvider;
/*     */     }
/*     */ 
/*     */     
/*     */     public Locale getLocale() {
/* 271 */       return getLocaleProvider().getLocale();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isValidLocaleString(String localeStr) {
/* 276 */       return getLocaleProvider().isValidLocaleString(localeStr);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isValidLocale(Locale locale) {
/* 281 */       return getLocaleProvider().isValidLocale(locale);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LoggingValidationAware
/*     */     implements ValidationAware
/*     */   {
/*     */     private Logger log;
/*     */ 
/*     */     
/*     */     public LoggingValidationAware(Class clazz) {
/* 293 */       this.log = LogManager.getLogger(clazz);
/*     */     }
/*     */     
/*     */     public LoggingValidationAware(Object obj) {
/* 297 */       this.log = LogManager.getLogger(obj.getClass());
/*     */     }
/*     */     
/*     */     public void setActionErrors(Collection<String> errorMessages) {
/* 301 */       for (String errorMessage : errorMessages) {
/* 302 */         String s = errorMessage;
/* 303 */         addActionError(s);
/*     */       } 
/*     */     }
/*     */     
/*     */     public Collection<String> getActionErrors() {
/* 308 */       return null;
/*     */     }
/*     */     
/*     */     public void setActionMessages(Collection<String> messages) {
/* 312 */       for (String message : messages) {
/* 313 */         String s = message;
/* 314 */         addActionMessage(s);
/*     */       } 
/*     */     }
/*     */     
/*     */     public Collection<String> getActionMessages() {
/* 319 */       return null;
/*     */     }
/*     */     
/*     */     public void setFieldErrors(Map<String, List<String>> errorMap) {
/* 323 */       for (Map.Entry<String, List<String>> entry : errorMap.entrySet()) {
/* 324 */         addFieldError(entry.getKey(), ((List)entry.getValue()).toString());
/*     */       }
/*     */     }
/*     */     
/*     */     public Map<String, List<String>> getFieldErrors() {
/* 329 */       return null;
/*     */     }
/*     */     
/*     */     public void addActionError(String anErrorMessage) {
/* 333 */       this.log.error("Validation error: {}", anErrorMessage);
/*     */     }
/*     */     
/*     */     public void addActionMessage(String aMessage) {
/* 337 */       this.log.info("Validation Message: {}", aMessage);
/*     */     }
/*     */     
/*     */     public void addFieldError(String fieldName, String errorMessage) {
/* 341 */       this.log.error("Validation error for {}:{}", fieldName, errorMessage);
/*     */     }
/*     */     
/*     */     public boolean hasActionErrors() {
/* 345 */       return false;
/*     */     }
/*     */     
/*     */     public boolean hasActionMessages() {
/* 349 */       return false;
/*     */     }
/*     */     
/*     */     public boolean hasErrors() {
/* 353 */       return false;
/*     */     }
/*     */     
/*     */     public boolean hasFieldErrors() {
/* 357 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\DelegatingValidatorContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */