/*    */ package com.opensymphony.xwork2.ognl.accessor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ognl.ObjectProxy;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*    */ import java.util.Map;
/*    */ import ognl.OgnlContext;
/*    */ import ognl.OgnlException;
/*    */ import ognl.OgnlRuntime;
/*    */ import ognl.PropertyAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectProxyPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/* 55 */     ObjectProxy proxy = (ObjectProxy)target;
/* 56 */     setupContext(context, proxy);
/*    */     
/* 58 */     return OgnlRuntime.getPropertyAccessor(proxy.getValue().getClass()).getProperty(context, target, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 63 */     ObjectProxy proxy = (ObjectProxy)target;
/* 64 */     setupContext(context, proxy);
/*    */     
/* 66 */     OgnlRuntime.getPropertyAccessor(proxy.getValue().getClass()).setProperty(context, target, name, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void setupContext(Map context, ObjectProxy proxy) {
/* 77 */     ReflectionContextState.setLastBeanClassAccessed(context, proxy.getLastClassAccessed());
/* 78 */     ReflectionContextState.setLastBeanPropertyAccessed(context, proxy.getLastPropertyAccessed());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\ObjectProxyPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */