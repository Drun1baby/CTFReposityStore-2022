/*     */ package com.opensymphony.xwork2.inject;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConstructionContext<T>
/*     */ {
/*     */   T currentReference;
/*     */   boolean constructing;
/*     */   List<DelegatingInvocationHandler<T>> invocationHandlers;
/*     */   
/*     */   T getCurrentReference() {
/*  39 */     return this.currentReference;
/*     */   }
/*     */   
/*     */   void removeCurrentReference() {
/*  43 */     this.currentReference = null;
/*     */   }
/*     */   
/*     */   void setCurrentReference(T currentReference) {
/*  47 */     this.currentReference = currentReference;
/*     */   }
/*     */   
/*     */   boolean isConstructing() {
/*  51 */     return this.constructing;
/*     */   }
/*     */   
/*     */   void startConstruction() {
/*  55 */     this.constructing = true;
/*     */   }
/*     */   
/*     */   void finishConstruction() {
/*  59 */     this.constructing = false;
/*  60 */     this.invocationHandlers = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object createProxy(Class<? super T> expectedType) {
/*  68 */     if (!expectedType.isInterface()) {
/*  69 */       throw new DependencyException(expectedType.getName() + " is not an interface.");
/*     */     }
/*     */     
/*  72 */     if (this.invocationHandlers == null) {
/*  73 */       this.invocationHandlers = new ArrayList<>();
/*     */     }
/*     */     
/*  76 */     DelegatingInvocationHandler<T> invocationHandler = new DelegatingInvocationHandler<>();
/*  77 */     this.invocationHandlers.add(invocationHandler);
/*     */     
/*  79 */     return Proxy.newProxyInstance(expectedType.getClassLoader(), new Class[] { expectedType }, invocationHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setProxyDelegates(T delegate) {
/*  87 */     if (this.invocationHandlers != null) {
/*  88 */       for (DelegatingInvocationHandler<T> invocationHandler : this.invocationHandlers) {
/*  89 */         invocationHandler.setDelegate(delegate);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static class DelegatingInvocationHandler<T>
/*     */     implements InvocationHandler
/*     */   {
/*     */     T delegate;
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 100 */       if (this.delegate == null) {
/* 101 */         throw new IllegalStateException("Not finished constructing. Please don't call methods on this object until the caller's construction is complete.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 107 */         return method.invoke(this.delegate, args);
/* 108 */       } catch (IllegalAccessException|IllegalArgumentException e) {
/* 109 */         throw new RuntimeException(e);
/* 110 */       } catch (InvocationTargetException e) {
/* 111 */         throw e.getTargetException();
/*     */       } 
/*     */     }
/*     */     
/*     */     void setDelegate(T delegate) {
/* 116 */       this.delegate = delegate;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\ConstructionContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */