/*     */ package com.opensymphony.xwork2.util.profiling;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ObjectProfiler
/*     */ {
/*     */   public static Object getProfiledObject(Class interfaceClazz, Object o) {
/*  93 */     if (!UtilTimerStack.isActive()) {
/*  94 */       return o;
/*     */     }
/*     */ 
/*     */     
/*  98 */     if (interfaceClazz.isInterface()) {
/*  99 */       InvocationHandler timerHandler = new TimerInvocationHandler(o);
/* 100 */       return Proxy.newProxyInstance(interfaceClazz.getClassLoader(), new Class[] { interfaceClazz }, timerHandler);
/*     */     } 
/*     */     
/* 103 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object profiledInvoke(Method target, Object value, Object[] args) throws IllegalAccessException, InvocationTargetException {
/* 122 */     if (!UtilTimerStack.isActive()) {
/* 123 */       return target.invoke(value, args);
/*     */     }
/*     */     
/* 126 */     String logLine = getTrimmedClassName(target) + "." + target.getName() + "()";
/*     */     
/* 128 */     UtilTimerStack.push(logLine);
/*     */     try {
/* 130 */       Object returnValue = target.invoke(value, args);
/*     */ 
/*     */       
/* 133 */       if (returnValue != null && target.getReturnType().isInterface()) {
/* 134 */         InvocationHandler timerHandler = new TimerInvocationHandler(returnValue);
/* 135 */         return Proxy.newProxyInstance(returnValue.getClass().getClassLoader(), new Class[] { target.getReturnType() }, timerHandler);
/*     */       } 
/*     */       
/* 138 */       return returnValue;
/*     */     } finally {
/*     */       
/* 141 */       UtilTimerStack.pop(logLine);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTrimmedClassName(Method method) {
/* 153 */     String classname = method.getDeclaringClass().getName();
/* 154 */     return classname.substring(classname.lastIndexOf('.') + 1);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\profiling\ObjectProfiler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */