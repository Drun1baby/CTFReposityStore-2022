/*    */ package com.opensymphony.xwork2.util.logging.commons;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class CommonsLoggerFactory
/*    */   extends LoggerFactory
/*    */ {
/*    */   protected Logger getLoggerImpl(Class<?> cls) {
/* 35 */     return new CommonsLogger(LogFactory.getLog(cls));
/*    */   }
/*    */ 
/*    */   
/*    */   protected Logger getLoggerImpl(String name) {
/* 40 */     return new CommonsLogger(LogFactory.getLog(name));
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\commons\CommonsLoggerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */