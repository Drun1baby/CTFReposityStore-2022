/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.conversion.ConversionPropertiesProcessor;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import com.opensymphony.xwork2.inject.EarlyInitializable;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConversionPropertiesProcessor
/*     */   implements ConversionPropertiesProcessor, EarlyInitializable
/*     */ {
/*  41 */   private static final Logger LOG = LogManager.getLogger(DefaultConversionPropertiesProcessor.class);
/*     */   
/*     */   private TypeConverterCreator converterCreator;
/*     */   private TypeConverterHolder converterHolder;
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterCreator(TypeConverterCreator converterCreator) {
/*  48 */     this.converterCreator = converterCreator;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterHolder(TypeConverterHolder converterHolder) {
/*  53 */     this.converterHolder = converterHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  58 */     LOG.debug("Processing default conversion properties files");
/*  59 */     processRequired("struts-default-conversion.properties");
/*  60 */     process("xwork-conversion.properties");
/*     */   }
/*     */   
/*     */   public void process(String propsName) {
/*  64 */     loadConversionProperties(propsName, false);
/*     */   }
/*     */   
/*     */   public void processRequired(String propsName) {
/*  68 */     loadConversionProperties(propsName, true);
/*     */   }
/*     */   
/*     */   public void loadConversionProperties(String propsName, boolean require) {
/*     */     try {
/*  73 */       Iterator<URL> resources = ClassLoaderUtil.getResources(propsName, getClass(), true);
/*  74 */       while (resources.hasNext()) {
/*  75 */         URL url = resources.next();
/*  76 */         Properties props = new Properties();
/*  77 */         props.load(url.openStream());
/*     */         
/*  79 */         LOG.debug("Processing conversion file [{}]", propsName);
/*     */         
/*  81 */         for (Object<Object, Object> o : props.entrySet()) {
/*  82 */           Map.Entry entry = (Map.Entry)o;
/*  83 */           String key = (String)entry.getKey();
/*     */           
/*     */           try {
/*  86 */             TypeConverter typeConverter = this.converterCreator.createTypeConverter((String)entry.getValue());
/*  87 */             if (LOG.isDebugEnabled()) {
/*  88 */               LOG.debug("\t{}:{} [treated as TypeConverter {}]", key, entry.getValue(), typeConverter);
/*     */             }
/*  90 */             this.converterHolder.addDefaultMapping(key, typeConverter);
/*  91 */           } catch (Exception e) {
/*  92 */             LOG.error("Conversion registration error", e);
/*     */           } 
/*     */         } 
/*     */       } 
/*  96 */     } catch (IOException ex) {
/*  97 */       if (require) {
/*  98 */         throw new XWorkException("Cannot load conversion properties file: " + propsName, ex);
/*     */       }
/* 100 */       LOG.debug("Cannot load conversion properties file: {}", propsName, ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultConversionPropertiesProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */