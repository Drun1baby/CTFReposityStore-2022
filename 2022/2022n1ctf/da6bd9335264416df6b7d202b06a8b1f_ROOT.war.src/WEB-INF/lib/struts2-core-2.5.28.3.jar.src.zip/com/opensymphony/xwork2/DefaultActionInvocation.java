/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.interceptor.WithLazyParams;
/*     */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import ognl.MethodFailedException;
/*     */ import ognl.NoSuchPropertyException;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultActionInvocation
/*     */   implements ActionInvocation
/*     */ {
/*  54 */   private static final Logger LOG = LogManager.getLogger(DefaultActionInvocation.class);
/*     */   
/*     */   protected Object action;
/*     */   protected ActionProxy proxy;
/*     */   protected List<PreResultListener> preResultListeners;
/*     */   protected Map<String, Object> extraContext;
/*     */   protected ActionContext invocationContext;
/*     */   protected Iterator<InterceptorMapping> interceptors;
/*     */   protected ValueStack stack;
/*     */   protected Result result;
/*     */   protected Result explicitResult;
/*     */   protected String resultCode;
/*     */   protected boolean executed = false;
/*     */   protected boolean pushAction = true;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected ActionEventListener actionEventListener;
/*     */   protected ValueStackFactory valueStackFactory;
/*     */   protected Container container;
/*     */   protected UnknownHandlerManager unknownHandlerManager;
/*     */   protected OgnlUtil ognlUtil;
/*     */   protected WithLazyParams.LazyParamInjector lazyParamInjector;
/*     */   
/*     */   public DefaultActionInvocation(Map<String, Object> extraContext, boolean pushAction) {
/*  77 */     this.extraContext = extraContext;
/*  78 */     this.pushAction = pushAction;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUnknownHandlerManager(UnknownHandlerManager unknownHandlerManager) {
/*  83 */     this.unknownHandlerManager = unknownHandlerManager;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory fac) {
/*  88 */     this.valueStackFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  93 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container cont) {
/*  98 */     this.container = cont;
/*     */   }
/*     */   
/*     */   @Inject(required = false)
/*     */   public void setActionEventListener(ActionEventListener listener) {
/* 103 */     this.actionEventListener = listener;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setOgnlUtil(OgnlUtil ognlUtil) {
/* 108 */     this.ognlUtil = ognlUtil;
/*     */   }
/*     */   
/*     */   public Object getAction() {
/* 112 */     return this.action;
/*     */   }
/*     */   
/*     */   public boolean isExecuted() {
/* 116 */     return this.executed;
/*     */   }
/*     */   
/*     */   public ActionContext getInvocationContext() {
/* 120 */     return this.invocationContext;
/*     */   }
/*     */   
/*     */   public ActionProxy getProxy() {
/* 124 */     return this.proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result getResult() throws Exception {
/* 137 */     Result returnResult = this.result;
/*     */ 
/*     */     
/* 140 */     while (returnResult instanceof ActionChainResult) {
/* 141 */       ActionProxy aProxy = ((ActionChainResult)returnResult).getProxy();
/*     */       
/* 143 */       if (aProxy != null) {
/* 144 */         Result proxyResult = aProxy.getInvocation().getResult();
/*     */         
/* 146 */         if (proxyResult != null && aProxy.getExecuteResult()) {
/* 147 */           returnResult = proxyResult;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     return returnResult;
/*     */   }
/*     */   
/*     */   public String getResultCode() {
/* 160 */     return this.resultCode;
/*     */   }
/*     */   
/*     */   public void setResultCode(String resultCode) {
/* 164 */     if (isExecuted()) {
/* 165 */       throw new IllegalStateException("Result has already been executed.");
/*     */     }
/* 167 */     this.resultCode = resultCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueStack getStack() {
/* 172 */     return this.stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPreResultListener(PreResultListener listener) {
/* 183 */     if (this.preResultListeners == null) {
/* 184 */       this.preResultListeners = new ArrayList<>(1);
/*     */     }
/*     */     
/* 187 */     this.preResultListeners.add(listener);
/*     */   }
/*     */   
/*     */   public Result createResult() throws Exception {
/* 191 */     LOG.trace("Creating result related to resultCode [{}]", this.resultCode);
/*     */     
/* 193 */     if (this.explicitResult != null) {
/* 194 */       Result ret = this.explicitResult;
/* 195 */       this.explicitResult = null;
/*     */       
/* 197 */       return ret;
/*     */     } 
/* 199 */     ActionConfig config = this.proxy.getConfig();
/* 200 */     Map<String, ResultConfig> results = config.getResults();
/*     */     
/* 202 */     ResultConfig resultConfig = null;
/*     */     
/*     */     try {
/* 205 */       resultConfig = results.get(this.resultCode);
/* 206 */     } catch (NullPointerException e) {
/* 207 */       LOG.debug("Got NPE trying to read result configuration for resultCode [{}]", this.resultCode);
/*     */     } 
/*     */     
/* 210 */     if (resultConfig == null)
/*     */     {
/* 212 */       resultConfig = results.get("*");
/*     */     }
/*     */     
/* 215 */     if (resultConfig != null)
/*     */       try {
/* 217 */         return this.objectFactory.buildResult(resultConfig, this.invocationContext.getContextMap());
/* 218 */       } catch (Exception e) {
/* 219 */         LOG.error("There was an exception while instantiating the result of type {}", resultConfig.getClassName(), e);
/* 220 */         throw new XWorkException(e, resultConfig);
/*     */       }  
/* 222 */     if (this.resultCode != null && !"none".equals(this.resultCode) && this.unknownHandlerManager.hasUnknownHandlers()) {
/* 223 */       return this.unknownHandlerManager.handleUnknownResult(this.invocationContext, this.proxy.getActionName(), this.proxy.getConfig(), this.resultCode);
/*     */     }
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String invoke() throws Exception {
/* 232 */     String profileKey = "invoke: ";
/*     */     try {
/* 234 */       UtilTimerStack.push(profileKey);
/*     */       
/* 236 */       if (this.executed) {
/* 237 */         throw new IllegalStateException("Action has already executed");
/*     */       }
/*     */       
/* 240 */       if (this.interceptors.hasNext()) {
/* 241 */         InterceptorMapping interceptorMapping = this.interceptors.next();
/* 242 */         String interceptorMsg = "interceptorMapping: " + interceptorMapping.getName();
/* 243 */         UtilTimerStack.push(interceptorMsg);
/*     */         try {
/* 245 */           Interceptor interceptor = interceptorMapping.getInterceptor();
/* 246 */           if (interceptor instanceof WithLazyParams) {
/* 247 */             interceptor = this.lazyParamInjector.injectParams(interceptor, interceptorMapping.getParams(), this.invocationContext);
/*     */           }
/* 249 */           this.resultCode = interceptor.intercept(this);
/*     */         } finally {
/* 251 */           UtilTimerStack.pop(interceptorMsg);
/*     */         } 
/*     */       } else {
/* 254 */         this.resultCode = invokeActionOnly();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 259 */       if (!this.executed) {
/* 260 */         if (this.preResultListeners != null) {
/* 261 */           LOG.trace("Executing PreResultListeners for result [{}]", this.result);
/*     */           
/* 263 */           for (PreResultListener preResultListener : this.preResultListeners) {
/* 264 */             PreResultListener listener = preResultListener;
/*     */             
/* 266 */             String _profileKey = "preResultListener: ";
/*     */             try {
/* 268 */               UtilTimerStack.push(_profileKey);
/* 269 */               listener.beforeResult(this, this.resultCode);
/*     */             } finally {
/*     */               
/* 272 */               UtilTimerStack.pop(_profileKey);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 278 */         if (this.proxy.getExecuteResult()) {
/* 279 */           executeResult();
/*     */         }
/*     */         
/* 282 */         this.executed = true;
/*     */       } 
/*     */       
/* 285 */       return this.resultCode;
/*     */     } finally {
/*     */       
/* 288 */       UtilTimerStack.pop(profileKey);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String invokeActionOnly() throws Exception {
/* 293 */     return invokeAction(getAction(), this.proxy.getConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void createAction(Map<String, Object> contextMap) {
/* 298 */     String timerKey = "actionCreate: " + this.proxy.getActionName();
/*     */     try {
/* 300 */       UtilTimerStack.push(timerKey);
/* 301 */       this.action = this.objectFactory.buildAction(this.proxy.getActionName(), this.proxy.getNamespace(), this.proxy.getConfig(), contextMap);
/* 302 */     } catch (InstantiationException e) {
/* 303 */       throw new XWorkException("Unable to instantiate Action!", e, this.proxy.getConfig());
/* 304 */     } catch (IllegalAccessException e) {
/* 305 */       throw new XWorkException("Illegal access to constructor, is it public?", e, this.proxy.getConfig());
/* 306 */     } catch (Exception e) {
/*     */ 
/*     */       
/* 309 */       if (this.proxy == null) {
/* 310 */         gripe = "Whoa!  No ActionProxy instance found in current ActionInvocation.  This is bad ... very bad";
/* 311 */       } else if (this.proxy.getConfig() == null) {
/* 312 */         gripe = "Sheesh.  Where'd that ActionProxy get to?  I can't find it in the current ActionInvocation!?";
/* 313 */       } else if (this.proxy.getConfig().getClassName() == null) {
/* 314 */         gripe = "No Action defined for '" + this.proxy.getActionName() + "' in namespace '" + this.proxy.getNamespace() + "'";
/*     */       } else {
/* 316 */         gripe = "Unable to instantiate Action, " + this.proxy.getConfig().getClassName() + ",  defined for '" + this.proxy.getActionName() + "' in namespace '" + this.proxy.getNamespace() + "'";
/*     */       } 
/*     */       
/* 319 */       String gripe = gripe + ((" -- " + e.getMessage() != null) ? e.getMessage() : " [no message in exception]");
/* 320 */       throw new XWorkException(gripe, e, this.proxy.getConfig());
/*     */     } finally {
/* 322 */       UtilTimerStack.pop(timerKey);
/*     */     } 
/*     */     
/* 325 */     if (this.actionEventListener != null) {
/* 326 */       this.action = this.actionEventListener.prepare(this.action, this.stack);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Object> createContextMap() {
/*     */     Map<String, Object> contextMap;
/* 333 */     if (this.extraContext != null && this.extraContext.containsKey("com.opensymphony.xwork2.util.ValueStack.ValueStack")) {
/*     */       
/* 335 */       this.stack = (ValueStack)this.extraContext.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/*     */       
/* 337 */       if (this.stack == null) {
/* 338 */         throw new IllegalStateException("There was a null Stack set into the extra params.");
/*     */       }
/*     */       
/* 341 */       contextMap = this.stack.getContext();
/*     */     }
/*     */     else {
/*     */       
/* 345 */       this.stack = this.valueStackFactory.createValueStack();
/*     */ 
/*     */       
/* 348 */       contextMap = this.stack.getContext();
/*     */     } 
/*     */ 
/*     */     
/* 352 */     if (this.extraContext != null) {
/* 353 */       contextMap.putAll(this.extraContext);
/*     */     }
/*     */ 
/*     */     
/* 357 */     contextMap.put("com.opensymphony.xwork2.ActionContext.actionInvocation", this);
/* 358 */     contextMap.put("com.opensymphony.xwork2.ActionContext.container", this.container);
/*     */     
/* 360 */     return contextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void executeResult() throws Exception {
/* 369 */     this.result = createResult();
/*     */     
/* 371 */     String timerKey = "executeResult: " + getResultCode();
/*     */     try {
/* 373 */       UtilTimerStack.push(timerKey);
/* 374 */       if (this.result != null)
/* 375 */       { this.result.execute(this); }
/* 376 */       else { if (this.resultCode != null && !"none".equals(this.resultCode)) {
/* 377 */           throw new ConfigurationException("No result defined for action " + getAction().getClass().getName() + " and result " + getResultCode(), this.proxy.getConfig());
/*     */         }
/*     */         
/* 380 */         if (LOG.isDebugEnabled()) {
/* 381 */           LOG.debug("No result returned for action {} at {}", getAction().getClass().getName(), this.proxy.getConfig().getLocation());
/*     */         } }
/*     */     
/*     */     } finally {
/* 385 */       UtilTimerStack.pop(timerKey);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void init(ActionProxy proxy) {
/* 390 */     this.proxy = proxy;
/* 391 */     Map<String, Object> contextMap = createContextMap();
/*     */ 
/*     */ 
/*     */     
/* 395 */     ActionContext actionContext = ActionContext.getContext();
/*     */     
/* 397 */     if (actionContext != null) {
/* 398 */       actionContext.setActionInvocation(this);
/*     */     }
/*     */     
/* 401 */     createAction(contextMap);
/*     */     
/* 403 */     if (this.pushAction) {
/* 404 */       this.stack.push(this.action);
/* 405 */       contextMap.put("action", this.action);
/*     */     } 
/*     */     
/* 408 */     this.invocationContext = new ActionContext(contextMap);
/* 409 */     this.invocationContext.setName(proxy.getActionName());
/*     */     
/* 411 */     createInterceptors(proxy);
/*     */     
/* 413 */     prepareLazyParamInjector(this.invocationContext.getValueStack());
/*     */   }
/*     */   
/*     */   protected void prepareLazyParamInjector(ValueStack valueStack) {
/* 417 */     this.lazyParamInjector = new WithLazyParams.LazyParamInjector(valueStack);
/* 418 */     this.container.inject(this.lazyParamInjector);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void createInterceptors(ActionProxy proxy) {
/* 423 */     List<InterceptorMapping> interceptorList = new ArrayList<>(proxy.getConfig().getInterceptors());
/* 424 */     this.interceptors = interceptorList.iterator();
/*     */   }
/*     */   
/*     */   protected String invokeAction(Object action, ActionConfig actionConfig) throws Exception {
/* 428 */     String methodName = this.proxy.getMethod();
/*     */     
/* 430 */     LOG.debug("Executing action method = {}", methodName);
/*     */     
/* 432 */     String timerKey = "invokeAction: " + this.proxy.getActionName(); try {
/*     */       Object methodResult;
/* 434 */       UtilTimerStack.push(timerKey);
/*     */ 
/*     */       
/*     */       try {
/* 438 */         methodResult = this.ognlUtil.callMethod(methodName + "()", getStack().getContext(), action);
/* 439 */       } catch (MethodFailedException e) {
/*     */         
/* 441 */         if (e.getReason() instanceof NoSuchMethodException) {
/* 442 */           if (this.unknownHandlerManager.hasUnknownHandlers()) {
/*     */             try {
/* 444 */               methodResult = this.unknownHandlerManager.handleUnknownMethod(action, methodName);
/* 445 */             } catch (NoSuchMethodException ignore) {
/*     */               
/* 447 */               throw e;
/*     */             } 
/*     */           } else {
/*     */             
/* 451 */             throw e;
/*     */           } 
/*     */           
/* 454 */           if (methodResult == null) {
/* 455 */             throw e;
/*     */           }
/*     */         } else {
/*     */           
/* 459 */           throw e;
/*     */         } 
/*     */       } 
/* 462 */       return saveResult(actionConfig, methodResult);
/* 463 */     } catch (NoSuchPropertyException e) {
/* 464 */       Object methodResult; throw new IllegalArgumentException("The " + methodName + "() is not defined in action " + getAction().getClass() + "");
/* 465 */     } catch (MethodFailedException e) {
/*     */       Object methodResult;
/* 467 */       Throwable t = methodResult.getCause();
/*     */       
/* 469 */       if (this.actionEventListener != null) {
/* 470 */         String result = this.actionEventListener.handleException(t, getStack());
/* 471 */         if (result != null) {
/* 472 */           return result;
/*     */         }
/*     */       } 
/* 475 */       if (t instanceof Exception) {
/* 476 */         throw (Exception)t;
/*     */       }
/* 478 */       throw methodResult;
/*     */     } finally {
/*     */       
/* 481 */       UtilTimerStack.pop(timerKey);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String saveResult(ActionConfig actionConfig, Object methodResult) {
/* 492 */     if (methodResult instanceof Result) {
/* 493 */       this.explicitResult = (Result)methodResult;
/*     */ 
/*     */       
/* 496 */       this.container.inject(this.explicitResult);
/* 497 */       return null;
/*     */     } 
/* 499 */     return (String)methodResult;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultActionInvocation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */