/*    */ package com.opensymphony.xwork2.inject.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Strings
/*    */ {
/*    */   @Deprecated
/*    */   public static String capitalize(String s) {
/* 49 */     if (s.length() == 0)
/* 50 */       return s; 
/* 51 */     char first = s.charAt(0);
/* 52 */     char capitalized = Character.toUpperCase(first);
/* 53 */     return (first == capitalized) ? s : (capitalized + s.substring(1));
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\injec\\util\Strings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */