/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.WildcardHelper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodFilterInterceptorUtil
/*     */ {
/*     */   public static boolean applyMethod(Set<String> excludeMethods, Set<String> includeMethods, String method) {
/*     */     String methodCopy;
/*  55 */     boolean needsPatternMatch = false;
/*  56 */     for (String includeMethod : includeMethods) {
/*  57 */       if (!"*".equals(includeMethod) && includeMethod.contains("*")) {
/*  58 */         needsPatternMatch = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  63 */     for (String excludeMethod : excludeMethods) {
/*  64 */       if (!"*".equals(excludeMethod) && excludeMethod.contains("*")) {
/*  65 */         needsPatternMatch = true;
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/*  72 */     if (!needsPatternMatch && (includeMethods.contains("*") || includeMethods.size() == 0) && 
/*  73 */       excludeMethods != null && excludeMethods.contains(method) && !includeMethods.contains(method))
/*     */     {
/*     */       
/*  76 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  81 */     WildcardHelper wildcard = new WildcardHelper();
/*     */     
/*  83 */     if (method == null) {
/*  84 */       methodCopy = "";
/*     */     } else {
/*     */       
/*  87 */       methodCopy = new String(method);
/*     */     } 
/*  89 */     for (String pattern : includeMethods) {
/*  90 */       if (pattern.contains("*")) {
/*  91 */         int[] compiledPattern = wildcard.compilePattern(pattern);
/*  92 */         HashMap<String, String> matchedPatterns = new HashMap<>();
/*  93 */         boolean matches = wildcard.match(matchedPatterns, methodCopy, compiledPattern);
/*  94 */         if (matches) {
/*  95 */           return true;
/*     */         }
/*     */         continue;
/*     */       } 
/*  99 */       if (pattern.equals(methodCopy)) {
/* 100 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 104 */     if (excludeMethods.contains("*")) {
/* 105 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 109 */     for (String pattern : excludeMethods) {
/* 110 */       if (pattern.contains("*")) {
/* 111 */         int[] compiledPattern = wildcard.compilePattern(pattern);
/* 112 */         HashMap<String, String> matchedPatterns = new HashMap<>();
/* 113 */         boolean matches = wildcard.match(matchedPatterns, methodCopy, compiledPattern);
/* 114 */         if (matches)
/*     */         {
/* 116 */           return false;
/*     */         }
/*     */         continue;
/*     */       } 
/* 120 */       if (pattern.equals(methodCopy))
/*     */       {
/* 122 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     return (includeMethods.size() == 0 || includeMethods.contains(method) || includeMethods.contains("*"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean applyMethod(String excludeMethods, String includeMethods, String method) {
/* 142 */     Set<String> includeMethodsSet = TextParseUtil.commaDelimitedStringToSet((includeMethods == null) ? "" : includeMethods);
/* 143 */     Set<String> excludeMethodsSet = TextParseUtil.commaDelimitedStringToSet((excludeMethods == null) ? "" : excludeMethods);
/*     */     
/* 145 */     return applyMethod(excludeMethodsSet, includeMethodsSet, method);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\MethodFilterInterceptorUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */