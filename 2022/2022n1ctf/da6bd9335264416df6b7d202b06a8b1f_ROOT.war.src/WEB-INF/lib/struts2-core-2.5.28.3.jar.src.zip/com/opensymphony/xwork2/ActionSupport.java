/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.ValidationAware;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionSupport
/*     */   implements Action, Validateable, ValidationAware, TextProvider, LocaleProvider, Serializable
/*     */ {
/*  38 */   private static final Logger LOG = LogManager.getLogger(ActionSupport.class);
/*     */   
/*  40 */   private final ValidationAwareSupport validationAware = new ValidationAwareSupport();
/*     */   
/*     */   private transient TextProvider textProvider;
/*     */   
/*     */   private transient LocaleProvider localeProvider;
/*     */   protected Container container;
/*     */   
/*     */   public void setActionErrors(Collection<String> errorMessages) {
/*  48 */     this.validationAware.setActionErrors(errorMessages);
/*     */   }
/*     */   
/*     */   public Collection<String> getActionErrors() {
/*  52 */     return this.validationAware.getActionErrors();
/*     */   }
/*     */   
/*     */   public void setActionMessages(Collection<String> messages) {
/*  56 */     this.validationAware.setActionMessages(messages);
/*     */   }
/*     */   
/*     */   public Collection<String> getActionMessages() {
/*  60 */     return this.validationAware.getActionMessages();
/*     */   }
/*     */   
/*     */   public void setFieldErrors(Map<String, List<String>> errorMap) {
/*  64 */     this.validationAware.setFieldErrors(errorMap);
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> getFieldErrors() {
/*  68 */     return this.validationAware.getFieldErrors();
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/*  73 */     return getLocaleProvider().getLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidLocaleString(String localeStr) {
/*  78 */     return getLocaleProvider().isValidLocaleString(localeStr);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidLocale(Locale locale) {
/*  83 */     return getLocaleProvider().isValidLocale(locale);
/*     */   }
/*     */   
/*     */   public boolean hasKey(String key) {
/*  87 */     return getTextProvider().hasKey(key);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName) {
/*  91 */     return getTextProvider().getText(aTextName);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue) {
/*  95 */     return getTextProvider().getText(aTextName, defaultValue);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue, String obj) {
/*  99 */     return getTextProvider().getText(aTextName, defaultValue, obj);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, List<?> args) {
/* 103 */     return getTextProvider().getText(aTextName, args);
/*     */   }
/*     */   
/*     */   public String getText(String key, String[] args) {
/* 107 */     return getTextProvider().getText(key, args);
/*     */   }
/*     */   
/*     */   public String getText(String aTextName, String defaultValue, List<?> args) {
/* 111 */     return getTextProvider().getText(aTextName, defaultValue, args);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args) {
/* 115 */     return getTextProvider().getText(key, defaultValue, args);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args, ValueStack stack) {
/* 119 */     return getTextProvider().getText(key, defaultValue, args, stack);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args, ValueStack stack) {
/* 123 */     return getTextProvider().getText(key, defaultValue, args, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormatted(String key, String expr) {
/* 134 */     Map<String, Object> conversionErrors = ActionContext.getContext().getConversionErrors();
/* 135 */     if (conversionErrors.containsKey(expr)) {
/* 136 */       String[] vals = (String[])conversionErrors.get(expr);
/* 137 */       return vals[0];
/*     */     } 
/* 139 */     ValueStack valueStack = ActionContext.getContext().getValueStack();
/* 140 */     Object val = valueStack.findValue(expr);
/* 141 */     return getText(key, Arrays.asList(new Object[] { val }));
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceBundle getTexts() {
/* 146 */     return getTextProvider().getTexts();
/*     */   }
/*     */   
/*     */   public ResourceBundle getTexts(String aBundleName) {
/* 150 */     return getTextProvider().getTexts(aBundleName);
/*     */   }
/*     */   
/*     */   public void addActionError(String anErrorMessage) {
/* 154 */     this.validationAware.addActionError(anErrorMessage);
/*     */   }
/*     */   
/*     */   public void addActionMessage(String aMessage) {
/* 158 */     this.validationAware.addActionMessage(aMessage);
/*     */   }
/*     */   
/*     */   public void addFieldError(String fieldName, String errorMessage) {
/* 162 */     this.validationAware.addFieldError(fieldName, errorMessage);
/*     */   }
/*     */   
/*     */   public String input() throws Exception {
/* 166 */     return "input";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String execute() throws Exception {
/* 184 */     return "success";
/*     */   }
/*     */   
/*     */   public boolean hasActionErrors() {
/* 188 */     return this.validationAware.hasActionErrors();
/*     */   }
/*     */   
/*     */   public boolean hasActionMessages() {
/* 192 */     return this.validationAware.hasActionMessages();
/*     */   }
/*     */   
/*     */   public boolean hasErrors() {
/* 196 */     return this.validationAware.hasErrors();
/*     */   }
/*     */   
/*     */   public boolean hasFieldErrors() {
/* 200 */     return this.validationAware.hasFieldErrors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearFieldErrors() {
/* 208 */     this.validationAware.clearFieldErrors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearActionErrors() {
/* 216 */     this.validationAware.clearActionErrors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearMessages() {
/* 224 */     this.validationAware.clearMessages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearErrors() {
/* 232 */     this.validationAware.clearErrors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearErrorsAndMessages() {
/* 240 */     this.validationAware.clearErrorsAndMessages();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/* 252 */     return super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause(String result) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextProvider getTextProvider() {
/* 285 */     if (this.textProvider == null) {
/* 286 */       Container container = getContainer();
/* 287 */       TextProviderFactory tpf = (TextProviderFactory)container.getInstance(TextProviderFactory.class);
/* 288 */       this.textProvider = tpf.createInstance(getClass());
/*     */     } 
/* 290 */     return this.textProvider;
/*     */   }
/*     */   
/*     */   protected LocaleProvider getLocaleProvider() {
/* 294 */     if (this.localeProvider == null) {
/* 295 */       Container container = getContainer();
/* 296 */       LocaleProviderFactory localeProviderFactory = (LocaleProviderFactory)container.getInstance(LocaleProviderFactory.class);
/* 297 */       this.localeProvider = localeProviderFactory.createLocaleProvider();
/*     */     } 
/* 299 */     return this.localeProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Container getContainer() {
/* 306 */     if (this.container == null) {
/* 307 */       this.container = ActionContext.getContext().getContainer();
/* 308 */       if (this.container != null) {
/* 309 */         boolean devMode = Boolean.parseBoolean((String)this.container.getInstance(String.class, "struts.devMode"));
/* 310 */         if (devMode) {
/* 311 */           LOG.warn("Container is null, action was created manually? Fallback to ActionContext");
/*     */         } else {
/* 313 */           LOG.debug("Container is null, action was created manually? Fallback to ActionContext");
/*     */         } 
/*     */       } else {
/* 316 */         LOG.warn("Container is null, action was created out of ActionContext scope?!?");
/*     */       } 
/*     */     } 
/* 319 */     return this.container;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 324 */     this.container = container;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ActionSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */