/*     */ package com.opensymphony.xwork2.util.reflection;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionContextState
/*     */ {
/*     */   private static final String GETTING_BY_KEY_PROPERTY = "xwork.getting.by.key.property";
/*     */   private static final String SET_MAP_KEY = "set.map.key";
/*     */   public static final String CURRENT_PROPERTY_PATH = "current.property.path";
/*     */   public static final String FULL_PROPERTY_PATH = "current.property.path";
/*     */   public static final String CREATE_NULL_OBJECTS = "xwork.NullHandler.createNullObjects";
/*     */   public static final String DENY_METHOD_EXECUTION = "xwork.MethodAccessor.denyMethodExecution";
/*     */   public static final String DENY_INDEXED_ACCESS_EXECUTION = "xwork.IndexedPropertyAccessor.denyMethodExecution";
/*     */   
/*     */   public static boolean isCreatingNullObjects(Map<String, Object> context) {
/*  45 */     return getBooleanProperty("xwork.NullHandler.createNullObjects", context);
/*     */   }
/*     */   
/*     */   public static void setCreatingNullObjects(Map<String, Object> context, boolean creatingNullObjects) {
/*  49 */     setBooleanValue("xwork.NullHandler.createNullObjects", context, creatingNullObjects);
/*     */   }
/*     */   
/*     */   public static boolean isGettingByKeyProperty(Map<String, Object> context) {
/*  53 */     return getBooleanProperty("xwork.getting.by.key.property", context);
/*     */   }
/*     */   
/*     */   public static void setDenyMethodExecution(Map<String, Object> context, boolean denyMethodExecution) {
/*  57 */     setBooleanValue("xwork.MethodAccessor.denyMethodExecution", context, denyMethodExecution);
/*     */   }
/*     */   
/*     */   public static boolean isDenyMethodExecution(Map<String, Object> context) {
/*  61 */     return getBooleanProperty("xwork.MethodAccessor.denyMethodExecution", context);
/*     */   }
/*     */   
/*     */   public static void setGettingByKeyProperty(Map<String, Object> context, boolean gettingByKeyProperty) {
/*  65 */     setBooleanValue("xwork.getting.by.key.property", context, gettingByKeyProperty);
/*     */   }
/*     */   
/*     */   public static boolean isReportingConversionErrors(Map<String, Object> context) {
/*  69 */     return getBooleanProperty("report.conversion.errors", context);
/*     */   }
/*     */   
/*     */   public static void setReportingConversionErrors(Map<String, Object> context, boolean reportingErrors) {
/*  73 */     setBooleanValue("report.conversion.errors", context, reportingErrors);
/*     */   }
/*     */   
/*     */   public static Class getLastBeanClassAccessed(Map<String, Object> context) {
/*  77 */     return (Class)context.get("last.bean.accessed");
/*     */   }
/*     */   
/*     */   public static void setLastBeanPropertyAccessed(Map<String, Object> context, String property) {
/*  81 */     context.put("last.property.accessed", property);
/*     */   }
/*     */   
/*     */   public static String getLastBeanPropertyAccessed(Map<String, Object> context) {
/*  85 */     return (String)context.get("last.property.accessed");
/*     */   }
/*     */   
/*     */   public static void setLastBeanClassAccessed(Map<String, Object> context, Class clazz) {
/*  89 */     context.put("last.bean.accessed", clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCurrentPropertyPath(Map<String, Object> context) {
/* 108 */     return (String)context.get("current.property.path");
/*     */   }
/*     */   
/*     */   public static String getFullPropertyPath(Map<String, Object> context) {
/* 112 */     return (String)context.get("current.property.path");
/*     */   }
/*     */   
/*     */   public static void setFullPropertyPath(Map<String, Object> context, String path) {
/* 116 */     context.put("current.property.path", path);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateCurrentPropertyPath(Map<String, Object> context, Object name) {
/* 121 */     String currentPath = getCurrentPropertyPath(context);
/* 122 */     if (name != null) {
/* 123 */       if (currentPath != null) {
/* 124 */         StringBuilder sb = new StringBuilder(currentPath);
/* 125 */         sb.append(".");
/* 126 */         sb.append(name.toString());
/* 127 */         currentPath = sb.toString();
/*     */       } else {
/* 129 */         currentPath = name.toString();
/*     */       } 
/* 131 */       context.put("current.property.path", currentPath);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setSetMap(Map<String, Object> context, Map<Object, Object> setMap, String path) {
/* 136 */     Map<Object, Map<Object, Object>> mapOfSetMaps = (Map<Object, Map<Object, Object>>)context.get("set.map.key");
/* 137 */     if (mapOfSetMaps == null) {
/* 138 */       mapOfSetMaps = new HashMap<>();
/* 139 */       context.put("set.map.key", mapOfSetMaps);
/*     */     } 
/* 141 */     mapOfSetMaps.put(path, setMap);
/*     */   }
/*     */   
/*     */   public static Map<Object, Object> getSetMap(Map<String, Object> context, String path) {
/* 145 */     Map<Object, Map<Object, Object>> mapOfSetMaps = (Map<Object, Map<Object, Object>>)context.get("set.map.key");
/* 146 */     if (mapOfSetMaps == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     return mapOfSetMaps.get(path);
/*     */   }
/*     */   
/*     */   private static boolean getBooleanProperty(String property, Map<String, Object> context) {
/* 153 */     Boolean myBool = (Boolean)context.get(property);
/* 154 */     return (myBool == null) ? false : myBool.booleanValue();
/*     */   }
/*     */   
/*     */   private static void setBooleanValue(String property, Map<String, Object> context, boolean value) {
/* 158 */     context.put(property, new Boolean(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearCurrentPropertyPath(Map<String, Object> context) {
/* 165 */     context.put("current.property.path", null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clear(Map<String, Object> context) {
/* 170 */     if (context != null) {
/* 171 */       context.put("last.bean.accessed", null);
/* 172 */       context.put("last.property.accessed", null);
/*     */       
/* 174 */       context.put("current.property.path", null);
/* 175 */       context.put("current.property.path", null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\reflection\ReflectionContextState.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */