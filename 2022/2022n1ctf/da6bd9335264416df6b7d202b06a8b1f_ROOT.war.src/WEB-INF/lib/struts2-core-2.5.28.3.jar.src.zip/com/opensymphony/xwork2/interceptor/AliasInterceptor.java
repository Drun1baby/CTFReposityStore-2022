/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.LocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClearableValueStack;
/*     */ import com.opensymphony.xwork2.util.Evaluated;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ import org.apache.struts2.dispatcher.Parameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliasInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*  94 */   private static final Logger LOG = LogManager.getLogger(AliasInterceptor.class);
/*     */   
/*     */   private static final String DEFAULT_ALIAS_KEY = "aliases";
/*  97 */   protected String aliasesKey = "aliases";
/*     */   
/*     */   protected ValueStackFactory valueStackFactory;
/*     */   protected LocalizedTextProvider localizedTextProvider;
/*     */   protected boolean devMode = false;
/*     */   
/*     */   @Inject("devMode")
/*     */   public void setDevMode(String mode) {
/* 105 */     this.devMode = Boolean.parseBoolean(mode);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 110 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/* 115 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAliasesKey(String aliasesKey) {
/* 130 */     this.aliasesKey = aliasesKey;
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 135 */     ActionConfig config = invocation.getProxy().getConfig();
/* 136 */     ActionContext ac = invocation.getInvocationContext();
/* 137 */     Object action = invocation.getAction();
/*     */ 
/*     */     
/* 140 */     Map<String, String> parameters = config.getParams();
/*     */     
/* 142 */     if (parameters.containsKey(this.aliasesKey)) {
/*     */       
/* 144 */       String aliasExpression = parameters.get(this.aliasesKey);
/* 145 */       ValueStack stack = ac.getValueStack();
/* 146 */       Object obj = stack.findValue(aliasExpression);
/*     */       
/* 148 */       if (obj != null && obj instanceof Map) {
/*     */         
/* 150 */         ValueStack newStack = this.valueStackFactory.createValueStack(stack);
/* 151 */         boolean clearableStack = newStack instanceof ClearableValueStack;
/* 152 */         if (clearableStack) {
/*     */ 
/*     */           
/* 155 */           ((ClearableValueStack)newStack).clearContextValues();
/* 156 */           Map<String, Object> context = newStack.getContext();
/* 157 */           ReflectionContextState.setCreatingNullObjects(context, true);
/* 158 */           ReflectionContextState.setDenyMethodExecution(context, true);
/* 159 */           ReflectionContextState.setReportingConversionErrors(context, true);
/*     */ 
/*     */           
/* 162 */           context.put("com.opensymphony.xwork2.ActionContext.locale", stack.getContext().get("com.opensymphony.xwork2.ActionContext.locale"));
/*     */         } 
/*     */ 
/*     */         
/* 166 */         Map aliases = (Map)obj;
/* 167 */         for (Object o : aliases.entrySet()) {
/* 168 */           Map.Entry entry = (Map.Entry)o;
/* 169 */           String name = entry.getKey().toString();
/* 170 */           String alias = (String)entry.getValue();
/* 171 */           Evaluated value = new Evaluated(stack.findValue(name));
/* 172 */           if (!value.isDefined()) {
/*     */             
/* 174 */             HttpParameters contextParameters = ActionContext.getContext().getParameters();
/*     */             
/* 176 */             if (null != contextParameters) {
/* 177 */               Parameter param = contextParameters.get(name);
/* 178 */               if (param.isDefined()) {
/* 179 */                 value = new Evaluated(param.getValue());
/*     */               }
/*     */             } 
/*     */           } 
/* 183 */           if (value.isDefined()) {
/*     */             try {
/* 185 */               newStack.setValue(alias, value.get());
/* 186 */             } catch (RuntimeException e) {
/* 187 */               if (this.devMode) {
/* 188 */                 String developerNotification = this.localizedTextProvider.findText(ParametersInterceptor.class, "devmode.notification", ActionContext.getContext().getLocale(), "Developer Notification:\n{0}", new Object[] { "Unexpected Exception caught setting '" + entry.getKey() + "' on '" + action.getClass() + ": " + e.getMessage() });
/*     */ 
/*     */                 
/* 191 */                 LOG.error(developerNotification);
/* 192 */                 if (action instanceof ValidationAware) {
/* 193 */                   ((ValidationAware)action).addActionMessage(developerNotification);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 200 */         if (clearableStack && stack.getContext() != null && newStack.getContext() != null)
/* 201 */           stack.getContext().put("com.opensymphony.xwork2.ActionContext.conversionErrors", newStack.getContext().get("com.opensymphony.xwork2.ActionContext.conversionErrors")); 
/*     */       } else {
/* 203 */         LOG.debug("invalid alias expression: {}", this.aliasesKey);
/*     */       } 
/*     */     } 
/*     */     
/* 207 */     return invocation.invoke();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\AliasInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */