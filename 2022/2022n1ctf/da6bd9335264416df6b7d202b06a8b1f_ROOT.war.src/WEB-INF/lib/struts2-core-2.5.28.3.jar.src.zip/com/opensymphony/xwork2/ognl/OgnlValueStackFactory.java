/*     */ package com.opensymphony.xwork2.ognl;
/*     */ 
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.conversion.NullHandler;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.accessor.CompoundRootAccessor;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import ognl.MethodAccessor;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.PropertyAccessor;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlValueStackFactory
/*     */   implements ValueStackFactory
/*     */ {
/*  47 */   private static final Logger LOG = LogManager.getLogger(OgnlValueStackFactory.class);
/*     */   
/*     */   protected XWorkConverter xworkConverter;
/*     */   protected CompoundRootAccessor compoundRootAccessor;
/*     */   protected TextProvider textProvider;
/*     */   protected Container container;
/*     */   private boolean allowStaticMethodAccess;
/*     */   
/*     */   @Inject
/*     */   protected void setXWorkConverter(XWorkConverter converter) {
/*  57 */     this.xworkConverter = converter;
/*     */   }
/*     */   
/*     */   @Inject("system")
/*     */   protected void setTextProvider(TextProvider textProvider) {
/*  62 */     this.textProvider = textProvider;
/*     */   }
/*     */   
/*     */   @Inject(value = "allowStaticMethodAccess", required = false)
/*     */   protected void setAllowStaticMethodAccess(String allowStaticMethodAccess) {
/*  67 */     this.allowStaticMethodAccess = BooleanUtils.toBoolean(allowStaticMethodAccess);
/*     */   }
/*     */   
/*     */   public ValueStack createValueStack() {
/*  71 */     ValueStack stack = new OgnlValueStack(this.xworkConverter, this.compoundRootAccessor, this.textProvider, this.allowStaticMethodAccess);
/*  72 */     this.container.inject(stack);
/*  73 */     stack.getContext().put("com.opensymphony.xwork2.ActionContext.container", this.container);
/*  74 */     return stack;
/*     */   }
/*     */   
/*     */   public ValueStack createValueStack(ValueStack stack) {
/*  78 */     ValueStack result = new OgnlValueStack(stack, this.xworkConverter, this.compoundRootAccessor, this.allowStaticMethodAccess);
/*  79 */     this.container.inject(result);
/*  80 */     stack.getContext().put("com.opensymphony.xwork2.ActionContext.container", this.container);
/*  81 */     return result;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   protected void setContainer(Container container) throws ClassNotFoundException {
/*  86 */     Set<String> names = container.getInstanceNames(PropertyAccessor.class);
/*  87 */     for (String name : names) {
/*  88 */       Class<?> cls = Class.forName(name);
/*  89 */       if (cls != null) {
/*  90 */         if (Map.class.isAssignableFrom(cls)) {
/*  91 */           PropertyAccessor propertyAccessor = (PropertyAccessor)container.getInstance(PropertyAccessor.class, name);
/*     */         }
/*  93 */         OgnlRuntime.setPropertyAccessor(cls, (PropertyAccessor)container.getInstance(PropertyAccessor.class, name));
/*  94 */         if (this.compoundRootAccessor == null && CompoundRoot.class.isAssignableFrom(cls)) {
/*  95 */           this.compoundRootAccessor = (CompoundRootAccessor)container.getInstance(PropertyAccessor.class, name);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     names = container.getInstanceNames(MethodAccessor.class);
/* 101 */     for (String name : names) {
/* 102 */       Class<?> cls = Class.forName(name);
/* 103 */       if (cls != null) {
/* 104 */         OgnlRuntime.setMethodAccessor(cls, (MethodAccessor)container.getInstance(MethodAccessor.class, name));
/*     */       }
/*     */     } 
/*     */     
/* 108 */     names = container.getInstanceNames(NullHandler.class);
/* 109 */     for (String name : names) {
/* 110 */       Class<?> cls = Class.forName(name);
/* 111 */       if (cls != null) {
/* 112 */         OgnlRuntime.setNullHandler(cls, new OgnlNullHandlerWrapper((NullHandler)container.getInstance(NullHandler.class, name)));
/*     */       }
/*     */     } 
/* 115 */     if (this.compoundRootAccessor == null) {
/* 116 */       throw new IllegalStateException("Couldn't find the compound root accessor");
/*     */     }
/* 118 */     this.container = container;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\OgnlValueStackFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */