/*    */ package com.opensymphony.xwork2.ognl.accessor;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*    */ import java.util.Map;
/*    */ import ognl.ObjectPropertyAccessor;
/*    */ import ognl.OgnlException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XWorkObjectPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map<String, Class<?>> context, Object target, Object oname) throws OgnlException {
/* 39 */     context.put("last.bean.accessed", target.getClass());
/* 40 */     context.put("last.property.accessed", oname.toString());
/* 41 */     ReflectionContextState.updateCurrentPropertyPath(context, oname);
/* 42 */     return super.getProperty(context, target, oname);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\XWorkObjectPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */