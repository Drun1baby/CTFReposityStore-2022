/*    */ package com.opensymphony.xwork2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.config.ContainerProvider;
/*    */ import com.opensymphony.xwork2.config.providers.XWorkConfigurationProvider;
/*    */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XWorkTestCaseHelper
/*    */ {
/*    */   public static ConfigurationManager setUp() throws Exception {
/* 35 */     ConfigurationManager configurationManager = new ConfigurationManager("default");
/* 36 */     configurationManager.addContainerProvider((ContainerProvider)new XWorkConfigurationProvider());
/* 37 */     Configuration config = configurationManager.getConfiguration();
/* 38 */     Container container = config.getContainer();
/*    */ 
/*    */     
/* 41 */     ValueStack stack = ((ValueStackFactory)container.getInstance(ValueStackFactory.class)).createValueStack();
/* 42 */     stack.getContext().put("com.opensymphony.xwork2.ActionContext.container", container);
/* 43 */     ActionContext.setContext(new ActionContext(stack.getContext()));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     return configurationManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ConfigurationManager loadConfigurationProviders(ConfigurationManager configurationManager, ConfigurationProvider... providers) {
/*    */     try {
/* 56 */       tearDown(configurationManager);
/* 57 */     } catch (Exception e) {
/* 58 */       throw new RuntimeException("Cannot clean old configuration", e);
/*    */     } 
/* 60 */     configurationManager = new ConfigurationManager("default");
/* 61 */     configurationManager.addContainerProvider(new ContainerProvider() { public void destroy() {}
/*    */           
/*    */           public boolean needsReload() {
/* 64 */             return false;
/*    */           } public void init(Configuration configuration) throws ConfigurationException {}
/*    */           public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 67 */             builder.setAllowDuplicates(true);
/*    */           } }
/*    */       );
/*    */     
/* 71 */     configurationManager.addContainerProvider((ContainerProvider)new XWorkConfigurationProvider());
/* 72 */     for (ConfigurationProvider prov : providers) {
/* 73 */       if (prov instanceof XmlConfigurationProvider) {
/* 74 */         ((XmlConfigurationProvider)prov).setThrowExceptionOnDuplicateBeans(false);
/*    */       }
/* 76 */       configurationManager.addContainerProvider((ContainerProvider)prov);
/*    */     } 
/* 78 */     Container container = configurationManager.getConfiguration().getContainer();
/*    */ 
/*    */     
/* 81 */     ValueStack stack = ((ValueStackFactory)container.getInstance(ValueStackFactory.class)).createValueStack();
/* 82 */     stack.getContext().put("com.opensymphony.xwork2.ActionContext.container", container);
/* 83 */     ActionContext.setContext(new ActionContext(stack.getContext()));
/*    */     
/* 85 */     return configurationManager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void tearDown(ConfigurationManager configurationManager) throws Exception {
/* 91 */     if (configurationManager != null) {
/* 92 */       configurationManager.destroyConfiguration();
/*    */     }
/* 94 */     ActionContext.setContext(null);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\XWorkTestCaseHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */