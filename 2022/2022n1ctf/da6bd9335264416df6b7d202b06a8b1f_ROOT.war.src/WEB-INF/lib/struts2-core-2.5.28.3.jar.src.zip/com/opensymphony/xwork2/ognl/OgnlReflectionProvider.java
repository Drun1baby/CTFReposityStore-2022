/*     */ package com.opensymphony.xwork2.ognl;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlReflectionProvider
/*     */   implements ReflectionProvider
/*     */ {
/*     */   private OgnlUtil ognlUtil;
/*     */   
/*     */   @Inject
/*     */   public void setOgnlUtil(OgnlUtil ognlUtil) {
/*  41 */     this.ognlUtil = ognlUtil;
/*     */   }
/*     */   
/*     */   public Field getField(Class inClass, String name) {
/*  45 */     return OgnlRuntime.getField(inClass, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getGetMethod(Class targetClass, String propertyName) throws IntrospectionException, ReflectionException {
/*     */     try {
/*  51 */       return OgnlRuntime.getGetMethod(null, targetClass, propertyName);
/*  52 */     } catch (OgnlException e) {
/*  53 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getSetMethod(Class targetClass, String propertyName) throws IntrospectionException, ReflectionException {
/*     */     try {
/*  60 */       return OgnlRuntime.getSetMethod(null, targetClass, propertyName);
/*  61 */     } catch (OgnlException e) {
/*  62 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, ?> props, Object o, Map<String, Object> context) {
/*  67 */     this.ognlUtil.setProperties(props, o, context);
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, ?> props, Object o, Map<String, Object> context, boolean throwPropertyExceptions) throws ReflectionException {
/*  71 */     this.ognlUtil.setProperties(props, o, context, throwPropertyExceptions);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperties(Map<String, ?> properties, Object o) {
/*  76 */     this.ognlUtil.setProperties(properties, o);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyDescriptor getPropertyDescriptor(Class targetClass, String propertyName) throws IntrospectionException, ReflectionException {
/*     */     try {
/*  83 */       return OgnlRuntime.getPropertyDescriptor(targetClass, propertyName);
/*  84 */     } catch (OgnlException e) {
/*  85 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void copy(Object from, Object to, Map<String, Object> context, Collection<String> exclusions, Collection<String> inclusions) {
/*  91 */     copy(from, to, context, exclusions, inclusions, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void copy(Object from, Object to, Map<String, Object> context, Collection<String> exclusions, Collection<String> inclusions, Class<?> editable) {
/*  96 */     this.ognlUtil.copy(from, to, context, exclusions, inclusions, editable);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getRealTarget(String property, Map<String, Object> context, Object root) throws ReflectionException {
/*     */     try {
/* 102 */       return this.ognlUtil.getRealTarget(property, context, root);
/* 103 */     } catch (OgnlException e) {
/* 104 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value, Object o, Map<String, Object> context) {
/* 109 */     this.ognlUtil.setProperty(name, value, o, context);
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value, Object o, Map<String, Object> context, boolean throwPropertyExceptions) {
/* 113 */     this.ognlUtil.setProperty(name, value, o, context, throwPropertyExceptions);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map getBeanMap(Object source) throws IntrospectionException, ReflectionException {
/*     */     try {
/* 119 */       return this.ognlUtil.getBeanMap(source);
/* 120 */     } catch (OgnlException e) {
/* 121 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(String expression, Map<String, Object> context, Object root) throws ReflectionException {
/*     */     try {
/* 128 */       return this.ognlUtil.getValue(expression, context, root);
/* 129 */     } catch (OgnlException e) {
/* 130 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(String expression, Map<String, Object> context, Object root, Object value) throws ReflectionException {
/*     */     try {
/* 137 */       Ognl.setValue(expression, context, root, value);
/* 138 */     } catch (OgnlException e) {
/* 139 */       throw new ReflectionException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors(Object source) throws IntrospectionException {
/* 145 */     return this.ognlUtil.getPropertyDescriptors(source);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\OgnlReflectionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */