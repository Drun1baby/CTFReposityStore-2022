/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionChainResult
/*     */   implements Result
/*     */ {
/*  86 */   private static final Logger LOG = LogManager.getLogger(ActionChainResult.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_PARAM = "actionName";
/*     */ 
/*     */   
/*     */   private static final String CHAIN_HISTORY = "CHAIN_HISTORY";
/*     */ 
/*     */   
/*     */   public static final String SKIP_ACTIONS_PARAM = "skipActions";
/*     */ 
/*     */   
/*     */   private ActionProxy proxy;
/*     */ 
/*     */   
/*     */   private String actionName;
/*     */ 
/*     */   
/*     */   private String namespace;
/*     */ 
/*     */   
/*     */   private String methodName;
/*     */ 
/*     */   
/*     */   private String skipActions;
/*     */ 
/*     */   
/*     */   private ActionProxyFactory actionProxyFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionChainResult() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionChainResult(String namespace, String actionName, String methodName) {
/* 123 */     this.namespace = namespace;
/* 124 */     this.actionName = actionName;
/* 125 */     this.methodName = methodName;
/*     */   }
/*     */   
/*     */   public ActionChainResult(String namespace, String actionName, String methodName, String skipActions) {
/* 129 */     this.namespace = namespace;
/* 130 */     this.actionName = actionName;
/* 131 */     this.methodName = methodName;
/* 132 */     this.skipActions = skipActions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   public void setActionProxyFactory(ActionProxyFactory actionProxyFactory) {
/* 141 */     this.actionProxyFactory = actionProxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActionName(String actionName) {
/* 150 */     this.actionName = actionName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespace(String namespace) {
/* 160 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSkipActions(String actions) {
/* 171 */     this.skipActions = actions;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMethod(String method) {
/* 176 */     this.methodName = method;
/*     */   }
/*     */   
/*     */   public ActionProxy getProxy() {
/* 180 */     return this.proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedList<String> getChainHistory() {
/* 190 */     LinkedList<String> chainHistory = (LinkedList<String>)ActionContext.getContext().get("CHAIN_HISTORY");
/*     */     
/* 192 */     if (chainHistory == null) {
/* 193 */       chainHistory = new LinkedList<>();
/* 194 */       ActionContext.getContext().put("CHAIN_HISTORY", chainHistory);
/*     */     } 
/*     */     
/* 197 */     return chainHistory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(ActionInvocation invocation) throws Exception {
/* 204 */     ValueStack stack = ActionContext.getContext().getValueStack();
/* 205 */     String finalNamespace = (this.namespace != null) ? TextParseUtil.translateVariables(this.namespace, stack) : invocation.getProxy().getNamespace();
/*     */ 
/*     */     
/* 208 */     String finalActionName = TextParseUtil.translateVariables(this.actionName, stack);
/* 209 */     String finalMethodName = (this.methodName != null) ? TextParseUtil.translateVariables(this.methodName, stack) : null;
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (isInChainHistory(finalNamespace, finalActionName, finalMethodName)) {
/* 214 */       addToHistory(finalNamespace, finalActionName, finalMethodName);
/* 215 */       throw new XWorkException("Infinite recursion detected: " + getChainHistory().toString());
/*     */     } 
/*     */     
/* 218 */     if (getChainHistory().isEmpty() && invocation != null && invocation.getProxy() != null) {
/* 219 */       addToHistory(finalNamespace, invocation.getProxy().getActionName(), invocation.getProxy().getMethod());
/*     */     }
/* 221 */     addToHistory(finalNamespace, finalActionName, finalMethodName);
/*     */     
/* 223 */     HashMap<String, Object> extraContext = new HashMap<>();
/* 224 */     extraContext.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", ActionContext.getContext().getValueStack());
/* 225 */     extraContext.put("com.opensymphony.xwork2.ActionContext.parameters", ActionContext.getContext().getParameters());
/* 226 */     extraContext.put("CHAIN_HISTORY", getChainHistory());
/*     */     
/* 228 */     LOG.debug("Chaining to action {}", finalActionName);
/*     */     
/* 230 */     this.proxy = this.actionProxyFactory.createActionProxy(finalNamespace, finalActionName, finalMethodName, extraContext);
/* 231 */     this.proxy.execute();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 235 */     if (this == o) return true; 
/* 236 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 238 */     ActionChainResult that = (ActionChainResult)o;
/*     */     
/* 240 */     if ((this.actionName != null) ? !this.actionName.equals(that.actionName) : (that.actionName != null)) return false; 
/* 241 */     if ((this.methodName != null) ? !this.methodName.equals(that.methodName) : (that.methodName != null)) return false; 
/* 242 */     if ((this.namespace != null) ? !this.namespace.equals(that.namespace) : (that.namespace != null)) return false;
/*     */     
/* 244 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 249 */     int result = (this.actionName != null) ? this.actionName.hashCode() : 0;
/* 250 */     result = 31 * result + ((this.namespace != null) ? this.namespace.hashCode() : 0);
/* 251 */     result = 31 * result + ((this.methodName != null) ? this.methodName.hashCode() : 0);
/* 252 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isInChainHistory(String namespace, String actionName, String methodName) {
/* 256 */     LinkedList<? extends String> chainHistory = getChainHistory();
/*     */     
/* 258 */     if (chainHistory == null) {
/* 259 */       return false;
/*     */     }
/*     */     
/* 262 */     Set<String> skipActionsList = new HashSet<>();
/* 263 */     if (this.skipActions != null && this.skipActions.length() > 0) {
/* 264 */       ValueStack stack = ActionContext.getContext().getValueStack();
/* 265 */       String finalSkipActions = TextParseUtil.translateVariables(this.skipActions, stack);
/* 266 */       skipActionsList.addAll(TextParseUtil.commaDelimitedStringToSet(finalSkipActions));
/*     */     } 
/* 268 */     if (!skipActionsList.contains(actionName))
/*     */     {
/* 270 */       return chainHistory.contains(makeKey(namespace, actionName, methodName));
/*     */     }
/*     */     
/* 273 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToHistory(String namespace, String actionName, String methodName) {
/* 278 */     List<String> chainHistory = getChainHistory();
/* 279 */     chainHistory.add(makeKey(namespace, actionName, methodName));
/*     */   }
/*     */   
/*     */   private String makeKey(String namespace, String actionName, String methodName) {
/* 283 */     if (null == methodName) {
/* 284 */       return namespace + "/" + actionName;
/*     */     }
/*     */     
/* 287 */     return namespace + "/" + actionName + "!" + methodName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ActionChainResult.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */