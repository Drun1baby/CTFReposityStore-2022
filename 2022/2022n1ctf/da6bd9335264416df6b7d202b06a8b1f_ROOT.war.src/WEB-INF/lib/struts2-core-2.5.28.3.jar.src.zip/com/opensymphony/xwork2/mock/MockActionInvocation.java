/*     */ package com.opensymphony.xwork2.mock;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionEventListener;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MockActionInvocation
/*     */   implements ActionInvocation
/*     */ {
/*     */   private Object action;
/*     */   private ActionContext invocationContext;
/*     */   private ActionEventListener actionEventListener;
/*     */   private ActionProxy proxy;
/*     */   private Result result;
/*     */   private String resultCode;
/*     */   private ValueStack stack;
/*  46 */   private List<PreResultListener> preResultListeners = new ArrayList<>();
/*     */   
/*     */   public Object getAction() {
/*  49 */     return this.action;
/*     */   }
/*     */   
/*     */   public void setAction(Object action) {
/*  53 */     this.action = action;
/*     */   }
/*     */   
/*     */   public ActionContext getInvocationContext() {
/*  57 */     return this.invocationContext;
/*     */   }
/*     */   
/*     */   public void setInvocationContext(ActionContext invocationContext) {
/*  61 */     this.invocationContext = invocationContext;
/*     */   }
/*     */   
/*     */   public ActionProxy getProxy() {
/*  65 */     return this.proxy;
/*     */   }
/*     */   
/*     */   public void setProxy(ActionProxy proxy) {
/*  69 */     this.proxy = proxy;
/*     */   }
/*     */   
/*     */   public Result getResult() {
/*  73 */     return this.result;
/*     */   }
/*     */   
/*     */   public void setResult(Result result) {
/*  77 */     this.result = result;
/*     */   }
/*     */   
/*     */   public String getResultCode() {
/*  81 */     return this.resultCode;
/*     */   }
/*     */   
/*     */   public void setResultCode(String resultCode) {
/*  85 */     this.resultCode = resultCode;
/*     */   }
/*     */   
/*     */   public ValueStack getStack() {
/*  89 */     return this.stack;
/*     */   }
/*     */   
/*     */   public void setStack(ValueStack stack) {
/*  93 */     this.stack = stack;
/*     */   }
/*     */   
/*     */   public boolean isExecuted() {
/*  97 */     return false;
/*     */   }
/*     */   
/*     */   public void addPreResultListener(PreResultListener listener) {
/* 101 */     this.preResultListeners.add(listener);
/*     */   }
/*     */   
/*     */   public String invoke() throws Exception {
/* 105 */     for (PreResultListener preResultListener : this.preResultListeners) {
/* 106 */       PreResultListener listener = preResultListener;
/* 107 */       listener.beforeResult(this, this.resultCode);
/*     */     } 
/* 109 */     return this.resultCode;
/*     */   }
/*     */   
/*     */   public String invokeActionOnly() throws Exception {
/* 113 */     return this.resultCode;
/*     */   }
/*     */   
/*     */   public void setActionEventListener(ActionEventListener listener) {
/* 117 */     this.actionEventListener = listener;
/*     */   }
/*     */   
/*     */   public ActionEventListener getActionEventListener() {
/* 121 */     return this.actionEventListener;
/*     */   }
/*     */   
/*     */   public void init(ActionProxy proxy) {}
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockActionInvocation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */