/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllowedMethods
/*     */ {
/*  31 */   private static final Logger LOG = LogManager.getLogger(AllowedMethods.class);
/*     */   
/*     */   private Set<AllowedMethod> allowedMethods;
/*     */   
/*     */   private final boolean strictMethodInvocation;
/*     */   private String defaultRegex;
/*     */   
/*     */   public static AllowedMethods build(boolean strictMethodInvocation, Set<String> methods, String defaultRegex) {
/*  39 */     Set<AllowedMethod> allowedMethods = new HashSet<>();
/*  40 */     for (String method : methods) {
/*  41 */       boolean isPattern = false;
/*  42 */       StringBuilder methodPattern = new StringBuilder();
/*  43 */       int len = method.length();
/*     */       
/*  45 */       for (int x = 0; x < len; x++) {
/*  46 */         char c = method.charAt(x);
/*  47 */         if (x < len - 2 && c == '{' && '}' == method.charAt(x + 2)) {
/*  48 */           methodPattern.append(defaultRegex);
/*  49 */           isPattern = true;
/*  50 */           x += 2;
/*     */         } else {
/*  52 */           methodPattern.append(c);
/*     */         } 
/*     */       } 
/*     */       
/*  56 */       if (isPattern && !method.startsWith("regex:") && !strictMethodInvocation) {
/*  57 */         allowedMethods.add(new PatternAllowedMethod(methodPattern.toString(), method)); continue;
/*  58 */       }  if (method.startsWith("regex:")) {
/*  59 */         String pattern = method.substring(method.indexOf(':') + 1);
/*  60 */         allowedMethods.add(new PatternAllowedMethod(pattern, method)); continue;
/*  61 */       }  if (method.contains("*") && !method.startsWith("regex:") && !strictMethodInvocation) {
/*  62 */         String pattern = method.replace("*", defaultRegex);
/*  63 */         allowedMethods.add(new PatternAllowedMethod(pattern, method)); continue;
/*  64 */       }  if (!isPattern) {
/*  65 */         allowedMethods.add(new LiteralAllowedMethod(method)); continue;
/*     */       } 
/*  67 */       LOG.trace("Ignoring method name: [{}] when SMI is set to [{}]", method, Boolean.valueOf(strictMethodInvocation));
/*     */     } 
/*     */ 
/*     */     
/*  71 */     LOG.debug("Defined allowed methods: {}", allowedMethods);
/*     */     
/*  73 */     return new AllowedMethods(strictMethodInvocation, allowedMethods, defaultRegex);
/*     */   }
/*     */   
/*     */   private AllowedMethods(boolean strictMethodInvocation, Set<AllowedMethod> methods, String defaultRegex) {
/*  77 */     this.strictMethodInvocation = strictMethodInvocation;
/*  78 */     this.defaultRegex = defaultRegex;
/*  79 */     this.allowedMethods = Collections.unmodifiableSet(methods);
/*     */   }
/*     */   
/*     */   public boolean isAllowed(String method) {
/*  83 */     for (AllowedMethod allowedMethod : this.allowedMethods) {
/*  84 */       if (allowedMethod.isAllowed(method)) {
/*  85 */         return true;
/*     */       }
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   public Set<String> list() {
/*  92 */     Set<String> result = new HashSet<>();
/*  93 */     for (AllowedMethod allowedMethod : this.allowedMethods) {
/*  94 */       result.add(allowedMethod.original());
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */   
/*     */   public String getDefaultRegex() {
/* 100 */     return this.defaultRegex;
/*     */   }
/*     */   
/*     */   public boolean isStrictMethodInvocation() {
/* 104 */     return this.strictMethodInvocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 109 */     if (this == o) return true; 
/* 110 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 112 */     AllowedMethods that = (AllowedMethods)o;
/*     */     
/* 114 */     return this.allowedMethods.equals(that.allowedMethods);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     return this.allowedMethods.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "allowedMethods=" + this.allowedMethods;
/*     */   }
/*     */   private static interface AllowedMethod {
/*     */     boolean isAllowed(String param1String);
/*     */     String original(); }
/*     */   
/*     */   private static class PatternAllowedMethod implements AllowedMethod { private final Pattern allowedMethodPattern;
/*     */     
/*     */     public PatternAllowedMethod(String pattern, String original) {
/* 139 */       this.original = original;
/* 140 */       this.allowedMethodPattern = Pattern.compile(pattern);
/*     */     }
/*     */     private String original;
/*     */     
/*     */     public boolean isAllowed(String methodName) {
/* 145 */       return this.allowedMethodPattern.matcher(methodName).matches();
/*     */     }
/*     */ 
/*     */     
/*     */     public String original() {
/* 150 */       return this.original;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 155 */       if (this == o) return true; 
/* 156 */       if (o == null || getClass() != o.getClass()) return false;
/*     */       
/* 158 */       PatternAllowedMethod that = (PatternAllowedMethod)o;
/*     */       
/* 160 */       return this.allowedMethodPattern.pattern().equals(that.allowedMethodPattern.pattern());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 166 */       return this.allowedMethodPattern.pattern().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 171 */       return "PatternAllowedMethod{allowedMethodPattern=" + this.allowedMethodPattern + ", original='" + this.original + '\'' + '}';
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LiteralAllowedMethod
/*     */     implements AllowedMethod
/*     */   {
/*     */     private String allowedMethod;
/*     */ 
/*     */     
/*     */     public LiteralAllowedMethod(String allowedMethod) {
/* 183 */       this.allowedMethod = allowedMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isAllowed(String methodName) {
/* 188 */       return methodName.equals(this.allowedMethod);
/*     */     }
/*     */ 
/*     */     
/*     */     public String original() {
/* 193 */       return this.allowedMethod;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 198 */       if (this == o) return true; 
/* 199 */       if (o == null || getClass() != o.getClass()) return false;
/*     */       
/* 201 */       LiteralAllowedMethod that = (LiteralAllowedMethod)o;
/*     */       
/* 203 */       return this.allowedMethod.equals(that.allowedMethod);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 209 */       return this.allowedMethod.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 214 */       return "LiteralAllowedMethod{allowedMethod='" + this.allowedMethod + '\'' + '}';
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\AllowedMethods.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */