package com.opensymphony.xwork2.config;

import com.opensymphony.xwork2.inject.ContainerBuilder;
import com.opensymphony.xwork2.util.location.LocatableProperties;

public interface ContainerProvider {
  void destroy();
  
  void init(Configuration paramConfiguration) throws ConfigurationException;
  
  boolean needsReload();
  
  void register(ContainerBuilder paramContainerBuilder, LocatableProperties paramLocatableProperties) throws ConfigurationException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\ContainerProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */