/*     */ package com.opensymphony.xwork2.mock;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MockActionProxy
/*     */   implements ActionProxy
/*     */ {
/*     */   Object action;
/*     */   String actionName;
/*     */   ActionConfig config;
/*     */   boolean executeResult;
/*     */   ActionInvocation invocation;
/*     */   String namespace;
/*     */   String method;
/*     */   boolean executedCalled;
/*     */   String returnedResult;
/*     */   Configuration configuration;
/*     */   boolean methodSpecified;
/*     */   
/*     */   public void prepare() throws Exception {}
/*     */   
/*     */   public String execute() throws Exception {
/*  49 */     this.executedCalled = true;
/*     */     
/*  51 */     return this.returnedResult;
/*     */   }
/*     */   
/*     */   public void setReturnedResult(String returnedResult) {
/*  55 */     this.returnedResult = returnedResult;
/*     */   }
/*     */   
/*     */   public boolean isExecutedCalled() {
/*  59 */     return this.executedCalled;
/*     */   }
/*     */   
/*     */   public Object getAction() {
/*  63 */     return this.action;
/*     */   }
/*     */   
/*     */   public void setAction(Object action) {
/*  67 */     this.action = action;
/*     */   }
/*     */   
/*     */   public String getActionName() {
/*  71 */     return this.actionName;
/*     */   }
/*     */   
/*     */   public void setActionName(String actionName) {
/*  75 */     this.actionName = actionName;
/*     */   }
/*     */   
/*     */   public ActionConfig getConfig() {
/*  79 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setConfig(ActionConfig config) {
/*  83 */     this.config = config;
/*     */   }
/*     */   
/*     */   public boolean getExecuteResult() {
/*  87 */     return this.executeResult;
/*     */   }
/*     */   
/*     */   public void setExecuteResult(boolean executeResult) {
/*  91 */     this.executeResult = executeResult;
/*     */   }
/*     */   
/*     */   public ActionInvocation getInvocation() {
/*  95 */     return this.invocation;
/*     */   }
/*     */   
/*     */   public void setInvocation(ActionInvocation invocation) {
/*  99 */     this.invocation = invocation;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 103 */     return this.namespace;
/*     */   }
/*     */   
/*     */   public void setNamespace(String namespace) {
/* 107 */     this.namespace = namespace;
/*     */   }
/*     */   
/*     */   public String getMethod() {
/* 111 */     return this.method;
/*     */   }
/*     */   
/*     */   public void setMethod(String method) {
/* 115 */     this.method = method;
/* 116 */     this.methodSpecified = StringUtils.isNotEmpty(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMethodSpecified() {
/* 121 */     return this.methodSpecified;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMethodSpecified(boolean methodSpecified) {
/* 126 */     this.methodSpecified = methodSpecified;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockActionProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */