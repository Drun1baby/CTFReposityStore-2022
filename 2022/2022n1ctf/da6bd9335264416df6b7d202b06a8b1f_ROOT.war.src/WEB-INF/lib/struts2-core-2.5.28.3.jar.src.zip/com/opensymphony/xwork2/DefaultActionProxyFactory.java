/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultActionProxyFactory
/*    */   implements ActionProxyFactory
/*    */ {
/*    */   protected Container container;
/*    */   
/*    */   @Inject
/*    */   public void setContainer(Container container) {
/* 41 */     this.container = container;
/*    */   }
/*    */   
/*    */   public ActionProxy createActionProxy(String namespace, String actionName, Map<String, Object> extraContext) {
/* 45 */     return createActionProxy(namespace, actionName, (String)null, extraContext, true, true);
/*    */   }
/*    */   
/*    */   public ActionProxy createActionProxy(String namespace, String actionName, String methodName, Map<String, Object> extraContext) {
/* 49 */     return createActionProxy(namespace, actionName, methodName, extraContext, true, true);
/*    */   }
/*    */   
/*    */   public ActionProxy createActionProxy(String namespace, String actionName, Map<String, Object> extraContext, boolean executeResult, boolean cleanupContext) {
/* 53 */     return createActionProxy(namespace, actionName, (String)null, extraContext, executeResult, cleanupContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public ActionProxy createActionProxy(String namespace, String actionName, String methodName, Map<String, Object> extraContext, boolean executeResult, boolean cleanupContext) {
/* 58 */     ActionInvocation inv = createActionInvocation(extraContext, true);
/* 59 */     this.container.inject(inv);
/* 60 */     return createActionProxy(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/*    */   }
/*    */   
/*    */   protected ActionInvocation createActionInvocation(Map<String, Object> extraContext, boolean pushAction) {
/* 64 */     return new DefaultActionInvocation(extraContext, pushAction);
/*    */   }
/*    */ 
/*    */   
/*    */   public ActionProxy createActionProxy(ActionInvocation inv, String namespace, String actionName, boolean executeResult, boolean cleanupContext) {
/* 69 */     return createActionProxy(inv, namespace, actionName, (String)null, executeResult, cleanupContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public ActionProxy createActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext) {
/* 74 */     DefaultActionProxy proxy = new DefaultActionProxy(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/* 75 */     this.container.inject(proxy);
/* 76 */     proxy.prepare();
/* 77 */     return proxy;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return getClass().getSimpleName();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultActionProxyFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */