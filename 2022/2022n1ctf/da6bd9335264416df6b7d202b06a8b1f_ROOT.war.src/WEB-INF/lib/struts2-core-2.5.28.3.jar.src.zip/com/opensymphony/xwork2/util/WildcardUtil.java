/*    */ package com.opensymphony.xwork2.util;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WildcardUtil
/*    */ {
/*    */   private static final String theSpecialRegexCharList = ".[]\\?*+{}|()^$";
/*    */   
/*    */   public static Pattern compileWildcardPattern(String pattern) {
/* 34 */     StringBuilder buf = new StringBuilder(pattern);
/*    */     
/* 36 */     for (int i = buf.length() - 1; i >= 0; i--) {
/*    */       
/* 38 */       char c = buf.charAt(i);
/* 39 */       if (c == '*' && (i == 0 || buf.charAt(i - 1) != '\\')) {
/*    */         
/* 41 */         buf.insert(i + 1, '?');
/* 42 */         buf.insert(i, '.');
/*    */       }
/* 44 */       else if (c == '*') {
/*    */         
/* 46 */         i--;
/*    */       }
/* 48 */       else if (needsBackslashToBeLiteralInRegex(c)) {
/*    */         
/* 50 */         buf.insert(i, '\\');
/*    */       } 
/*    */     } 
/*    */     
/* 54 */     return Pattern.compile(buf.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean needsBackslashToBeLiteralInRegex(char c) {
/* 68 */     return (".[]\\?*+{}|()^$".indexOf(c) >= 0);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\WildcardUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */