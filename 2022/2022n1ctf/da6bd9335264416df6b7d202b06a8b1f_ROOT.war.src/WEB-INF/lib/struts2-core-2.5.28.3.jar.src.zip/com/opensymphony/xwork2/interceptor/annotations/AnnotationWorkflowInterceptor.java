/*     */ package com.opensymphony.xwork2.interceptor.annotations;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.reflect.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationWorkflowInterceptor
/*     */   extends AbstractInterceptor
/*     */   implements PreResultListener
/*     */ {
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 116 */     Object action = invocation.getAction();
/* 117 */     invocation.addPreResultListener(this);
/* 118 */     List<Method> methods = new ArrayList<>(MethodUtils.getMethodsListWithAnnotation(action.getClass(), Before.class, true, true));
/*     */     
/* 120 */     if (methods.size() > 0) {
/*     */       
/* 122 */       Collections.sort(methods, new Comparator<Method>() {
/*     */             public int compare(Method method1, Method method2) {
/* 124 */               return AnnotationWorkflowInterceptor.comparePriorities(((Before)MethodUtils.getAnnotation(method1, Before.class, true, true)).priority(), ((Before)MethodUtils.getAnnotation(method2, Before.class, true, true)).priority());
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 129 */       for (Method m : methods) {
/* 130 */         String resultCode = (String)MethodUtils.invokeMethod(action, true, m.getName());
/* 131 */         if (resultCode != null)
/*     */         {
/* 133 */           return resultCode;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 138 */     String invocationResult = invocation.invoke();
/*     */ 
/*     */     
/* 141 */     methods = new ArrayList<>(MethodUtils.getMethodsListWithAnnotation(action.getClass(), After.class, true, true));
/*     */ 
/*     */     
/* 144 */     if (methods.size() > 0) {
/*     */       
/* 146 */       Collections.sort(methods, new Comparator<Method>() {
/*     */             public int compare(Method method1, Method method2) {
/* 148 */               return AnnotationWorkflowInterceptor.comparePriorities(((After)MethodUtils.getAnnotation(method1, After.class, true, true)).priority(), ((After)MethodUtils.getAnnotation(method2, After.class, true, true)).priority());
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 153 */       for (Method m : methods) {
/* 154 */         MethodUtils.invokeMethod(action, true, m.getName());
/*     */       }
/*     */     } 
/*     */     
/* 158 */     return invocationResult;
/*     */   }
/*     */   
/*     */   protected static int comparePriorities(int val1, int val2) {
/* 162 */     if (val2 < val1)
/* 163 */       return -1; 
/* 164 */     if (val2 > val1) {
/* 165 */       return 1;
/*     */     }
/* 167 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeResult(ActionInvocation invocation, String resultCode) {
/* 177 */     Object action = invocation.getAction();
/* 178 */     List<Method> methods = new ArrayList<>(MethodUtils.getMethodsListWithAnnotation(action.getClass(), BeforeResult.class, true, true));
/*     */ 
/*     */     
/* 181 */     if (methods.size() > 0) {
/*     */       
/* 183 */       Collections.sort(methods, new Comparator<Method>() {
/*     */             public int compare(Method method1, Method method2) {
/* 185 */               return AnnotationWorkflowInterceptor.comparePriorities(((BeforeResult)MethodUtils.getAnnotation(method1, BeforeResult.class, true, true)).priority(), ((BeforeResult)MethodUtils.getAnnotation(method2, BeforeResult.class, true, true)).priority());
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 190 */       for (Method m : methods) {
/*     */         try {
/* 192 */           MethodUtils.invokeMethod(action, true, m.getName());
/* 193 */         } catch (Exception e) {
/* 194 */           throw new XWorkException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\annotations\AnnotationWorkflowInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */