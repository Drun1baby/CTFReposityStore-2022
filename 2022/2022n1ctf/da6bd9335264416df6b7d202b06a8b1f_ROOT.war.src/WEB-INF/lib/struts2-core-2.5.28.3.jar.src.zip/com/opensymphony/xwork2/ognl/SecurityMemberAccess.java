/*     */ package com.opensymphony.xwork2.ognl;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ProxyUtil;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import ognl.DefaultMemberAccess;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityMemberAccess
/*     */   extends DefaultMemberAccess
/*     */ {
/*  39 */   private static final Logger LOG = LogManager.getLogger(SecurityMemberAccess.class);
/*     */   
/*     */   private final boolean allowStaticMethodAccess;
/*  42 */   private Set<Pattern> excludeProperties = Collections.emptySet();
/*  43 */   private Set<Pattern> acceptProperties = Collections.emptySet();
/*  44 */   private Set<Class<?>> excludedClasses = Collections.emptySet();
/*  45 */   private Set<Pattern> excludedPackageNamePatterns = Collections.emptySet();
/*  46 */   private Set<String> excludedPackageNames = Collections.emptySet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disallowProxyMemberAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityMemberAccess(boolean allowStaticMethodAccess) {
/*  57 */     super(false);
/*  58 */     this.allowStaticMethodAccess = allowStaticMethodAccess;
/*     */   }
/*     */   
/*     */   public boolean getAllowStaticMethodAccess() {
/*  62 */     return this.allowStaticMethodAccess;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAccessible(Map context, Object target, Member member, String propertyName) {
/*  67 */     LOG.debug("Checking access for [target: {}, member: {}, property: {}]", target, member, propertyName);
/*     */     
/*  69 */     Class<?> memberClass = member.getDeclaringClass();
/*  70 */     Class<?> targetClass = (target != null) ? target.getClass() : memberClass;
/*     */     
/*  72 */     if (checkEnumAccess(target, member)) {
/*  73 */       LOG.trace("Allowing access to enum: target class [{}] of target [{}], member [{}]", targetClass, target, member);
/*  74 */       return true;
/*     */     } 
/*     */     
/*  77 */     if (Modifier.isStatic(member.getModifiers()) && this.allowStaticMethodAccess) {
/*  78 */       LOG.debug("Support for accessing static methods [target: {}, targetClass: {}, member: {}, property: {}] is deprecated!", target, targetClass, member, propertyName);
/*     */       
/*  80 */       if (!isClassExcluded(memberClass)) {
/*  81 */         targetClass = memberClass;
/*     */       }
/*     */     } 
/*     */     
/*  85 */     if (isPackageExcluded(targetClass.getPackage(), memberClass.getPackage())) {
/*  86 */       LOG.warn("Package [{}] of target class [{}] of target [{}] or package [{}] of member [{}] are excluded!", targetClass.getPackage(), targetClass, target, memberClass.getPackage(), member);
/*     */       
/*  88 */       return false;
/*     */     } 
/*     */     
/*  91 */     if (isClassExcluded(targetClass)) {
/*  92 */       LOG.warn("Target class [{}] of target [{}] is excluded!", targetClass, target);
/*  93 */       return false;
/*     */     } 
/*     */     
/*  96 */     if (isClassExcluded(memberClass)) {
/*  97 */       LOG.warn("Declaring class of member type [{}] is excluded!", member);
/*  98 */       return false;
/*     */     } 
/*     */     
/* 101 */     if (this.disallowProxyMemberAccess && ProxyUtil.isProxyMember(member, target)) {
/* 102 */       LOG.warn("Access to proxy is blocked! Target class [{}] of target [{}], member [{}]", targetClass, target, member);
/* 103 */       return false;
/*     */     } 
/*     */     
/* 106 */     boolean allow = true;
/* 107 */     if (!checkStaticMethodAccess(member)) {
/* 108 */       LOG.warn("Access to static [{}] is blocked!", member);
/* 109 */       allow = false;
/*     */     } 
/*     */ 
/*     */     
/* 113 */     if (!allow) {
/* 114 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 118 */     return (super.isAccessible(context, target, member, propertyName) && isAcceptableProperty(propertyName));
/*     */   }
/*     */   
/*     */   protected boolean checkStaticMethodAccess(Member member) {
/* 122 */     int modifiers = member.getModifiers();
/* 123 */     if (Modifier.isStatic(modifiers)) {
/* 124 */       return this.allowStaticMethodAccess;
/*     */     }
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkEnumAccess(Object target, Member member) {
/* 131 */     if (target instanceof Class) {
/* 132 */       Class<?> clazz = (Class)target;
/* 133 */       if (Enum.class.isAssignableFrom(clazz) && member.getName().equals("values")) {
/* 134 */         return true;
/*     */       }
/*     */     } 
/* 137 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isPackageExcluded(Package targetPackage, Package memberPackage) {
/* 141 */     if (targetPackage == null || memberPackage == null) {
/* 142 */       LOG.warn("The use of the default (unnamed) package is discouraged!");
/*     */     }
/*     */     
/* 145 */     String targetPackageName = (targetPackage == null) ? "" : targetPackage.getName();
/* 146 */     String memberPackageName = (memberPackage == null) ? "" : memberPackage.getName();
/*     */     
/* 148 */     for (Pattern pattern : this.excludedPackageNamePatterns) {
/* 149 */       if (pattern.matcher(targetPackageName).matches() || pattern.matcher(memberPackageName).matches()) {
/* 150 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 154 */     targetPackageName = targetPackageName + ".";
/* 155 */     memberPackageName = memberPackageName + ".";
/*     */     
/* 157 */     for (String packageName : this.excludedPackageNames) {
/* 158 */       if (targetPackageName.startsWith(packageName) || memberPackageName.startsWith(packageName)) {
/* 159 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isClassExcluded(Class<?> clazz) {
/* 167 */     if (clazz == Object.class || (clazz == Class.class && !this.allowStaticMethodAccess)) {
/* 168 */       return true;
/*     */     }
/* 170 */     for (Class<?> excludedClass : this.excludedClasses) {
/* 171 */       if (clazz.isAssignableFrom(excludedClass)) {
/* 172 */         return true;
/*     */       }
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isAcceptableProperty(String name) {
/* 179 */     return (name == null || (!isExcluded(name) && isAccepted(name)));
/*     */   }
/*     */   
/*     */   protected boolean isAccepted(String paramName) {
/* 183 */     if (!this.acceptProperties.isEmpty()) {
/* 184 */       for (Pattern pattern : this.acceptProperties) {
/* 185 */         Matcher matcher = pattern.matcher(paramName);
/* 186 */         if (matcher.matches()) {
/* 187 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 192 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 196 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean isExcluded(String paramName) {
/* 200 */     if (!this.excludeProperties.isEmpty()) {
/* 201 */       for (Pattern pattern : this.excludeProperties) {
/* 202 */         Matcher matcher = pattern.matcher(paramName);
/* 203 */         if (matcher.matches()) {
/* 204 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 208 */     return false;
/*     */   }
/*     */   
/*     */   public void setExcludeProperties(Set<Pattern> excludeProperties) {
/* 212 */     this.excludeProperties = excludeProperties;
/*     */   }
/*     */   
/*     */   public void setAcceptProperties(Set<Pattern> acceptedProperties) {
/* 216 */     this.acceptProperties = acceptedProperties;
/*     */   }
/*     */   
/*     */   public void setExcludedClasses(Set<Class<?>> excludedClasses) {
/* 220 */     this.excludedClasses = excludedClasses;
/*     */   }
/*     */   
/*     */   public void setExcludedPackageNamePatterns(Set<Pattern> excludedPackageNamePatterns) {
/* 224 */     this.excludedPackageNamePatterns = excludedPackageNamePatterns;
/*     */   }
/*     */   
/*     */   public void setExcludedPackageNames(Set<String> excludedPackageNames) {
/* 228 */     this.excludedPackageNames = excludedPackageNames;
/*     */   }
/*     */   
/*     */   public void setDisallowProxyMemberAccess(boolean disallowProxyMemberAccess) {
/* 232 */     this.disallowProxyMemberAccess = disallowProxyMemberAccess;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\SecurityMemberAccess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */