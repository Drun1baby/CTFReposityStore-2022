/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.CreateIfNull;
/*     */ import com.opensymphony.xwork2.util.Element;
/*     */ import com.opensymphony.xwork2.util.Key;
/*     */ import com.opensymphony.xwork2.util.KeyProperty;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultObjectTypeDeterminer
/*     */   implements ObjectTypeDeterminer
/*     */ {
/*  59 */   protected static final Logger LOG = LogManager.getLogger(DefaultObjectTypeDeterminer.class);
/*     */   
/*     */   public static final String KEY_PREFIX = "Key_";
/*     */   
/*     */   public static final String ELEMENT_PREFIX = "Element_";
/*     */   public static final String KEY_PROPERTY_PREFIX = "KeyProperty_";
/*     */   public static final String CREATE_IF_NULL_PREFIX = "CreateIfNull_";
/*     */   public static final String DEPRECATED_ELEMENT_PREFIX = "Collection_";
/*     */   private ReflectionProvider reflectionProvider;
/*     */   private XWorkConverter xworkConverter;
/*     */   
/*     */   @Inject
/*     */   public DefaultObjectTypeDeterminer(@Inject XWorkConverter converter, @Inject ReflectionProvider provider) {
/*  72 */     this.reflectionProvider = provider;
/*  73 */     this.xworkConverter = converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getKeyClass(Class parentClass, String property) {
/*  88 */     Key annotation = getAnnotation(parentClass, property, Key.class);
/*  89 */     if (annotation != null) {
/*  90 */       return annotation.value();
/*     */     }
/*  92 */     Class clazz = getClass(parentClass, property, false);
/*  93 */     if (clazz != null) {
/*  94 */       return clazz;
/*     */     }
/*  96 */     return (Class)this.xworkConverter.getConverter(parentClass, "Key_" + property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getElementClass(Class parentClass, String property, Object key) {
/* 112 */     Element annotation = getAnnotation(parentClass, property, Element.class);
/* 113 */     if (annotation != null) {
/* 114 */       return annotation.value();
/*     */     }
/* 116 */     Class clazz = getClass(parentClass, property, true);
/* 117 */     if (clazz != null) {
/* 118 */       return clazz;
/*     */     }
/* 120 */     clazz = (Class)this.xworkConverter.getConverter(parentClass, "Element_" + property);
/* 121 */     if (clazz == null) {
/* 122 */       clazz = (Class)this.xworkConverter.getConverter(parentClass, "Collection_" + property);
/* 123 */       if (clazz != null) {
/* 124 */         LOG.info("The Collection_xxx pattern for collection type conversion is deprecated. Please use Element_xxx!");
/*     */       }
/*     */     } 
/* 127 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyProperty(Class parentClass, String property) {
/* 141 */     KeyProperty annotation = getAnnotation(parentClass, property, KeyProperty.class);
/* 142 */     if (annotation != null) {
/* 143 */       return annotation.value();
/*     */     }
/* 145 */     return (String)this.xworkConverter.getConverter(parentClass, "KeyProperty_" + property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldCreateIfNew(Class parentClass, String property, Object target, String keyProperty, boolean isIndexAccessed) {
/* 163 */     CreateIfNull annotation = getAnnotation(parentClass, property, CreateIfNull.class);
/* 164 */     if (annotation != null) {
/* 165 */       return annotation.value();
/*     */     }
/* 167 */     String configValue = (String)this.xworkConverter.getConverter(parentClass, "CreateIfNull_" + property);
/*     */     
/* 169 */     if (configValue != null) {
/* 170 */       return BooleanUtils.toBoolean(configValue);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     return (target instanceof Map || isIndexAccessed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends java.lang.annotation.Annotation> T getAnnotation(Class parentClass, String property, Class<T> annotationClass) {
/* 189 */     T annotation = null;
/* 190 */     Field field = this.reflectionProvider.getField(parentClass, property);
/*     */     
/* 192 */     if (field != null) {
/* 193 */       annotation = field.getAnnotation(annotationClass);
/*     */     }
/* 195 */     if (annotation == null) {
/* 196 */       annotation = getAnnotationFromSetter(parentClass, property, annotationClass);
/*     */     }
/* 198 */     if (annotation == null) {
/* 199 */       annotation = getAnnotationFromGetter(parentClass, property, annotationClass);
/*     */     }
/*     */     
/* 202 */     return annotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends java.lang.annotation.Annotation> T getAnnotationFromGetter(Class parentClass, String property, Class<T> annotationClass) {
/*     */     try {
/* 215 */       Method getter = this.reflectionProvider.getGetMethod(parentClass, property);
/*     */       
/* 217 */       if (getter != null) {
/* 218 */         return getter.getAnnotation(annotationClass);
/*     */       }
/* 220 */     } catch (ReflectionException|java.beans.IntrospectionException reflectionException) {}
/*     */ 
/*     */     
/* 223 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends java.lang.annotation.Annotation> T getAnnotationFromSetter(Class parentClass, String property, Class<T> annotationClass) {
/*     */     try {
/* 236 */       Method setter = this.reflectionProvider.getSetMethod(parentClass, property);
/*     */       
/* 238 */       if (setter != null) {
/* 239 */         return setter.getAnnotation(annotationClass);
/*     */       }
/* 241 */     } catch (ReflectionException|java.beans.IntrospectionException reflectionException) {}
/*     */ 
/*     */     
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getClass(Class parentClass, String property, boolean element) {
/*     */     try {
/* 257 */       Field field = this.reflectionProvider.getField(parentClass, property);
/* 258 */       Type genericType = null;
/*     */       
/* 260 */       if (field != null) {
/* 261 */         genericType = field.getGenericType();
/*     */       }
/*     */       
/* 264 */       if (genericType == null || !(genericType instanceof ParameterizedType)) {
/*     */         try {
/* 266 */           Method setter = this.reflectionProvider.getSetMethod(parentClass, property);
/* 267 */           genericType = (setter != null) ? setter.getGenericParameterTypes()[0] : null;
/* 268 */         } catch (ReflectionException|java.beans.IntrospectionException reflectionException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       if (genericType == null || !(genericType instanceof ParameterizedType)) {
/*     */         try {
/* 276 */           Method getter = this.reflectionProvider.getGetMethod(parentClass, property);
/* 277 */           genericType = getter.getGenericReturnType();
/* 278 */         } catch (ReflectionException|java.beans.IntrospectionException reflectionException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 283 */       if (genericType instanceof ParameterizedType) {
/* 284 */         ParameterizedType type = (ParameterizedType)genericType;
/* 285 */         int index = (element && type.getRawType().toString().contains(Map.class.getName())) ? 1 : 0;
/* 286 */         Type resultType = type.getActualTypeArguments()[index];
/* 287 */         if (resultType instanceof ParameterizedType) {
/* 288 */           return (Class)((ParameterizedType)resultType).getRawType();
/*     */         }
/* 290 */         return (Class)resultType;
/*     */       } 
/* 292 */     } catch (Exception e) {
/* 293 */       LOG.debug("Error while retrieving generic property class for property: {}", property, e);
/*     */     } 
/* 295 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultObjectTypeDeterminer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */