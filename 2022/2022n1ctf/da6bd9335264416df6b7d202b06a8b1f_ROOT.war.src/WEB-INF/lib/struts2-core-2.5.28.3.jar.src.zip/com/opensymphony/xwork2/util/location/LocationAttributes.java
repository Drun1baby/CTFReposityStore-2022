/*     */ package com.opensymphony.xwork2.util.location;
/*     */ 
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationAttributes
/*     */ {
/*     */   public static final String PREFIX = "loc";
/*     */   public static final String URI = "http://struts.apache.org/xwork/location";
/*     */   public static final String SRC_ATTR = "src";
/*     */   public static final String LINE_ATTR = "line";
/*     */   public static final String COL_ATTR = "column";
/*     */   public static final String Q_SRC_ATTR = "loc:src";
/*     */   public static final String Q_LINE_ATTR = "loc:line";
/*     */   public static final String Q_COL_ATTR = "loc:column";
/*     */   
/*     */   public static Attributes addLocationAttributes(Locator locator, Attributes attrs) {
/*  82 */     if (locator == null || attrs.getIndex("http://struts.apache.org/xwork/location", "src") != -1)
/*     */     {
/*  84 */       return attrs;
/*     */     }
/*     */ 
/*     */     
/*  88 */     AttributesImpl newAttrs = (attrs instanceof AttributesImpl) ? (AttributesImpl)attrs : new AttributesImpl(attrs);
/*     */ 
/*     */     
/*  91 */     newAttrs.addAttribute("http://struts.apache.org/xwork/location", "src", "loc:src", "CDATA", locator.getSystemId());
/*  92 */     newAttrs.addAttribute("http://struts.apache.org/xwork/location", "line", "loc:line", "CDATA", Integer.toString(locator.getLineNumber()));
/*  93 */     newAttrs.addAttribute("http://struts.apache.org/xwork/location", "column", "loc:column", "CDATA", Integer.toString(locator.getColumnNumber()));
/*     */     
/*  95 */     return newAttrs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getLocation(Attributes attrs, String description) {
/* 106 */     String src = attrs.getValue("http://struts.apache.org/xwork/location", "src");
/* 107 */     if (src == null) {
/* 108 */       return Location.UNKNOWN;
/*     */     }
/*     */     
/* 111 */     return new LocationImpl(description, src, getLine(attrs), getColumn(attrs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocationString(Attributes attrs) {
/* 123 */     String src = attrs.getValue("http://struts.apache.org/xwork/location", "src");
/* 124 */     if (src == null) {
/* 125 */       return "[unknown location]";
/*     */     }
/*     */     
/* 128 */     return src + ":" + attrs.getValue("http://struts.apache.org/xwork/location", "line") + ":" + attrs.getValue("http://struts.apache.org/xwork/location", "column");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getURI(Attributes attrs) {
/* 139 */     String src = attrs.getValue("http://struts.apache.org/xwork/location", "src");
/* 140 */     return (src != null) ? src : "[unknown location]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getLine(Attributes attrs) {
/* 151 */     String line = attrs.getValue("http://struts.apache.org/xwork/location", "line");
/* 152 */     return (line != null) ? Integer.parseInt(line) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getColumn(Attributes attrs) {
/* 163 */     String col = attrs.getValue("http://struts.apache.org/xwork/location", "column");
/* 164 */     return (col != null) ? Integer.parseInt(col) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getLocation(Element elem, String description) {
/* 175 */     Attr srcAttr = elem.getAttributeNodeNS("http://struts.apache.org/xwork/location", "src");
/* 176 */     if (srcAttr == null) {
/* 177 */       return Location.UNKNOWN;
/*     */     }
/*     */     
/* 180 */     return new LocationImpl((description == null) ? elem.getNodeName() : description, srcAttr.getValue(), getLine(elem), getColumn(elem));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getLocation(Element elem) {
/* 191 */     return getLocation(elem, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLocationString(Element elem) {
/* 204 */     Attr srcAttr = elem.getAttributeNodeNS("http://struts.apache.org/xwork/location", "src");
/* 205 */     if (srcAttr == null) {
/* 206 */       return "[unknown location]";
/*     */     }
/*     */     
/* 209 */     return srcAttr.getValue() + ":" + elem.getAttributeNS("http://struts.apache.org/xwork/location", "line") + ":" + elem.getAttributeNS("http://struts.apache.org/xwork/location", "column");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getURI(Element elem) {
/* 220 */     Attr attr = elem.getAttributeNodeNS("http://struts.apache.org/xwork/location", "src");
/* 221 */     return (attr != null) ? attr.getValue() : "[unknown location]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getLine(Element elem) {
/* 232 */     Attr attr = elem.getAttributeNodeNS("http://struts.apache.org/xwork/location", "line");
/* 233 */     return (attr != null) ? Integer.parseInt(attr.getValue()) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getColumn(Element elem) {
/* 244 */     Attr attr = elem.getAttributeNodeNS("http://struts.apache.org/xwork/location", "column");
/* 245 */     return (attr != null) ? Integer.parseInt(attr.getValue()) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(Element elem, boolean recurse) {
/* 255 */     elem.removeAttributeNS("http://struts.apache.org/xwork/location", "src");
/* 256 */     elem.removeAttributeNS("http://struts.apache.org/xwork/location", "line");
/* 257 */     elem.removeAttributeNS("http://struts.apache.org/xwork/location", "column");
/* 258 */     if (recurse) {
/* 259 */       NodeList children = elem.getChildNodes();
/* 260 */       for (int i = 0; i < children.getLength(); i++) {
/* 261 */         Node child = children.item(i);
/* 262 */         if (child.getNodeType() == 1) {
/* 263 */           remove((Element)child, recurse);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pipe
/*     */     implements ContentHandler
/*     */   {
/*     */     private Locator locator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ContentHandler nextHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pipe() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Pipe(ContentHandler next) {
/* 305 */       this.nextHandler = next;
/*     */     }
/*     */     
/*     */     public void setDocumentLocator(Locator locator) {
/* 309 */       this.locator = locator;
/* 310 */       this.nextHandler.setDocumentLocator(locator);
/*     */     }
/*     */     
/*     */     public void startDocument() throws SAXException {
/* 314 */       this.nextHandler.startDocument();
/* 315 */       this.nextHandler.startPrefixMapping("loc", "http://struts.apache.org/xwork/location");
/*     */     }
/*     */     
/*     */     public void endDocument() throws SAXException {
/* 319 */       endPrefixMapping("loc");
/* 320 */       this.nextHandler.endDocument();
/*     */     }
/*     */ 
/*     */     
/*     */     public void startElement(String uri, String loc, String raw, Attributes attrs) throws SAXException {
/* 325 */       this.nextHandler.startElement(uri, loc, raw, LocationAttributes.addLocationAttributes(this.locator, attrs));
/*     */     }
/*     */     
/*     */     public void endElement(String arg0, String arg1, String arg2) throws SAXException {
/* 329 */       this.nextHandler.endElement(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void startPrefixMapping(String arg0, String arg1) throws SAXException {
/* 333 */       this.nextHandler.startPrefixMapping(arg0, arg1);
/*     */     }
/*     */     
/*     */     public void endPrefixMapping(String arg0) throws SAXException {
/* 337 */       this.nextHandler.endPrefixMapping(arg0);
/*     */     }
/*     */     
/*     */     public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
/* 341 */       this.nextHandler.characters(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void ignorableWhitespace(char[] arg0, int arg1, int arg2) throws SAXException {
/* 345 */       this.nextHandler.ignorableWhitespace(arg0, arg1, arg2);
/*     */     }
/*     */     
/*     */     public void processingInstruction(String arg0, String arg1) throws SAXException {
/* 349 */       this.nextHandler.processingInstruction(arg0, arg1);
/*     */     }
/*     */     
/*     */     public void skippedEntity(String arg0) throws SAXException {
/* 353 */       this.nextHandler.skippedEntity(arg0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\location\LocationAttributes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */