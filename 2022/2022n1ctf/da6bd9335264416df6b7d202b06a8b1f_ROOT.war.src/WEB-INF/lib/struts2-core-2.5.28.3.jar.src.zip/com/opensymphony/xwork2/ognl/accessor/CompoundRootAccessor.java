/*     */ package com.opensymphony.xwork2.ognl.accessor;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.OgnlValueStack;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import ognl.ClassResolver;
/*     */ import ognl.MethodAccessor;
/*     */ import ognl.MethodFailedException;
/*     */ import ognl.NoSuchPropertyException;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.PropertyAccessor;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundRootAccessor
/*     */   implements PropertyAccessor, MethodAccessor, ClassResolver
/*     */ {
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/*  60 */     return null;
/*     */   }
/*     */   
/*  63 */   private static final Logger LOG = LogManager.getLogger(CompoundRootAccessor.class);
/*  64 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*  65 */   private static Map<MethodCall, Boolean> invalidMethods = new ConcurrentHashMap<>();
/*     */   private boolean devMode;
/*     */   
/*     */   @Inject("devMode")
/*     */   protected void setDevMode(String mode) {
/*  70 */     this.devMode = BooleanUtils.toBoolean(mode);
/*     */   }
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/*  74 */     CompoundRoot root = (CompoundRoot)target;
/*  75 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     
/*  77 */     for (Object o : root) {
/*  78 */       if (o == null) {
/*     */         continue;
/*     */       }
/*     */       
/*     */       try {
/*  83 */         if (OgnlRuntime.hasSetProperty(ognlContext, o, name)) {
/*  84 */           OgnlRuntime.setProperty(ognlContext, o, name, value);
/*     */           return;
/*     */         } 
/*  87 */         if (o instanceof Map)
/*     */         {
/*  89 */           Map<Object, Object> map = (Map<Object, Object>)o;
/*     */           try {
/*  91 */             map.put(name, value);
/*     */             return;
/*  93 */           } catch (UnsupportedOperationException unsupportedOperationException) {}
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 103 */       catch (IntrospectionException introspectionException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 108 */     boolean reportError = BooleanUtils.toBoolean((Boolean)context.get("com.opensymphony.xwork2.util.ValueStack.ReportErrorsOnNoProp"));
/*     */     
/* 110 */     if (reportError || this.devMode) {
/* 111 */       String msg = String.format("No object in the CompoundRoot has a publicly accessible property named '%s' (no setter could be found).", new Object[] { name });
/*     */       
/* 113 */       if (reportError) {
/* 114 */         throw new XWorkException(msg);
/*     */       }
/* 116 */       LOG.warn(msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/* 122 */     CompoundRoot root = (CompoundRoot)target;
/* 123 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     
/* 125 */     if (name instanceof Integer) {
/* 126 */       Integer index = (Integer)name;
/* 127 */       return root.cutStack(index.intValue());
/* 128 */     }  if (name instanceof String) {
/* 129 */       if ("top".equals(name)) {
/* 130 */         if (root.size() > 0) {
/* 131 */           return root.get(0);
/*     */         }
/* 133 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 137 */       for (Object o : root) {
/* 138 */         if (o == null) {
/*     */           continue;
/*     */         }
/*     */         
/*     */         try {
/* 143 */           if (OgnlRuntime.hasGetProperty(ognlContext, o, name) || (o instanceof Map && ((Map)o).containsKey(name))) {
/* 144 */             return OgnlRuntime.getProperty(ognlContext, o, name);
/*     */           }
/* 146 */         } catch (OgnlException e) {
/* 147 */           if (e.getReason() != null) {
/* 148 */             String msg = "Caught an Ognl exception while getting property " + name;
/* 149 */             throw new XWorkException(msg, e);
/*     */           } 
/* 151 */         } catch (IntrospectionException introspectionException) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       if (context.containsKey(OgnlValueStack.THROW_EXCEPTION_ON_FAILURE)) {
/* 158 */         throw new NoSuchPropertyException(target, name);
/*     */       }
/* 160 */       return null;
/*     */     } 
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object callMethod(Map context, Object target, String name, Object[] objects) throws MethodFailedException {
/* 167 */     CompoundRoot root = (CompoundRoot)target;
/*     */     
/* 169 */     if ("describe".equals(name)) {
/*     */       Object v;
/* 171 */       if (objects != null && objects.length == 1) {
/* 172 */         v = objects[0];
/*     */       } else {
/* 174 */         v = root.get(0);
/*     */       } 
/*     */ 
/*     */       
/* 178 */       if (v instanceof java.util.Collection || v instanceof Map || v.getClass().isArray()) {
/* 179 */         return v.toString();
/*     */       }
/*     */       
/*     */       try {
/* 183 */         Map<String, PropertyDescriptor> descriptors = OgnlRuntime.getPropertyDescriptors(v.getClass());
/*     */         
/* 185 */         int maxSize = 0;
/* 186 */         for (String pdName : descriptors.keySet()) {
/* 187 */           if (pdName.length() > maxSize) {
/* 188 */             maxSize = pdName.length();
/*     */           }
/*     */         } 
/*     */         
/* 192 */         SortedSet<String> set = new TreeSet<>();
/* 193 */         StringBuffer sb = new StringBuffer();
/* 194 */         for (PropertyDescriptor pd : descriptors.values()) {
/*     */           
/* 196 */           sb.append(pd.getName()).append(": ");
/* 197 */           int padding = maxSize - pd.getName().length();
/* 198 */           for (int i = 0; i < padding; i++) {
/* 199 */             sb.append(" ");
/*     */           }
/* 201 */           sb.append(pd.getPropertyType().getName());
/* 202 */           set.add(sb.toString());
/*     */           
/* 204 */           sb = new StringBuffer();
/*     */         } 
/*     */         
/* 207 */         sb = new StringBuffer();
/* 208 */         for (String aSet : set) {
/* 209 */           String s = aSet;
/* 210 */           sb.append(s).append("\n");
/*     */         } 
/*     */         
/* 213 */         return sb.toString();
/* 214 */       } catch (IntrospectionException|OgnlException e) {
/* 215 */         LOG.debug("Got exception in callMethod", e);
/*     */         
/* 217 */         return null;
/*     */       } 
/*     */     } 
/* 220 */     Throwable reason = null;
/* 221 */     Class[] argTypes = getArgTypes(objects);
/* 222 */     for (Object o : root) {
/* 223 */       if (o == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 227 */       Class<?> clazz = o.getClass();
/*     */       
/* 229 */       MethodCall mc = null;
/*     */       
/* 231 */       if (argTypes != null) {
/* 232 */         mc = new MethodCall(clazz, name, argTypes);
/*     */       }
/*     */       
/* 235 */       if (argTypes == null || !invalidMethods.containsKey(mc)) {
/*     */         try {
/* 237 */           return OgnlRuntime.callMethod((OgnlContext)context, o, name, objects);
/* 238 */         } catch (OgnlException e) {
/* 239 */           reason = e.getReason();
/*     */           
/* 241 */           if (reason != null && !(reason instanceof NoSuchMethodException)) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 246 */           if (mc != null && reason != null) {
/* 247 */             invalidMethods.put(mc, Boolean.TRUE);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 254 */     if (context.containsKey(OgnlValueStack.THROW_EXCEPTION_ON_FAILURE)) {
/* 255 */       throw new MethodFailedException(target, name, reason);
/*     */     }
/*     */     
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   public Object callStaticMethod(Map transientVars, Class aClass, String s, Object[] objects) throws MethodFailedException {
/* 262 */     return null;
/*     */   }
/*     */   
/*     */   public Class classForName(String className, Map context) throws ClassNotFoundException {
/* 266 */     Object root = Ognl.getRoot(context);
/*     */     
/*     */     try {
/* 269 */       if (root instanceof CompoundRoot && 
/* 270 */         className.startsWith("vs")) {
/* 271 */         CompoundRoot compoundRoot = (CompoundRoot)root;
/*     */         
/* 273 */         if ("vs".equals(className)) {
/* 274 */           return compoundRoot.peek().getClass();
/*     */         }
/*     */         
/* 277 */         int index = Integer.parseInt(className.substring(2));
/*     */         
/* 279 */         return compoundRoot.get(index - 1).getClass();
/*     */       }
/*     */     
/* 282 */     } catch (Exception e) {
/* 283 */       LOG.debug("Got exception when tried to get class for name [{}]", className, e);
/*     */     } 
/*     */     
/* 286 */     return Thread.currentThread().getContextClassLoader().loadClass(className);
/*     */   }
/*     */   
/*     */   private Class[] getArgTypes(Object[] args) {
/* 290 */     if (args == null) {
/* 291 */       return EMPTY_CLASS_ARRAY;
/*     */     }
/*     */     
/* 294 */     Class[] classes = new Class[args.length];
/*     */     
/* 296 */     for (int i = 0; i < args.length; i++) {
/* 297 */       Object arg = args[i];
/* 298 */       classes[i] = (arg != null) ? arg.getClass() : Object.class;
/*     */     } 
/*     */     
/* 301 */     return classes;
/*     */   }
/*     */   
/*     */   static class MethodCall
/*     */   {
/*     */     Class clazz;
/*     */     String name;
/*     */     Class[] args;
/*     */     int hash;
/*     */     
/*     */     public MethodCall(Class clazz, String name, Class[] args) {
/* 312 */       this.clazz = clazz;
/* 313 */       this.name = name;
/* 314 */       this.args = args;
/* 315 */       this.hash = clazz.hashCode() + name.hashCode();
/*     */       
/* 317 */       for (Class arg : args) {
/* 318 */         this.hash += arg.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 324 */       MethodCall mc = (MethodCall)obj;
/*     */       
/* 326 */       return (mc.clazz.equals(this.clazz) && mc.name.equals(this.name) && Arrays.equals((Object[])mc.args, (Object[])this.args));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 331 */       return this.hash;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\CompoundRootAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */