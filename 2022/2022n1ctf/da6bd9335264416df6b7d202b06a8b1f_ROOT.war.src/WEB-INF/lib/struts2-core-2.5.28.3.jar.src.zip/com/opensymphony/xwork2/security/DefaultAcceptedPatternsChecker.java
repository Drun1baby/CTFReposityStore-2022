/*     */ package com.opensymphony.xwork2.security;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAcceptedPatternsChecker
/*     */   implements AcceptedPatternsChecker
/*     */ {
/*  37 */   private static final Logger LOG = LogManager.getLogger(DefaultAcceptedPatternsChecker.class);
/*     */   
/*  39 */   public static final String[] ACCEPTED_PATTERNS = new String[] { "\\w+((\\.\\w+)|(\\[\\d+])|(\\(\\d+\\))|(\\['(\\w|[\\u4e00-\\u9fa5])+'])|(\\('(\\w|[\\u4e00-\\u9fa5])+'\\)))*" };
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final String[] DMI_AWARE_ACCEPTED_PATTERNS = new String[] { "\\w+([:]?\\w+)?((\\.\\w+)|(\\[\\d+])|(\\(\\d+\\))|(\\['(\\w|[\\u4e00-\\u9fa5])+'])|(\\('(\\w|[\\u4e00-\\u9fa5])+'\\)))*([!]?\\w+)?" };
/*     */ 
/*     */   
/*     */   private Set<Pattern> acceptedPatterns;
/*     */ 
/*     */   
/*     */   public DefaultAcceptedPatternsChecker() {
/*  50 */     setAcceptedPatterns(ACCEPTED_PATTERNS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultAcceptedPatternsChecker(@Inject(value = "struts.enable.DynamicMethodInvocation", required = false) String dmiValue) {
/*  56 */     if (BooleanUtils.toBoolean(dmiValue)) {
/*  57 */       LOG.debug("DMI is enabled, adding DMI related accepted patterns");
/*  58 */       setAcceptedPatterns(DMI_AWARE_ACCEPTED_PATTERNS);
/*     */     } else {
/*  60 */       setAcceptedPatterns(ACCEPTED_PATTERNS);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(value = "overrideAcceptedPatterns", required = false)
/*     */   protected void setOverrideAcceptedPatterns(String acceptablePatterns) {
/*  66 */     LOG.warn("Overriding accepted patterns [{}] with [{}], be aware that this affects all instances and safety of your application!", this.acceptedPatterns, acceptablePatterns);
/*     */     
/*  68 */     this.acceptedPatterns = new HashSet<>();
/*     */     try {
/*  70 */       for (String pattern : TextParseUtil.commaDelimitedStringToSet(acceptablePatterns)) {
/*  71 */         this.acceptedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/*  74 */       this.acceptedPatterns = Collections.unmodifiableSet(this.acceptedPatterns);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(value = "additionalAcceptedPatterns", required = false)
/*     */   protected void setAdditionalAcceptedPatterns(String acceptablePatterns) {
/*  80 */     LOG.warn("Adding additional global patterns [{}] to accepted patterns!", acceptablePatterns);
/*  81 */     this.acceptedPatterns = new HashSet<>(this.acceptedPatterns);
/*     */     try {
/*  83 */       for (String pattern : TextParseUtil.commaDelimitedStringToSet(acceptablePatterns)) {
/*  84 */         this.acceptedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/*  87 */       this.acceptedPatterns = Collections.unmodifiableSet(this.acceptedPatterns);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptedPatterns(String commaDelimitedPatterns) {
/*  93 */     setAcceptedPatterns(TextParseUtil.commaDelimitedStringToSet(commaDelimitedPatterns));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptedPatterns(String[] additionalPatterns) {
/*  98 */     setAcceptedPatterns(new HashSet<>(Arrays.asList(additionalPatterns)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptedPatterns(Set<String> patterns) {
/* 103 */     if (this.acceptedPatterns == null) {
/*     */       
/* 105 */       LOG.debug("Sets accepted patterns to [{}], note this impacts the safety of your application!", patterns);
/*     */     } else {
/* 107 */       LOG.warn("Replacing accepted patterns [{}] with [{}], be aware that this affects all instances and safety of your application!", this.acceptedPatterns, patterns);
/*     */     } 
/*     */     
/* 110 */     this.acceptedPatterns = new HashSet<>(patterns.size());
/*     */     try {
/* 112 */       for (String pattern : patterns) {
/* 113 */         this.acceptedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/* 116 */       this.acceptedPatterns = Collections.unmodifiableSet(this.acceptedPatterns);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AcceptedPatternsChecker.IsAccepted isAccepted(String value) {
/* 122 */     for (Pattern acceptedPattern : this.acceptedPatterns) {
/* 123 */       if (acceptedPattern.matcher(value).matches()) {
/* 124 */         LOG.trace("[{}] matches accepted pattern [{}]", value, acceptedPattern);
/* 125 */         return AcceptedPatternsChecker.IsAccepted.yes(acceptedPattern.toString());
/*     */       } 
/*     */     } 
/* 128 */     return AcceptedPatternsChecker.IsAccepted.no(this.acceptedPatterns.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Pattern> getAcceptedPatterns() {
/* 133 */     return this.acceptedPatterns;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\security\DefaultAcceptedPatternsChecker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */