/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrutsTextProviderFactory
/*    */   implements TextProviderFactory
/*    */ {
/*    */   protected LocaleProviderFactory localeProviderFactory;
/*    */   protected LocalizedTextProvider localizedTextProvider;
/*    */   protected TextProvider defaultTextProvider;
/*    */   
/*    */   @Inject
/*    */   public void setLocaleProviderFactory(LocaleProviderFactory localeProviderFactory) {
/* 36 */     this.localeProviderFactory = localeProviderFactory;
/*    */   }
/*    */   
/*    */   @Inject
/*    */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/* 41 */     this.localizedTextProvider = localizedTextProvider;
/*    */   }
/*    */   
/*    */   @Inject(required = false)
/*    */   public void setDefaultTextProvider(TextProvider defaultTextProvider) {
/* 46 */     this.defaultTextProvider = defaultTextProvider;
/*    */   }
/*    */ 
/*    */   
/*    */   public TextProvider createInstance(Class clazz) {
/* 51 */     TextProvider instance = getTextProvider(clazz);
/* 52 */     if (instance instanceof ResourceBundleTextProvider) {
/* 53 */       ((ResourceBundleTextProvider)instance).setClazz(clazz);
/* 54 */       ((ResourceBundleTextProvider)instance).setLocaleProvider(this.localeProviderFactory.createLocaleProvider());
/*    */     } 
/* 56 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public TextProvider createInstance(ResourceBundle bundle) {
/* 61 */     TextProvider instance = getTextProvider(bundle);
/* 62 */     if (instance instanceof ResourceBundleTextProvider) {
/* 63 */       ((ResourceBundleTextProvider)instance).setBundle(bundle);
/* 64 */       ((ResourceBundleTextProvider)instance).setLocaleProvider(this.localeProviderFactory.createLocaleProvider());
/*    */     } 
/* 66 */     return instance;
/*    */   }
/*    */   
/*    */   protected TextProvider getTextProvider(Class clazz) {
/* 70 */     if (this.defaultTextProvider != null) {
/* 71 */       return this.defaultTextProvider;
/*    */     }
/*    */     
/* 74 */     return new TextProviderSupport(clazz, this.localeProviderFactory.createLocaleProvider(), this.localizedTextProvider);
/*    */   }
/*    */   
/*    */   protected TextProvider getTextProvider(ResourceBundle bundle) {
/* 78 */     if (this.defaultTextProvider != null) {
/* 79 */       return this.defaultTextProvider;
/*    */     }
/*    */     
/* 82 */     return new TextProviderSupport(bundle, this.localeProviderFactory.createLocaleProvider(), this.localizedTextProvider);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\StrutsTextProviderFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */