/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.apache.commons.lang3.LocaleUtils;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apache.logging.log4j.message.Message;
/*    */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLocaleProvider
/*    */   implements LocaleProvider
/*    */ {
/* 34 */   private static final Logger LOG = LogManager.getLogger(DefaultLocaleProvider.class);
/*    */ 
/*    */   
/*    */   public Locale getLocale() {
/* 38 */     ActionContext ctx = ActionContext.getContext();
/* 39 */     if (ctx != null) {
/* 40 */       return ctx.getLocale();
/*    */     }
/* 42 */     LOG.debug("Action context not initialized");
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValidLocaleString(String localeStr) {
/* 49 */     Locale locale = null;
/*    */     try {
/* 51 */       locale = LocaleUtils.toLocale(StringUtils.trimToNull(localeStr));
/* 52 */     } catch (IllegalArgumentException e) {
/* 53 */       LOG.warn((Message)new ParameterizedMessage("Cannot convert [{}] to proper locale", localeStr), e);
/*    */     } 
/* 55 */     return isValidLocale(locale);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isValidLocale(Locale locale) {
/* 60 */     return LocaleUtils.isAvailableLocale(locale);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultLocaleProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */