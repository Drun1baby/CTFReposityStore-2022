/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTypeConverterHolder
/*     */   implements TypeConverterHolder
/*     */ {
/*  40 */   private HashMap<String, TypeConverter> defaultMappings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private HashMap<Class, Map<String, Object>> mappings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private HashSet<Class> noMapping = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected HashSet<String> unknownMappings = new HashSet<>();
/*     */   
/*     */   public void addDefaultMapping(String className, TypeConverter typeConverter) {
/*  77 */     this.defaultMappings.put(className, typeConverter);
/*  78 */     if (this.unknownMappings.contains(className)) {
/*  79 */       this.unknownMappings.remove(className);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean containsDefaultMapping(String className) {
/*  84 */     return this.defaultMappings.containsKey(className);
/*     */   }
/*     */   
/*     */   public TypeConverter getDefaultMapping(String className) {
/*  88 */     return this.defaultMappings.get(className);
/*     */   }
/*     */   
/*     */   public Map<String, Object> getMapping(Class clazz) {
/*  92 */     return this.mappings.get(clazz);
/*     */   }
/*     */   
/*     */   public void addMapping(Class clazz, Map<String, Object> mapping) {
/*  96 */     this.mappings.put(clazz, mapping);
/*     */   }
/*     */   
/*     */   public boolean containsNoMapping(Class clazz) {
/* 100 */     return this.noMapping.contains(clazz);
/*     */   }
/*     */   
/*     */   public void addNoMapping(Class clazz) {
/* 104 */     this.noMapping.add(clazz);
/*     */   }
/*     */   
/*     */   public boolean containsUnknownMapping(String className) {
/* 108 */     return this.unknownMappings.contains(className);
/*     */   }
/*     */   
/*     */   public void addUnknownMapping(String className) {
/* 112 */     this.unknownMappings.add(className);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultTypeConverterHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */