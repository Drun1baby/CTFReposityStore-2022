/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.LocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.conversion.ConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionFileProcessor;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import com.opensymphony.xwork2.conversion.annotations.Conversion;
/*     */ import com.opensymphony.xwork2.conversion.annotations.ConversionRule;
/*     */ import com.opensymphony.xwork2.conversion.annotations.TypeConversion;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkConverter
/*     */   extends DefaultTypeConverter
/*     */ {
/* 136 */   private static final Logger LOG = LogManager.getLogger(XWorkConverter.class);
/*     */   
/*     */   public static final String REPORT_CONVERSION_ERRORS = "report.conversion.errors";
/*     */   
/*     */   public static final String CONVERSION_PROPERTY_FULLNAME = "conversion.property.fullName";
/*     */   public static final String CONVERSION_ERROR_PROPERTY_PREFIX = "invalid.fieldvalue.";
/*     */   public static final String CONVERSION_COLLECTION_PREFIX = "Collection_";
/*     */   public static final String LAST_BEAN_CLASS_ACCESSED = "last.bean.accessed";
/*     */   public static final String LAST_BEAN_PROPERTY_ACCESSED = "last.property.accessed";
/*     */   public static final String MESSAGE_INDEX_PATTERN = "\\[\\d+\\]\\.";
/*     */   public static final String MESSAGE_INDEX_BRACKET_PATTERN = "[\\[\\]\\.]";
/*     */   public static final String PERIOD = ".";
/* 148 */   public static final Pattern messageIndexPattern = Pattern.compile("\\[\\d+\\]\\.");
/*     */   
/*     */   private TypeConverter defaultTypeConverter;
/*     */   
/*     */   private FileManager fileManager;
/*     */   
/*     */   private boolean reloadingConfigs;
/*     */   
/*     */   private ConversionFileProcessor fileProcessor;
/*     */   
/*     */   private ConversionAnnotationProcessor annotationProcessor;
/*     */   
/*     */   private TypeConverterHolder converterHolder;
/*     */   
/*     */   @Inject
/*     */   public void setDefaultTypeConverter(XWorkBasicConverter converter) {
/* 164 */     this.defaultTypeConverter = converter;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/* 169 */     this.fileManager = fileManagerFactory.getFileManager();
/*     */   }
/*     */   
/*     */   @Inject(value = "reloadXmlConfiguration", required = false)
/*     */   public void setReloadingConfigs(String reloadingConfigs) {
/* 174 */     this.reloadingConfigs = Boolean.parseBoolean(reloadingConfigs);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setConversionFileProcessor(ConversionFileProcessor fileProcessor) {
/* 179 */     this.fileProcessor = fileProcessor;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setConversionAnnotationProcessor(ConversionAnnotationProcessor annotationProcessor) {
/* 184 */     this.annotationProcessor = annotationProcessor;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterHolder(TypeConverterHolder converterHolder) {
/* 189 */     this.converterHolder = converterHolder;
/*     */   }
/*     */   
/*     */   public static String getConversionErrorMessage(String propertyName, ValueStack stack) {
/* 193 */     LocalizedTextProvider localizedTextProvider = (LocalizedTextProvider)ActionContext.getContext().getContainer().getInstance(LocalizedTextProvider.class);
/* 194 */     String defaultMessage = localizedTextProvider.findDefaultText("xwork.default.invalid.fieldvalue", ActionContext.getContext().getLocale(), new Object[] { propertyName });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     List<String> indexValues = getIndexValues(propertyName);
/*     */     
/* 202 */     propertyName = removeAllIndexesInPropertyName(propertyName);
/*     */     
/* 204 */     String getTextExpression = "getText('invalid.fieldvalue." + propertyName + "','" + defaultMessage + "')";
/* 205 */     String message = (String)stack.findValue(getTextExpression);
/*     */     
/* 207 */     if (message == null) {
/* 208 */       message = defaultMessage;
/*     */     } else {
/* 210 */       message = MessageFormat.format(message, indexValues.toArray());
/*     */     } 
/*     */     
/* 213 */     return message;
/*     */   }
/*     */   
/*     */   private static String removeAllIndexesInPropertyName(String propertyName) {
/* 217 */     return propertyName.replaceAll("\\[\\d+\\]\\.", ".");
/*     */   }
/*     */   
/*     */   private static List<String> getIndexValues(String propertyName) {
/* 221 */     Matcher matcher = messageIndexPattern.matcher(propertyName);
/* 222 */     List<String> indexes = new ArrayList<>();
/* 223 */     while (matcher.find()) {
/* 224 */       Integer index = Integer.valueOf((new Integer(matcher.group().replaceAll("[\\[\\]\\.]", ""))).intValue() + 1);
/* 225 */       indexes.add(Integer.toString(index.intValue()));
/*     */     } 
/* 227 */     return indexes;
/*     */   }
/*     */   
/*     */   public String buildConverterFilename(Class clazz) {
/* 231 */     String className = clazz.getName();
/* 232 */     return className.replace('.', '/') + "-conversion.properties";
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convertValue(Map<String, Object> map, Object o, Class aClass) {
/* 237 */     return convertValue(map, null, null, null, o, aClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object target, Member member, String property, Object value, Class<?> toClass) {
/* 255 */     TypeConverter tc = null;
/*     */     
/* 257 */     if (value != null && toClass == value.getClass()) {
/* 258 */       return value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (target != null) {
/* 264 */       Class<?> clazz = target.getClass();
/*     */       
/* 266 */       Object[] classProp = null;
/*     */ 
/*     */       
/* 269 */       if (target instanceof com.opensymphony.xwork2.util.CompoundRoot && context != null) {
/* 270 */         classProp = getClassProperty(context);
/*     */       }
/*     */       
/* 273 */       if (classProp != null) {
/* 274 */         clazz = (Class)classProp[0];
/* 275 */         property = (String)classProp[1];
/*     */       } 
/*     */       
/* 278 */       tc = (TypeConverter)getConverter(clazz, property);
/* 279 */       LOG.debug("field-level type converter for property [{}] = {}", property, (tc == null) ? "none found" : tc);
/*     */     } 
/*     */     
/* 282 */     if (tc == null && context != null) {
/*     */       
/* 284 */       Object lastPropertyPath = context.get("current.property.path");
/* 285 */       Class clazz = (Class)context.get("last.bean.accessed");
/* 286 */       if (lastPropertyPath != null && clazz != null) {
/* 287 */         String path = lastPropertyPath + "." + property;
/* 288 */         tc = (TypeConverter)getConverter(clazz, path);
/*     */       } 
/*     */     } 
/*     */     
/* 292 */     if (tc == null) {
/* 293 */       if (toClass.equals(String.class) && value != null && !value.getClass().equals(String.class) && !value.getClass().equals(String[].class)) {
/*     */         
/* 295 */         tc = lookup(value.getClass());
/*     */       } else {
/*     */         
/* 298 */         tc = lookup(toClass);
/*     */       } 
/*     */       
/* 301 */       if (LOG.isDebugEnabled()) {
/* 302 */         LOG.debug("global-level type converter for property [{}] = {} ", property, (tc == null) ? "none found" : tc);
/*     */       }
/*     */     } 
/*     */     
/* 306 */     if (tc != null) {
/*     */       try {
/* 308 */         return tc.convertValue(context, target, member, property, value, toClass);
/* 309 */       } catch (Exception e) {
/* 310 */         LOG.debug("Unable to convert value using type converter [{}]", tc.getClass().getName(), e);
/* 311 */         handleConversionException(context, property, value, target);
/*     */         
/* 313 */         return TypeConverter.NO_CONVERSION_POSSIBLE;
/*     */       } 
/*     */     }
/*     */     
/* 317 */     if (this.defaultTypeConverter != null) {
/*     */       try {
/* 319 */         LOG.debug("Falling back to default type converter [{}]", this.defaultTypeConverter);
/* 320 */         return this.defaultTypeConverter.convertValue(context, target, member, property, value, toClass);
/* 321 */       } catch (Exception e) {
/* 322 */         LOG.debug("Unable to convert value using type converter [{}]", this.defaultTypeConverter.getClass().getName(), e);
/* 323 */         handleConversionException(context, property, value, target);
/*     */         
/* 325 */         return TypeConverter.NO_CONVERSION_POSSIBLE;
/*     */       } 
/*     */     }
/*     */     try {
/* 329 */       LOG.debug("Falling back to Ognl's default type conversion");
/* 330 */       return convertValue(value, toClass);
/* 331 */     } catch (Exception e) {
/* 332 */       LOG.debug("Unable to convert value using type converter [{}]", getClass().getName(), e);
/* 333 */       handleConversionException(context, property, value, target);
/*     */       
/* 335 */       return TypeConverter.NO_CONVERSION_POSSIBLE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverter lookup(String className, boolean isPrimitive) {
/* 348 */     if (this.converterHolder.containsUnknownMapping(className) && !this.converterHolder.containsDefaultMapping(className)) {
/* 349 */       return null;
/*     */     }
/*     */     
/* 352 */     TypeConverter result = this.converterHolder.getDefaultMapping(className);
/*     */ 
/*     */     
/* 355 */     if (result == null && !isPrimitive) {
/* 356 */       Class<?> clazz = null;
/*     */       
/*     */       try {
/* 359 */         clazz = Thread.currentThread().getContextClassLoader().loadClass(className);
/* 360 */       } catch (ClassNotFoundException cnfe) {
/* 361 */         LOG.debug("Cannot load class {}", className, cnfe);
/*     */       } 
/*     */       
/* 364 */       result = lookupSuper(clazz);
/*     */       
/* 366 */       if (result != null) {
/*     */         
/* 368 */         registerConverter(className, result);
/*     */       } else {
/*     */         
/* 371 */         registerConverterNotFound(className);
/*     */       } 
/*     */     } 
/*     */     
/* 375 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverter lookup(Class clazz) {
/* 385 */     TypeConverter result = lookup(clazz.getName(), clazz.isPrimitive());
/*     */     
/* 387 */     if (result == null && clazz.isPrimitive())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 392 */       return this.defaultTypeConverter;
/*     */     }
/*     */     
/* 395 */     return result;
/*     */   }
/*     */   
/*     */   protected Object getConverter(Class clazz, String property) {
/* 399 */     LOG.debug("Retrieving convert for class [{}] and property [{}]", clazz, property);
/*     */     
/* 401 */     synchronized (clazz) {
/* 402 */       if (property != null && !this.converterHolder.containsNoMapping(clazz)) {
/*     */         try {
/* 404 */           Map<String, Object> mapping = this.converterHolder.getMapping(clazz);
/*     */           
/* 406 */           if (mapping == null) {
/* 407 */             mapping = buildConverterMapping(clazz);
/*     */           } else {
/* 409 */             mapping = conditionalReload(clazz, mapping);
/*     */           } 
/*     */           
/* 412 */           Object converter = mapping.get(property);
/* 413 */           if (converter == null && LOG.isDebugEnabled()) {
/* 414 */             LOG.debug("Converter is null for property [{}]. Mapping size [{}]:", property, Integer.valueOf(mapping.size()));
/* 415 */             for (Map.Entry<String, Object> entry : mapping.entrySet()) {
/* 416 */               LOG.debug("{}:{}", entry.getKey(), entry.getValue());
/*     */             }
/*     */           } 
/* 419 */           return converter;
/* 420 */         } catch (Throwable t) {
/* 421 */           LOG.debug("Got exception trying to resolve convert for class [{}] and property [{}]", clazz, property, t);
/* 422 */           this.converterHolder.addNoMapping(clazz);
/*     */         } 
/*     */       }
/*     */     } 
/* 426 */     return null;
/*     */   }
/*     */   
/*     */   protected void handleConversionException(Map<String, Object> context, String property, Object value, Object object) {
/* 430 */     if (context != null && Boolean.TRUE.equals(context.get("report.conversion.errors"))) {
/* 431 */       String realProperty = property;
/* 432 */       String fullName = (String)context.get("conversion.property.fullName");
/*     */       
/* 434 */       if (fullName != null) {
/* 435 */         realProperty = fullName;
/*     */       }
/*     */       
/* 438 */       Map<String, Object> conversionErrors = (Map<String, Object>)context.get("com.opensymphony.xwork2.ActionContext.conversionErrors");
/*     */       
/* 440 */       if (conversionErrors == null) {
/* 441 */         conversionErrors = new HashMap<>();
/* 442 */         context.put("com.opensymphony.xwork2.ActionContext.conversionErrors", conversionErrors);
/*     */       } 
/*     */       
/* 445 */       conversionErrors.put(realProperty, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void registerConverter(String className, TypeConverter converter) {
/* 450 */     this.converterHolder.addDefaultMapping(className, converter);
/*     */   }
/*     */   
/*     */   public synchronized void registerConverterNotFound(String className) {
/* 454 */     this.converterHolder.addUnknownMapping(className);
/*     */   }
/*     */   
/*     */   private Object[] getClassProperty(Map<String, Object> context) {
/* 458 */     Object lastClass = context.get("last.bean.accessed");
/* 459 */     Object lastProperty = context.get("last.property.accessed");
/* 460 */     (new Object[2])[0] = lastClass; (new Object[2])[1] = lastProperty; return (lastClass != null && lastProperty != null) ? new Object[2] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addConverterMapping(Map<String, Object> mapping, Class clazz) {
/* 472 */     String converterFilename = buildConverterFilename(clazz);
/* 473 */     this.fileProcessor.process(mapping, clazz, converterFilename);
/*     */ 
/*     */     
/* 476 */     Annotation[] annotations = clazz.getAnnotations();
/*     */     
/* 478 */     for (Annotation annotation : annotations) {
/* 479 */       if (annotation instanceof Conversion) {
/* 480 */         Conversion conversion = (Conversion)annotation;
/* 481 */         for (TypeConversion tc : conversion.conversions()) {
/* 482 */           if (mapping.containsKey(tc.key())) {
/*     */             break;
/*     */           }
/* 485 */           if (LOG.isDebugEnabled()) {
/* 486 */             if (StringUtils.isEmpty(tc.key())) {
/* 487 */               LOG.debug("WARNING! key of @TypeConversion [{}/{}] applied to [{}] is empty!", tc.converter(), tc.converterClass(), clazz.getName());
/*     */             } else {
/* 489 */               LOG.debug("TypeConversion [{}/{}] with key: [{}]", tc.converter(), tc.converterClass(), tc.key());
/*     */             } 
/*     */           }
/* 492 */           this.annotationProcessor.process(mapping, tc, tc.key());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 498 */     for (Method method : clazz.getMethods()) {
/* 499 */       annotations = method.getAnnotations();
/* 500 */       for (Annotation annotation : annotations) {
/* 501 */         if (annotation instanceof TypeConversion) {
/* 502 */           TypeConversion tc = (TypeConversion)annotation;
/* 503 */           String key = tc.key();
/*     */           
/* 505 */           if (StringUtils.isEmpty(key)) {
/* 506 */             key = AnnotationUtils.resolvePropertyName(method);
/* 507 */             switch (tc.rule()) {
/*     */               case COLLECTION:
/* 509 */                 key = "Collection_" + key;
/*     */                 break;
/*     */               case CREATE_IF_NULL:
/* 512 */                 key = "CreateIfNull_" + key;
/*     */                 break;
/*     */               case ELEMENT:
/* 515 */                 key = "Element_" + key;
/*     */                 break;
/*     */               case KEY:
/* 518 */                 key = "Key_" + key;
/*     */                 break;
/*     */               case KEY_PROPERTY:
/* 521 */                 key = "KeyProperty_" + key;
/*     */                 break;
/*     */             } 
/* 524 */             LOG.debug("Retrieved key [{}] from method name [{}]", key, method.getName());
/*     */           } 
/* 526 */           if (mapping.containsKey(key)) {
/*     */             break;
/*     */           }
/* 529 */           this.annotationProcessor.process(mapping, tc, key);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, Object> buildConverterMapping(Class clazz) throws Exception {
/* 546 */     Map<String, Object> mapping = new HashMap<>();
/*     */ 
/*     */     
/* 549 */     Class curClazz = clazz;
/*     */     
/* 551 */     while (!curClazz.equals(Object.class)) {
/*     */       
/* 553 */       addConverterMapping(mapping, curClazz);
/*     */ 
/*     */       
/* 556 */       Class[] interfaces = curClazz.getInterfaces();
/*     */       
/* 558 */       for (Class anInterface : interfaces) {
/* 559 */         addConverterMapping(mapping, anInterface);
/*     */       }
/*     */       
/* 562 */       curClazz = curClazz.getSuperclass();
/*     */     } 
/*     */     
/* 565 */     if (mapping.size() > 0) {
/* 566 */       this.converterHolder.addMapping(clazz, mapping);
/*     */     } else {
/* 568 */       this.converterHolder.addNoMapping(clazz);
/*     */     } 
/*     */     
/* 571 */     return mapping;
/*     */   }
/*     */   
/*     */   private Map<String, Object> conditionalReload(Class clazz, Map<String, Object> oldValues) throws Exception {
/* 575 */     Map<String, Object> mapping = oldValues;
/*     */     
/* 577 */     if (this.reloadingConfigs) {
/* 578 */       URL fileUrl = ClassLoaderUtil.getResource(buildConverterFilename(clazz), clazz);
/* 579 */       if (this.fileManager.fileNeedsReloading(fileUrl)) {
/* 580 */         mapping = buildConverterMapping(clazz);
/*     */       }
/*     */     } 
/*     */     
/* 584 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeConverter lookupSuper(Class clazz) {
/* 595 */     TypeConverter result = null;
/*     */     
/* 597 */     if (clazz != null) {
/* 598 */       result = this.converterHolder.getDefaultMapping(clazz.getName());
/*     */       
/* 600 */       if (result == null) {
/*     */         
/* 602 */         Class[] interfaces = clazz.getInterfaces();
/*     */         
/* 604 */         for (Class anInterface : interfaces) {
/* 605 */           if (this.converterHolder.containsDefaultMapping(anInterface.getName())) {
/* 606 */             result = this.converterHolder.getDefaultMapping(anInterface.getName());
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 611 */         if (result == null)
/*     */         {
/*     */           
/* 614 */           result = lookupSuper(clazz.getSuperclass());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 619 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\XWorkConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */