/*     */ package com.opensymphony.xwork2.interceptor.annotations;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationParameterFilterInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/*  57 */     Object action = invocation.getAction();
/*  58 */     HttpParameters parameters = invocation.getInvocationContext().getParameters();
/*     */     
/*  60 */     Object model = invocation.getStack().peek();
/*  61 */     if (model == action) {
/*  62 */       model = null;
/*     */     }
/*     */     
/*  65 */     boolean blockByDefault = action.getClass().isAnnotationPresent((Class)BlockByDefault.class);
/*  66 */     List<Field> annotatedFields = new ArrayList<>();
/*     */     
/*  68 */     if (blockByDefault) {
/*  69 */       AnnotationUtils.addAllFields(Allowed.class, action.getClass(), annotatedFields);
/*  70 */       if (model != null) {
/*  71 */         AnnotationUtils.addAllFields(Allowed.class, model.getClass(), annotatedFields);
/*     */       }
/*     */       
/*  74 */       for (String paramName : parameters.keySet()) {
/*  75 */         boolean allowed = false;
/*     */         
/*  77 */         for (Field field : annotatedFields) {
/*     */ 
/*     */           
/*  80 */           if (field.getName().equals(paramName)) {
/*  81 */             allowed = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*  86 */         if (!allowed) {
/*  87 */           parameters = parameters.remove(paramName);
/*     */         }
/*     */       } 
/*     */     } else {
/*  91 */       AnnotationUtils.addAllFields(Blocked.class, action.getClass(), annotatedFields);
/*  92 */       if (model != null) {
/*  93 */         AnnotationUtils.addAllFields(Blocked.class, model.getClass(), annotatedFields);
/*     */       }
/*     */       
/*  96 */       for (String paramName : parameters.keySet()) {
/*  97 */         for (Field field : annotatedFields) {
/*     */ 
/*     */           
/* 100 */           if (field.getName().equals(paramName)) {
/* 101 */             parameters = parameters.remove(paramName);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     invocation.getInvocationContext().setParameters(parameters);
/*     */     
/* 109 */     return invocation.invoke();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\annotations\AnnotationParameterFilterInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */