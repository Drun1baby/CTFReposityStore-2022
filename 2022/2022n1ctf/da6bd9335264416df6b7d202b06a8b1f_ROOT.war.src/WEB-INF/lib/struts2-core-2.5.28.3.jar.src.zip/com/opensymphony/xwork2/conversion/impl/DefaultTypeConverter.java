/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.XWorkTypeConverterWrapper;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Member;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import ognl.TypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DefaultTypeConverter
/*     */   implements TypeConverter
/*     */ {
/*  47 */   protected static String MILLISECOND_FORMAT = ".SSS";
/*     */   
/*     */   private static final String NULL_STRING = "null";
/*     */   
/*     */   private static final Map<Class, Object> primitiveDefaults;
/*     */   
/*     */   private Container container;
/*     */   
/*     */   static {
/*  56 */     Map<Class<?>, Object> map = new HashMap<>();
/*  57 */     map.put(boolean.class, Boolean.FALSE);
/*  58 */     map.put(byte.class, Byte.valueOf((byte)0));
/*  59 */     map.put(short.class, Short.valueOf((short)0));
/*  60 */     map.put(char.class, new Character(false));
/*  61 */     map.put(int.class, Integer.valueOf(0));
/*  62 */     map.put(long.class, Long.valueOf(0L));
/*  63 */     map.put(float.class, new Float(0.0F));
/*  64 */     map.put(double.class, new Double(0.0D));
/*  65 */     map.put(BigInteger.class, new BigInteger("0"));
/*  66 */     map.put(BigDecimal.class, new BigDecimal(0.0D));
/*  67 */     primitiveDefaults = Collections.unmodifiableMap(map);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  72 */     this.container = container;
/*     */   }
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object value, Class toType) {
/*  76 */     return convertValue(value, toType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class toType) {
/*  81 */     return convertValue(context, value, toType);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeConverter getTypeConverter(Map<String, Object> context) {
/*  86 */     Object obj = context.get("_typeConverter");
/*  87 */     if (obj instanceof TypeConverter) {
/*  88 */       return (TypeConverter)obj;
/*     */     }
/*     */     
/*  91 */     if (obj instanceof TypeConverter) {
/*  92 */       return (TypeConverter)new XWorkTypeConverterWrapper((TypeConverter)obj);
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object convertValue(Object value, Class<Integer> toType) {
/* 111 */     Object<?> result = null;
/*     */     
/* 113 */     if (value != null) {
/*     */       
/* 115 */       if (value.getClass().isArray() && toType.isArray()) {
/* 116 */         Class<?> componentType = toType.getComponentType();
/*     */         
/* 118 */         result = (Object<?>)Array.newInstance(componentType, Array.getLength(value));
/*     */         
/* 120 */         for (int i = 0, icount = Array.getLength(value); i < icount; i++) {
/* 121 */           Array.set(result, i, convertValue(Array.get(value, i), componentType));
/*     */         }
/*     */       } else {
/*     */         
/* 125 */         if (toType == Integer.class || toType == int.class)
/* 126 */           result = (Object<?>)Integer.valueOf((int)longValue(value)); 
/* 127 */         if (toType == Double.class || toType == double.class)
/* 128 */           result = (Object<?>)Double.valueOf(doubleValue(value)); 
/* 129 */         if (toType == Boolean.class || toType == boolean.class)
/* 130 */           result = (Object<?>)(booleanValue(value) ? Boolean.TRUE : Boolean.FALSE); 
/* 131 */         if (toType == Byte.class || toType == byte.class)
/* 132 */           result = (Object<?>)Byte.valueOf((byte)(int)longValue(value)); 
/* 133 */         if (toType == Character.class || toType == char.class)
/* 134 */           result = (Object<?>)Character.valueOf((char)(int)longValue(value)); 
/* 135 */         if (toType == Short.class || toType == short.class)
/* 136 */           result = (Object<?>)Short.valueOf((short)(int)longValue(value)); 
/* 137 */         if (toType == Long.class || toType == long.class)
/* 138 */           result = (Object<?>)Long.valueOf(longValue(value)); 
/* 139 */         if (toType == Float.class || toType == float.class)
/* 140 */           result = (Object<?>)new Float(doubleValue(value)); 
/* 141 */         if (toType == BigInteger.class)
/* 142 */           result = (Object<?>)bigIntValue(value); 
/* 143 */         if (toType == BigDecimal.class)
/* 144 */           result = (Object<?>)bigDecValue(value); 
/* 145 */         if (toType == String.class)
/* 146 */           result = (Object<?>)stringValue(value); 
/* 147 */         if (Enum.class.isAssignableFrom(toType)) {
/* 148 */           result = (Object<?>)enumValue(toType, value);
/*     */         }
/*     */       } 
/* 151 */     } else if (toType.isPrimitive()) {
/* 152 */       result = (Object<?>)primitiveDefaults.get(toType);
/*     */     } 
/*     */     
/* 155 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean booleanValue(Object value) {
/* 168 */     if (value == null)
/* 169 */       return false; 
/* 170 */     Class<?> c = value.getClass();
/* 171 */     if (c == Boolean.class) {
/* 172 */       return ((Boolean)value).booleanValue();
/*     */     }
/*     */     
/* 175 */     if (c == Character.class)
/* 176 */       return (((Character)value).charValue() != '\000'); 
/* 177 */     if (value instanceof Number)
/* 178 */       return (((Number)value).doubleValue() != 0.0D); 
/* 179 */     return true;
/*     */   }
/*     */   
/*     */   public Enum<?> enumValue(Class<Enum<?>> toClass, Object o) {
/* 183 */     Enum<?> result = null;
/* 184 */     if (o == null) {
/* 185 */       result = null;
/* 186 */     } else if (o instanceof String[]) {
/* 187 */       result = Enum.valueOf(toClass, ((String[])o)[0]);
/* 188 */     } else if (o instanceof String) {
/* 189 */       result = Enum.valueOf(toClass, (String)o);
/*     */     } 
/* 191 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long longValue(Object value) throws NumberFormatException {
/* 204 */     if (value == null)
/* 205 */       return 0L; 
/* 206 */     Class<?> c = value.getClass();
/* 207 */     if (c.getSuperclass() == Number.class)
/* 208 */       return ((Number)value).longValue(); 
/* 209 */     if (c == Boolean.class)
/* 210 */       return ((Boolean)value).booleanValue() ? 1L : 0L; 
/* 211 */     if (c == Character.class)
/* 212 */       return ((Character)value).charValue(); 
/* 213 */     return Long.parseLong(stringValue(value, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double doubleValue(Object value) throws NumberFormatException {
/* 226 */     if (value == null)
/* 227 */       return 0.0D; 
/* 228 */     Class<?> c = value.getClass();
/* 229 */     if (c.getSuperclass() == Number.class)
/* 230 */       return ((Number)value).doubleValue(); 
/* 231 */     if (c == Boolean.class)
/* 232 */       return ((Boolean)value).booleanValue() ? 1.0D : 0.0D; 
/* 233 */     if (c == Character.class)
/* 234 */       return ((Character)value).charValue(); 
/* 235 */     String s = stringValue(value, true);
/*     */     
/* 237 */     return (s.length() == 0) ? 0.0D : Double.parseDouble(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger bigIntValue(Object value) throws NumberFormatException {
/* 255 */     if (value == null)
/* 256 */       return BigInteger.valueOf(0L); 
/* 257 */     Class<?> c = value.getClass();
/* 258 */     if (c == BigInteger.class)
/* 259 */       return (BigInteger)value; 
/* 260 */     if (c == BigDecimal.class)
/* 261 */       return ((BigDecimal)value).toBigInteger(); 
/* 262 */     if (c.getSuperclass() == Number.class)
/* 263 */       return BigInteger.valueOf(((Number)value).longValue()); 
/* 264 */     if (c == Boolean.class)
/* 265 */       return BigInteger.valueOf(((Boolean)value).booleanValue() ? 1L : 0L); 
/* 266 */     if (c == Character.class)
/* 267 */       return BigInteger.valueOf(((Character)value).charValue()); 
/* 268 */     return new BigInteger(stringValue(value, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal bigDecValue(Object value) throws NumberFormatException {
/* 282 */     if (value == null)
/* 283 */       return BigDecimal.valueOf(0L); 
/* 284 */     Class<?> c = value.getClass();
/* 285 */     if (c == BigDecimal.class)
/* 286 */       return (BigDecimal)value; 
/* 287 */     if (c == BigInteger.class)
/* 288 */       return new BigDecimal((BigInteger)value); 
/* 289 */     if (c.getSuperclass() == Number.class)
/* 290 */       return new BigDecimal(((Number)value).doubleValue()); 
/* 291 */     if (c == Boolean.class)
/* 292 */       return BigDecimal.valueOf(((Boolean)value).booleanValue() ? 1L : 0L); 
/* 293 */     if (c == Character.class)
/* 294 */       return BigDecimal.valueOf(((Character)value).charValue()); 
/* 295 */     return new BigDecimal(stringValue(value, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stringValue(Object value, boolean trim) {
/*     */     String result;
/* 312 */     if (value == null) {
/* 313 */       result = "null";
/*     */     } else {
/* 315 */       result = value.toString();
/* 316 */       if (trim) {
/* 317 */         result = result.trim();
/*     */       }
/*     */     } 
/* 320 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stringValue(Object value) {
/* 332 */     return stringValue(value, false);
/*     */   }
/*     */   
/*     */   protected Locale getLocale(Map<String, Object> context) {
/* 336 */     Locale locale = null;
/* 337 */     if (context != null) {
/* 338 */       locale = (Locale)context.get("com.opensymphony.xwork2.ActionContext.locale");
/*     */     }
/* 340 */     if (locale == null) {
/* 341 */       LocaleProviderFactory localeProviderFactory = (LocaleProviderFactory)this.container.getInstance(LocaleProviderFactory.class);
/* 342 */       locale = localeProviderFactory.createLocaleProvider().getLocale();
/*     */     } 
/* 344 */     return locale;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultTypeConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */