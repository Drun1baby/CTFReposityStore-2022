/*    */ package com.opensymphony.xwork2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.Result;
/*    */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionExceptionHandler;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultResultFactory
/*    */   implements ResultFactory
/*    */ {
/*    */   private ObjectFactory objectFactory;
/*    */   private ReflectionProvider reflectionProvider;
/*    */   
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 41 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 46 */     this.reflectionProvider = reflectionProvider;
/*    */   }
/*    */   
/*    */   public Result buildResult(ResultConfig resultConfig, Map<String, Object> extraContext) throws Exception {
/* 50 */     String resultClassName = resultConfig.getClassName();
/* 51 */     Result result = null;
/*    */     
/* 53 */     if (resultClassName != null) {
/* 54 */       result = (Result)this.objectFactory.buildBean(resultClassName, extraContext);
/* 55 */       Map<String, String> params = resultConfig.getParams();
/* 56 */       if (params != null) {
/* 57 */         for (Map.Entry<String, String> paramEntry : params.entrySet()) {
/*    */           try {
/* 59 */             this.reflectionProvider.setProperty(paramEntry.getKey(), paramEntry.getValue(), result, extraContext, true);
/* 60 */           } catch (ReflectionException ex) {
/* 61 */             if (result instanceof ReflectionExceptionHandler) {
/* 62 */               ((ReflectionExceptionHandler)result).handle(ex);
/*    */             }
/*    */           } 
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 69 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\DefaultResultFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */