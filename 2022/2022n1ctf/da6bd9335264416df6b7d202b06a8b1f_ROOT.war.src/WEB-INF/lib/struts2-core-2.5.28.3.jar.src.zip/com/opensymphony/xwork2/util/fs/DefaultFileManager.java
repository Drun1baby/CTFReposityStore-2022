/*     */ package com.opensymphony.xwork2.util.fs;
/*     */ 
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFileManager
/*     */   implements FileManager
/*     */ {
/*  38 */   private static Logger LOG = LogManager.getLogger(DefaultFileManager.class);
/*     */   
/*  40 */   private static final Pattern JAR_PATTERN = Pattern.compile("^(jar:|wsjar:|zip:|vfsfile:|code-source:)?(file:)?(.*?)(\\!/|\\.jar/)(.*)");
/*     */   
/*     */   private static final int JAR_FILE_PATH = 3;
/*  43 */   protected static final Map<String, Revision> files = Collections.synchronizedMap(new HashMap<>());
/*  44 */   private static final List<URL> lazyMonitoredFilesCache = Collections.synchronizedList(new ArrayList<>());
/*     */ 
/*     */   
/*     */   protected boolean reloadingConfigs = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReloadingConfigs(boolean reloadingConfigs) {
/*  52 */     if (reloadingConfigs && !this.reloadingConfigs) {
/*     */       
/*  54 */       this.reloadingConfigs = true;
/*  55 */       synchronized (lazyMonitoredFilesCache) {
/*  56 */         for (URL fileUrl : lazyMonitoredFilesCache) {
/*  57 */           monitorFile(fileUrl);
/*     */         }
/*  59 */         lazyMonitoredFilesCache.clear();
/*     */       } 
/*     */     } 
/*  62 */     this.reloadingConfigs = reloadingConfigs;
/*     */   }
/*     */   
/*     */   public boolean fileNeedsReloading(URL fileUrl) {
/*  66 */     return (fileUrl != null && fileNeedsReloading(fileUrl.toString()));
/*     */   }
/*     */   
/*     */   public boolean fileNeedsReloading(String fileName) {
/*  70 */     Revision revision = files.get(fileName);
/*  71 */     if (revision == null)
/*     */     {
/*     */       
/*  74 */       return this.reloadingConfigs;
/*     */     }
/*  76 */     return revision.needsReloading();
/*     */   }
/*     */   
/*     */   public InputStream loadFile(URL fileUrl) {
/*  80 */     if (fileUrl == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     InputStream is = openFile(fileUrl);
/*  84 */     monitorFile(fileUrl);
/*  85 */     return is;
/*     */   }
/*     */   
/*     */   private InputStream openFile(URL fileUrl) {
/*     */     try {
/*  90 */       InputStream is = fileUrl.openStream();
/*  91 */       if (is == null) {
/*  92 */         throw new IllegalArgumentException("No file '" + fileUrl + "' found as a resource");
/*     */       }
/*  94 */       return is;
/*  95 */     } catch (IOException e) {
/*  96 */       throw new IllegalArgumentException("No file '" + fileUrl + "' found as a resource");
/*     */     } 
/*     */   }
/*     */   public void monitorFile(URL fileUrl) {
/*     */     Revision revision;
/* 101 */     String fileName = fileUrl.toString();
/* 102 */     if (!this.reloadingConfigs) {
/*     */       
/* 104 */       files.remove(fileName);
/* 105 */       lazyMonitoredFilesCache.add(fileUrl);
/*     */       
/*     */       return;
/*     */     } 
/* 109 */     LOG.debug("Creating revision for URL: {}", fileName);
/* 110 */     if (isJarURL(fileUrl)) {
/* 111 */       revision = JarEntryRevision.build(fileUrl, this);
/*     */     } else {
/* 113 */       revision = FileRevision.build(fileUrl);
/*     */     } 
/* 115 */     if (revision == null) {
/* 116 */       files.put(fileName, Revision.build(fileUrl));
/*     */     } else {
/* 118 */       files.put(fileName, revision);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isJarURL(URL fileUrl) {
/* 129 */     Matcher jarMatcher = JAR_PATTERN.matcher(fileUrl.getPath());
/* 130 */     return jarMatcher.matches();
/*     */   }
/*     */   
/*     */   public URL normalizeToFileProtocol(URL url) {
/* 134 */     String fileName = url.toExternalForm();
/* 135 */     Matcher jarMatcher = JAR_PATTERN.matcher(fileName);
/*     */     try {
/* 137 */       if (jarMatcher.matches()) {
/* 138 */         String path = jarMatcher.group(3);
/* 139 */         return new URL("file", "", path);
/* 140 */       }  if ("file".equals(url.getProtocol())) {
/* 141 */         return url;
/*     */       }
/* 143 */       LOG.warn("Could not normalize URL [{}] to file protocol!", url);
/* 144 */       return null;
/*     */     }
/* 146 */     catch (MalformedURLException e) {
/* 147 */       LOG.warn("Error normalizing URL [{}] to file protocol!", url, e);
/* 148 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean support() {
/* 153 */     return false;
/*     */   }
/*     */   
/*     */   public boolean internal() {
/* 157 */     return true;
/*     */   }
/*     */   
/*     */   public Collection<? extends URL> getAllPhysicalUrls(URL url) throws IOException {
/* 161 */     return Arrays.asList(new URL[] { url });
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\DefaultFileManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */