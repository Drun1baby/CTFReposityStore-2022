/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateConverter
/*     */   extends DefaultTypeConverter
/*     */ {
/*     */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class<Time> toType) {
/*  36 */     Date result = null;
/*     */     
/*  38 */     if (value instanceof String && value != null && ((String)value).length() > 0) {
/*  39 */       String sa = (String)value;
/*  40 */       Locale locale = getLocale(context);
/*     */       
/*  42 */       DateFormat df = null;
/*  43 */       if (Time.class == toType) {
/*  44 */         df = DateFormat.getTimeInstance(2, locale);
/*  45 */       } else if (Timestamp.class == toType) {
/*  46 */         Date check = null;
/*  47 */         SimpleDateFormat dtfmt = (SimpleDateFormat)DateFormat.getDateTimeInstance(3, 2, locale);
/*     */ 
/*     */         
/*  50 */         SimpleDateFormat fullfmt = new SimpleDateFormat(dtfmt.toPattern() + MILLISECOND_FORMAT, locale);
/*     */ 
/*     */         
/*  53 */         SimpleDateFormat dfmt = (SimpleDateFormat)DateFormat.getDateInstance(3, locale);
/*     */ 
/*     */         
/*  56 */         SimpleDateFormat[] fmts = { fullfmt, dtfmt, dfmt };
/*  57 */         for (SimpleDateFormat fmt : fmts) {
/*     */           try {
/*  59 */             check = fmt.parse(sa);
/*  60 */             df = fmt;
/*  61 */             if (check != null) {
/*     */               break;
/*     */             }
/*  64 */           } catch (ParseException parseException) {}
/*     */         }
/*     */       
/*  67 */       } else if (Date.class == toType) {
/*     */         
/*  69 */         DateFormat[] dfs = getDateFormats(locale);
/*  70 */         for (DateFormat df1 : dfs) {
/*     */           try {
/*  72 */             Date check = df1.parse(sa);
/*  73 */             df = df1;
/*  74 */             if (check != null) {
/*     */               break;
/*     */             }
/*  77 */           } catch (ParseException parseException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  82 */       if (df == null) {
/*  83 */         df = DateFormat.getDateInstance(3, locale);
/*     */       }
/*     */       try {
/*  86 */         df.setLenient(false);
/*  87 */         result = df.parse(sa);
/*  88 */         if (Date.class != toType) {
/*     */           try {
/*  90 */             Constructor<Time> constructor = toType.getConstructor(new Class[] { long.class });
/*  91 */             return constructor.newInstance(new Object[] { Long.valueOf(result.getTime()) });
/*  92 */           } catch (Exception e) {
/*  93 */             throw new XWorkException("Couldn't create class " + toType + " using default (long) constructor", e);
/*     */           } 
/*     */         }
/*  96 */       } catch (ParseException e) {
/*  97 */         throw new XWorkException("Could not parse date", e);
/*     */       } 
/*  99 */     } else if (Date.class.isAssignableFrom(value.getClass())) {
/* 100 */       result = (Date)value;
/*     */     } 
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   private DateFormat[] getDateFormats(Locale locale) {
/* 106 */     DateFormat dt1 = DateFormat.getDateTimeInstance(3, 1, locale);
/* 107 */     DateFormat dt2 = DateFormat.getDateTimeInstance(3, 2, locale);
/* 108 */     DateFormat dt3 = DateFormat.getDateTimeInstance(3, 3, locale);
/*     */     
/* 110 */     DateFormat d1 = DateFormat.getDateInstance(3, locale);
/* 111 */     DateFormat d2 = DateFormat.getDateInstance(2, locale);
/* 112 */     DateFormat d3 = DateFormat.getDateInstance(1, locale);
/*     */     
/* 114 */     DateFormat rfc3339 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
/* 115 */     DateFormat rfc3339dateOnly = new SimpleDateFormat("yyyy-MM-dd");
/*     */     
/* 117 */     return new DateFormat[] { dt1, dt2, dt3, rfc3339, d1, d2, d3, rfc3339dateOnly };
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DateConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */