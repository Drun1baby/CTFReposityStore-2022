/*    */ package com.opensymphony.xwork2.conversion.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*    */ import java.lang.reflect.Array;
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayConverter
/*    */   extends DefaultTypeConverter
/*    */ {
/*    */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class toType) {
/* 31 */     Object result = null;
/* 32 */     Class<?> componentType = toType.getComponentType();
/*    */     
/* 34 */     if (componentType != null) {
/* 35 */       TypeConverter converter = getTypeConverter(context);
/*    */       
/* 37 */       if (value.getClass().isArray()) {
/* 38 */         int length = Array.getLength(value);
/* 39 */         result = Array.newInstance(componentType, length);
/*    */         
/* 41 */         for (int i = 0; i < length; i++) {
/* 42 */           Object valueItem = Array.get(value, i);
/* 43 */           Array.set(result, i, converter.convertValue(context, target, member, propertyName, valueItem, componentType));
/*    */         } 
/*    */       } else {
/* 46 */         result = Array.newInstance(componentType, 1);
/* 47 */         Array.set(result, 0, converter.convertValue(context, target, member, propertyName, value, componentType));
/*    */       } 
/*    */     } 
/*    */     
/* 51 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\ArrayConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */