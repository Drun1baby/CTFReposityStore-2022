/*    */ package com.opensymphony.xwork2.util.classloader;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipFile;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarResourceStore
/*    */   extends AbstractResourceStore
/*    */ {
/* 32 */   private static final Logger LOG = LogManager.getLogger(JarResourceStore.class);
/*    */   
/*    */   public JarResourceStore(File file) {
/* 35 */     super(file);
/*    */   }
/*    */   
/*    */   public byte[] read(String pResourceName) {
/* 39 */     InputStream in = null;
/*    */     try {
/* 41 */       ZipFile jarFile = new ZipFile(this.file);
/* 42 */       ZipEntry entry = jarFile.getEntry(pResourceName);
/*    */ 
/*    */       
/* 45 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 46 */       in = jarFile.getInputStream(entry);
/* 47 */       copy(in, out);
/*    */       
/* 49 */       return out.toByteArray();
/* 50 */     } catch (Exception e) {
/* 51 */       LOG.debug("Unable to read file [{}] from [{}]", pResourceName, this.file.getName(), e);
/* 52 */       return null;
/*    */     } finally {
/* 54 */       closeQuietly(in);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static long copy(InputStream input, OutputStream output) throws IOException {
/* 59 */     byte[] buffer = new byte[4096];
/* 60 */     long count = 0L;
/* 61 */     int n = 0;
/* 62 */     while (-1 != (n = input.read(buffer))) {
/* 63 */       output.write(buffer, 0, n);
/* 64 */       count += n;
/*    */     } 
/* 66 */     return count;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\classloader\JarResourceStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */