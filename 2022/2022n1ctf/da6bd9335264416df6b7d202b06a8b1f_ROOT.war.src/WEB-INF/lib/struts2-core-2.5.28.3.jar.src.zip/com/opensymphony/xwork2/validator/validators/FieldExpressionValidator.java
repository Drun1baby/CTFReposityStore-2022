/*    */ package com.opensymphony.xwork2.validator.validators;
/*    */ 
/*    */ import com.opensymphony.xwork2.validator.ValidationException;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldExpressionValidator
/*    */   extends FieldValidatorSupport
/*    */ {
/* 62 */   private static final Logger LOG = LogManager.getLogger(FieldExpressionValidator.class);
/*    */   
/*    */   private String expression;
/*    */   
/*    */   public void setExpression(String expression) {
/* 67 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public String getExpression() {
/* 71 */     return this.expression;
/*    */   }
/*    */   
/*    */   public void validate(Object object) throws ValidationException {
/* 75 */     String fieldName = getFieldName();
/*    */     
/* 77 */     Boolean answer = Boolean.FALSE;
/* 78 */     Object obj = null;
/*    */     
/*    */     try {
/* 81 */       obj = getFieldValue(this.expression, object);
/* 82 */     } catch (ValidationException e) {
/* 83 */       throw e;
/* 84 */     } catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */     
/* 88 */     if (obj != null && obj instanceof Boolean) {
/* 89 */       answer = (Boolean)obj;
/*    */     } else {
/* 91 */       LOG.warn("Got result of {} when trying to get Boolean.", obj);
/*    */     } 
/*    */     
/* 94 */     if (!answer.booleanValue())
/* 95 */       addFieldError(fieldName, object); 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\FieldExpressionValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */