/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*     */ import com.opensymphony.xwork2.validator.annotations.ConditionalVisitorFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.ConversionErrorFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.CreditCardValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.CustomValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.DateRangeFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.DoubleRangeFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.EmailValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.ExpressionValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.FieldExpressionValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.IntRangeFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.LongRangeFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.RegexFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.RequiredFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.RequiredStringValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.ShortRangeFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.StringLengthFieldValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.UrlValidator;
/*     */ import com.opensymphony.xwork2.validator.annotations.Validation;
/*     */ import com.opensymphony.xwork2.validator.annotations.ValidationParameter;
/*     */ import com.opensymphony.xwork2.validator.annotations.Validations;
/*     */ import com.opensymphony.xwork2.validator.annotations.VisitorFieldValidator;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ public class AnnotationValidationConfigurationBuilder
/*     */ {
/*     */   private ValidatorFactory validatorFactory;
/*     */   
/*     */   public AnnotationValidationConfigurationBuilder(ValidatorFactory fac) {
/*  44 */     this.validatorFactory = fac;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ValidatorConfig> processAnnotations(Object o) {
/*  49 */     List<ValidatorConfig> result = new ArrayList<>();
/*     */     
/*  51 */     String fieldName = null;
/*  52 */     String methodName = null;
/*     */     
/*  54 */     Annotation[] annotations = null;
/*     */     
/*  56 */     if (o instanceof Class) {
/*  57 */       Class clazz = (Class)o;
/*  58 */       annotations = clazz.getAnnotations();
/*     */     } 
/*     */     
/*  61 */     if (o instanceof Method) {
/*  62 */       Method method = (Method)o;
/*  63 */       fieldName = AnnotationUtils.resolvePropertyName(method);
/*  64 */       methodName = method.getName();
/*     */       
/*  66 */       annotations = method.getAnnotations();
/*     */     } 
/*     */     
/*  69 */     if (annotations != null) {
/*  70 */       for (Annotation a : annotations) {
/*     */ 
/*     */         
/*  73 */         if (a instanceof Validations) {
/*  74 */           processValidationAnnotation(a, fieldName, methodName, result);
/*     */         }
/*     */ 
/*     */         
/*  78 */         if (a instanceof Validation) {
/*  79 */           Validation v = (Validation)a;
/*  80 */           if (v.validations() != null) {
/*  81 */             for (Validations val : v.validations()) {
/*  82 */               processValidationAnnotation((Annotation)val, fieldName, methodName, result);
/*     */             
/*     */             }
/*     */           }
/*     */         }
/*  87 */         else if (a instanceof ExpressionValidator) {
/*  88 */           ExpressionValidator v = (ExpressionValidator)a;
/*  89 */           ValidatorConfig temp = processExpressionValidatorAnnotation(v, fieldName, methodName);
/*  90 */           if (temp != null) {
/*  91 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/*  95 */         else if (a instanceof CustomValidator) {
/*  96 */           CustomValidator v = (CustomValidator)a;
/*  97 */           ValidatorConfig temp = processCustomValidatorAnnotation(v, fieldName, methodName);
/*  98 */           if (temp != null) {
/*  99 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 103 */         else if (a instanceof ConversionErrorFieldValidator) {
/* 104 */           ConversionErrorFieldValidator v = (ConversionErrorFieldValidator)a;
/* 105 */           ValidatorConfig temp = processConversionErrorFieldValidatorAnnotation(v, fieldName, methodName);
/* 106 */           if (temp != null) {
/* 107 */             result.add(temp);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 112 */         else if (a instanceof DateRangeFieldValidator) {
/* 113 */           DateRangeFieldValidator v = (DateRangeFieldValidator)a;
/* 114 */           ValidatorConfig temp = processDateRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 115 */           if (temp != null) {
/* 116 */             result.add(temp);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 121 */         else if (a instanceof EmailValidator) {
/* 122 */           EmailValidator v = (EmailValidator)a;
/* 123 */           ValidatorConfig temp = processEmailValidatorAnnotation(v, fieldName, methodName);
/* 124 */           if (temp != null) {
/* 125 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 129 */         else if (a instanceof CreditCardValidator) {
/* 130 */           CreditCardValidator v = (CreditCardValidator)a;
/* 131 */           ValidatorConfig temp = processCreditCardValidatorAnnotation(v, fieldName, methodName);
/* 132 */           if (temp != null) {
/* 133 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 137 */         else if (a instanceof FieldExpressionValidator) {
/* 138 */           FieldExpressionValidator v = (FieldExpressionValidator)a;
/* 139 */           ValidatorConfig temp = processFieldExpressionValidatorAnnotation(v, fieldName, methodName);
/* 140 */           if (temp != null) {
/* 141 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 145 */         else if (a instanceof IntRangeFieldValidator) {
/* 146 */           IntRangeFieldValidator v = (IntRangeFieldValidator)a;
/* 147 */           ValidatorConfig temp = processIntRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 148 */           if (temp != null) {
/* 149 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 153 */         else if (a instanceof LongRangeFieldValidator) {
/* 154 */           LongRangeFieldValidator v = (LongRangeFieldValidator)a;
/* 155 */           ValidatorConfig temp = processLongRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 156 */           if (temp != null) {
/* 157 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 161 */         else if (a instanceof ShortRangeFieldValidator) {
/* 162 */           ShortRangeFieldValidator v = (ShortRangeFieldValidator)a;
/* 163 */           ValidatorConfig temp = processShortRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 164 */           if (temp != null) {
/* 165 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 169 */         else if (a instanceof DoubleRangeFieldValidator) {
/* 170 */           DoubleRangeFieldValidator v = (DoubleRangeFieldValidator)a;
/* 171 */           ValidatorConfig temp = processDoubleRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 172 */           if (temp != null) {
/* 173 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 177 */         else if (a instanceof RequiredFieldValidator) {
/* 178 */           RequiredFieldValidator v = (RequiredFieldValidator)a;
/* 179 */           ValidatorConfig temp = processRequiredFieldValidatorAnnotation(v, fieldName, methodName);
/* 180 */           if (temp != null) {
/* 181 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 185 */         else if (a instanceof RequiredStringValidator) {
/* 186 */           RequiredStringValidator v = (RequiredStringValidator)a;
/* 187 */           ValidatorConfig temp = processRequiredStringValidatorAnnotation(v, fieldName, methodName);
/* 188 */           if (temp != null) {
/* 189 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 193 */         else if (a instanceof StringLengthFieldValidator) {
/* 194 */           StringLengthFieldValidator v = (StringLengthFieldValidator)a;
/* 195 */           ValidatorConfig temp = processStringLengthFieldValidatorAnnotation(v, fieldName, methodName);
/* 196 */           if (temp != null) {
/* 197 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 201 */         else if (a instanceof UrlValidator) {
/* 202 */           UrlValidator v = (UrlValidator)a;
/* 203 */           ValidatorConfig temp = processUrlValidatorAnnotation(v, fieldName, methodName);
/* 204 */           if (temp != null) {
/* 205 */             result.add(temp);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 210 */         else if (a instanceof ConditionalVisitorFieldValidator) {
/* 211 */           ConditionalVisitorFieldValidator v = (ConditionalVisitorFieldValidator)a;
/* 212 */           ValidatorConfig temp = processConditionalVisitorFieldValidatorAnnotation(v, fieldName, methodName);
/* 213 */           if (temp != null) {
/* 214 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 218 */         else if (a instanceof VisitorFieldValidator) {
/* 219 */           VisitorFieldValidator v = (VisitorFieldValidator)a;
/* 220 */           ValidatorConfig temp = processVisitorFieldValidatorAnnotation(v, fieldName, methodName);
/* 221 */           if (temp != null) {
/* 222 */             result.add(temp);
/*     */           
/*     */           }
/*     */         }
/* 226 */         else if (a instanceof RegexFieldValidator) {
/* 227 */           RegexFieldValidator v = (RegexFieldValidator)a;
/* 228 */           ValidatorConfig temp = processRegexFieldValidatorAnnotation(v, fieldName, methodName);
/* 229 */           if (temp != null) {
/* 230 */             result.add(temp);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 235 */     return result;
/*     */   }
/*     */   
/*     */   private void processValidationAnnotation(Annotation a, String fieldName, String methodName, List<ValidatorConfig> result) {
/* 239 */     Validations validations = (Validations)a;
/* 240 */     CustomValidator[] cv = validations.customValidators();
/* 241 */     if (cv != null) {
/* 242 */       for (CustomValidator v : cv) {
/* 243 */         ValidatorConfig temp = processCustomValidatorAnnotation(v, fieldName, methodName);
/* 244 */         if (temp != null) {
/* 245 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 249 */     ExpressionValidator[] ev = validations.expressions();
/* 250 */     if (ev != null) {
/* 251 */       for (ExpressionValidator v : ev) {
/* 252 */         ValidatorConfig temp = processExpressionValidatorAnnotation(v, fieldName, methodName);
/* 253 */         if (temp != null) {
/* 254 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 258 */     ConversionErrorFieldValidator[] cef = validations.conversionErrorFields();
/* 259 */     if (cef != null) {
/* 260 */       for (ConversionErrorFieldValidator v : cef) {
/* 261 */         ValidatorConfig temp = processConversionErrorFieldValidatorAnnotation(v, fieldName, methodName);
/* 262 */         if (temp != null) {
/* 263 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 267 */     DateRangeFieldValidator[] drfv = validations.dateRangeFields();
/* 268 */     if (drfv != null) {
/* 269 */       for (DateRangeFieldValidator v : drfv) {
/* 270 */         ValidatorConfig temp = processDateRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 271 */         if (temp != null) {
/* 272 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 276 */     EmailValidator[] emv = validations.emails();
/* 277 */     if (emv != null) {
/* 278 */       for (EmailValidator v : emv) {
/* 279 */         ValidatorConfig temp = processEmailValidatorAnnotation(v, fieldName, methodName);
/* 280 */         if (temp != null) {
/* 281 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 285 */     CreditCardValidator[] ccv = validations.creditCards();
/* 286 */     if (ccv != null) {
/* 287 */       for (CreditCardValidator v : ccv) {
/* 288 */         ValidatorConfig temp = processCreditCardValidatorAnnotation(v, fieldName, methodName);
/* 289 */         if (temp != null) {
/* 290 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 294 */     FieldExpressionValidator[] fev = validations.fieldExpressions();
/* 295 */     if (fev != null) {
/* 296 */       for (FieldExpressionValidator v : fev) {
/* 297 */         ValidatorConfig temp = processFieldExpressionValidatorAnnotation(v, fieldName, methodName);
/* 298 */         if (temp != null) {
/* 299 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 303 */     IntRangeFieldValidator[] irfv = validations.intRangeFields();
/* 304 */     if (irfv != null) {
/* 305 */       for (IntRangeFieldValidator v : irfv) {
/* 306 */         ValidatorConfig temp = processIntRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 307 */         if (temp != null) {
/* 308 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 312 */     LongRangeFieldValidator[] lrfv = validations.longRangeFields();
/* 313 */     if (irfv != null) {
/* 314 */       for (LongRangeFieldValidator v : lrfv) {
/* 315 */         ValidatorConfig temp = processLongRangeFieldValidatorAnnotation(v, fieldName, methodName);
/* 316 */         if (temp != null) {
/* 317 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 321 */     RegexFieldValidator[] rfv = validations.regexFields();
/* 322 */     if (rfv != null) {
/* 323 */       for (RegexFieldValidator v : rfv) {
/* 324 */         ValidatorConfig temp = processRegexFieldValidatorAnnotation(v, fieldName, methodName);
/* 325 */         if (temp != null) {
/* 326 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 330 */     RequiredFieldValidator[] rv = validations.requiredFields();
/* 331 */     if (rv != null) {
/* 332 */       for (RequiredFieldValidator v : rv) {
/* 333 */         ValidatorConfig temp = processRequiredFieldValidatorAnnotation(v, fieldName, methodName);
/* 334 */         if (temp != null) {
/* 335 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 339 */     RequiredStringValidator[] rsv = validations.requiredStrings();
/* 340 */     if (rsv != null) {
/* 341 */       for (RequiredStringValidator v : rsv) {
/* 342 */         ValidatorConfig temp = processRequiredStringValidatorAnnotation(v, fieldName, methodName);
/* 343 */         if (temp != null) {
/* 344 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 348 */     StringLengthFieldValidator[] slfv = validations.stringLengthFields();
/* 349 */     if (slfv != null) {
/* 350 */       for (StringLengthFieldValidator v : slfv) {
/* 351 */         ValidatorConfig temp = processStringLengthFieldValidatorAnnotation(v, fieldName, methodName);
/* 352 */         if (temp != null) {
/* 353 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 357 */     UrlValidator[] uv = validations.urls();
/* 358 */     if (uv != null) {
/* 359 */       for (UrlValidator v : uv) {
/* 360 */         ValidatorConfig temp = processUrlValidatorAnnotation(v, fieldName, methodName);
/* 361 */         if (temp != null) {
/* 362 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 366 */     ConditionalVisitorFieldValidator[] cvfv = validations.conditionalVisitorFields();
/* 367 */     if (cvfv != null) {
/* 368 */       for (ConditionalVisitorFieldValidator v : cvfv) {
/* 369 */         ValidatorConfig temp = processConditionalVisitorFieldValidatorAnnotation(v, fieldName, methodName);
/* 370 */         if (temp != null) {
/* 371 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/* 375 */     VisitorFieldValidator[] vfv = validations.visitorFields();
/* 376 */     if (vfv != null) {
/* 377 */       for (VisitorFieldValidator v : vfv) {
/* 378 */         ValidatorConfig temp = processVisitorFieldValidatorAnnotation(v, fieldName, methodName);
/* 379 */         if (temp != null) {
/* 380 */           result.add(temp);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private ValidatorConfig processExpressionValidatorAnnotation(ExpressionValidator v, String fieldName, String methodName) {
/* 387 */     String validatorType = "expression";
/*     */     
/* 389 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 391 */     if (fieldName != null) {
/* 392 */       params.put("fieldName", fieldName);
/*     */     }
/*     */     
/* 395 */     params.put("expression", v.expression());
/*     */     
/* 397 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 398 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processCustomValidatorAnnotation(CustomValidator v, String fieldName, String methodName) {
/* 410 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 412 */     if (fieldName != null) {
/* 413 */       params.put("fieldName", fieldName);
/* 414 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 415 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */ 
/*     */     
/* 419 */     String validatorType = v.type();
/* 420 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/*     */     
/* 422 */     ValidationParameter[] arrayOfValidationParameter = v.parameters();
/*     */     
/* 424 */     if (arrayOfValidationParameter != null) {
/* 425 */       for (ValidationParameter validationParameter : arrayOfValidationParameter) {
/* 426 */         if (validationParameter instanceof ValidationParameter) {
/* 427 */           ValidationParameter parameter = validationParameter;
/* 428 */           String parameterName = parameter.name();
/* 429 */           String parameterValue = parameter.value();
/* 430 */           params.put(parameterName, parameterValue);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 435 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processRegexFieldValidatorAnnotation(RegexFieldValidator v, String fieldName, String methodName) {
/* 446 */     String validatorType = "regex";
/*     */     
/* 448 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 450 */     if (fieldName != null) {
/* 451 */       params.put("fieldName", fieldName);
/* 452 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 453 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 456 */     params.put("regex", v.regex());
/* 457 */     params.put("regexExpression", v.regexExpression());
/*     */     
/* 459 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 460 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).addParam("trim", Boolean.valueOf(v.trim())).addParam("trimExpression", v.trimExpression()).addParam("caseSensitive", Boolean.valueOf(v.caseSensitive())).addParam("caseSensitiveExpression", v.caseSensitiveExpression()).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processConditionalVisitorFieldValidatorAnnotation(ConditionalVisitorFieldValidator v, String fieldName, String methodName) {
/* 475 */     String validatorType = "conditionalvisitor";
/*     */     
/* 477 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 479 */     if (fieldName != null) {
/* 480 */       params.put("fieldName", fieldName);
/* 481 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 482 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 485 */     params.put("expression", v.expression());
/* 486 */     params.put("context", v.context());
/* 487 */     params.put("appendPrefix", String.valueOf(v.appendPrefix()));
/*     */     
/* 489 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 490 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processVisitorFieldValidatorAnnotation(VisitorFieldValidator v, String fieldName, String methodName) {
/* 502 */     String validatorType = "visitor";
/*     */     
/* 504 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 506 */     if (fieldName != null) {
/* 507 */       params.put("fieldName", fieldName);
/* 508 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 509 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 512 */     params.put("context", v.context());
/* 513 */     params.put("appendPrefix", String.valueOf(v.appendPrefix()));
/*     */     
/* 515 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 516 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processUrlValidatorAnnotation(UrlValidator v, String fieldName, String methodName) {
/* 527 */     String validatorType = "url";
/*     */     
/* 529 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 531 */     if (fieldName != null) {
/* 532 */       params.put("fieldName", fieldName);
/* 533 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 534 */       params.put("fieldName", v.fieldName());
/*     */     } 
/* 536 */     if (StringUtils.isNotEmpty(v.urlRegex())) {
/* 537 */       params.put("urlRegex", v.urlRegex());
/*     */     }
/* 539 */     if (StringUtils.isNotEmpty(v.urlRegexExpression())) {
/* 540 */       params.put("urlRegexExpression", v.urlRegexExpression());
/*     */     }
/*     */     
/* 543 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 544 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processStringLengthFieldValidatorAnnotation(StringLengthFieldValidator v, String fieldName, String methodName) {
/* 555 */     String validatorType = "stringlength";
/*     */     
/* 557 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 559 */     if (fieldName != null) {
/* 560 */       params.put("fieldName", fieldName);
/* 561 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 562 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 565 */     if (StringUtils.isNotEmpty(v.maxLength())) {
/* 566 */       params.put("maxLength", v.maxLength());
/*     */     }
/* 568 */     if (StringUtils.isNotEmpty(v.minLength())) {
/* 569 */       params.put("minLength", v.minLength());
/*     */     }
/* 571 */     if (StringUtils.isNotEmpty(v.maxLengthExpression())) {
/* 572 */       params.put("maxLengthExpression", v.maxLengthExpression());
/*     */     }
/* 574 */     if (StringUtils.isNotEmpty(v.minLengthExpression())) {
/* 575 */       params.put("minLengthExpression", v.minLengthExpression());
/*     */     }
/* 577 */     if (StringUtils.isNotEmpty(v.trimExpression())) {
/* 578 */       params.put("trimExpression", v.trimExpression());
/*     */     } else {
/* 580 */       params.put("trim", String.valueOf(v.trim()));
/*     */     } 
/* 582 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 583 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Date parseDateString(String value, String format) {
/* 595 */     SimpleDateFormat d0 = null;
/* 596 */     if (StringUtils.isNotEmpty(format)) {
/* 597 */       d0 = new SimpleDateFormat(format);
/*     */     }
/* 599 */     SimpleDateFormat d1 = (SimpleDateFormat)DateFormat.getDateTimeInstance(3, 1, Locale.getDefault());
/* 600 */     SimpleDateFormat d2 = (SimpleDateFormat)DateFormat.getDateTimeInstance(3, 2, Locale.getDefault());
/* 601 */     SimpleDateFormat d3 = (SimpleDateFormat)DateFormat.getDateTimeInstance(3, 3, Locale.getDefault());
/* 602 */     (new SimpleDateFormat[4])[0] = d0; (new SimpleDateFormat[4])[1] = d1; (new SimpleDateFormat[4])[2] = d2; (new SimpleDateFormat[4])[3] = d3; (new SimpleDateFormat[3])[0] = d1; (new SimpleDateFormat[3])[1] = d2; (new SimpleDateFormat[3])[2] = d3; SimpleDateFormat[] dfs = (d0 != null) ? new SimpleDateFormat[4] : new SimpleDateFormat[3];
/* 603 */     for (SimpleDateFormat df : dfs) {
/*     */       try {
/* 605 */         Date check = df.parse(value);
/* 606 */         if (check != null) {
/* 607 */           return check;
/*     */         }
/* 609 */       } catch (ParseException parseException) {}
/*     */     } 
/* 611 */     return null;
/*     */   }
/*     */   
/*     */   private ValidatorConfig processRequiredStringValidatorAnnotation(RequiredStringValidator v, String fieldName, String methodName) {
/* 615 */     String validatorType = "requiredstring";
/*     */     
/* 617 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 619 */     if (fieldName != null) {
/* 620 */       params.put("fieldName", fieldName);
/* 621 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 622 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 625 */     params.put("trim", String.valueOf(v.trim()));
/*     */     
/* 627 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 628 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageParams(v.messageParams()).messageKey(v.key()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processRequiredFieldValidatorAnnotation(RequiredFieldValidator v, String fieldName, String methodName) {
/* 639 */     String validatorType = "required";
/*     */     
/* 641 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 643 */     if (fieldName != null) {
/* 644 */       params.put("fieldName", fieldName);
/* 645 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 646 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 649 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 650 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processIntRangeFieldValidatorAnnotation(IntRangeFieldValidator v, String fieldName, String methodName) {
/* 661 */     String validatorType = "int";
/*     */     
/* 663 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 665 */     if (fieldName != null) {
/* 666 */       params.put("fieldName", fieldName);
/* 667 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 668 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 671 */     if (v.min() != null && v.min().length() > 0) {
/* 672 */       params.put("min", v.min());
/*     */     }
/* 674 */     if (v.max() != null && v.max().length() > 0) {
/* 675 */       params.put("max", v.max());
/*     */     }
/* 677 */     if (StringUtils.isNotEmpty(v.maxExpression())) {
/* 678 */       params.put("maxExpression", v.maxExpression());
/*     */     }
/* 680 */     if (StringUtils.isNotEmpty(v.minExpression())) {
/* 681 */       params.put("minExpression", v.minExpression());
/*     */     }
/*     */     
/* 684 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 685 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processLongRangeFieldValidatorAnnotation(LongRangeFieldValidator v, String fieldName, String methodName) {
/* 696 */     String validatorType = "long";
/*     */     
/* 698 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 700 */     if (fieldName != null) {
/* 701 */       params.put("fieldName", fieldName);
/* 702 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 703 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 706 */     if (v.min() != null && v.min().length() > 0) {
/* 707 */       params.put("min", v.min());
/*     */     }
/* 709 */     if (v.max() != null && v.max().length() > 0) {
/* 710 */       params.put("max", v.max());
/*     */     }
/* 712 */     if (StringUtils.isNotEmpty(v.maxExpression())) {
/* 713 */       params.put("maxExpression", v.maxExpression());
/*     */     }
/* 715 */     if (StringUtils.isNotEmpty(v.minExpression())) {
/* 716 */       params.put("minExpression", v.minExpression());
/*     */     }
/*     */     
/* 719 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 720 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processShortRangeFieldValidatorAnnotation(ShortRangeFieldValidator v, String fieldName, String methodName) {
/* 731 */     String validatorType = "short";
/*     */     
/* 733 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 735 */     if (fieldName != null) {
/* 736 */       params.put("fieldName", fieldName);
/* 737 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 738 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 741 */     if (StringUtils.isNotEmpty(v.min())) {
/* 742 */       params.put("min", v.min());
/*     */     }
/* 744 */     if (StringUtils.isNotEmpty(v.max())) {
/* 745 */       params.put("max", v.max());
/*     */     }
/* 747 */     if (StringUtils.isNotEmpty(v.maxExpression())) {
/* 748 */       params.put("maxExpression", v.maxExpression());
/*     */     }
/* 750 */     if (StringUtils.isNotEmpty(v.minExpression())) {
/* 751 */       params.put("minExpression", v.minExpression());
/*     */     }
/*     */     
/* 754 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 755 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processDoubleRangeFieldValidatorAnnotation(DoubleRangeFieldValidator v, String fieldName, String methodName) {
/* 766 */     String validatorType = "double";
/*     */     
/* 768 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 770 */     if (fieldName != null) {
/* 771 */       params.put("fieldName", fieldName);
/* 772 */     } else if (v.fieldName() != null && v.fieldName().length() > 0) {
/* 773 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 776 */     if (v.minInclusive() != null && v.minInclusive().length() > 0) {
/* 777 */       params.put("minInclusive", v.minInclusive());
/*     */     }
/* 779 */     if (v.maxInclusive() != null && v.maxInclusive().length() > 0) {
/* 780 */       params.put("maxInclusive", v.maxInclusive());
/*     */     }
/*     */     
/* 783 */     if (v.minExclusive() != null && v.minExclusive().length() > 0) {
/* 784 */       params.put("minExclusive", v.minExclusive());
/*     */     }
/* 786 */     if (v.maxExclusive() != null && v.maxExclusive().length() > 0) {
/* 787 */       params.put("maxExclusive", v.maxExclusive());
/*     */     }
/*     */     
/* 790 */     if (StringUtils.isNotEmpty(v.minInclusiveExpression())) {
/* 791 */       params.put("minInclusiveExpression", v.minInclusiveExpression());
/*     */     }
/* 793 */     if (StringUtils.isNotEmpty(v.maxInclusiveExpression())) {
/* 794 */       params.put("maxInclusiveExpression", v.maxInclusiveExpression());
/*     */     }
/*     */     
/* 797 */     if (StringUtils.isNotEmpty(v.minExclusiveExpression())) {
/* 798 */       params.put("minExclusiveExpression", v.minExclusiveExpression());
/*     */     }
/* 800 */     if (StringUtils.isNotEmpty(v.maxExclusiveExpression())) {
/* 801 */       params.put("maxExclusiveExpression", v.maxExclusiveExpression());
/*     */     }
/*     */     
/* 804 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 805 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processFieldExpressionValidatorAnnotation(FieldExpressionValidator v, String fieldName, String methodName) {
/* 816 */     String validatorType = "fieldexpression";
/*     */     
/* 818 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 820 */     if (fieldName != null) {
/* 821 */       params.put("fieldName", fieldName);
/* 822 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 823 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 826 */     params.put("expression", v.expression());
/*     */     
/* 828 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 829 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processEmailValidatorAnnotation(EmailValidator v, String fieldName, String methodName) {
/* 840 */     String validatorType = "email";
/*     */     
/* 842 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 844 */     if (fieldName != null) {
/* 845 */       params.put("fieldName", fieldName);
/* 846 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 847 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 850 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 851 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processCreditCardValidatorAnnotation(CreditCardValidator v, String fieldName, String methodName) {
/* 862 */     String validatorType = "creditcard";
/*     */     
/* 864 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 866 */     if (fieldName != null) {
/* 867 */       params.put("fieldName", fieldName);
/* 868 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 869 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 872 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 873 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processDateRangeFieldValidatorAnnotation(DateRangeFieldValidator v, String fieldName, String methodName) {
/* 884 */     String validatorType = "date";
/*     */     
/* 886 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 888 */     if (fieldName != null) {
/* 889 */       params.put("fieldName", fieldName);
/* 890 */     } else if (v.fieldName() != null && v.fieldName().length() > 0) {
/* 891 */       params.put("fieldName", v.fieldName());
/*     */     } 
/* 893 */     if (v.min() != null && v.min().length() > 0) {
/* 894 */       Date minDate = parseDateString(v.min(), v.dateFormat());
/* 895 */       params.put("min", (minDate == null) ? v.min() : minDate);
/*     */     } 
/* 897 */     if (v.max() != null && v.max().length() > 0) {
/* 898 */       Date maxDate = parseDateString(v.max(), v.dateFormat());
/* 899 */       params.put("max", (maxDate == null) ? v.max() : maxDate);
/*     */     } 
/*     */     
/* 902 */     if (StringUtils.isNotEmpty(v.minExpression())) {
/* 903 */       params.put("minExpression", v.minExpression());
/*     */     }
/* 905 */     if (StringUtils.isNotEmpty(v.maxExpression())) {
/* 906 */       params.put("maxExpression", v.maxExpression());
/*     */     }
/*     */     
/* 909 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 910 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidatorConfig processConversionErrorFieldValidatorAnnotation(ConversionErrorFieldValidator v, String fieldName, String methodName) {
/* 921 */     String validatorType = "conversion";
/*     */     
/* 923 */     Map<String, Object> params = new HashMap<>();
/*     */     
/* 925 */     if (fieldName != null) {
/* 926 */       params.put("fieldName", fieldName);
/* 927 */     } else if (StringUtils.isNotEmpty(v.fieldName())) {
/* 928 */       params.put("fieldName", v.fieldName());
/*     */     } 
/*     */     
/* 931 */     this.validatorFactory.lookupRegisteredValidatorType(validatorType);
/* 932 */     return (new ValidatorConfig.Builder(validatorType)).addParams(params).addParam("methodName", methodName).addParam("repopulateField", Boolean.valueOf(v.repopulateField())).shortCircuit(v.shortCircuit()).defaultMessage(v.message()).messageKey(v.key()).messageParams(v.messageParams()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ValidatorConfig> buildAnnotationClassValidatorConfigs(Class aClass) {
/* 945 */     List<ValidatorConfig> result = new ArrayList<>();
/*     */     
/* 947 */     List<ValidatorConfig> temp = processAnnotations(aClass);
/* 948 */     if (temp != null) {
/* 949 */       result.addAll(temp);
/*     */     }
/*     */     
/* 952 */     Method[] methods = aClass.getDeclaredMethods();
/*     */     
/* 954 */     if (methods != null) {
/* 955 */       for (Method method : methods) {
/* 956 */         temp = processAnnotations(method);
/* 957 */         if (temp != null) {
/* 958 */           result.addAll(temp);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 963 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\AnnotationValidationConfigurationBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */