/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegexFieldValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*  91 */   private static final Logger LOG = LogManager.getLogger(RegexFieldValidator.class);
/*     */   
/*     */   private String regex;
/*     */   private String regexExpression;
/*  95 */   private Boolean caseSensitive = Boolean.valueOf(true);
/*  96 */   private String caseSensitiveExpression = "";
/*  97 */   private Boolean trim = Boolean.valueOf(true);
/*  98 */   private String trimExpression = "";
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/* 101 */     String fieldName = getFieldName();
/* 102 */     Object value = getFieldValue(fieldName, object);
/*     */ 
/*     */     
/* 105 */     String regexToUse = getRegex();
/* 106 */     LOG.debug("Defined regexp as [{}]", regexToUse);
/*     */     
/* 108 */     if (value == null || regexToUse == null) {
/* 109 */       LOG.debug("Either value is empty (please use a required validator) or regex is empty");
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     if (value.getClass().isArray()) {
/* 114 */       Object[] values = (Object[])value;
/* 115 */       for (Object objValue : values) {
/* 116 */         validateFieldValue(object, Objects.toString(objValue, ""), regexToUse);
/*     */       }
/* 118 */     } else if (Collection.class.isAssignableFrom(value.getClass())) {
/* 119 */       Collection values = (Collection)value;
/* 120 */       for (Object objValue : values) {
/* 121 */         validateFieldValue(object, Objects.toString(objValue, ""), regexToUse);
/*     */       }
/*     */     } else {
/* 124 */       validateFieldValue(object, Objects.toString(value, ""), regexToUse);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateFieldValue(Object object, String value, String regexToUse) {
/*     */     Pattern pattern;
/* 130 */     String str = value.trim();
/* 131 */     if (str.length() == 0) {
/* 132 */       LOG.debug("Value is empty, please use a required validator");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 138 */     if (isCaseSensitive()) {
/* 139 */       pattern = Pattern.compile(regexToUse);
/*     */     } else {
/* 141 */       pattern = Pattern.compile(regexToUse, 2);
/*     */     } 
/*     */     
/* 144 */     String compare = value;
/* 145 */     if (isTrimed()) {
/* 146 */       compare = compare.trim();
/*     */     }
/*     */     
/*     */     try {
/* 150 */       setCurrentValue(compare);
/* 151 */       Matcher matcher = pattern.matcher(compare);
/* 152 */       if (!matcher.matches()) {
/* 153 */         addFieldError(this.fieldName, object);
/*     */       }
/*     */     } finally {
/* 156 */       setCurrentValue((Object)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegex() {
/* 164 */     if (StringUtils.isNotEmpty(this.regex))
/* 165 */       return this.regex; 
/* 166 */     if (StringUtils.isNotEmpty(this.regexExpression)) {
/* 167 */       return (String)parse(this.regexExpression, String.class);
/*     */     }
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegex(String regex) {
/* 177 */     this.regex = regex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegexExpression(String regexExpression) {
/* 184 */     this.regexExpression = regexExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive() {
/* 192 */     if (StringUtils.isNotEmpty(this.caseSensitiveExpression)) {
/* 193 */       return ((Boolean)parse(this.caseSensitiveExpression, Boolean.class)).booleanValue();
/*     */     }
/* 195 */     return this.caseSensitive.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCaseSensitive(Boolean caseSensitive) {
/* 203 */     this.caseSensitive = caseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCaseSensitiveExpression(String caseSensitiveExpression) {
/* 210 */     this.caseSensitiveExpression = caseSensitiveExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrimed() {
/* 218 */     if (StringUtils.isNotEmpty(this.trimExpression)) {
/* 219 */       return ((Boolean)parse(this.trimExpression, Boolean.class)).booleanValue();
/*     */     }
/* 221 */     return this.trim.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrim(Boolean trim) {
/* 229 */     this.trim = trim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrimExpression(String trimExpression) {
/* 238 */     this.trimExpression = trimExpression;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\RegexFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */