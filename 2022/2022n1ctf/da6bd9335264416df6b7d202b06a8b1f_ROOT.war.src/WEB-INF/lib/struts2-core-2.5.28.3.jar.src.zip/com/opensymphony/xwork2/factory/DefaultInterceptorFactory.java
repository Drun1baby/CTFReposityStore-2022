/*    */ package com.opensymphony.xwork2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.entities.InterceptorConfig;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*    */ import com.opensymphony.xwork2.interceptor.WithLazyParams;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultInterceptorFactory
/*    */   implements InterceptorFactory
/*    */ {
/* 39 */   private static final Logger LOG = LogManager.getLogger(DefaultInterceptorFactory.class);
/*    */   
/*    */   private ObjectFactory objectFactory;
/*    */   private ReflectionProvider reflectionProvider;
/*    */   
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 46 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 51 */     this.reflectionProvider = reflectionProvider;
/*    */   } public Interceptor buildInterceptor(InterceptorConfig interceptorConfig, Map<String, String> interceptorRefParams) throws ConfigurationException {
/*    */     String message;
/*    */     Throwable cause;
/* 55 */     String interceptorClassName = interceptorConfig.getClassName();
/* 56 */     Map<String, String> thisInterceptorClassParams = interceptorConfig.getParams();
/* 57 */     Map<String, String> params = (thisInterceptorClassParams == null) ? new HashMap<>() : new HashMap<>(thisInterceptorClassParams);
/* 58 */     params.putAll(interceptorRefParams);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 65 */       Object o = this.objectFactory.buildBean(interceptorClassName, null);
/* 66 */       if (o instanceof WithLazyParams) {
/* 67 */         LOG.debug("Interceptor {} is marked with interface {} and params will be set during action invocation", interceptorClassName, WithLazyParams.class.getName());
/*    */       } else {
/*    */         
/* 70 */         this.reflectionProvider.setProperties(params, o);
/*    */       } 
/*    */       
/* 73 */       if (o instanceof Interceptor) {
/* 74 */         Interceptor interceptor = (Interceptor)o;
/* 75 */         interceptor.init();
/* 76 */         return interceptor;
/*    */       } 
/*    */       
/* 79 */       throw new ConfigurationException("Class [" + interceptorClassName + "] does not implement Interceptor", interceptorConfig);
/* 80 */     } catch (InstantiationException e) {
/* 81 */       cause = e;
/* 82 */       message = "Unable to instantiate an instance of Interceptor class [" + interceptorClassName + "].";
/* 83 */     } catch (IllegalAccessException e) {
/* 84 */       cause = e;
/* 85 */       message = "IllegalAccessException while attempting to instantiate an instance of Interceptor class [" + interceptorClassName + "].";
/* 86 */     } catch (ClassCastException e) {
/* 87 */       cause = e;
/* 88 */       message = "Class [" + interceptorClassName + "] does not implement com.opensymphony.xwork2.interceptor.Interceptor";
/* 89 */     } catch (Exception e) {
/* 90 */       cause = e;
/* 91 */       message = "Caught Exception while registering Interceptor class " + interceptorClassName;
/* 92 */     } catch (NoClassDefFoundError e) {
/* 93 */       cause = e;
/* 94 */       message = "Could not load class " + interceptorClassName + ". Perhaps it exists but certain dependencies are not available?";
/*    */     } 
/*    */     
/* 97 */     throw new ConfigurationException(message, cause, interceptorConfig);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\DefaultInterceptorFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */