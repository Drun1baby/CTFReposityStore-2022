/*    */ package com.opensymphony.xwork2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import com.opensymphony.xwork2.validator.Validator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultValidatorFactory
/*    */   implements ValidatorFactory
/*    */ {
/*    */   private ObjectFactory objectFactory;
/*    */   private ReflectionProvider reflectionProvider;
/*    */   
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 38 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 43 */     this.reflectionProvider = reflectionProvider;
/*    */   }
/*    */   
/*    */   public Validator buildValidator(String className, Map<String, Object> params, Map<String, Object> extraContext) throws Exception {
/* 47 */     Validator validator = (Validator)this.objectFactory.buildBean(className, extraContext);
/* 48 */     this.reflectionProvider.setProperties(params, validator, extraContext);
/*    */     
/* 50 */     return validator;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\DefaultValidatorFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */