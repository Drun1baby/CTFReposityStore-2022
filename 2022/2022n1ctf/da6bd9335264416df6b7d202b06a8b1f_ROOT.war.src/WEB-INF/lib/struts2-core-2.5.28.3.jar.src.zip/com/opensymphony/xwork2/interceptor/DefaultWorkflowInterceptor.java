/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.annotations.InputConfig;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.lang3.reflect.MethodUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultWorkflowInterceptor
/*     */   extends MethodFilterInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 7563014655616490865L;
/* 137 */   private static final Logger LOG = LogManager.getLogger(DefaultWorkflowInterceptor.class);
/*     */   
/* 139 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */   
/* 141 */   private String inputResultName = "input";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputResultName(String inputResultName) {
/* 150 */     this.inputResultName = inputResultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String doIntercept(ActionInvocation invocation) throws Exception {
/* 162 */     Object action = invocation.getAction();
/*     */     
/* 164 */     if (action instanceof ValidationAware) {
/* 165 */       ValidationAware validationAwareAction = (ValidationAware)action;
/*     */       
/* 167 */       if (validationAwareAction.hasErrors()) {
/* 168 */         LOG.debug("Errors on action [{}], returning result name [{}]", validationAwareAction, this.inputResultName);
/*     */         
/* 170 */         String resultName = this.inputResultName;
/* 171 */         resultName = processValidationWorkflowAware(action, resultName);
/* 172 */         resultName = processInputConfig(action, invocation.getProxy().getMethod(), resultName);
/* 173 */         resultName = processValidationErrorAware(action, resultName);
/*     */         
/* 175 */         return resultName;
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String processValidationWorkflowAware(Object action, String currentResultName) {
/* 191 */     String resultName = currentResultName;
/* 192 */     if (action instanceof ValidationWorkflowAware) {
/* 193 */       resultName = ((ValidationWorkflowAware)action).getInputResultName();
/* 194 */       LOG.debug("Changing result name from [{}] to [{}] because of processing [{}] interface applied to [{}]", currentResultName, resultName, ValidationWorkflowAware.class.getSimpleName(), action);
/*     */     } 
/*     */     
/* 197 */     return resultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processInputConfig(Object action, String method, String currentResultName) throws Exception {
/* 211 */     String resultName = currentResultName;
/* 212 */     InputConfig annotation = (InputConfig)MethodUtils.getAnnotation(action.getClass().getMethod(method, EMPTY_CLASS_ARRAY), InputConfig.class, true, true);
/*     */     
/* 214 */     if (annotation != null) {
/* 215 */       if (StringUtils.isNotEmpty(annotation.methodName())) {
/* 216 */         resultName = (String)MethodUtils.invokeMethod(action, true, annotation.methodName());
/*     */       } else {
/* 218 */         resultName = annotation.resultName();
/*     */       } 
/* 220 */       LOG.debug("Changing result name from [{}] to [{}] because of processing annotation [{}] on action [{}]", currentResultName, resultName, InputConfig.class.getSimpleName(), action);
/*     */     } 
/*     */     
/* 223 */     return resultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processValidationErrorAware(Object action, String currentResultName) {
/* 236 */     String resultName = currentResultName;
/* 237 */     if (action instanceof ValidationErrorAware) {
/* 238 */       resultName = ((ValidationErrorAware)action).actionErrorOccurred(currentResultName);
/* 239 */       LOG.debug("Changing result name from [{}] to [{}] because of processing interface [{}] on action [{}]", currentResultName, resultName, ValidationErrorAware.class.getSimpleName(), action);
/*     */     } 
/*     */     
/* 242 */     return resultName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\DefaultWorkflowInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */