/*    */ package com.opensymphony.xwork2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.UnknownHandler;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultUnknownHandlerFactory
/*    */   implements UnknownHandlerFactory
/*    */ {
/*    */   private Container container;
/*    */   
/*    */   @Inject
/*    */   public void setContainer(Container container) {
/* 36 */     this.container = container;
/*    */   }
/*    */   
/*    */   public UnknownHandler buildUnknownHandler(String unknownHandlerName, Map<String, Object> extraContext) throws Exception {
/* 40 */     return (UnknownHandler)this.container.getInstance(UnknownHandler.class, unknownHandlerName);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\DefaultUnknownHandlerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */