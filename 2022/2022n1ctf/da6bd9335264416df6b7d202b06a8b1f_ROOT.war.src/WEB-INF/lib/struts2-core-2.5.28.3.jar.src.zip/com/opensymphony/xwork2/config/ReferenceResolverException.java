/*    */ package com.opensymphony.xwork2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.XWorkException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ReferenceResolverException
/*    */   extends XWorkException
/*    */ {
/*    */   public ReferenceResolverException() {}
/*    */   
/*    */   public ReferenceResolverException(String s) {
/* 39 */     super(s);
/*    */   }
/*    */   
/*    */   public ReferenceResolverException(String s, Throwable cause) {
/* 43 */     super(s, cause);
/*    */   }
/*    */   
/*    */   public ReferenceResolverException(Throwable cause) {
/* 47 */     super(cause);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\ReferenceResolverException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */