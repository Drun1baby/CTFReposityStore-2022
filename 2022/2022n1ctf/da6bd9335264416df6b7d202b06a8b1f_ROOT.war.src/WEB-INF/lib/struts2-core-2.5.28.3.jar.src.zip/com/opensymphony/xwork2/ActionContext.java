/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionContext
/*     */   implements Serializable
/*     */ {
/*  53 */   static ThreadLocal<ActionContext> actionContext = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ACTION_NAME = "com.opensymphony.xwork2.ActionContext.name";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String VALUE_STACK = "com.opensymphony.xwork2.util.ValueStack.ValueStack";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SESSION = "com.opensymphony.xwork2.ActionContext.session";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String APPLICATION = "com.opensymphony.xwork2.ActionContext.application";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PARAMETERS = "com.opensymphony.xwork2.ActionContext.parameters";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOCALE = "com.opensymphony.xwork2.ActionContext.locale";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TYPE_CONVERTER = "com.opensymphony.xwork2.ActionContext.typeConverter";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ACTION_INVOCATION = "com.opensymphony.xwork2.ActionContext.actionInvocation";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONVERSION_ERRORS = "com.opensymphony.xwork2.ActionContext.conversionErrors";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String CONTAINER = "com.opensymphony.xwork2.ActionContext.container";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> context;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionContext(Map<String, Object> context) {
/* 114 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActionInvocation(ActionInvocation actionInvocation) {
/* 124 */     put("com.opensymphony.xwork2.ActionContext.actionInvocation", actionInvocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionInvocation getActionInvocation() {
/* 133 */     return (ActionInvocation)get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplication(Map<String, Object> application) {
/* 142 */     put("com.opensymphony.xwork2.ActionContext.application", application);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getApplication() {
/* 151 */     return (Map<String, Object>)get("com.opensymphony.xwork2.ActionContext.application");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContext(ActionContext context) {
/* 160 */     actionContext.set(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ActionContext getContext() {
/* 169 */     return actionContext.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextMap(Map<String, Object> contextMap) {
/* 178 */     (getContext()).context = contextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getContextMap() {
/* 187 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConversionErrors(Map<String, Object> conversionErrors) {
/* 196 */     put("com.opensymphony.xwork2.ActionContext.conversionErrors", conversionErrors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getConversionErrors() {
/* 206 */     Map<String, Object> errors = (Map<String, Object>)get("com.opensymphony.xwork2.ActionContext.conversionErrors");
/*     */     
/* 208 */     if (errors == null) {
/* 209 */       errors = new HashMap<>();
/* 210 */       setConversionErrors(errors);
/*     */     } 
/*     */     
/* 213 */     return errors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 222 */     put("com.opensymphony.xwork2.ActionContext.locale", locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 232 */     Locale locale = (Locale)get("com.opensymphony.xwork2.ActionContext.locale");
/*     */     
/* 234 */     if (locale == null) {
/* 235 */       locale = Locale.getDefault();
/* 236 */       setLocale(locale);
/*     */     } 
/*     */     
/* 239 */     return locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 248 */     put("com.opensymphony.xwork2.ActionContext.name", name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 257 */     return (String)get("com.opensymphony.xwork2.ActionContext.name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(HttpParameters parameters) {
/* 266 */     put("com.opensymphony.xwork2.ActionContext.parameters", parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpParameters getParameters() {
/* 277 */     return (HttpParameters)get("com.opensymphony.xwork2.ActionContext.parameters");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSession(Map<String, Object> session) {
/* 286 */     put("com.opensymphony.xwork2.ActionContext.session", session);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getSession() {
/* 295 */     return (Map<String, Object>)get("com.opensymphony.xwork2.ActionContext.session");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueStack(ValueStack stack) {
/* 304 */     put("com.opensymphony.xwork2.util.ValueStack.ValueStack", stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueStack getValueStack() {
/* 313 */     return (ValueStack)get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainer(Container cont) {
/* 322 */     put("com.opensymphony.xwork2.ActionContext.container", cont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/* 331 */     return (Container)get("com.opensymphony.xwork2.ActionContext.container");
/*     */   }
/*     */   
/*     */   public <T> T getInstance(Class<T> type) {
/* 335 */     Container cont = getContainer();
/* 336 */     if (cont != null) {
/* 337 */       return (T)cont.getInstance(type);
/*     */     }
/* 339 */     throw new XWorkException("Cannot find an initialized container for this request.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String key) {
/* 350 */     return this.context.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String key, Object value) {
/* 360 */     this.context.put(key, value);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ActionContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */