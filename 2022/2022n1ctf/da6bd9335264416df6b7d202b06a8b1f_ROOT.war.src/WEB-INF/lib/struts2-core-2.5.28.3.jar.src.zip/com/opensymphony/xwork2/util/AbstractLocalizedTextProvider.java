/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.LocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractLocalizedTextProvider
/*     */   implements LocalizedTextProvider
/*     */ {
/*  48 */   private static final Logger LOG = LogManager.getLogger(AbstractLocalizedTextProvider.class);
/*     */   
/*     */   public static final String XWORK_MESSAGES_BUNDLE = "com/opensymphony/xwork2/xwork-messages";
/*     */   
/*     */   public static final String STRUTS_MESSAGES_BUNDLE = "org/apache/struts2/struts-messages";
/*     */   
/*     */   private static final String TOMCAT_RESOURCE_ENTRIES_FIELD = "resourceEntries";
/*     */   private static final String RELOADED = "com.opensymphony.xwork2.util.LocalizedTextProvider.reloaded";
/*  56 */   protected final ConcurrentMap<String, ResourceBundle> bundlesMap = new ConcurrentHashMap<>();
/*     */   
/*     */   protected boolean devMode = false;
/*     */   protected boolean reloadBundles = false;
/*  60 */   private final ConcurrentMap<MessageFormatKey, MessageFormat> messageFormats = new ConcurrentHashMap<>();
/*  61 */   private final ConcurrentMap<Integer, List<String>> classLoaderMap = new ConcurrentHashMap<>();
/*  62 */   private final ConcurrentMap<String, Boolean> missingBundles = new ConcurrentHashMap<>();
/*  63 */   private final ConcurrentMap<Integer, ClassLoader> delegatedClassLoaderMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefaultResourceBundle(String resourceBundleName) {
/*  74 */     ClassLoader ccl = getCurrentThreadContextClassLoader();
/*  75 */     synchronized ("com/opensymphony/xwork2/xwork-messages") {
/*  76 */       List<String> bundles = this.classLoaderMap.get(Integer.valueOf(ccl.hashCode()));
/*  77 */       if (bundles == null) {
/*  78 */         bundles = new CopyOnWriteArrayList<>();
/*  79 */         this.classLoaderMap.put(Integer.valueOf(ccl.hashCode()), bundles);
/*     */       } 
/*  81 */       bundles.remove(resourceBundleName);
/*  82 */       bundles.add(0, resourceBundleName);
/*     */     } 
/*     */     
/*  85 */     if (LOG.isDebugEnabled()) {
/*  86 */       LOG.debug("Added default resource bundle '{}' to default resource bundles for the following classloader '{}'", resourceBundleName, ccl.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<String> getCurrentBundleNames() {
/*  91 */     return this.classLoaderMap.get(Integer.valueOf(getCurrentThreadContextClassLoader().hashCode()));
/*     */   }
/*     */   
/*     */   protected ClassLoader getCurrentThreadContextClassLoader() {
/*  95 */     return Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.custom.i18n.resources", required = false)
/*     */   public void setCustomI18NResources(String bundles) {
/* 100 */     if (bundles != null && bundles.length() > 0) {
/* 101 */       StringTokenizer customBundles = new StringTokenizer(bundles, ", ");
/*     */       
/* 103 */       while (customBundles.hasMoreTokens()) {
/* 104 */         String name = customBundles.nextToken();
/*     */         try {
/* 106 */           LOG.trace("Loading global messages from [{}]", name);
/* 107 */           addDefaultResourceBundle(name);
/* 108 */         } catch (Exception e) {
/* 109 */           LOG.error((Message)new ParameterizedMessage("Could not find messages file {}.properties. Skipping", name), e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findDefaultText(String aTextName, Locale locale) {
/* 125 */     List<String> localList = getCurrentBundleNames();
/*     */     
/* 127 */     for (String bundleName : localList) {
/* 128 */       ResourceBundle bundle = findResourceBundle(bundleName, locale);
/* 129 */       if (bundle != null) {
/* 130 */         reloadBundles();
/*     */         try {
/* 132 */           return bundle.getString(aTextName);
/* 133 */         } catch (MissingResourceException missingResourceException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 139 */     if (this.devMode) {
/* 140 */       LOG.warn("Missing key [{}] in bundles [{}]!", aTextName, localList);
/*     */     } else {
/* 142 */       LOG.debug("Missing key [{}] in bundles [{}]!", aTextName, localList);
/*     */     } 
/*     */     
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findDefaultText(String aTextName, Locale locale, Object[] params) {
/* 159 */     String defaultText = findDefaultText(aTextName, locale);
/* 160 */     if (defaultText != null) {
/* 161 */       MessageFormat mf = buildMessageFormat(defaultText, locale);
/* 162 */       return formatWithNullDetection(mf, params);
/*     */     } 
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(ResourceBundle bundle, String aTextName, Locale locale, String defaultMessage, Object[] args, ValueStack valueStack) {
/*     */     try {
/* 195 */       reloadBundles(valueStack.getContext());
/*     */       
/* 197 */       String message = TextParseUtil.translateVariables(bundle.getString(aTextName), valueStack);
/* 198 */       MessageFormat mf = buildMessageFormat(message, locale);
/*     */       
/* 200 */       return formatWithNullDetection(mf, args);
/* 201 */     } catch (MissingResourceException ex) {
/* 202 */       if (this.devMode) {
/* 203 */         LOG.warn("Missing key [{}] in bundle [{}]!", aTextName, bundle);
/*     */       } else {
/* 205 */         LOG.debug("Missing key [{}] in bundle [{}]!", aTextName, bundle);
/*     */       } 
/*     */ 
/*     */       
/* 209 */       GetDefaultMessageReturnArg result = getDefaultMessage(aTextName, locale, valueStack, args, defaultMessage);
/* 210 */       if (unableToFindTextForKey(result)) {
/* 211 */         LOG.warn("Unable to find text for key '{}' in ResourceBundles for locale '{}'", aTextName, locale);
/*     */       }
/* 213 */       return (result != null) ? result.message : null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelegatedClassLoader(ClassLoader classLoader) {
/* 220 */     synchronized (this.bundlesMap) {
/* 221 */       this.delegatedClassLoaderMap.put(Integer.valueOf(getCurrentThreadContextClassLoader().hashCode()), classLoader);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearBundle(String bundleName) {
/* 235 */     ResourceBundle removedBundle = this.bundlesMap.remove(getCurrentThreadContextClassLoader().hashCode() + bundleName);
/* 236 */     LOG.debug("Clearing resource bundle [{}], result: [{}].", bundleName, Boolean.valueOf((removedBundle != null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearBundle(String bundleName, Locale locale) {
/* 247 */     String key = createMissesKey(String.valueOf(getCurrentThreadContextClassLoader().hashCode()), bundleName, locale);
/* 248 */     ResourceBundle removedBundle = this.bundlesMap.remove(key);
/* 249 */     LOG.debug("Clearing resource bundle [{}], locale [{}], result: [{}].", bundleName, locale, Boolean.valueOf((removedBundle != null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearMissingBundlesCache() {
/* 263 */     this.missingBundles.clear();
/* 264 */     LOG.debug("Cleared the missing bundles cache.");
/*     */   }
/*     */   
/*     */   protected void reloadBundles() {
/* 268 */     reloadBundles((ActionContext.getContext() != null) ? ActionContext.getContext().getContextMap() : null);
/*     */   }
/*     */   
/*     */   protected void reloadBundles(Map<String, Object> context) {
/* 272 */     if (this.reloadBundles) {
/*     */       try {
/*     */         Boolean reloaded;
/* 275 */         if (context != null) {
/* 276 */           reloaded = (Boolean)ObjectUtils.defaultIfNull(context.get("com.opensymphony.xwork2.util.LocalizedTextProvider.reloaded"), Boolean.FALSE);
/*     */         } else {
/* 278 */           reloaded = Boolean.FALSE;
/*     */         } 
/* 280 */         if (!reloaded.booleanValue()) {
/* 281 */           this.bundlesMap.clear();
/*     */           try {
/* 283 */             clearMap(ResourceBundle.class, null, "cacheList");
/* 284 */           } catch (NoSuchFieldException e) {
/*     */ 
/*     */             
/* 287 */             clearMap(ResourceBundle.class, null, "cache");
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 292 */           clearTomcatCache();
/* 293 */           if (context != null) {
/* 294 */             context.put("com.opensymphony.xwork2.util.LocalizedTextProvider.reloaded", Boolean.valueOf(true));
/*     */           }
/* 296 */           LOG.debug("Resource bundles reloaded");
/*     */         } 
/* 298 */       } catch (Exception e) {
/* 299 */         LOG.error("Could not reload resource bundles", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void clearTomcatCache() {
/* 305 */     ClassLoader loader = getCurrentThreadContextClassLoader();
/*     */     
/* 307 */     Class<?> cl = loader.getClass();
/*     */     
/*     */     try {
/* 310 */       if ("org.apache.catalina.loader.WebappClassLoader".equals(cl.getName())) {
/* 311 */         clearMap(cl, loader, "resourceEntries");
/*     */       } else {
/* 313 */         LOG.debug("Class loader {} is not tomcat loader.", cl.getName());
/*     */       } 
/* 315 */     } catch (NoSuchFieldException nsfe) {
/* 316 */       if ("org.apache.catalina.loader.WebappClassLoaderBase".equals(cl.getSuperclass().getName())) {
/* 317 */         LOG.debug("Base class {} doesn't contain '{}' field, trying with parent!", cl.getName(), "resourceEntries", nsfe);
/*     */         try {
/* 319 */           clearMap(cl.getSuperclass(), loader, "resourceEntries");
/* 320 */         } catch (Exception e) {
/* 321 */           LOG.warn("Couldn't clear tomcat cache using {}", cl.getSuperclass().getName(), e);
/*     */         } 
/*     */       } 
/* 324 */     } catch (Exception e) {
/* 325 */       LOG.warn("Couldn't clear tomcat cache", cl.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearMap(Class cl, Object obj, String name) throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
/* 332 */     Field field = cl.getDeclaredField(name);
/* 333 */     field.setAccessible(true);
/*     */     
/* 335 */     Object cache = field.get(obj);
/*     */     
/* 337 */     synchronized (cache) {
/* 338 */       Class<?> ccl = cache.getClass();
/* 339 */       Method clearMethod = ccl.getMethod("clear", new Class[0]);
/* 340 */       clearMethod.invoke(cache, new Object[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected MessageFormat buildMessageFormat(String pattern, Locale locale) {
/* 345 */     MessageFormatKey key = new MessageFormatKey(pattern, locale);
/* 346 */     MessageFormat format = this.messageFormats.get(key);
/* 347 */     if (format == null) {
/* 348 */       format = new MessageFormat(pattern);
/* 349 */       format.setLocale(locale);
/* 350 */       format.applyPattern(pattern);
/* 351 */       this.messageFormats.put(key, format);
/*     */     } 
/*     */     
/* 354 */     return format;
/*     */   }
/*     */   
/*     */   protected String formatWithNullDetection(MessageFormat mf, Object[] args) {
/* 358 */     String message = mf.format(args);
/* 359 */     if ("null".equals(message)) {
/* 360 */       return null;
/*     */     }
/* 362 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   @Inject(value = "struts.i18n.reload", required = false)
/*     */   public void setReloadBundles(String reloadBundles) {
/* 368 */     this.reloadBundles = Boolean.parseBoolean(reloadBundles);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.devMode", required = false)
/*     */   public void setDevMode(String devMode) {
/* 373 */     this.devMode = Boolean.parseBoolean(devMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle findResourceBundle(String aBundleName, Locale locale) {
/* 388 */     ClassLoader classLoader = getCurrentThreadContextClassLoader();
/* 389 */     String key = createMissesKey(String.valueOf(classLoader.hashCode()), aBundleName, locale);
/*     */     
/* 391 */     if (this.missingBundles.containsKey(key)) {
/* 392 */       return null;
/*     */     }
/*     */     
/* 395 */     ResourceBundle bundle = null;
/*     */     try {
/* 397 */       if (this.bundlesMap.containsKey(key)) {
/* 398 */         bundle = this.bundlesMap.get(key);
/*     */       } else {
/* 400 */         bundle = ResourceBundle.getBundle(aBundleName, locale, classLoader);
/* 401 */         this.bundlesMap.putIfAbsent(key, bundle);
/*     */       } 
/* 403 */     } catch (MissingResourceException ex) {
/* 404 */       if (this.delegatedClassLoaderMap.containsKey(Integer.valueOf(classLoader.hashCode()))) {
/*     */         try {
/* 406 */           if (this.bundlesMap.containsKey(key)) {
/* 407 */             bundle = this.bundlesMap.get(key);
/*     */           } else {
/* 409 */             bundle = ResourceBundle.getBundle(aBundleName, locale, this.delegatedClassLoaderMap.get(Integer.valueOf(classLoader.hashCode())));
/* 410 */             this.bundlesMap.putIfAbsent(key, bundle);
/*     */           } 
/* 412 */         } catch (MissingResourceException e) {
/* 413 */           LOG.debug("Missing resource bundle [{}]!", aBundleName, e);
/* 414 */           this.missingBundles.putIfAbsent(key, Boolean.TRUE);
/*     */         } 
/*     */       } else {
/* 417 */         LOG.debug("Missing resource bundle [{}]!", aBundleName);
/* 418 */         this.missingBundles.putIfAbsent(key, Boolean.TRUE);
/*     */       } 
/*     */     } 
/* 421 */     return bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void reset() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean unableToFindTextForKey(GetDefaultMessageReturnArg result) {
/* 441 */     if (result == null || result.message == null) {
/* 442 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 446 */     if (result.foundInBundle) {
/* 447 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 451 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createMissesKey(String prefix, String aBundleName, Locale locale) {
/* 463 */     return prefix + aBundleName + "_" + locale.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GetDefaultMessageReturnArg getDefaultMessage(String key, Locale locale, ValueStack valueStack, Object[] args, String defaultMessage) {
/* 471 */     GetDefaultMessageReturnArg result = null;
/* 472 */     boolean found = true;
/*     */     
/* 474 */     if (key != null) {
/* 475 */       String message = findDefaultText(key, locale);
/*     */       
/* 477 */       if (message == null) {
/* 478 */         message = defaultMessage;
/* 479 */         found = false;
/*     */       } 
/*     */ 
/*     */       
/* 483 */       if (message != null) {
/* 484 */         MessageFormat mf = buildMessageFormat(TextParseUtil.translateVariables(message, valueStack), locale);
/*     */         
/* 486 */         String msg = formatWithNullDetection(mf, args);
/* 487 */         result = new GetDefaultMessageReturnArg(msg, found);
/*     */       } 
/*     */     } 
/*     */     
/* 491 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMessage(String bundleName, Locale locale, String key, ValueStack valueStack, Object[] args) {
/* 498 */     ResourceBundle bundle = findResourceBundle(bundleName, locale);
/* 499 */     if (bundle == null) {
/* 500 */       return null;
/*     */     }
/* 502 */     if (valueStack != null)
/* 503 */       reloadBundles(valueStack.getContext()); 
/*     */     try {
/* 505 */       String message = bundle.getString(key);
/* 506 */       if (valueStack != null)
/* 507 */         message = TextParseUtil.translateVariables(bundle.getString(key), valueStack); 
/* 508 */       MessageFormat mf = buildMessageFormat(message, locale);
/* 509 */       return formatWithNullDetection(mf, args);
/* 510 */     } catch (MissingResourceException e) {
/* 511 */       if (this.devMode) {
/* 512 */         LOG.warn("Missing key [{}] in bundle [{}]!", key, bundleName);
/*     */       } else {
/* 514 */         LOG.debug("Missing key [{}] in bundle [{}]!", key, bundleName);
/*     */       } 
/* 516 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String findMessage(Class clazz, String key, String indexedKey, Locale locale, Object[] args, Set<String> checked, ValueStack valueStack) {
/* 528 */     if (checked == null) {
/* 529 */       checked = new TreeSet<>();
/* 530 */     } else if (checked.contains(clazz.getName())) {
/* 531 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 535 */     String msg = getMessage(clazz.getName(), locale, key, valueStack, args);
/*     */     
/* 537 */     if (msg != null) {
/* 538 */       return msg;
/*     */     }
/*     */     
/* 541 */     if (indexedKey != null) {
/* 542 */       msg = getMessage(clazz.getName(), locale, indexedKey, valueStack, args);
/*     */       
/* 544 */       if (msg != null) {
/* 545 */         return msg;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 550 */     Class[] interfaces = clazz.getInterfaces();
/*     */     
/* 552 */     for (Class anInterface : interfaces) {
/* 553 */       msg = getMessage(anInterface.getName(), locale, key, valueStack, args);
/*     */       
/* 555 */       if (msg != null) {
/* 556 */         return msg;
/*     */       }
/*     */       
/* 559 */       if (indexedKey != null) {
/* 560 */         msg = getMessage(anInterface.getName(), locale, indexedKey, valueStack, args);
/*     */         
/* 562 */         if (msg != null) {
/* 563 */           return msg;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 569 */     if (clazz.isInterface()) {
/* 570 */       interfaces = clazz.getInterfaces();
/*     */       
/* 572 */       for (Class anInterface : interfaces) {
/* 573 */         msg = findMessage(anInterface, key, indexedKey, locale, args, checked, valueStack);
/*     */         
/* 575 */         if (msg != null) {
/* 576 */           return msg;
/*     */         }
/*     */       }
/*     */     
/* 580 */     } else if (!clazz.equals(Object.class) && !clazz.isPrimitive()) {
/* 581 */       return findMessage(clazz.getSuperclass(), key, indexedKey, locale, args, checked, valueStack);
/*     */     } 
/*     */ 
/*     */     
/* 585 */     return null;
/*     */   }
/*     */   
/*     */   static class MessageFormatKey {
/*     */     String pattern;
/*     */     Locale locale;
/*     */     
/*     */     MessageFormatKey(String pattern, Locale locale) {
/* 593 */       this.pattern = pattern;
/* 594 */       this.locale = locale;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 600 */       if (this == o) return true; 
/* 601 */       if (o == null || getClass() != o.getClass()) return false;
/*     */       
/* 603 */       MessageFormatKey that = (MessageFormatKey)o;
/*     */       
/* 605 */       if ((this.pattern != null) ? !this.pattern.equals(that.pattern) : (that.pattern != null)) return false; 
/* 606 */       return (this.locale != null) ? this.locale.equals(that.locale) : ((that.locale == null));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 611 */       int result = (this.pattern != null) ? this.pattern.hashCode() : 0;
/* 612 */       result = 31 * result + ((this.locale != null) ? this.locale.hashCode() : 0);
/* 613 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   static class GetDefaultMessageReturnArg {
/*     */     String message;
/*     */     boolean foundInBundle;
/*     */     
/*     */     public GetDefaultMessageReturnArg(String message, boolean foundInBundle) {
/* 622 */       this.message = message;
/* 623 */       this.foundInBundle = foundInBundle;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\AbstractLocalizedTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */