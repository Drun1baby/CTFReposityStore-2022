/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.Preparable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrepareInterceptor
/*     */   extends MethodFilterInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -5216969014510719786L;
/*     */   private static final String PREPARE_PREFIX = "prepare";
/*     */   private static final String ALT_PREPARE_PREFIX = "prepareDo";
/*     */   private boolean alwaysInvokePrepare = true;
/*     */   private boolean firstCallPrepareDo = false;
/*     */   
/*     */   public void setAlwaysInvokePrepare(String alwaysInvokePrepare) {
/* 121 */     this.alwaysInvokePrepare = Boolean.parseBoolean(alwaysInvokePrepare);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFirstCallPrepareDo(String firstCallPrepareDo) {
/* 132 */     this.firstCallPrepareDo = Boolean.parseBoolean(firstCallPrepareDo);
/*     */   }
/*     */ 
/*     */   
/*     */   public String doIntercept(ActionInvocation invocation) throws Exception {
/* 137 */     Object action = invocation.getAction();
/*     */     
/* 139 */     if (action instanceof Preparable) {
/*     */       try {
/*     */         String[] prefixes;
/* 142 */         if (this.firstCallPrepareDo) {
/* 143 */           prefixes = new String[] { "prepareDo", "prepare" };
/*     */         } else {
/* 145 */           prefixes = new String[] { "prepare", "prepareDo" };
/*     */         } 
/* 147 */         PrefixMethodInvocationUtil.invokePrefixMethod(invocation, prefixes);
/*     */       }
/* 149 */       catch (InvocationTargetException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 156 */         Throwable cause = e.getCause();
/* 157 */         if (cause instanceof Exception)
/* 158 */           throw (Exception)cause; 
/* 159 */         if (cause instanceof Error) {
/* 160 */           throw (Error)cause;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 166 */         throw e;
/*     */       } 
/*     */ 
/*     */       
/* 170 */       if (this.alwaysInvokePrepare) {
/* 171 */         ((Preparable)action).prepare();
/*     */       }
/*     */     } 
/*     */     
/* 175 */     return invocation.invoke();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\PrepareInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */