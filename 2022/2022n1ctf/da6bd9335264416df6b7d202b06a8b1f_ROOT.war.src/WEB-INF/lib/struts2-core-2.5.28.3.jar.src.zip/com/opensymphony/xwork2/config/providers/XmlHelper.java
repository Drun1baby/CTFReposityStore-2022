/*     */ package com.opensymphony.xwork2.config.providers;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlHelper
/*     */ {
/*     */   public static Map<String, String> getParams(Element paramsElement) {
/*  67 */     LinkedHashMap<String, String> params = new LinkedHashMap<>();
/*     */     
/*  69 */     if (paramsElement == null) {
/*  70 */       return params;
/*     */     }
/*     */     
/*  73 */     NodeList childNodes = paramsElement.getChildNodes();
/*     */     
/*  75 */     for (int i = 0; i < childNodes.getLength(); i++) {
/*  76 */       Node childNode = childNodes.item(i);
/*     */       
/*  78 */       if (childNode.getNodeType() == 1 && "param".equals(childNode.getNodeName())) {
/*  79 */         Element paramElement = (Element)childNode;
/*  80 */         String paramName = paramElement.getAttribute("name");
/*     */         
/*  82 */         String val = getContent(paramElement);
/*  83 */         if (val.length() > 0) {
/*  84 */           params.put(paramName, val);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  89 */     return params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getContent(Element element) {
/* 112 */     StringBuilder paramValue = new StringBuilder();
/* 113 */     NodeList childNodes = element.getChildNodes();
/* 114 */     for (int j = 0; j < childNodes.getLength(); j++) {
/* 115 */       Node currentNode = childNodes.item(j);
/* 116 */       if (currentNode != null && currentNode.getNodeType() == 3) {
/* 117 */         String val = currentNode.getNodeValue();
/* 118 */         if (val != null) {
/* 119 */           paramValue.append(val.trim());
/*     */         }
/*     */       } 
/*     */     } 
/* 123 */     return paramValue.toString().trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getLoadOrder(Document doc) {
/* 131 */     Element rootElement = doc.getDocumentElement();
/* 132 */     String number = rootElement.getAttribute("order");
/* 133 */     if (StringUtils.isNotBlank(number)) {
/*     */       try {
/* 135 */         return Integer.valueOf(Integer.parseInt(number));
/* 136 */       } catch (NumberFormatException e) {
/* 137 */         return Integer.valueOf(2147483647);
/*     */       } 
/*     */     }
/*     */     
/* 141 */     return Integer.valueOf(2147483647);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\XmlHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */