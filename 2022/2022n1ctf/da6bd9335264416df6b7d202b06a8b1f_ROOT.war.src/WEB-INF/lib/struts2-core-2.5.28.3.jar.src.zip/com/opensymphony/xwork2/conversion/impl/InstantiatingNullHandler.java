/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.conversion.NullHandler;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstantiatingNullHandler
/*     */   implements NullHandler
/*     */ {
/*  71 */   private static final Logger LOG = LogManager.getLogger(InstantiatingNullHandler.class);
/*     */   
/*     */   private ReflectionProvider reflectionProvider;
/*     */   private ObjectFactory objectFactory;
/*     */   private ObjectTypeDeterminer objectTypeDeterminer;
/*     */   
/*     */   @Inject
/*     */   public void setObjectTypeDeterminer(ObjectTypeDeterminer det) {
/*  79 */     this.objectTypeDeterminer = det;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/*  84 */     this.reflectionProvider = prov;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  89 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   public Object nullMethodResult(Map<String, Object> context, Object target, String methodName, Object[] args) {
/*  93 */     LOG.debug("Entering nullMethodResult");
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public Object nullPropertyValue(Map<String, Object> context, Object target, Object property) {
/*  98 */     LOG.debug("Entering nullPropertyValue [target={}, property={}]", target, property);
/*  99 */     boolean c = ReflectionContextState.isCreatingNullObjects(context);
/*     */     
/* 101 */     if (!c) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     if (target == null || property == null) {
/* 106 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 110 */       String propName = property.toString();
/* 111 */       Object realTarget = this.reflectionProvider.getRealTarget(propName, context, target);
/* 112 */       Class<?> clazz = null;
/*     */       
/* 114 */       if (realTarget != null) {
/* 115 */         PropertyDescriptor pd = this.reflectionProvider.getPropertyDescriptor(realTarget.getClass(), propName);
/* 116 */         if (pd == null) {
/* 117 */           return null;
/*     */         }
/*     */         
/* 120 */         clazz = pd.getPropertyType();
/*     */       } 
/*     */       
/* 123 */       if (clazz == null)
/*     */       {
/* 125 */         return null;
/*     */       }
/*     */       
/* 128 */       Object param = createObject(clazz, realTarget, propName, context);
/*     */       
/* 130 */       this.reflectionProvider.setValue(propName, context, realTarget, param);
/*     */       
/* 132 */       return param;
/* 133 */     } catch (Exception e) {
/* 134 */       LOG.error("Could not create and/or set value back on to object", e);
/*     */ 
/*     */       
/* 137 */       return null;
/*     */     } 
/*     */   }
/*     */   private Object createObject(Class<?> clazz, Object target, String property, Map<String, Object> context) throws Exception {
/* 141 */     if (Set.class.isAssignableFrom(clazz))
/* 142 */       return new HashSet(); 
/* 143 */     if (Collection.class.isAssignableFrom(clazz))
/* 144 */       return new ArrayList(); 
/* 145 */     if (clazz == Map.class)
/* 146 */       return new HashMap<>(); 
/* 147 */     if (clazz == EnumMap.class) {
/* 148 */       Class<Enum> keyClass = this.objectTypeDeterminer.getKeyClass(target.getClass(), property);
/* 149 */       return new EnumMap<>(keyClass);
/*     */     } 
/*     */     
/* 152 */     return this.objectFactory.buildBean(clazz, context);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\InstantiatingNullHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */