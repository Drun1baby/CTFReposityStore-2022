/*     */ package com.opensymphony.xwork2.inject.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceCache<K, V>
/*     */   extends ReferenceMap<K, V>
/*     */ {
/*     */   private static final long serialVersionUID = 0L;
/*  39 */   transient ConcurrentMap<Object, Future<V>> futures = new ConcurrentHashMap<>();
/*  40 */   transient ThreadLocal<Future<V>> localFuture = new ThreadLocal<>();
/*     */   
/*     */   public ReferenceCache(ReferenceType keyReferenceType, ReferenceType valueReferenceType) {
/*  43 */     super(keyReferenceType, valueReferenceType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceCache() {
/*  50 */     super(ReferenceType.STRONG, ReferenceType.STRONG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract V create(K paramK);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   V internalCreate(K key) {
/*     */     try {
/*  67 */       FutureTask<V> futureTask = new FutureTask<>(new CallableCreate(key));
/*     */ 
/*     */       
/*  70 */       Object keyReference = referenceKey(key);
/*  71 */       Future<V> future = this.futures.putIfAbsent(keyReference, futureTask);
/*  72 */       if (future == null) {
/*     */         
/*     */         try {
/*  75 */           if (this.localFuture.get() != null) {
/*  76 */             throw new IllegalStateException("Nested creations within the same cache are not allowed.");
/*     */           }
/*  78 */           this.localFuture.set(futureTask);
/*  79 */           futureTask.run();
/*  80 */           V value = futureTask.get();
/*  81 */           putStrategy().execute(this, keyReference, referenceValue(keyReference, value));
/*  82 */           return value;
/*     */         } finally {
/*  84 */           this.localFuture.remove();
/*  85 */           this.futures.remove(keyReference);
/*     */         } 
/*     */       }
/*     */       
/*  89 */       return future.get();
/*     */     }
/*  91 */     catch (InterruptedException e) {
/*  92 */       throw new RuntimeException(e);
/*  93 */     } catch (ExecutionException e) {
/*  94 */       Throwable cause = e.getCause();
/*  95 */       if (cause instanceof RuntimeException)
/*  96 */         throw (RuntimeException)cause; 
/*  97 */       if (cause instanceof Error) {
/*  98 */         throw (Error)cause;
/*     */       }
/* 100 */       throw new RuntimeException(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 122 */     V value = super.get(key);
/* 123 */     return (value == null) ? internalCreate((K)key) : value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cancel() {
/* 132 */     Future<V> future = this.localFuture.get();
/* 133 */     if (future == null) {
/* 134 */       throw new IllegalStateException("Not in create().");
/*     */     }
/* 136 */     future.cancel(false);
/*     */   }
/*     */   
/*     */   class CallableCreate
/*     */     implements Callable<V> {
/*     */     K key;
/*     */     
/*     */     public CallableCreate(K key) {
/* 144 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public V call() {
/* 149 */       V value = ReferenceCache.this.internalGet(this.key);
/* 150 */       if (value != null) {
/* 151 */         return value;
/*     */       }
/*     */ 
/*     */       
/* 155 */       value = ReferenceCache.this.create(this.key);
/* 156 */       if (value == null) {
/* 157 */         throw new NullPointerException("create(K) returned null for: " + this.key);
/*     */       }
/* 159 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> ReferenceCache<K, V> of(ReferenceType keyReferenceType, ReferenceType valueReferenceType, final Function<? super K, ? extends V> function) {
/* 179 */     ensureNotNull(function);
/* 180 */     return new ReferenceCache<K, V>(keyReferenceType, valueReferenceType)
/*     */       {
/*     */         protected V create(K key) {
/* 183 */           return function.apply(key);
/*     */         }
/*     */ 
/*     */         
/*     */         private static final long serialVersionUID = 0L;
/*     */       };
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 192 */     in.defaultReadObject();
/* 193 */     this.futures = new ConcurrentHashMap<>();
/* 194 */     this.localFuture = new ThreadLocal<>();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\injec\\util\ReferenceCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */