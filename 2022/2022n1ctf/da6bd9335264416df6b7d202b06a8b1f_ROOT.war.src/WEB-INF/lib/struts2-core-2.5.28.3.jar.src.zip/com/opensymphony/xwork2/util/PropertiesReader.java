/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesReader
/*     */   extends LineNumberReader
/*     */ {
/*     */   private List<String> commentLines;
/*     */   private String propertyName;
/*     */   private String propertyValue;
/*     */   private char delimiter;
/*     */   static final String COMMENT_CHARS = "#!";
/*     */   private static final int HEX_RADIX = 16;
/*     */   private static final int UNICODE_LEN = 4;
/*  77 */   private static final char[] SEPARATORS = new char[] { '=', ':' };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private static final char[] WHITE_SPACE = new char[] { ' ', '\t', '\f' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesReader(Reader reader) {
/*  90 */     this(reader, ',');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesReader(Reader reader, char listDelimiter) {
/* 102 */     super(reader);
/* 103 */     this.commentLines = new ArrayList<>();
/* 104 */     this.delimiter = listDelimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isCommentLine(String line) {
/* 116 */     String s = line.trim();
/*     */     
/* 118 */     return (s.length() < 1 || "#!".indexOf(s.charAt(0)) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readProperty() throws IOException {
/*     */     String line;
/* 132 */     this.commentLines.clear();
/* 133 */     StringBuilder buffer = new StringBuilder();
/*     */     
/*     */     while (true) {
/* 136 */       line = readLine();
/* 137 */       if (line == null)
/*     */       {
/* 139 */         return null;
/*     */       }
/*     */       
/* 142 */       if (isCommentLine(line)) {
/* 143 */         this.commentLines.add(line);
/*     */         
/*     */         continue;
/*     */       } 
/* 147 */       line = line.trim();
/*     */       
/* 149 */       if (checkCombineLines(line)) {
/* 150 */         line = line.substring(0, line.length() - 1);
/* 151 */         buffer.append(line); continue;
/*     */       }  break;
/* 153 */     }  buffer.append(line);
/*     */ 
/*     */ 
/*     */     
/* 157 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nextProperty() throws IOException {
/* 172 */     String line = readProperty();
/*     */     
/* 174 */     if (line == null) {
/* 175 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 179 */     String[] property = parseProperty(line);
/* 180 */     this.propertyName = unescapeJava(property[0]);
/* 181 */     this.propertyValue = unescapeJava(property[1], this.delimiter);
/* 182 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getCommentLines() {
/* 193 */     return this.commentLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/* 205 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyValue() {
/* 217 */     return this.propertyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkCombineLines(String line) {
/* 228 */     int bsCount = 0;
/* 229 */     for (int idx = line.length() - 1; idx >= 0 && line.charAt(idx) == '\\'; idx--) {
/* 230 */       bsCount++;
/*     */     }
/*     */     
/* 233 */     return (bsCount % 2 == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] parseProperty(String line) {
/* 247 */     String[] result = new String[2];
/* 248 */     StringBuilder key = new StringBuilder();
/* 249 */     StringBuilder value = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     int state = 0;
/*     */     
/* 258 */     for (int pos = 0; pos < line.length(); pos++) {
/* 259 */       char c = line.charAt(pos);
/*     */       
/* 261 */       switch (state) {
/*     */         case 0:
/* 263 */           if (c == '\\') {
/* 264 */             state = 1; break;
/* 265 */           }  if (contains(WHITE_SPACE, c)) {
/*     */             
/* 267 */             state = 2; break;
/* 268 */           }  if (contains(SEPARATORS, c)) {
/*     */             
/* 270 */             state = 3; break;
/*     */           } 
/* 272 */           key.append(c);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 278 */           if (contains(SEPARATORS, c) || contains(WHITE_SPACE, c)) {
/*     */             
/* 280 */             key.append(c);
/*     */           } else {
/*     */             
/* 283 */             key.append('\\');
/* 284 */             key.append(c);
/*     */           } 
/*     */ 
/*     */           
/* 288 */           state = 0;
/*     */           break;
/*     */ 
/*     */         
/*     */         case 2:
/* 293 */           if (contains(WHITE_SPACE, c)) {
/*     */             
/* 295 */             state = 2; break;
/* 296 */           }  if (contains(SEPARATORS, c)) {
/*     */             
/* 298 */             state = 3;
/*     */             break;
/*     */           } 
/* 301 */           value.append(c);
/*     */ 
/*     */           
/* 304 */           state = 3;
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 310 */           value.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 315 */     result[0] = key.toString().trim();
/* 316 */     result[1] = value.toString().trim();
/*     */     
/* 318 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String unescapeJava(String str, char delimiter) {
/* 333 */     if (str == null) {
/* 334 */       return null;
/*     */     }
/* 336 */     int sz = str.length();
/* 337 */     StringBuilder out = new StringBuilder(sz);
/* 338 */     StringBuffer unicode = new StringBuffer(4);
/* 339 */     boolean hadSlash = false;
/* 340 */     boolean inUnicode = false;
/* 341 */     for (int i = 0; i < sz; i++) {
/* 342 */       char ch = str.charAt(i);
/* 343 */       if (inUnicode) {
/*     */ 
/*     */         
/* 346 */         unicode.append(ch);
/* 347 */         if (unicode.length() == 4) {
/*     */           
/*     */           try {
/*     */             
/* 351 */             int value = Integer.parseInt(unicode.toString(), 16);
/* 352 */             out.append((char)value);
/* 353 */             unicode.setLength(0);
/* 354 */             inUnicode = false;
/* 355 */             hadSlash = false;
/* 356 */           } catch (NumberFormatException nfe) {
/* 357 */             throw new RuntimeException("Unable to parse unicode value: " + unicode, nfe);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       }
/* 363 */       else if (hadSlash) {
/*     */         
/* 365 */         hadSlash = false;
/*     */         
/* 367 */         if (ch == '\\') {
/* 368 */           out.append('\\');
/* 369 */         } else if (ch == '\'') {
/* 370 */           out.append('\'');
/* 371 */         } else if (ch == '"') {
/* 372 */           out.append('"');
/* 373 */         } else if (ch == 'r') {
/* 374 */           out.append('\r');
/* 375 */         } else if (ch == 'f') {
/* 376 */           out.append('\f');
/* 377 */         } else if (ch == 't') {
/* 378 */           out.append('\t');
/* 379 */         } else if (ch == 'n') {
/* 380 */           out.append('\n');
/* 381 */         } else if (ch == 'b') {
/* 382 */           out.append('\b');
/* 383 */         } else if (ch == delimiter) {
/* 384 */           out.append('\\');
/* 385 */           out.append(delimiter);
/* 386 */         } else if (ch == 'u') {
/*     */           
/* 388 */           inUnicode = true;
/*     */         } else {
/* 390 */           out.append(ch);
/*     */         }
/*     */       
/*     */       }
/* 394 */       else if (ch == '\\') {
/* 395 */         hadSlash = true;
/*     */       } else {
/*     */         
/* 398 */         out.append(ch);
/*     */       } 
/*     */     } 
/* 401 */     if (hadSlash)
/*     */     {
/*     */       
/* 404 */       out.append('\\');
/*     */     }
/*     */     
/* 407 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(char[] array, char objectToFind) {
/* 420 */     if (array == null) {
/* 421 */       return false;
/*     */     }
/* 423 */     for (char anArray : array) {
/* 424 */       if (objectToFind == anArray) {
/* 425 */         return true;
/*     */       }
/*     */     } 
/* 428 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeJava(String str) {
/* 441 */     if (str == null) {
/* 442 */       return null;
/*     */     }
/*     */     try {
/* 445 */       StringWriter writer = new StringWriter(str.length());
/* 446 */       unescapeJava(writer, str);
/* 447 */       return writer.toString();
/* 448 */     } catch (IOException ioe) {
/*     */       
/* 450 */       ioe.printStackTrace();
/* 451 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unescapeJava(Writer out, String str) throws IOException {
/* 471 */     if (out == null) {
/* 472 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/* 474 */     if (str == null) {
/*     */       return;
/*     */     }
/* 477 */     int sz = str.length();
/* 478 */     StringBuffer unicode = new StringBuffer(4);
/* 479 */     boolean hadSlash = false;
/* 480 */     boolean inUnicode = false;
/* 481 */     for (int i = 0; i < sz; i++) {
/* 482 */       char ch = str.charAt(i);
/* 483 */       if (inUnicode) {
/*     */ 
/*     */         
/* 486 */         unicode.append(ch);
/* 487 */         if (unicode.length() == 4) {
/*     */           
/*     */           try {
/*     */             
/* 491 */             int value = Integer.parseInt(unicode.toString(), 16);
/* 492 */             out.write((char)value);
/* 493 */             unicode.setLength(0);
/* 494 */             inUnicode = false;
/* 495 */             hadSlash = false;
/* 496 */           } catch (NumberFormatException nfe) {
/* 497 */             throw new RuntimeException("Unable to parse unicode value: " + unicode, nfe);
/*     */           }
/*     */         
/*     */         }
/*     */       }
/* 502 */       else if (hadSlash) {
/*     */         
/* 504 */         hadSlash = false;
/* 505 */         switch (ch) {
/*     */           case '\\':
/* 507 */             out.write(92);
/*     */             break;
/*     */           case '\'':
/* 510 */             out.write(39);
/*     */             break;
/*     */           case '"':
/* 513 */             out.write(34);
/*     */             break;
/*     */           case 'r':
/* 516 */             out.write(13);
/*     */             break;
/*     */           case 'f':
/* 519 */             out.write(12);
/*     */             break;
/*     */           case 't':
/* 522 */             out.write(9);
/*     */             break;
/*     */           case 'n':
/* 525 */             out.write(10);
/*     */             break;
/*     */           case 'b':
/* 528 */             out.write(8);
/*     */             break;
/*     */           
/*     */           case 'u':
/* 532 */             inUnicode = true;
/*     */             break;
/*     */           
/*     */           default:
/* 536 */             out.write(ch);
/*     */             break;
/*     */         } 
/*     */       
/* 540 */       } else if (ch == '\\') {
/* 541 */         hadSlash = true;
/*     */       } else {
/*     */         
/* 544 */         out.write(ch);
/*     */       } 
/* 546 */     }  if (hadSlash)
/*     */     {
/*     */       
/* 549 */       out.write(92);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\PropertiesReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */