/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationActionValidatorManager
/*     */   implements ActionValidatorManager
/*     */ {
/*     */   protected static final String VALIDATION_CONFIG_SUFFIX = "-validation.xml";
/*  49 */   private final Map<String, List<ValidatorConfig>> validatorCache = Collections.synchronizedMap(new HashMap<>());
/*  50 */   private final Map<String, List<ValidatorConfig>> validatorFileCache = Collections.synchronizedMap(new HashMap<>());
/*  51 */   private static final Logger LOG = LogManager.getLogger(AnnotationActionValidatorManager.class);
/*     */   
/*     */   private ValidatorFactory validatorFactory;
/*     */   private ValidatorFileParser validatorFileParser;
/*     */   private FileManager fileManager;
/*     */   private boolean reloadingConfigs;
/*     */   private TextProviderFactory textProviderFactory;
/*     */   
/*     */   @Inject
/*     */   public void setValidatorFactory(ValidatorFactory fac) {
/*  61 */     this.validatorFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValidatorFileParser(ValidatorFileParser parser) {
/*  66 */     this.validatorFileParser = parser;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/*  71 */     this.fileManager = fileManagerFactory.getFileManager();
/*     */   }
/*     */   
/*     */   @Inject(value = "reloadXmlConfiguration", required = false)
/*     */   public void setReloadingConfigs(String reloadingConfigs) {
/*  76 */     this.reloadingConfigs = Boolean.parseBoolean(reloadingConfigs);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTextProviderFactory(TextProviderFactory textProviderFactory) {
/*  81 */     this.textProviderFactory = textProviderFactory;
/*     */   }
/*     */   
/*     */   public List<Validator> getValidators(Class clazz, String context) {
/*  85 */     return getValidators(clazz, context, null);
/*     */   }
/*     */   
/*     */   public List<Validator> getValidators(Class clazz, String context, String method) {
/*  89 */     String validatorKey = buildValidatorKey(clazz, context);
/*     */ 
/*     */     
/*  92 */     if (this.validatorCache.containsKey(validatorKey)) {
/*  93 */       if (this.reloadingConfigs) {
/*  94 */         this.validatorCache.put(validatorKey, buildValidatorConfigs(clazz, context, true, null));
/*     */       }
/*     */     } else {
/*  97 */       this.validatorCache.put(validatorKey, buildValidatorConfigs(clazz, context, false, null));
/*     */     } 
/*     */ 
/*     */     
/* 101 */     List<ValidatorConfig> cfgs = new ArrayList<>(this.validatorCache.get(validatorKey));
/*     */     
/* 103 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/*     */     
/* 106 */     ArrayList<Validator> validators = new ArrayList<>(cfgs.size());
/* 107 */     for (ValidatorConfig cfg : cfgs) {
/* 108 */       if (method == null || method.equals(cfg.getParams().get("methodName"))) {
/* 109 */         Validator validator = this.validatorFactory.getValidator((new ValidatorConfig.Builder(cfg)).removeParam("methodName").build());
/*     */ 
/*     */ 
/*     */         
/* 113 */         validator.setValidatorType(cfg.getType());
/* 114 */         validator.setValueStack(stack);
/* 115 */         validators.add(validator);
/*     */       } 
/*     */     } 
/*     */     
/* 119 */     return validators;
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context) throws ValidationException {
/* 123 */     validate(object, context, (String)null);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, String method) throws ValidationException {
/* 127 */     ValidatorContext validatorContext = new DelegatingValidatorContext(object, this.textProviderFactory);
/* 128 */     validate(object, context, validatorContext, method);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, ValidatorContext validatorContext) throws ValidationException {
/* 132 */     validate(object, context, validatorContext, null);
/*     */   }
/*     */   
/*     */   public void validate(Object object, String context, ValidatorContext validatorContext, String method) throws ValidationException {
/* 136 */     List<Validator> validators = getValidators(object.getClass(), context, method);
/* 137 */     Set<String> shortcircuitedFields = null;
/*     */     
/* 139 */     for (Validator validator : validators) {
/*     */       
/* 141 */       try { validator.setValidatorContext(validatorContext);
/*     */         
/* 143 */         LOG.debug("Running validator: {} for object {} and method {}", validator, object, method);
/*     */         
/* 145 */         FieldValidator fValidator = null;
/* 146 */         String fullFieldName = null;
/*     */         
/* 148 */         if (validator instanceof FieldValidator)
/* 149 */         { fValidator = (FieldValidator)validator;
/* 150 */           fullFieldName = fValidator.getValidatorContext().getFullFieldName(fValidator.getFieldName());
/*     */           
/* 152 */           if (shortcircuitedFields != null && shortcircuitedFields.contains(fullFieldName))
/* 153 */           { LOG.debug("Short-circuited, skipping");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 208 */             validator.setValidatorContext(null); continue; }  }  if (validator instanceof ShortCircuitableValidator && ((ShortCircuitableValidator)validator).isShortCircuit()) { List<String> errs = null; if (fValidator != null) { if (validatorContext.hasFieldErrors()) { Collection<String> fieldErrors = (Collection<String>)validatorContext.getFieldErrors().get(fullFieldName); if (fieldErrors != null) errs = new ArrayList<>(fieldErrors);  }  } else if (validatorContext.hasActionErrors()) { Collection<String> actionErrors = validatorContext.getActionErrors(); if (actionErrors != null) errs = new ArrayList<>(actionErrors);  }  validator.validate(object); if (fValidator != null) { if (validatorContext.hasFieldErrors()) { Collection<String> errCol = (Collection<String>)validatorContext.getFieldErrors().get(fullFieldName); if (errCol != null && !errCol.equals(errs)) { LOG.debug("Short-circuiting on field validation"); if (shortcircuitedFields == null) shortcircuitedFields = new TreeSet<>();  shortcircuitedFields.add(fullFieldName); }  }  } else if (validatorContext.hasActionErrors()) { Collection<String> errCol = validatorContext.getActionErrors(); if (errCol != null && !errCol.equals(errs)) { LOG.debug("Short-circuiting"); validator.setValidatorContext(null); break; }  }  validator.setValidatorContext(null); continue; }  validator.validate(object); } finally { validator.setValidatorContext(null); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildValidatorKey(Class clazz, String context) {
/* 222 */     ActionInvocation invocation = ActionContext.getContext().getActionInvocation();
/* 223 */     ActionProxy proxy = invocation.getProxy();
/* 224 */     ActionConfig config = proxy.getConfig();
/*     */     
/* 226 */     StringBuilder sb = new StringBuilder(clazz.getName());
/* 227 */     sb.append("/");
/* 228 */     if (StringUtils.isNotBlank(config.getPackageName())) {
/* 229 */       sb.append(config.getPackageName());
/* 230 */       sb.append("/");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     String configName = config.getName();
/* 247 */     if (configName.contains("*") || (configName.contains("{") && configName.contains("}"))) {
/* 248 */       sb.append(configName);
/* 249 */       sb.append("|");
/* 250 */       sb.append(proxy.getMethod());
/*     */     } else {
/* 252 */       sb.append(context);
/*     */     } 
/*     */     
/* 255 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private List<ValidatorConfig> buildAliasValidatorConfigs(Class aClass, String context, boolean checkFile) {
/* 259 */     String fileName = aClass.getName().replace('.', '/') + "-" + context.replace('/', '-') + "-validation.xml";
/*     */     
/* 261 */     return loadFile(fileName, aClass, checkFile);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<ValidatorConfig> buildClassValidatorConfigs(Class aClass, boolean checkFile) {
/* 267 */     String fileName = aClass.getName().replace('.', '/') + "-validation.xml";
/*     */     
/* 269 */     List<ValidatorConfig> result = new ArrayList<>(loadFile(fileName, aClass, checkFile));
/*     */     
/* 271 */     AnnotationValidationConfigurationBuilder builder = new AnnotationValidationConfigurationBuilder(this.validatorFactory);
/*     */     
/* 273 */     List<ValidatorConfig> annotationResult = new ArrayList<>(builder.buildAnnotationClassValidatorConfigs(aClass));
/*     */     
/* 275 */     result.addAll(annotationResult);
/*     */     
/* 277 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ValidatorConfig> buildValidatorConfigs(Class clazz, String context, boolean checkFile, Set<String> checked) {
/* 324 */     List<ValidatorConfig> validatorConfigs = new ArrayList<>();
/*     */     
/* 326 */     if (checked == null) {
/* 327 */       checked = new TreeSet<>();
/* 328 */     } else if (checked.contains(clazz.getName())) {
/* 329 */       return validatorConfigs;
/*     */     } 
/*     */     
/* 332 */     if (clazz.isInterface()) {
/* 333 */       Class[] arrayOfClass = clazz.getInterfaces();
/*     */       
/* 335 */       for (Class anInterface : arrayOfClass) {
/* 336 */         validatorConfigs.addAll(buildValidatorConfigs(anInterface, context, checkFile, checked));
/*     */       }
/*     */     }
/* 339 */     else if (!clazz.equals(Object.class)) {
/* 340 */       validatorConfigs.addAll(buildValidatorConfigs(clazz.getSuperclass(), context, checkFile, checked));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 345 */     Class[] interfaces = clazz.getInterfaces();
/*     */     
/* 347 */     for (Class anInterface1 : interfaces) {
/* 348 */       if (!checked.contains(anInterface1.getName())) {
/*     */ 
/*     */ 
/*     */         
/* 352 */         validatorConfigs.addAll(buildClassValidatorConfigs(anInterface1, checkFile));
/*     */         
/* 354 */         if (context != null) {
/* 355 */           validatorConfigs.addAll(buildAliasValidatorConfigs(anInterface1, context, checkFile));
/*     */         }
/*     */         
/* 358 */         checked.add(anInterface1.getName());
/*     */       } 
/*     */     } 
/* 361 */     validatorConfigs.addAll(buildClassValidatorConfigs(clazz, checkFile));
/*     */     
/* 363 */     if (context != null) {
/* 364 */       validatorConfigs.addAll(buildAliasValidatorConfigs(clazz, context, checkFile));
/*     */     }
/*     */     
/* 367 */     checked.add(clazz.getName());
/*     */     
/* 369 */     return validatorConfigs;
/*     */   }
/*     */   
/*     */   private List<ValidatorConfig> loadFile(String fileName, Class clazz, boolean checkFile) {
/* 373 */     List<ValidatorConfig> retList = Collections.emptyList();
/*     */     
/* 375 */     URL fileUrl = ClassLoaderUtil.getResource(fileName, clazz);
/*     */     
/* 377 */     if ((checkFile && this.fileManager.fileNeedsReloading(fileUrl)) || !this.validatorFileCache.containsKey(fileName)) {
/* 378 */       try (InputStream is = this.fileManager.loadFile(fileUrl)) {
/* 379 */         if (is != null) {
/* 380 */           retList = new ArrayList<>(this.validatorFileParser.parseActionValidatorConfigs(this.validatorFactory, is, fileName));
/*     */         }
/* 382 */       } catch (IOException e) {
/* 383 */         LOG.error("Caught exception while loading file {}", fileName, e);
/*     */       } 
/*     */       
/* 386 */       this.validatorFileCache.put(fileName, retList);
/*     */     } else {
/* 388 */       retList = this.validatorFileCache.get(fileName);
/*     */     } 
/*     */     
/* 391 */     return retList;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\AnnotationActionValidatorManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */