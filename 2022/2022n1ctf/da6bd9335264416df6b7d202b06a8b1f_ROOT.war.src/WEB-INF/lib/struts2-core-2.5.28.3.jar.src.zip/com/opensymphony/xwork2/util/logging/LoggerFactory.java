/*     */ package com.opensymphony.xwork2.util.logging;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.util.logging.commons.CommonsLoggerFactory;
/*     */ import com.opensymphony.xwork2.util.logging.jdk.JdkLoggerFactory;
/*     */ import com.opensymphony.xwork2.util.logging.log4j2.Log4j2LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.logging.slf4j.Slf4jLoggerFactory;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class LoggerFactory
/*     */ {
/*  41 */   private static final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */   
/*     */   private static LoggerFactory factory;
/*  44 */   private static final List<LoggerClass> loggers = new LinkedList<LoggerClass>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLoggerFactory(LoggerFactory factory) {
/*  53 */     lock.writeLock().lock();
/*     */     try {
/*  55 */       LoggerFactory.factory = factory;
/*     */     } finally {
/*  57 */       lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Logger getLogger(Class<?> cls) {
/*  62 */     return getLoggerFactory().getLoggerImpl(cls);
/*     */   }
/*     */   
/*     */   public static Logger getLogger(String name) {
/*  66 */     return getLoggerFactory().getLoggerImpl(name);
/*     */   }
/*     */   
/*     */   protected static LoggerFactory getLoggerFactory() {
/*  70 */     lock.readLock().lock();
/*     */     try {
/*  72 */       if (factory != null) {
/*  73 */         return factory;
/*     */       }
/*     */     } finally {
/*  76 */       lock.readLock().unlock();
/*     */     } 
/*  78 */     lock.writeLock().lock();
/*     */     try {
/*  80 */       if (factory == null) {
/*  81 */         createLoggerFactory();
/*     */       }
/*  83 */       return factory;
/*     */     } finally {
/*  85 */       lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void createLoggerFactory() {
/*  90 */     String userLoggerFactory = System.getProperty("xwork.loggerFactory");
/*  91 */     if (userLoggerFactory != null) {
/*     */       try {
/*  93 */         Class<?> clazz = Class.forName(userLoggerFactory);
/*  94 */         factory = (LoggerFactory)clazz.newInstance();
/*  95 */       } catch (Exception e) {
/*  96 */         throw new XWorkException("System property [xwork.loggerFactory] was defined as [" + userLoggerFactory + "] but there is a problem to use that LoggerFactory!", e);
/*     */       } 
/*     */     } else {
/*     */       
/* 100 */       factory = (LoggerFactory)new JdkLoggerFactory();
/* 101 */       for (LoggerClass logger : loggers) {
/* 102 */         if (logger.isSupported()) {
/* 103 */           factory = logger.createInstance();
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract Logger getLoggerImpl(Class<?> paramClass);
/*     */   
/*     */   protected abstract Logger getLoggerImpl(String paramString);
/*     */   
/*     */   private static class LoggerClass<T extends LoggerFactory>
/*     */   {
/*     */     private final String loggerClazzName;
/*     */     private final Class<T> loggerImplClazz;
/*     */     
/*     */     public LoggerClass(String loggerClazzName, Class<T> loggerImplClazz) {
/* 120 */       this.loggerClazzName = loggerClazzName;
/* 121 */       this.loggerImplClazz = loggerImplClazz;
/*     */     }
/*     */     
/*     */     public boolean isSupported() {
/*     */       try {
/* 126 */         Class.forName(this.loggerClazzName);
/* 127 */         return true;
/* 128 */       } catch (ClassNotFoundException ignore) {
/* 129 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     public LoggerFactory createInstance() {
/*     */       try {
/* 135 */         return (LoggerFactory)this.loggerImplClazz.newInstance();
/* 136 */       } catch (Exception e) {
/* 137 */         throw new XWorkException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\LoggerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */