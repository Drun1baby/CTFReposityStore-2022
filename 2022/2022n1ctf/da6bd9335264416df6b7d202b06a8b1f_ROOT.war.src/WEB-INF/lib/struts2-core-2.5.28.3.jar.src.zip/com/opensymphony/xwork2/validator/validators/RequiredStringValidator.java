/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequiredStringValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*     */   private boolean trim = true;
/*     */   
/*     */   public void setTrim(boolean trim) {
/*  80 */     this.trim = trim;
/*     */   }
/*     */   
/*     */   public void setTrimExpression(String trimExpression) {
/*  84 */     this.trim = ((Boolean)parse(trimExpression, Boolean.class)).booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isTrim() {
/*  88 */     return this.trim;
/*     */   }
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/*  92 */     Object fieldValue = getFieldValue(getFieldName(), object);
/*     */     
/*  94 */     if (fieldValue == null) {
/*  95 */       addFieldError(getFieldName(), object);
/*     */       
/*     */       return;
/*     */     } 
/*  99 */     if (fieldValue.getClass().isArray()) {
/* 100 */       Object[] values = (Object[])fieldValue;
/* 101 */       for (Object value : values) {
/* 102 */         validateValue(object, value);
/*     */       }
/* 104 */     } else if (Collection.class.isAssignableFrom(fieldValue.getClass())) {
/* 105 */       Collection values = (Collection)fieldValue;
/* 106 */       for (Object value : values) {
/* 107 */         validateValue(object, value);
/*     */       }
/*     */     } else {
/* 110 */       validateValue(object, fieldValue);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateValue(Object object, Object fieldValue) {
/*     */     try {
/* 116 */       setCurrentValue(fieldValue);
/* 117 */       if (fieldValue == null) {
/* 118 */         addFieldError(getFieldName(), object);
/*     */         
/*     */         return;
/*     */       } 
/* 122 */       if (fieldValue instanceof String) {
/* 123 */         String stingValue = (String)fieldValue;
/*     */         
/* 125 */         if (this.trim) {
/* 126 */           stingValue = stingValue.trim();
/*     */         }
/*     */         
/* 129 */         if (stingValue.length() == 0) {
/* 130 */           addFieldError(getFieldName(), object);
/*     */         }
/*     */       } else {
/* 133 */         addFieldError(getFieldName(), object);
/*     */       } 
/*     */     } finally {
/* 136 */       setCurrentValue((Object)null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\RequiredStringValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */