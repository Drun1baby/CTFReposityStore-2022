/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatorConfig
/*     */   extends Located
/*     */ {
/*     */   private String type;
/*     */   private Map<String, Object> params;
/*     */   private String defaultMessage;
/*     */   private String messageKey;
/*     */   private boolean shortCircuit;
/*     */   private String[] messageParams;
/*     */   
/*     */   protected ValidatorConfig(String validatorType) {
/*  50 */     this.type = validatorType;
/*  51 */     this.params = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   protected ValidatorConfig(ValidatorConfig orig) {
/*  55 */     this.type = orig.type;
/*  56 */     this.params = new LinkedHashMap<>(orig.params);
/*  57 */     this.defaultMessage = orig.defaultMessage;
/*  58 */     this.messageKey = orig.messageKey;
/*  59 */     this.shortCircuit = orig.shortCircuit;
/*  60 */     this.messageParams = orig.messageParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultMessage() {
/*  67 */     return this.defaultMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessageKey() {
/*  74 */     return this.messageKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShortCircuit() {
/*  82 */     return this.shortCircuit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getParams() {
/*  89 */     return this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  96 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMessageParams() {
/* 103 */     return this.messageParams;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private ValidatorConfig target;
/*     */ 
/*     */     
/*     */     public Builder(String validatorType) {
/* 113 */       this.target = new ValidatorConfig(validatorType);
/*     */     }
/*     */     
/*     */     public Builder(ValidatorConfig config) {
/* 117 */       this.target = new ValidatorConfig(config);
/*     */     }
/*     */     
/*     */     public Builder shortCircuit(boolean shortCircuit) {
/* 121 */       this.target.shortCircuit = shortCircuit;
/* 122 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultMessage(String msg) {
/* 126 */       if (msg != null && msg.trim().length() > 0) {
/* 127 */         this.target.defaultMessage = msg;
/*     */       }
/* 129 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageParams(String[] msgParams) {
/* 133 */       this.target.messageParams = msgParams;
/* 134 */       return this;
/*     */     }
/*     */     
/*     */     public Builder messageKey(String key) {
/* 138 */       if (key != null && key.trim().length() > 0) {
/* 139 */         this.target.messageKey = key;
/*     */       }
/* 141 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, Object value) {
/* 145 */       if (value != null && name != null) {
/* 146 */         this.target.params.put(name, value);
/*     */       }
/* 148 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, Object> params) {
/* 152 */       this.target.params.putAll(params);
/* 153 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 157 */       this.target.location = loc;
/* 158 */       return this;
/*     */     }
/*     */     
/*     */     public ValidatorConfig build() {
/* 162 */       this.target.params = Collections.unmodifiableMap(this.target.params);
/* 163 */       ValidatorConfig result = this.target;
/* 164 */       this.target = new ValidatorConfig(this.target);
/* 165 */       return result;
/*     */     }
/*     */     
/*     */     public Builder removeParam(String key) {
/* 169 */       this.target.params.remove(key);
/* 170 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\ValidatorConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */