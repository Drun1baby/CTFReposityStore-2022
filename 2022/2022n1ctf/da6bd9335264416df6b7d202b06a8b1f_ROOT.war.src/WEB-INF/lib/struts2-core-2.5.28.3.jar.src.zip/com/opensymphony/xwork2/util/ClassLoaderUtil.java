/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLoaderUtil
/*     */ {
/*     */   public static Iterator<URL> getResources(String resourceName, Class callingClass, boolean aggregate) throws IOException {
/*  67 */     AggregateIterator<URL> iterator = new AggregateIterator<>();
/*     */     
/*  69 */     iterator.addEnumeration(Thread.currentThread().getContextClassLoader().getResources(resourceName));
/*     */     
/*  71 */     if (!iterator.hasNext() || aggregate) {
/*  72 */       iterator.addEnumeration(ClassLoaderUtil.class.getClassLoader().getResources(resourceName));
/*     */     }
/*     */     
/*  75 */     if (!iterator.hasNext() || aggregate) {
/*  76 */       ClassLoader cl = callingClass.getClassLoader();
/*     */       
/*  78 */       if (cl != null) {
/*  79 */         iterator.addEnumeration(cl.getResources(resourceName));
/*     */       }
/*     */     } 
/*     */     
/*  83 */     if (!iterator.hasNext() && resourceName != null && (resourceName.length() == 0 || resourceName.charAt(0) != '/')) {
/*  84 */       return getResources('/' + resourceName, callingClass, aggregate);
/*     */     }
/*     */     
/*  87 */     return iterator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getResource(String resourceName, Class callingClass) {
/* 108 */     URL url = Thread.currentThread().getContextClassLoader().getResource(resourceName);
/*     */     
/* 110 */     if (url == null) {
/* 111 */       url = ClassLoaderUtil.class.getClassLoader().getResource(resourceName);
/*     */     }
/*     */     
/* 114 */     if (url == null) {
/* 115 */       ClassLoader cl = callingClass.getClassLoader();
/*     */       
/* 117 */       if (cl != null) {
/* 118 */         url = cl.getResource(resourceName);
/*     */       }
/*     */     } 
/*     */     
/* 122 */     if (url == null && resourceName != null && (resourceName.length() == 0 || resourceName.charAt(0) != '/')) {
/* 123 */       return getResource('/' + resourceName, callingClass);
/*     */     }
/*     */     
/* 126 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputStream getResourceAsStream(String resourceName, Class callingClass) {
/* 139 */     URL url = getResource(resourceName, callingClass);
/*     */     
/*     */     try {
/* 142 */       return (url != null) ? url.openStream() : null;
/* 143 */     } catch (IOException e) {
/* 144 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class loadClass(String className, Class callingClass) throws ClassNotFoundException {
/*     */     try {
/* 171 */       return Thread.currentThread().getContextClassLoader().loadClass(className);
/* 172 */     } catch (ClassNotFoundException e) {
/*     */       try {
/* 174 */         return Class.forName(className);
/* 175 */       } catch (ClassNotFoundException ex) {
/*     */         try {
/* 177 */           return ClassLoaderUtil.class.getClassLoader().loadClass(className);
/* 178 */         } catch (ClassNotFoundException exc) {
/* 179 */           return callingClass.getClassLoader().loadClass(className);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printClassLoader() {
/* 189 */     System.out.println("ClassLoaderUtils.printClassLoader");
/* 190 */     printClassLoader(Thread.currentThread().getContextClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printClassLoader(ClassLoader cl) {
/* 199 */     System.out.println("ClassLoaderUtils.printClassLoader(cl = " + cl + ")");
/*     */     
/* 201 */     if (cl != null) {
/* 202 */       printClassLoader(cl.getParent());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class AggregateIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/* 214 */     LinkedList<Enumeration<E>> enums = new LinkedList<>();
/* 215 */     Enumeration<E> cur = null;
/* 216 */     E next = null;
/* 217 */     Set<E> loaded = new HashSet<>();
/*     */     
/*     */     public AggregateIterator<E> addEnumeration(Enumeration<E> e) {
/* 220 */       if (e.hasMoreElements()) {
/* 221 */         if (this.cur == null) {
/* 222 */           this.cur = e;
/* 223 */           this.next = e.nextElement();
/* 224 */           this.loaded.add(this.next);
/*     */         } else {
/* 226 */           this.enums.add(e);
/*     */         } 
/*     */       }
/* 229 */       return this;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 233 */       return (this.next != null);
/*     */     }
/*     */     
/*     */     public E next() {
/* 237 */       if (this.next != null) {
/* 238 */         E prev = this.next;
/* 239 */         this.next = loadNext();
/* 240 */         return prev;
/*     */       } 
/* 242 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     
/*     */     private Enumeration<E> determineCurrentEnumeration() {
/* 247 */       if (this.cur != null && !this.cur.hasMoreElements()) {
/* 248 */         if (this.enums.size() > 0) {
/* 249 */           this.cur = this.enums.removeLast();
/*     */         } else {
/* 251 */           this.cur = null;
/*     */         } 
/*     */       }
/* 254 */       return this.cur;
/*     */     }
/*     */     
/*     */     private E loadNext() {
/* 258 */       if (determineCurrentEnumeration() != null) {
/* 259 */         E tmp = this.cur.nextElement();
/* 260 */         int loadedSize = this.loaded.size();
/* 261 */         while (this.loaded.contains(tmp)) {
/* 262 */           tmp = loadNext();
/* 263 */           if (tmp == null || this.loaded.size() > loadedSize) {
/*     */             break;
/*     */           }
/*     */         } 
/* 267 */         if (tmp != null) {
/* 268 */           this.loaded.add(tmp);
/*     */         }
/* 270 */         return tmp;
/*     */       } 
/* 272 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 277 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ClassLoaderUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */