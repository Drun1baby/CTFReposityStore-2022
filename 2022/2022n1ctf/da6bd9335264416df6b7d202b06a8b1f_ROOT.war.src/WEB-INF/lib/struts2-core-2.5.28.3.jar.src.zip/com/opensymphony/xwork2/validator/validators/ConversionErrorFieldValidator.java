/*    */ package com.opensymphony.xwork2.validator.validators;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*    */ import com.opensymphony.xwork2.validator.ValidationException;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversionErrorFieldValidator
/*    */   extends RepopulateConversionErrorFieldValidatorSupport
/*    */ {
/*    */   public void doValidate(Object object) throws ValidationException {
/* 70 */     String fieldName = getFieldName();
/* 71 */     String fullFieldName = getValidatorContext().getFullFieldName(fieldName);
/* 72 */     ActionContext context = ActionContext.getContext();
/* 73 */     Map<String, Object> conversionErrors = context.getConversionErrors();
/*    */     
/* 75 */     if (conversionErrors.containsKey(fullFieldName)) {
/* 76 */       if (StringUtils.isBlank(this.defaultMessage)) {
/* 77 */         this.defaultMessage = XWorkConverter.getConversionErrorMessage(fullFieldName, context.getValueStack());
/*    */       }
/*    */       
/* 80 */       addFieldError(fieldName, object);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\ConversionErrorFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */