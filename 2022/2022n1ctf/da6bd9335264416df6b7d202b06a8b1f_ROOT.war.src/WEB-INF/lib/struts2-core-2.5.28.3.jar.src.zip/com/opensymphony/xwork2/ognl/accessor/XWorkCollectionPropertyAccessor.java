/*     */ package com.opensymphony.xwork2.ognl.accessor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import ognl.ObjectPropertyAccessor;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.SetPropertyAccessor;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkCollectionPropertyAccessor
/*     */   extends SetPropertyAccessor
/*     */ {
/*  44 */   private static final Logger LOG = LogManager.getLogger(XWorkCollectionPropertyAccessor.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String KEY_PROPERTY_FOR_CREATION = "makeNew";
/*     */ 
/*     */   
/*  51 */   private final ObjectPropertyAccessor _accessor = new ObjectPropertyAccessor();
/*     */   
/*     */   private XWorkConverter xworkConverter;
/*     */   private ObjectFactory objectFactory;
/*     */   private ObjectTypeDeterminer objectTypeDeterminer;
/*     */   private OgnlUtil ognlUtil;
/*     */   
/*     */   @Inject
/*     */   public void setXWorkConverter(XWorkConverter conv) {
/*  60 */     this.xworkConverter = conv;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  65 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectTypeDeterminer(ObjectTypeDeterminer ot) {
/*  70 */     this.objectTypeDeterminer = ot;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setOgnlUtil(OgnlUtil util) {
/*  75 */     this.ognlUtil = util;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object key) throws OgnlException {
/*     */     Class<?> keyType;
/*  90 */     LOG.trace("Entering getProperty()");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     if (!ReflectionContextState.isGettingByKeyProperty(context) && !key.equals("makeNew")) {
/*  96 */       return super.getProperty(context, target, key);
/*     */     }
/*     */     
/*  99 */     ReflectionContextState.setGettingByKeyProperty(context, false);
/*     */     
/* 101 */     Collection<E> c = (Collection)target;
/*     */ 
/*     */     
/* 104 */     Class lastBeanClass = ReflectionContextState.getLastBeanClassAccessed(context);
/*     */ 
/*     */     
/* 107 */     String lastPropertyClass = ReflectionContextState.getLastBeanPropertyAccessed(context);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (lastBeanClass == null || lastPropertyClass == null) {
/* 113 */       ReflectionContextState.updateCurrentPropertyPath(context, key);
/* 114 */       return super.getProperty(context, target, key);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 119 */     String keyProperty = this.objectTypeDeterminer.getKeyProperty(lastBeanClass, lastPropertyClass);
/*     */ 
/*     */     
/* 122 */     Class collClass = this.objectTypeDeterminer.getElementClass(lastBeanClass, lastPropertyClass, key);
/*     */ 
/*     */     
/* 125 */     Class toGetTypeFrom = (collClass != null) ? collClass : c.iterator().next().getClass();
/*     */     try {
/* 127 */       keyType = OgnlRuntime.getPropertyDescriptor(toGetTypeFrom, keyProperty).getPropertyType();
/* 128 */     } catch (Exception exc) {
/* 129 */       throw new OgnlException("Error getting property descriptor: " + exc.getMessage());
/*     */     } 
/*     */ 
/*     */     
/* 133 */     if (ReflectionContextState.isCreatingNullObjects(context)) {
/* 134 */       Map<Object, Object> collMap = getSetMap(context, c, keyProperty);
/* 135 */       if (key.toString().equals("makeNew"))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 140 */         return collMap.get(null);
/*     */       }
/* 142 */       Object object1 = this.xworkConverter.convertValue(context, key, keyType);
/* 143 */       Object value = collMap.get(object1);
/* 144 */       if (value == null && ReflectionContextState.isCreatingNullObjects(context) && this.objectTypeDeterminer.shouldCreateIfNew(lastBeanClass, lastPropertyClass, c, keyProperty, false)) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 152 */           value = this.objectFactory.buildBean(collClass, context);
/*     */ 
/*     */           
/* 155 */           this._accessor.setProperty(context, value, keyProperty, object1);
/*     */ 
/*     */           
/* 158 */           c.add((E)value);
/*     */ 
/*     */           
/* 161 */           collMap.put(object1, value);
/*     */         
/*     */         }
/* 164 */         catch (Exception exc) {
/* 165 */           throw new OgnlException("Error adding new element to collection", exc);
/*     */         } 
/*     */       }
/*     */       
/* 169 */       return value;
/*     */     } 
/* 171 */     if (key.toString().equals("makeNew")) {
/* 172 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     Object realKey = this.xworkConverter.convertValue(context, key, keyType);
/* 180 */     return getPropertyThroughIteration(context, c, keyProperty, realKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map getSetMap(Map context, Collection collection, String property) throws OgnlException {
/* 189 */     LOG.trace("getting set Map");
/*     */     
/* 191 */     String path = ReflectionContextState.getCurrentPropertyPath(context);
/* 192 */     Map<Object, Object> map = ReflectionContextState.getSetMap(context, path);
/*     */     
/* 194 */     if (map == null) {
/* 195 */       LOG.trace("creating set Map");
/*     */       
/* 197 */       map = new HashMap<>();
/* 198 */       map.put(null, new SurrugateList(collection));
/* 199 */       for (Object currTest : collection) {
/* 200 */         Object currKey = this._accessor.getProperty(context, currTest, property);
/* 201 */         if (currKey != null) {
/* 202 */           map.put(currKey, currTest);
/*     */         }
/*     */       } 
/* 205 */       ReflectionContextState.setSetMap(context, map, path);
/*     */     } 
/* 207 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPropertyThroughIteration(Map context, Collection collection, String property, Object key) throws OgnlException {
/* 216 */     for (Object currTest : collection) {
/* 217 */       if (this._accessor.getProperty(context, currTest, property).equals(key)) {
/* 218 */         return currTest;
/*     */       }
/*     */     } 
/*     */     
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 227 */     Class lastClass = (Class)context.get("last.bean.accessed");
/* 228 */     String lastProperty = (String)context.get("last.property.accessed");
/* 229 */     Class convertToClass = this.objectTypeDeterminer.getElementClass(lastClass, lastProperty, name);
/*     */     
/* 231 */     if (name instanceof String && value.getClass().isArray()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 236 */       Collection<Object> c = (Collection)target;
/* 237 */       Object[] values = (Object[])value;
/* 238 */       for (Object v : values) {
/*     */         try {
/* 240 */           Object o = this.objectFactory.buildBean(convertToClass, context);
/* 241 */           this.ognlUtil.setValue((String)name, context, o, v);
/* 242 */           c.add(o);
/* 243 */         } catch (Exception e) {
/* 244 */           throw new OgnlException("Error converting given String values for Collection.", e);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 253 */     Object realValue = getRealValue(context, value, convertToClass);
/*     */     
/* 255 */     super.setProperty(context, target, name, realValue);
/*     */   }
/*     */   
/*     */   private Object getRealValue(Map context, Object value, Class convertToClass) {
/* 259 */     if (value == null || convertToClass == null) {
/* 260 */       return value;
/*     */     }
/* 262 */     return this.xworkConverter.convertValue(context, value, convertToClass);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\XWorkCollectionPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */