/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionMappingInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/* 159 */   private static final Logger LOG = LogManager.getLogger(ExceptionMappingInterceptor.class);
/*     */   
/*     */   protected Logger categoryLogger;
/*     */   
/*     */   protected boolean logEnabled = false;
/*     */   protected String logCategory;
/*     */   protected String logLevel;
/*     */   
/*     */   public boolean isLogEnabled() {
/* 168 */     return this.logEnabled;
/*     */   }
/*     */   
/*     */   public void setLogEnabled(boolean logEnabled) {
/* 172 */     this.logEnabled = logEnabled;
/*     */   }
/*     */   
/*     */   public String getLogCategory() {
/* 176 */     return this.logCategory;
/*     */   }
/*     */   
/*     */   public void setLogCategory(String logCatgory) {
/* 180 */     this.logCategory = logCatgory;
/*     */   }
/*     */   
/*     */   public String getLogLevel() {
/* 184 */     return this.logLevel;
/*     */   }
/*     */   
/*     */   public void setLogLevel(String logLevel) {
/* 188 */     this.logLevel = logLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/*     */     String result;
/*     */     try {
/* 196 */       result = invocation.invoke();
/* 197 */     } catch (Exception e) {
/* 198 */       if (isLogEnabled()) {
/* 199 */         handleLogging(e);
/*     */       }
/* 201 */       List<ExceptionMappingConfig> exceptionMappings = invocation.getProxy().getConfig().getExceptionMappings();
/* 202 */       ExceptionMappingConfig mappingConfig = findMappingFromExceptions(exceptionMappings, e);
/* 203 */       if (mappingConfig != null && mappingConfig.getResult() != null) {
/* 204 */         Map<String, String> mappingParams = mappingConfig.getParams();
/*     */         
/* 206 */         HttpParameters parameters = HttpParameters.create(mappingParams).build();
/* 207 */         invocation.getInvocationContext().setParameters(parameters);
/* 208 */         result = mappingConfig.getResult();
/* 209 */         publishException(invocation, new ExceptionHolder(e));
/*     */       } else {
/* 211 */         throw e;
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleLogging(Exception e) {
/* 224 */     if (this.logCategory != null) {
/* 225 */       if (this.categoryLogger == null)
/*     */       {
/* 227 */         this.categoryLogger = LogManager.getLogger(this.logCategory);
/*     */       }
/* 229 */       doLog(this.categoryLogger, e);
/*     */     } else {
/* 231 */       doLog(LOG, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doLog(Logger logger, Exception e) {
/* 242 */     if (this.logLevel == null) {
/* 243 */       logger.debug(e.getMessage(), e);
/*     */       
/*     */       return;
/*     */     } 
/* 247 */     if ("trace".equalsIgnoreCase(this.logLevel)) {
/* 248 */       logger.trace(e.getMessage(), e);
/* 249 */     } else if ("debug".equalsIgnoreCase(this.logLevel)) {
/* 250 */       logger.debug(e.getMessage(), e);
/* 251 */     } else if ("info".equalsIgnoreCase(this.logLevel)) {
/* 252 */       logger.info(e.getMessage(), e);
/* 253 */     } else if ("warn".equalsIgnoreCase(this.logLevel)) {
/* 254 */       logger.warn(e.getMessage(), e);
/* 255 */     } else if ("error".equalsIgnoreCase(this.logLevel)) {
/* 256 */       logger.error(e.getMessage(), e);
/* 257 */     } else if ("fatal".equalsIgnoreCase(this.logLevel)) {
/* 258 */       logger.fatal(e.getMessage(), e);
/*     */     } else {
/* 260 */       throw new IllegalArgumentException("LogLevel [" + this.logLevel + "] is not supported");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ExceptionMappingConfig findMappingFromExceptions(List<ExceptionMappingConfig> exceptionMappings, Throwable t) {
/* 272 */     ExceptionMappingConfig config = null;
/*     */     
/* 274 */     if (exceptionMappings != null) {
/* 275 */       int deepest = Integer.MAX_VALUE;
/* 276 */       for (ExceptionMappingConfig exceptionMapping : exceptionMappings) {
/* 277 */         ExceptionMappingConfig exceptionMappingConfig = exceptionMapping;
/* 278 */         int depth = getDepth(exceptionMappingConfig.getExceptionClassName(), t);
/* 279 */         if (depth >= 0 && depth < deepest) {
/* 280 */           deepest = depth;
/* 281 */           config = exceptionMappingConfig;
/*     */         } 
/*     */       } 
/*     */     } 
/* 285 */     return config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDepth(String exceptionMapping, Throwable t) {
/* 297 */     return getDepth(exceptionMapping, t.getClass(), 0);
/*     */   }
/*     */   
/*     */   private int getDepth(String exceptionMapping, Class exceptionClass, int depth) {
/* 301 */     if (exceptionClass.getName().contains(exceptionMapping))
/*     */     {
/* 303 */       return depth;
/*     */     }
/*     */     
/* 306 */     if (exceptionClass.equals(Throwable.class)) {
/* 307 */       return -1;
/*     */     }
/* 309 */     return getDepth(exceptionMapping, exceptionClass.getSuperclass(), depth + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishException(ActionInvocation invocation, ExceptionHolder exceptionHolder) {
/* 320 */     invocation.getStack().push(exceptionHolder);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ExceptionMappingInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */