/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.io.Serializable;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultActionProxy
/*     */   implements ActionProxy, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3293074152487468527L;
/*  46 */   private static final Logger LOG = LogManager.getLogger(DefaultActionProxy.class);
/*     */ 
/*     */   
/*     */   protected Configuration configuration;
/*     */ 
/*     */   
/*     */   protected ActionConfig config;
/*     */ 
/*     */   
/*     */   protected ActionInvocation invocation;
/*     */ 
/*     */   
/*     */   protected UnknownHandlerManager unknownHandlerManager;
/*     */ 
/*     */   
/*     */   protected LocalizedTextProvider localizedTextProvider;
/*     */ 
/*     */   
/*     */   protected String actionName;
/*     */ 
/*     */   
/*     */   protected String namespace;
/*     */ 
/*     */   
/*     */   protected String method;
/*     */   
/*     */   protected boolean executeResult;
/*     */   
/*     */   protected boolean cleanupContext;
/*     */   
/*     */   protected ObjectFactory objectFactory;
/*     */   
/*     */   protected ActionEventListener actionEventListener;
/*     */   
/*     */   private boolean methodSpecified = true;
/*     */ 
/*     */   
/*     */   protected DefaultActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext) {
/*  84 */     this.invocation = inv;
/*  85 */     this.cleanupContext = cleanupContext;
/*  86 */     LOG.debug("Creating an DefaultActionProxy for namespace [{}] and action name [{}]", namespace, actionName);
/*     */     
/*  88 */     this.actionName = StringEscapeUtils.escapeHtml4(actionName);
/*  89 */     this.namespace = namespace;
/*  90 */     this.executeResult = executeResult;
/*  91 */     this.method = StringEscapeUtils.escapeEcmaScript(StringEscapeUtils.escapeHtml4(methodName));
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory factory) {
/*  96 */     this.objectFactory = factory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setConfiguration(Configuration config) {
/* 101 */     this.configuration = config;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUnknownHandler(UnknownHandlerManager unknownHandlerManager) {
/* 106 */     this.unknownHandlerManager = unknownHandlerManager;
/*     */   }
/*     */   
/*     */   @Inject(required = false)
/*     */   public void setActionEventListener(ActionEventListener listener) {
/* 111 */     this.actionEventListener = listener;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/* 116 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */   
/*     */   public Object getAction() {
/* 120 */     return this.invocation.getAction();
/*     */   }
/*     */   
/*     */   public String getActionName() {
/* 124 */     return this.actionName;
/*     */   }
/*     */   
/*     */   public ActionConfig getConfig() {
/* 128 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setExecuteResult(boolean executeResult) {
/* 132 */     this.executeResult = executeResult;
/*     */   }
/*     */   
/*     */   public boolean getExecuteResult() {
/* 136 */     return this.executeResult;
/*     */   }
/*     */   
/*     */   public ActionInvocation getInvocation() {
/* 140 */     return this.invocation;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 144 */     return this.namespace;
/*     */   }
/*     */   
/*     */   public String execute() throws Exception {
/* 148 */     ActionContext nestedContext = ActionContext.getContext();
/* 149 */     ActionContext.setContext(this.invocation.getInvocationContext());
/*     */     
/* 151 */     String retCode = null;
/*     */     
/* 153 */     String profileKey = "execute: ";
/*     */     try {
/* 155 */       UtilTimerStack.push(profileKey);
/*     */       
/* 157 */       retCode = this.invocation.invoke();
/*     */     } finally {
/* 159 */       if (this.cleanupContext) {
/* 160 */         ActionContext.setContext(nestedContext);
/*     */       }
/* 162 */       UtilTimerStack.pop(profileKey);
/*     */     } 
/*     */     
/* 165 */     return retCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMethod() {
/* 170 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void resolveMethod() {
/* 176 */     if (StringUtils.isEmpty(this.method)) {
/* 177 */       this.method = this.config.getMethodName();
/* 178 */       if (StringUtils.isEmpty(this.method)) {
/* 179 */         this.method = "execute";
/*     */       }
/* 181 */       this.methodSpecified = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void prepare() {
/* 186 */     String profileKey = "create DefaultActionProxy: ";
/*     */     try {
/* 188 */       UtilTimerStack.push(profileKey);
/* 189 */       this.config = this.configuration.getRuntimeConfiguration().getActionConfig(this.namespace, this.actionName);
/*     */       
/* 191 */       if (this.config == null && this.unknownHandlerManager.hasUnknownHandlers()) {
/* 192 */         this.config = this.unknownHandlerManager.handleUnknownAction(this.namespace, this.actionName);
/*     */       }
/* 194 */       if (this.config == null) {
/* 195 */         throw new ConfigurationException(getErrorMessage());
/*     */       }
/*     */       
/* 198 */       resolveMethod();
/*     */       
/* 200 */       if (this.config.isAllowedMethod(this.method)) {
/* 201 */         this.invocation.init(this);
/*     */       } else {
/* 203 */         throw new ConfigurationException(prepareNotAllowedErrorMessage());
/*     */       } 
/*     */     } finally {
/* 206 */       UtilTimerStack.pop(profileKey);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String prepareNotAllowedErrorMessage() {
/* 211 */     return this.localizedTextProvider.findDefaultText("struts.exception.method-not-allowed", Locale.getDefault(), (Object[])new String[] { this.method, this.actionName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getErrorMessage() {
/* 219 */     if (this.namespace != null && this.namespace.trim().length() > 0) {
/* 220 */       return this.localizedTextProvider.findDefaultText("xwork.exception.missing-package-action", Locale.getDefault(), (Object[])new String[] { this.namespace, this.actionName });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 225 */     return this.localizedTextProvider.findDefaultText("xwork.exception.missing-action", Locale.getDefault(), (Object[])new String[] { this.actionName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMethodSpecified() {
/* 233 */     return this.methodSpecified;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultActionProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */