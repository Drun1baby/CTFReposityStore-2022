/*    */ package com.opensymphony.xwork2.inject;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InternalContext
/*    */ {
/*    */   final ContainerImpl container;
/* 31 */   final Map<Object, ConstructionContext<?>> constructionContexts = new HashMap<>();
/*    */   Scope.Strategy scopeStrategy;
/*    */   ExternalContext<?> externalContext;
/*    */   
/*    */   InternalContext(ContainerImpl container) {
/* 36 */     this.container = container;
/*    */   }
/*    */   
/*    */   public Container getContainer() {
/* 40 */     return this.container;
/*    */   }
/*    */   
/*    */   ContainerImpl getContainerImpl() {
/* 44 */     return this.container;
/*    */   }
/*    */   
/*    */   Scope.Strategy getScopeStrategy() {
/* 48 */     if (this.scopeStrategy == null) {
/* 49 */       this.scopeStrategy = (Scope.Strategy)this.container.localScopeStrategy.get();
/*    */       
/* 51 */       if (this.scopeStrategy == null) {
/* 52 */         throw new IllegalStateException("Scope strategy not set. Please call Container.setScopeStrategy().");
/*    */       }
/*    */     } 
/*    */     
/* 56 */     return this.scopeStrategy;
/*    */   }
/*    */ 
/*    */   
/*    */   <T> ConstructionContext<T> getConstructionContext(Object key) {
/* 61 */     ConstructionContext<T> constructionContext = (ConstructionContext<T>)this.constructionContexts.get(key);
/* 62 */     if (constructionContext == null) {
/* 63 */       constructionContext = new ConstructionContext<>();
/* 64 */       this.constructionContexts.put(key, constructionContext);
/*    */     } 
/* 66 */     return constructionContext;
/*    */   }
/*    */ 
/*    */   
/*    */   <T> ExternalContext<T> getExternalContext() {
/* 71 */     return (ExternalContext)this.externalContext;
/*    */   }
/*    */   
/*    */   void setExternalContext(ExternalContext<?> externalContext) {
/* 75 */     this.externalContext = externalContext;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\InternalContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */