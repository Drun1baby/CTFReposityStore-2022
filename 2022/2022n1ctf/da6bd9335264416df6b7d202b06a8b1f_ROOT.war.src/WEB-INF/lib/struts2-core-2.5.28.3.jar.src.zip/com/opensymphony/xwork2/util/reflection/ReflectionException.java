/*    */ package com.opensymphony.xwork2.util.reflection;
/*    */ 
/*    */ import com.opensymphony.xwork2.XWorkException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReflectionException
/*    */   extends XWorkException
/*    */ {
/*    */   public ReflectionException() {}
/*    */   
/*    */   public ReflectionException(String s) {
/* 30 */     super(s);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReflectionException(String s, Object target) {
/* 35 */     super(s, target);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReflectionException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReflectionException(Throwable cause, Object target) {
/* 45 */     super(cause, target);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReflectionException(String s, Throwable cause) {
/* 50 */     super(s, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReflectionException(String s, Throwable cause, Object target) {
/* 55 */     super(s, cause, target);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\reflection\ReflectionException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */