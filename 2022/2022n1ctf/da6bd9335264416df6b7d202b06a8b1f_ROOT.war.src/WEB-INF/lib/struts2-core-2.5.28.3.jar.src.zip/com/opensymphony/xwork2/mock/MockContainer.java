/*    */ package com.opensymphony.xwork2.mock;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MockContainer
/*    */   implements Container
/*    */ {
/*    */   public void inject(Object o) {}
/*    */   
/*    */   public <T> T inject(Class<T> implementation) {
/* 36 */     return null;
/*    */   }
/*    */   
/*    */   public <T> T getInstance(Class<T> type, String name) {
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public <T> T getInstance(Class<T> type) {
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public Set<String> getInstanceNames(Class<?> type) {
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public void setScopeStrategy(Scope.Strategy scopeStrategy) {}
/*    */   
/*    */   public void removeScopeStrategy() {}
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */