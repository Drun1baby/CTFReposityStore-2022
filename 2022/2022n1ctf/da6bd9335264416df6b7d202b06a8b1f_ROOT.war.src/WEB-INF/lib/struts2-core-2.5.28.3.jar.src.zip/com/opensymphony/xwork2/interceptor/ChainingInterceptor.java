/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionChainResult;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ProxyUtil;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChainingInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/* 118 */   private static final Logger LOG = LogManager.getLogger(ChainingInterceptor.class);
/*     */   
/*     */   private static final String ACTION_ERRORS = "actionErrors";
/*     */   
/*     */   private static final String FIELD_ERRORS = "fieldErrors";
/*     */   
/*     */   private static final String ACTION_MESSAGES = "actionMessages";
/*     */   
/*     */   private boolean copyMessages = false;
/*     */   private boolean copyErrors = false;
/*     */   private boolean copyFieldErrors = false;
/*     */   protected Collection<String> excludes;
/*     */   protected Collection<String> includes;
/*     */   protected ReflectionProvider reflectionProvider;
/*     */   
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/* 135 */     this.reflectionProvider = prov;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.xwork.chaining.copyErrors", required = false)
/*     */   public void setCopyErrors(String copyErrors) {
/* 140 */     this.copyErrors = "true".equalsIgnoreCase(copyErrors);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.xwork.chaining.copyFieldErrors", required = false)
/*     */   public void setCopyFieldErrors(String copyFieldErrors) {
/* 145 */     this.copyFieldErrors = "true".equalsIgnoreCase(copyFieldErrors);
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.xwork.chaining.copyMessages", required = false)
/*     */   public void setCopyMessages(String copyMessages) {
/* 150 */     this.copyMessages = "true".equalsIgnoreCase(copyMessages);
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 155 */     ValueStack stack = invocation.getStack();
/* 156 */     CompoundRoot root = stack.getRoot();
/* 157 */     if (shouldCopyStack(invocation, root)) {
/* 158 */       copyStack(invocation, root);
/*     */     }
/* 160 */     return invocation.invoke();
/*     */   }
/*     */   
/*     */   private void copyStack(ActionInvocation invocation, CompoundRoot root) {
/* 164 */     List list = prepareList(root);
/* 165 */     Map<String, Object> ctxMap = invocation.getInvocationContext().getContextMap();
/* 166 */     for (Object object : list) {
/* 167 */       if (shouldCopy(object)) {
/* 168 */         Object action = invocation.getAction();
/* 169 */         Class<?> editable = null;
/* 170 */         if (ProxyUtil.isProxy(action)) {
/* 171 */           editable = ProxyUtil.ultimateTargetClass(action);
/*     */         }
/* 173 */         this.reflectionProvider.copy(object, action, ctxMap, prepareExcludes(), this.includes, editable);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Collection<String> prepareExcludes() {
/* 179 */     Collection<String> localExcludes = this.excludes;
/* 180 */     if ((!this.copyErrors || !this.copyMessages || !this.copyFieldErrors) && 
/* 181 */       localExcludes == null) {
/* 182 */       localExcludes = new HashSet<>();
/* 183 */       if (!this.copyErrors) {
/* 184 */         localExcludes.add("actionErrors");
/*     */       }
/* 186 */       if (!this.copyMessages) {
/* 187 */         localExcludes.add("actionMessages");
/*     */       }
/* 189 */       if (!this.copyFieldErrors) {
/* 190 */         localExcludes.add("fieldErrors");
/*     */       }
/*     */     } 
/*     */     
/* 194 */     return localExcludes;
/*     */   }
/*     */   
/*     */   private boolean shouldCopy(Object o) {
/* 198 */     return (o != null && !(o instanceof com.opensymphony.xwork2.Unchainable));
/*     */   }
/*     */ 
/*     */   
/*     */   private List prepareList(CompoundRoot root) {
/* 203 */     List<?> list = new ArrayList((Collection<?>)root);
/* 204 */     list.remove(0);
/* 205 */     Collections.reverse(list);
/* 206 */     return list;
/*     */   }
/*     */   
/*     */   private boolean shouldCopyStack(ActionInvocation invocation, CompoundRoot root) throws Exception {
/* 210 */     Result result = invocation.getResult();
/* 211 */     return (root.size() > 1 && (result == null || ActionChainResult.class.isAssignableFrom(result.getClass())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getExcludes() {
/* 220 */     return this.excludes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludes(String excludes) {
/* 229 */     this.excludes = TextParseUtil.commaDelimitedStringToSet(excludes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludesCollection(Collection<String> excludes) {
/* 238 */     this.excludes = excludes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getIncludes() {
/* 247 */     return this.includes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludes(String includes) {
/* 256 */     this.includes = TextParseUtil.commaDelimitedStringToSet(includes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIncludesCollection(Collection<String> includes) {
/* 266 */     this.includes = includes;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ChainingInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */