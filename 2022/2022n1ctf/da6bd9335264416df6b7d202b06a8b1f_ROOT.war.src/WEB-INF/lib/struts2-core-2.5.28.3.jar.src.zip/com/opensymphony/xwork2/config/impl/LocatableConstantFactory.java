/*    */ package com.opensymphony.xwork2.config.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Context;
/*    */ import com.opensymphony.xwork2.inject.Factory;
/*    */ import com.opensymphony.xwork2.util.location.Located;
/*    */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocatableConstantFactory<T>
/*    */   extends Located
/*    */   implements Factory
/*    */ {
/*    */   T constant;
/*    */   
/*    */   public LocatableConstantFactory(T constant, Object location) {
/* 32 */     this.constant = constant;
/* 33 */     setLocation(LocationUtils.getLocation(location));
/*    */   }
/*    */   
/*    */   public T create(Context ignored) {
/* 37 */     return this.constant;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class type() {
/* 42 */     return this.constant.getClass();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuilder sb = new StringBuilder();
/* 48 */     sb.append(super.toString());
/* 49 */     sb.append(" defined at ");
/* 50 */     sb.append(getLocation().toString());
/* 51 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\LocatableConstantFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */