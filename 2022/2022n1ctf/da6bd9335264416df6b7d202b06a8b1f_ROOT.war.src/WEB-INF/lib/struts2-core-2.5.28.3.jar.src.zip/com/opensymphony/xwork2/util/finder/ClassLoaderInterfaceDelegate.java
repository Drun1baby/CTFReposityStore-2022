/*    */ package com.opensymphony.xwork2.util.finder;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLoaderInterfaceDelegate
/*    */   implements ClassLoaderInterface
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public ClassLoaderInterfaceDelegate(ClassLoader classLoader) {
/* 33 */     this.classLoader = classLoader;
/*    */   }
/*    */   
/*    */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/* 37 */     return this.classLoader.loadClass(name);
/*    */   }
/*    */   
/*    */   public URL getResource(String className) {
/* 41 */     return this.classLoader.getResource(className);
/*    */   }
/*    */   
/*    */   public Enumeration<URL> getResources(String name) throws IOException {
/* 45 */     return this.classLoader.getResources(name);
/*    */   }
/*    */   
/*    */   public InputStream getResourceAsStream(String name) {
/* 49 */     return this.classLoader.getResourceAsStream(name);
/*    */   }
/*    */   
/*    */   public ClassLoaderInterface getParent() {
/* 53 */     return (this.classLoader.getParent() != null) ? new ClassLoaderInterfaceDelegate(this.classLoader.getParent()) : null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\finder\ClassLoaderInterfaceDelegate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */