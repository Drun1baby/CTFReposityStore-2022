/*    */ package com.opensymphony.xwork2.interceptor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*    */ import com.opensymphony.xwork2.util.TextParseUtil;
/*    */ import com.opensymphony.xwork2.util.TextParser;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WithLazyParams
/*    */ {
/*    */   public static class LazyParamInjector
/*    */   {
/*    */     protected OgnlUtil ognlUtil;
/*    */     protected TextParser textParser;
/*    */     protected ReflectionProvider reflectionProvider;
/*    */     
/* 50 */     private final TextParseUtil.ParsedValueEvaluator valueEvaluator = new TextParseUtil.ParsedValueEvaluator() {
/*    */         public Object evaluate(String parsedValue) {
/* 52 */           return valueStack.findValue(parsedValue);
/*    */         }
/*    */       };
/*    */ 
/*    */     
/*    */     @Inject
/*    */     public void setTextParser(TextParser textParser) {
/* 59 */       this.textParser = textParser;
/*    */     }
/*    */     public LazyParamInjector(final ValueStack valueStack) {}
/*    */     @Inject
/*    */     public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 64 */       this.reflectionProvider = reflectionProvider;
/*    */     }
/*    */     
/*    */     @Inject
/*    */     public void setOgnlUtil(OgnlUtil ognlUtil) {
/* 69 */       this.ognlUtil = ognlUtil;
/*    */     }
/*    */     
/*    */     public Interceptor injectParams(Interceptor interceptor, Map<String, String> params, ActionContext invocationContext) {
/* 73 */       for (Map.Entry<String, String> entry : params.entrySet()) {
/* 74 */         Object paramValue = this.textParser.evaluate(new char[] { '$' }, entry.getValue(), this.valueEvaluator, 1);
/* 75 */         this.ognlUtil.setProperty(entry.getKey(), paramValue, interceptor, invocationContext.getContextMap());
/*    */       } 
/*    */       
/* 78 */       return interceptor;
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\WithLazyParams.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */