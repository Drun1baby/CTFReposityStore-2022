/*    */ package com.opensymphony.xwork2.config.entities;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.location.Located;
/*    */ import com.opensymphony.xwork2.util.location.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownHandlerConfig
/*    */   extends Located
/*    */ {
/*    */   private String name;
/*    */   
/*    */   public UnknownHandlerConfig(String name, Location location) {
/* 29 */     this.name = name;
/* 30 */     this.location = location;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 38 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return "UnknownHandlerConfig: [" + this.name + "]";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\UnknownHandlerConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */