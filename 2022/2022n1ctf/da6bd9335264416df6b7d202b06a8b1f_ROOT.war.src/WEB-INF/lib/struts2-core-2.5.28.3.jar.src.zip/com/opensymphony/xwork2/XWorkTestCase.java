/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.inject.Context;
/*    */ import com.opensymphony.xwork2.inject.Factory;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import com.opensymphony.xwork2.test.StubConfigurationProvider;
/*    */ import com.opensymphony.xwork2.util.XWorkTestCaseHelper;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ import junit.framework.TestCase;
/*    */ import org.apache.commons.lang3.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XWorkTestCase
/*    */   extends TestCase
/*    */ {
/*    */   protected ConfigurationManager configurationManager;
/*    */   protected Configuration configuration;
/*    */   protected Container container;
/*    */   protected ActionProxyFactory actionProxyFactory;
/*    */   
/*    */   protected void setUp() throws Exception {
/* 51 */     this.configurationManager = XWorkTestCaseHelper.setUp();
/* 52 */     this.configuration = this.configurationManager.getConfiguration();
/* 53 */     this.container = this.configuration.getContainer();
/* 54 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void tearDown() throws Exception {
/* 59 */     XWorkTestCaseHelper.tearDown(this.configurationManager);
/* 60 */     this.configurationManager = null;
/* 61 */     this.configuration = null;
/* 62 */     this.container = null;
/* 63 */     this.actionProxyFactory = null;
/*    */   }
/*    */   
/*    */   protected void loadConfigurationProviders(ConfigurationProvider... providers) {
/* 67 */     this.configurationManager = XWorkTestCaseHelper.loadConfigurationProviders(this.configurationManager, providers);
/* 68 */     this.configuration = this.configurationManager.getConfiguration();
/* 69 */     this.container = this.configuration.getContainer();
/* 70 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */   
/*    */   protected void loadButAdd(Class<?> type, Object impl) {
/* 74 */     loadButAdd(type, "default", impl);
/*    */   }
/*    */   
/*    */   protected void loadButAdd(final Class<?> type, final String name, final Object impl) {
/* 78 */     loadConfigurationProviders(new ConfigurationProvider[] { (ConfigurationProvider)new StubConfigurationProvider()
/*    */           {
/*    */             public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException
/*    */             {
/* 82 */               if (impl instanceof String || ClassUtils.isPrimitiveOrWrapper(impl.getClass())) {
/* 83 */                 props.setProperty(name, "" + impl);
/*    */               } else {
/* 85 */                 builder.factory(type, name, new Factory() {
/*    */                       public Object create(Context context) throws Exception {
/* 87 */                         return impl;
/*    */                       }
/*    */ 
/*    */                       
/*    */                       public Class type() {
/* 92 */                         return impl.getClass();
/*    */                       }
/*    */                     },  Scope.SINGLETON);
/*    */               } 
/*    */             }
/*    */           } });
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\XWorkTestCase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */