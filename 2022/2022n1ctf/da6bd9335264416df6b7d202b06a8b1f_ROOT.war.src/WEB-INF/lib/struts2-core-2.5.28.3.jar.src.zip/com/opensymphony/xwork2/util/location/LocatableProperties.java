/*    */ package com.opensymphony.xwork2.util.location;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.PropertiesReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocatableProperties
/*    */   extends Properties
/*    */   implements Locatable
/*    */ {
/*    */   Location location;
/*    */   Map<String, Location> propLocations;
/*    */   
/*    */   public LocatableProperties() {
/* 43 */     this(Location.UNKNOWN);
/*    */   }
/*    */ 
/*    */   
/*    */   public LocatableProperties(Location loc) {
/* 48 */     this.location = loc;
/* 49 */     this.propLocations = new HashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public void load(InputStream in) throws IOException {
/* 54 */     Reader reader = new InputStreamReader(in);
/* 55 */     PropertiesReader pr = new PropertiesReader(reader);
/* 56 */     while (pr.nextProperty()) {
/* 57 */       String name = pr.getPropertyName();
/* 58 */       String val = pr.getPropertyValue();
/* 59 */       int line = pr.getLineNumber();
/* 60 */       String desc = convertCommentsToString(pr.getCommentLines());
/*    */       
/* 62 */       Location loc = new LocationImpl(desc, this.location.getURI(), line, 0);
/* 63 */       setProperty(name, val, loc);
/*    */     } 
/*    */   }
/*    */   
/*    */   String convertCommentsToString(List<String> lines) {
/* 68 */     StringBuilder sb = new StringBuilder();
/* 69 */     if (lines != null && !lines.isEmpty()) {
/* 70 */       for (String line : lines) {
/* 71 */         sb.append(line).append('\n');
/*    */       }
/*    */     }
/* 74 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public Object setProperty(String key, String value, Object locationObj) {
/* 78 */     Object obj = setProperty(key, value);
/* 79 */     if (this.location != null) {
/* 80 */       Location loc = LocationUtils.getLocation(locationObj);
/* 81 */       this.propLocations.put(key, loc);
/*    */     } 
/* 83 */     return obj;
/*    */   }
/*    */   
/*    */   public Location getPropertyLocation(String key) {
/* 87 */     Location loc = this.propLocations.get(key);
/* 88 */     if (loc != null) {
/* 89 */       return loc;
/*    */     }
/* 91 */     return Location.UNKNOWN;
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 96 */     return this.location;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\location\LocatableProperties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */