package com.opensymphony.xwork2;

import com.opensymphony.xwork2.util.ValueStack;

public interface ActionEventListener {
  Object prepare(Object paramObject, ValueStack paramValueStack);
  
  String handleException(Throwable paramThrowable, ValueStack paramValueStack);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ActionEventListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */