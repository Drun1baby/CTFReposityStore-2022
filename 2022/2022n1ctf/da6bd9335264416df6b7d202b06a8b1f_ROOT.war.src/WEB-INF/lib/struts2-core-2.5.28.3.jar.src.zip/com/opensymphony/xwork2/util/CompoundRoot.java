/*    */ package com.opensymphony.xwork2.util;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompoundRoot
/*    */   extends CopyOnWriteArrayList<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 8563229069192473995L;
/*    */   
/*    */   public CompoundRoot() {}
/*    */   
/*    */   public CompoundRoot(List<?> list) {
/* 39 */     super(list);
/*    */   }
/*    */ 
/*    */   
/*    */   public CompoundRoot cutStack(int index) {
/* 44 */     return new CompoundRoot(subList(index, size()));
/*    */   }
/*    */   
/*    */   public Object peek() {
/* 48 */     return get(0);
/*    */   }
/*    */   
/*    */   public Object pop() {
/* 52 */     return remove(0);
/*    */   }
/*    */   
/*    */   public void push(Object o) {
/* 56 */     add(0, o);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\CompoundRoot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */