/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleRangeFieldValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*  97 */   private static final Logger LOG = LogManager.getLogger(DoubleRangeFieldValidator.class);
/*     */   
/*  99 */   private Double maxInclusive = null;
/* 100 */   private Double minInclusive = null;
/* 101 */   private Double minExclusive = null;
/* 102 */   private Double maxExclusive = null;
/*     */   
/*     */   private String minInclusiveExpression;
/*     */   private String maxInclusiveExpression;
/*     */   private String minExclusiveExpression;
/*     */   private String maxExclusiveExpression;
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/* 110 */     String fieldName = getFieldName();
/* 111 */     Object obj = getFieldValue(fieldName, object);
/* 112 */     if (obj == null) {
/*     */       return;
/*     */     }
/*     */     
/* 116 */     Double maxInclusiveToUse = getMaxInclusive();
/* 117 */     Double minInclusiveToUse = getMinInclusive();
/* 118 */     Double maxExclusiveToUse = getMaxExclusive();
/* 119 */     Double minExclusiveToUse = getMinExclusive();
/*     */     
/* 121 */     if (obj.getClass().isArray()) {
/* 122 */       Object[] values = (Object[])obj;
/* 123 */       validateCollection(maxInclusiveToUse, minInclusiveToUse, maxExclusiveToUse, minExclusiveToUse, Arrays.asList(values));
/* 124 */     } else if (Collection.class.isAssignableFrom(obj.getClass())) {
/* 125 */       Collection values = (Collection)obj;
/* 126 */       validateCollection(maxInclusiveToUse, minInclusiveToUse, maxExclusiveToUse, minExclusiveToUse, values);
/*     */     } else {
/* 128 */       validateValue(obj, maxInclusiveToUse, minInclusiveToUse, maxExclusiveToUse, minExclusiveToUse);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateCollection(Double maxInclusiveToUse, Double minInclusiveToUse, Double maxExclusiveToUse, Double minExclusiveToUse, Collection values) {
/* 133 */     for (Object objValue : values) {
/* 134 */       validateValue(objValue, maxInclusiveToUse, minInclusiveToUse, maxExclusiveToUse, minExclusiveToUse);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateValue(Object obj, Double maxInclusiveToUse, Double minInclusiveToUse, Double maxExclusiveToUse, Double minExclusiveToUse) {
/*     */     try {
/* 140 */       setCurrentValue(obj);
/* 141 */       Double value = Double.valueOf(obj.toString());
/* 142 */       if ((maxInclusiveToUse != null && value.compareTo(maxInclusiveToUse) > 0) || (minInclusiveToUse != null && value.compareTo(minInclusiveToUse) < 0) || (maxExclusiveToUse != null && value.compareTo(maxExclusiveToUse) >= 0) || (minExclusiveToUse != null && value.compareTo(minExclusiveToUse) <= 0))
/*     */       {
/*     */ 
/*     */         
/* 146 */         addFieldError(getFieldName(), value);
/*     */       }
/* 148 */     } catch (NumberFormatException e) {
/* 149 */       LOG.debug("Cannot validate value {} - not a Double", e);
/*     */     } finally {
/* 151 */       setCurrentValue((Object)null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMaxInclusive(Double maxInclusive) {
/* 156 */     this.maxInclusive = maxInclusive;
/*     */   }
/*     */   
/*     */   public Double getMaxInclusive() {
/* 160 */     if (this.maxInclusive != null)
/* 161 */       return this.maxInclusive; 
/* 162 */     if (StringUtils.isNotEmpty(this.maxInclusiveExpression)) {
/* 163 */       return (Double)parse(this.maxInclusiveExpression, Double.class);
/*     */     }
/* 165 */     return this.maxInclusive;
/*     */   }
/*     */   
/*     */   public void setMinInclusive(Double minInclusive) {
/* 169 */     this.minInclusive = minInclusive;
/*     */   }
/*     */   
/*     */   public Double getMinInclusive() {
/* 173 */     if (this.minInclusive != null)
/* 174 */       return this.minInclusive; 
/* 175 */     if (StringUtils.isNotEmpty(this.minInclusiveExpression)) {
/* 176 */       return (Double)parse(this.minInclusiveExpression, Double.class);
/*     */     }
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   public void setMinExclusive(Double minExclusive) {
/* 182 */     this.minExclusive = minExclusive;
/*     */   }
/*     */   
/*     */   public Double getMinExclusive() {
/* 186 */     if (this.minExclusive != null)
/* 187 */       return this.minExclusive; 
/* 188 */     if (StringUtils.isNotEmpty(this.minExclusiveExpression)) {
/* 189 */       return (Double)parse(this.minExclusiveExpression, Double.class);
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */   
/*     */   public void setMaxExclusive(Double maxExclusive) {
/* 195 */     this.maxExclusive = maxExclusive;
/*     */   }
/*     */   
/*     */   public Double getMaxExclusive() {
/* 199 */     if (this.maxExclusive != null)
/* 200 */       return this.maxExclusive; 
/* 201 */     if (StringUtils.isNotEmpty(this.maxExclusiveExpression)) {
/* 202 */       return (Double)parse(this.maxExclusiveExpression, Double.class);
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */   public void setMinInclusiveExpression(String minInclusiveExpression) {
/* 208 */     this.minInclusiveExpression = minInclusiveExpression;
/*     */   }
/*     */   
/*     */   public void setMaxInclusiveExpression(String maxInclusiveExpression) {
/* 212 */     this.maxInclusiveExpression = maxInclusiveExpression;
/*     */   }
/*     */   
/*     */   public void setMinExclusiveExpression(String minExclusiveExpression) {
/* 216 */     this.minExclusiveExpression = minExclusiveExpression;
/*     */   }
/*     */   
/*     */   public void setMaxExclusiveExpression(String maxExclusiveExpression) {
/* 220 */     this.maxExclusiveExpression = maxExclusiveExpression;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\DoubleRangeFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */