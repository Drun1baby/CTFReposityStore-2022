/*     */ package com.opensymphony.xwork2.util.logging.commons;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class CommonsLogger
/*     */   implements Logger
/*     */ {
/*     */   private Log log;
/*     */   
/*     */   public CommonsLogger(Log log) {
/*  36 */     this.log = log;
/*     */   }
/*     */   
/*     */   public void error(String msg, String... args) {
/*  40 */     this.log.error(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void error(String msg, Object... args) {
/*  44 */     this.log.error(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void error(String msg, Throwable ex, String... args) {
/*  48 */     this.log.error(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public void info(String msg, String... args) {
/*  52 */     this.log.info(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void info(String msg, Throwable ex, String... args) {
/*  56 */     this.log.info(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/*  62 */     return this.log.isInfoEnabled();
/*     */   }
/*     */   
/*     */   public void warn(String msg, String... args) {
/*  66 */     this.log.warn(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void warn(String msg, Object... args) {
/*  70 */     this.log.warn(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void warn(String msg, Throwable ex, String... args) {
/*  74 */     this.log.warn(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  78 */     return this.log.isDebugEnabled();
/*     */   }
/*     */   
/*     */   public void debug(String msg, String... args) {
/*  82 */     this.log.debug(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void debug(String msg, Object... args) {
/*  86 */     this.log.debug(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void debug(String msg, Throwable ex, String... args) {
/*  90 */     this.log.debug(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  94 */     return this.log.isTraceEnabled();
/*     */   }
/*     */   
/*     */   public void trace(String msg, String... args) {
/*  98 */     this.log.trace(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void trace(String msg, Object... args) {
/* 102 */     this.log.trace(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void trace(String msg, Throwable ex, String... args) {
/* 106 */     this.log.trace(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fatal(String msg, String... args) {
/* 111 */     this.log.fatal(LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void fatal(String msg, Throwable ex, String... args) {
/* 115 */     this.log.fatal(LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 119 */     return this.log.isErrorEnabled();
/*     */   }
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 123 */     return this.log.isFatalEnabled();
/*     */   }
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 127 */     return this.log.isWarnEnabled();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\commons\CommonsLogger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */