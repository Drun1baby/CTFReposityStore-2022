/*     */ package com.opensymphony.xwork2.util.fs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StrutsJarURLConnection
/*     */   extends URLConnection
/*     */   implements AutoCloseable
/*     */ {
/*     */   private static final String FILE_URL_PREFIX = "file:";
/*     */   private JarURLConnection jarURLConnection;
/*     */   private JarFile jarFile;
/*     */   private String entryName;
/*     */   private URL jarFileURL;
/*     */   
/*     */   private StrutsJarURLConnection(URL url) throws IOException {
/*  57 */     super(url);
/*     */     
/*  59 */     URLConnection conn = this.url.openConnection();
/*  60 */     if (conn instanceof JarURLConnection) {
/*  61 */       this.jarURLConnection = (JarURLConnection)conn;
/*     */     } else {
/*     */       try {
/*  64 */         conn.getInputStream().close();
/*  65 */       } catch (IOException iOException) {}
/*     */       
/*  67 */       parseSpecs(url);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseSpecs(URL url) throws MalformedURLException, UnsupportedEncodingException {
/*  75 */     String spec = url.getFile();
/*     */     
/*  77 */     int separator = spec.indexOf("!/");
/*     */ 
/*     */ 
/*     */     
/*  81 */     if (separator == -1) {
/*  82 */       throw new MalformedURLException("no !/ found in url spec:" + spec);
/*     */     }
/*     */ 
/*     */     
/*  86 */     String jarFileSpec = spec.substring(0, separator++);
/*     */     try {
/*  88 */       this.jarFileURL = new URL(jarFileSpec);
/*  89 */     } catch (MalformedURLException e) {
/*     */ 
/*     */       
/*  92 */       if (!jarFileSpec.startsWith("/")) {
/*  93 */         jarFileSpec = "/" + jarFileSpec;
/*     */       }
/*  95 */       this.jarFileURL = new URL("file:" + jarFileSpec);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     this.entryName = null;
/*     */ 
/*     */     
/* 102 */     if (++separator != spec.length()) {
/* 103 */       this.entryName = spec.substring(separator, spec.length());
/* 104 */       this.entryName = URLDecoder.decode(this.entryName, "UTF-8");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 110 */     if (this.connected) {
/*     */       return;
/*     */     }
/*     */     
/* 114 */     if (this.jarURLConnection != null) {
/* 115 */       this.connected = true;
/*     */       
/*     */       return;
/*     */     } 
/* 119 */     try (InputStream in = this.jarFileURL.openConnection().getInputStream()) {
/* 120 */       this.jarFile = AccessController.<JarFile>doPrivileged(new PrivilegedExceptionAction<JarFile>()
/*     */           {
/*     */             public JarFile run() throws IOException {
/* 123 */               Path tmpFile = Files.createTempFile("jar_cache", null, (FileAttribute<?>[])new FileAttribute[0]);
/*     */               try {
/* 125 */                 Files.copy(in, tmpFile, new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/* 126 */                 JarFile jarFile = new JarFile(tmpFile.toFile(), true, 5);
/*     */                 
/* 128 */                 return jarFile;
/* 129 */               } catch (Throwable thr) {
/*     */                 try {
/* 131 */                   Files.delete(tmpFile);
/* 132 */                 } catch (IOException ioe) {
/* 133 */                   thr.addSuppressed(ioe);
/*     */                 } 
/* 135 */                 throw thr;
/*     */               } finally {
/* 137 */                 in.close();
/*     */               } 
/*     */             }
/*     */           });
/* 141 */       this.connected = true;
/* 142 */     } catch (PrivilegedActionException pae) {
/* 143 */       throw (IOException)pae.getException();
/*     */     } 
/*     */   }
/*     */   
/*     */   JarEntry getJarEntry() throws IOException {
/* 148 */     if (this.jarURLConnection != null) {
/* 149 */       return this.jarURLConnection.getJarEntry();
/*     */     }
/* 151 */     connect();
/* 152 */     return this.jarFile.getJarEntry(this.entryName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseCaches(boolean usecaches) {
/* 158 */     super.setUseCaches(usecaches);
/*     */     
/* 160 */     if (this.jarURLConnection != null) {
/* 161 */       this.jarURLConnection.setUseCaches(usecaches);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 167 */     if (this.jarURLConnection != null) {
/* 168 */       return this.jarURLConnection.getInputStream();
/*     */     }
/* 170 */     return this.jarFile.getInputStream(this.jarFile.getJarEntry(this.entryName));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws Exception {
/*     */     try {
/* 177 */       getInputStream().close();
/* 178 */     } catch (IOException iOException) {}
/*     */     
/* 180 */     if (this.jarURLConnection == null) {
/*     */       try {
/* 182 */         this.jarFile.close();
/* 183 */       } catch (IOException iOException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static StrutsJarURLConnection openConnection(URL url) throws IOException {
/* 189 */     return new StrutsJarURLConnection(url);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\StrutsJarURLConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */