/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberConverter
/*     */   extends DefaultTypeConverter
/*     */ {
/*  36 */   private static final Logger LOG = LogManager.getLogger(NumberConverter.class);
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class<BigDecimal> toType) {
/*  39 */     if (value instanceof String) {
/*  40 */       String stringValue = String.valueOf(value);
/*     */       
/*  42 */       if (toType == BigDecimal.class)
/*  43 */         return convertToBigDecimal(context, stringValue); 
/*  44 */       if (toType == BigInteger.class)
/*  45 */         return new BigInteger(stringValue); 
/*  46 */       if (toType == Double.class || toType == double.class)
/*  47 */         return convertToDouble(context, stringValue); 
/*  48 */       if (toType == Float.class || toType == float.class)
/*  49 */         return convertToFloat(context, stringValue); 
/*  50 */       if (toType.isPrimitive()) {
/*  51 */         Object convertedValue = convertValue(context, value, toType);
/*     */         
/*  53 */         if (!isInRange((Number)convertedValue, stringValue, toType)) {
/*  54 */           throw new XWorkException("Overflow or underflow casting: \"" + stringValue + "\" into class " + convertedValue.getClass().getName());
/*     */         }
/*  56 */         return convertedValue;
/*     */       } 
/*  58 */       if (!toType.isPrimitive() && stringValue.isEmpty()) {
/*  59 */         return null;
/*     */       }
/*  61 */       NumberFormat numFormat = NumberFormat.getInstance(getLocale(context));
/*  62 */       ParsePosition parsePos = new ParsePosition(0);
/*  63 */       if (isIntegerType(toType)) {
/*  64 */         numFormat.setParseIntegerOnly(true);
/*     */       }
/*  66 */       numFormat.setGroupingUsed(true);
/*  67 */       Number number = numFormat.parse(stringValue, parsePos);
/*     */       
/*  69 */       if (parsePos.getIndex() != stringValue.length()) {
/*  70 */         throw new XWorkException("Unparseable number: \"" + stringValue + "\" at position " + parsePos.getIndex());
/*     */       }
/*     */       
/*  73 */       if (!isInRange(number, stringValue, toType)) {
/*  74 */         throw new XWorkException("Overflow or underflow casting: \"" + stringValue + "\" into class " + number.getClass().getName());
/*     */       }
/*  76 */       value = convertValue(context, number, toType);
/*     */     
/*     */     }
/*  79 */     else if (value instanceof Object[]) {
/*  80 */       Object[] objArray = (Object[])value;
/*     */       
/*  82 */       if (objArray.length == 1) {
/*  83 */         return convertValue(context, (Object)null, (Member)null, (String)null, objArray[0], toType);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  88 */     return convertValue(context, value, toType);
/*     */   }
/*     */   
/*     */   protected Object convertToBigDecimal(Map<String, Object> context, String stringValue) {
/*  92 */     Locale locale = getLocale(context);
/*     */     
/*  94 */     NumberFormat format = getNumberFormat(locale);
/*  95 */     if (format instanceof DecimalFormat) {
/*  96 */       ((DecimalFormat)format).setParseBigDecimal(true);
/*  97 */       char separator = ((DecimalFormat)format).getDecimalFormatSymbols().getGroupingSeparator();
/*  98 */       stringValue = normalize(stringValue, separator);
/*     */     } 
/*     */     
/* 101 */     LOG.debug("Trying to convert a value {} with locale {} to BigDecimal", stringValue, locale);
/* 102 */     ParsePosition parsePosition = new ParsePosition(0);
/* 103 */     Number number = format.parse(stringValue, parsePosition);
/*     */     
/* 105 */     if (parsePosition.getIndex() != stringValue.length()) {
/* 106 */       throw new XWorkException("Unparseable number: \"" + stringValue + "\" at position " + parsePosition.getIndex());
/*     */     }
/*     */     
/* 109 */     return number;
/*     */   }
/*     */   
/*     */   protected Object convertToDouble(Map<String, Object> context, String stringValue) {
/* 113 */     Locale locale = getLocale(context);
/*     */     
/* 115 */     NumberFormat format = getNumberFormat(locale);
/* 116 */     if (format instanceof DecimalFormat) {
/* 117 */       char separator = ((DecimalFormat)format).getDecimalFormatSymbols().getGroupingSeparator();
/* 118 */       stringValue = normalize(stringValue, separator);
/*     */     } 
/*     */     
/* 121 */     LOG.debug("Trying to convert a value {} with locale {} to Double", stringValue, locale);
/* 122 */     ParsePosition parsePosition = new ParsePosition(0);
/* 123 */     Number number = format.parse(stringValue, parsePosition);
/*     */     
/* 125 */     if (parsePosition.getIndex() != stringValue.length()) {
/* 126 */       throw new XWorkException("Unparseable number: \"" + stringValue + "\" at position " + parsePosition.getIndex());
/*     */     }
/*     */     
/* 129 */     if (!isInRange(number, stringValue, Double.class)) {
/* 130 */       throw new XWorkException("Overflow or underflow converting: \"" + stringValue + "\" into class " + number.getClass().getName());
/*     */     }
/*     */     
/* 133 */     if (number != null) {
/* 134 */       return Double.valueOf(number.doubleValue());
/*     */     }
/*     */     
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   protected Object convertToFloat(Map<String, Object> context, String stringValue) {
/* 141 */     Locale locale = getLocale(context);
/*     */     
/* 143 */     NumberFormat format = getNumberFormat(locale);
/* 144 */     if (format instanceof DecimalFormat) {
/* 145 */       char separator = ((DecimalFormat)format).getDecimalFormatSymbols().getGroupingSeparator();
/* 146 */       stringValue = normalize(stringValue, separator);
/*     */     } 
/*     */     
/* 149 */     LOG.debug("Trying to convert a value {} with locale {} to Float", stringValue, locale);
/* 150 */     ParsePosition parsePosition = new ParsePosition(0);
/* 151 */     Number number = format.parse(stringValue, parsePosition);
/*     */     
/* 153 */     if (parsePosition.getIndex() != stringValue.length()) {
/* 154 */       throw new XWorkException("Unparseable number: \"" + stringValue + "\" at position " + parsePosition.getIndex());
/*     */     }
/*     */     
/* 157 */     if (!isInRange(number, stringValue, Float.class)) {
/* 158 */       throw new XWorkException("Overflow or underflow converting: \"" + stringValue + "\" into class " + number.getClass().getName());
/*     */     }
/*     */     
/* 161 */     if (number != null) {
/* 162 */       return Float.valueOf(number.floatValue());
/*     */     }
/*     */     
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   protected NumberFormat getNumberFormat(Locale locale) {
/* 169 */     NumberFormat format = NumberFormat.getNumberInstance(locale);
/* 170 */     format.setGroupingUsed(true);
/* 171 */     return format;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String normalize(String strValue, char separator) {
/* 176 */     if (separator == ' ') {
/* 177 */       strValue = strValue.replaceAll(" ", String.valueOf(separator));
/*     */     }
/* 179 */     return strValue;
/*     */   }
/*     */   
/*     */   protected boolean isInRange(Number value, String stringValue, Class<double> toType) {
/* 183 */     Number bigValue = null;
/* 184 */     Number lowerBound = null;
/* 185 */     Number upperBound = null;
/*     */     
/*     */     try {
/* 188 */       if (double.class == toType || Double.class == toType) {
/* 189 */         bigValue = new BigDecimal(stringValue);
/*     */         
/* 191 */         lowerBound = BigDecimal.valueOf(Double.MAX_VALUE).negate();
/* 192 */         upperBound = BigDecimal.valueOf(Double.MAX_VALUE);
/* 193 */       } else if (float.class == toType || Float.class == toType) {
/* 194 */         bigValue = new BigDecimal(stringValue);
/*     */         
/* 196 */         lowerBound = BigDecimal.valueOf(3.4028234663852886E38D).negate();
/* 197 */         upperBound = BigDecimal.valueOf(3.4028234663852886E38D);
/* 198 */       } else if (byte.class == toType || Byte.class == toType) {
/* 199 */         bigValue = new BigInteger(stringValue);
/* 200 */         lowerBound = BigInteger.valueOf(-128L);
/* 201 */         upperBound = BigInteger.valueOf(127L);
/* 202 */       } else if (char.class == toType || Character.class == toType) {
/* 203 */         bigValue = new BigInteger(stringValue);
/* 204 */         lowerBound = BigInteger.valueOf(0L);
/* 205 */         upperBound = BigInteger.valueOf(65535L);
/* 206 */       } else if (short.class == toType || Short.class == toType) {
/* 207 */         bigValue = new BigInteger(stringValue);
/* 208 */         lowerBound = BigInteger.valueOf(-32768L);
/* 209 */         upperBound = BigInteger.valueOf(32767L);
/* 210 */       } else if (int.class == toType || Integer.class == toType) {
/* 211 */         bigValue = new BigInteger(stringValue);
/* 212 */         lowerBound = BigInteger.valueOf(-2147483648L);
/* 213 */         upperBound = BigInteger.valueOf(2147483647L);
/* 214 */       } else if (long.class == toType || Long.class == toType) {
/* 215 */         bigValue = new BigInteger(stringValue);
/* 216 */         lowerBound = BigInteger.valueOf(Long.MIN_VALUE);
/* 217 */         upperBound = BigInteger.valueOf(Long.MAX_VALUE);
/*     */       } else {
/* 219 */         throw new IllegalArgumentException("Unexpected numeric type: " + toType.getName());
/*     */       } 
/* 221 */     } catch (NumberFormatException e) {
/*     */       
/* 223 */       return true;
/*     */     } 
/*     */     
/* 226 */     return (((Comparable<Number>)bigValue).compareTo(lowerBound) >= 0 && ((Comparable<Number>)bigValue).compareTo(upperBound) <= 0);
/*     */   }
/*     */   
/*     */   private boolean isIntegerType(Class<double> type) {
/* 230 */     if (double.class == type || float.class == type || Double.class == type || Float.class == type || char.class == type || Character.class == type)
/*     */     {
/* 232 */       return false;
/*     */     }
/*     */     
/* 235 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\NumberConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */