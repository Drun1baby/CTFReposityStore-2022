/*    */ package com.opensymphony.xwork2.config.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Context;
/*    */ import com.opensymphony.xwork2.inject.Factory;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import com.opensymphony.xwork2.util.location.Located;
/*    */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*    */ import java.util.LinkedHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocatableFactory<T>
/*    */   extends Located
/*    */   implements Factory<T>
/*    */ {
/*    */   private Class implementation;
/*    */   private Class type;
/*    */   private String name;
/*    */   private Scope scope;
/*    */   
/*    */   public LocatableFactory(String name, Class type, Class implementation, Scope scope, Object location) {
/* 41 */     this.implementation = implementation;
/* 42 */     this.type = type;
/* 43 */     this.name = name;
/* 44 */     this.scope = scope;
/* 45 */     setLocation(LocationUtils.getLocation(location));
/*    */   }
/*    */ 
/*    */   
/*    */   public T create(Context context) {
/* 50 */     Object obj = context.getContainer().inject(this.implementation);
/* 51 */     return (T)obj;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends T> type() {
/* 56 */     return this.implementation;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     String fields = (new LinkedHashMap<String, Object>() {  }).toString();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     StringBuilder sb = new StringBuilder(fields);
/* 70 */     sb.append(super.toString());
/* 71 */     sb.append(" defined at ");
/* 72 */     sb.append(getLocation().toString());
/* 73 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\LocatableFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */