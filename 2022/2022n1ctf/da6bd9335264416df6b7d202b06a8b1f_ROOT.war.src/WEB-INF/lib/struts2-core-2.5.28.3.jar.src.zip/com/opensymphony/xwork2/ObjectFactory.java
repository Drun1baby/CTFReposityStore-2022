/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.factory.ActionFactory;
/*     */ import com.opensymphony.xwork2.factory.ConverterFactory;
/*     */ import com.opensymphony.xwork2.factory.InterceptorFactory;
/*     */ import com.opensymphony.xwork2.factory.ResultFactory;
/*     */ import com.opensymphony.xwork2.factory.UnknownHandlerFactory;
/*     */ import com.opensymphony.xwork2.factory.ValidatorFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.validator.Validator;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectFactory
/*     */   implements Serializable
/*     */ {
/*  51 */   private static final Logger LOG = LogManager.getLogger(ObjectFactory.class);
/*     */   
/*     */   private transient ClassLoader ccl;
/*     */   
/*     */   private Container container;
/*     */   
/*     */   private ActionFactory actionFactory;
/*     */   
/*     */   private ResultFactory resultFactory;
/*     */   
/*     */   private InterceptorFactory interceptorFactory;
/*     */   private ValidatorFactory validatorFactory;
/*     */   private ConverterFactory converterFactory;
/*     */   private UnknownHandlerFactory unknownHandlerFactory;
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  68 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject(value = "objectFactory.classloader", required = false)
/*     */   public void setClassLoader(ClassLoader cl) {
/*  73 */     this.ccl = cl;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setActionFactory(ActionFactory actionFactory) {
/*  78 */     this.actionFactory = actionFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setResultFactory(ResultFactory resultFactory) {
/*  83 */     this.resultFactory = resultFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setInterceptorFactory(InterceptorFactory interceptorFactory) {
/*  88 */     this.interceptorFactory = interceptorFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setValidatorFactory(ValidatorFactory validatorFactory) {
/*  93 */     this.validatorFactory = validatorFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setConverterFactory(ConverterFactory converterFactory) {
/*  98 */     this.converterFactory = converterFactory;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setUnknownHandlerFactory(UnknownHandlerFactory unknownHandlerFactory) {
/* 103 */     this.unknownHandlerFactory = unknownHandlerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNoArgConstructorRequired() {
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getClassInstance(String className) throws ClassNotFoundException {
/* 125 */     if (this.ccl != null) {
/* 126 */       return this.ccl.loadClass(className);
/*     */     }
/*     */     
/* 129 */     return ClassLoaderUtil.loadClass(className, getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildAction(String actionName, String namespace, ActionConfig config, Map<String, Object> extraContext) throws Exception {
/* 142 */     return this.actionFactory.buildAction(actionName, namespace, config, extraContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildBean(Class clazz, Map<String, Object> extraContext) throws Exception {
/* 154 */     return clazz.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object injectInternalBeans(Object obj) {
/* 162 */     if (obj != null && this.container != null) {
/* 163 */       this.container.inject(obj);
/*     */     }
/* 165 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildBean(String className, Map<String, Object> extraContext) throws Exception {
/* 177 */     return buildBean(className, extraContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildBean(String className, Map<String, Object> extraContext, boolean injectInternal) throws Exception {
/* 190 */     Class clazz = getClassInstance(className);
/* 191 */     Object obj = buildBean(clazz, extraContext);
/* 192 */     if (injectInternal) {
/* 193 */       injectInternalBeans(obj);
/*     */     }
/* 195 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interceptor buildInterceptor(InterceptorConfig interceptorConfig, Map<String, String> interceptorRefParams) throws ConfigurationException {
/* 212 */     return this.interceptorFactory.buildInterceptor(interceptorConfig, interceptorRefParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result buildResult(ResultConfig resultConfig, Map<String, Object> extraContext) throws Exception {
/* 225 */     return this.resultFactory.buildResult(resultConfig, extraContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Validator buildValidator(String className, Map<String, Object> params, Map<String, Object> extraContext) throws Exception {
/* 239 */     return this.validatorFactory.buildValidator(className, params, extraContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConverter buildConverter(Class<? extends TypeConverter> converterClass, Map<String, Object> extraContext) throws Exception {
/* 251 */     return this.converterFactory.buildConverter(converterClass, extraContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnknownHandler buildUnknownHandler(String unknownHandlerName, Map<String, Object> extraContext) throws Exception {
/* 263 */     return this.unknownHandlerFactory.buildUnknownHandler(unknownHandlerName, extraContext);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ObjectFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */