/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.UnknownHandlerConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultUnknownHandlerManager
/*     */   implements UnknownHandlerManager
/*     */ {
/*     */   private Container container;
/*     */   protected ArrayList<UnknownHandler> unknownHandlers;
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  46 */     this.container = container;
/*     */     try {
/*  48 */       build();
/*  49 */     } catch (Exception e) {
/*  50 */       throw new ConfigurationException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void build() throws Exception {
/*  61 */     Configuration configuration = (Configuration)this.container.getInstance(Configuration.class);
/*  62 */     ObjectFactory factory = (ObjectFactory)this.container.getInstance(ObjectFactory.class);
/*     */     
/*  64 */     if (configuration != null && this.container != null) {
/*  65 */       List<UnknownHandlerConfig> unkownHandlerStack = configuration.getUnknownHandlerStack();
/*  66 */       this.unknownHandlers = new ArrayList<>();
/*     */       
/*  68 */       if (unkownHandlerStack != null && !unkownHandlerStack.isEmpty()) {
/*     */         
/*  70 */         for (UnknownHandlerConfig unknownHandlerConfig : unkownHandlerStack) {
/*  71 */           UnknownHandler uh = factory.buildUnknownHandler(unknownHandlerConfig.getName(), new HashMap<>());
/*  72 */           this.unknownHandlers.add(uh);
/*     */         } 
/*     */       } else {
/*     */         
/*  76 */         Set<String> unknownHandlerNames = this.container.getInstanceNames(UnknownHandler.class);
/*  77 */         for (String unknownHandlerName : unknownHandlerNames) {
/*  78 */           UnknownHandler uh = (UnknownHandler)this.container.getInstance(UnknownHandler.class, unknownHandlerName);
/*  79 */           this.unknownHandlers.add(uh);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result handleUnknownResult(ActionContext actionContext, String actionName, ActionConfig actionConfig, String resultCode) {
/*  94 */     for (UnknownHandler unknownHandler : this.unknownHandlers) {
/*  95 */       Result result = unknownHandler.handleUnknownResult(actionContext, actionName, actionConfig, resultCode);
/*  96 */       if (result != null) {
/*  97 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleUnknownMethod(Object action, String methodName) throws NoSuchMethodException {
/* 113 */     for (UnknownHandler unknownHandler : this.unknownHandlers) {
/* 114 */       Object result = unknownHandler.handleUnknownActionMethod(action, methodName);
/* 115 */       if (result != null) {
/* 116 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 120 */     if (this.unknownHandlers.isEmpty()) {
/* 121 */       throw new NoSuchMethodException(String.format("No UnknownHandlers defined to handle method [%s]", new Object[] { methodName }));
/*     */     }
/* 123 */     throw new NoSuchMethodException(String.format("None of defined UnknownHandlers can handle method [%s]", new Object[] { methodName }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionConfig handleUnknownAction(String namespace, String actionName) {
/* 134 */     for (UnknownHandler unknownHandler : this.unknownHandlers) {
/* 135 */       ActionConfig result = unknownHandler.handleUnknownAction(namespace, actionName);
/* 136 */       if (result != null) {
/* 137 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasUnknownHandlers() {
/* 145 */     return (this.unknownHandlers != null && !this.unknownHandlers.isEmpty());
/*     */   }
/*     */   
/*     */   public List<UnknownHandler> getUnknownHandlers() {
/* 149 */     return this.unknownHandlers;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultUnknownHandlerManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */