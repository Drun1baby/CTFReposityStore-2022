/*    */ package com.opensymphony.xwork2.util.fs;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileRevision
/*    */   extends Revision
/*    */ {
/*    */   private File file;
/*    */   private long lastModified;
/*    */   
/*    */   public static Revision build(URL fileUrl) {
/*    */     File file;
/*    */     try {
/* 36 */       if (fileUrl != null) {
/* 37 */         file = new File(fileUrl.toURI());
/*    */       } else {
/* 39 */         return null;
/*    */       } 
/* 41 */     } catch (URISyntaxException e) {
/* 42 */       file = new File(fileUrl.getPath());
/* 43 */     } catch (Throwable t) {
/* 44 */       return null;
/*    */     } 
/* 46 */     if (file.exists() && file.canRead()) {
/* 47 */       long lastModified = file.lastModified();
/* 48 */       return new FileRevision(file, lastModified);
/*    */     } 
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   private FileRevision(File file, long lastUpdated) {
/* 54 */     if (file == null) {
/* 55 */       throw new IllegalArgumentException("File cannot be null");
/*    */     }
/*    */     
/* 58 */     this.file = file;
/* 59 */     this.lastModified = lastUpdated;
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 63 */     return this.file;
/*    */   }
/*    */   
/*    */   public boolean needsReloading() {
/* 67 */     return (this.lastModified < this.file.lastModified());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\FileRevision.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */