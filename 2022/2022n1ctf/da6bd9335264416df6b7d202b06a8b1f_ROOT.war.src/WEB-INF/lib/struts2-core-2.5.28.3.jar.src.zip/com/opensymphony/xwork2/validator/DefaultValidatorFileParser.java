/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.providers.XmlHelper;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.DomHelper;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultValidatorFileParser
/*     */   implements ValidatorFileParser
/*     */ {
/*  50 */   private static Logger LOG = LogManager.getLogger(DefaultValidatorFileParser.class);
/*     */   
/*     */   static final String DEFAULT_MULTI_TEXTVALUE_SEPARATOR = " ";
/*     */   
/*     */   static final String MULTI_TEXTVALUE_SEPARATOR_CONFIG_KEY = "xwork.validatorfileparser.multi_textvalue_separator";
/*     */   private ObjectFactory objectFactory;
/*  56 */   private String multiTextvalueSeparator = " ";
/*     */   
/*     */   @Inject(value = "xwork.validatorfileparser.multi_textvalue_separator", required = false)
/*     */   public void setMultiTextvalueSeparator(String type) {
/*  60 */     this.multiTextvalueSeparator = type;
/*     */   }
/*     */   
/*     */   public String getMultiTextvalueSeparator() {
/*  64 */     return this.multiTextvalueSeparator;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  69 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   public List<ValidatorConfig> parseActionValidatorConfigs(ValidatorFactory validatorFactory, InputStream is, String resourceName) {
/*  73 */     List<ValidatorConfig> validatorCfgs = new ArrayList<>();
/*     */     
/*  75 */     InputSource in = new InputSource(is);
/*  76 */     in.setSystemId(resourceName);
/*     */     
/*  78 */     Map<String, String> dtdMappings = new HashMap<>();
/*  79 */     dtdMappings.put("-//Apache Struts//XWork Validator 1.0//EN", "xwork-validator-1.0.dtd");
/*  80 */     dtdMappings.put("-//Apache Struts//XWork Validator 1.0.2//EN", "xwork-validator-1.0.2.dtd");
/*  81 */     dtdMappings.put("-//Apache Struts//XWork Validator 1.0.3//EN", "xwork-validator-1.0.3.dtd");
/*  82 */     dtdMappings.put("-//Apache Struts//XWork Validator Config 1.0//EN", "xwork-validator-config-1.0.dtd");
/*     */     
/*  84 */     Document doc = DomHelper.parse(in, dtdMappings);
/*     */     
/*  86 */     if (doc != null) {
/*  87 */       NodeList fieldNodes = doc.getElementsByTagName("field");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       NodeList validatorNodes = doc.getElementsByTagName("validator");
/*  94 */       addValidatorConfigs(validatorFactory, validatorNodes, new HashMap<>(), validatorCfgs);
/*     */ 
/*     */       
/*  97 */       for (int i = 0; i < fieldNodes.getLength(); i++) {
/*  98 */         Element fieldElement = (Element)fieldNodes.item(i);
/*  99 */         String fieldName = fieldElement.getAttribute("name");
/* 100 */         Map<String, Object> extraParams = new HashMap<>();
/* 101 */         extraParams.put("fieldName", fieldName);
/*     */         
/* 103 */         NodeList nodeList = fieldElement.getElementsByTagName("field-validator");
/* 104 */         addValidatorConfigs(validatorFactory, nodeList, extraParams, validatorCfgs);
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     return validatorCfgs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseValidatorDefinitions(Map<String, String> validators, InputStream is, String resourceName) {
/* 114 */     InputSource in = new InputSource(is);
/* 115 */     in.setSystemId(resourceName);
/*     */     
/* 117 */     Map<String, String> dtdMappings = new HashMap<>();
/* 118 */     dtdMappings.put("-//Apache Struts//XWork Validator Config 1.0//EN", "xwork-validator-config-1.0.dtd");
/* 119 */     dtdMappings.put("-//Apache Struts//XWork Validator Definition 1.0//EN", "xwork-validator-definition-1.0.dtd");
/*     */     
/* 121 */     Document doc = DomHelper.parse(in, dtdMappings);
/*     */     
/* 123 */     if (doc != null) {
/* 124 */       NodeList nodes = doc.getElementsByTagName("validator");
/*     */       
/* 126 */       for (int i = 0; i < nodes.getLength(); i++) {
/* 127 */         Element validatorElement = (Element)nodes.item(i);
/* 128 */         String name = validatorElement.getAttribute("name");
/* 129 */         String className = validatorElement.getAttribute("class");
/*     */ 
/*     */         
/*     */         try {
/* 133 */           this.objectFactory.buildValidator(className, new HashMap<>(), ActionContext.getContext().getContextMap());
/* 134 */           validators.put(name, className);
/* 135 */         } catch (Exception e) {
/* 136 */           throw new ConfigurationException("Unable to load validator class " + className, e, validatorElement);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTextValue(Element valueEle) {
/* 155 */     StringBuilder value = new StringBuilder();
/* 156 */     NodeList nl = valueEle.getChildNodes();
/* 157 */     boolean firstCDataFound = false;
/* 158 */     for (int i = 0; i < nl.getLength(); i++) {
/* 159 */       Node item = nl.item(i);
/* 160 */       if ((item instanceof org.w3c.dom.CharacterData && !(item instanceof org.w3c.dom.Comment)) || item instanceof org.w3c.dom.EntityReference) {
/* 161 */         String nodeValue = item.getNodeValue();
/* 162 */         if (nodeValue != null) {
/* 163 */           if (firstCDataFound) {
/* 164 */             value.append(getMultiTextvalueSeparator());
/*     */           } else {
/* 166 */             firstCDataFound = true;
/*     */           } 
/* 168 */           value.append(nodeValue.trim());
/*     */         } 
/*     */       } 
/*     */     } 
/* 172 */     return value.toString().trim();
/*     */   }
/*     */   
/*     */   private void addValidatorConfigs(ValidatorFactory factory, NodeList validatorNodes, Map<String, Object> extraParams, List<ValidatorConfig> validatorCfgs) {
/* 176 */     for (int j = 0; j < validatorNodes.getLength(); j++) {
/* 177 */       Element validatorElement = (Element)validatorNodes.item(j);
/* 178 */       String validatorType = validatorElement.getAttribute("type");
/* 179 */       Map<String, Object> params = new HashMap<>(extraParams);
/*     */       
/* 181 */       params.putAll(XmlHelper.getParams(validatorElement));
/*     */ 
/*     */       
/*     */       try {
/* 185 */         factory.lookupRegisteredValidatorType(validatorType);
/* 186 */       } catch (IllegalArgumentException ex) {
/* 187 */         throw new ConfigurationException("Invalid validation type: " + validatorType, validatorElement);
/*     */       } 
/*     */       
/* 190 */       ValidatorConfig.Builder vCfg = (new ValidatorConfig.Builder(validatorType)).addParams(params).location(DomHelper.getLocationObject(validatorElement)).shortCircuit(Boolean.valueOf(validatorElement.getAttribute("short-circuit")).booleanValue());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       NodeList messageNodes = validatorElement.getElementsByTagName("message");
/* 196 */       Element messageElement = (Element)messageNodes.item(0);
/*     */       
/* 198 */       Node defaultMessageNode = messageElement.getFirstChild();
/* 199 */       String defaultMessage = (defaultMessageNode == null) ? "" : defaultMessageNode.getNodeValue();
/* 200 */       vCfg.defaultMessage(defaultMessage);
/*     */       
/* 202 */       Map<String, String> messageParams = XmlHelper.getParams(messageElement);
/* 203 */       String key = messageElement.getAttribute("key");
/*     */ 
/*     */       
/* 206 */       if (key != null && key.trim().length() > 0) {
/* 207 */         vCfg.messageKey(key);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 220 */         if (messageParams.containsKey("defaultMessage")) {
/* 221 */           vCfg.defaultMessage(messageParams.get("defaultMessage"));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 226 */         TreeMap<Integer, String> sortedMessageParameters = new TreeMap<>();
/* 227 */         for (Map.Entry<String, String> messageParamEntry : messageParams.entrySet()) {
/*     */           
/*     */           try {
/* 230 */             int _order = Integer.parseInt(messageParamEntry.getKey());
/* 231 */             sortedMessageParameters.put(Integer.valueOf(_order), messageParamEntry.getValue());
/*     */           }
/* 233 */           catch (NumberFormatException numberFormatException) {}
/*     */         } 
/*     */ 
/*     */         
/* 237 */         vCfg.messageParams((String[])sortedMessageParameters.values().toArray((Object[])new String[sortedMessageParameters.values().size()]));
/*     */       }
/* 239 */       else if (messageParams != null && messageParams.size() > 0) {
/*     */ 
/*     */         
/* 242 */         if (LOG.isWarnEnabled()) {
/* 243 */           LOG.warn("validator of type [" + validatorType + "] have i18n message parameters defined but no i18n message key, it's parameters will be ignored");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 248 */       validatorCfgs.add(vCfg.build());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\DefaultValidatorFileParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */