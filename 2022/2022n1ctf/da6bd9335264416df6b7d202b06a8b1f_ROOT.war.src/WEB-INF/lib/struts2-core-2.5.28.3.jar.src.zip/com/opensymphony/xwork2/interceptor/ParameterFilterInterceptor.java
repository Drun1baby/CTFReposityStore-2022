/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterFilterInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/* 104 */   private static final Logger LOG = LogManager.getLogger(ParameterFilterInterceptor.class);
/*     */   
/*     */   private Collection<String> allowed;
/*     */   
/*     */   private Collection<String> blocked;
/*     */   
/*     */   private Map<String, Boolean> includesExcludesMap;
/*     */   private boolean defaultBlock = false;
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 114 */     HttpParameters parameters = invocation.getInvocationContext().getParameters();
/*     */     
/* 116 */     Map<String, Boolean> includesExcludesMap = getIncludesExcludesMap();
/*     */     
/* 118 */     for (String param : parameters.keySet()) {
/* 119 */       boolean currentAllowed = !isDefaultBlock();
/*     */       
/* 121 */       for (Map.Entry<String, Boolean> entry : includesExcludesMap.entrySet()) {
/* 122 */         String currRule = entry.getKey();
/*     */         
/* 124 */         if (param.startsWith(currRule) && (param.length() == currRule.length() || isPropertySeparator(param.charAt(currRule.length()))))
/*     */         {
/*     */           
/* 127 */           currentAllowed = ((Boolean)entry.getValue()).booleanValue();
/*     */         }
/*     */       } 
/* 130 */       if (!currentAllowed) {
/* 131 */         LOG.debug("Removing param: {}", param);
/* 132 */         parameters = parameters.remove(param);
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     invocation.getInvocationContext().setParameters(parameters);
/*     */     
/* 138 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPropertySeparator(char c) {
/* 148 */     return (c == '.' || c == '(' || c == '[');
/*     */   }
/*     */   
/*     */   private Map<String, Boolean> getIncludesExcludesMap() {
/* 152 */     if (this.includesExcludesMap == null) {
/* 153 */       this.includesExcludesMap = new TreeMap<>();
/*     */       
/* 155 */       if (getAllowedCollection() != null) {
/* 156 */         for (String e : getAllowedCollection()) {
/* 157 */           this.includesExcludesMap.put(e, Boolean.TRUE);
/*     */         }
/*     */       }
/* 160 */       if (getBlockedCollection() != null) {
/* 161 */         for (String b : getBlockedCollection()) {
/* 162 */           this.includesExcludesMap.put(b, Boolean.FALSE);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 167 */     return this.includesExcludesMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultBlock() {
/* 174 */     return this.defaultBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultBlock(boolean defaultExclude) {
/* 181 */     this.defaultBlock = defaultExclude;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getBlockedCollection() {
/* 188 */     return this.blocked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockedCollection(Collection<String> blocked) {
/* 195 */     this.blocked = blocked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlocked(String blocked) {
/* 202 */     setBlockedCollection(asCollection(blocked));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getAllowedCollection() {
/* 209 */     return this.allowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowedCollection(Collection<String> allowed) {
/* 216 */     this.allowed = allowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowed(String allowed) {
/* 223 */     setAllowedCollection(asCollection(allowed));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<String> asCollection(String commaDelim) {
/* 233 */     if (StringUtils.isBlank(commaDelim)) {
/* 234 */       return null;
/*     */     }
/* 236 */     return TextParseUtil.commaDelimitedStringToSet(commaDelim);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ParameterFilterInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */