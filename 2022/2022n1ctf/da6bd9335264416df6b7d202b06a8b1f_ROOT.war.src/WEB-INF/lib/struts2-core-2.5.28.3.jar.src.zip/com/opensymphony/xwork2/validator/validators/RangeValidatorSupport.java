/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Collection;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RangeValidatorSupport<T extends Comparable>
/*     */   extends FieldValidatorSupport
/*     */ {
/*  33 */   private static final Logger LOG = LogManager.getLogger(RangeValidatorSupport.class);
/*     */   
/*     */   private final Class<T> type;
/*     */   
/*     */   private T min;
/*     */   private String minExpression;
/*     */   private T max;
/*     */   private String maxExpression;
/*     */   
/*     */   protected RangeValidatorSupport(Class<T> type) {
/*  43 */     this.type = type;
/*     */   }
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/*  47 */     Object obj = getFieldValue(getFieldName(), object);
/*     */ 
/*     */ 
/*     */     
/*  51 */     if (obj == null) {
/*     */       return;
/*     */     }
/*     */     
/*  55 */     T min = getMin();
/*  56 */     T max = getMax();
/*     */     
/*  58 */     if (obj.getClass().isArray()) {
/*  59 */       Object[] values = (Object[])obj;
/*  60 */       for (Object objValue : values) {
/*  61 */         validateValue(object, (Comparable<T>)objValue, min, max);
/*     */       }
/*  63 */     } else if (Collection.class.isAssignableFrom(obj.getClass())) {
/*  64 */       Collection<?> values = (Collection)obj;
/*  65 */       for (Object objValue : values) {
/*  66 */         validateValue(object, (Comparable<T>)objValue, min, max);
/*     */       }
/*     */     } else {
/*  69 */       validateValue(object, (Comparable<T>)obj, min, max);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateValue(Object object, Comparable<T> value, T min, T max) {
/*  74 */     setCurrentValue(value);
/*     */ 
/*     */     
/*  77 */     if (min != null && value.compareTo(min) < 0) {
/*  78 */       addFieldError(getFieldName(), object);
/*     */     }
/*     */ 
/*     */     
/*  82 */     if (max != null && value.compareTo(max) > 0) {
/*  83 */       addFieldError(getFieldName(), object);
/*     */     }
/*     */     
/*  86 */     setCurrentValue((Object)null);
/*     */   }
/*     */   
/*     */   public void setMin(T min) {
/*  90 */     this.min = min;
/*     */   }
/*     */   
/*     */   public T getMin() {
/*  94 */     return getT(this.min, this.minExpression, this.type);
/*     */   }
/*     */   
/*     */   public T getMax() {
/*  98 */     return getT(this.max, this.maxExpression, this.type);
/*     */   }
/*     */   
/*     */   public void setMinExpression(String minExpression) {
/* 102 */     LOG.debug("${minExpression} was defined as [{}]", minExpression);
/* 103 */     this.minExpression = minExpression;
/*     */   }
/*     */   
/*     */   public void setMax(T max) {
/* 107 */     this.max = max;
/*     */   }
/*     */   
/*     */   public void setMaxExpression(String maxExpression) {
/* 111 */     LOG.debug("${maxExpression} was defined as [{}]", maxExpression);
/* 112 */     this.maxExpression = maxExpression;
/*     */   }
/*     */   
/*     */   protected T getT(T minMax, String minMaxExpression, Class<T> toType) {
/* 116 */     if (minMax != null)
/* 117 */       return minMax; 
/* 118 */     if (StringUtils.isNotEmpty(minMaxExpression)) {
/* 119 */       return (T)parse(minMaxExpression, toType);
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\RangeValidatorSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */