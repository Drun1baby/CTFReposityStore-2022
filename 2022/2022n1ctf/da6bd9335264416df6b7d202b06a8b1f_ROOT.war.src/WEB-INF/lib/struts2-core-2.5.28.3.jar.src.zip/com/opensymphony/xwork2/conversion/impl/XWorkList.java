/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkList
/*     */   extends ArrayList
/*     */ {
/*  42 */   private static final Logger LOG = LogManager.getLogger(XWorkConverter.class);
/*     */   
/*     */   private Class clazz;
/*     */   
/*     */   public XWorkList(Class clazz) {
/*  47 */     this.clazz = clazz;
/*     */   }
/*     */   
/*     */   public XWorkList(Class clazz, int initialCapacity) {
/*  51 */     super(initialCapacity);
/*  52 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int index, Object element) {
/*  73 */     if (index >= size()) {
/*  74 */       get(index);
/*     */     }
/*     */     
/*  77 */     element = convert(element);
/*     */     
/*  79 */     super.add(index, element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(Object element) {
/*  96 */     element = convert(element);
/*     */     
/*  98 */     return super.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection collection) {
/* 120 */     if (collection == null) {
/* 121 */       throw new NullPointerException("Collection to add is null");
/*     */     }
/*     */     
/* 124 */     for (Object nextElement : collection) {
/* 125 */       add(nextElement);
/*     */     }
/*     */     
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection collection) {
/* 151 */     if (collection == null) {
/* 152 */       throw new NullPointerException("Collection to add is null");
/*     */     }
/*     */     
/* 155 */     boolean trim = false;
/*     */     
/* 157 */     if (index >= size()) {
/* 158 */       trim = true;
/*     */     }
/*     */     
/* 161 */     for (Iterator it = collection.iterator(); it.hasNext(); index++) {
/* 162 */       add(index, it.next());
/*     */     }
/*     */     
/* 165 */     if (trim) {
/* 166 */       remove(size() - 1);
/*     */     }
/*     */     
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object get(int index) {
/* 187 */     while (index >= size()) {
/*     */       try {
/* 189 */         add(getObjectFactory().buildBean(this.clazz, ActionContext.getContext().getContextMap()));
/* 190 */       } catch (Exception e) {
/* 191 */         throw new XWorkException(e);
/*     */       } 
/*     */     } 
/*     */     
/* 195 */     return super.get(index);
/*     */   }
/*     */   
/*     */   private ObjectFactory getObjectFactory() {
/* 199 */     return (ObjectFactory)ActionContext.getContext().getInstance(ObjectFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object set(int index, Object element) {
/* 219 */     if (index >= size()) {
/* 220 */       get(index);
/*     */     }
/*     */     
/* 223 */     element = convert(element);
/*     */     
/* 225 */     return super.set(index, element);
/*     */   }
/*     */   
/*     */   private Object convert(Object element) {
/* 229 */     if (element != null && !this.clazz.isAssignableFrom(element.getClass())) {
/*     */       
/* 231 */       LOG.debug("Converting from {} to {}", element.getClass().getName(), this.clazz.getName());
/* 232 */       TypeConverter converter = getTypeConverter();
/* 233 */       Map<String, Object> context = ActionContext.getContext().getContextMap();
/* 234 */       element = converter.convertValue(context, null, null, null, element, this.clazz);
/*     */     } 
/*     */     
/* 237 */     return element;
/*     */   }
/*     */   
/*     */   private TypeConverter getTypeConverter() {
/* 241 */     return (TypeConverter)ActionContext.getContext().getContainer().getInstance(XWorkConverter.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object element) {
/* 246 */     element = convert(element);
/* 247 */     return super.contains(element);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\XWorkList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */