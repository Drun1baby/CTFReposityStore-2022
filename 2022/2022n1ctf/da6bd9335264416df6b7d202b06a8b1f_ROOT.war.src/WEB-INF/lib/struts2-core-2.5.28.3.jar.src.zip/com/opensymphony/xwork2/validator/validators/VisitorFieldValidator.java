/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.CompositeTextProvider;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.ValidationAware;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.validator.ActionValidatorManager;
/*     */ import com.opensymphony.xwork2.validator.DelegatingValidatorContext;
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import com.opensymphony.xwork2.validator.ValidatorContext;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VisitorFieldValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*  92 */   private static final Logger LOG = LogManager.getLogger(VisitorFieldValidator.class);
/*     */   
/*     */   private String context;
/*     */   
/*     */   private boolean appendPrefix = true;
/*     */   private ActionValidatorManager actionValidatorManager;
/*     */   
/*     */   @Inject
/*     */   public void setActionValidatorManager(ActionValidatorManager mgr) {
/* 101 */     this.actionValidatorManager = mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAppendPrefix(boolean appendPrefix) {
/* 110 */     this.appendPrefix = appendPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAppendPrefix() {
/* 119 */     return this.appendPrefix;
/*     */   }
/*     */   
/*     */   public void setContext(String context) {
/* 123 */     this.context = context;
/*     */   }
/*     */   
/*     */   public String getContext() {
/* 127 */     return this.context;
/*     */   }
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/* 131 */     String fieldName = getFieldName();
/* 132 */     Object value = getFieldValue(fieldName, object);
/* 133 */     if (value == null) {
/* 134 */       LOG.warn("The visited object is null, VisitorValidator will not be able to handle validation properly. Please make sure the visited object is not null for VisitorValidator to function properly");
/*     */       return;
/*     */     } 
/* 137 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */     
/* 139 */     stack.push(object);
/*     */     
/* 141 */     String visitorContext = (this.context == null) ? ActionContext.getContext().getName() : this.context;
/*     */     
/* 143 */     if (value instanceof Collection) {
/* 144 */       Collection coll = (Collection)value;
/* 145 */       Object[] array = coll.toArray();
/*     */       
/* 147 */       validateArrayElements(array, fieldName, visitorContext);
/* 148 */     } else if (value instanceof Object[]) {
/* 149 */       Object[] array = (Object[])value;
/*     */       
/* 151 */       validateArrayElements(array, fieldName, visitorContext);
/*     */     } else {
/* 153 */       validateObject(fieldName, value, visitorContext);
/*     */     } 
/*     */     
/* 156 */     stack.pop();
/*     */   }
/*     */   
/*     */   private void validateArrayElements(Object[] array, String fieldName, String visitorContext) throws ValidationException {
/* 160 */     if (array == null) {
/*     */       return;
/*     */     }
/*     */     
/* 164 */     for (int i = 0; i < array.length; i++) {
/* 165 */       Object o = array[i];
/* 166 */       if (o != null)
/* 167 */         validateObject(fieldName + "[" + i + "]", o, visitorContext); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateObject(String fieldName, Object o, String visitorContext) throws ValidationException {
/*     */     DelegatingValidatorContext delegatingValidatorContext;
/* 173 */     ValueStack stack = ActionContext.getContext().getValueStack();
/* 174 */     stack.push(o);
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (this.appendPrefix) {
/* 179 */       ValidatorContext parent = getValidatorContext();
/* 180 */       delegatingValidatorContext = new AppendingValidatorContext(parent, (TextProvider)createTextProvider(o, parent), fieldName, getMessage(o));
/*     */     } else {
/* 182 */       ValidatorContext parent = getValidatorContext();
/* 183 */       CompositeTextProvider textProvider = createTextProvider(o, parent);
/* 184 */       delegatingValidatorContext = new DelegatingValidatorContext((ValidationAware)parent, (TextProvider)textProvider, (LocaleProvider)parent);
/*     */     } 
/*     */     
/* 187 */     this.actionValidatorManager.validate(o, visitorContext, (ValidatorContext)delegatingValidatorContext);
/* 188 */     stack.pop();
/*     */   }
/*     */   
/*     */   private CompositeTextProvider createTextProvider(Object o, ValidatorContext parent) {
/* 192 */     List<TextProvider> textProviders = new LinkedList<>();
/* 193 */     if (o instanceof TextProvider) {
/* 194 */       textProviders.add((TextProvider)o);
/*     */     } else {
/* 196 */       textProviders.add(this.textProviderFactory.createInstance(o.getClass()));
/*     */     } 
/* 198 */     textProviders.add(parent);
/*     */     
/* 200 */     return new CompositeTextProvider(textProviders);
/*     */   }
/*     */   
/*     */   public static class AppendingValidatorContext extends DelegatingValidatorContext {
/*     */     private String field;
/*     */     private String message;
/*     */     private ValidatorContext parent;
/*     */     
/*     */     public AppendingValidatorContext(ValidatorContext parent, TextProvider textProvider, String field, String message) {
/* 209 */       super((ValidationAware)parent, textProvider, (LocaleProvider)parent);
/*     */       
/* 211 */       this.field = field;
/* 212 */       this.message = message;
/* 213 */       this.parent = parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getFullFieldName(String fieldName) {
/* 224 */       if (this.parent instanceof AppendingValidatorContext) {
/* 225 */         return this.parent.getFullFieldName(this.field + "." + fieldName);
/*     */       }
/* 227 */       return this.field + "." + fieldName;
/*     */     }
/*     */     
/*     */     public String getFieldNameWithField(String fieldName) {
/* 231 */       return this.field + "." + fieldName;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addActionError(String anErrorMessage) {
/* 236 */       super.addFieldError(getFieldNameWithField(this.field), this.message + anErrorMessage);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addFieldError(String fieldName, String errorMessage) {
/* 241 */       super.addFieldError(getFieldNameWithField(fieldName), this.message + errorMessage);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\VisitorFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */