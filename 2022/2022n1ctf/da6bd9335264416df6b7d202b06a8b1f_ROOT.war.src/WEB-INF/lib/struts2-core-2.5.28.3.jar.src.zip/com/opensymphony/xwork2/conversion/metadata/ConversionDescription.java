/*     */ package com.opensymphony.xwork2.conversion.metadata;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.annotations.ConversionRule;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ConversionDescription
/*     */ {
/*  43 */   protected static Logger log = null;
/*     */ 
/*     */   
/*     */   public static final String KEY_PREFIX = "Key_";
/*     */   
/*     */   public static final String ELEMENT_PREFIX = "Element_";
/*     */   
/*     */   public static final String KEY_PROPERTY_PREFIX = "KeyProperty_";
/*     */   
/*     */   public static final String DEPRECATED_ELEMENT_PREFIX = "Collection_";
/*     */   
/*  54 */   String MAP_PREFIX = "Map_";
/*     */   
/*     */   public String property;
/*  57 */   public String typeConverter = "";
/*  58 */   public String rule = "";
/*  59 */   public String value = "";
/*     */   public String fullQualifiedClassName;
/*  61 */   public String type = null;
/*     */   
/*     */   public ConversionDescription() {
/*  64 */     log = LogManager.getLogger(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversionDescription(String property) {
/*  73 */     this.property = property;
/*  74 */     log = LogManager.getLogger(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String property) {
/*  86 */     this.property = property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeConverter(String typeConverter) {
/*  95 */     this.typeConverter = typeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRule(String rule) {
/* 102 */     if (rule != null && rule.length() > 0) {
/* 103 */       if (rule.equals(ConversionRule.COLLECTION.toString())) {
/* 104 */         this.rule = "Collection_";
/* 105 */       } else if (rule.equals(ConversionRule.ELEMENT.toString())) {
/* 106 */         this.rule = "Element_";
/* 107 */       } else if (rule.equals(ConversionRule.KEY.toString())) {
/* 108 */         this.rule = "Key_";
/* 109 */       } else if (rule.equals(ConversionRule.KEY_PROPERTY.toString())) {
/* 110 */         this.rule = "KeyProperty_";
/* 111 */       } else if (rule.equals(ConversionRule.MAP.toString())) {
/* 112 */         this.rule = this.MAP_PREFIX;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(String type) {
/* 119 */     this.type = type;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 123 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 127 */     return this.value;
/*     */   }
/*     */   
/*     */   public void setValue(String value) {
/* 131 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asProperty() {
/* 147 */     StringWriter sw = new StringWriter();
/* 148 */     PrintWriter writer = null;
/*     */     try {
/* 150 */       writer = new PrintWriter(sw);
/* 151 */       writer.print(this.rule);
/* 152 */       writer.print(this.property);
/* 153 */       writer.print("=");
/* 154 */       if (this.rule.startsWith("KeyProperty_") && this.value != null && this.value.length() > 0) {
/* 155 */         writer.print(this.value);
/*     */       } else {
/* 157 */         writer.print(this.typeConverter);
/*     */       } 
/*     */     } finally {
/* 160 */       if (writer != null) {
/* 161 */         writer.flush();
/* 162 */         writer.close();
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullQualifiedClassName() {
/* 176 */     return this.fullQualifiedClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFullQualifiedClassName(String fullQualifiedClassName) {
/* 185 */     this.fullQualifiedClassName = fullQualifiedClassName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\metadata\ConversionDescription.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */