/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.inject.Context;
/*    */ import com.opensymphony.xwork2.inject.Factory;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import com.opensymphony.xwork2.test.StubConfigurationProvider;
/*    */ import com.opensymphony.xwork2.util.XWorkTestCaseHelper;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ import org.junit.After;
/*    */ import org.junit.Before;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XWorkJUnit4TestCase
/*    */ {
/*    */   protected ConfigurationManager configurationManager;
/*    */   protected Configuration configuration;
/*    */   protected Container container;
/*    */   protected ActionProxyFactory actionProxyFactory;
/*    */   
/*    */   @Before
/*    */   public void setUp() throws Exception {
/* 41 */     this.configurationManager = XWorkTestCaseHelper.setUp();
/* 42 */     this.configuration = this.configurationManager.getConfiguration();
/* 43 */     this.container = this.configuration.getContainer();
/* 44 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */   
/*    */   @After
/*    */   public void tearDown() throws Exception {
/* 49 */     XWorkTestCaseHelper.tearDown(this.configurationManager);
/* 50 */     this.configurationManager = null;
/* 51 */     this.configuration = null;
/* 52 */     this.container = null;
/* 53 */     this.actionProxyFactory = null;
/*    */   }
/*    */   
/*    */   protected void loadConfigurationProviders(ConfigurationProvider... providers) {
/* 57 */     this.configurationManager = XWorkTestCaseHelper.loadConfigurationProviders(this.configurationManager, providers);
/* 58 */     this.configuration = this.configurationManager.getConfiguration();
/* 59 */     this.container = this.configuration.getContainer();
/* 60 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */   
/*    */   protected void loadButAdd(Class<?> type, Object impl) {
/* 64 */     loadButAdd(type, "default", impl);
/*    */   }
/*    */   
/*    */   protected void loadButAdd(final Class<?> type, final String name, final Object impl) {
/* 68 */     loadConfigurationProviders(new ConfigurationProvider[] { (ConfigurationProvider)new StubConfigurationProvider()
/*    */           {
/*    */             public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException
/*    */             {
/* 72 */               builder.factory(type, name, new Factory() {
/*    */                     public Object create(Context context) throws Exception {
/* 74 */                       return impl;
/*    */                     }
/*    */ 
/*    */                     
/*    */                     public Class type() {
/* 79 */                       return impl.getClass();
/*    */                     }
/*    */                   },  Scope.SINGLETON);
/*    */             }
/*    */           } });
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\XWorkJUnit4TestCase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */