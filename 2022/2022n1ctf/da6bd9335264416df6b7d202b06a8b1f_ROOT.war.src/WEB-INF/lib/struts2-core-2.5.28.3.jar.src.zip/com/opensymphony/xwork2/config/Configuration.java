package com.opensymphony.xwork2.config;

import com.opensymphony.xwork2.config.entities.PackageConfig;
import com.opensymphony.xwork2.config.entities.UnknownHandlerConfig;
import com.opensymphony.xwork2.inject.Container;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface Configuration extends Serializable {
  void rebuildRuntimeConfiguration();
  
  PackageConfig getPackageConfig(String paramString);
  
  Set<String> getPackageConfigNames();
  
  Map<String, PackageConfig> getPackageConfigs();
  
  RuntimeConfiguration getRuntimeConfiguration();
  
  void addPackageConfig(String paramString, PackageConfig paramPackageConfig);
  
  PackageConfig removePackageConfig(String paramString);
  
  void destroy();
  
  List<PackageProvider> reloadContainer(List<ContainerProvider> paramList) throws ConfigurationException;
  
  Container getContainer();
  
  Set<String> getLoadedFileNames();
  
  List<UnknownHandlerConfig> getUnknownHandlerStack();
  
  void setUnknownHandlerStack(List<UnknownHandlerConfig> paramList);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\Configuration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */