package com.opensymphony.xwork2.validator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface DateRangeFieldValidator {
  String min() default "";
  
  String minExpression() default "";
  
  String max() default "";
  
  String maxExpression() default "";
  
  String dateFormat() default "";
  
  String message() default "";
  
  String key() default "";
  
  String[] messageParams() default {};
  
  String fieldName() default "";
  
  boolean shortCircuit() default false;
  
  ValidatorType type() default ValidatorType.FIELD;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\annotations\DateRangeFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */