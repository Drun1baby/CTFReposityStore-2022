/*    */ package com.opensymphony.xwork2.mock;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.Result;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MockResult
/*    */   implements Result
/*    */ {
/*    */   public static final String DEFAULT_PARAM = "foo";
/*    */   
/*    */   public boolean equals(Object o) {
/* 36 */     if (this == o) {
/* 37 */       return true;
/*    */     }
/*    */     
/* 40 */     return o instanceof MockResult;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(ActionInvocation invocation) throws Exception {}
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     return 10;
/*    */   }
/*    */   
/*    */   public void setFoo(String foo) {}
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockResult.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */