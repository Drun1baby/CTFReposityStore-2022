/*     */ package com.opensymphony.xwork2.security;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultExcludedPatternsChecker
/*     */   implements ExcludedPatternsChecker
/*     */ {
/*  37 */   private static final Logger LOG = LogManager.getLogger(DefaultExcludedPatternsChecker.class);
/*     */   
/*  39 */   public static final String[] EXCLUDED_PATTERNS = new String[] { "(^|\\%\\{)((#?)(top(\\.|\\['|\\[\")|\\[\\d\\]\\.)?)(dojo|struts|session|request|response|application|servlet(Request|Response|Context)|parameters|context|_memberAccess)(\\.|\\[).*", ".*(^|\\.|\\[|\\'|\"|get)class(\\(\\.|\\[|\\'|\").*" };
/*     */ 
/*     */   
/*     */   private Set<Pattern> excludedPatterns;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultExcludedPatternsChecker() {
/*  47 */     setExcludedPatterns(EXCLUDED_PATTERNS);
/*     */   }
/*     */   
/*     */   @Inject(value = "overrideExcludedPatterns", required = false)
/*     */   protected void setOverrideExcludePatterns(String excludePatterns) {
/*  52 */     if (this.excludedPatterns != null && this.excludedPatterns.size() > 0) {
/*  53 */       LOG.warn("Overriding excluded patterns [{}] with [{}], be aware that this affects all instances and safety of your application!", this.excludedPatterns, excludePatterns);
/*     */     }
/*     */     else {
/*     */       
/*  57 */       LOG.debug("Overriding excluded patterns with [{}]", excludePatterns);
/*     */     } 
/*  59 */     this.excludedPatterns = new HashSet<>();
/*     */     try {
/*  61 */       for (String pattern : TextParseUtil.commaDelimitedStringToSet(excludePatterns)) {
/*  62 */         this.excludedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/*  65 */       this.excludedPatterns = Collections.unmodifiableSet(this.excludedPatterns);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(value = "additionalExcludedPatterns", required = false)
/*     */   public void setAdditionalExcludePatterns(String excludePatterns) {
/*  71 */     LOG.debug("Adding additional global patterns [{}] to excluded patterns!", excludePatterns);
/*  72 */     this.excludedPatterns = new HashSet<>(this.excludedPatterns);
/*     */     try {
/*  74 */       for (String pattern : TextParseUtil.commaDelimitedStringToSet(excludePatterns)) {
/*  75 */         this.excludedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/*  78 */       this.excludedPatterns = Collections.unmodifiableSet(this.excludedPatterns);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject("struts.enable.DynamicMethodInvocation")
/*     */   protected void setDynamicMethodInvocation(String dmiValue) {
/*  84 */     if (!BooleanUtils.toBoolean(dmiValue)) {
/*  85 */       LOG.debug("DMI is disabled, adding DMI related excluded patterns");
/*  86 */       setAdditionalExcludePatterns("^(action|method):.*");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExcludedPatterns(String commaDelimitedPatterns) {
/*  92 */     setExcludedPatterns(TextParseUtil.commaDelimitedStringToSet(commaDelimitedPatterns));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExcludedPatterns(String[] patterns) {
/*  97 */     setExcludedPatterns(new HashSet<>(Arrays.asList(patterns)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExcludedPatterns(Set<String> patterns) {
/* 102 */     if (this.excludedPatterns != null && this.excludedPatterns.size() > 0) {
/* 103 */       LOG.warn("Replacing excluded patterns [{}] with [{}], be aware that this affects all instances and safety of your application!", this.excludedPatterns, patterns);
/*     */     }
/*     */     else {
/*     */       
/* 107 */       LOG.debug("Sets excluded patterns to [{}]", patterns);
/*     */     } 
/* 109 */     this.excludedPatterns = new HashSet<>(patterns.size());
/*     */     try {
/* 111 */       for (String pattern : patterns) {
/* 112 */         this.excludedPatterns.add(Pattern.compile(pattern, 2));
/*     */       }
/*     */     } finally {
/* 115 */       this.excludedPatterns = Collections.unmodifiableSet(this.excludedPatterns);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ExcludedPatternsChecker.IsExcluded isExcluded(String value) {
/* 121 */     for (Pattern excludedPattern : this.excludedPatterns) {
/* 122 */       if (excludedPattern.matcher(value).matches()) {
/* 123 */         LOG.trace("[{}] matches excluded pattern [{}]", value, excludedPattern);
/* 124 */         return ExcludedPatternsChecker.IsExcluded.yes(excludedPattern);
/*     */       } 
/*     */     } 
/* 127 */     return ExcludedPatternsChecker.IsExcluded.no(this.excludedPatterns);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Pattern> getExcludedPatterns() {
/* 132 */     return this.excludedPatterns;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\security\DefaultExcludedPatternsChecker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */