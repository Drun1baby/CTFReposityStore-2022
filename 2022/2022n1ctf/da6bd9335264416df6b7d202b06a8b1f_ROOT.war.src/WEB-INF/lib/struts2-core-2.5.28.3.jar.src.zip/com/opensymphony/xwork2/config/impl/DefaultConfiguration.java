/*     */ package com.opensymphony.xwork2.config.impl;
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.DefaultTextProvider;
/*     */ import com.opensymphony.xwork2.LocaleProviderFactory;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.ContainerProvider;
/*     */ import com.opensymphony.xwork2.config.PackageProvider;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
/*     */ import com.opensymphony.xwork2.config.entities.UnknownHandlerConfig;
/*     */ import com.opensymphony.xwork2.config.providers.EnvsValueSubstitutor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionFileProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionPropertiesProcessor;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.ArrayConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.CollectionConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.DateConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.DefaultConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.factory.ActionFactory;
/*     */ import com.opensymphony.xwork2.factory.DefaultConverterFactory;
/*     */ import com.opensymphony.xwork2.factory.DefaultUnknownHandlerFactory;
/*     */ import com.opensymphony.xwork2.factory.ResultFactory;
/*     */ import com.opensymphony.xwork2.factory.UnknownHandlerFactory;
/*     */ import com.opensymphony.xwork2.factory.ValidatorFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Context;
/*     */ import com.opensymphony.xwork2.inject.Factory;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.ognl.OgnlReflectionProvider;
/*     */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import com.opensymphony.xwork2.util.StrutsLocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import ognl.PropertyAccessor;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ public class DefaultConfiguration implements Configuration {
/*  57 */   protected static final Logger LOG = LogManager.getLogger(DefaultConfiguration.class);
/*     */ 
/*     */   
/*  60 */   protected Map<String, PackageConfig> packageContexts = new LinkedHashMap<>();
/*     */   protected RuntimeConfiguration runtimeConfiguration;
/*     */   protected Container container;
/*     */   protected String defaultFrameworkBeanName;
/*  64 */   protected Set<String> loadedFileNames = new TreeSet<>();
/*     */   
/*     */   protected List<UnknownHandlerConfig> unknownHandlerStack;
/*     */   
/*     */   ObjectFactory objectFactory;
/*     */   
/*     */   public DefaultConfiguration() {
/*  71 */     this("default");
/*     */   }
/*     */   
/*     */   public DefaultConfiguration(String defaultBeanName) {
/*  75 */     this.defaultFrameworkBeanName = defaultBeanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public PackageConfig getPackageConfig(String name) {
/*  80 */     return this.packageContexts.get(name);
/*     */   }
/*     */   
/*     */   public List<UnknownHandlerConfig> getUnknownHandlerStack() {
/*  84 */     return this.unknownHandlerStack;
/*     */   }
/*     */   
/*     */   public void setUnknownHandlerStack(List<UnknownHandlerConfig> unknownHandlerStack) {
/*  88 */     this.unknownHandlerStack = unknownHandlerStack;
/*     */   }
/*     */   
/*     */   public Set<String> getPackageConfigNames() {
/*  92 */     return this.packageContexts.keySet();
/*     */   }
/*     */   
/*     */   public Map<String, PackageConfig> getPackageConfigs() {
/*  96 */     return this.packageContexts;
/*     */   }
/*     */   
/*     */   public Set<String> getLoadedFileNames() {
/* 100 */     return this.loadedFileNames;
/*     */   }
/*     */   
/*     */   public RuntimeConfiguration getRuntimeConfiguration() {
/* 104 */     return this.runtimeConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/* 111 */     return this.container;
/*     */   }
/*     */   
/*     */   public void addPackageConfig(String name, PackageConfig packageContext) {
/* 115 */     PackageConfig check = this.packageContexts.get(name);
/* 116 */     if (check != null) {
/* 117 */       if (check.getLocation() != null && packageContext.getLocation() != null && check.getLocation().equals(packageContext.getLocation())) {
/*     */         
/* 119 */         LOG.debug("The package name '{}' is already been loaded by the same location and could be removed: {}", name, packageContext.getLocation());
/*     */       } else {
/*     */         
/* 122 */         throw new ConfigurationException("The package name '" + name + "' at location " + packageContext.getLocation() + " is already been used by another package at location " + check.getLocation(), packageContext);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.packageContexts.put(name, packageContext);
/*     */   }
/*     */   
/*     */   public PackageConfig removePackageConfig(String packageName) {
/* 132 */     return this.packageContexts.remove(packageName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 139 */     this.packageContexts.clear();
/* 140 */     this.loadedFileNames.clear();
/*     */   }
/*     */   
/*     */   public void rebuildRuntimeConfiguration() {
/* 144 */     this.runtimeConfiguration = buildRuntimeConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<PackageProvider> reloadContainer(List<ContainerProvider> providers) throws ConfigurationException {
/* 156 */     this.packageContexts.clear();
/* 157 */     this.loadedFileNames.clear();
/* 158 */     List<PackageProvider> packageProviders = new ArrayList<>();
/*     */     
/* 160 */     ContainerProperties props = new ContainerProperties();
/* 161 */     ContainerBuilder builder = new ContainerBuilder();
/* 162 */     Container bootstrap = createBootstrapContainer(providers);
/* 163 */     for (ContainerProvider containerProvider : providers) {
/*     */       
/* 165 */       bootstrap.inject(containerProvider);
/* 166 */       containerProvider.init(this);
/* 167 */       containerProvider.register(builder, props);
/*     */     } 
/* 169 */     props.setConstants(builder);
/*     */     
/* 171 */     builder.factory(Configuration.class, new Factory<Configuration>() {
/*     */           public Configuration create(Context context) throws Exception {
/* 173 */             return DefaultConfiguration.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends Configuration> type() {
/* 178 */             return (Class)DefaultConfiguration.this.getClass();
/*     */           }
/*     */         });
/*     */     
/* 182 */     ActionContext oldContext = ActionContext.getContext();
/*     */ 
/*     */     
/*     */     try {
/* 186 */       setContext(bootstrap);
/* 187 */       this.container = builder.create(false);
/* 188 */       setContext(this.container);
/* 189 */       this.objectFactory = (ObjectFactory)this.container.getInstance(ObjectFactory.class);
/*     */ 
/*     */       
/* 192 */       for (ContainerProvider containerProvider : providers) {
/*     */         
/* 194 */         if (containerProvider instanceof PackageProvider) {
/* 195 */           this.container.inject(containerProvider);
/* 196 */           ((PackageProvider)containerProvider).loadPackages();
/* 197 */           packageProviders.add((PackageProvider)containerProvider);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 202 */       Set<String> packageProviderNames = this.container.getInstanceNames(PackageProvider.class);
/* 203 */       for (String name : packageProviderNames) {
/* 204 */         PackageProvider provider = (PackageProvider)this.container.getInstance(PackageProvider.class, name);
/* 205 */         provider.init(this);
/* 206 */         provider.loadPackages();
/* 207 */         packageProviders.add(provider);
/*     */       } 
/*     */       
/* 210 */       rebuildRuntimeConfiguration();
/*     */     } finally {
/* 212 */       if (oldContext == null) {
/* 213 */         ActionContext.setContext(null);
/*     */       }
/*     */     } 
/* 216 */     return packageProviders;
/*     */   }
/*     */   
/*     */   protected ActionContext setContext(Container cont) {
/* 220 */     ActionContext context = ActionContext.getContext();
/* 221 */     if (context == null) {
/* 222 */       ValueStack vs = ((ValueStackFactory)cont.getInstance(ValueStackFactory.class)).createValueStack();
/* 223 */       context = new ActionContext(vs.getContext());
/* 224 */       ActionContext.setContext(context);
/*     */     } 
/* 226 */     return context;
/*     */   }
/*     */   
/*     */   protected Container createBootstrapContainer(List<ContainerProvider> providers) {
/* 230 */     ContainerBuilder builder = new ContainerBuilder();
/* 231 */     boolean fmFactoryRegistered = false;
/* 232 */     for (ContainerProvider provider : providers) {
/* 233 */       if (provider instanceof com.opensymphony.xwork2.config.FileManagerProvider) {
/* 234 */         provider.register(builder, null);
/*     */       }
/* 236 */       if (provider instanceof com.opensymphony.xwork2.config.FileManagerFactoryProvider) {
/* 237 */         provider.register(builder, null);
/* 238 */         fmFactoryRegistered = true;
/*     */       } 
/*     */     } 
/* 241 */     builder.factory(ObjectFactory.class, Scope.SINGLETON);
/* 242 */     builder.factory(ActionFactory.class, DefaultActionFactory.class, Scope.SINGLETON);
/* 243 */     builder.factory(ResultFactory.class, DefaultResultFactory.class, Scope.SINGLETON);
/* 244 */     builder.factory(InterceptorFactory.class, DefaultInterceptorFactory.class, Scope.SINGLETON);
/* 245 */     builder.factory(ValidatorFactory.class, DefaultValidatorFactory.class, Scope.SINGLETON);
/* 246 */     builder.factory(ConverterFactory.class, DefaultConverterFactory.class, Scope.SINGLETON);
/* 247 */     builder.factory(UnknownHandlerFactory.class, DefaultUnknownHandlerFactory.class, Scope.SINGLETON);
/*     */     
/* 249 */     builder.factory(FileManager.class, "system", DefaultFileManager.class, Scope.SINGLETON);
/* 250 */     if (!fmFactoryRegistered) {
/* 251 */       builder.factory(FileManagerFactory.class, DefaultFileManagerFactory.class, Scope.SINGLETON);
/*     */     }
/* 253 */     builder.factory(ReflectionProvider.class, OgnlReflectionProvider.class, Scope.SINGLETON);
/* 254 */     builder.factory(ValueStackFactory.class, OgnlValueStackFactory.class, Scope.SINGLETON);
/*     */     
/* 256 */     builder.factory(XWorkConverter.class, Scope.SINGLETON);
/* 257 */     builder.factory(ConversionPropertiesProcessor.class, DefaultConversionPropertiesProcessor.class, Scope.SINGLETON);
/* 258 */     builder.factory(ConversionFileProcessor.class, DefaultConversionFileProcessor.class, Scope.SINGLETON);
/* 259 */     builder.factory(ConversionAnnotationProcessor.class, DefaultConversionAnnotationProcessor.class, Scope.SINGLETON);
/* 260 */     builder.factory(TypeConverterCreator.class, DefaultTypeConverterCreator.class, Scope.SINGLETON);
/* 261 */     builder.factory(TypeConverterHolder.class, DefaultTypeConverterHolder.class, Scope.SINGLETON);
/*     */     
/* 263 */     builder.factory(XWorkBasicConverter.class, Scope.SINGLETON);
/* 264 */     builder.factory(TypeConverter.class, "collectionConverter", CollectionConverter.class, Scope.SINGLETON);
/* 265 */     builder.factory(TypeConverter.class, "arrayConverter", ArrayConverter.class, Scope.SINGLETON);
/* 266 */     builder.factory(TypeConverter.class, "dateConverter", DateConverter.class, Scope.SINGLETON);
/* 267 */     builder.factory(TypeConverter.class, "numberConverter", NumberConverter.class, Scope.SINGLETON);
/* 268 */     builder.factory(TypeConverter.class, "stringConverter", StringConverter.class, Scope.SINGLETON);
/*     */     
/* 270 */     builder.factory(TextProvider.class, "system", DefaultTextProvider.class, Scope.SINGLETON);
/*     */     
/* 272 */     builder.factory(LocalizedTextProvider.class, StrutsLocalizedTextProvider.class, Scope.SINGLETON);
/* 273 */     builder.factory(TextProviderFactory.class, StrutsTextProviderFactory.class, Scope.SINGLETON);
/* 274 */     builder.factory(LocaleProviderFactory.class, DefaultLocaleProviderFactory.class, Scope.SINGLETON);
/*     */     
/* 276 */     builder.factory(TextParser.class, OgnlTextParser.class, Scope.SINGLETON);
/*     */     
/* 278 */     builder.factory(ObjectTypeDeterminer.class, DefaultObjectTypeDeterminer.class, Scope.SINGLETON);
/* 279 */     builder.factory(PropertyAccessor.class, CompoundRoot.class.getName(), CompoundRootAccessor.class, Scope.SINGLETON);
/* 280 */     builder.factory(OgnlUtil.class, Scope.SINGLETON);
/*     */     
/* 282 */     builder.factory(ValueSubstitutor.class, EnvsValueSubstitutor.class, Scope.SINGLETON);
/*     */     
/* 284 */     builder.constant("devMode", "false");
/* 285 */     builder.constant("struts.devMode", "false");
/* 286 */     builder.constant("logMissingProperties", "false");
/* 287 */     builder.constant("enableOGNLEvalExpression", "false");
/* 288 */     builder.constant("enableOGNLExpressionCache", "true");
/* 289 */     builder.constant("reloadXmlConfiguration", "false");
/* 290 */     builder.constant("struts.i18n.reload", "false");
/*     */     
/* 292 */     builder.constant("struts.matcher.appendNamedParameters", "true");
/*     */     
/* 294 */     return builder.create(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized RuntimeConfiguration buildRuntimeConfiguration() throws ConfigurationException {
/* 314 */     Map<String, Map<String, ActionConfig>> namespaceActionConfigs = new LinkedHashMap<>();
/* 315 */     Map<String, String> namespaceConfigs = new LinkedHashMap<>();
/*     */     
/* 317 */     for (PackageConfig packageConfig : this.packageContexts.values()) {
/*     */       
/* 319 */       if (!packageConfig.isAbstract()) {
/* 320 */         String namespace = packageConfig.getNamespace();
/* 321 */         Map<String, ActionConfig> configs = namespaceActionConfigs.get(namespace);
/*     */         
/* 323 */         if (configs == null) {
/* 324 */           configs = new LinkedHashMap<>();
/*     */         }
/*     */         
/* 327 */         Map<String, ActionConfig> actionConfigs = packageConfig.getAllActionConfigs();
/*     */         
/* 329 */         for (String o : actionConfigs.keySet()) {
/* 330 */           String actionName = o;
/* 331 */           ActionConfig baseConfig = actionConfigs.get(actionName);
/* 332 */           configs.put(actionName, buildFullActionConfig(packageConfig, baseConfig));
/*     */         } 
/*     */         
/* 335 */         namespaceActionConfigs.put(namespace, configs);
/* 336 */         if (packageConfig.getFullDefaultActionRef() != null) {
/* 337 */           namespaceConfigs.put(namespace, packageConfig.getFullDefaultActionRef());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 342 */     PatternMatcher<int[]> matcher = (PatternMatcher<int[]>)this.container.getInstance(PatternMatcher.class);
/* 343 */     boolean appendNamedParameters = Boolean.parseBoolean((String)this.container.getInstance(String.class, "struts.matcher.appendNamedParameters"));
/*     */ 
/*     */ 
/*     */     
/* 347 */     return new RuntimeConfigurationImpl(Collections.unmodifiableMap(namespaceActionConfigs), Collections.unmodifiableMap(namespaceConfigs), matcher, appendNamedParameters);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setDefaultResults(Map<String, ResultConfig> results, PackageConfig packageContext) {
/* 352 */     String defaultResult = packageContext.getFullDefaultResultType();
/*     */     
/* 354 */     for (Map.Entry<String, ResultConfig> entry : results.entrySet()) {
/*     */       
/* 356 */       if (entry.getValue() == null) {
/* 357 */         ResultTypeConfig resultTypeConfig = (ResultTypeConfig)packageContext.getAllResultTypeConfigs().get(defaultResult);
/* 358 */         entry.setValue((new ResultConfig.Builder(null, resultTypeConfig.getClassName())).build());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ActionConfig buildFullActionConfig(PackageConfig packageContext, ActionConfig baseConfig) throws ConfigurationException {
/* 374 */     Map<String, String> params = new TreeMap<>(baseConfig.getParams());
/* 375 */     Map<String, ResultConfig> results = new TreeMap<>();
/*     */     
/* 377 */     if (!baseConfig.getPackageName().equals(packageContext.getName()) && this.packageContexts.containsKey(baseConfig.getPackageName())) {
/* 378 */       results.putAll(((PackageConfig)this.packageContexts.get(baseConfig.getPackageName())).getAllGlobalResults());
/*     */     } else {
/* 380 */       results.putAll(packageContext.getAllGlobalResults());
/*     */     } 
/*     */     
/* 383 */     results.putAll(baseConfig.getResults());
/*     */     
/* 385 */     setDefaultResults(results, packageContext);
/*     */     
/* 387 */     List<InterceptorMapping> interceptors = new ArrayList<>(baseConfig.getInterceptors());
/*     */     
/* 389 */     if (interceptors.size() <= 0) {
/* 390 */       String defaultInterceptorRefName = packageContext.getFullDefaultInterceptorRef();
/*     */       
/* 392 */       if (defaultInterceptorRefName != null) {
/* 393 */         interceptors.addAll(InterceptorBuilder.constructInterceptorReference((InterceptorLocator)new PackageConfig.Builder(packageContext), defaultInterceptorRefName, new LinkedHashMap<>(), packageContext.getLocation(), this.objectFactory));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 398 */     String methodRegex = (String)this.container.getInstance(String.class, "struts.strictMethodInvocation.methodRegex");
/* 399 */     if (methodRegex == null) {
/* 400 */       methodRegex = "([A-Za-z0-9_$]*)";
/*     */     }
/*     */     
/* 403 */     LOG.debug("Using pattern [{}] to match allowed methods when SMI is disabled!", methodRegex);
/*     */     
/* 405 */     return (new ActionConfig.Builder(baseConfig)).addParams(params).addResultConfigs(results).defaultClassName(packageContext.getDefaultClassRef()).interceptors(interceptors).setStrictMethodInvocation(packageContext.isStrictMethodInvocation()).setDefaultMethodRegex(methodRegex).addExceptionMappings(packageContext.getAllExceptionMappingConfigs()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class RuntimeConfigurationImpl
/*     */     implements RuntimeConfiguration
/*     */   {
/*     */     private Map<String, Map<String, ActionConfig>> namespaceActionConfigs;
/*     */ 
/*     */ 
/*     */     
/*     */     private Map<String, ActionConfigMatcher> namespaceActionConfigMatchers;
/*     */ 
/*     */     
/*     */     private NamespaceMatcher namespaceMatcher;
/*     */ 
/*     */     
/*     */     private Map<String, String> namespaceConfigs;
/*     */ 
/*     */ 
/*     */     
/*     */     public RuntimeConfigurationImpl(Map<String, Map<String, ActionConfig>> namespaceActionConfigs, Map<String, String> namespaceConfigs, PatternMatcher<int[]> matcher, boolean appendNamedParameters) {
/* 429 */       this.namespaceActionConfigs = namespaceActionConfigs;
/* 430 */       this.namespaceConfigs = namespaceConfigs;
/*     */       
/* 432 */       this.namespaceActionConfigMatchers = new LinkedHashMap<>();
/* 433 */       this.namespaceMatcher = new NamespaceMatcher(matcher, namespaceActionConfigs.keySet(), appendNamedParameters);
/*     */       
/* 435 */       for (Map.Entry<String, Map<String, ActionConfig>> entry : namespaceActionConfigs.entrySet()) {
/* 436 */         ActionConfigMatcher configMatcher = new ActionConfigMatcher(matcher, entry.getValue(), true, appendNamedParameters);
/* 437 */         this.namespaceActionConfigMatchers.put(entry.getKey(), configMatcher);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ActionConfig getActionConfig(String namespace, String name) {
/* 451 */       ActionConfig config = findActionConfigInNamespace(namespace, name);
/*     */ 
/*     */       
/* 454 */       if (config == null) {
/* 455 */         NamespaceMatch match = this.namespaceMatcher.match(namespace);
/* 456 */         if (match != null) {
/* 457 */           config = findActionConfigInNamespace(match.getPattern(), name);
/*     */ 
/*     */           
/* 460 */           if (config != null) {
/* 461 */             config = (new ActionConfig.Builder(config)).addParams(match.getVariables()).build();
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 469 */       if (config == null && StringUtils.isNotBlank(namespace)) {
/* 470 */         config = findActionConfigInNamespace("", name);
/*     */       }
/*     */ 
/*     */       
/* 474 */       return config;
/*     */     }
/*     */     
/*     */     private ActionConfig findActionConfigInNamespace(String namespace, String name) {
/* 478 */       ActionConfig config = null;
/* 479 */       if (namespace == null) {
/* 480 */         namespace = "";
/*     */       }
/* 482 */       Map<String, ActionConfig> actions = this.namespaceActionConfigs.get(namespace);
/* 483 */       if (actions != null) {
/* 484 */         config = actions.get(name);
/*     */         
/* 486 */         if (config == null) {
/* 487 */           config = ((ActionConfigMatcher)this.namespaceActionConfigMatchers.get(namespace)).match(name);
/*     */           
/* 489 */           if (config == null) {
/* 490 */             String defaultActionRef = this.namespaceConfigs.get(namespace);
/* 491 */             if (defaultActionRef != null) {
/* 492 */               config = actions.get(defaultActionRef);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 497 */       return config;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<String, Map<String, ActionConfig>> getActionConfigs() {
/* 506 */       return this.namespaceActionConfigs;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 511 */       StringBuilder buff = new StringBuilder("RuntimeConfiguration - actions are\n");
/*     */       
/* 513 */       for (Map.Entry<String, Map<String, ActionConfig>> entry : this.namespaceActionConfigs.entrySet()) {
/* 514 */         Map<String, ActionConfig> actionConfigs = entry.getValue();
/*     */         
/* 516 */         for (String s : actionConfigs.keySet()) {
/* 517 */           buff.append(entry.getKey()).append("/").append(s).append("\n");
/*     */         }
/*     */       } 
/*     */       
/* 521 */       return buff.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   class ContainerProperties
/*     */     extends LocatableProperties {
/*     */     private static final long serialVersionUID = -7320625750836896089L;
/*     */     
/*     */     public Object setProperty(String key, String value) {
/* 530 */       String oldValue = getProperty(key);
/* 531 */       if (DefaultConfiguration.LOG.isInfoEnabled() && oldValue != null && !oldValue.equals(value) && !DefaultConfiguration.this.defaultFrameworkBeanName.equals(oldValue)) {
/* 532 */         DefaultConfiguration.LOG.info("Overriding property {} - old value: {} new value: {}", key, oldValue, value);
/*     */       }
/* 534 */       return super.setProperty(key, value);
/*     */     }
/*     */     
/*     */     public void setConstants(ContainerBuilder builder) {
/* 538 */       for (Object keyobj : keySet()) {
/* 539 */         String key = (String)keyobj;
/* 540 */         builder.factory(String.class, key, new LocatableConstantFactory<>(getProperty(key), getPropertyLocation(key)));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\DefaultConfiguration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */