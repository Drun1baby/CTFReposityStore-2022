/*    */ package com.opensymphony.xwork2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.FileManager;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.inject.Scope;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileManagerProvider
/*    */   implements ContainerProvider
/*    */ {
/*    */   private Class<? extends FileManager> fileManagerClass;
/*    */   private String name;
/*    */   
/*    */   public FileManagerProvider(Class<? extends FileManager> fileManagerClass, String name) {
/* 35 */     this.fileManagerClass = fileManagerClass;
/* 36 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {}
/*    */ 
/*    */   
/*    */   public void init(Configuration configuration) throws ConfigurationException {}
/*    */   
/*    */   public boolean needsReload() {
/* 46 */     return false;
/*    */   }
/*    */   
/*    */   public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 50 */     builder.factory(FileManager.class, this.name, this.fileManagerClass, Scope.SINGLETON);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\FileManagerProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */