/*    */ package com.opensymphony.xwork2.security;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AcceptedPatternsChecker
/*    */ {
/*    */   IsAccepted isAccepted(String paramString);
/*    */   
/*    */   void setAcceptedPatterns(String paramString);
/*    */   
/*    */   void setAcceptedPatterns(String[] paramArrayOfString);
/*    */   
/*    */   void setAcceptedPatterns(Set<String> paramSet);
/*    */   
/*    */   Set<Pattern> getAcceptedPatterns();
/*    */   
/*    */   public static final class IsAccepted
/*    */   {
/*    */     private final boolean accepted;
/*    */     private final String acceptedPattern;
/*    */     
/*    */     public static IsAccepted yes(String acceptedPattern) {
/* 71 */       return new IsAccepted(true, acceptedPattern);
/*    */     }
/*    */     
/*    */     public static IsAccepted no(String acceptedPatterns) {
/* 75 */       return new IsAccepted(false, acceptedPatterns);
/*    */     }
/*    */     
/*    */     private IsAccepted(boolean accepted, String acceptedPattern) {
/* 79 */       this.accepted = accepted;
/* 80 */       this.acceptedPattern = acceptedPattern;
/*    */     }
/*    */     
/*    */     public boolean isAccepted() {
/* 84 */       return this.accepted;
/*    */     }
/*    */     
/*    */     public String getAcceptedPattern() {
/* 88 */       return this.acceptedPattern;
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 93 */       return "IsAccepted {accepted=" + this.accepted + ", acceptedPattern=" + this.acceptedPattern + " }";
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\security\AcceptedPatternsChecker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */