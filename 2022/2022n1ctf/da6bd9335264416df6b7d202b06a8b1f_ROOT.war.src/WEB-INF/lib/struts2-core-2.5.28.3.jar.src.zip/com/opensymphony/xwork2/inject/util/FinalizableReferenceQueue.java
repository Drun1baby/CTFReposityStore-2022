/*    */ package com.opensymphony.xwork2.inject.util;
/*    */ 
/*    */ import java.lang.ref.Reference;
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FinalizableReferenceQueue
/*    */   extends ReferenceQueue<Object>
/*    */ {
/* 31 */   private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void cleanUp(Reference reference) {
/*    */     try {
/* 38 */       ((FinalizableReference)reference).finalizeReferent();
/* 39 */     } catch (Throwable t) {
/* 40 */       deliverBadNews(t);
/*    */     } 
/*    */   }
/*    */   
/*    */   void deliverBadNews(Throwable t) {
/* 45 */     logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*    */   }
/*    */   
/*    */   void start() {
/* 49 */     Thread thread = new Thread("FinalizableReferenceQueue") {
/*    */         public void run() {
/*    */           while (true) {
/*    */             try {
/*    */               while (true)
/* 54 */                 FinalizableReferenceQueue.this.cleanUp(FinalizableReferenceQueue.this.remove());  break;
/* 55 */             } catch (InterruptedException interruptedException) {}
/*    */           } 
/*    */         }
/*    */       };
/* 59 */     thread.setDaemon(true);
/* 60 */     thread.start();
/*    */   }
/*    */   
/* 63 */   static ReferenceQueue<Object> instance = createAndStart();
/*    */   
/*    */   static FinalizableReferenceQueue createAndStart() {
/* 66 */     FinalizableReferenceQueue queue = new FinalizableReferenceQueue();
/* 67 */     queue.start();
/* 68 */     return queue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReferenceQueue<Object> getInstance() {
/* 75 */     return instance;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\injec\\util\FinalizableReferenceQueue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */