/*    */ package com.opensymphony.xwork2.util.logging;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class LoggerUtils
/*    */ {
/*    */   public static String format(String msg, String... args) {
/* 49 */     if (msg != null && msg.length() > 0 && msg.indexOf('#') > -1) {
/* 50 */       StringBuilder sb = new StringBuilder();
/* 51 */       boolean isArg = false;
/* 52 */       for (int x = 0; x < msg.length(); x++) {
/* 53 */         char c = msg.charAt(x);
/* 54 */         if (isArg) {
/* 55 */           isArg = false;
/* 56 */           if (Character.isDigit(c)) {
/* 57 */             int val = Character.getNumericValue(c);
/* 58 */             if (val >= 0 && val < args.length) {
/* 59 */               sb.append(args[val]);
/*    */               continue;
/*    */             } 
/*    */           } 
/* 63 */           sb.append('#');
/*    */         } 
/* 65 */         if (c == '#') {
/* 66 */           isArg = true;
/*    */         } else {
/*    */           
/* 69 */           sb.append(c);
/*    */         }  continue;
/*    */       } 
/* 72 */       if (isArg) {
/* 73 */         sb.append('#');
/*    */       }
/* 75 */       return sb.toString();
/*    */     } 
/* 77 */     return msg;
/*    */   }
/*    */ 
/*    */   
/*    */   public static String format(String msg, Object[] args) {
/* 82 */     List<String> strArgs = new LinkedList<>();
/* 83 */     for (Object arg : args) {
/* 84 */       strArgs.add((arg != null) ? arg.toString() : "(null)");
/*    */     }
/* 86 */     return format(msg, strArgs.<String>toArray(new String[strArgs.size()]));
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\LoggerUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */