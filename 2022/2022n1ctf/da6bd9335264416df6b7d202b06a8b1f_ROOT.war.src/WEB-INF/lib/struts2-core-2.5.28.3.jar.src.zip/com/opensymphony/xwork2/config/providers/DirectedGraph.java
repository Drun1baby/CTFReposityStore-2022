/*     */ package com.opensymphony.xwork2.config.providers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DirectedGraph<T>
/*     */   implements Iterable<T>
/*     */ {
/*  30 */   private final Map<T, Set<T>> mGraph = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addNode(T node) {
/*  41 */     if (this.mGraph.containsKey(node)) {
/*  42 */       return false;
/*     */     }
/*     */     
/*  45 */     this.mGraph.put(node, new HashSet<>());
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEdge(T start, T dest) {
/*  62 */     if (!this.mGraph.containsKey(start))
/*  63 */       throw new NoSuchElementException("The start node does not exist in the graph."); 
/*  64 */     if (!this.mGraph.containsKey(dest)) {
/*  65 */       throw new NoSuchElementException("The destination node does not exist in the graph.");
/*     */     }
/*     */ 
/*     */     
/*  69 */     ((Set<T>)this.mGraph.get(start)).add(dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeEdge(T start, T dest) {
/*  85 */     if (!this.mGraph.containsKey(start))
/*  86 */       throw new NoSuchElementException("The start node does not exist in the graph."); 
/*  87 */     if (!this.mGraph.containsKey(dest)) {
/*  88 */       throw new NoSuchElementException("The destination node does not exist in the graph.");
/*     */     }
/*     */     
/*  91 */     ((Set)this.mGraph.get(start)).remove(dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean edgeExists(T start, T end) {
/* 108 */     if (!this.mGraph.containsKey(start))
/* 109 */       throw new NoSuchElementException("The start node does not exist in the graph."); 
/* 110 */     if (!this.mGraph.containsKey(end)) {
/* 111 */       throw new NoSuchElementException("The end node does not exist in the graph.");
/*     */     }
/*     */     
/* 114 */     return ((Set)this.mGraph.get(start)).contains(end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<T> edgesFrom(T node) {
/* 128 */     Set<T> arcs = this.mGraph.get(node);
/* 129 */     if (arcs == null) {
/* 130 */       throw new NoSuchElementException("Source node does not exist.");
/*     */     }
/* 132 */     return Collections.unmodifiableSet(arcs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 141 */     return this.mGraph.keySet().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 150 */     return this.mGraph.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 159 */     return this.mGraph.isEmpty();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\DirectedGraph.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */