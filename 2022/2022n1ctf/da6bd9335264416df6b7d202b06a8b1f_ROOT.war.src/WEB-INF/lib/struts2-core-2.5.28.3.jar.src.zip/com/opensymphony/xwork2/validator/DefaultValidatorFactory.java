/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.Initializable;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultValidatorFactory
/*     */   implements ValidatorFactory, Initializable
/*     */ {
/*  50 */   protected Map<String, String> validators = new HashMap<>();
/*  51 */   private static Logger LOG = LogManager.getLogger(DefaultValidatorFactory.class);
/*     */   protected ObjectFactory objectFactory;
/*     */   protected ValidatorFileParser validatorFileParser;
/*     */   
/*     */   @Inject
/*     */   public DefaultValidatorFactory(@Inject ObjectFactory objectFactory, @Inject ValidatorFileParser parser) {
/*  57 */     this.objectFactory = objectFactory;
/*  58 */     this.validatorFileParser = parser;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*  63 */     parseValidators();
/*     */   }
/*     */   
/*     */   public Validator getValidator(ValidatorConfig cfg) {
/*     */     Validator validator;
/*  68 */     String className = lookupRegisteredValidatorType(cfg.getType());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  75 */       validator = this.objectFactory.buildValidator(className, cfg.getParams(), ActionContext.getContext().getContextMap());
/*  76 */     } catch (Exception e) {
/*  77 */       String msg = "There was a problem creating a Validator of type " + className + " : caused by " + e.getMessage();
/*  78 */       throw new XWorkException(msg, e, cfg);
/*     */     } 
/*     */ 
/*     */     
/*  82 */     validator.setMessageKey(cfg.getMessageKey());
/*  83 */     validator.setDefaultMessage(cfg.getDefaultMessage());
/*  84 */     validator.setMessageParameters(cfg.getMessageParams());
/*  85 */     if (validator instanceof ShortCircuitableValidator) {
/*  86 */       ((ShortCircuitableValidator)validator).setShortCircuit(cfg.isShortCircuit());
/*     */     }
/*     */     
/*  89 */     return validator;
/*     */   }
/*     */   
/*     */   public void registerValidator(String name, String className) {
/*  93 */     LOG.debug("Registering validator of class {} with name {}", className, name);
/*  94 */     this.validators.put(name, className);
/*     */   }
/*     */ 
/*     */   
/*     */   public String lookupRegisteredValidatorType(String name) {
/*  99 */     String className = this.validators.get(name);
/*     */     
/* 101 */     if (className == null) {
/* 102 */       throw new IllegalArgumentException("There is no validator class mapped to the name " + name);
/*     */     }
/*     */     
/* 105 */     return className;
/*     */   }
/*     */   
/*     */   private void parseValidators() {
/* 109 */     LOG.debug("Loading validator definitions.");
/*     */     
/* 111 */     List<File> files = new ArrayList<>();
/*     */     
/*     */     try {
/* 114 */       Iterator<URL> urls = ClassLoaderUtil.getResources("", DefaultValidatorFactory.class, false);
/* 115 */       while (urls.hasNext()) {
/* 116 */         URL u = urls.next();
/*     */         try {
/* 118 */           URI uri = new URI(u.toExternalForm().replaceAll(" ", "%20"));
/* 119 */           if (!uri.isOpaque() && "file".equalsIgnoreCase(uri.getScheme())) {
/* 120 */             File f = new File(uri);
/* 121 */             FilenameFilter filter = new FilenameFilter() {
/*     */                 public boolean accept(File file, String fileName) {
/* 123 */                   return fileName.contains("-validators.xml");
/*     */                 }
/*     */               };
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 130 */             if (f.isDirectory()) {
/*     */               try {
/* 132 */                 File[] ff = f.listFiles(filter);
/* 133 */                 if (ff != null && ff.length > 0) {
/* 134 */                   files.addAll(Arrays.asList(ff));
/*     */                 }
/* 136 */               } catch (SecurityException se) {
/* 137 */                 LOG.error("Security Exception while accessing directory '{}'", f, se);
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/*     */               continue;
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 147 */             ZipInputStream zipInputStream = null;
/* 148 */             try (InputStream inputStream = u.openStream()) {
/* 149 */               if (inputStream instanceof ZipInputStream) {
/* 150 */                 zipInputStream = (ZipInputStream)inputStream;
/*     */               } else {
/* 152 */                 zipInputStream = new ZipInputStream(inputStream);
/*     */               } 
/* 154 */               ZipEntry zipEntry = zipInputStream.getNextEntry();
/* 155 */               while (zipEntry != null) {
/* 156 */                 if (zipEntry.getName().endsWith("-validators.xml")) {
/* 157 */                   LOG.trace("Adding validator {}", zipEntry.getName());
/* 158 */                   files.add(new File(zipEntry.getName()));
/*     */                 } 
/* 160 */                 zipEntry = zipInputStream.getNextEntry();
/*     */               } 
/*     */             } finally {
/*     */               
/* 164 */               if (zipInputStream != null) {
/* 165 */                 zipInputStream.close();
/*     */               }
/*     */             }
/*     */           
/*     */           } 
/* 170 */         } catch (Exception ex) {
/* 171 */           LOG.error("Unable to load {}", u, ex);
/*     */         } 
/*     */       } 
/* 174 */     } catch (IOException e) {
/* 175 */       throw new ConfigurationException("Unable to parse validators", e);
/*     */     } 
/*     */ 
/*     */     
/* 179 */     String resourceName = "com/opensymphony/xwork2/validator/validators/default.xml";
/* 180 */     retrieveValidatorConfiguration(resourceName);
/*     */ 
/*     */     
/* 183 */     resourceName = "validators.xml";
/* 184 */     retrieveValidatorConfiguration(resourceName);
/*     */ 
/*     */     
/* 187 */     for (File file : files) {
/* 188 */       retrieveValidatorConfiguration(file.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void retrieveValidatorConfiguration(String resourceName) {
/* 193 */     InputStream is = ClassLoaderUtil.getResourceAsStream(resourceName, DefaultValidatorFactory.class);
/* 194 */     if (is != null)
/* 195 */       this.validatorFileParser.parseValidatorDefinitions(this.validators, is, resourceName); 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\DefaultValidatorFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */