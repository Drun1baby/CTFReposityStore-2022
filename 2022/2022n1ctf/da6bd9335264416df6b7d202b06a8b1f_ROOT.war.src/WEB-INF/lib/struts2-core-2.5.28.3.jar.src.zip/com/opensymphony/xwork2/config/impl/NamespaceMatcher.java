/*    */ package com.opensymphony.xwork2.config.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.PatternMatcher;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamespaceMatcher
/*    */   extends AbstractMatcher<NamespaceMatch>
/*    */ {
/*    */   public NamespaceMatcher(PatternMatcher<?> patternMatcher, Set<String> namespaces) {
/* 34 */     this(patternMatcher, namespaces, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NamespaceMatcher(PatternMatcher<?> patternMatcher, Set<String> namespaces, boolean appendNamedParameters) {
/* 48 */     super(patternMatcher, appendNamedParameters);
/* 49 */     for (String name : namespaces) {
/* 50 */       if (!patternMatcher.isLiteral(name)) {
/* 51 */         addPattern(name, new NamespaceMatch(name, null), false);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected NamespaceMatch convert(String path, NamespaceMatch orig, Map<String, String> vars) {
/* 66 */     return new NamespaceMatch(orig.getPattern(), vars);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\NamespaceMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */