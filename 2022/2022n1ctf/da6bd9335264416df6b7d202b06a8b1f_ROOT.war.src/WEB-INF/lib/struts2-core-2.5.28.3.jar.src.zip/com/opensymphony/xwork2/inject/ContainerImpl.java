/*     */ package com.opensymphony.xwork2.inject;class ContainerImpl implements Container { final Map<Key<?>, InternalFactory<?>> factories; final Map<Class<?>, Set<String>> factoryNamesByType; final Map<Class<?>, List<Injector>> injectors;
/*     */   Map<Class<?>, ConstructorInjector> constructors;
/*     */   ThreadLocal<Object[]> localContext;
/*     */   final ThreadLocal<Object> localScopeStrategy;
/*     */   
/*     */   <T> InternalFactory<? extends T> getFactory(Key<T> key) {
/*     */     return (InternalFactory<? extends T>)this.factories.get(key);
/*     */   }
/*     */   
/*     */   void addInjectors(Class<Object> clazz, List<Injector> injectors) {
/*     */     if (clazz == Object.class)
/*     */       return; 
/*     */     addInjectors(clazz.getSuperclass(), injectors);
/*     */     addInjectorsForFields(clazz.getDeclaredFields(), false, injectors);
/*     */     addInjectorsForMethods(clazz.getDeclaredMethods(), false, injectors);
/*     */   }
/*     */   
/*     */   void injectStatics(List<Class<?>> staticInjections) {
/*     */     final List<Injector> injectors = new ArrayList<>();
/*     */     for (Class<?> clazz : staticInjections) {
/*     */       addInjectorsForFields(clazz.getDeclaredFields(), true, injectors);
/*     */       addInjectorsForMethods(clazz.getDeclaredMethods(), true, injectors);
/*     */     } 
/*     */     callInContext(new ContextualCallable<Void>() { public Void call(InternalContext context) {
/*     */             for (ContainerImpl.Injector injector : injectors)
/*     */               injector.inject(context, null); 
/*     */             return null;
/*     */           } }
/*     */       );
/*     */   }
/*     */   
/*     */   void addInjectorsForMethods(Method[] methods, boolean statics, List<Injector> injectors) {
/*     */     addInjectorsForMembers(Arrays.asList((Member[])methods), statics, injectors, (InjectorFactory)new InjectorFactory<Method>() { public ContainerImpl.Injector create(ContainerImpl container, Method method, String name) throws ContainerImpl.MissingDependencyException {
/*     */             return new ContainerImpl.MethodInjector(container, method, name);
/*     */           } }
/*     */       );
/*     */   }
/*     */   
/*     */   void addInjectorsForFields(Field[] fields, boolean statics, List<Injector> injectors) {
/*     */     addInjectorsForMembers(Arrays.asList((Member[])fields), statics, injectors, (InjectorFactory)new InjectorFactory<Field>() { public ContainerImpl.Injector create(ContainerImpl container, Field field, String name) throws ContainerImpl.MissingDependencyException {
/*     */             return new ContainerImpl.FieldInjector(container, field, name);
/*     */           } }
/*     */       );
/*     */   }
/*     */   
/*     */   <M extends Member & AnnotatedElement> void addInjectorsForMembers(List<M> members, boolean statics, List<Injector> injectors, InjectorFactory<M> injectorFactory) {
/*     */     for (Member member : members) {
/*     */       if (isStatic(member) == statics) {
/*     */         Inject inject = ((AnnotatedElement)member).<Inject>getAnnotation(Inject.class);
/*     */         if (inject != null)
/*     */           try {
/*     */             injectors.add(injectorFactory.create(this, (M)member, inject.value()));
/*     */           } catch (MissingDependencyException e) {
/*     */             if (inject.required())
/*     */               throw new DependencyException(e); 
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isStatic(Member member) {
/*     */     return Modifier.isStatic(member.getModifiers());
/*     */   }
/*     */   
/*  65 */   ContainerImpl(Map<Key<?>, InternalFactory<?>> factories) { this.injectors = (Map<Class<?>, List<Injector>>)new ReferenceCache<Class<?>, List<Injector>>()
/*     */       {
/*     */         protected List<ContainerImpl.Injector> create(Class<?> key)
/*     */         {
/*  69 */           List<ContainerImpl.Injector> injectors = new ArrayList<>();
/*  70 */           ContainerImpl.this.addInjectors(key, injectors);
/*  71 */           return injectors;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 291 */     this.constructors = (Map<Class<?>, ConstructorInjector>)new ReferenceCache<Class<?>, ConstructorInjector>()
/*     */       {
/*     */         
/*     */         protected ContainerImpl.ConstructorInjector<?> create(Class<?> implementation)
/*     */         {
/* 296 */           return new ContainerImpl.ConstructorInjector(ContainerImpl.this, implementation);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 543 */     this.localContext = new ThreadLocal<Object[]>()
/*     */       {
/*     */         protected Object[] initialValue() {
/* 546 */           return new Object[1];
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 583 */     this.localScopeStrategy = new ThreadLocal(); this.factories = factories; Map<Class<?>, Set<String>> map = new HashMap<>(); for (Key<?> key : factories.keySet()) { Set<String> names = map.get(key.getType()); if (names == null) { names = new HashSet<>(); map.put(key.getType(), names); }  names.add(key.getName()); }  for (Map.Entry<Class<?>, Set<String>> entry : map.entrySet()) entry.setValue(Collections.unmodifiableSet(entry.getValue()));  this.factoryNamesByType = Collections.unmodifiableMap(map); } static class FieldInjector implements Injector {
/*     */     final Field field; final InternalFactory<?> factory; final ExternalContext<?> externalContext; public FieldInjector(ContainerImpl container, Field field, String name) throws ContainerImpl.MissingDependencyException { this.field = field; if ((!Modifier.isPublic(field.getModifiers()) || !Modifier.isPublic(field.getDeclaringClass().getModifiers())) && !field.isAccessible()) { SecurityManager sm = System.getSecurityManager(); try { if (sm != null) sm.checkPermission(new ReflectPermission("suppressAccessChecks"));  field.setAccessible(true); } catch (AccessControlException e) { throw new DependencyException("Security manager in use, could not access field: " + field.getDeclaringClass().getName() + "(" + field.getName() + ")", e); }  }  Key<?> key = Key.newInstance(field.getType(), name); this.factory = container.getFactory(key); if (this.factory == null) throw new ContainerImpl.MissingDependencyException("No mapping found for dependency " + key + " in " + field + ".");  this.externalContext = ExternalContext.newInstance(field, key, container); } public void inject(InternalContext context, Object o) { ExternalContext<?> previous = context.getExternalContext(); context.setExternalContext(this.externalContext); try { this.field.set(o, this.factory.create(context)); } catch (IllegalAccessException e) { throw new AssertionError(e); } finally { context.setExternalContext(previous); }  } } <M extends java.lang.reflect.AccessibleObject & Member> ParameterInjector<?>[] getParametersInjectors(M member, Annotation[][] annotations, Class[] parameterTypes, String defaultName) throws MissingDependencyException { List<ParameterInjector<?>> parameterInjectors = new ArrayList<>(); Iterator<Annotation[]> annotationsIterator = (Iterator)Arrays.<Annotation[]>asList(annotations).iterator(); for (Class<?> parameterType : parameterTypes) { Inject annotation = findInject(annotationsIterator.next()); String name = (annotation == null) ? defaultName : annotation.value(); Key<?> key = Key.newInstance(parameterType, name); parameterInjectors.add(createParameterInjector(key, (Member)member)); }  return toArray(parameterInjectors); } <T> ParameterInjector<T> createParameterInjector(Key<T> key, Member member) throws MissingDependencyException { InternalFactory<? extends T> factory = getFactory(key); if (factory == null) throw new MissingDependencyException("No mapping found for dependency " + key + " in " + member + ".");  ExternalContext<T> externalContext = ExternalContext.newInstance(member, key, this); return new ParameterInjector<>(externalContext, factory); } private ParameterInjector<?>[] toArray(List<ParameterInjector<?>> parameterInjections) { return (ParameterInjector<?>[])parameterInjections.<ParameterInjector>toArray(new ParameterInjector[parameterInjections.size()]); } Inject findInject(Annotation[] annotations) { for (Annotation annotation : annotations) { if (annotation.annotationType() == Inject.class) return Inject.class.cast(annotation);  }  return null; } static class MethodInjector implements Injector {
/*     */     final Method method; final ContainerImpl.ParameterInjector<?>[] parameterInjectors; public MethodInjector(ContainerImpl container, Method method, String name) throws ContainerImpl.MissingDependencyException { this.method = method; if ((!Modifier.isPublic(method.getModifiers()) || !Modifier.isPublic(method.getDeclaringClass().getModifiers())) && !method.isAccessible()) { SecurityManager sm = System.getSecurityManager(); try { if (sm != null) sm.checkPermission(new ReflectPermission("suppressAccessChecks"));  method.setAccessible(true); } catch (AccessControlException e) { throw new DependencyException("Security manager in use, could not access method: " + name + "(" + method.getName() + ")", e); }  }  Class<?>[] parameterTypes = method.getParameterTypes(); if (parameterTypes.length == 0) throw new DependencyException(method + " has no parameters to inject.");  this.parameterInjectors = container.getParametersInjectors(method, method.getParameterAnnotations(), parameterTypes, name); } public void inject(InternalContext context, Object o) { try { this.method.invoke(o, ContainerImpl.getParameters(this.method, context, (ContainerImpl.ParameterInjector[])this.parameterInjectors)); } catch (Exception e) { throw new RuntimeException(e); }  } }
/* 586 */   public void setScopeStrategy(Scope.Strategy scopeStrategy) { this.localScopeStrategy.set(scopeStrategy); }
/*     */   static class ConstructorInjector<T> {
/*     */     final Class<T> implementation;
/*     */     final List<ContainerImpl.Injector> injectors; final Constructor<T> constructor; final ContainerImpl.ParameterInjector<?>[] parameterInjectors; ConstructorInjector(ContainerImpl container, Class<T> implementation) { ContainerImpl.ParameterInjector[] arrayOfParameterInjector; this.implementation = implementation; this.constructor = findConstructorIn(implementation); if ((!Modifier.isPublic(this.constructor.getModifiers()) || !Modifier.isPublic(this.constructor.getDeclaringClass().getModifiers())) && !this.constructor.isAccessible()) { SecurityManager sm = System.getSecurityManager(); try { if (sm != null) sm.checkPermission(new ReflectPermission("suppressAccessChecks"));  this.constructor.setAccessible(true); } catch (AccessControlException e) { throw new DependencyException("Security manager in use, could not access constructor: " + implementation.getName() + "(" + this.constructor.getName() + ")", e); }  }  ContainerImpl.MissingDependencyException exception = null; Inject inject = null; ContainerImpl.ParameterInjector<?>[] parameters = null; try { inject = this.constructor.<Inject>getAnnotation(Inject.class); arrayOfParameterInjector = (ContainerImpl.ParameterInjector[])constructParameterInjector(inject, container, this.constructor); } catch (MissingDependencyException e) { exception = e; }  this.parameterInjectors = (ContainerImpl.ParameterInjector<?>[])arrayOfParameterInjector; if (exception != null && inject != null && inject.required()) throw new DependencyException(exception);  this.injectors = container.injectors.get(implementation); } ContainerImpl.ParameterInjector<?>[] constructParameterInjector(Inject inject, ContainerImpl container, Constructor<T> constructor) throws ContainerImpl.MissingDependencyException { return ((constructor.getParameterTypes()).length == 0) ? null : container.<Constructor<T>>getParametersInjectors(constructor, constructor.getParameterAnnotations(), constructor.getParameterTypes(), inject.value()); } private Constructor<T> findConstructorIn(Class<T> implementation) { Constructor<T> found = null; Constructor[] arrayOfConstructor = (Constructor[])implementation.getDeclaredConstructors(); for (Constructor<T> constructor : arrayOfConstructor) { if (constructor.getAnnotation(Inject.class) != null) { if (found != null) throw new DependencyException("More than one constructor annotated with @Inject found in " + implementation + ".");  found = constructor; }  }  if (found != null) return found;  try { return implementation.getDeclaredConstructor(new Class[0]); } catch (NoSuchMethodException e) { throw new DependencyException("Could not find a suitable constructor in " + implementation.getName() + "."); }  } Object construct(InternalContext context, Class<? super T> expectedType) { ConstructionContext<T> constructionContext = context.getConstructionContext(this); if (constructionContext.isConstructing()) return constructionContext.createProxy(expectedType);  T t = constructionContext.getCurrentReference(); if (t != null) return t;  try { constructionContext.startConstruction(); try { Object[] parameters = ContainerImpl.getParameters(this.constructor, context, (ContainerImpl.ParameterInjector[])this.parameterInjectors); t = this.constructor.newInstance(parameters); constructionContext.setProxyDelegates(t); } finally { constructionContext.finishConstruction(); }  constructionContext.setCurrentReference(t); for (ContainerImpl.Injector injector : this.injectors) injector.inject(context, t);  return t; } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) { throw new RuntimeException(e); } finally { constructionContext.removeCurrentReference(); }  } } static class ParameterInjector<T> {
/* 590 */     final ExternalContext<T> externalContext; final InternalFactory<? extends T> factory; public ParameterInjector(ExternalContext<T> externalContext, InternalFactory<? extends T> factory) { this.externalContext = externalContext; this.factory = factory; } T inject(Member member, InternalContext context) { ExternalContext<?> previous = context.getExternalContext(); context.setExternalContext(this.externalContext); try { return this.factory.create(context); } finally { context.setExternalContext(previous); }  } } private static Object[] getParameters(Member member, InternalContext context, ParameterInjector[] parameterInjectors) { if (parameterInjectors == null) return null;  Object[] parameters = new Object[parameterInjectors.length]; for (int i = 0; i < parameters.length; i++) parameters[i] = parameterInjectors[i].inject(member, context);  return parameters; } public void removeScopeStrategy() { this.localScopeStrategy.remove(); }
/*     */   void inject(Object o, InternalContext context) { List<Injector> injectors = this.injectors.get(o.getClass()); for (Injector injector : injectors) injector.inject(context, o);  }
/*     */   <T> T inject(Class<T> implementation, InternalContext context) { try { ConstructorInjector<T> constructor = getConstructor(implementation); return implementation.cast(constructor.construct(context, implementation)); } catch (Exception e) { throw new RuntimeException(e); }  } <T> T getInstance(Class<T> type, String name, InternalContext context) { ExternalContext<?> previous = context.getExternalContext(); Key<T> key = Key.newInstance(type, name); context.setExternalContext(ExternalContext.newInstance(null, key, this)); try { InternalFactory<? extends T> o = getFactory(key); if (o != null) return (T)getFactory((Key)key).create(context);  return null; } finally { context.setExternalContext(previous); }  } <T> T getInstance(Class<T> type, InternalContext context) { return getInstance(type, "default", context); } public void inject(final Object o) { callInContext(new ContextualCallable<Void>() {
/*     */           public Void call(InternalContext context) { ContainerImpl.this.inject(o, context); return null; }
/*     */         }); } public <T> T inject(final Class<T> implementation) { return callInContext(new ContextualCallable<T>() {
/*     */           public T call(InternalContext context) { return ContainerImpl.this.inject(implementation, context); }
/*     */         }); } public <T> T getInstance(final Class<T> type, final String name) { return callInContext(new ContextualCallable<T>() {
/*     */           public T call(InternalContext context) { return ContainerImpl.this.getInstance(type, name, context); }
/*     */         }); } public <T> T getInstance(final Class<T> type) { return callInContext(new ContextualCallable<T>() {
/*     */           public T call(InternalContext context) { return ContainerImpl.this.getInstance(type, context); }
/*     */         }); } public Set<String> getInstanceNames(Class<?> type) { Set<String> names = this.factoryNamesByType.get(type); if (names == null) names = Collections.emptySet();  return names; } <T> T callInContext(ContextualCallable<T> callable) { Object[] reference = this.localContext.get(); if (reference[0] == null) { reference[0] = new InternalContext(this); try { return callable.call((InternalContext)reference[0]); } finally { reference[0] = null; this.localContext.remove(); }  }  return callable.call((InternalContext)reference[0]); } <T> ConstructorInjector<T> getConstructor(Class<T> implementation) { return this.constructors.get(implementation); } static class MissingDependencyException extends Exception
/*     */   {
/* 602 */     MissingDependencyException(String message) { super(message); }
/*     */   
/*     */   }
/*     */   
/*     */   static interface Injector extends Serializable {
/*     */     void inject(InternalContext param1InternalContext, Object param1Object);
/*     */   }
/*     */   
/*     */   static interface ContextualCallable<T> {
/*     */     T call(InternalContext param1InternalContext);
/*     */   }
/*     */   
/*     */   static interface InjectorFactory<M extends Member & AnnotatedElement> {
/*     */     ContainerImpl.Injector create(ContainerImpl param1ContainerImpl, M param1M, String param1String) throws ContainerImpl.MissingDependencyException;
/*     */   } }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\ContainerImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */