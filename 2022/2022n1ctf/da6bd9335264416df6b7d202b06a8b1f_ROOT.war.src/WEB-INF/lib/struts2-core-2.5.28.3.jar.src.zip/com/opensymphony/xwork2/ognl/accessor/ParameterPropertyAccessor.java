/*    */ package com.opensymphony.xwork2.ognl.accessor;
/*    */ 
/*    */ import java.util.Map;
/*    */ import ognl.ObjectPropertyAccessor;
/*    */ import ognl.OgnlException;
/*    */ import org.apache.struts2.dispatcher.Parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object oname) throws OgnlException {
/* 31 */     if (target instanceof Parameter) {
/* 32 */       if ("value".equalsIgnoreCase(String.valueOf(oname))) {
/* 33 */         throw new OgnlException("Access to " + oname + " is not allowed! Call parameter name directly!");
/*    */       }
/* 35 */       return ((Parameter)target).getObject();
/*    */     } 
/* 37 */     return super.getProperty(context, target, oname);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(Map context, Object target, Object oname, Object value) throws OgnlException {
/* 42 */     if (target instanceof Parameter) {
/* 43 */       throw new OgnlException("Access to " + target.getClass().getName() + " is read-only!");
/*    */     }
/* 45 */     super.setProperty(context, target, oname, value);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\ParameterPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */