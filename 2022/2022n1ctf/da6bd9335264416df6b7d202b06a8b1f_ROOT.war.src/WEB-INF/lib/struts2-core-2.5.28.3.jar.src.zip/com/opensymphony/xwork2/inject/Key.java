/*    */ package com.opensymphony.xwork2.inject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Key<T>
/*    */ {
/*    */   final Class<T> type;
/*    */   final String name;
/*    */   final int hashCode;
/*    */   
/*    */   private Key(Class<T> type, String name) {
/* 35 */     if (type == null) {
/* 36 */       throw new NullPointerException("Type is null.");
/*    */     }
/* 38 */     if (name == null) {
/* 39 */       throw new NullPointerException("Name is null.");
/*    */     }
/*    */     
/* 42 */     this.type = type;
/* 43 */     this.name = name;
/*    */     
/* 45 */     this.hashCode = type.hashCode() * 31 + name.hashCode();
/*    */   }
/*    */   
/*    */   Class<T> getType() {
/* 49 */     return this.type;
/*    */   }
/*    */   
/*    */   String getName() {
/* 53 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return this.hashCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 63 */     if (!(o instanceof Key)) {
/* 64 */       return false;
/*    */     }
/* 66 */     if (o == this) {
/* 67 */       return true;
/*    */     }
/* 69 */     Key other = (Key)o;
/* 70 */     return (this.name.equals(other.name) && this.type.equals(other.type));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return "[type=" + this.type.getName() + ", name='" + this.name + "']";
/*    */   }
/*    */   
/*    */   static <T> Key<T> newInstance(Class<T> type, String name) {
/* 79 */     return new Key<>(type, name);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\Key.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */