/*     */ package com.opensymphony.xwork2.inject;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Scope
/*     */ {
/*  32 */   PROTOTYPE
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(Class<T> type, String name, InternalFactory<? extends T> factory)
/*     */     {
/*  36 */       return InitializableFactory.wrapIfNeeded(factory);
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   SINGLETON
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(Class<T> type, String name, final InternalFactory<? extends T> factory) {
/*  46 */       return new InternalFactory<T>() {
/*     */           volatile T instance;
/*     */           
/*     */           public T create(InternalContext context) {
/*  50 */             if (this.instance == null) {
/*  51 */               synchronized (context.getContainer()) {
/*  52 */                 if (this.instance == null) {
/*  53 */                   this.instance = InitializableFactory.<T>wrapIfNeeded(factory).create(context);
/*     */                 }
/*     */               } 
/*     */             }
/*  57 */             return this.instance;
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends T> type() {
/*  62 */             return factory.type();
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/*  67 */             return factory.toString();
/*     */           }
/*     */         };
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   THREAD
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(Class<T> type, String name, final InternalFactory<? extends T> factory) {
/*  87 */       return new InternalFactory<T>() {
/*  88 */           final ThreadLocal<T> threadLocal = new ThreadLocal<>();
/*     */           
/*     */           public T create(InternalContext context) {
/*  91 */             T t = this.threadLocal.get();
/*  92 */             if (t == null) {
/*  93 */               t = InitializableFactory.<T>wrapIfNeeded(factory).create(context);
/*  94 */               this.threadLocal.set(t);
/*     */             } 
/*  96 */             return t;
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends T> type() {
/* 101 */             return factory.type();
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/* 106 */             return factory.toString();
/*     */           }
/*     */         };
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   REQUEST
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(final Class<T> type, final String name, final InternalFactory<? extends T> factory) {
/* 118 */       return new InternalFactory<T>() {
/*     */           public T create(InternalContext context) {
/* 120 */             Scope.Strategy strategy = context.getScopeStrategy();
/*     */             try {
/* 122 */               return strategy.findInRequest(type, name, Scope.null.this.toCallable(context, factory));
/*     */             }
/* 124 */             catch (Exception e) {
/* 125 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends T> type() {
/* 131 */             return factory.type();
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/* 136 */             return factory.toString();
/*     */           }
/*     */         };
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   SESSION
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(final Class<T> type, final String name, final InternalFactory<? extends T> factory) {
/* 148 */       return new InternalFactory<T>() {
/*     */           public T create(InternalContext context) {
/* 150 */             Scope.Strategy strategy = context.getScopeStrategy();
/*     */             try {
/* 152 */               return strategy.findInSession(type, name, Scope.null.this.toCallable(context, factory));
/*     */             }
/* 154 */             catch (Exception e) {
/* 155 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends T> type() {
/* 161 */             return factory.type();
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/* 166 */             return factory.toString();
/*     */           }
/*     */         };
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   WIZARD
/*     */   {
/*     */     <T> InternalFactory<? extends T> scopeFactory(final Class<T> type, final String name, final InternalFactory<? extends T> factory) {
/* 178 */       return new InternalFactory<T>() {
/*     */           public T create(InternalContext context) {
/* 180 */             Scope.Strategy strategy = context.getScopeStrategy();
/*     */             try {
/* 182 */               return strategy.findInWizard(type, name, Scope.null.this.toCallable(context, factory));
/*     */             }
/* 184 */             catch (Exception e) {
/* 185 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Class<? extends T> type() {
/* 191 */             return factory.type();
/*     */           }
/*     */ 
/*     */           
/*     */           public String toString() {
/* 196 */             return factory.toString();
/*     */           }
/*     */         };
/*     */     }
/*     */   };
/*     */ 
/*     */   
/*     */   <T> Callable<? extends T> toCallable(final InternalContext context, final InternalFactory<? extends T> factory) {
/* 204 */     return new Callable<T>() {
/*     */         public T call() throws Exception {
/* 206 */           return InitializableFactory.<T>wrapIfNeeded(factory).create(context);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   abstract <T> InternalFactory<? extends T> scopeFactory(Class<T> paramClass, String paramString, InternalFactory<? extends T> paramInternalFactory);
/*     */   
/*     */   public static interface Strategy {
/*     */     <T> T findInRequest(Class<T> param1Class, String param1String, Callable<? extends T> param1Callable) throws Exception;
/*     */     
/*     */     <T> T findInSession(Class<T> param1Class, String param1String, Callable<? extends T> param1Callable) throws Exception;
/*     */     
/*     */     <T> T findInWizard(Class<T> param1Class, String param1String, Callable<? extends T> param1Callable) throws Exception;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\Scope.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */