package com.opensymphony.xwork2.util.reflection;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;

public interface ReflectionProvider {
  Method getGetMethod(Class paramClass, String paramString) throws IntrospectionException, ReflectionException;
  
  Method getSetMethod(Class paramClass, String paramString) throws IntrospectionException, ReflectionException;
  
  Field getField(Class paramClass, String paramString);
  
  void setProperties(Map<String, ?> paramMap, Object paramObject, Map<String, Object> paramMap1);
  
  void setProperties(Map<String, ?> paramMap, Object paramObject, Map<String, Object> paramMap1, boolean paramBoolean) throws ReflectionException;
  
  void setProperties(Map<String, ?> paramMap, Object paramObject);
  
  PropertyDescriptor getPropertyDescriptor(Class paramClass, String paramString) throws IntrospectionException, ReflectionException;
  
  void copy(Object paramObject1, Object paramObject2, Map<String, Object> paramMap, Collection<String> paramCollection1, Collection<String> paramCollection2);
  
  void copy(Object paramObject1, Object paramObject2, Map<String, Object> paramMap, Collection<String> paramCollection1, Collection<String> paramCollection2, Class<?> paramClass);
  
  Object getRealTarget(String paramString, Map<String, Object> paramMap, Object paramObject) throws ReflectionException;
  
  void setProperty(String paramString, Object paramObject1, Object paramObject2, Map<String, Object> paramMap, boolean paramBoolean);
  
  void setProperty(String paramString, Object paramObject1, Object paramObject2, Map<String, Object> paramMap);
  
  Map<String, Object> getBeanMap(Object paramObject) throws IntrospectionException, ReflectionException;
  
  Object getValue(String paramString, Map<String, Object> paramMap, Object paramObject) throws ReflectionException;
  
  void setValue(String paramString, Map<String, Object> paramMap, Object paramObject1, Object paramObject2) throws ReflectionException;
  
  PropertyDescriptor[] getPropertyDescriptors(Object paramObject) throws IntrospectionException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\reflection\ReflectionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */