package com.opensymphony.xwork2;

import java.util.Map;

public interface ActionProxyFactory {
  ActionProxy createActionProxy(String paramString1, String paramString2, String paramString3, Map<String, Object> paramMap);
  
  ActionProxy createActionProxy(String paramString1, String paramString2, String paramString3, Map<String, Object> paramMap, boolean paramBoolean1, boolean paramBoolean2);
  
  ActionProxy createActionProxy(ActionInvocation paramActionInvocation, String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ActionProxyFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */