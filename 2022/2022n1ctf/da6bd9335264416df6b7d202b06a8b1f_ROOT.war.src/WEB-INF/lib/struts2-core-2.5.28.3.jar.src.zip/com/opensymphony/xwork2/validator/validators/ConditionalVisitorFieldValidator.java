/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalVisitorFieldValidator
/*     */   extends VisitorFieldValidator
/*     */ {
/*  52 */   private static final Logger LOG = LogManager.getLogger(ConditionalVisitorFieldValidator.class);
/*     */   
/*     */   private String expression;
/*     */   
/*     */   public void setExpression(String expression) {
/*  57 */     this.expression = expression;
/*     */   }
/*     */   
/*     */   public String getExpression() {
/*  61 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/*  72 */     if (validateExpression(object)) {
/*  73 */       super.validate(object);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean validateExpression(Object object) throws ValidationException {
/*  86 */     Boolean answer = Boolean.FALSE;
/*  87 */     Object obj = null;
/*     */     
/*     */     try {
/*  90 */       obj = getFieldValue(this.expression, object);
/*  91 */     } catch (ValidationException e) {
/*  92 */       throw e;
/*  93 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (obj != null && obj instanceof Boolean) {
/*  98 */       answer = (Boolean)obj;
/*     */     } else {
/* 100 */       LOG.warn("Got result of {} when trying to get Boolean.", obj);
/*     */     } 
/*     */     
/* 103 */     return answer.booleanValue();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\ConditionalVisitorFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */