/*    */ package com.opensymphony.xwork2.inject;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.LinkedHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExternalContext<T>
/*    */   implements Context
/*    */ {
/*    */   final Member member;
/*    */   final Key<T> key;
/*    */   final ContainerImpl container;
/*    */   
/*    */   public ExternalContext(Member member, Key<T> key, ContainerImpl container) {
/* 39 */     this.member = member;
/* 40 */     this.key = key;
/* 41 */     this.container = container;
/*    */   }
/*    */   
/*    */   public Class<T> getType() {
/* 45 */     return this.key.getType();
/*    */   }
/*    */   
/*    */   public Scope.Strategy getScopeStrategy() {
/* 49 */     return this.container.localScopeStrategy.get();
/*    */   }
/*    */   
/*    */   public Container getContainer() {
/* 53 */     return this.container;
/*    */   }
/*    */   
/*    */   public Member getMember() {
/* 57 */     return this.member;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 61 */     return this.key.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     return "Context" + (new LinkedHashMap<String, Object>() {  }).toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> ExternalContext<T> newInstance(Member member, Key<T> key, ContainerImpl container) {
/* 75 */     return new ExternalContext<>(member, key, container);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\ExternalContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */