/*    */ package com.opensymphony.xwork2.conversion.impl;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.lang.reflect.Member;
/*    */ import java.math.BigDecimal;
/*    */ import java.text.DateFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringConverter
/*    */   extends DefaultTypeConverter
/*    */ {
/*    */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class toType) {
/*    */     String result;
/* 43 */     if (value.getClass().isArray()) {
/* 44 */       int length = Array.getLength(value);
/* 45 */       List<String> converted = new ArrayList<>(length);
/*    */       
/* 47 */       for (int i = 0; i < length; i++) {
/* 48 */         Object o = Array.get(value, i);
/* 49 */         converted.add(convertToString(getLocale(context), o));
/*    */       } 
/*    */       
/* 52 */       result = StringUtils.join(converted, ", ");
/* 53 */     } else if (value.getClass().isAssignableFrom(Collection.class)) {
/* 54 */       Collection<?> colValue = (Collection)value;
/* 55 */       List<String> converted = new ArrayList<>(colValue.hashCode());
/*    */       
/* 57 */       for (Object o : colValue) {
/* 58 */         converted.add(convertToString(getLocale(context), o));
/*    */       }
/*    */       
/* 61 */       result = StringUtils.join(converted, ", ");
/* 62 */     } else if (value instanceof java.util.Date) {
/*    */       DateFormat df;
/* 64 */       if (value instanceof java.sql.Time) {
/* 65 */         df = DateFormat.getTimeInstance(2, getLocale(context));
/* 66 */       } else if (value instanceof java.sql.Timestamp) {
/* 67 */         SimpleDateFormat dfmt = (SimpleDateFormat)DateFormat.getDateTimeInstance(3, 2, getLocale(context));
/*    */ 
/*    */         
/* 70 */         df = new SimpleDateFormat(dfmt.toPattern() + MILLISECOND_FORMAT);
/*    */       } else {
/* 72 */         df = DateFormat.getDateInstance(3, getLocale(context));
/*    */       } 
/* 74 */       result = df.format(value);
/*    */     } else {
/* 76 */       result = convertToString(getLocale(context), value);
/*    */     } 
/*    */     
/* 79 */     return result;
/*    */   }
/*    */   
/*    */   protected String convertToString(Locale locale, Object value) {
/* 83 */     if (Number.class.isInstance(value)) {
/* 84 */       NumberFormat format = NumberFormat.getNumberInstance(locale);
/* 85 */       format.setGroupingUsed(false);
/*    */       
/* 87 */       Object fixedValue = value;
/* 88 */       if (BigDecimal.class.isInstance(value) || Double.class.isInstance(value) || Float.class.isInstance(value)) {
/* 89 */         format.setMaximumFractionDigits(2147483647);
/* 90 */         if (Float.class.isInstance(value)) {
/* 91 */           fixedValue = Double.valueOf(value.toString());
/*    */         }
/*    */       } 
/* 94 */       return format.format(fixedValue);
/*    */     } 
/* 96 */     return Objects.toString(value, null);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\StringConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */