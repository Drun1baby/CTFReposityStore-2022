/*     */ package com.opensymphony.xwork2.util.logging.jdk;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerUtils;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JdkLogger
/*     */   implements Logger
/*     */ {
/*     */   private Logger log;
/*     */   
/*     */   public JdkLogger(Logger log) {
/*  37 */     this.log = log;
/*     */   }
/*     */   
/*     */   public void error(String msg, String... args) {
/*  41 */     this.log.log(Level.SEVERE, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void error(String msg, Object... args) {
/*  45 */     this.log.log(Level.SEVERE, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void error(String msg, Throwable ex, String... args) {
/*  49 */     this.log.log(Level.SEVERE, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public void fatal(String msg, String... args) {
/*  53 */     this.log.log(Level.SEVERE, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void fatal(String msg, Throwable ex, String... args) {
/*  57 */     this.log.log(Level.SEVERE, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public void info(String msg, String... args) {
/*  61 */     this.log.log(Level.INFO, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void info(String msg, Throwable ex, String... args) {
/*  65 */     this.log.log(Level.INFO, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isInfoEnabled() {
/*  69 */     return this.log.isLoggable(Level.INFO);
/*     */   }
/*     */   
/*     */   public void warn(String msg, String... args) {
/*  73 */     this.log.log(Level.WARNING, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void warn(String msg, Object... args) {
/*  77 */     this.log.log(Level.WARNING, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void warn(String msg, Throwable ex, String... args) {
/*  81 */     this.log.log(Level.WARNING, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  85 */     return this.log.isLoggable(Level.FINE);
/*     */   }
/*     */   
/*     */   public void debug(String msg, String... args) {
/*  89 */     this.log.log(Level.FINE, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void debug(String msg, Object... args) {
/*  93 */     this.log.log(Level.FINE, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void debug(String msg, Throwable ex, String... args) {
/*  97 */     this.log.log(Level.FINE, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 101 */     return this.log.isLoggable(Level.FINEST);
/*     */   }
/*     */   
/*     */   public void trace(String msg, String... args) {
/* 105 */     this.log.log(Level.FINEST, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void trace(String msg, Object... args) {
/* 109 */     this.log.log(Level.FINEST, LoggerUtils.format(msg, args));
/*     */   }
/*     */   
/*     */   public void trace(String msg, Throwable ex, String... args) {
/* 113 */     this.log.log(Level.FINEST, LoggerUtils.format(msg, args), ex);
/*     */   }
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 117 */     return this.log.isLoggable(Level.SEVERE);
/*     */   }
/*     */   
/*     */   public boolean isFatalEnabled() {
/* 121 */     return this.log.isLoggable(Level.SEVERE);
/*     */   }
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 125 */     return this.log.isLoggable(Level.WARNING);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\jdk\JdkLogger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */