/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionConverter
/*     */   extends DefaultTypeConverter
/*     */ {
/*     */   private ObjectTypeDeterminer objectTypeDeterminer;
/*     */   
/*     */   @Inject
/*     */   public void setObjectTypeDeterminer(ObjectTypeDeterminer determiner) {
/*  39 */     this.objectTypeDeterminer = determiner;
/*     */   }
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object target, Member member, String propertyName, Object value, Class toType) {
/*     */     Collection<Object> result;
/*  44 */     Class<String> memberType = String.class;
/*     */     
/*  46 */     if (target != null) {
/*  47 */       memberType = this.objectTypeDeterminer.getElementClass(target.getClass(), propertyName, null);
/*     */       
/*  49 */       if (memberType == null) {
/*  50 */         memberType = String.class;
/*     */       }
/*     */     } 
/*     */     
/*  54 */     if (toType.isAssignableFrom(value.getClass())) {
/*     */       
/*  56 */       result = (Collection)value;
/*  57 */     } else if (value.getClass().isArray()) {
/*  58 */       Object[] objArray = (Object[])value;
/*  59 */       TypeConverter converter = getTypeConverter(context);
/*  60 */       result = createCollection(toType, memberType, objArray.length);
/*     */       
/*  62 */       for (Object anObjArray : objArray) {
/*  63 */         Object convertedValue = converter.convertValue(context, target, member, propertyName, anObjArray, memberType);
/*  64 */         if (!TypeConverter.NO_CONVERSION_POSSIBLE.equals(convertedValue)) {
/*  65 */           result.add(convertedValue);
/*     */         }
/*     */       } 
/*  68 */     } else if (Collection.class.isAssignableFrom(value.getClass())) {
/*  69 */       Collection col = (Collection)value;
/*  70 */       TypeConverter converter = getTypeConverter(context);
/*  71 */       result = createCollection(toType, memberType, col.size());
/*     */       
/*  73 */       for (Object aCol : col) {
/*  74 */         Object convertedValue = converter.convertValue(context, target, member, propertyName, aCol, memberType);
/*  75 */         if (!TypeConverter.NO_CONVERSION_POSSIBLE.equals(convertedValue)) {
/*  76 */           result.add(convertedValue);
/*     */         }
/*     */       } 
/*     */     } else {
/*  80 */       result = createCollection(toType, memberType, -1);
/*  81 */       TypeConverter converter = getTypeConverter(context);
/*  82 */       Object convertedValue = converter.convertValue(context, target, member, propertyName, value, memberType);
/*  83 */       if (!TypeConverter.NO_CONVERSION_POSSIBLE.equals(convertedValue)) {
/*  84 */         result.add(convertedValue);
/*     */       }
/*     */     } 
/*     */     
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection createCollection(Class<Set> toType, Class memberType, int size) {
/*     */     Collection result;
/*  94 */     if (toType == Set.class) {
/*  95 */       if (size > 0) {
/*  96 */         result = new HashSet(size);
/*     */       } else {
/*  98 */         result = new HashSet();
/*     */       } 
/* 100 */     } else if (toType == SortedSet.class) {
/* 101 */       result = new TreeSet();
/*     */     }
/* 103 */     else if (size > 0) {
/* 104 */       result = new XWorkList(memberType, size);
/*     */     } else {
/* 106 */       result = new XWorkList(memberType);
/*     */     } 
/*     */ 
/*     */     
/* 110 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\CollectionConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */