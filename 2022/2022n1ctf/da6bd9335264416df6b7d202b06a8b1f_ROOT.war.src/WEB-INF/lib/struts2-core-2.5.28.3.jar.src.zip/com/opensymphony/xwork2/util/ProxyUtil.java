/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.lang3.reflect.ConstructorUtils;
/*     */ import org.apache.commons.lang3.reflect.FieldUtils;
/*     */ import org.apache.commons.lang3.reflect.MethodUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyUtil
/*     */ {
/*     */   private static final String SPRING_ADVISED_CLASS_NAME = "org.springframework.aop.framework.Advised";
/*     */   private static final String SPRING_SPRINGPROXY_CLASS_NAME = "org.springframework.aop.SpringProxy";
/*     */   private static final String SPRING_SINGLETONTARGETSOURCE_CLASS_NAME = "org.springframework.aop.target.SingletonTargetSource";
/*     */   private static final String SPRING_TARGETCLASSAWARE_CLASS_NAME = "org.springframework.aop.TargetClassAware";
/*  42 */   private static final Map<Class<?>, Boolean> isProxyCache = new ConcurrentHashMap<>(256);
/*     */   
/*  44 */   private static final Map<Member, Boolean> isProxyMemberCache = new ConcurrentHashMap<>(256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> ultimateTargetClass(Object candidate) {
/*  56 */     Class<?> result = null;
/*  57 */     if (isSpringAopProxy(candidate)) {
/*  58 */       result = springUltimateTargetClass(candidate);
/*     */     }
/*  60 */     if (result == null) {
/*  61 */       result = candidate.getClass();
/*     */     }
/*     */     
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProxy(Object object) {
/*  72 */     Class<?> clazz = object.getClass();
/*  73 */     Boolean flag = isProxyCache.get(clazz);
/*  74 */     if (flag != null) {
/*  75 */       return flag.booleanValue();
/*     */     }
/*     */     
/*  78 */     boolean isProxy = isSpringAopProxy(object);
/*     */     
/*  80 */     isProxyCache.put(clazz, Boolean.valueOf(isProxy));
/*  81 */     return isProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProxyMember(Member member, Object object) {
/*  90 */     if (!Modifier.isStatic(member.getModifiers()) && !isProxy(object)) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     Boolean flag = isProxyMemberCache.get(member);
/*  95 */     if (flag != null) {
/*  96 */       return flag.booleanValue();
/*     */     }
/*     */     
/*  99 */     boolean isProxyMember = isSpringProxyMember(member);
/*     */     
/* 101 */     isProxyMemberCache.put(member, Boolean.valueOf(isProxyMember));
/* 102 */     return isProxyMember;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> springUltimateTargetClass(Object candidate) {
/* 114 */     Object current = candidate;
/* 115 */     Class<?> result = null;
/* 116 */     while (null != current && implementsInterface(current.getClass(), "org.springframework.aop.TargetClassAware")) {
/*     */       try {
/* 118 */         result = (Class)MethodUtils.invokeMethod(current, "getTargetClass");
/* 119 */       } catch (Throwable throwable) {}
/*     */       
/* 121 */       current = getSingletonTarget(current);
/*     */     } 
/* 123 */     if (result == null) {
/* 124 */       Class<?> clazz = candidate.getClass();
/* 125 */       result = isCglibProxyClass(clazz) ? clazz.getSuperclass() : candidate.getClass();
/*     */     } 
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSpringAopProxy(Object object) {
/* 135 */     Class<?> clazz = object.getClass();
/* 136 */     return (implementsInterface(clazz, "org.springframework.aop.SpringProxy") && (Proxy.isProxyClass(clazz) || isCglibProxyClass(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSpringProxyMember(Member member) {
/*     */     try {
/* 146 */       Class<?> clazz = ClassLoaderUtil.loadClass("org.springframework.aop.framework.Advised", ProxyUtil.class);
/* 147 */       if (hasMember(clazz, member))
/* 148 */         return true; 
/* 149 */       clazz = ClassLoaderUtil.loadClass("org.springframework.aop.TargetClassAware", ProxyUtil.class);
/* 150 */       if (hasMember(clazz, member))
/* 151 */         return true; 
/* 152 */       clazz = ClassLoaderUtil.loadClass("org.springframework.aop.SpringProxy", ProxyUtil.class);
/* 153 */       if (hasMember(clazz, member))
/* 154 */         return true; 
/* 155 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getSingletonTarget(Object candidate) {
/*     */     try {
/* 169 */       if (implementsInterface(candidate.getClass(), "org.springframework.aop.framework.Advised")) {
/* 170 */         Object targetSource = MethodUtils.invokeMethod(candidate, "getTargetSource");
/* 171 */         if (implementsInterface(targetSource.getClass(), "org.springframework.aop.target.SingletonTargetSource")) {
/* 172 */           return MethodUtils.invokeMethod(targetSource, "getTarget");
/*     */         }
/*     */       } 
/* 175 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isCglibProxyClass(Class<?> clazz) {
/* 186 */     return (clazz != null && clazz.getName().contains("$$"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean implementsInterface(Class<?> clazz, String ifaceClassName) {
/*     */     try {
/* 196 */       Class<?> ifaceClass = ClassLoaderUtil.loadClass(ifaceClassName, ProxyUtil.class);
/* 197 */       return ifaceClass.isAssignableFrom(clazz);
/* 198 */     } catch (ClassNotFoundException e) {
/* 199 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasMember(Class<?> clazz, Member member) {
/* 209 */     if (member instanceof Method) {
/* 210 */       return (null != MethodUtils.getMatchingMethod(clazz, member.getName(), ((Method)member).getParameterTypes()));
/*     */     }
/* 212 */     if (member instanceof java.lang.reflect.Field) {
/* 213 */       return (null != FieldUtils.getField(clazz, member.getName(), true));
/*     */     }
/* 215 */     if (member instanceof Constructor) {
/* 216 */       return (null != ConstructorUtils.getMatchingAccessibleConstructor(clazz, ((Constructor)member).getParameterTypes()));
/*     */     }
/*     */     
/* 219 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ProxyUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */