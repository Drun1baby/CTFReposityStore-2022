/*      */ package com.opensymphony.xwork2.config.providers;
/*      */ 
/*      */ import com.opensymphony.xwork2.FileManager;
/*      */ import com.opensymphony.xwork2.FileManagerFactory;
/*      */ import com.opensymphony.xwork2.ObjectFactory;
/*      */ import com.opensymphony.xwork2.XWorkException;
/*      */ import com.opensymphony.xwork2.config.Configuration;
/*      */ import com.opensymphony.xwork2.config.ConfigurationException;
/*      */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*      */ import com.opensymphony.xwork2.config.ConfigurationUtil;
/*      */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*      */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
/*      */ import com.opensymphony.xwork2.config.entities.InterceptorConfig;
/*      */ import com.opensymphony.xwork2.config.entities.InterceptorLocator;
/*      */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*      */ import com.opensymphony.xwork2.config.entities.InterceptorStackConfig;
/*      */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*      */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*      */ import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
/*      */ import com.opensymphony.xwork2.config.entities.UnknownHandlerConfig;
/*      */ import com.opensymphony.xwork2.config.impl.LocatableFactory;
/*      */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*      */ import com.opensymphony.xwork2.inject.Factory;
/*      */ import com.opensymphony.xwork2.inject.Inject;
/*      */ import com.opensymphony.xwork2.inject.Scope;
/*      */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*      */ import com.opensymphony.xwork2.util.ClassPathFinder;
/*      */ import com.opensymphony.xwork2.util.DomHelper;
/*      */ import com.opensymphony.xwork2.util.TextParseUtil;
/*      */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*      */ import com.opensymphony.xwork2.util.location.Location;
/*      */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.lang3.BooleanUtils;
/*      */ import org.apache.commons.lang3.StringUtils;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XmlConfigurationProvider
/*      */   implements ConfigurationProvider
/*      */ {
/*   89 */   private static final Logger LOG = LogManager.getLogger(XmlConfigurationProvider.class);
/*      */   
/*      */   private List<Document> documents;
/*      */   
/*      */   private Set<String> includedFileNames;
/*      */   private String configFileName;
/*      */   private ObjectFactory objectFactory;
/*   96 */   private final Set<String> loadedFileUrls = new HashSet<>();
/*      */   private boolean errorIfMissing;
/*      */   private Map<String, String> dtdMappings;
/*      */   private Configuration configuration;
/*      */   private boolean throwExceptionOnDuplicateBeans = true;
/*  101 */   private final Map<String, Element> declaredPackages = new HashMap<>();
/*      */   
/*      */   private FileManager fileManager;
/*      */   private ValueSubstitutor valueSubstitutor;
/*      */   
/*      */   public XmlConfigurationProvider() {
/*  107 */     this("xwork.xml", true);
/*      */   }
/*      */   
/*      */   public XmlConfigurationProvider(String filename) {
/*  111 */     this(filename, true);
/*      */   }
/*      */   
/*      */   public XmlConfigurationProvider(String filename, boolean errorIfMissing) {
/*  115 */     this.configFileName = filename;
/*  116 */     this.errorIfMissing = errorIfMissing;
/*      */     
/*  118 */     Map<String, String> mappings = new HashMap<>();
/*  119 */     mappings.put("-//Apache Struts//XWork 2.5//EN", "xwork-2.5.dtd");
/*  120 */     mappings.put("-//Apache Struts//XWork 2.3//EN", "xwork-2.3.dtd");
/*  121 */     mappings.put("-//Apache Struts//XWork 2.1.3//EN", "xwork-2.1.3.dtd");
/*  122 */     mappings.put("-//Apache Struts//XWork 2.1//EN", "xwork-2.1.dtd");
/*  123 */     mappings.put("-//Apache Struts//XWork 2.0//EN", "xwork-2.0.dtd");
/*  124 */     mappings.put("-//Apache Struts//XWork 1.1.1//EN", "xwork-1.1.1.dtd");
/*  125 */     mappings.put("-//Apache Struts//XWork 1.1//EN", "xwork-1.1.dtd");
/*  126 */     mappings.put("-//Apache Struts//XWork 1.0//EN", "xwork-1.0.dtd");
/*  127 */     setDtdMappings(mappings);
/*      */   }
/*      */   
/*      */   public void setThrowExceptionOnDuplicateBeans(boolean val) {
/*  131 */     this.throwExceptionOnDuplicateBeans = val;
/*      */   }
/*      */   
/*      */   public void setDtdMappings(Map<String, String> mappings) {
/*  135 */     this.dtdMappings = Collections.unmodifiableMap(mappings);
/*      */   }
/*      */   
/*      */   @Inject
/*      */   public void setObjectFactory(ObjectFactory objectFactory) {
/*  140 */     this.objectFactory = objectFactory;
/*      */   }
/*      */   
/*      */   @Inject
/*      */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/*  145 */     this.fileManager = fileManagerFactory.getFileManager();
/*      */   }
/*      */   
/*      */   @Inject(required = false)
/*      */   public void setValueSubstitutor(ValueSubstitutor valueSubstitutor) {
/*  150 */     this.valueSubstitutor = valueSubstitutor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> getDtdMappings() {
/*  159 */     return this.dtdMappings;
/*      */   }
/*      */   
/*      */   public void init(Configuration configuration) {
/*  163 */     this.configuration = configuration;
/*  164 */     this.includedFileNames = configuration.getLoadedFileNames();
/*  165 */     loadDocuments(this.configFileName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void destroy() {}
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  173 */     if (this == o) {
/*  174 */       return true;
/*      */     }
/*      */     
/*  177 */     if (!(o instanceof XmlConfigurationProvider)) {
/*  178 */       return false;
/*      */     }
/*      */     
/*  181 */     XmlConfigurationProvider xmlConfigurationProvider = (XmlConfigurationProvider)o;
/*      */     
/*  183 */     if ((this.configFileName != null) ? !this.configFileName.equals(xmlConfigurationProvider.configFileName) : (xmlConfigurationProvider.configFileName != null)) {
/*  184 */       return false;
/*      */     }
/*      */     
/*  187 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  192 */     return (this.configFileName != null) ? this.configFileName.hashCode() : 0;
/*      */   }
/*      */   
/*      */   private void loadDocuments(String configFileName) {
/*      */     try {
/*  197 */       this.loadedFileUrls.clear();
/*  198 */       this.documents = loadConfigurationFiles(configFileName, null);
/*  199 */     } catch (ConfigurationException e) {
/*  200 */       throw e;
/*  201 */     } catch (Exception e) {
/*  202 */       throw new ConfigurationException("Error loading configuration file " + configFileName, e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void register(ContainerBuilder containerBuilder, LocatableProperties props) throws ConfigurationException {
/*  207 */     LOG.trace("Parsing configuration file [{}]", this.configFileName);
/*  208 */     Map<String, Node> loadedBeans = new HashMap<>();
/*  209 */     for (Document doc : this.documents) {
/*  210 */       Element rootElement = doc.getDocumentElement();
/*  211 */       NodeList children = rootElement.getChildNodes();
/*  212 */       int childSize = children.getLength();
/*      */       
/*  214 */       for (int i = 0; i < childSize; i++) {
/*  215 */         Node childNode = children.item(i);
/*      */         
/*  217 */         if (childNode instanceof Element) {
/*  218 */           Element child = (Element)childNode;
/*      */           
/*  220 */           String nodeName = child.getNodeName();
/*      */           
/*  222 */           if ("bean".equals(nodeName)) {
/*  223 */             String type = child.getAttribute("type");
/*  224 */             String name = child.getAttribute("name");
/*  225 */             String impl = child.getAttribute("class");
/*  226 */             String onlyStatic = child.getAttribute("static");
/*  227 */             String scopeStr = child.getAttribute("scope");
/*  228 */             boolean optional = "true".equals(child.getAttribute("optional"));
/*  229 */             Scope scope = Scope.SINGLETON;
/*  230 */             if ("prototype".equals(scopeStr)) {
/*  231 */               scope = Scope.PROTOTYPE;
/*  232 */             } else if ("request".equals(scopeStr)) {
/*  233 */               scope = Scope.REQUEST;
/*  234 */             } else if ("session".equals(scopeStr)) {
/*  235 */               scope = Scope.SESSION;
/*  236 */             } else if ("singleton".equals(scopeStr)) {
/*  237 */               scope = Scope.SINGLETON;
/*  238 */             } else if ("thread".equals(scopeStr)) {
/*  239 */               scope = Scope.THREAD;
/*      */             } 
/*      */             
/*  242 */             if (StringUtils.isEmpty(name)) {
/*  243 */               name = "default";
/*      */             }
/*      */             
/*      */             try {
/*  247 */               Class classImpl = ClassLoaderUtil.loadClass(impl, getClass());
/*  248 */               Class classType = classImpl;
/*  249 */               if (StringUtils.isNotEmpty(type)) {
/*  250 */                 classType = ClassLoaderUtil.loadClass(type, getClass());
/*      */               }
/*  252 */               if ("true".equals(onlyStatic)) {
/*      */                 
/*  254 */                 classImpl.getDeclaredClasses();
/*  255 */                 containerBuilder.injectStatics(new Class[] { classImpl });
/*      */               } else {
/*  257 */                 if (containerBuilder.contains(classType, name)) {
/*  258 */                   Location loc = LocationUtils.getLocation(loadedBeans.get(classType.getName() + name));
/*  259 */                   if (this.throwExceptionOnDuplicateBeans) {
/*  260 */                     throw new ConfigurationException("Bean type " + classType + " with the name " + name + " has already been loaded by " + loc, child);
/*      */                   }
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  266 */                 classImpl.getDeclaredConstructors();
/*      */                 
/*  268 */                 LOG.debug("Loaded type: {} name: {} impl: {}", type, name, impl);
/*  269 */                 containerBuilder.factory(classType, name, (Factory)new LocatableFactory(name, classType, classImpl, scope, childNode), scope);
/*      */               } 
/*  271 */               loadedBeans.put(classType.getName() + name, child);
/*  272 */             } catch (Throwable ex) {
/*  273 */               if (!optional) {
/*  274 */                 throw new ConfigurationException("Unable to load bean: type:" + type + " class:" + impl, ex, childNode);
/*      */               }
/*  276 */               LOG.debug("Unable to load optional class: {}", impl);
/*      */             }
/*      */           
/*  279 */           } else if ("constant".equals(nodeName)) {
/*  280 */             String name = child.getAttribute("name");
/*  281 */             String value = child.getAttribute("value");
/*      */             
/*  283 */             if (this.valueSubstitutor != null) {
/*  284 */               LOG.debug("Substituting value [{}] using [{}]", value, this.valueSubstitutor.getClass().getName());
/*  285 */               value = this.valueSubstitutor.substitute(value);
/*      */             } 
/*      */             
/*  288 */             props.setProperty(name, value, childNode);
/*  289 */           } else if (nodeName.equals("unknown-handler-stack")) {
/*  290 */             List<UnknownHandlerConfig> unknownHandlerStack = new ArrayList<>();
/*  291 */             NodeList unknownHandlers = child.getElementsByTagName("unknown-handler-ref");
/*  292 */             int unknownHandlersSize = unknownHandlers.getLength();
/*      */             
/*  294 */             for (int k = 0; k < unknownHandlersSize; k++) {
/*  295 */               Element unknownHandler = (Element)unknownHandlers.item(k);
/*  296 */               Location location = LocationUtils.getLocation(unknownHandler);
/*  297 */               unknownHandlerStack.add(new UnknownHandlerConfig(unknownHandler.getAttribute("name"), location));
/*      */             } 
/*      */             
/*  300 */             if (!unknownHandlerStack.isEmpty())
/*  301 */               this.configuration.setUnknownHandlerStack(unknownHandlerStack); 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void loadPackages() throws ConfigurationException {
/*  309 */     List<Element> reloads = new ArrayList<>();
/*  310 */     verifyPackageStructure();
/*      */     
/*  312 */     for (Document doc : this.documents) {
/*  313 */       Element rootElement = doc.getDocumentElement();
/*  314 */       NodeList children = rootElement.getChildNodes();
/*  315 */       int childSize = children.getLength();
/*      */       
/*  317 */       for (int i = 0; i < childSize; i++) {
/*  318 */         Node childNode = children.item(i);
/*      */         
/*  320 */         if (childNode instanceof Element) {
/*  321 */           Element child = (Element)childNode;
/*      */           
/*  323 */           String nodeName = child.getNodeName();
/*      */           
/*  325 */           if ("package".equals(nodeName)) {
/*  326 */             PackageConfig cfg = addPackage(child);
/*  327 */             if (cfg.isNeedsRefresh()) {
/*  328 */               reloads.add(child);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  333 */       loadExtraConfiguration(doc);
/*      */     } 
/*      */     
/*  336 */     if (reloads.size() > 0) {
/*  337 */       reloadRequiredPackages(reloads);
/*      */     }
/*      */     
/*  340 */     for (Document doc : this.documents) {
/*  341 */       loadExtraConfiguration(doc);
/*      */     }
/*      */     
/*  344 */     this.documents.clear();
/*  345 */     this.declaredPackages.clear();
/*  346 */     this.configuration = null;
/*      */   }
/*      */   
/*      */   private void verifyPackageStructure() {
/*  350 */     DirectedGraph<String> graph = new DirectedGraph<>();
/*      */     
/*  352 */     for (Document doc : this.documents) {
/*  353 */       Element rootElement = doc.getDocumentElement();
/*  354 */       NodeList children = rootElement.getChildNodes();
/*  355 */       int childSize = children.getLength();
/*  356 */       for (int i = 0; i < childSize; i++) {
/*  357 */         Node childNode = children.item(i);
/*  358 */         if (childNode instanceof Element) {
/*  359 */           Element child = (Element)childNode;
/*      */           
/*  361 */           String nodeName = child.getNodeName();
/*      */           
/*  363 */           if ("package".equals(nodeName)) {
/*  364 */             String packageName = child.getAttribute("name");
/*  365 */             this.declaredPackages.put(packageName, child);
/*  366 */             graph.addNode(packageName);
/*      */             
/*  368 */             String extendsAttribute = child.getAttribute("extends");
/*  369 */             List<String> parents = ConfigurationUtil.buildParentListFromString(extendsAttribute);
/*  370 */             for (String parent : parents) {
/*  371 */               graph.addNode(parent);
/*  372 */               graph.addEdge(packageName, parent);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  379 */     CycleDetector<String> detector = new CycleDetector<>(graph);
/*  380 */     if (detector.containsCycle()) {
/*  381 */       StringBuilder builder = new StringBuilder("The following packages participate in cycles:");
/*  382 */       for (String packageName : detector.getVerticesInCycles()) {
/*  383 */         builder.append(" ");
/*  384 */         builder.append(packageName);
/*      */       } 
/*  386 */       throw new ConfigurationException(builder.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void reloadRequiredPackages(List<Element> reloads) {
/*  391 */     if (reloads.size() > 0) {
/*  392 */       List<Element> result = new ArrayList<>();
/*  393 */       for (Element pkg : reloads) {
/*  394 */         PackageConfig cfg = addPackage(pkg);
/*  395 */         if (cfg.isNeedsRefresh()) {
/*  396 */           result.add(pkg);
/*      */         }
/*      */       } 
/*  399 */       if (result.size() > 0 && result.size() != reloads.size()) {
/*  400 */         reloadRequiredPackages(result);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  405 */       if (result.size() > 0) {
/*  406 */         for (Element rp : result) {
/*  407 */           String parent = rp.getAttribute("extends");
/*  408 */           if (parent != null) {
/*  409 */             List<PackageConfig> parents = ConfigurationUtil.buildParentsFromString(this.configuration, parent);
/*  410 */             if (parents != null && parents.size() <= 0) {
/*  411 */               LOG.error("Unable to find parent packages {}", parent);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needsReload() {
/*  427 */     for (String url : this.loadedFileUrls) {
/*  428 */       if (this.fileManager.fileNeedsReloading(url)) {
/*  429 */         return true;
/*      */       }
/*      */     } 
/*  432 */     return false;
/*      */   }
/*      */   protected void addAction(Element actionElement, PackageConfig.Builder packageContext) throws ConfigurationException {
/*      */     Map<String, ResultConfig> results;
/*  436 */     String name = actionElement.getAttribute("name");
/*  437 */     String className = actionElement.getAttribute("class");
/*      */     
/*  439 */     String methodName = StringUtils.trimToNull(actionElement.getAttribute("method"));
/*  440 */     Location location = DomHelper.getLocationObject(actionElement);
/*      */     
/*  442 */     if (location == null) {
/*  443 */       LOG.warn("Location null for {}", className);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  448 */     if (!StringUtils.isEmpty(className))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  457 */       if (!verifyAction(className, name, location)) {
/*  458 */         LOG.error("Unable to verify action [{}] with class [{}], from [{}]", name, className, location);
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/*  465 */       results = buildResults(actionElement, packageContext);
/*  466 */     } catch (ConfigurationException e) {
/*  467 */       throw new ConfigurationException("Error building results for action " + name + " in namespace " + packageContext.getNamespace(), e, actionElement);
/*      */     } 
/*      */     
/*  470 */     List<InterceptorMapping> interceptorList = buildInterceptorList(actionElement, packageContext);
/*      */     
/*  472 */     List<ExceptionMappingConfig> exceptionMappings = buildExceptionMappings(actionElement, packageContext);
/*      */     
/*  474 */     Set<String> allowedMethods = buildAllowedMethods(actionElement, packageContext);
/*      */     
/*  476 */     ActionConfig actionConfig = (new ActionConfig.Builder(packageContext.getName(), name, className)).methodName(methodName).addResultConfigs(results).addInterceptors(interceptorList).addExceptionMappings(exceptionMappings).addParams(XmlHelper.getParams(actionElement)).setStrictMethodInvocation(packageContext.isStrictMethodInvocation()).addAllowedMethod(allowedMethods).location(location).build();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  486 */     packageContext.addActionConfig(name, actionConfig);
/*      */     
/*  488 */     LOG.debug("Loaded {}{} in '{}' package: {}", StringUtils.isNotEmpty(packageContext.getNamespace()) ? (packageContext.getNamespace() + "/") : "", name, packageContext.getName(), actionConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean verifyAction(String className, String name, Location loc) {
/*  494 */     if (className.contains("{")) {
/*  495 */       LOG.debug("Action class [{}] contains a wildcard replacement value, so it can't be verified", className);
/*  496 */       return true;
/*      */     } 
/*      */     try {
/*  499 */       if (this.objectFactory.isNoArgConstructorRequired()) {
/*  500 */         Class clazz = this.objectFactory.getClassInstance(className);
/*  501 */         if (!Modifier.isPublic(clazz.getModifiers())) {
/*  502 */           throw new ConfigurationException("Action class [" + className + "] is not public", loc);
/*      */         }
/*  504 */         clazz.getConstructor(new Class[0]);
/*      */       } 
/*  506 */     } catch (ClassNotFoundException e) {
/*  507 */       LOG.debug("Class not found for action [{}]", className, e);
/*  508 */       throw new ConfigurationException("Action class [" + className + "] not found", loc);
/*  509 */     } catch (NoSuchMethodException e) {
/*  510 */       LOG.debug("No constructor found for action [{}]", className, e);
/*  511 */       throw new ConfigurationException("Action class [" + className + "] does not have a public no-arg constructor", e, loc);
/*  512 */     } catch (RuntimeException ex) {
/*      */       
/*  514 */       LOG.info("Unable to verify action class [{}] exists at initialization", className);
/*  515 */       LOG.debug("Action verification cause", ex);
/*  516 */     } catch (Exception ex) {
/*      */       
/*  518 */       LOG.debug("Unable to verify action class [{}]", className, ex);
/*  519 */       throw new ConfigurationException(ex, loc);
/*      */     } 
/*  521 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PackageConfig addPackage(Element packageElement) throws ConfigurationException {
/*  532 */     String packageName = packageElement.getAttribute("name");
/*  533 */     PackageConfig packageConfig = this.configuration.getPackageConfig(packageName);
/*  534 */     if (packageConfig != null) {
/*  535 */       LOG.debug("Package [{}] already loaded, skipping re-loading it and using existing PackageConfig [{}]", packageName, packageConfig);
/*  536 */       return packageConfig;
/*      */     } 
/*      */     
/*  539 */     PackageConfig.Builder newPackage = buildPackageContext(packageElement);
/*      */     
/*  541 */     if (newPackage.isNeedsRefresh()) {
/*  542 */       return newPackage.build();
/*      */     }
/*      */     
/*  545 */     LOG.debug("Loaded {}", newPackage);
/*      */ 
/*      */     
/*  548 */     addResultTypes(newPackage, packageElement);
/*      */ 
/*      */     
/*  551 */     loadInterceptors(newPackage, packageElement);
/*      */ 
/*      */     
/*  554 */     loadDefaultInterceptorRef(newPackage, packageElement);
/*      */ 
/*      */     
/*  557 */     loadDefaultClassRef(newPackage, packageElement);
/*      */ 
/*      */     
/*  560 */     loadGlobalResults(newPackage, packageElement);
/*      */     
/*  562 */     loadGlobalAllowedMethods(newPackage, packageElement);
/*      */ 
/*      */     
/*  565 */     loadGlobalExceptionMappings(newPackage, packageElement);
/*      */ 
/*      */     
/*  568 */     NodeList actionList = packageElement.getElementsByTagName("action");
/*      */     
/*  570 */     for (int i = 0; i < actionList.getLength(); i++) {
/*  571 */       Element actionElement = (Element)actionList.item(i);
/*  572 */       addAction(actionElement, newPackage);
/*      */     } 
/*      */ 
/*      */     
/*  576 */     loadDefaultActionRef(newPackage, packageElement);
/*      */     
/*  578 */     PackageConfig cfg = newPackage.build();
/*  579 */     this.configuration.addPackageConfig(cfg.getName(), cfg);
/*  580 */     return cfg;
/*      */   }
/*      */   
/*      */   protected void addResultTypes(PackageConfig.Builder packageContext, Element element) {
/*  584 */     NodeList resultTypeList = element.getElementsByTagName("result-type");
/*      */     
/*  586 */     for (int i = 0; i < resultTypeList.getLength(); i++) {
/*  587 */       Element resultTypeElement = (Element)resultTypeList.item(i);
/*  588 */       String name = resultTypeElement.getAttribute("name");
/*  589 */       String className = resultTypeElement.getAttribute("class");
/*  590 */       String def = resultTypeElement.getAttribute("default");
/*      */       
/*  592 */       Location loc = DomHelper.getLocationObject(resultTypeElement);
/*      */       
/*  594 */       Class clazz = verifyResultType(className, loc);
/*  595 */       if (clazz != null) {
/*  596 */         String paramName = null;
/*      */         try {
/*  598 */           paramName = (String)clazz.getField("DEFAULT_PARAM").get(null);
/*  599 */         } catch (Throwable t) {
/*  600 */           LOG.debug("The result type [{}] doesn't have a default param [DEFAULT_PARAM] defined!", className, t);
/*      */         } 
/*  602 */         ResultTypeConfig.Builder resultType = (new ResultTypeConfig.Builder(name, className)).defaultResultParam(paramName).location(DomHelper.getLocationObject(resultTypeElement));
/*      */ 
/*      */         
/*  605 */         Map<String, String> params = XmlHelper.getParams(resultTypeElement);
/*      */         
/*  607 */         if (!params.isEmpty()) {
/*  608 */           resultType.addParams(params);
/*      */         }
/*  610 */         packageContext.addResultTypeConfig(resultType.build());
/*      */ 
/*      */         
/*  613 */         if (BooleanUtils.toBoolean(def)) {
/*  614 */           packageContext.defaultResultType(name);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Class verifyResultType(String className, Location loc) {
/*      */     try {
/*  622 */       return this.objectFactory.getClassInstance(className);
/*  623 */     } catch (ClassNotFoundException|NoClassDefFoundError e) {
/*  624 */       LOG.warn("Result class [{}] doesn't exist ({}) at {}, ignoring", className, e.getClass().getSimpleName(), loc, e);
/*      */ 
/*      */       
/*  627 */       return null;
/*      */     } 
/*      */   }
/*      */   protected List<InterceptorMapping> buildInterceptorList(Element element, PackageConfig.Builder context) throws ConfigurationException {
/*  631 */     List<InterceptorMapping> interceptorList = new ArrayList<>();
/*  632 */     NodeList interceptorRefList = element.getElementsByTagName("interceptor-ref");
/*      */     
/*  634 */     for (int i = 0; i < interceptorRefList.getLength(); i++) {
/*  635 */       Element interceptorRefElement = (Element)interceptorRefList.item(i);
/*      */       
/*  637 */       if (interceptorRefElement.getParentNode().equals(element) || interceptorRefElement.getParentNode().getNodeName().equals(element.getNodeName())) {
/*  638 */         List<InterceptorMapping> interceptors = lookupInterceptorReference(context, interceptorRefElement);
/*  639 */         interceptorList.addAll(interceptors);
/*      */       } 
/*      */     } 
/*      */     
/*  643 */     return interceptorList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PackageConfig.Builder buildPackageContext(Element packageElement) {
/*  660 */     String parent = packageElement.getAttribute("extends");
/*  661 */     String abstractVal = packageElement.getAttribute("abstract");
/*  662 */     boolean isAbstract = Boolean.parseBoolean(abstractVal);
/*  663 */     String name = StringUtils.defaultString(packageElement.getAttribute("name"));
/*  664 */     String namespace = StringUtils.defaultString(packageElement.getAttribute("namespace"));
/*      */ 
/*      */     
/*  667 */     boolean strictDMI = true;
/*  668 */     if (packageElement.hasAttribute("strict-method-invocation")) {
/*  669 */       strictDMI = Boolean.parseBoolean(packageElement.getAttribute("strict-method-invocation"));
/*      */     }
/*      */     
/*  672 */     PackageConfig.Builder cfg = (new PackageConfig.Builder(name)).namespace(namespace).isAbstract(isAbstract).strictMethodInvocation(strictDMI).location(DomHelper.getLocationObject(packageElement));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  678 */     if (StringUtils.isNotEmpty(StringUtils.defaultString(parent))) {
/*  679 */       List<PackageConfig> parents = new ArrayList<>();
/*  680 */       for (String parentPackageName : ConfigurationUtil.buildParentListFromString(parent)) {
/*  681 */         if (this.configuration.getPackageConfigNames().contains(parentPackageName)) {
/*  682 */           parents.add(this.configuration.getPackageConfig(parentPackageName)); continue;
/*  683 */         }  if (this.declaredPackages.containsKey(parentPackageName)) {
/*  684 */           if (this.configuration.getPackageConfig(parentPackageName) == null) {
/*  685 */             addPackage(this.declaredPackages.get(parentPackageName));
/*      */           }
/*  687 */           parents.add(this.configuration.getPackageConfig(parentPackageName)); continue;
/*      */         } 
/*  689 */         throw new ConfigurationException("Parent package is not defined: " + parentPackageName);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  694 */       if (parents.size() <= 0) {
/*  695 */         cfg.needsRefresh(true);
/*      */       } else {
/*  697 */         cfg.addParents(parents);
/*      */       } 
/*      */     } 
/*      */     
/*  701 */     return cfg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, ResultConfig> buildResults(Element element, PackageConfig.Builder packageContext) {
/*  713 */     NodeList resultEls = element.getElementsByTagName("result");
/*      */     
/*  715 */     Map<String, ResultConfig> results = new LinkedHashMap<>();
/*      */     
/*  717 */     for (int i = 0; i < resultEls.getLength(); i++) {
/*  718 */       Element resultElement = (Element)resultEls.item(i);
/*      */       
/*  720 */       if (resultElement.getParentNode().equals(element) || resultElement.getParentNode().getNodeName().equals(element.getNodeName())) {
/*  721 */         String resultName = resultElement.getAttribute("name");
/*  722 */         String resultType = resultElement.getAttribute("type");
/*      */ 
/*      */         
/*  725 */         if (StringUtils.isEmpty(resultName)) {
/*  726 */           resultName = "success";
/*      */         }
/*      */ 
/*      */         
/*  730 */         if (StringUtils.isEmpty(resultType)) {
/*  731 */           resultType = packageContext.getFullDefaultResultType();
/*      */ 
/*      */           
/*  734 */           if (StringUtils.isEmpty(resultType))
/*      */           {
/*  736 */             throw new ConfigurationException("No result type specified for result named '" + resultName + "', perhaps the parent package does not specify the result type?", resultElement);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  742 */         ResultTypeConfig config = packageContext.getResultType(resultType);
/*      */         
/*  744 */         if (config == null) {
/*  745 */           throw new ConfigurationException("There is no result type defined for type '" + resultType + "' mapped with name '" + resultName + "'." + "  Did you mean '" + guessResultType(resultType) + "'?", resultElement);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  750 */         String resultClass = config.getClassName();
/*      */ 
/*      */         
/*  753 */         if (resultClass == null) {
/*  754 */           throw new ConfigurationException("Result type '" + resultType + "' is invalid");
/*      */         }
/*      */         
/*  757 */         Map<String, String> resultParams = XmlHelper.getParams(resultElement);
/*      */         
/*  759 */         if (resultParams.size() == 0)
/*      */         {
/*      */           
/*  762 */           if (resultElement.getChildNodes().getLength() >= 1) {
/*  763 */             resultParams = new LinkedHashMap<>();
/*      */             
/*  765 */             String paramName = config.getDefaultResultParam();
/*  766 */             if (paramName != null) {
/*  767 */               StringBuilder paramValue = new StringBuilder();
/*  768 */               for (int j = 0; j < resultElement.getChildNodes().getLength(); j++) {
/*  769 */                 if (resultElement.getChildNodes().item(j).getNodeType() == 3) {
/*  770 */                   String str = resultElement.getChildNodes().item(j).getNodeValue();
/*  771 */                   if (str != null) {
/*  772 */                     paramValue.append(str);
/*      */                   }
/*      */                 } 
/*      */               } 
/*  776 */               String val = paramValue.toString().trim();
/*  777 */               if (val.length() > 0) {
/*  778 */                 resultParams.put(paramName, val);
/*      */               }
/*      */             } else {
/*  781 */               LOG.debug("No default parameter defined for result [{}] of type [{}] ", config.getName(), config.getClassName());
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  787 */         Map<String, String> params = new LinkedHashMap<>();
/*  788 */         Map<String, String> configParams = config.getParams();
/*  789 */         if (configParams != null) {
/*  790 */           params.putAll(configParams);
/*      */         }
/*  792 */         params.putAll(resultParams);
/*      */         
/*  794 */         Set<String> resultNamesSet = TextParseUtil.commaDelimitedStringToSet(resultName);
/*  795 */         if (resultNamesSet.isEmpty()) {
/*  796 */           resultNamesSet.add(resultName);
/*      */         }
/*      */         
/*  799 */         for (String name : resultNamesSet) {
/*  800 */           ResultConfig resultConfig = (new ResultConfig.Builder(name, resultClass)).addParams(params).location(DomHelper.getLocationObject(element)).build();
/*      */ 
/*      */ 
/*      */           
/*  804 */           results.put(resultConfig.getName(), resultConfig);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  809 */     return results;
/*      */   }
/*      */   
/*      */   protected String guessResultType(String type) {
/*  813 */     StringBuilder sb = null;
/*  814 */     if (type != null) {
/*  815 */       sb = new StringBuilder();
/*  816 */       boolean capNext = false;
/*  817 */       for (int x = 0; x < type.length(); x++) {
/*  818 */         char c = type.charAt(x);
/*  819 */         if (c == '-') {
/*  820 */           capNext = true;
/*      */         } else {
/*  822 */           if (Character.isLowerCase(c) && capNext) {
/*  823 */             c = Character.toUpperCase(c);
/*  824 */             capNext = false;
/*      */           } 
/*  826 */           sb.append(c);
/*      */         } 
/*      */       } 
/*  829 */     }  return (sb != null) ? sb.toString() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<ExceptionMappingConfig> buildExceptionMappings(Element element, PackageConfig.Builder packageContext) {
/*  841 */     NodeList exceptionMappingEls = element.getElementsByTagName("exception-mapping");
/*      */     
/*  843 */     List<ExceptionMappingConfig> exceptionMappings = new ArrayList<>();
/*      */     
/*  845 */     for (int i = 0; i < exceptionMappingEls.getLength(); i++) {
/*  846 */       Element ehElement = (Element)exceptionMappingEls.item(i);
/*      */       
/*  848 */       if (ehElement.getParentNode().equals(element) || ehElement.getParentNode().getNodeName().equals(element.getNodeName())) {
/*  849 */         String emName = ehElement.getAttribute("name");
/*  850 */         String exceptionClassName = ehElement.getAttribute("exception");
/*  851 */         String exceptionResult = ehElement.getAttribute("result");
/*      */         
/*  853 */         Map<String, String> params = XmlHelper.getParams(ehElement);
/*      */         
/*  855 */         if (StringUtils.isEmpty(emName)) {
/*  856 */           emName = exceptionResult;
/*      */         }
/*      */         
/*  859 */         ExceptionMappingConfig ehConfig = (new ExceptionMappingConfig.Builder(emName, exceptionClassName, exceptionResult)).addParams(params).location(DomHelper.getLocationObject(ehElement)).build();
/*      */ 
/*      */ 
/*      */         
/*  863 */         exceptionMappings.add(ehConfig);
/*      */       } 
/*      */     } 
/*      */     
/*  867 */     return exceptionMappings;
/*      */   }
/*      */   protected Set<String> buildAllowedMethods(Element element, PackageConfig.Builder packageContext) {
/*      */     Set<String> allowedMethods;
/*  871 */     NodeList allowedMethodsEls = element.getElementsByTagName("allowed-methods");
/*      */ 
/*      */     
/*  874 */     if (allowedMethodsEls.getLength() > 0) {
/*      */       
/*  876 */       allowedMethods = new HashSet<>(packageContext.getGlobalAllowedMethods());
/*      */       
/*  878 */       Node allowedMethodsNode = allowedMethodsEls.item(0);
/*  879 */       if (allowedMethodsNode != null) {
/*  880 */         NodeList allowedMethodsChildren = allowedMethodsNode.getChildNodes();
/*  881 */         StringBuilder allowedMethodsSB = new StringBuilder();
/*  882 */         for (int i = 0; i < allowedMethodsChildren.getLength(); i++) {
/*  883 */           Node allowedMethodsChildNode = allowedMethodsChildren.item(i);
/*  884 */           if (allowedMethodsChildNode != null && allowedMethodsChildNode.getNodeType() == 3) {
/*  885 */             String childNodeValue = allowedMethodsChildNode.getNodeValue();
/*  886 */             childNodeValue = (childNodeValue != null) ? childNodeValue.trim() : "";
/*  887 */             if (childNodeValue.length() > 0) {
/*  888 */               allowedMethodsSB.append(childNodeValue);
/*      */             }
/*      */           } 
/*      */         } 
/*  892 */         if (allowedMethodsSB.length() > 0) {
/*  893 */           allowedMethods.addAll(TextParseUtil.commaDelimitedStringToSet(allowedMethodsSB.toString()));
/*      */         }
/*      */       } 
/*  896 */     } else if (packageContext.isStrictMethodInvocation()) {
/*      */       
/*  898 */       allowedMethods = new HashSet<>(packageContext.getGlobalAllowedMethods());
/*      */     } else {
/*      */       
/*  901 */       allowedMethods = new HashSet<>();
/*  902 */       allowedMethods.add("*");
/*      */     } 
/*      */     
/*  905 */     LOG.debug("Collected allowed methods: {}", allowedMethods);
/*      */     
/*  907 */     return Collections.unmodifiableSet(allowedMethods);
/*      */   }
/*      */   
/*      */   protected void loadDefaultInterceptorRef(PackageConfig.Builder packageContext, Element element) {
/*  911 */     NodeList resultTypeList = element.getElementsByTagName("default-interceptor-ref");
/*      */     
/*  913 */     if (resultTypeList.getLength() > 0) {
/*  914 */       Element defaultRefElement = (Element)resultTypeList.item(0);
/*  915 */       packageContext.defaultInterceptorRef(defaultRefElement.getAttribute("name"));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadDefaultActionRef(PackageConfig.Builder packageContext, Element element) {
/*  920 */     NodeList resultTypeList = element.getElementsByTagName("default-action-ref");
/*      */     
/*  922 */     if (resultTypeList.getLength() > 0) {
/*  923 */       Element defaultRefElement = (Element)resultTypeList.item(0);
/*  924 */       packageContext.defaultActionRef(defaultRefElement.getAttribute("name"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadGlobalResults(PackageConfig.Builder packageContext, Element packageElement) {
/*  935 */     NodeList globalResultList = packageElement.getElementsByTagName("global-results");
/*      */     
/*  937 */     if (globalResultList.getLength() > 0) {
/*  938 */       Element globalResultElement = (Element)globalResultList.item(0);
/*  939 */       Map<String, ResultConfig> results = buildResults(globalResultElement, packageContext);
/*  940 */       packageContext.addGlobalResultConfigs(results);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadGlobalAllowedMethods(PackageConfig.Builder packageContext, Element packageElement) {
/*  945 */     NodeList globalAllowedMethodsElms = packageElement.getElementsByTagName("global-allowed-methods");
/*      */     
/*  947 */     if (globalAllowedMethodsElms.getLength() > 0) {
/*  948 */       Set<String> globalAllowedMethods = new HashSet<>();
/*      */       
/*  950 */       Node globaAllowedMethodsNode = globalAllowedMethodsElms.item(0);
/*  951 */       if (globaAllowedMethodsNode != null) {
/*  952 */         NodeList globaAllowedMethodsChildren = globaAllowedMethodsNode.getChildNodes();
/*  953 */         StringBuilder globalAllowedMethodsSB = new StringBuilder();
/*  954 */         for (int i = 0; i < globaAllowedMethodsChildren.getLength(); i++) {
/*  955 */           Node globalAllowedMethodsChildNode = globaAllowedMethodsChildren.item(i);
/*  956 */           if (globalAllowedMethodsChildNode != null && globalAllowedMethodsChildNode.getNodeType() == 3) {
/*  957 */             String childNodeValue = globalAllowedMethodsChildNode.getNodeValue();
/*  958 */             childNodeValue = (childNodeValue != null) ? childNodeValue.trim() : "";
/*  959 */             if (childNodeValue.length() > 0) {
/*  960 */               globalAllowedMethodsSB.append(childNodeValue);
/*      */             }
/*      */           } 
/*      */         } 
/*  964 */         if (globalAllowedMethodsSB.length() > 0) {
/*  965 */           globalAllowedMethods.addAll(TextParseUtil.commaDelimitedStringToSet(globalAllowedMethodsSB.toString()));
/*      */         }
/*      */       } 
/*  968 */       packageContext.addGlobalAllowedMethods(globalAllowedMethods);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadDefaultClassRef(PackageConfig.Builder packageContext, Element element) {
/*  973 */     NodeList defaultClassRefList = element.getElementsByTagName("default-class-ref");
/*  974 */     if (defaultClassRefList.getLength() > 0) {
/*  975 */       Element defaultClassRefElement = (Element)defaultClassRefList.item(0);
/*  976 */       packageContext.defaultClassRef(defaultClassRefElement.getAttribute("class"));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadGlobalExceptionMappings(PackageConfig.Builder packageContext, Element packageElement) {
/*  987 */     NodeList globalExceptionMappingList = packageElement.getElementsByTagName("global-exception-mappings");
/*      */     
/*  989 */     if (globalExceptionMappingList.getLength() > 0) {
/*  990 */       Element globalExceptionMappingElement = (Element)globalExceptionMappingList.item(0);
/*  991 */       List<ExceptionMappingConfig> exceptionMappings = buildExceptionMappings(globalExceptionMappingElement, packageContext);
/*  992 */       packageContext.addGlobalExceptionMappingConfigs(exceptionMappings);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected InterceptorStackConfig loadInterceptorStack(Element element, PackageConfig.Builder context) throws ConfigurationException {
/*  997 */     String name = element.getAttribute("name");
/*      */     
/*  999 */     InterceptorStackConfig.Builder config = (new InterceptorStackConfig.Builder(name)).location(DomHelper.getLocationObject(element));
/*      */     
/* 1001 */     NodeList interceptorRefList = element.getElementsByTagName("interceptor-ref");
/*      */     
/* 1003 */     for (int j = 0; j < interceptorRefList.getLength(); j++) {
/* 1004 */       Element interceptorRefElement = (Element)interceptorRefList.item(j);
/* 1005 */       List<InterceptorMapping> interceptors = lookupInterceptorReference(context, interceptorRefElement);
/* 1006 */       config.addInterceptors(interceptors);
/*      */     } 
/*      */     
/* 1009 */     return config.build();
/*      */   }
/*      */   
/*      */   protected void loadInterceptorStacks(Element element, PackageConfig.Builder context) throws ConfigurationException {
/* 1013 */     NodeList interceptorStackList = element.getElementsByTagName("interceptor-stack");
/*      */     
/* 1015 */     for (int i = 0; i < interceptorStackList.getLength(); i++) {
/* 1016 */       Element interceptorStackElement = (Element)interceptorStackList.item(i);
/*      */       
/* 1018 */       InterceptorStackConfig config = loadInterceptorStack(interceptorStackElement, context);
/*      */       
/* 1020 */       context.addInterceptorStackConfig(config);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadInterceptors(PackageConfig.Builder context, Element element) throws ConfigurationException {
/* 1025 */     NodeList interceptorList = element.getElementsByTagName("interceptor");
/*      */     
/* 1027 */     for (int i = 0; i < interceptorList.getLength(); i++) {
/* 1028 */       Element interceptorElement = (Element)interceptorList.item(i);
/* 1029 */       String name = interceptorElement.getAttribute("name");
/* 1030 */       String className = interceptorElement.getAttribute("class");
/*      */       
/* 1032 */       Map<String, String> params = XmlHelper.getParams(interceptorElement);
/* 1033 */       InterceptorConfig config = (new InterceptorConfig.Builder(name, className)).addParams(params).location(DomHelper.getLocationObject(interceptorElement)).build();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1038 */       context.addInterceptorConfig(config);
/*      */     } 
/*      */     
/* 1041 */     loadInterceptorStacks(element, context);
/*      */   }
/*      */   
/*      */   private List<Document> loadConfigurationFiles(String fileName, Element includeElement) {
/* 1045 */     List<Document> docs = new ArrayList<>();
/* 1046 */     List<Document> finalDocs = new ArrayList<>();
/* 1047 */     if (!this.includedFileNames.contains(fileName)) {
/* 1048 */       LOG.debug("Loading action configurations from: {}", fileName);
/*      */       
/* 1050 */       this.includedFileNames.add(fileName);
/*      */       
/* 1052 */       Iterator<URL> urls = null;
/* 1053 */       InputStream is = null;
/*      */       
/* 1055 */       IOException ioException = null;
/*      */       try {
/* 1057 */         urls = getConfigurationUrls(fileName);
/* 1058 */       } catch (IOException ex) {
/* 1059 */         ioException = ex;
/*      */       } 
/*      */       
/* 1062 */       if (urls == null || !urls.hasNext()) {
/* 1063 */         if (this.errorIfMissing) {
/* 1064 */           throw new ConfigurationException("Could not open files of the name " + fileName, ioException);
/*      */         }
/* 1066 */         LOG.trace("Unable to locate configuration files of the name {}, skipping", fileName);
/* 1067 */         return docs;
/*      */       } 
/*      */ 
/*      */       
/* 1071 */       URL url = null;
/* 1072 */       while (urls.hasNext()) {
/*      */         try {
/* 1074 */           url = urls.next();
/* 1075 */           is = this.fileManager.loadFile(url);
/*      */           
/* 1077 */           InputSource in = new InputSource(is);
/*      */           
/* 1079 */           in.setSystemId(url.toString());
/*      */           
/* 1081 */           docs.add(DomHelper.parse(in, this.dtdMappings));
/* 1082 */           this.loadedFileUrls.add(url.toString());
/* 1083 */         } catch (XWorkException e) {
/* 1084 */           if (includeElement != null) {
/* 1085 */             throw new ConfigurationException("Unable to load " + url, e, includeElement);
/*      */           }
/* 1087 */           throw new ConfigurationException("Unable to load " + url, e);
/*      */         }
/* 1089 */         catch (Exception e) {
/* 1090 */           throw new ConfigurationException("Caught exception while loading file " + fileName, e, includeElement);
/*      */         } finally {
/* 1092 */           if (is != null) {
/*      */             try {
/* 1094 */               is.close();
/* 1095 */             } catch (IOException e) {
/* 1096 */               LOG.error("Unable to close input stream", e);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1103 */       Collections.sort(docs, new Comparator<Document>() {
/*      */             public int compare(Document doc1, Document doc2) {
/* 1105 */               return XmlHelper.getLoadOrder(doc1).compareTo(XmlHelper.getLoadOrder(doc2));
/*      */             }
/*      */           });
/*      */       
/* 1109 */       for (Document doc : docs) {
/* 1110 */         Element rootElement = doc.getDocumentElement();
/* 1111 */         NodeList children = rootElement.getChildNodes();
/* 1112 */         int childSize = children.getLength();
/*      */         
/* 1114 */         for (int i = 0; i < childSize; i++) {
/* 1115 */           Node childNode = children.item(i);
/*      */           
/* 1117 */           if (childNode instanceof Element) {
/* 1118 */             Element child = (Element)childNode;
/*      */             
/* 1120 */             String nodeName = child.getNodeName();
/*      */             
/* 1122 */             if ("include".equals(nodeName)) {
/* 1123 */               String includeFileName = child.getAttribute("file");
/* 1124 */               if (includeFileName.indexOf('*') != -1) {
/*      */                 
/* 1126 */                 ClassPathFinder wildcardFinder = new ClassPathFinder();
/* 1127 */                 wildcardFinder.setPattern(includeFileName);
/* 1128 */                 Vector<String> wildcardMatches = wildcardFinder.findMatches();
/* 1129 */                 for (String match : wildcardMatches) {
/* 1130 */                   finalDocs.addAll(loadConfigurationFiles(match, child));
/*      */                 }
/*      */               } else {
/* 1133 */                 finalDocs.addAll(loadConfigurationFiles(includeFileName, child));
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/* 1138 */         finalDocs.add(doc);
/*      */       } 
/*      */       
/* 1141 */       LOG.debug("Loaded action configuration from: {}", fileName);
/*      */     } 
/* 1143 */     return finalDocs;
/*      */   }
/*      */   
/*      */   protected Iterator<URL> getConfigurationUrls(String fileName) throws IOException {
/* 1147 */     return ClassLoaderUtil.getResources(fileName, XmlConfigurationProvider.class, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadExtraConfiguration(Document doc) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<InterceptorMapping> lookupInterceptorReference(PackageConfig.Builder context, Element interceptorRefElement) throws ConfigurationException {
/* 1169 */     String refName = interceptorRefElement.getAttribute("name");
/* 1170 */     Map<String, String> refParams = XmlHelper.getParams(interceptorRefElement);
/*      */     
/* 1172 */     Location loc = LocationUtils.getLocation(interceptorRefElement);
/* 1173 */     return InterceptorBuilder.constructInterceptorReference((InterceptorLocator)context, refName, refParams, loc, this.objectFactory);
/*      */   }
/*      */   
/*      */   List<Document> getDocuments() {
/* 1177 */     return this.documents;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1182 */     return "XmlConfigurationProvider{configFileName='" + this.configFileName + '\'' + '}';
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\XmlConfigurationProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */