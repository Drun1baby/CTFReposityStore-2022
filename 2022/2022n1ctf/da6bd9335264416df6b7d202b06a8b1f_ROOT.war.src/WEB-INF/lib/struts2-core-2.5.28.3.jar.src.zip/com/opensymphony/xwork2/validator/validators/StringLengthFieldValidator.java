/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringLengthFieldValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*  95 */   private static final Logger LOG = LogManager.getLogger(StringLengthFieldValidator.class);
/*     */   
/*     */   private boolean trim = true;
/*  98 */   private int maxLength = -1;
/*  99 */   private int minLength = -1;
/*     */   
/*     */   private String maxLengthExpression;
/*     */   private String minLengthExpression;
/*     */   private String trimExpression;
/*     */   
/*     */   public void setMaxLength(int maxLength) {
/* 106 */     this.maxLength = maxLength;
/*     */   }
/*     */   
/*     */   public void setMaxLengthExpression(String maxLengthExpression) {
/* 110 */     this.maxLengthExpression = maxLengthExpression;
/*     */   }
/*     */   
/*     */   public int getMaxLength() {
/* 114 */     if (StringUtils.isNotEmpty(this.maxLengthExpression)) {
/* 115 */       return ((Integer)parse(this.maxLengthExpression, Integer.class)).intValue();
/*     */     }
/* 117 */     return this.maxLength;
/*     */   }
/*     */   
/*     */   public void setMinLength(int minLength) {
/* 121 */     this.minLength = minLength;
/*     */   }
/*     */   
/*     */   public void setMinLengthExpression(String minLengthExpression) {
/* 125 */     this.minLengthExpression = minLengthExpression;
/*     */   }
/*     */   
/*     */   public int getMinLength() {
/* 129 */     if (StringUtils.isNotEmpty(this.minLengthExpression)) {
/* 130 */       return ((Integer)parse(this.minLengthExpression, Integer.class)).intValue();
/*     */     }
/* 132 */     return this.minLength;
/*     */   }
/*     */   
/*     */   public void setTrim(boolean trim) {
/* 136 */     this.trim = trim;
/*     */   }
/*     */   
/*     */   public void setTrimExpression(String trimExpression) {
/* 140 */     this.trimExpression = trimExpression;
/*     */   }
/*     */   
/*     */   public boolean isTrim() {
/* 144 */     if (StringUtils.isNotEmpty(this.trimExpression)) {
/* 145 */       return ((Boolean)parse(this.trimExpression, Boolean.class)).booleanValue();
/*     */     }
/* 147 */     return this.trim;
/*     */   }
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/* 151 */     Object fieldValue = getFieldValue(this.fieldName, object);
/*     */     
/* 153 */     if (fieldValue == null) {
/* 154 */       LOG.debug("Value for field {} is null, use a required validator", getFieldName());
/* 155 */     } else if (fieldValue.getClass().isArray()) {
/* 156 */       Object[] values = (Object[])fieldValue;
/* 157 */       for (Object value : values) {
/* 158 */         validateValue(object, value);
/*     */       }
/* 160 */     } else if (Collection.class.isAssignableFrom(fieldValue.getClass())) {
/* 161 */       Collection values = (Collection)fieldValue;
/* 162 */       for (Object value : values) {
/* 163 */         validateValue(object, value);
/*     */       }
/*     */     } else {
/* 166 */       validateValue(object, fieldValue);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateValue(Object object, Object value) {
/* 171 */     String stringValue = Objects.toString(value, "");
/*     */     
/* 173 */     if (StringUtils.isEmpty(stringValue)) {
/* 174 */       LOG.debug("Value is empty, use a required validator");
/*     */       
/*     */       return;
/*     */     } 
/* 178 */     if (isTrim()) {
/* 179 */       stringValue = stringValue.trim();
/* 180 */       if (StringUtils.isEmpty(stringValue)) {
/* 181 */         LOG.debug("Value is empty, use a required validator");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 186 */     int minLengthToUse = getMinLength();
/* 187 */     int maxLengthToUse = getMaxLength();
/*     */     
/*     */     try {
/* 190 */       setCurrentValue(stringValue);
/* 191 */       if (minLengthToUse > -1 && stringValue.length() < minLengthToUse) {
/* 192 */         addFieldError(this.fieldName, object);
/* 193 */       } else if (maxLengthToUse > -1 && stringValue.length() > maxLengthToUse) {
/* 194 */         addFieldError(this.fieldName, object);
/*     */       } 
/*     */     } finally {
/* 197 */       setCurrentValue((Object)null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\StringLengthFieldValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */