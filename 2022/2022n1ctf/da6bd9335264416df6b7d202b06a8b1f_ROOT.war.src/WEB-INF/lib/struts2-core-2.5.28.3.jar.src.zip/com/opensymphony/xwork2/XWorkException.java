/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Locatable;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkException
/*     */   extends RuntimeException
/*     */   implements Locatable
/*     */ {
/*     */   private Location location;
/*     */   
/*     */   public XWorkException() {}
/*     */   
/*     */   public XWorkException(String s) {
/*  48 */     this(s, (Throwable)null, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XWorkException(String s, Object target) {
/*  59 */     this(s, (Throwable)null, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XWorkException(Throwable cause) {
/*  68 */     this((String)null, cause, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XWorkException(Throwable cause, Object target) {
/*  78 */     this((String)null, cause, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XWorkException(String s, Throwable cause) {
/*  89 */     this(s, cause, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XWorkException(String s, Throwable cause, Object target) {
/* 102 */     super(s, cause);
/*     */     
/* 104 */     this.location = LocationUtils.getLocation(target);
/* 105 */     if (this.location == Location.UNKNOWN) {
/* 106 */       this.location = LocationUtils.getLocation(cause);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/* 116 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     String msg = getMessage();
/* 130 */     if (msg == null && getCause() != null) {
/* 131 */       msg = getCause().getMessage();
/*     */     }
/*     */     
/* 134 */     if (this.location != null) {
/* 135 */       if (msg != null) {
/* 136 */         return msg + " - " + this.location.toString();
/*     */       }
/* 138 */       return this.location.toString();
/*     */     } 
/*     */     
/* 141 */     return msg;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\XWorkException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */