/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextProviderSupport
/*     */   implements ResourceBundleTextProvider
/*     */ {
/*     */   protected Class clazz;
/*     */   protected LocaleProvider localeProvider;
/*     */   protected ResourceBundle bundle;
/*     */   protected LocalizedTextProvider localizedTextProvider;
/*     */   
/*     */   public TextProviderSupport(Class clazz, LocaleProvider provider, LocalizedTextProvider localizedTextProvider) {
/*  46 */     this.clazz = clazz;
/*  47 */     this.localeProvider = provider;
/*  48 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextProviderSupport(ResourceBundle bundle, LocaleProvider provider, LocalizedTextProvider localizedTextProvider) {
/*  58 */     this.bundle = bundle;
/*  59 */     this.localeProvider = provider;
/*  60 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBundle(ResourceBundle bundle) {
/*  68 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(Class clazz) {
/*  76 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocaleProvider(LocaleProvider localeProvider) {
/*  84 */     this.localeProvider = localeProvider;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocaleProviderFactory(LocaleProviderFactory localeProviderFactory) {
/*  89 */     this.localeProvider = localeProviderFactory.createLocaleProvider();
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/*  94 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasKey(String key) {
/*     */     String message;
/* 107 */     if (this.clazz != null) {
/* 108 */       message = this.localizedTextProvider.findText(this.clazz, key, getLocale(), (String)null, new Object[0]);
/*     */     } else {
/* 110 */       message = this.localizedTextProvider.findText(this.bundle, key, getLocale(), (String)null, new Object[0]);
/*     */     } 
/* 112 */     return (message != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key) {
/* 127 */     return getText(key, key, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue) {
/* 143 */     return getText(key, defaultValue, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String arg) {
/* 159 */     List<Object> args = new ArrayList();
/* 160 */     args.add(arg);
/* 161 */     return getText(key, defaultValue, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, List<?> args) {
/* 177 */     return getText(key, key, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String[] args) {
/* 193 */     return getText(key, key, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args) {
/* 210 */     Object[] argsArray = (args != null && !args.equals(Collections.emptyList())) ? args.toArray() : null;
/* 211 */     if (this.clazz != null) {
/* 212 */       return this.localizedTextProvider.findText(this.clazz, key, getLocale(), defaultValue, argsArray);
/*     */     }
/* 214 */     return this.localizedTextProvider.findText(this.bundle, key, getLocale(), defaultValue, argsArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args) {
/* 232 */     if (this.clazz != null) {
/* 233 */       return this.localizedTextProvider.findText(this.clazz, key, getLocale(), defaultValue, (Object[])args);
/*     */     }
/* 235 */     return this.localizedTextProvider.findText(this.bundle, key, getLocale(), defaultValue, (Object[])args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args, ValueStack stack) {
/*     */     Locale locale;
/* 252 */     Object[] argsArray = (args != null) ? args.toArray() : null;
/*     */     
/* 254 */     if (stack == null) {
/* 255 */       locale = getLocale();
/*     */     } else {
/* 257 */       locale = (Locale)stack.getContext().get("com.opensymphony.xwork2.ActionContext.locale");
/*     */     } 
/* 259 */     if (locale == null) {
/* 260 */       locale = getLocale();
/*     */     }
/* 262 */     if (this.clazz != null) {
/* 263 */       return this.localizedTextProvider.findText(this.clazz, key, locale, defaultValue, argsArray, stack);
/*     */     }
/* 265 */     return this.localizedTextProvider.findText(this.bundle, key, locale, defaultValue, argsArray, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args, ValueStack stack) {
/*     */     Locale locale;
/* 284 */     if (stack == null) {
/* 285 */       locale = getLocale();
/*     */     } else {
/* 287 */       locale = (Locale)stack.getContext().get("com.opensymphony.xwork2.ActionContext.locale");
/*     */     } 
/* 289 */     if (locale == null) {
/* 290 */       locale = getLocale();
/*     */     }
/* 292 */     if (this.clazz != null) {
/* 293 */       return this.localizedTextProvider.findText(this.clazz, key, locale, defaultValue, (Object[])args, stack);
/*     */     }
/* 295 */     return this.localizedTextProvider.findText(this.bundle, key, locale, defaultValue, (Object[])args, stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getTexts(String aBundleName) {
/* 315 */     return this.localizedTextProvider.findResourceBundle(aBundleName, getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getTexts() {
/* 325 */     if (this.clazz != null) {
/* 326 */       return getTexts(this.clazz.getName());
/*     */     }
/* 328 */     return this.bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Locale getLocale() {
/* 337 */     return this.localeProvider.getLocale();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\TextProviderSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */