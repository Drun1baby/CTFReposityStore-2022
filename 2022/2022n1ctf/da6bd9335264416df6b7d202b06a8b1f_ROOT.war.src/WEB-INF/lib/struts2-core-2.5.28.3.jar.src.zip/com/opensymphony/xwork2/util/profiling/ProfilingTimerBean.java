/*     */ package com.opensymphony.xwork2.util.profiling;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ProfilingTimerBean
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6180672043920208784L;
/*  65 */   List<ProfilingTimerBean> children = new ArrayList<>();
/*  66 */   ProfilingTimerBean parent = null;
/*     */   
/*     */   String resource;
/*     */   
/*     */   long startTime;
/*     */   long totalTime;
/*     */   
/*     */   public ProfilingTimerBean(String resource) {
/*  74 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   protected void addParent(ProfilingTimerBean parent) {
/*  78 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public ProfilingTimerBean getParent() {
/*  82 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addChild(ProfilingTimerBean child) {
/*  87 */     this.children.add(child);
/*  88 */     child.addParent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStartTime() {
/*  93 */     this.startTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public void setEndTime() {
/*  97 */     this.totalTime = System.currentTimeMillis() - this.startTime;
/*     */   }
/*     */   
/*     */   public String getResource() {
/* 101 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrintable(long minTime) {
/* 109 */     return getPrintable("", minTime);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getPrintable(String indent, long minTime) {
/* 114 */     if (this.totalTime >= minTime) {
/* 115 */       StringBuilder buffer = new StringBuilder();
/* 116 */       buffer.append(indent);
/* 117 */       buffer.append("[" + this.totalTime + "ms] - " + this.resource);
/* 118 */       buffer.append("\n");
/*     */       
/* 120 */       for (ProfilingTimerBean aChildren : this.children) {
/* 121 */         buffer.append(aChildren.getPrintable(indent + "  ", minTime));
/*     */       }
/*     */       
/* 124 */       return buffer.toString();
/*     */     } 
/* 126 */     return "";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\profiling\ProfilingTimerBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */