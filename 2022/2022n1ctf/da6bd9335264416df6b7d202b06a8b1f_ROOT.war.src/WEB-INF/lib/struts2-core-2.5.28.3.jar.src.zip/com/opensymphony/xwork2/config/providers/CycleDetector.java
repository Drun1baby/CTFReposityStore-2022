/*    */ package com.opensymphony.xwork2.config.providers;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CycleDetector<T>
/*    */ {
/*    */   private DirectedGraph<T> graph;
/*    */   private Map<T, Status> marks;
/*    */   private List<T> verticesInCycles;
/*    */   
/*    */   private enum Status
/*    */   {
/* 31 */     MARKED, COMPLETE; }
/*    */   
/*    */   public CycleDetector(DirectedGraph<T> graph) {
/* 34 */     this.graph = graph;
/* 35 */     this.marks = new HashMap<>();
/* 36 */     this.verticesInCycles = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public boolean containsCycle() {
/* 40 */     for (T v : this.graph) {
/* 41 */       if (this.marks.containsKey(v) || 
/* 42 */         mark(v));
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     return !this.verticesInCycles.isEmpty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean mark(T vertex) {
/* 55 */     List<T> localCycles = new ArrayList<>();
/* 56 */     this.marks.put(vertex, Status.MARKED);
/* 57 */     for (T u : this.graph.edgesFrom(vertex)) {
/* 58 */       if (this.marks.get(u) == Status.MARKED) {
/* 59 */         localCycles.add(vertex); continue;
/*    */       } 
/* 61 */       if (!this.marks.containsKey(u) && 
/* 62 */         mark(u)) {
/* 63 */         localCycles.add(vertex);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 68 */     this.marks.put(vertex, Status.COMPLETE);
/*    */     
/* 70 */     this.verticesInCycles.addAll(localCycles);
/* 71 */     return !localCycles.isEmpty();
/*    */   }
/*    */   
/*    */   public List<T> getVerticesInCycles() {
/* 75 */     return this.verticesInCycles;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\CycleDetector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */