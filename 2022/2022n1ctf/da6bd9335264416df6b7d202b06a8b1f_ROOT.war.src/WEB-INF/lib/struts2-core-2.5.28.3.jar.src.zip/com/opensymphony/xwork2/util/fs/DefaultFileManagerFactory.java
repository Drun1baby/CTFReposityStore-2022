/*     */ package com.opensymphony.xwork2.util.fs;
/*     */ 
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFileManagerFactory
/*     */   implements FileManagerFactory
/*     */ {
/*  37 */   private static final Logger LOG = LogManager.getLogger(DefaultFileManagerFactory.class);
/*     */   
/*     */   private boolean reloadingConfigs;
/*     */   private FileManagerHolder fileManagerHolder;
/*     */   private FileManager systemFileManager;
/*     */   private Container container;
/*     */   
/*     */   @Inject("system")
/*     */   public void setFileManager(FileManager fileManager) {
/*  46 */     this.systemFileManager = fileManager;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  51 */     this.container = container;
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.configuration.xml.reload", required = false)
/*     */   public void setReloadingConfigs(String reloadingConfigs) {
/*  56 */     this.reloadingConfigs = Boolean.parseBoolean(reloadingConfigs);
/*     */   }
/*     */   
/*     */   public FileManager getFileManager() {
/*  60 */     if (this.fileManagerHolder != null) {
/*  61 */       return this.fileManagerHolder.getFileManager();
/*     */     }
/*     */     
/*  64 */     FileManager fileManager = lookupFileManager();
/*  65 */     if (fileManager != null) {
/*  66 */       LOG.debug("Using FileManager implementation [{}]", fileManager.getClass().getSimpleName());
/*  67 */       fileManager.setReloadingConfigs(this.reloadingConfigs);
/*  68 */       this.fileManagerHolder = new FileManagerHolder(fileManager);
/*  69 */       return fileManager;
/*     */     } 
/*     */     
/*  72 */     LOG.debug("Using default implementation of FileManager provided under name [system]: {}", this.systemFileManager.getClass().getSimpleName());
/*  73 */     this.systemFileManager.setReloadingConfigs(this.reloadingConfigs);
/*  74 */     this.fileManagerHolder = new FileManagerHolder(this.systemFileManager);
/*  75 */     return this.systemFileManager;
/*     */   }
/*     */   
/*     */   private FileManager lookupFileManager() {
/*  79 */     Set<String> names = this.container.getInstanceNames(FileManager.class);
/*  80 */     LOG.debug("Found following implementations of FileManager interface: {}", names);
/*  81 */     Set<FileManager> internals = new HashSet<>();
/*  82 */     Set<FileManager> users = new HashSet<>();
/*  83 */     for (String fmName : names) {
/*  84 */       FileManager fm = (FileManager)this.container.getInstance(FileManager.class, fmName);
/*  85 */       if (fm.internal()) {
/*  86 */         internals.add(fm); continue;
/*     */       } 
/*  88 */       users.add(fm);
/*     */     } 
/*     */     
/*  91 */     for (FileManager fm : users) {
/*  92 */       if (fm.support()) {
/*  93 */         LOG.debug("Using FileManager implementation [{}]", fm.getClass().getSimpleName());
/*  94 */         return fm;
/*     */       } 
/*     */     } 
/*  97 */     LOG.debug("No user defined FileManager, looking up for internal implementations!");
/*  98 */     for (FileManager fm : internals) {
/*  99 */       if (fm.support()) {
/* 100 */         return fm;
/*     */       }
/*     */     } 
/* 103 */     return null;
/*     */   }
/*     */   
/*     */   private static class FileManagerHolder
/*     */   {
/*     */     private final FileManager fileManager;
/*     */     
/*     */     public FileManagerHolder(FileManager fileManager) {
/* 111 */       this.fileManager = fileManager;
/*     */     }
/*     */     
/*     */     public FileManager getFileManager() {
/* 115 */       return this.fileManager;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\fs\DefaultFileManagerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */