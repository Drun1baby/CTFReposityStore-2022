/*    */ package com.opensymphony.xwork2.util.logging.slf4j;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Slf4jLoggerFactory
/*    */   extends LoggerFactory
/*    */ {
/*    */   protected Logger getLoggerImpl(Class<?> cls) {
/* 39 */     return new Slf4jLogger(LoggerFactory.getLogger(cls));
/*    */   }
/*    */ 
/*    */   
/*    */   protected Logger getLoggerImpl(String name) {
/* 44 */     return new Slf4jLogger(LoggerFactory.getLogger(name));
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\slf4j\Slf4jLoggerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */