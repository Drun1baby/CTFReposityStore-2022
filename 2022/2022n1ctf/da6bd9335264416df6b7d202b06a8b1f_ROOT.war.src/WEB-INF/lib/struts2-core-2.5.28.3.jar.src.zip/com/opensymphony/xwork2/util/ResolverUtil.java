/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverUtil<T>
/*     */ {
/*  72 */   private static final Logger LOG = LogManager.getLogger(ResolverUtil.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Test
/*     */   {
/*     */     boolean matches(Class param1Class);
/*     */ 
/*     */     
/*     */     boolean matches(URL param1URL);
/*     */ 
/*     */     
/*     */     boolean doesMatchClass();
/*     */ 
/*     */     
/*     */     boolean doesMatchResource();
/*     */   }
/*     */ 
/*     */   
/*     */   public static abstract class ClassTest
/*     */     implements Test
/*     */   {
/*     */     public boolean matches(URL resource) {
/*  95 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean doesMatchClass() {
/*  99 */       return true;
/*     */     }
/*     */     public boolean doesMatchResource() {
/* 102 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class ResourceTest implements Test {
/*     */     public boolean matches(Class cls) {
/* 108 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean doesMatchClass() {
/* 112 */       return false;
/*     */     }
/*     */     public boolean doesMatchResource() {
/* 115 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IsA
/*     */     extends ClassTest
/*     */   {
/*     */     private Class parent;
/*     */ 
/*     */ 
/*     */     
/*     */     public IsA(Class parentType) {
/* 129 */       this.parent = parentType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Class<?> type) {
/* 136 */       return (type != null && this.parent.isAssignableFrom(type));
/*     */     }
/*     */     
/*     */     public String toString() {
/* 140 */       return "is assignable to " + this.parent.getSimpleName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NameEndsWith
/*     */     extends ClassTest
/*     */   {
/*     */     private String suffix;
/*     */ 
/*     */ 
/*     */     
/*     */     public NameEndsWith(String suffix) {
/* 154 */       this.suffix = suffix;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Class type) {
/* 161 */       return (type != null && type.getName().endsWith(this.suffix));
/*     */     }
/*     */     
/*     */     public String toString() {
/* 165 */       return "ends with the suffix " + this.suffix;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AnnotatedWith
/*     */     extends ClassTest
/*     */   {
/*     */     private Class<? extends Annotation> annotation;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotatedWith(Class<? extends Annotation> annotation) {
/* 181 */       this.annotation = annotation;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Class type) {
/* 188 */       return (type != null && type.isAnnotationPresent(this.annotation));
/*     */     }
/*     */     
/*     */     public String toString() {
/* 192 */       return "annotated with @" + this.annotation.getSimpleName();
/*     */     } }
/*     */   
/*     */   public static class NameIs extends ResourceTest {
/*     */     private String name;
/*     */     
/*     */     public NameIs(String name) {
/* 199 */       this.name = "/" + name;
/*     */     }
/*     */     public boolean matches(URL resource) {
/* 202 */       return resource.getPath().endsWith(this.name);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 206 */       return "named " + this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 211 */   private Set<Class<? extends T>> classMatches = new HashSet<>();
/*     */ 
/*     */   
/* 214 */   private Set<URL> resourceMatches = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassLoader classloader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Class<? extends T>> getClasses() {
/* 229 */     return this.classMatches;
/*     */   }
/*     */   
/*     */   public Set<URL> getResources() {
/* 233 */     return this.resourceMatches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 244 */     return (this.classloader == null) ? Thread.currentThread().getContextClassLoader() : this.classloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassLoader(ClassLoader classloader) {
/* 253 */     this.classloader = classloader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findImplementations(Class parent, String... packageNames) {
/* 265 */     if (packageNames == null)
/*     */       return; 
/* 267 */     Test test = new IsA(parent);
/* 268 */     for (String pkg : packageNames) {
/* 269 */       findInPackage(test, pkg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findSuffix(String suffix, String... packageNames) {
/* 281 */     if (packageNames == null)
/*     */       return; 
/* 283 */     Test test = new NameEndsWith(suffix);
/* 284 */     for (String pkg : packageNames) {
/* 285 */       findInPackage(test, pkg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findAnnotated(Class<? extends Annotation> annotation, String... packageNames) {
/* 297 */     if (packageNames == null)
/*     */       return; 
/* 299 */     Test test = new AnnotatedWith(annotation);
/* 300 */     for (String pkg : packageNames) {
/* 301 */       findInPackage(test, pkg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void findNamedResource(String name, String... pathNames) {
/* 306 */     if (pathNames == null)
/*     */       return; 
/* 308 */     Test test = new NameIs(name);
/* 309 */     for (String pkg : pathNames) {
/* 310 */       findInPackage(test, pkg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void find(Test test, String... packageNames) {
/* 322 */     if (packageNames == null)
/*     */       return; 
/* 324 */     for (String pkg : packageNames) {
/* 325 */       findInPackage(test, pkg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findInPackage(Test test, String packageName) {
/*     */     Enumeration<URL> urls;
/* 340 */     packageName = packageName.replace('.', '/');
/* 341 */     ClassLoader loader = getClassLoader();
/*     */ 
/*     */     
/*     */     try {
/* 345 */       urls = loader.getResources(packageName);
/*     */     }
/* 347 */     catch (IOException ioe) {
/* 348 */       if (LOG.isWarnEnabled()) {
/* 349 */         LOG.warn("Could not read package: " + packageName, ioe);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 354 */     while (urls.hasMoreElements()) {
/*     */       try {
/* 356 */         String urlPath = ((URL)urls.nextElement()).getFile();
/* 357 */         urlPath = URLDecoder.decode(urlPath, "UTF-8");
/*     */ 
/*     */         
/* 360 */         if (urlPath.startsWith("file:")) {
/* 361 */           urlPath = urlPath.substring(5);
/*     */         }
/*     */ 
/*     */         
/* 365 */         if (urlPath.indexOf('!') > 0) {
/* 366 */           urlPath = urlPath.substring(0, urlPath.indexOf('!'));
/*     */         }
/*     */         
/* 369 */         if (LOG.isInfoEnabled()) {
/* 370 */           LOG.info("Scanning for classes in [" + urlPath + "] matching criteria: " + test);
/*     */         }
/* 372 */         File file = new File(urlPath);
/* 373 */         if (file.isDirectory()) {
/* 374 */           loadImplementationsInDirectory(test, packageName, file);
/*     */           continue;
/*     */         } 
/* 377 */         loadImplementationsInJar(test, packageName, file);
/*     */       
/*     */       }
/* 380 */       catch (IOException ioe) {
/* 381 */         if (LOG.isWarnEnabled()) {
/* 382 */           LOG.warn("could not read entries", ioe);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadImplementationsInDirectory(Test test, String parent, File location) {
/* 402 */     File[] files = location.listFiles();
/* 403 */     StringBuilder builder = null;
/*     */     
/* 405 */     for (File file : files) {
/* 406 */       builder = new StringBuilder(100);
/* 407 */       builder.append(parent).append("/").append(file.getName());
/* 408 */       String packageOrClass = (parent == null) ? file.getName() : builder.toString();
/*     */       
/* 410 */       if (file.isDirectory()) {
/* 411 */         loadImplementationsInDirectory(test, packageOrClass, file);
/*     */       }
/* 413 */       else if (isTestApplicable(test, file.getName())) {
/* 414 */         addIfMatching(test, packageOrClass);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isTestApplicable(Test test, String path) {
/* 420 */     return (test.doesMatchResource() || (path.endsWith(".class") && test.doesMatchClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadImplementationsInJar(Test test, String parent, File jarfile) {
/*     */     try {
/* 436 */       JarInputStream jarStream = new JarInputStream(new FileInputStream(jarfile));
/*     */       JarEntry entry;
/* 438 */       while ((entry = jarStream.getNextJarEntry()) != null) {
/* 439 */         String name = entry.getName();
/* 440 */         if (!entry.isDirectory() && name.startsWith(parent) && isTestApplicable(test, name)) {
/* 441 */           addIfMatching(test, name);
/*     */         }
/*     */       }
/*     */     
/* 445 */     } catch (IOException ioe) {
/* 446 */       LOG.error("Could not search jar file '" + jarfile + "' for classes matching criteria: " + test + " due to an IOException", ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addIfMatching(Test test, String fqn) {
/*     */     try {
/* 460 */       ClassLoader loader = getClassLoader();
/* 461 */       if (test.doesMatchClass()) {
/* 462 */         String externalName = fqn.substring(0, fqn.indexOf('.')).replace('/', '.');
/* 463 */         if (LOG.isDebugEnabled()) {
/* 464 */           LOG.debug("Checking to see if class " + externalName + " matches criteria [" + test + "]");
/*     */         }
/*     */         
/* 467 */         Class<?> type = loader.loadClass(externalName);
/* 468 */         if (test.matches(type)) {
/* 469 */           this.classMatches.add(type);
/*     */         }
/*     */       } 
/* 472 */       if (test.doesMatchResource()) {
/* 473 */         URL url = loader.getResource(fqn);
/* 474 */         if (url == null) {
/* 475 */           url = loader.getResource(fqn.substring(1));
/*     */         }
/* 477 */         if (url != null && test.matches(url)) {
/* 478 */           this.resourceMatches.add(url);
/*     */         }
/*     */       }
/*     */     
/* 482 */     } catch (Throwable t) {
/* 483 */       if (LOG.isWarnEnabled())
/* 484 */         LOG.warn("Could not examine class '" + fqn + "' due to a " + t.getClass().getName() + " with message: " + t.getMessage()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ResolverUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */