/*    */ package com.opensymphony.xwork2.util;
/*    */ 
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OgnlTextParser
/*    */   implements TextParser
/*    */ {
/*    */   public Object evaluate(char[] openChars, String expression, TextParseUtil.ParsedValueEvaluator evaluator, int maxLoopCount) {
/* 31 */     Object result = expression = (String)((expression == null) ? "" : expression);
/* 32 */     int pos = 0;
/*    */     
/* 34 */     for (char open : openChars) {
/* 35 */       int loopCount = 1;
/*    */       
/* 37 */       String lookupChars = open + "{";
/*    */       
/*    */       while (true) {
/* 40 */         int start = expression.indexOf(lookupChars, pos);
/* 41 */         if (start == -1) {
/* 42 */           loopCount++;
/* 43 */           start = expression.indexOf(lookupChars);
/*    */         } 
/* 45 */         if (loopCount > maxLoopCount) {
/*    */           break;
/*    */         }
/*    */         
/* 49 */         int length = expression.length();
/* 50 */         int x = start + 2;
/*    */ 
/*    */         
/* 53 */         int count = 1;
/* 54 */         while (start != -1 && x < length && count != 0) {
/* 55 */           char c = expression.charAt(x++);
/* 56 */           if (c == '{') {
/* 57 */             count++; continue;
/* 58 */           }  if (c == '}') {
/* 59 */             count--;
/*    */           }
/*    */         } 
/* 62 */         int end = x - 1;
/*    */         
/* 64 */         if (start != -1 && end != -1 && count == 0) {
/* 65 */           String var = expression.substring(start + 2, end);
/*    */           
/* 67 */           Object o = evaluator.evaluate(var);
/*    */           
/* 69 */           String left = expression.substring(0, start);
/* 70 */           String right = expression.substring(end + 1);
/* 71 */           String middle = null;
/* 72 */           if (o != null) {
/* 73 */             middle = o.toString();
/* 74 */             if (StringUtils.isEmpty(left)) {
/* 75 */               result = o;
/*    */             } else {
/* 77 */               result = left.concat(middle);
/*    */             } 
/*    */             
/* 80 */             if (StringUtils.isNotEmpty(right)) {
/* 81 */               result = result.toString().concat(right);
/*    */             }
/*    */             
/* 84 */             expression = left.concat(middle).concat(right);
/*    */           } else {
/*    */             
/* 87 */             expression = left.concat(right);
/* 88 */             result = expression;
/*    */           } 
/* 90 */           pos = ((left != null && left.length() > 0) ? (left.length() - 1) : 0) + ((middle != null && middle.length() > 0) ? (middle.length() - 1) : 0) + 1;
/*    */ 
/*    */           
/* 93 */           pos = Math.max(pos, 1);
/*    */           continue;
/*    */         } 
/*    */         break;
/*    */       } 
/*    */     } 
/* 99 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\OgnlTextParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */