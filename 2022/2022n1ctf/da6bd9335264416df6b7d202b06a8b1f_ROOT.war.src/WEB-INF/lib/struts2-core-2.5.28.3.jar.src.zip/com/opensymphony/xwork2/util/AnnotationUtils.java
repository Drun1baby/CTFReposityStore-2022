/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationUtils
/*     */ {
/*  45 */   private static final Pattern SETTER_PATTERN = Pattern.compile("set([A-Z][A-Za-z0-9]*)$");
/*  46 */   private static final Pattern GETTER_PATTERN = Pattern.compile("(get|is|has)([A-Z][A-Za-z0-9]*)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addAllFields(Class<? extends Annotation> annotationClass, Class clazz, List<Field> allFields) {
/*  57 */     if (clazz == null) {
/*     */       return;
/*     */     }
/*     */     
/*  61 */     Field[] fields = clazz.getDeclaredFields();
/*     */     
/*  63 */     for (Field field : fields) {
/*  64 */       Annotation ann = field.getAnnotation((Class)annotationClass);
/*  65 */       if (ann != null) {
/*  66 */         allFields.add(field);
/*     */       }
/*     */     } 
/*  69 */     addAllFields(annotationClass, clazz.getSuperclass(), allFields);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addAllMethods(Class<? extends Annotation> annotationClass, Class clazz, List<Method> allMethods) {
/*  81 */     if (clazz == null) {
/*     */       return;
/*     */     }
/*     */     
/*  85 */     Method[] methods = clazz.getDeclaredMethods();
/*     */     
/*  87 */     for (Method method : methods) {
/*  88 */       Annotation ann = method.getAnnotation((Class)annotationClass);
/*  89 */       if (ann != null) {
/*  90 */         allMethods.add(method);
/*     */       }
/*     */     } 
/*  93 */     addAllMethods(annotationClass, clazz.getSuperclass(), allMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addAllInterfaces(Class clazz, List<Class<?>> allInterfaces) {
/* 101 */     if (clazz == null) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     Class[] interfaces = clazz.getInterfaces();
/* 106 */     allInterfaces.addAll(Arrays.asList(interfaces));
/* 107 */     addAllInterfaces(clazz.getSuperclass(), allInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String resolvePropertyName(Method method) {
/* 119 */     Matcher matcher = SETTER_PATTERN.matcher(method.getName());
/* 120 */     if (matcher.matches() && (method.getParameterTypes()).length == 1) {
/* 121 */       String raw = matcher.group(1);
/* 122 */       return raw.substring(0, 1).toLowerCase() + raw.substring(1);
/*     */     } 
/*     */     
/* 125 */     matcher = GETTER_PATTERN.matcher(method.getName());
/* 126 */     if (matcher.matches() && (method.getParameterTypes()).length == 0) {
/* 127 */       String raw = matcher.group(2);
/* 128 */       return raw.substring(0, 1).toLowerCase() + raw.substring(1);
/*     */     } 
/*     */     
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> T findAnnotation(Class<?> clazz, Class<T> annotationClass) {
/* 144 */     T ann = clazz.getAnnotation(annotationClass);
/* 145 */     while (ann == null && clazz != null) {
/* 146 */       ann = clazz.getAnnotation(annotationClass);
/* 147 */       if (ann == null) {
/* 148 */         ann = clazz.getPackage().getAnnotation(annotationClass);
/*     */       }
/* 150 */       if (ann == null) {
/* 151 */         clazz = clazz.getSuperclass();
/* 152 */         if (clazz != null) {
/* 153 */           ann = clazz.getAnnotation(annotationClass);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     return ann;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Annotation> List<T> findAnnotations(Class<?> clazz, Class<T> annotationClass) {
/* 171 */     List<T> anns = new ArrayList<>();
/*     */     
/* 173 */     List<Class<?>> classes = new ArrayList<>();
/* 174 */     classes.add(clazz);
/*     */     
/* 176 */     classes.addAll(ClassUtils.getAllSuperclasses(clazz));
/* 177 */     classes.addAll(ClassUtils.getAllInterfaces(clazz));
/* 178 */     for (Class<?> aClass : classes) {
/* 179 */       T ann = aClass.getAnnotation(annotationClass);
/* 180 */       if (ann != null) {
/* 181 */         anns.add(ann);
/*     */       }
/*     */       
/* 184 */       ann = aClass.getPackage().getAnnotation(annotationClass);
/* 185 */       if (ann != null) {
/* 186 */         anns.add(ann);
/*     */       }
/*     */     } 
/*     */     
/* 190 */     return anns;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\AnnotationUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */