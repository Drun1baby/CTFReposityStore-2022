package com.opensymphony.xwork2.validator;

import java.util.List;

public interface ActionValidatorManager {
  List<Validator> getValidators(Class paramClass, String paramString1, String paramString2);
  
  List<Validator> getValidators(Class paramClass, String paramString);
  
  void validate(Object paramObject, String paramString) throws ValidationException;
  
  void validate(Object paramObject, String paramString, ValidatorContext paramValidatorContext) throws ValidationException;
  
  void validate(Object paramObject, String paramString1, String paramString2) throws ValidationException;
  
  void validate(Object paramObject, String paramString1, ValidatorContext paramValidatorContext, String paramString2) throws ValidationException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\ActionValidatorManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */