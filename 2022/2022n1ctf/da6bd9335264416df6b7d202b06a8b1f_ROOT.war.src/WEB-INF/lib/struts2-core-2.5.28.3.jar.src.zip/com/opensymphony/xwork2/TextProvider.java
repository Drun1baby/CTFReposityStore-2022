package com.opensymphony.xwork2;

import com.opensymphony.xwork2.util.ValueStack;
import java.util.List;
import java.util.ResourceBundle;

public interface TextProvider {
  boolean hasKey(String paramString);
  
  String getText(String paramString);
  
  String getText(String paramString1, String paramString2);
  
  String getText(String paramString1, String paramString2, String paramString3);
  
  String getText(String paramString, List<?> paramList);
  
  String getText(String paramString, String[] paramArrayOfString);
  
  String getText(String paramString1, String paramString2, List<?> paramList);
  
  String getText(String paramString1, String paramString2, String[] paramArrayOfString);
  
  String getText(String paramString1, String paramString2, List<?> paramList, ValueStack paramValueStack);
  
  String getText(String paramString1, String paramString2, String[] paramArrayOfString, ValueStack paramValueStack);
  
  ResourceBundle getTexts(String paramString);
  
  ResourceBundle getTexts();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\TextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */