/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeTextProvider
/*     */   implements TextProvider
/*     */ {
/*  36 */   private static final Logger LOG = LogManager.getLogger(CompositeTextProvider.class);
/*     */   
/*  38 */   private List<TextProvider> textProviders = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompositeTextProvider(List<TextProvider> textProviders) {
/*  46 */     this.textProviders.addAll(textProviders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompositeTextProvider(TextProvider[] textProviders) {
/*  55 */     this(Arrays.asList(textProviders));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasKey(String key) {
/*  69 */     for (TextProvider tp : this.textProviders) {
/*  70 */       if (tp.hasKey(key)) {
/*  71 */         return true;
/*     */       }
/*     */     } 
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key) {
/*  86 */     return getText(key, key, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue) {
/*  99 */     return getText(key, defaultValue, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, final String obj) {
/* 114 */     return getText(key, defaultValue, new ArrayList()
/*     */         {
/*     */         
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, List<?> args) {
/* 131 */     return getText(key, key, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String[] args) {
/* 144 */     return getText(key, key, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args) {
/* 162 */     for (TextProvider textProvider : this.textProviders) {
/* 163 */       String msg = textProvider.getText(key, defaultValue, args);
/* 164 */       if (msg != null && !msg.equals(defaultValue)) {
/* 165 */         return msg;
/*     */       }
/*     */     } 
/* 168 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args) {
/* 186 */     for (TextProvider textProvider : this.textProviders) {
/* 187 */       String msg = textProvider.getText(key, defaultValue, args);
/* 188 */       if (msg != null && !msg.equals(defaultValue)) {
/* 189 */         return msg;
/*     */       }
/*     */     } 
/* 192 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args, ValueStack stack) {
/* 211 */     for (TextProvider textProvider : this.textProviders) {
/* 212 */       String msg = textProvider.getText(key, defaultValue, args, stack);
/* 213 */       if (msg != null && !msg.equals(defaultValue)) {
/* 214 */         return msg;
/*     */       }
/*     */     } 
/* 217 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args, ValueStack stack) {
/* 235 */     for (TextProvider textProvider : this.textProviders) {
/* 236 */       String msg = textProvider.getText(key, defaultValue, args, stack);
/* 237 */       if (msg != null && !msg.equals(defaultValue)) {
/* 238 */         return msg;
/*     */       }
/*     */     } 
/* 241 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getTexts(String bundleName) {
/* 255 */     for (TextProvider textProvider : this.textProviders) {
/* 256 */       ResourceBundle bundle = textProvider.getTexts(bundleName);
/* 257 */       if (bundle != null) {
/* 258 */         return bundle;
/*     */       }
/*     */     } 
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceBundle getTexts() {
/* 273 */     for (TextProvider textProvider : this.textProviders) {
/* 274 */       ResourceBundle bundle = textProvider.getTexts();
/* 275 */       if (bundle != null) {
/* 276 */         return bundle;
/*     */       }
/*     */     } 
/* 279 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\CompositeTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */