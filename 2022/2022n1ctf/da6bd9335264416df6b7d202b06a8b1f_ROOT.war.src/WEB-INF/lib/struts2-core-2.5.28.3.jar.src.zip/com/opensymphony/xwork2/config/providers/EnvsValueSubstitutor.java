/*    */ package com.opensymphony.xwork2.config.providers;
/*    */ 
/*    */ import org.apache.commons.lang3.text.StrSubstitutor;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvsValueSubstitutor
/*    */   implements ValueSubstitutor
/*    */ {
/* 27 */   private static final Logger LOG = LogManager.getLogger(EnvsValueSubstitutor.class);
/*    */   
/*    */   protected StrSubstitutor strSubstitutor;
/*    */   
/*    */   public EnvsValueSubstitutor() {
/* 32 */     this.strSubstitutor = new StrSubstitutor(System.getenv());
/* 33 */     this.strSubstitutor.setVariablePrefix("${env.");
/* 34 */     this.strSubstitutor.setVariableSuffix('}');
/* 35 */     this.strSubstitutor.setValueDelimiter(":");
/*    */   }
/*    */ 
/*    */   
/*    */   public String substitute(String value) {
/* 40 */     LOG.debug("Substituting value {} with proper System variable or environment variable", value);
/*    */     
/* 42 */     String substituted = StrSubstitutor.replaceSystemProperties(value);
/* 43 */     return this.strSubstitutor.replace(substituted);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\providers\EnvsValueSubstitutor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */