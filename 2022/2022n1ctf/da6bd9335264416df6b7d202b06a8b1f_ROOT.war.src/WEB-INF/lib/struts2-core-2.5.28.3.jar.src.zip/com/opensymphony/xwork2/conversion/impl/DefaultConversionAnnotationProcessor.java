/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.ConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import com.opensymphony.xwork2.conversion.annotations.ConversionRule;
/*     */ import com.opensymphony.xwork2.conversion.annotations.ConversionType;
/*     */ import com.opensymphony.xwork2.conversion.annotations.TypeConversion;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConversionAnnotationProcessor
/*     */   implements ConversionAnnotationProcessor
/*     */ {
/*  41 */   private static final Logger LOG = LogManager.getLogger(DefaultConversionAnnotationProcessor.class);
/*     */   
/*     */   private TypeConverterCreator converterCreator;
/*     */   private TypeConverterHolder converterHolder;
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterCreator(TypeConverterCreator converterCreator) {
/*  48 */     this.converterCreator = converterCreator;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setTypeConverterHolder(TypeConverterHolder converterHolder) {
/*  53 */     this.converterHolder = converterHolder;
/*     */   }
/*     */   
/*     */   public void process(Map<String, Object> mapping, TypeConversion tc, String key) {
/*  57 */     LOG.debug("TypeConversion [{}/{}] with key: [{}]", tc.converter(), tc.converterClass(), key);
/*  58 */     if (key == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  62 */       if (tc.type() == ConversionType.APPLICATION) {
/*  63 */         if (StringUtils.isNoneEmpty(new CharSequence[] { tc.converter() })) {
/*  64 */           this.converterHolder.addDefaultMapping(key, this.converterCreator.createTypeConverter(tc.converter()));
/*     */         } else {
/*  66 */           this.converterHolder.addDefaultMapping(key, this.converterCreator.createTypeConverter(tc.converterClass()));
/*     */         }
/*     */       
/*  69 */       } else if (tc.rule() == ConversionRule.KEY_PROPERTY || tc.rule() == ConversionRule.CREATE_IF_NULL) {
/*  70 */         mapping.put(key, tc.value());
/*     */       
/*     */       }
/*  73 */       else if (tc.rule() != ConversionRule.ELEMENT && tc.rule() != ConversionRule.KEY && tc.rule() != ConversionRule.COLLECTION) {
/*  74 */         if (StringUtils.isNoneEmpty(new CharSequence[] { tc.converter() })) {
/*  75 */           mapping.put(key, this.converterCreator.createTypeConverter(tc.converter()));
/*     */         } else {
/*  77 */           mapping.put(key, this.converterCreator.createTypeConverter(tc.converterClass()));
/*     */         }
/*     */       
/*     */       }
/*  81 */       else if (tc.rule() == ConversionRule.KEY) {
/*     */         Class<?> converterClass;
/*  83 */         if (StringUtils.isNoneEmpty(new CharSequence[] { tc.converter() })) {
/*  84 */           converterClass = ClassLoaderUtil.loadClass(tc.converter(), getClass());
/*     */         } else {
/*  86 */           converterClass = tc.converterClass();
/*     */         } 
/*     */         
/*  89 */         LOG.debug("Converter class: [{}]", converterClass);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  94 */         if (converterClass.isAssignableFrom(TypeConverter.class)) {
/*  95 */           if (StringUtils.isNoneEmpty(new CharSequence[] { tc.converter() })) {
/*  96 */             mapping.put(key, this.converterCreator.createTypeConverter(tc.converter()));
/*     */           } else {
/*  98 */             mapping.put(key, this.converterCreator.createTypeConverter(tc.converterClass()));
/*     */           } 
/*     */         } else {
/* 101 */           mapping.put(key, converterClass);
/* 102 */           LOG.debug("Object placed in mapping for key [{}] is [{}]", key, mapping.get(key));
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 107 */       else if (StringUtils.isNoneEmpty(new CharSequence[] { tc.converter() })) {
/* 108 */         mapping.put(key, ClassLoaderUtil.loadClass(tc.converter(), getClass()));
/*     */       } else {
/* 110 */         mapping.put(key, tc.converterClass());
/*     */       }
/*     */     
/*     */     }
/* 114 */     catch (Exception e) {
/* 115 */       LOG.debug("Got exception for {}", key, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultConversionAnnotationProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */