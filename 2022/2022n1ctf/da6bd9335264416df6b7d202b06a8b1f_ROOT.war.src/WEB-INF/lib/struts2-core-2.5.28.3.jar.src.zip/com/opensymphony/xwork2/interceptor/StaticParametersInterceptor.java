/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.LocalizedTextProvider;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.Parameterizable;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClearableValueStack;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticParametersInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*     */   private boolean parse;
/*     */   private boolean overwrite;
/*     */   private boolean merge = true;
/*     */   private boolean devMode = false;
/*  95 */   private static final Logger LOG = LogManager.getLogger(StaticParametersInterceptor.class);
/*     */   
/*     */   private ValueStackFactory valueStackFactory;
/*     */   private LocalizedTextProvider localizedTextProvider;
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 102 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   
/*     */   @Inject("devMode")
/*     */   public void setDevMode(String mode) {
/* 107 */     this.devMode = BooleanUtils.toBoolean(mode);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/* 112 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */   
/*     */   public void setParse(String value) {
/* 116 */     this.parse = BooleanUtils.toBoolean(value);
/*     */   }
/*     */   
/*     */   public void setMerge(String value) {
/* 120 */     this.merge = BooleanUtils.toBoolean(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverwrite(String value) {
/* 130 */     this.overwrite = BooleanUtils.toBoolean(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 135 */     ActionConfig config = invocation.getProxy().getConfig();
/* 136 */     Object action = invocation.getAction();
/*     */     
/* 138 */     Map<String, String> parameters = config.getParams();
/*     */     
/* 140 */     LOG.debug("Setting static parameters: {}", parameters);
/*     */ 
/*     */     
/* 143 */     if (action instanceof Parameterizable) {
/* 144 */       ((Parameterizable)action).setParams(parameters);
/*     */     }
/*     */     
/* 147 */     if (parameters != null) {
/* 148 */       ActionContext ac = ActionContext.getContext();
/* 149 */       Map<String, Object> contextMap = ac.getContextMap();
/*     */       try {
/* 151 */         ReflectionContextState.setCreatingNullObjects(contextMap, true);
/* 152 */         ReflectionContextState.setReportingConversionErrors(contextMap, true);
/* 153 */         ValueStack stack = ac.getValueStack();
/*     */         
/* 155 */         ValueStack newStack = this.valueStackFactory.createValueStack(stack);
/* 156 */         boolean clearableStack = newStack instanceof ClearableValueStack;
/* 157 */         if (clearableStack) {
/*     */ 
/*     */           
/* 160 */           ((ClearableValueStack)newStack).clearContextValues();
/* 161 */           Map<String, Object> context = newStack.getContext();
/* 162 */           ReflectionContextState.setCreatingNullObjects(context, true);
/* 163 */           ReflectionContextState.setDenyMethodExecution(context, true);
/* 164 */           ReflectionContextState.setReportingConversionErrors(context, true);
/*     */ 
/*     */           
/* 167 */           context.put("com.opensymphony.xwork2.ActionContext.locale", stack.getContext().get("com.opensymphony.xwork2.ActionContext.locale"));
/*     */         } 
/*     */         
/* 170 */         for (Map.Entry<String, String> entry : parameters.entrySet()) {
/* 171 */           Object val = entry.getValue();
/* 172 */           if (this.parse && val instanceof String) {
/* 173 */             val = TextParseUtil.translateVariables(val.toString(), stack);
/*     */           }
/*     */           try {
/* 176 */             newStack.setValue(entry.getKey(), val);
/* 177 */           } catch (RuntimeException e) {
/* 178 */             if (this.devMode) {
/*     */               
/* 180 */               String developerNotification = this.localizedTextProvider.findText(ParametersInterceptor.class, "devmode.notification", ActionContext.getContext().getLocale(), "Developer Notification:\n{0}", new Object[] { "Unexpected Exception caught setting '" + (String)entry.getKey() + "' on '" + action.getClass() + ": " + e.getMessage() });
/*     */ 
/*     */               
/* 183 */               LOG.error(developerNotification);
/* 184 */               if (action instanceof ValidationAware) {
/* 185 */                 ((ValidationAware)action).addActionMessage(developerNotification);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 191 */         if (clearableStack && stack.getContext() != null && newStack.getContext() != null) {
/* 192 */           stack.getContext().put("com.opensymphony.xwork2.ActionContext.conversionErrors", newStack.getContext().get("com.opensymphony.xwork2.ActionContext.conversionErrors"));
/*     */         }
/* 194 */         if (this.merge)
/* 195 */           addParametersToContext(ac, parameters); 
/*     */       } finally {
/* 197 */         ReflectionContextState.setCreatingNullObjects(contextMap, false);
/* 198 */         ReflectionContextState.setReportingConversionErrors(contextMap, false);
/*     */       } 
/*     */     } 
/* 201 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> retrieveParameters(ActionContext ac) {
/* 211 */     ActionConfig config = ac.getActionInvocation().getProxy().getConfig();
/* 212 */     if (config != null) {
/* 213 */       return config.getParams();
/*     */     }
/* 215 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addParametersToContext(ActionContext ac, Map<String, ?> newParams) {
/*     */     HttpParameters.Builder combinedParams;
/* 228 */     HttpParameters previousParams = ac.getParameters();
/*     */ 
/*     */     
/* 231 */     if (this.overwrite) {
/* 232 */       combinedParams = HttpParameters.create().withParent(previousParams);
/* 233 */       combinedParams = combinedParams.withExtraParams(newParams);
/*     */     } else {
/* 235 */       combinedParams = HttpParameters.create(newParams);
/* 236 */       combinedParams = combinedParams.withExtraParams((Map)previousParams);
/*     */     } 
/* 238 */     ac.setParameters(combinedParams.build());
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\StaticParametersInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */