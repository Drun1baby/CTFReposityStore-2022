/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodFilterInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*  75 */   private static final Logger LOG = LogManager.getLogger(MethodFilterInterceptor.class);
/*     */   
/*  77 */   protected Set<String> excludeMethods = Collections.emptySet();
/*  78 */   protected Set<String> includeMethods = Collections.emptySet();
/*     */   
/*     */   public void setExcludeMethods(String excludeMethods) {
/*  81 */     this.excludeMethods = TextParseUtil.commaDelimitedStringToSet(excludeMethods);
/*     */   }
/*     */   
/*     */   public Set<String> getExcludeMethodsSet() {
/*  85 */     return this.excludeMethods;
/*     */   }
/*     */   
/*     */   public void setIncludeMethods(String includeMethods) {
/*  89 */     this.includeMethods = TextParseUtil.commaDelimitedStringToSet(includeMethods);
/*     */   }
/*     */   
/*     */   public Set<String> getIncludeMethodsSet() {
/*  93 */     return this.includeMethods;
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/*  98 */     if (applyInterceptor(invocation)) {
/*  99 */       return doIntercept(invocation);
/*     */     }
/* 101 */     return invocation.invoke();
/*     */   }
/*     */   
/*     */   protected boolean applyInterceptor(ActionInvocation invocation) {
/* 105 */     String method = invocation.getProxy().getMethod();
/*     */     
/* 107 */     boolean applyMethod = MethodFilterInterceptorUtil.applyMethod(this.excludeMethods, this.includeMethods, method);
/* 108 */     if (!applyMethod) {
/* 109 */       LOG.debug("Skipping Interceptor... Method [{}] found in exclude list.", method);
/*     */     }
/* 111 */     return applyMethod;
/*     */   }
/*     */   
/*     */   protected abstract String doIntercept(ActionInvocation paramActionInvocation) throws Exception;
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\MethodFilterInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */