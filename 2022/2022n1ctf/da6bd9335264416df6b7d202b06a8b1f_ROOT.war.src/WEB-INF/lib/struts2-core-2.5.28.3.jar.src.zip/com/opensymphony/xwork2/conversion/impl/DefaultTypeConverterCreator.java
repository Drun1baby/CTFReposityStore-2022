/*    */ package com.opensymphony.xwork2.conversion.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*    */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.ognl.XWorkTypeConverterWrapper;
/*    */ import ognl.TypeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultTypeConverterCreator
/*    */   implements TypeConverterCreator
/*    */ {
/*    */   private ObjectFactory objectFactory;
/*    */   
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 36 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   
/*    */   public TypeConverter createTypeConverter(String className) throws Exception {
/* 40 */     Object obj = this.objectFactory.buildBean(className, null);
/* 41 */     return getTypeConverter(obj);
/*    */   }
/*    */   
/*    */   public TypeConverter createTypeConverter(Class<?> clazz) throws Exception {
/* 45 */     Object obj = this.objectFactory.buildBean(clazz, null);
/* 46 */     return getTypeConverter(obj);
/*    */   }
/*    */   
/*    */   protected TypeConverter getTypeConverter(Object obj) {
/* 50 */     if (obj instanceof TypeConverter) {
/* 51 */       return (TypeConverter)obj;
/*    */     }
/*    */     
/* 54 */     if (obj instanceof TypeConverter) {
/* 55 */       return (TypeConverter)new XWorkTypeConverterWrapper((TypeConverter)obj);
/*    */     }
/* 57 */     throw new IllegalArgumentException("Type converter class " + obj.getClass() + " doesn't implement com.opensymphony.xwork2.conversion.TypeConverter");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\DefaultTypeConverterCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */