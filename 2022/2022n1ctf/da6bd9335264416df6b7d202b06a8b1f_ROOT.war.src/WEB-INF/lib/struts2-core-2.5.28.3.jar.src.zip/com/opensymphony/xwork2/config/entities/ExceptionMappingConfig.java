/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionMappingConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   protected String name;
/*     */   protected String exceptionClassName;
/*     */   protected String result;
/*     */   protected Map<String, String> params;
/*     */   
/*     */   protected ExceptionMappingConfig(String name, String exceptionClassName, String result) {
/*  43 */     this.name = name;
/*  44 */     this.exceptionClassName = exceptionClassName;
/*  45 */     this.result = result;
/*  46 */     this.params = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   protected ExceptionMappingConfig(ExceptionMappingConfig target) {
/*  50 */     this.name = target.name;
/*  51 */     this.exceptionClassName = target.exceptionClassName;
/*  52 */     this.result = target.result;
/*  53 */     this.params = new LinkedHashMap<>(target.params);
/*  54 */     this.location = target.location;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  58 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getExceptionClassName() {
/*  62 */     return this.exceptionClassName;
/*     */   }
/*     */   
/*     */   public String getResult() {
/*  66 */     return this.result;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParams() {
/*  70 */     return this.params;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  75 */     if (this == o) {
/*  76 */       return true;
/*     */     }
/*     */     
/*  79 */     if (!(o instanceof ExceptionMappingConfig)) {
/*  80 */       return false;
/*     */     }
/*     */     
/*  83 */     ExceptionMappingConfig exceptionMappingConfig = (ExceptionMappingConfig)o;
/*     */     
/*  85 */     if ((this.name != null) ? !this.name.equals(exceptionMappingConfig.name) : (exceptionMappingConfig.name != null)) {
/*  86 */       return false;
/*     */     }
/*     */     
/*  89 */     if ((this.exceptionClassName != null) ? !this.exceptionClassName.equals(exceptionMappingConfig.exceptionClassName) : (exceptionMappingConfig.exceptionClassName != null))
/*     */     {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     if ((this.result != null) ? !this.result.equals(exceptionMappingConfig.result) : (exceptionMappingConfig.result != null))
/*     */     {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     if ((this.params != null) ? !this.params.equals(exceptionMappingConfig.params) : (exceptionMappingConfig.params != null))
/*     */     {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 110 */     int hashCode = (this.name != null) ? this.name.hashCode() : 0;
/* 111 */     hashCode = 29 * hashCode + ((this.exceptionClassName != null) ? this.exceptionClassName.hashCode() : 0);
/* 112 */     hashCode = 29 * hashCode + ((this.result != null) ? this.result.hashCode() : 0);
/* 113 */     hashCode = 29 * hashCode + ((this.params != null) ? this.params.hashCode() : 0);
/*     */     
/* 115 */     return hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return "ExceptionMappingConfig: [" + this.name + "] handle [" + this.exceptionClassName + "] to result [" + this.result + "] with params " + this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     protected ExceptionMappingConfig target;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(ExceptionMappingConfig toClone) {
/* 134 */       this.target = new ExceptionMappingConfig(toClone);
/*     */     }
/*     */     
/*     */     public Builder(String name, String exceptionClassName, String result) {
/* 138 */       this.target = new ExceptionMappingConfig(name, exceptionClassName, result);
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 142 */       this.target.name = name;
/* 143 */       return this;
/*     */     }
/*     */     
/*     */     public Builder exceptionClassName(String name) {
/* 147 */       this.target.exceptionClassName = name;
/* 148 */       return this;
/*     */     }
/*     */     
/*     */     public Builder result(String result) {
/* 152 */       this.target.result = result;
/* 153 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, String value) {
/* 157 */       this.target.params.put(name, value);
/* 158 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, String> params) {
/* 162 */       this.target.params.putAll(params);
/* 163 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 167 */       this.target.location = loc;
/* 168 */       return this;
/*     */     }
/*     */     
/*     */     public ExceptionMappingConfig build() {
/* 172 */       embalmTarget();
/* 173 */       ExceptionMappingConfig result = this.target;
/* 174 */       this.target = new ExceptionMappingConfig(this.target);
/* 175 */       return result;
/*     */     }
/*     */     
/*     */     protected void embalmTarget() {
/* 179 */       this.target.params = Collections.unmodifiableMap(this.target.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\ExceptionMappingConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */