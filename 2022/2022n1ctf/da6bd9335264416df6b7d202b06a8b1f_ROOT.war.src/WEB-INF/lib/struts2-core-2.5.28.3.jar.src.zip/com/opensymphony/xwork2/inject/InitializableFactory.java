/*    */ package com.opensymphony.xwork2.inject;
/*    */ 
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InitializableFactory<T>
/*    */   implements InternalFactory<T>
/*    */ {
/* 26 */   private static final Logger LOG = LogManager.getLogger(InitializableFactory.class);
/*    */   
/*    */   private InternalFactory<T> internalFactory;
/*    */   
/*    */   private InitializableFactory(InternalFactory<T> internalFactory) {
/* 31 */     this.internalFactory = internalFactory;
/*    */   }
/*    */   
/*    */   public static <T> InternalFactory<T> wrapIfNeeded(InternalFactory<T> internalFactory) {
/* 35 */     if (Initializable.class.isAssignableFrom(internalFactory.type())) {
/* 36 */       return new InitializableFactory<>(internalFactory);
/*    */     }
/* 38 */     return internalFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public T create(InternalContext context) {
/* 43 */     T instance = this.internalFactory.create(context);
/* 44 */     if (Initializable.class.isAssignableFrom(instance.getClass())) {
/* 45 */       ((Initializable)Initializable.class.cast(instance)).init();
/*    */     } else {
/* 47 */       LOG.error("Class {} is not marked as {}!", this.internalFactory.getClass().getName(), Initializable.class.getName());
/*    */     } 
/* 49 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<? extends T> type() {
/* 54 */     return this.internalFactory.type();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\InitializableFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */