package com.opensymphony.xwork2.util.logging;

@Deprecated
public interface Logger {
  void trace(String paramString, String... paramVarArgs);
  
  void trace(String paramString, Object... paramVarArgs);
  
  void trace(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isTraceEnabled();
  
  void debug(String paramString, String... paramVarArgs);
  
  void debug(String paramString, Object... paramVarArgs);
  
  void debug(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isDebugEnabled();
  
  void info(String paramString, String... paramVarArgs);
  
  void info(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isInfoEnabled();
  
  void warn(String paramString, String... paramVarArgs);
  
  void warn(String paramString, Object... paramVarArgs);
  
  void warn(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isWarnEnabled();
  
  void error(String paramString, String... paramVarArgs);
  
  void error(String paramString, Object... paramVarArgs);
  
  void error(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isErrorEnabled();
  
  void fatal(String paramString, String... paramVarArgs);
  
  void fatal(String paramString, Throwable paramThrowable, String... paramVarArgs);
  
  boolean isFatalEnabled();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\Logger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */