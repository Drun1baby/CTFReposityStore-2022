/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalLocalizedTextProvider
/*     */   extends AbstractLocalizedTextProvider
/*     */ {
/*  35 */   private static final Logger LOG = LogManager.getLogger(GlobalLocalizedTextProvider.class);
/*     */   
/*     */   public GlobalLocalizedTextProvider() {
/*  38 */     addDefaultResourceBundle("com/opensymphony/xwork2/xwork-messages");
/*  39 */     addDefaultResourceBundle("org/apache/struts2/struts-messages");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class aClass, String aTextName, Locale locale) {
/*  54 */     return findText(aClass, aTextName, locale, aTextName, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class aClass, String aTextName, Locale locale, String defaultMessage, Object[] args) {
/* 105 */     ValueStack valueStack = ActionContext.getContext().getValueStack();
/* 106 */     return findText(aClass, aTextName, locale, defaultMessage, args, valueStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(Class aClass, String aTextName, Locale locale, String defaultMessage, Object[] args, ValueStack valueStack) {
/*     */     AbstractLocalizedTextProvider.GetDefaultMessageReturnArg result;
/* 163 */     String indexedTextName = null;
/* 164 */     if (aTextName == null) {
/* 165 */       LOG.warn("Trying to find text with null key!");
/* 166 */       aTextName = "";
/*     */     } 
/*     */     
/* 169 */     if (aTextName.contains("[")) {
/* 170 */       int i = -1;
/*     */       
/* 172 */       indexedTextName = aTextName;
/*     */       
/* 174 */       while ((i = indexedTextName.indexOf('[', i + 1)) != -1) {
/* 175 */         int j = indexedTextName.indexOf(']', i);
/* 176 */         String a = indexedTextName.substring(0, i);
/* 177 */         String b = indexedTextName.substring(j);
/* 178 */         indexedTextName = a + "[*" + b;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 184 */     if (indexedTextName == null) {
/* 185 */       result = getDefaultMessage(aTextName, locale, valueStack, args, defaultMessage);
/*     */     } else {
/* 187 */       result = getDefaultMessage(aTextName, locale, valueStack, args, null);
/* 188 */       if (result != null && result.message != null) {
/* 189 */         return result.message;
/*     */       }
/* 191 */       result = getDefaultMessage(indexedTextName, locale, valueStack, args, defaultMessage);
/*     */     } 
/*     */ 
/*     */     
/* 195 */     if (unableToFindTextForKey(result) && LOG.isDebugEnabled()) {
/* 196 */       String warn = "Unable to find text for key '" + aTextName + "' ";
/* 197 */       if (indexedTextName != null) {
/* 198 */         warn = warn + " or indexed key '" + indexedTextName + "' ";
/*     */       }
/* 200 */       warn = warn + "in class '" + aClass.getName() + "' and locale '" + locale + "'";
/* 201 */       LOG.debug(warn);
/*     */     } 
/*     */     
/* 204 */     return (result != null) ? result.message : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(ResourceBundle bundle, String aTextName, Locale locale) {
/* 226 */     return findText(bundle, aTextName, locale, aTextName, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findText(ResourceBundle bundle, String aTextName, Locale locale, String defaultMessage, Object[] args) {
/* 253 */     ValueStack valueStack = ActionContext.getContext().getValueStack();
/* 254 */     return findText(bundle, aTextName, locale, defaultMessage, args, valueStack);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\GlobalLocalizedTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */