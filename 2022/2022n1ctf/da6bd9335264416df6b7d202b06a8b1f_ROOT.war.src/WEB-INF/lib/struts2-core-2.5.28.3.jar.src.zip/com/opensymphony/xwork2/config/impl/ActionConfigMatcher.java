/*     */ package com.opensymphony.xwork2.config.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionConfigMatcher
/*     */   extends AbstractMatcher<ActionConfig>
/*     */   implements Serializable
/*     */ {
/*     */   public ActionConfigMatcher(PatternMatcher<?> patternMatcher, Map<String, ActionConfig> configs, boolean looseMatch) {
/*  61 */     this(patternMatcher, configs, looseMatch, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionConfigMatcher(PatternMatcher<?> patternMatcher, Map<String, ActionConfig> configs, boolean looseMatch, boolean appendNamedParameters) {
/*  87 */     super(patternMatcher, appendNamedParameters);
/*  88 */     for (Map.Entry<String, ActionConfig> entry : configs.entrySet()) {
/*  89 */       addPattern(entry.getKey(), entry.getValue(), looseMatch);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionConfig convert(String path, ActionConfig orig, Map<String, String> vars) {
/* 106 */     String methodName = convertParam(orig.getMethodName(), vars);
/*     */     
/* 108 */     if (StringUtils.isEmpty(methodName)) {
/* 109 */       methodName = "execute";
/*     */     }
/*     */     
/* 112 */     if (!orig.isAllowedMethod(methodName)) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     String className = convertParam(orig.getClassName(), vars);
/* 117 */     String pkgName = convertParam(orig.getPackageName(), vars);
/*     */     
/* 119 */     Map<String, String> params = replaceParameters(orig.getParams(), vars);
/*     */     
/* 121 */     Map<String, ResultConfig> results = new LinkedHashMap<>();
/* 122 */     for (String name : orig.getResults().keySet()) {
/* 123 */       ResultConfig result = (ResultConfig)orig.getResults().get(name);
/* 124 */       name = convertParam(name, vars);
/* 125 */       ResultConfig r = (new ResultConfig.Builder(name, convertParam(result.getClassName(), vars))).addParams(replaceParameters(result.getParams(), vars)).build();
/*     */ 
/*     */       
/* 128 */       results.put(name, r);
/*     */     } 
/*     */     
/* 131 */     List<ExceptionMappingConfig> exs = new ArrayList<>();
/* 132 */     for (ExceptionMappingConfig ex : orig.getExceptionMappings()) {
/* 133 */       String name = convertParam(ex.getName(), vars);
/* 134 */       String exClassName = convertParam(ex.getExceptionClassName(), vars);
/* 135 */       String exResult = convertParam(ex.getResult(), vars);
/* 136 */       Map<String, String> exParams = replaceParameters(ex.getParams(), vars);
/* 137 */       ExceptionMappingConfig e = (new ExceptionMappingConfig.Builder(name, exClassName, exResult)).addParams(exParams).build();
/* 138 */       exs.add(e);
/*     */     } 
/*     */     
/* 141 */     return (new ActionConfig.Builder(pkgName, orig.getName(), className)).methodName(methodName).addParams(params).addResultConfigs(results).setStrictMethodInvocation(orig.isStrictMethodInvocation()).addAllowedMethod(orig.getAllowedMethods()).addInterceptors(orig.getInterceptors()).addExceptionMappings(exs).location(orig.getLocation()).build();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\ActionConfigMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */