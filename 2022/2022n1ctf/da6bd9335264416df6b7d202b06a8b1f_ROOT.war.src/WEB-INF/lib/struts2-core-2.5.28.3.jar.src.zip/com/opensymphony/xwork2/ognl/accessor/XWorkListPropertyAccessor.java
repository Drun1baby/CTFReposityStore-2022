/*     */ package com.opensymphony.xwork2.ognl.accessor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import ognl.ListPropertyAccessor;
/*     */ import ognl.OgnlException;
/*     */ import ognl.PropertyAccessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkListPropertyAccessor
/*     */   extends ListPropertyAccessor
/*     */ {
/*  46 */   private XWorkCollectionPropertyAccessor _sAcc = new XWorkCollectionPropertyAccessor();
/*     */   
/*     */   private XWorkConverter xworkConverter;
/*     */   private ObjectFactory objectFactory;
/*     */   private ObjectTypeDeterminer objectTypeDeterminer;
/*     */   private OgnlUtil ognlUtil;
/*  52 */   private int autoGrowCollectionLimit = 255;
/*     */   
/*     */   @Deprecated
/*     */   @Inject(value = "xwork.autoGrowCollectionLimit", required = false)
/*     */   public void setDeprecatedAutoGrowCollectionLimit(String value) {
/*  57 */     this.autoGrowCollectionLimit = Integer.valueOf(value).intValue();
/*     */   }
/*     */   
/*     */   @Inject(value = "struts.ognl.autoGrowthCollectionLimit", required = false)
/*     */   public void setAutoGrowCollectionLimit(String value) {
/*  62 */     this.autoGrowCollectionLimit = Integer.parseInt(value);
/*     */   }
/*     */   
/*     */   @Inject("java.util.Collection")
/*     */   public void setXWorkCollectionPropertyAccessor(PropertyAccessor acc) {
/*  67 */     this._sAcc = (XWorkCollectionPropertyAccessor)acc;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setXWorkConverter(XWorkConverter conv) {
/*  72 */     this.xworkConverter = conv;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  77 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectTypeDeterminer(ObjectTypeDeterminer ot) {
/*  82 */     this.objectTypeDeterminer = ot;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setOgnlUtil(OgnlUtil util) {
/*  87 */     this.ognlUtil = util;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*  93 */     if (ReflectionContextState.isGettingByKeyProperty(context) || name.equals("makeNew"))
/*     */     {
/*  95 */       return this._sAcc.getProperty(context, target, name); } 
/*  96 */     if (name instanceof String) {
/*  97 */       return super.getProperty(context, target, name);
/*     */     }
/*  99 */     ReflectionContextState.updateCurrentPropertyPath(context, name);
/* 100 */     Class lastClass = (Class)context.get("last.bean.accessed");
/* 101 */     String lastProperty = (String)context.get("last.property.accessed");
/*     */     
/* 103 */     if (name instanceof Number && ReflectionContextState.isCreatingNullObjects(context) && this.objectTypeDeterminer.shouldCreateIfNew(lastClass, lastProperty, target, null, true)) {
/*     */ 
/*     */ 
/*     */       
/* 107 */       List<Object> list = (List)target;
/* 108 */       int index = ((Number)name).intValue();
/* 109 */       int listSize = list.size();
/*     */       
/* 111 */       if (lastClass == null || lastProperty == null) {
/* 112 */         return super.getProperty(context, target, name);
/*     */       }
/* 114 */       Class beanClass = this.objectTypeDeterminer.getElementClass(lastClass, lastProperty, name);
/* 115 */       if (listSize <= index) {
/*     */         Object result;
/*     */         
/* 118 */         for (int i = listSize; i < index; i++) {
/* 119 */           list.add(null);
/*     */         }
/*     */         try {
/* 122 */           list.add(index, result = this.objectFactory.buildBean(beanClass, context));
/* 123 */         } catch (Exception exc) {
/* 124 */           throw new XWorkException(exc);
/*     */         } 
/* 126 */         return result;
/* 127 */       }  if (list.get(index) == null) {
/*     */         Object result;
/*     */         try {
/* 130 */           list.set(index, result = this.objectFactory.buildBean(beanClass, context));
/* 131 */         } catch (Exception exc) {
/* 132 */           throw new XWorkException(exc);
/*     */         } 
/* 134 */         return result;
/*     */       } 
/*     */     } 
/* 137 */     return super.getProperty(context, target, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 144 */     Class lastClass = (Class)context.get("last.bean.accessed");
/* 145 */     String lastProperty = (String)context.get("last.property.accessed");
/* 146 */     Class convertToClass = this.objectTypeDeterminer.getElementClass(lastClass, lastProperty, name);
/*     */     
/* 148 */     if (name instanceof String && value.getClass().isArray()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 153 */       Collection<Object> c = (Collection)target;
/* 154 */       Object[] values = (Object[])value;
/* 155 */       for (Object v : values) {
/*     */         try {
/* 157 */           Object o = this.objectFactory.buildBean(convertToClass, context);
/* 158 */           this.ognlUtil.setValue((String)name, context, o, v);
/* 159 */           c.add(o);
/* 160 */         } catch (Exception e) {
/* 161 */           throw new OgnlException("Error converting given String values for Collection.", e);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     Object realValue = getRealValue(context, value, convertToClass);
/*     */     
/* 172 */     if (target instanceof List && name instanceof Number) {
/*     */       
/* 174 */       List list = (List)target;
/* 175 */       int listSize = list.size();
/* 176 */       int count = ((Number)name).intValue();
/* 177 */       if (count > this.autoGrowCollectionLimit) {
/* 178 */         throw new OgnlException("Error auto growing collection size to " + count + " which limited to " + this.autoGrowCollectionLimit);
/*     */       }
/* 180 */       if (count >= listSize) {
/* 181 */         for (int i = listSize; i <= count; i++) {
/* 182 */           list.add(null);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 187 */     super.setProperty(context, target, name, realValue);
/*     */   }
/*     */   
/*     */   private Object getRealValue(Map context, Object value, Class convertToClass) {
/* 191 */     if (value == null || convertToClass == null) {
/* 192 */       return value;
/*     */     }
/* 194 */     return this.xworkConverter.convertValue(context, value, convertToClass);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\XWorkListPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */