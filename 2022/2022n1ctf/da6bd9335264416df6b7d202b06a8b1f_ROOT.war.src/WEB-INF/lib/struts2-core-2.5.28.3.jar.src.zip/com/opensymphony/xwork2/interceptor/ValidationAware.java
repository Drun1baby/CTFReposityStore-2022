package com.opensymphony.xwork2.interceptor;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface ValidationAware {
  void setActionErrors(Collection<String> paramCollection);
  
  Collection<String> getActionErrors();
  
  void setActionMessages(Collection<String> paramCollection);
  
  Collection<String> getActionMessages();
  
  void setFieldErrors(Map<String, List<String>> paramMap);
  
  Map<String, List<String>> getFieldErrors();
  
  void addActionError(String paramString);
  
  void addActionMessage(String paramString);
  
  void addFieldError(String paramString1, String paramString2);
  
  boolean hasActionErrors();
  
  boolean hasActionMessages();
  
  boolean hasErrors();
  
  boolean hasFieldErrors();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ValidationAware.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */