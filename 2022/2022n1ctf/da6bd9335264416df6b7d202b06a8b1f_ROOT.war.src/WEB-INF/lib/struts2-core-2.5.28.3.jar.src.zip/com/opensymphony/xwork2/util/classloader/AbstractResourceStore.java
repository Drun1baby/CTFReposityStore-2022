/*    */ package com.opensymphony.xwork2.util.classloader;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractResourceStore
/*    */   implements ResourceStore
/*    */ {
/* 30 */   private static final Logger log = LogManager.getLogger(JarResourceStore.class);
/*    */   protected final File file;
/*    */   
/*    */   public AbstractResourceStore(File file) {
/* 34 */     this.file = file;
/*    */   }
/*    */   
/*    */   protected void closeQuietly(InputStream is) {
/*    */     try {
/* 39 */       if (is != null) {
/* 40 */         is.close();
/*    */       }
/* 42 */     } catch (IOException e) {
/* 43 */       log.error("Unable to close file input stream", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(String pResourceName, byte[] pResourceData) {}
/*    */   
/*    */   public String toString() {
/* 51 */     return getClass().getName() + this.file.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\classloader\AbstractResourceStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */