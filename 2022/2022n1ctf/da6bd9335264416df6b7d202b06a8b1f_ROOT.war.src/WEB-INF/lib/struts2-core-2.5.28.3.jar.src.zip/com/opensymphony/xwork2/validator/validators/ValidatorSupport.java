/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.validator.DelegatingValidatorContext;
/*     */ import com.opensymphony.xwork2.validator.ShortCircuitableValidator;
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import com.opensymphony.xwork2.validator.Validator;
/*     */ import com.opensymphony.xwork2.validator.ValidatorContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValidatorSupport
/*     */   implements Validator, ShortCircuitableValidator
/*     */ {
/*  42 */   private static final Logger LOG = LogManager.getLogger(ValidatorSupport.class);
/*     */   
/*     */   public static final String EMPTY_STRING = "";
/*     */   
/*     */   private ValidatorContext validatorContext;
/*     */   
/*     */   private boolean shortCircuit;
/*     */   private String type;
/*     */   private String[] messageParameters;
/*  51 */   protected String defaultMessage = "";
/*     */   protected String messageKey;
/*     */   protected ValueStack stack;
/*     */   protected TextProviderFactory textProviderFactory;
/*     */   
/*     */   @Inject
/*     */   public void setTextProviderFactory(TextProviderFactory textProviderFactory) {
/*  58 */     this.textProviderFactory = textProviderFactory;
/*     */   }
/*     */   
/*     */   public void setValueStack(ValueStack stack) {
/*  62 */     this.stack = stack;
/*     */   }
/*     */   
/*     */   public void setDefaultMessage(String message) {
/*  66 */     if (StringUtils.isNotEmpty(message)) {
/*  67 */       this.defaultMessage = message;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDefaultMessage() {
/*  72 */     return this.defaultMessage;
/*     */   }
/*     */   
/*     */   public String getMessage(Object object) {
/*     */     String message;
/*  77 */     boolean pop = false;
/*     */     
/*  79 */     if (!this.stack.getRoot().contains(object)) {
/*  80 */       this.stack.push(object);
/*  81 */       pop = true;
/*     */     } 
/*     */     
/*  84 */     this.stack.push(this);
/*     */     
/*  86 */     if (this.messageKey != null) {
/*  87 */       if (this.defaultMessage == null || "".equals(this.defaultMessage.trim())) {
/*  88 */         this.defaultMessage = this.messageKey;
/*     */       }
/*  90 */       if (this.validatorContext == null) {
/*  91 */         this.validatorContext = (ValidatorContext)new DelegatingValidatorContext(object, this.textProviderFactory);
/*     */       }
/*  93 */       List<Object> parsedMessageParameters = null;
/*  94 */       if (this.messageParameters != null) {
/*  95 */         parsedMessageParameters = new ArrayList();
/*  96 */         for (String messageParameter : this.messageParameters) {
/*  97 */           if (messageParameter != null) {
/*     */             try {
/*  99 */               Object val = this.stack.findValue(messageParameter);
/* 100 */               parsedMessageParameters.add(val);
/* 101 */             } catch (Exception e) {
/*     */ 
/*     */               
/* 104 */               LOG.warn("exception while parsing message parameter [{}]", messageParameter, e);
/* 105 */               parsedMessageParameters.add(messageParameter);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 111 */       message = this.validatorContext.getText(this.messageKey, this.defaultMessage, parsedMessageParameters);
/*     */     } else {
/* 113 */       message = this.defaultMessage;
/*     */     } 
/*     */     
/* 116 */     if (StringUtils.isNotBlank(message)) {
/* 117 */       message = TextParseUtil.translateVariables(message, this.stack);
/*     */     }
/* 119 */     this.stack.pop();
/*     */     
/* 121 */     if (pop) {
/* 122 */       this.stack.pop();
/*     */     }
/*     */     
/* 125 */     return message;
/*     */   }
/*     */   
/*     */   public void setMessageKey(String key) {
/* 129 */     this.messageKey = key;
/*     */   }
/*     */   
/*     */   public String getMessageKey() {
/* 133 */     return this.messageKey;
/*     */   }
/*     */   
/*     */   public String[] getMessageParameters() {
/* 137 */     return this.messageParameters;
/*     */   }
/*     */   
/*     */   public void setMessageParameters(String[] messageParameters) {
/* 141 */     this.messageParameters = messageParameters;
/*     */   }
/*     */   
/*     */   public void setShortCircuit(boolean shortcircuit) {
/* 145 */     this.shortCircuit = shortcircuit;
/*     */   }
/*     */   
/*     */   public boolean isShortCircuit() {
/* 149 */     return this.shortCircuit;
/*     */   }
/*     */   
/*     */   public void setValidatorContext(ValidatorContext validatorContext) {
/* 153 */     this.validatorContext = validatorContext;
/*     */   }
/*     */   
/*     */   public ValidatorContext getValidatorContext() {
/* 157 */     return this.validatorContext;
/*     */   }
/*     */   
/*     */   public void setValidatorType(String type) {
/* 161 */     this.type = type;
/*     */   }
/*     */   
/*     */   public String getValidatorType() {
/* 165 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object parse(String expression, Class type) {
/* 176 */     if (expression == null) {
/* 177 */       return null;
/*     */     }
/* 179 */     return TextParseUtil.translateVariables('$', expression, this.stack, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getFieldValue(String name, Object object) throws ValidationException {
/* 193 */     boolean pop = false;
/*     */     
/* 195 */     if (!this.stack.getRoot().contains(object)) {
/* 196 */       this.stack.push(object);
/* 197 */       pop = true;
/*     */     } 
/*     */     
/* 200 */     Object retVal = this.stack.findValue(name);
/*     */     
/* 202 */     if (pop) {
/* 203 */       this.stack.pop();
/*     */     }
/*     */     
/* 206 */     return retVal;
/*     */   }
/*     */   
/*     */   protected void addActionError(Object object) {
/* 210 */     this.validatorContext.addActionError(getMessage(object));
/*     */   }
/*     */   
/*     */   protected void addFieldError(String propertyName, Object object) {
/* 214 */     this.validatorContext.addFieldError(propertyName, getMessage(object));
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\ValidatorSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */