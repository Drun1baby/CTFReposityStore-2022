/*    */ package com.opensymphony.xwork2.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorMessageBuilder
/*    */ {
/* 26 */   private final StringBuilder message = new StringBuilder();
/*    */   
/*    */   public static ErrorMessageBuilder create() {
/* 29 */     return new ErrorMessageBuilder();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ErrorMessageBuilder errorSettingExpressionWithValue(String expr, Object value) {
/* 36 */     appenExpression(expr);
/* 37 */     if (value instanceof Object[]) {
/* 38 */       appendValueAsArray((Object[])value, this.message);
/*    */     } else {
/* 40 */       appendValue(value);
/*    */     } 
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   private void appenExpression(String expr) {
/* 46 */     this.message.append("Error setting expression '");
/* 47 */     this.message.append(expr);
/* 48 */     this.message.append("' with value ");
/*    */   }
/*    */   
/*    */   private void appendValue(Object value) {
/* 52 */     this.message.append("'");
/* 53 */     this.message.append(value);
/* 54 */     this.message.append("'");
/*    */   }
/*    */   
/*    */   private void appendValueAsArray(Object[] valueArray, StringBuilder msg) {
/* 58 */     msg.append("[");
/* 59 */     for (int index = 0; index < valueArray.length; index++) {
/* 60 */       appendValue(valueArray[index]);
/* 61 */       if (hasMoreElements(valueArray, index)) {
/* 62 */         msg.append(", ");
/*    */       }
/*    */     } 
/* 65 */     msg.append("]");
/*    */   }
/*    */   
/*    */   private boolean hasMoreElements(Object[] valueArray, int index) {
/* 69 */     return (index < valueArray.length + 1);
/*    */   }
/*    */   
/*    */   public String build() {
/* 73 */     return this.message.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\ErrorMessageBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */