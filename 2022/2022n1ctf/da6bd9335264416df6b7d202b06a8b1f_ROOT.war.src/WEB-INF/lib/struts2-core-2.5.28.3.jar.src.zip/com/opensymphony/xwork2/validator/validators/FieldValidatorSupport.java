/*    */ package com.opensymphony.xwork2.validator.validators;
/*    */ 
/*    */ import com.opensymphony.xwork2.validator.FieldValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FieldValidatorSupport
/*    */   extends ValidatorSupport
/*    */   implements FieldValidator
/*    */ {
/*    */   protected String fieldName;
/*    */   protected String type;
/*    */   protected Object currentValue;
/*    */   
/*    */   public void setFieldName(String fieldName) {
/* 36 */     this.fieldName = fieldName;
/*    */   }
/*    */   
/*    */   public String getFieldName() {
/* 40 */     return this.fieldName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValidatorType(String type) {
/* 45 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValidatorType() {
/* 50 */     return this.type;
/*    */   }
/*    */   
/*    */   public Object getCurrentValue() {
/* 54 */     return this.currentValue;
/*    */   }
/*    */   
/*    */   void setCurrentValue(Object currentValue) {
/* 58 */     this.currentValue = currentValue;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\FieldValidatorSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */