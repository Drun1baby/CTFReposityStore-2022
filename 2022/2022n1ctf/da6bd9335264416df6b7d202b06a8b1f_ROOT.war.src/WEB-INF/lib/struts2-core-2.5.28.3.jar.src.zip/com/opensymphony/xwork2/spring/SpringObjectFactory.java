/*     */ package com.opensymphony.xwork2.spring;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringObjectFactory
/*     */   extends ObjectFactory
/*     */   implements ApplicationContextAware
/*     */ {
/*  52 */   private static final Logger LOG = LogManager.getLogger(SpringObjectFactory.class);
/*     */   
/*     */   protected ApplicationContext appContext;
/*     */   protected AutowireCapableBeanFactory autoWiringFactory;
/*  56 */   protected int autowireStrategy = 1;
/*  57 */   private final Map<String, Object> classes = new HashMap<>();
/*     */ 
/*     */   
/*     */   private boolean useClassCache = true;
/*     */ 
/*     */   
/*     */   private boolean alwaysRespectAutowireStrategy = false;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private boolean enableAopSupport = false;
/*     */ 
/*     */   
/*     */   @Inject(value = "applicationContextPath", required = false)
/*     */   public void setApplicationContextPath(String ctx) {
/*  72 */     if (ctx != null) {
/*  73 */       setApplicationContext((ApplicationContext)new ClassPathXmlApplicationContext(ctx));
/*     */     }
/*     */   }
/*     */   
/*     */   @Inject(value = "enableAopSupport", required = false)
/*     */   public void setEnableAopSupport(String enableAopSupport) {
/*  79 */     this.enableAopSupport = BooleanUtils.toBoolean(enableAopSupport);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext appContext) throws BeansException {
/*  88 */     this.appContext = appContext;
/*  89 */     this.autoWiringFactory = findAutoWiringBeanFactory(this.appContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutowireStrategy(int autowireStrategy) {
/*  98 */     switch (autowireStrategy) {
/*     */       case 4:
/* 100 */         LOG.info("Setting autowire strategy to autodetect");
/* 101 */         this.autowireStrategy = autowireStrategy;
/*     */         return;
/*     */       case 1:
/* 104 */         LOG.info("Setting autowire strategy to name");
/* 105 */         this.autowireStrategy = autowireStrategy;
/*     */         return;
/*     */       case 2:
/* 108 */         LOG.info("Setting autowire strategy to type");
/* 109 */         this.autowireStrategy = autowireStrategy;
/*     */         return;
/*     */       case 3:
/* 112 */         LOG.info("Setting autowire strategy to constructor");
/* 113 */         this.autowireStrategy = autowireStrategy;
/*     */         return;
/*     */       case 0:
/* 116 */         LOG.info("Setting autowire strategy to none");
/* 117 */         this.autowireStrategy = autowireStrategy;
/*     */         return;
/*     */     } 
/* 120 */     throw new IllegalStateException("Invalid autowire type set");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAutowireStrategy() {
/* 125 */     return this.autowireStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AutowireCapableBeanFactory findAutoWiringBeanFactory(ApplicationContext context) {
/* 138 */     if (context instanceof AutowireCapableBeanFactory)
/*     */     {
/* 140 */       return (AutowireCapableBeanFactory)context; } 
/* 141 */     if (context instanceof ConfigurableApplicationContext)
/*     */     {
/* 143 */       return (AutowireCapableBeanFactory)((ConfigurableApplicationContext)context).getBeanFactory(); } 
/* 144 */     if (context.getParent() != null)
/*     */     {
/* 146 */       return findAutoWiringBeanFactory(context.getParent());
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildBean(String beanName, Map<String, Object> extraContext, boolean injectInternal) throws Exception {
/*     */     Object o;
/* 165 */     if (this.appContext.containsBean(beanName)) {
/* 166 */       o = this.appContext.getBean(beanName);
/*     */     } else {
/* 168 */       Class beanClazz = getClassInstance(beanName);
/* 169 */       o = buildBean(beanClazz, extraContext);
/*     */     } 
/* 171 */     if (injectInternal) {
/* 172 */       injectInternalBeans(o);
/*     */     }
/* 174 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object buildBean(Class clazz, Map<String, Object> extraContext) throws Exception {
/*     */     try {
/* 189 */       if (this.alwaysRespectAutowireStrategy) {
/*     */         
/* 191 */         Object object = this.autoWiringFactory.createBean(clazz, this.autowireStrategy, false);
/* 192 */         injectApplicationContext(object);
/* 193 */         return injectInternalBeans(object);
/* 194 */       }  if (this.enableAopSupport) {
/* 195 */         Object object = this.autoWiringFactory.createBean(clazz, 3, false);
/* 196 */         object = autoWireBean(object, this.autoWiringFactory);
/* 197 */         object = this.autoWiringFactory.initializeBean(object, object.getClass().getName());
/* 198 */         return object;
/*     */       } 
/* 200 */       Object bean = this.autoWiringFactory.autowire(clazz, 3, false);
/* 201 */       bean = this.autoWiringFactory.initializeBean(bean, bean.getClass().getName());
/* 202 */       return autoWireBean(bean, this.autoWiringFactory);
/*     */     }
/* 204 */     catch (UnsatisfiedDependencyException e) {
/* 205 */       LOG.error("Error building bean", (Throwable)e);
/*     */       
/* 207 */       return autoWireBean(super.buildBean(clazz, extraContext), this.autoWiringFactory);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object autoWireBean(Object bean) {
/* 212 */     return autoWireBean(bean, this.autoWiringFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object autoWireBean(Object bean, AutowireCapableBeanFactory autoWiringFactory) {
/* 222 */     if (autoWiringFactory != null) {
/* 223 */       autoWiringFactory.autowireBeanProperties(bean, this.autowireStrategy, false);
/*     */     }
/* 225 */     injectApplicationContext(bean);
/*     */     
/* 227 */     injectInternalBeans(bean);
/*     */     
/* 229 */     return bean;
/*     */   }
/*     */   
/*     */   private void injectApplicationContext(Object bean) {
/* 233 */     if (bean instanceof ApplicationContextAware) {
/* 234 */       ((ApplicationContextAware)bean).setApplicationContext(this.appContext);
/*     */     }
/*     */   }
/*     */   
/*     */   public Class getClassInstance(String className) throws ClassNotFoundException {
/* 239 */     Class<?> clazz = null;
/* 240 */     if (this.useClassCache) {
/* 241 */       synchronized (this.classes) {
/*     */ 
/*     */         
/* 244 */         clazz = (Class)this.classes.get(className);
/*     */       } 
/*     */     }
/*     */     
/* 248 */     if (clazz == null) {
/* 249 */       if (this.appContext.containsBean(className)) {
/* 250 */         clazz = this.appContext.getBean(className).getClass();
/*     */       } else {
/* 252 */         clazz = super.getClassInstance(className);
/*     */       } 
/*     */       
/* 255 */       if (this.useClassCache) {
/* 256 */         synchronized (this.classes) {
/* 257 */           this.classes.put(className, clazz);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 262 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNoArgConstructorRequired() {
/* 273 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseClassCache(boolean useClassCache) {
/* 282 */     this.useClassCache = useClassCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysRespectAutowireStrategy(boolean alwaysRespectAutowireStrategy) {
/* 291 */     this.alwaysRespectAutowireStrategy = alwaysRespectAutowireStrategy;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\spring\SpringObjectFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */