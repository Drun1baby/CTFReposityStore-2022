/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WildcardHelper
/*     */   implements PatternMatcher<int[]>
/*     */ {
/*     */   protected static final int MATCH_FILE = -1;
/*     */   protected static final int MATCH_PATH = -2;
/*     */   protected static final int MATCH_BEGIN = -4;
/*     */   protected static final int MATCH_THEEND = -5;
/*     */   protected static final int MATCH_END = -3;
/*     */   
/*     */   public boolean isLiteral(String pattern) {
/*  63 */     return (pattern == null || pattern.indexOf('*') == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] compilePattern(String data) {
/* 102 */     int[] expr = new int[data.length() + 2];
/* 103 */     char[] buff = data.toCharArray();
/*     */ 
/*     */     
/* 106 */     int y = 0;
/* 107 */     boolean slash = false;
/*     */ 
/*     */     
/* 110 */     expr[y++] = -4;
/*     */     
/* 112 */     if (buff.length > 0) {
/* 113 */       if (buff[0] == '\\') {
/* 114 */         slash = true;
/* 115 */       } else if (buff[0] == '*') {
/* 116 */         expr[y++] = -1;
/*     */       } else {
/* 118 */         expr[y++] = buff[0];
/*     */       } 
/*     */ 
/*     */       
/* 122 */       for (int x = 1; x < buff.length; x++) {
/*     */         
/* 124 */         if (slash) {
/* 125 */           expr[y++] = buff[x];
/* 126 */           slash = false;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 132 */         else if (buff[x] == '\\') {
/* 133 */           slash = true;
/*     */         
/*     */         }
/* 136 */         else if (buff[x] == '*') {
/*     */           
/* 138 */           if (expr[y - 1] <= -1) {
/* 139 */             expr[y - 1] = -2;
/*     */           } else {
/* 141 */             expr[y++] = -1;
/*     */           } 
/*     */         } else {
/* 144 */           expr[y++] = buff[x];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 151 */     expr[y] = -5;
/*     */     
/* 153 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(Map<String, String> map, String data, int[] expr) {
/* 167 */     if (map == null) {
/* 168 */       throw new NullPointerException("No map provided");
/*     */     }
/*     */     
/* 171 */     if (data == null) {
/* 172 */       throw new NullPointerException("No data provided");
/*     */     }
/*     */     
/* 175 */     if (expr == null) {
/* 176 */       throw new NullPointerException("No pattern expression provided");
/*     */     }
/*     */     
/* 179 */     char[] buff = data.toCharArray();
/*     */ 
/*     */     
/* 182 */     char[] rslt = new char[expr.length + buff.length];
/*     */ 
/*     */ 
/*     */     
/* 186 */     int charpos = 0;
/*     */ 
/*     */     
/* 189 */     int exprpos = 0;
/* 190 */     int buffpos = 0;
/* 191 */     int rsltpos = 0;
/* 192 */     int offset = -1;
/*     */ 
/*     */     
/* 195 */     int mcount = 0;
/*     */ 
/*     */     
/* 198 */     map.put(Integer.toString(mcount), data);
/*     */ 
/*     */     
/* 201 */     boolean matchBegin = false;
/*     */     
/* 203 */     if (expr[charpos] == -4) {
/* 204 */       matchBegin = true;
/* 205 */       exprpos = ++charpos;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 210 */     while (expr[charpos] >= 0) {
/* 211 */       charpos++;
/*     */     }
/*     */ 
/*     */     
/* 215 */     int exprchr = expr[charpos];
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 220 */       if (matchBegin) {
/* 221 */         if (!matchArray(expr, exprpos, charpos, buff, buffpos)) {
/* 222 */           return false;
/*     */         }
/*     */         
/* 225 */         matchBegin = false;
/*     */       } else {
/* 227 */         offset = indexOfArray(expr, exprpos, charpos, buff, buffpos);
/*     */         
/* 229 */         if (offset < 0) {
/* 230 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 235 */       if (matchBegin) {
/* 236 */         if (offset != 0) {
/* 237 */           return false;
/*     */         }
/*     */         
/* 240 */         matchBegin = false;
/*     */       } 
/*     */ 
/*     */       
/* 244 */       buffpos += charpos - exprpos;
/*     */ 
/*     */       
/* 247 */       if (exprchr == -3) {
/* 248 */         if (rsltpos > 0) {
/* 249 */           map.put(Integer.toString(++mcount), new String(rslt, 0, rsltpos));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 254 */         return true;
/* 255 */       }  if (exprchr == -5) {
/* 256 */         if (rsltpos > 0) {
/* 257 */           map.put(Integer.toString(++mcount), new String(rslt, 0, rsltpos));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 262 */         return (buffpos == buff.length);
/*     */       } 
/*     */ 
/*     */       
/* 266 */       exprpos = ++charpos;
/*     */       
/* 268 */       while (expr[charpos] >= 0) {
/* 269 */         charpos++;
/*     */       }
/*     */       
/* 272 */       int prevchr = exprchr;
/*     */       
/* 274 */       exprchr = expr[charpos];
/*     */ 
/*     */       
/* 277 */       offset = (prevchr == -1) ? indexOfArray(expr, exprpos, charpos, buff, buffpos) : lastIndexOfArray(expr, exprpos, charpos, buff, buffpos);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 282 */       if (offset < 0) {
/* 283 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 288 */       if (prevchr == -2) {
/* 289 */         while (buffpos < offset) {
/* 290 */           rslt[rsltpos++] = buff[buffpos++];
/*     */         }
/*     */       } else {
/*     */         
/* 294 */         while (buffpos < offset) {
/* 295 */           if (buff[buffpos] == '/') {
/* 296 */             return false;
/*     */           }
/*     */           
/* 299 */           rslt[rsltpos++] = buff[buffpos++];
/*     */         } 
/*     */       } 
/*     */       
/* 303 */       map.put(Integer.toString(++mcount), new String(rslt, 0, rsltpos));
/* 304 */       rsltpos = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int indexOfArray(int[] r, int rpos, int rend, char[] d, int dpos) {
/* 325 */     if (rend < rpos) {
/* 326 */       throw new IllegalArgumentException("rend < rpos");
/*     */     }
/*     */ 
/*     */     
/* 330 */     if (rend == rpos) {
/* 331 */       return d.length;
/*     */     }
/*     */ 
/*     */     
/* 335 */     if (rend - rpos == 1)
/*     */     {
/* 337 */       for (int x = dpos; x < d.length; x++) {
/* 338 */         if (r[rpos] == d[x]) {
/* 339 */           return x;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 346 */     while (dpos + rend - rpos <= d.length) {
/*     */       
/* 348 */       int y = dpos;
/*     */ 
/*     */ 
/*     */       
/* 352 */       for (int x = rpos; x <= rend; x++) {
/* 353 */         if (x == rend) {
/* 354 */           return dpos;
/*     */         }
/*     */         
/* 357 */         if (r[x] != d[y++]) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 363 */       dpos++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 368 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int lastIndexOfArray(int[] r, int rpos, int rend, char[] d, int dpos) {
/* 389 */     if (rend < rpos) {
/* 390 */       throw new IllegalArgumentException("rend < rpos");
/*     */     }
/*     */ 
/*     */     
/* 394 */     if (rend == rpos) {
/* 395 */       return d.length;
/*     */     }
/*     */ 
/*     */     
/* 399 */     if (rend - rpos == 1)
/*     */     {
/* 401 */       for (int x = d.length - 1; x > dpos; x--) {
/* 402 */         if (r[rpos] == d[x]) {
/* 403 */           return x;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 410 */     int l = d.length - rend - rpos;
/*     */     
/* 412 */     while (l >= dpos) {
/*     */       
/* 414 */       int y = l;
/*     */ 
/*     */ 
/*     */       
/* 418 */       for (int x = rpos; x <= rend; x++) {
/* 419 */         if (x == rend) {
/* 420 */           return l;
/*     */         }
/*     */         
/* 423 */         if (r[x] != d[y++]) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 429 */       l--;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 434 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchArray(int[] r, int rpos, int rend, char[] d, int dpos) {
/* 452 */     if (d.length - dpos < rend - rpos) {
/* 453 */       return false;
/*     */     }
/*     */     
/* 456 */     for (int i = rpos; i < rend; i++) {
/* 457 */       if (r[i] != d[dpos++]) {
/* 458 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 462 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\WildcardHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */