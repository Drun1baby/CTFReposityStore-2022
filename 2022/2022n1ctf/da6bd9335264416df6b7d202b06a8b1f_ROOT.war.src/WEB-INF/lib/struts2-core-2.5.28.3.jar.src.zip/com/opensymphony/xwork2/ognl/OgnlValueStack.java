/*     */ package com.opensymphony.xwork2.ognl;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.ognl.accessor.CompoundRootAccessor;
/*     */ import com.opensymphony.xwork2.util.ClearableValueStack;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.MemberAccessValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import ognl.ClassResolver;
/*     */ import ognl.MemberAccess;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.PropertyAccessor;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlValueStack
/*     */   implements Serializable, ValueStack, ClearableValueStack, MemberAccessValueStack
/*     */ {
/*  56 */   public static final String THROW_EXCEPTION_ON_FAILURE = OgnlValueStack.class.getName() + ".throwExceptionOnFailure";
/*     */   
/*  58 */   private static final Logger LOG = LogManager.getLogger(OgnlValueStack.class);
/*     */   
/*     */   private static final long serialVersionUID = 370737852934925530L;
/*     */   
/*     */   private static final String MAP_IDENTIFIER_KEY = "com.opensymphony.xwork2.util.OgnlValueStack.MAP_IDENTIFIER_KEY";
/*     */   
/*     */   protected CompoundRoot root;
/*     */   
/*     */   protected transient Map<String, Object> context;
/*     */   protected Class defaultType;
/*     */   protected Map<Object, Object> overrides;
/*     */   protected transient OgnlUtil ognlUtil;
/*     */   protected transient SecurityMemberAccess securityMemberAccess;
/*     */   private transient XWorkConverter converter;
/*     */   private boolean devMode;
/*     */   private boolean logMissingProperties;
/*     */   
/*     */   protected OgnlValueStack(XWorkConverter xworkConverter, CompoundRootAccessor accessor, TextProvider prov, boolean allowStaticAccess) {
/*  76 */     setRoot(xworkConverter, accessor, new CompoundRoot(), allowStaticAccess);
/*  77 */     push(prov);
/*     */   }
/*     */   
/*     */   protected OgnlValueStack(ValueStack vs, XWorkConverter xworkConverter, CompoundRootAccessor accessor, boolean allowStaticAccess) {
/*  81 */     setRoot(xworkConverter, accessor, new CompoundRoot((List)vs.getRoot()), allowStaticAccess);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   protected void setOgnlUtil(OgnlUtil ognlUtil) {
/*  86 */     this.ognlUtil = ognlUtil;
/*  87 */     this.securityMemberAccess.setExcludedClasses(ognlUtil.getExcludedClasses());
/*  88 */     this.securityMemberAccess.setExcludedPackageNamePatterns(ognlUtil.getExcludedPackageNamePatterns());
/*  89 */     this.securityMemberAccess.setExcludedPackageNames(ognlUtil.getExcludedPackageNames());
/*  90 */     this.securityMemberAccess.setDisallowProxyMemberAccess(ognlUtil.isDisallowProxyMemberAccess());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setRoot(XWorkConverter xworkConverter, CompoundRootAccessor accessor, CompoundRoot compoundRoot, boolean allowStaticMethodAccess) {
/*  95 */     this.root = compoundRoot;
/*  96 */     this.securityMemberAccess = new SecurityMemberAccess(allowStaticMethodAccess);
/*  97 */     this.context = Ognl.createDefaultContext(this.root, (ClassResolver)accessor, new OgnlTypeConverterWrapper((TypeConverter)xworkConverter), (MemberAccess)this.securityMemberAccess);
/*  98 */     this.context.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", this);
/*  99 */     Ognl.setClassResolver(this.context, (ClassResolver)accessor);
/* 100 */     ((OgnlContext)this.context).setTraceEvaluations(false);
/* 101 */     ((OgnlContext)this.context).setKeepLastEvaluation(false);
/*     */   }
/*     */   
/*     */   @Inject("devMode")
/*     */   protected void setDevMode(String mode) {
/* 106 */     this.devMode = BooleanUtils.toBoolean(mode);
/*     */   }
/*     */   
/*     */   @Inject(value = "logMissingProperties", required = false)
/*     */   protected void setLogMissingProperties(String logMissingProperties) {
/* 111 */     this.logMissingProperties = BooleanUtils.toBoolean(logMissingProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getContext() {
/* 118 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultType(Class defaultType) {
/* 125 */     this.defaultType = defaultType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExprOverrides(Map<Object, Object> overrides) {
/* 132 */     if (this.overrides == null) {
/* 133 */       this.overrides = overrides;
/*     */     } else {
/* 135 */       this.overrides.putAll(overrides);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Object, Object> getExprOverrides() {
/* 143 */     return this.overrides;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompoundRoot getRoot() {
/* 150 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String expr, Object value) {
/* 157 */     setValue(expr, value, this.devMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String expr, Object value) {
/* 164 */     setValue(expr, value, this.devMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String expr, Object value, boolean throwExceptionOnFailure) {
/* 171 */     Map<String, Object> context = getContext();
/*     */     try {
/* 173 */       trySetValue(expr, value, throwExceptionOnFailure, context);
/* 174 */     } catch (OgnlException e) {
/* 175 */       handleOgnlException(expr, value, throwExceptionOnFailure, e);
/* 176 */     } catch (RuntimeException re) {
/* 177 */       handleRuntimeException(expr, value, throwExceptionOnFailure, re);
/*     */     } finally {
/* 179 */       cleanUpContext(context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void trySetValue(String expr, Object value, boolean throwExceptionOnFailure, Map<String, Object> context) throws OgnlException {
/* 184 */     context.put("conversion.property.fullName", expr);
/* 185 */     context.put("com.opensymphony.xwork2.util.ValueStack.ReportErrorsOnNoProp", (throwExceptionOnFailure || this.logMissingProperties) ? Boolean.TRUE : Boolean.FALSE);
/* 186 */     this.ognlUtil.setValue(expr, context, this.root, value);
/*     */   }
/*     */   
/*     */   private void cleanUpContext(Map<String, Object> context) {
/* 190 */     ReflectionContextState.clear(context);
/* 191 */     context.remove("conversion.property.fullName");
/* 192 */     context.remove("com.opensymphony.xwork2.util.ValueStack.ReportErrorsOnNoProp");
/*     */   }
/*     */   
/*     */   protected void handleRuntimeException(String expr, Object value, boolean throwExceptionOnFailure, RuntimeException re) {
/* 196 */     if (throwExceptionOnFailure) {
/* 197 */       String message = ErrorMessageBuilder.create().errorSettingExpressionWithValue(expr, value).build();
/*     */ 
/*     */       
/* 200 */       throw new XWorkException(message, re);
/*     */     } 
/* 202 */     LOG.warn("Error setting value [{}] with expression [{}]", value, expr, re);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleOgnlException(String expr, Object value, boolean throwExceptionOnFailure, OgnlException e) {
/* 207 */     if (e != null && e.getReason() instanceof SecurityException) {
/* 208 */       LOG.error("Could not evaluate this expression due to security constraints: [{}]", expr, e);
/*     */     }
/* 210 */     boolean shouldLog = shouldLogMissingPropertyWarning(e);
/* 211 */     String msg = null;
/* 212 */     if (throwExceptionOnFailure || shouldLog) {
/* 213 */       msg = ErrorMessageBuilder.create().errorSettingExpressionWithValue(expr, value).build();
/*     */     }
/* 215 */     if (shouldLog) {
/* 216 */       LOG.warn(msg, (Throwable)e);
/*     */     }
/*     */     
/* 219 */     if (throwExceptionOnFailure) {
/* 220 */       throw new XWorkException(msg, e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findString(String expr) {
/* 228 */     return (String)findValue(expr, String.class);
/*     */   }
/*     */   
/*     */   public String findString(String expr, boolean throwExceptionOnFailure) {
/* 232 */     return (String)findValue(expr, String.class, throwExceptionOnFailure);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findValue(String expr, boolean throwExceptionOnFailure) {
/*     */     try {
/* 240 */       setupExceptionOnFailure(throwExceptionOnFailure);
/* 241 */       return tryFindValueWhenExpressionIsNotNull(expr);
/* 242 */     } catch (OgnlException e) {
/* 243 */       return handleOgnlException(expr, throwExceptionOnFailure, e);
/* 244 */     } catch (Exception e) {
/* 245 */       return handleOtherException(expr, throwExceptionOnFailure, e);
/*     */     } finally {
/* 247 */       ReflectionContextState.clear(this.context);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setupExceptionOnFailure(boolean throwExceptionOnFailure) {
/* 252 */     if (throwExceptionOnFailure || this.logMissingProperties) {
/* 253 */       this.context.put(THROW_EXCEPTION_ON_FAILURE, Boolean.valueOf(true));
/*     */     }
/*     */   }
/*     */   
/*     */   private Object tryFindValueWhenExpressionIsNotNull(String expr) throws OgnlException {
/* 258 */     if (expr == null) {
/* 259 */       return null;
/*     */     }
/* 261 */     return tryFindValue(expr);
/*     */   }
/*     */   
/*     */   protected Object handleOtherException(String expr, boolean throwExceptionOnFailure, Exception e) {
/* 265 */     logLookupFailure(expr, e);
/*     */     
/* 267 */     if (throwExceptionOnFailure) {
/* 268 */       throw new XWorkException(e);
/*     */     }
/* 270 */     return findInContext(expr);
/*     */   }
/*     */   
/*     */   private Object tryFindValue(String expr) throws OgnlException {
/*     */     Object value;
/* 275 */     expr = lookupForOverrides(expr);
/* 276 */     if (this.defaultType != null) {
/* 277 */       value = findValue(expr, this.defaultType);
/*     */     } else {
/* 279 */       value = getValueUsingOgnl(expr);
/* 280 */       if (value == null) {
/* 281 */         value = findInContext(expr);
/*     */       }
/*     */     } 
/* 284 */     return value;
/*     */   }
/*     */   
/*     */   private String lookupForOverrides(String expr) {
/* 288 */     if (this.overrides != null && this.overrides.containsKey(expr)) {
/* 289 */       expr = (String)this.overrides.get(expr);
/*     */     }
/* 291 */     return expr;
/*     */   }
/*     */   
/*     */   private Object getValueUsingOgnl(String expr) throws OgnlException {
/*     */     try {
/* 296 */       return this.ognlUtil.getValue(expr, this.context, this.root);
/*     */     } finally {
/* 298 */       this.context.remove(THROW_EXCEPTION_ON_FAILURE);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object findValue(String expr) {
/* 303 */     return findValue(expr, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findValue(String expr, Class asType, boolean throwExceptionOnFailure) {
/*     */     try {
/* 311 */       setupExceptionOnFailure(throwExceptionOnFailure);
/* 312 */       return tryFindValueWhenExpressionIsNotNull(expr, asType);
/* 313 */     } catch (OgnlException e) {
/* 314 */       Object value = handleOgnlException(expr, throwExceptionOnFailure, e);
/* 315 */       return this.converter.convertValue(getContext(), value, asType);
/* 316 */     } catch (Exception e) {
/* 317 */       Object value = handleOtherException(expr, throwExceptionOnFailure, e);
/* 318 */       return this.converter.convertValue(getContext(), value, asType);
/*     */     } finally {
/* 320 */       ReflectionContextState.clear(this.context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object tryFindValueWhenExpressionIsNotNull(String expr, Class asType) throws OgnlException {
/* 325 */     if (expr == null) {
/* 326 */       return null;
/*     */     }
/* 328 */     return tryFindValue(expr, asType);
/*     */   }
/*     */   
/*     */   protected Object handleOgnlException(String expr, boolean throwExceptionOnFailure, OgnlException e) {
/* 332 */     Object ret = null;
/* 333 */     if (e != null && e.getReason() instanceof SecurityException) {
/* 334 */       LOG.error("Could not evaluate this expression due to security constraints: [{}]", expr, e);
/*     */     } else {
/* 336 */       ret = findInContext(expr);
/*     */     } 
/* 338 */     if (ret == null) {
/* 339 */       if (shouldLogMissingPropertyWarning(e)) {
/* 340 */         LOG.warn("Could not find property [{}]!", expr, e);
/*     */       }
/* 342 */       if (throwExceptionOnFailure) {
/* 343 */         throw new XWorkException(e);
/*     */       }
/*     */     } 
/* 346 */     return ret;
/*     */   }
/*     */   
/*     */   protected boolean shouldLogMissingPropertyWarning(OgnlException e) {
/* 350 */     return ((e instanceof ognl.NoSuchPropertyException || (e instanceof ognl.MethodFailedException && e.getReason() instanceof NoSuchMethodException)) && this.logMissingProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object tryFindValue(String expr, Class asType) throws OgnlException {
/* 356 */     Object value = null;
/*     */     try {
/* 358 */       expr = lookupForOverrides(expr);
/* 359 */       value = getValue(expr, asType);
/* 360 */       if (value == null) {
/* 361 */         value = findInContext(expr);
/* 362 */         return this.converter.convertValue(getContext(), value, asType);
/*     */       } 
/*     */     } finally {
/* 365 */       this.context.remove(THROW_EXCEPTION_ON_FAILURE);
/*     */     } 
/* 367 */     return value;
/*     */   }
/*     */   
/*     */   private Object getValue(String expr, Class asType) throws OgnlException {
/* 371 */     return this.ognlUtil.getValue(expr, this.context, this.root, asType);
/*     */   }
/*     */   
/*     */   protected Object findInContext(String name) {
/* 375 */     return getContext().get(name);
/*     */   }
/*     */   
/*     */   public Object findValue(String expr, Class asType) {
/* 379 */     return findValue(expr, asType, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logLookupFailure(String expr, Exception e) {
/* 389 */     if (this.devMode) {
/* 390 */       LOG.warn("Caught an exception while evaluating expression '{}' against value stack", expr, e);
/* 391 */       LOG.warn("NOTE: Previous warning message was issued due to devMode set to true.");
/*     */     } else {
/* 393 */       LOG.debug("Caught an exception while evaluating expression '{}' against value stack", expr, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object peek() {
/* 401 */     return this.root.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object pop() {
/* 408 */     return this.root.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void push(Object o) {
/* 415 */     this.root.push(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(String key, Object o) {
/* 423 */     Map<String, Object> setMap = retrieveSetMap();
/* 424 */     setMap.put(key, o);
/*     */   }
/*     */   
/*     */   private Map retrieveSetMap() {
/*     */     Map<Object, Object> setMap;
/* 429 */     Object topObj = peek();
/* 430 */     if (shouldUseOldMap(topObj)) {
/* 431 */       setMap = (Map)topObj;
/*     */     } else {
/* 433 */       setMap = new HashMap<>();
/* 434 */       setMap.put("com.opensymphony.xwork2.util.OgnlValueStack.MAP_IDENTIFIER_KEY", "");
/* 435 */       push(setMap);
/*     */     } 
/* 437 */     return setMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldUseOldMap(Object topObj) {
/* 444 */     return (topObj instanceof Map && ((Map)topObj).get("com.opensymphony.xwork2.util.OgnlValueStack.MAP_IDENTIFIER_KEY") != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 451 */     return this.root.size();
/*     */   }
/*     */ 
/*     */   
/*     */   private Object readResolve() {
/* 456 */     ActionContext ac = ActionContext.getContext();
/* 457 */     Container cont = ac.getContainer();
/* 458 */     XWorkConverter xworkConverter = (XWorkConverter)cont.getInstance(XWorkConverter.class);
/* 459 */     CompoundRootAccessor accessor = (CompoundRootAccessor)cont.getInstance(PropertyAccessor.class, CompoundRoot.class.getName());
/* 460 */     TextProvider prov = (TextProvider)cont.getInstance(TextProvider.class, "system");
/* 461 */     boolean allow = BooleanUtils.toBoolean((String)cont.getInstance(String.class, "allowStaticMethodAccess"));
/* 462 */     OgnlValueStack aStack = new OgnlValueStack(xworkConverter, accessor, prov, allow);
/* 463 */     aStack.setOgnlUtil((OgnlUtil)cont.getInstance(OgnlUtil.class));
/* 464 */     aStack.setRoot(xworkConverter, accessor, this.root, allow);
/*     */     
/* 466 */     return aStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearContextValues() {
/* 473 */     ((OgnlContext)this.context).getValues().clear();
/*     */   }
/*     */   
/*     */   public void setAcceptProperties(Set<Pattern> acceptedProperties) {
/* 477 */     this.securityMemberAccess.setAcceptProperties(acceptedProperties);
/*     */   }
/*     */   
/*     */   public void setExcludeProperties(Set<Pattern> excludeProperties) {
/* 481 */     this.securityMemberAccess.setExcludeProperties(excludeProperties);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   protected void setXWorkConverter(XWorkConverter converter) {
/* 486 */     this.converter = converter;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\OgnlValueStack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */