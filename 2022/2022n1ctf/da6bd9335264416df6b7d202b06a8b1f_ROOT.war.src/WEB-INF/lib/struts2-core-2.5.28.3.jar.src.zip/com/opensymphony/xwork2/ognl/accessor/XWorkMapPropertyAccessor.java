/*     */ package com.opensymphony.xwork2.ognl.accessor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Map;
/*     */ import ognl.MapPropertyAccessor;
/*     */ import ognl.OgnlException;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkMapPropertyAccessor
/*     */   extends MapPropertyAccessor
/*     */ {
/*  41 */   private static final Logger LOG = LogManager.getLogger(XWorkMapPropertyAccessor.class);
/*     */   
/*  43 */   private static final String[] INDEX_ACCESS_PROPS = new String[] { "size", "isEmpty", "keys", "values" };
/*     */   
/*     */   private XWorkConverter xworkConverter;
/*     */   private ObjectFactory objectFactory;
/*     */   private ObjectTypeDeterminer objectTypeDeterminer;
/*     */   
/*     */   @Inject
/*     */   public void setXWorkConverter(XWorkConverter conv) {
/*  51 */     this.xworkConverter = conv;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac) {
/*  56 */     this.objectFactory = fac;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setObjectTypeDeterminer(ObjectTypeDeterminer ot) {
/*  61 */     this.objectTypeDeterminer = ot;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*  66 */     LOG.trace("Entering getProperty ({},{},{})", context, target, name);
/*     */     
/*  68 */     ReflectionContextState.updateCurrentPropertyPath(context, name);
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (name instanceof String && contains(INDEX_ACCESS_PROPS, (String)name)) {
/*  73 */       return super.getProperty(context, target, name);
/*     */     }
/*     */     
/*  76 */     Object result = null;
/*     */     
/*     */     try {
/*  79 */       result = super.getProperty(context, target, name);
/*  80 */     } catch (ClassCastException classCastException) {}
/*     */ 
/*     */     
/*  83 */     if (result == null) {
/*     */       
/*  85 */       Class lastClass = (Class)context.get("last.bean.accessed");
/*     */       
/*  87 */       String lastProperty = (String)context.get("last.property.accessed");
/*  88 */       if (lastClass == null || lastProperty == null) {
/*  89 */         return null;
/*     */       }
/*  91 */       Object key = getKey(context, name);
/*  92 */       Map<Object, Object> map = (Map)target;
/*  93 */       result = map.get(key);
/*     */       
/*  95 */       if (result == null && Boolean.TRUE.equals(context.get("xwork.NullHandler.createNullObjects")) && this.objectTypeDeterminer.shouldCreateIfNew(lastClass, lastProperty, target, null, false)) {
/*     */ 
/*     */         
/*  98 */         Class valueClass = this.objectTypeDeterminer.getElementClass(lastClass, lastProperty, key);
/*     */         
/*     */         try {
/* 101 */           result = this.objectFactory.buildBean(valueClass, context);
/* 102 */           map.put(key, result);
/* 103 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean contains(String[] array, String name) {
/* 115 */     for (String anArray : array) {
/* 116 */       if (anArray.equals(name)) {
/* 117 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 126 */     LOG.trace("Entering setProperty({},{},{},{})", context, target, name, value);
/*     */     
/* 128 */     Object key = getKey(context, name);
/* 129 */     Map<Object, Object> map = (Map)target;
/* 130 */     map.put(key, getValue(context, value));
/*     */   }
/*     */   
/*     */   private Object getValue(Map context, Object value) {
/* 134 */     Class lastClass = (Class)context.get("last.bean.accessed");
/* 135 */     String lastProperty = (String)context.get("last.property.accessed");
/* 136 */     if (lastClass == null || lastProperty == null) {
/* 137 */       return value;
/*     */     }
/* 139 */     Class elementClass = this.objectTypeDeterminer.getElementClass(lastClass, lastProperty, null);
/* 140 */     if (elementClass == null) {
/* 141 */       return value;
/*     */     }
/* 143 */     return this.xworkConverter.convertValue(context, value, elementClass);
/*     */   }
/*     */   
/*     */   private Object getKey(Map context, Object name) {
/* 147 */     Class lastClass = (Class)context.get("last.bean.accessed");
/* 148 */     String lastProperty = (String)context.get("last.property.accessed");
/* 149 */     if (lastClass == null || lastProperty == null)
/*     */     {
/*     */       
/* 152 */       return name;
/*     */     }
/* 154 */     Class<String> keyClass = this.objectTypeDeterminer.getKeyClass(lastClass, lastProperty);
/* 155 */     if (keyClass == null) {
/* 156 */       keyClass = String.class;
/*     */     }
/*     */     
/* 159 */     return this.xworkConverter.convertValue(context, name, keyClass);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\XWorkMapPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */