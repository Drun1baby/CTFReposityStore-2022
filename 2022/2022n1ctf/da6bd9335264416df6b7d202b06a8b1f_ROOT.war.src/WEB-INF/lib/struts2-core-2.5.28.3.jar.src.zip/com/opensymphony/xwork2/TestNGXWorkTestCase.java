/*    */ package com.opensymphony.xwork2;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.config.impl.MockConfiguration;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.util.XWorkTestCaseHelper;
/*    */ import org.testng.annotations.AfterTest;
/*    */ import org.testng.annotations.BeforeTest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestNGXWorkTestCase
/*    */ {
/*    */   protected ConfigurationManager configurationManager;
/*    */   protected Configuration configuration;
/*    */   protected Container container;
/*    */   protected ActionProxyFactory actionProxyFactory;
/*    */   
/*    */   @BeforeTest
/*    */   protected void setUp() throws Exception {
/* 43 */     this.configurationManager = XWorkTestCaseHelper.setUp();
/* 44 */     this.configuration = (Configuration)new MockConfiguration();
/* 45 */     ((MockConfiguration)this.configuration).selfRegister();
/* 46 */     this.container = this.configuration.getContainer();
/* 47 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */   
/*    */   @AfterTest
/*    */   protected void tearDown() throws Exception {
/* 52 */     XWorkTestCaseHelper.tearDown(this.configurationManager);
/* 53 */     this.configurationManager = null;
/* 54 */     this.configuration = null;
/* 55 */     this.container = null;
/* 56 */     this.actionProxyFactory = null;
/*    */   }
/*    */   
/*    */   protected void loadConfigurationProviders(ConfigurationProvider... providers) {
/* 60 */     this.configurationManager = XWorkTestCaseHelper.loadConfigurationProviders(this.configurationManager, providers);
/* 61 */     this.configuration = this.configurationManager.getConfiguration();
/* 62 */     this.container = this.configuration.getContainer();
/* 63 */     this.actionProxyFactory = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\TestNGXWorkTestCase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */