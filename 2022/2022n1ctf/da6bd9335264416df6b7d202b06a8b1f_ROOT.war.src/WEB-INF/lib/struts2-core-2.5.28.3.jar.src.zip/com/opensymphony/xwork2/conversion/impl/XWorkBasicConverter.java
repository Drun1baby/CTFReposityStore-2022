/*     */ package com.opensymphony.xwork2.conversion.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkBasicConverter
/*     */   extends DefaultTypeConverter
/*     */ {
/*     */   private Container container;
/*     */   
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  70 */     this.container = container;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convertValue(Map<String, Object> context, Object o, Member member, String propertyName, Object value, Class<String> toType) {
/*  75 */     Object result = null;
/*     */     
/*  77 */     if (value == null || toType.isAssignableFrom(value.getClass()))
/*     */     {
/*  79 */       return value;
/*     */     }
/*     */     
/*  82 */     if (toType == String.class) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  93 */       result = doConvertToString(context, value);
/*  94 */     } else if (toType == boolean.class) {
/*  95 */       result = doConvertToBoolean(value);
/*  96 */     } else if (toType == Boolean.class) {
/*  97 */       result = doConvertToBoolean(value);
/*  98 */     } else if (toType.isArray()) {
/*  99 */       result = doConvertToArray(context, o, member, propertyName, value, toType);
/* 100 */     } else if (Date.class.isAssignableFrom(toType)) {
/* 101 */       result = doConvertToDate(context, value, toType);
/* 102 */     } else if (Calendar.class.isAssignableFrom(toType)) {
/* 103 */       result = doConvertToCalendar(context, value);
/* 104 */     } else if (Collection.class.isAssignableFrom(toType)) {
/* 105 */       result = doConvertToCollection(context, o, member, propertyName, value, toType);
/* 106 */     } else if (toType == Character.class) {
/* 107 */       result = doConvertToCharacter(value);
/* 108 */     } else if (toType == char.class) {
/* 109 */       result = doConvertToCharacter(value);
/* 110 */     } else if (Number.class.isAssignableFrom(toType) || toType.isPrimitive()) {
/* 111 */       result = doConvertToNumber(context, value, toType);
/* 112 */     } else if (toType == Class.class) {
/* 113 */       result = doConvertToClass(value);
/*     */     } 
/*     */     
/* 116 */     if (result == null) {
/* 117 */       if (value instanceof Object[]) {
/* 118 */         Object[] array = (Object[])value;
/*     */         
/* 120 */         if (array.length >= 1) {
/* 121 */           value = array[0];
/*     */         } else {
/* 123 */           value = null;
/*     */         } 
/*     */ 
/*     */         
/* 127 */         result = convertValue(context, o, member, propertyName, value, toType);
/* 128 */       } else if (!"".equals(value)) {
/* 129 */         result = convertValue(context, value, toType);
/*     */       } 
/*     */       
/* 132 */       if (result == null && value != null && !"".equals(value)) {
/* 133 */         throw new XWorkException("Cannot create type " + toType + " from value " + value);
/*     */       }
/*     */     } 
/*     */     
/* 137 */     return result;
/*     */   }
/*     */   
/*     */   private Object doConvertToCalendar(Map<String, Object> context, Object value) {
/* 141 */     Object result = null;
/* 142 */     Date dateResult = (Date)doConvertToDate(context, value, Date.class);
/* 143 */     if (dateResult != null) {
/* 144 */       Calendar calendar = Calendar.getInstance();
/* 145 */       calendar.setTime(dateResult);
/* 146 */       result = calendar;
/*     */     } 
/* 148 */     return result;
/*     */   }
/*     */   
/*     */   private Object doConvertToCharacter(Object value) {
/* 152 */     if (value instanceof String) {
/* 153 */       String cStr = (String)value;
/* 154 */       return (cStr.length() > 0) ? Character.valueOf(cStr.charAt(0)) : null;
/*     */     } 
/* 156 */     return null;
/*     */   }
/*     */   
/*     */   private Object doConvertToBoolean(Object value) {
/* 160 */     if (value instanceof String) {
/* 161 */       String bStr = (String)value;
/* 162 */       return Boolean.valueOf(bStr);
/*     */     } 
/* 164 */     return null;
/*     */   }
/*     */   
/*     */   private Class doConvertToClass(Object value) {
/* 168 */     Class<?> clazz = null;
/* 169 */     if (value != null && value instanceof String && ((String)value).length() > 0) {
/*     */       try {
/* 171 */         clazz = Class.forName((String)value);
/* 172 */       } catch (ClassNotFoundException e) {
/* 173 */         throw new XWorkException(e.getLocalizedMessage(), e);
/*     */       } 
/*     */     }
/* 176 */     return clazz;
/*     */   }
/*     */   
/*     */   private Object doConvertToCollection(Map<String, Object> context, Object o, Member member, String prop, Object value, Class toType) {
/* 180 */     TypeConverter converter = (TypeConverter)this.container.getInstance(CollectionConverter.class);
/* 181 */     if (converter == null) {
/* 182 */       throw new XWorkException("TypeConverter with name [#0] must be registered first!", "collectionConverter");
/*     */     }
/* 184 */     return converter.convertValue(context, o, member, prop, value, toType);
/*     */   }
/*     */   
/*     */   private Object doConvertToArray(Map<String, Object> context, Object o, Member member, String prop, Object value, Class toType) {
/* 188 */     TypeConverter converter = (TypeConverter)this.container.getInstance(ArrayConverter.class);
/* 189 */     if (converter == null) {
/* 190 */       throw new XWorkException("TypeConverter with name [#0] must be registered first!", "arrayConverter");
/*     */     }
/* 192 */     return converter.convertValue(context, o, member, prop, value, toType);
/*     */   }
/*     */   
/*     */   private Object doConvertToDate(Map<String, Object> context, Object value, Class toType) {
/* 196 */     TypeConverter converter = (TypeConverter)this.container.getInstance(DateConverter.class);
/* 197 */     if (converter == null) {
/* 198 */       throw new XWorkException("TypeConverter with name [#0] must be registered first!", "dateConverter");
/*     */     }
/* 200 */     return converter.convertValue(context, null, null, null, value, toType);
/*     */   }
/*     */   
/*     */   private Object doConvertToNumber(Map<String, Object> context, Object value, Class toType) {
/* 204 */     TypeConverter converter = (TypeConverter)this.container.getInstance(NumberConverter.class);
/* 205 */     if (converter == null) {
/* 206 */       throw new XWorkException("TypeConverter with name [#0] must be registered first!", "numberConverter");
/*     */     }
/* 208 */     return converter.convertValue(context, null, null, null, value, toType);
/*     */   }
/*     */   
/*     */   private Object doConvertToString(Map<String, Object> context, Object value) {
/* 212 */     TypeConverter converter = (TypeConverter)this.container.getInstance(StringConverter.class);
/* 213 */     if (converter == null) {
/* 214 */       throw new XWorkException("TypeConverter with name [#0] must be registered first!", "stringConverter");
/*     */     }
/* 216 */     return converter.convertValue(context, null, null, null, value, null);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\impl\XWorkBasicConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */