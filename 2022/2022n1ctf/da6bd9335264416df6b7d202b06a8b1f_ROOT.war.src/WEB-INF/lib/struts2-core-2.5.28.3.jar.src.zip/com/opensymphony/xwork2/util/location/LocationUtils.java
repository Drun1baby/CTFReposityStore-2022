/*     */ package com.opensymphony.xwork2.util.location;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.transform.SourceLocator;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationUtils
/*     */ {
/*     */   public static final String UNKNOWN_STRING = "[unknown location]";
/*  43 */   private static List<WeakReference<LocationFinder>> finders = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Location location) {
/*  74 */     StringBuilder result = new StringBuilder();
/*     */     
/*  76 */     String description = location.getDescription();
/*  77 */     if (description != null) {
/*  78 */       result.append(description).append(" - ");
/*     */     }
/*     */     
/*  81 */     String uri = location.getURI();
/*  82 */     if (uri != null) {
/*  83 */       result.append(uri).append(':').append(location.getLineNumber()).append(':').append(location.getColumnNumber());
/*     */     } else {
/*  85 */       result.append("[unknown location]");
/*     */     } 
/*     */     
/*  88 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocationImpl parse(String text) throws IllegalArgumentException {
/*     */     String description;
/* 100 */     if (text == null || text.length() == 0) {
/* 101 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 106 */     int uriStart = text.lastIndexOf(" - ");
/* 107 */     if (uriStart > -1) {
/* 108 */       description = text.substring(0, uriStart);
/* 109 */       uriStart += 3;
/*     */     } else {
/* 111 */       description = null;
/* 112 */       uriStart = 0;
/*     */     } 
/*     */     
/*     */     try {
/* 116 */       int colSep = text.lastIndexOf(':');
/* 117 */       if (colSep > -1) {
/* 118 */         int column = Integer.parseInt(text.substring(colSep + 1));
/*     */         
/* 120 */         int lineSep = text.lastIndexOf(':', colSep - 1);
/* 121 */         if (lineSep > -1) {
/* 122 */           int line = Integer.parseInt(text.substring(lineSep + 1, colSep));
/* 123 */           return new LocationImpl(description, text.substring(uriStart, lineSep), line, column);
/*     */         }
/*     */       
/*     */       }
/* 127 */       else if (text.endsWith("[unknown location]")) {
/* 128 */         return LocationImpl.UNKNOWN;
/*     */       }
/*     */     
/* 131 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 135 */     return LocationImpl.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isKnown(Location location) {
/* 145 */     return (location != null && !Location.UNKNOWN.equals(location));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUnknown(Location location) {
/* 155 */     return (location == null || Location.UNKNOWN.equals(location));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addFinder(LocationFinder finder) {
/* 183 */     if (finder == null) {
/*     */       return;
/*     */     }
/*     */     
/* 187 */     synchronized (LocationFinder.class) {
/*     */ 
/*     */       
/* 190 */       List<WeakReference<LocationFinder>> newFinders = new ArrayList<>(finders);
/* 191 */       newFinders.add(new WeakReference<>(finder));
/* 192 */       finders = newFinders;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getLocation(Object obj) {
/* 204 */     return getLocation(obj, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Location getLocation(Object obj, String description) {
/* 217 */     if (obj instanceof Location) {
/* 218 */       return (Location)obj;
/*     */     }
/*     */     
/* 221 */     if (obj instanceof Locatable) {
/* 222 */       return ((Locatable)obj).getLocation();
/*     */     }
/*     */ 
/*     */     
/* 226 */     if (obj instanceof SAXParseException) {
/* 227 */       SAXParseException spe = (SAXParseException)obj;
/* 228 */       if (spe.getSystemId() != null) {
/* 229 */         return new LocationImpl(description, spe.getSystemId(), spe.getLineNumber(), spe.getColumnNumber());
/*     */       }
/* 231 */       return Location.UNKNOWN;
/*     */     } 
/*     */ 
/*     */     
/* 235 */     if (obj instanceof TransformerException) {
/* 236 */       TransformerException ex = (TransformerException)obj;
/* 237 */       SourceLocator locator = ex.getLocator();
/* 238 */       if (locator != null && locator.getSystemId() != null) {
/* 239 */         return new LocationImpl(description, locator.getSystemId(), locator.getLineNumber(), locator.getColumnNumber());
/*     */       }
/* 241 */       return Location.UNKNOWN;
/*     */     } 
/*     */ 
/*     */     
/* 245 */     if (obj instanceof Locator) {
/* 246 */       Locator locator = (Locator)obj;
/* 247 */       if (locator.getSystemId() != null) {
/* 248 */         return new LocationImpl(description, locator.getSystemId(), locator.getLineNumber(), locator.getColumnNumber());
/*     */       }
/* 250 */       return Location.UNKNOWN;
/*     */     } 
/*     */ 
/*     */     
/* 254 */     if (obj instanceof Element) {
/* 255 */       return LocationAttributes.getLocation((Element)obj);
/*     */     }
/*     */     
/* 258 */     List<WeakReference<LocationFinder>> currentFinders = finders;
/* 259 */     int size = currentFinders.size();
/* 260 */     for (int i = 0; i < size; i++) {
/* 261 */       WeakReference<LocationFinder> ref = currentFinders.get(i);
/* 262 */       LocationFinder finder = ref.get();
/* 263 */       if (finder == null) {
/*     */         
/* 265 */         synchronized (LocationFinder.class) {
/*     */           
/* 267 */           List<WeakReference<LocationFinder>> newFinders = new ArrayList<>(finders);
/* 268 */           newFinders.remove(ref);
/* 269 */           finders = newFinders;
/*     */         } 
/*     */       } else {
/* 272 */         Location result = finder.getLocation(obj, description);
/* 273 */         if (result != null) {
/* 274 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 279 */     if (obj instanceof Throwable) {
/* 280 */       Throwable t = (Throwable)obj;
/* 281 */       StackTraceElement[] stack = t.getStackTrace();
/* 282 */       if (stack != null && stack.length > 0) {
/* 283 */         StackTraceElement trace = stack[0];
/* 284 */         if (trace.getLineNumber() >= 0) {
/* 285 */           String uri = trace.getClassName();
/* 286 */           if (trace.getFileName() != null) {
/* 287 */             uri = uri.replace('.', '/');
/* 288 */             uri = uri.substring(0, uri.lastIndexOf('/') + 1);
/* 289 */             uri = uri + trace.getFileName();
/* 290 */             URL url = ClassLoaderUtil.getResource(uri, LocationUtils.class);
/* 291 */             if (url != null) {
/* 292 */               uri = url.toString();
/*     */             }
/*     */           } 
/* 295 */           if (description == null) {
/* 296 */             StringBuilder sb = new StringBuilder();
/* 297 */             sb.append("Class: ").append(trace.getClassName()).append("\n");
/* 298 */             sb.append("File: ").append(trace.getFileName()).append("\n");
/* 299 */             sb.append("Method: ").append(trace.getMethodName()).append("\n");
/* 300 */             sb.append("Line: ").append(trace.getLineNumber());
/* 301 */             description = sb.toString();
/*     */           } 
/* 303 */           return new LocationImpl(description, uri, trace.getLineNumber(), -1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 308 */     return Location.UNKNOWN;
/*     */   }
/*     */   
/*     */   public static interface LocationFinder {
/*     */     Location getLocation(Object param1Object, String param1String);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\location\LocationUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */