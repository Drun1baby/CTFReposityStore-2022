/*     */ package com.opensymphony.xwork2.validator;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.Validateable;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PrefixMethodInvocationUtil;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidationInterceptor
/*     */   extends MethodFilterInterceptor
/*     */ {
/* 135 */   private static final Logger LOG = LogManager.getLogger(ValidationInterceptor.class);
/*     */   
/*     */   private static final String VALIDATE_PREFIX = "validate";
/*     */   
/*     */   private static final String ALT_VALIDATE_PREFIX = "validateDo";
/*     */   
/*     */   private boolean validateAnnotatedMethodOnly;
/*     */   
/*     */   private ActionValidatorManager actionValidatorManager;
/*     */   private boolean alwaysInvokeValidate = true;
/*     */   private boolean programmatic = true;
/*     */   private boolean declarative = true;
/*     */   
/*     */   @Inject
/*     */   public void setActionValidatorManager(ActionValidatorManager mgr) {
/* 150 */     this.actionValidatorManager = mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProgrammatic(boolean programmatic) {
/* 160 */     this.programmatic = programmatic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeclarative(boolean declarative) {
/* 170 */     this.declarative = declarative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysInvokeValidate(String alwaysInvokeValidate) {
/* 180 */     this.alwaysInvokeValidate = Boolean.parseBoolean(alwaysInvokeValidate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidateAnnotatedMethodOnly() {
/* 189 */     return this.validateAnnotatedMethodOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidateAnnotatedMethodOnly(boolean validateAnnotatedMethodOnly) {
/* 199 */     this.validateAnnotatedMethodOnly = validateAnnotatedMethodOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doBeforeInvocation(ActionInvocation invocation) throws Exception {
/* 209 */     Object action = invocation.getAction();
/* 210 */     ActionProxy proxy = invocation.getProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     String context = getValidationContext(proxy);
/* 216 */     String method = proxy.getMethod();
/*     */     
/* 218 */     if (LOG.isDebugEnabled()) {
/* 219 */       LOG.debug("Validating {}/{} with method {}.", invocation.getProxy().getNamespace(), invocation.getProxy().getActionName(), method);
/*     */     }
/*     */ 
/*     */     
/* 223 */     if (this.declarative) {
/* 224 */       if (this.validateAnnotatedMethodOnly) {
/* 225 */         this.actionValidatorManager.validate(action, context, method);
/*     */       } else {
/* 227 */         this.actionValidatorManager.validate(action, context);
/*     */       } 
/*     */     }
/*     */     
/* 231 */     if (action instanceof Validateable && this.programmatic) {
/*     */       
/* 233 */       Exception exception = null;
/*     */       
/* 235 */       Validateable validateable = (Validateable)action;
/* 236 */       LOG.debug("Invoking validate() on action {}", validateable);
/*     */       
/*     */       try {
/* 239 */         PrefixMethodInvocationUtil.invokePrefixMethod(invocation, new String[] { "validate", "validateDo" });
/*     */       }
/* 241 */       catch (Exception e) {
/*     */ 
/*     */         
/* 244 */         LOG.warn("an exception occured while executing the prefix method", e);
/* 245 */         exception = e;
/*     */       } 
/*     */ 
/*     */       
/* 249 */       if (this.alwaysInvokeValidate) {
/* 250 */         validateable.validate();
/*     */       }
/*     */       
/* 253 */       if (exception != null)
/*     */       {
/* 255 */         throw exception;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String doIntercept(ActionInvocation invocation) throws Exception {
/* 262 */     doBeforeInvocation(invocation);
/* 263 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getValidationContext(ActionProxy proxy) {
/* 293 */     return proxy.getActionName();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\ValidationInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */