/*    */ package com.opensymphony.xwork2.util.logging.log4j2;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Log4j2LoggerFactory
/*    */   extends LoggerFactory
/*    */ {
/*    */   protected Logger getLoggerImpl(Class<?> cls) {
/* 39 */     return new Log4j2Logger(LogManager.getLogger(cls));
/*    */   }
/*    */ 
/*    */   
/*    */   protected Logger getLoggerImpl(String name) {
/* 44 */     return new Log4j2Logger(LogManager.getLogger(name));
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\logging\log4j2\Log4j2LoggerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */