/*    */ package com.opensymphony.xwork2.ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectProxy
/*    */ {
/*    */   private Object value;
/*    */   private Class lastClassAccessed;
/*    */   private String lastPropertyAccessed;
/*    */   
/*    */   public Class getLastClassAccessed() {
/* 35 */     return this.lastClassAccessed;
/*    */   }
/*    */   
/*    */   public void setLastClassAccessed(Class lastClassAccessed) {
/* 39 */     this.lastClassAccessed = lastClassAccessed;
/*    */   }
/*    */   
/*    */   public String getLastPropertyAccessed() {
/* 43 */     return this.lastPropertyAccessed;
/*    */   }
/*    */   
/*    */   public void setLastPropertyAccessed(String lastPropertyAccessed) {
/* 47 */     this.lastPropertyAccessed = lastPropertyAccessed;
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 51 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(Object value) {
/* 55 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\ObjectProxy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */