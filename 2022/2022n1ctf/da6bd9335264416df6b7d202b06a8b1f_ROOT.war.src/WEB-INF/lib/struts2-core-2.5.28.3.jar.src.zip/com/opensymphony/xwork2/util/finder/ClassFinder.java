/*     */ package com.opensymphony.xwork2.util.finder;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ClassFinder
/*     */ {
/*     */   boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<String> getClassesNotLoaded();
/*     */   
/*     */   List<Package> findAnnotatedPackages(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<Class> findAnnotatedClasses(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<Method> findAnnotatedMethods(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<Constructor> findAnnotatedConstructors(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<Field> findAnnotatedFields(Class<? extends Annotation> paramClass);
/*     */   
/*     */   List<Class> findClassesInPackage(String paramString, boolean paramBoolean);
/*     */   
/*     */   List<Class> findClasses(Test<ClassInfo> paramTest);
/*     */   
/*     */   List<Class> findClasses();
/*     */   
/*     */   ClassLoaderInterface getClassLoaderInterface();
/*     */   
/*     */   public static interface Info
/*     */   {
/*     */     String getName();
/*     */     
/*     */     List<ClassFinder.AnnotationInfo> getAnnotations();
/*     */   }
/*     */   
/*     */   public static class AnnotationInfo
/*     */     extends Annotatable
/*     */     implements Info
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     public AnnotationInfo(Annotation annotation) {
/*  96 */       this(annotation.getClass().getName());
/*     */     }
/*     */     
/*     */     public AnnotationInfo(Class<? extends Annotation> annotation) {
/* 100 */       this.name = annotation.getName().intern();
/*     */     }
/*     */     
/*     */     public AnnotationInfo(String name) {
/* 104 */       name = name.replaceAll("^L|;$", "");
/* 105 */       name = name.replace('/', '.');
/* 106 */       this.name = name.intern();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 110 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 115 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Annotatable {
/* 120 */     private final List<ClassFinder.AnnotationInfo> annotations = new ArrayList<>();
/*     */     
/*     */     public Annotatable(AnnotatedElement element) {
/* 123 */       for (Annotation annotation : element.getAnnotations()) {
/* 124 */         this.annotations.add(new ClassFinder.AnnotationInfo(annotation.annotationType().getName()));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotatable() {}
/*     */     
/*     */     public List<ClassFinder.AnnotationInfo> getAnnotations() {
/* 132 */       return this.annotations;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PackageInfo
/*     */     extends Annotatable implements Info {
/*     */     private final String name;
/*     */     private final ClassFinder.ClassInfo info;
/*     */     private final Package pkg;
/*     */     
/*     */     public PackageInfo(Package pkg) {
/* 143 */       super(pkg);
/* 144 */       this.pkg = pkg;
/* 145 */       this.name = pkg.getName();
/* 146 */       this.info = null;
/*     */     }
/*     */     
/*     */     public PackageInfo(String name, ClassFinder classFinder) {
/* 150 */       this.info = new ClassFinder.ClassInfo(name, null, classFinder);
/* 151 */       this.name = name;
/* 152 */       this.pkg = null;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 156 */       return this.name;
/*     */     }
/*     */     
/*     */     public Package get() throws ClassNotFoundException {
/* 160 */       return (this.pkg != null) ? this.pkg : this.info.get().getPackage();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ClassInfo extends Annotatable implements Info {
/*     */     private final String name;
/* 166 */     private final List<ClassFinder.MethodInfo> methods = new ArrayList<>();
/* 167 */     private final List<ClassFinder.MethodInfo> constructors = new ArrayList<>();
/*     */     private final String superType;
/* 169 */     private final List<String> interfaces = new ArrayList<>();
/* 170 */     private final List<String> superInterfaces = new ArrayList<>();
/* 171 */     private final List<ClassFinder.FieldInfo> fields = new ArrayList<>();
/*     */     private Class<?> clazz;
/*     */     private ClassFinder classFinder;
/*     */     private ClassNotFoundException notFound;
/*     */     
/*     */     public ClassInfo(Class<?> clazz, ClassFinder classFinder) {
/* 177 */       super(clazz);
/* 178 */       this.clazz = clazz;
/* 179 */       this.classFinder = classFinder;
/* 180 */       this.name = clazz.getName();
/* 181 */       Class<?> superclass = clazz.getSuperclass();
/* 182 */       this.superType = (superclass != null) ? superclass.getName() : null;
/*     */     }
/*     */     
/*     */     public ClassInfo(String name, String superType, ClassFinder classFinder) {
/* 186 */       this.name = name;
/* 187 */       this.superType = superType;
/* 188 */       this.classFinder = classFinder;
/*     */     }
/*     */     
/*     */     public String getPackageName() {
/* 192 */       return (this.name.indexOf('.') > 0) ? this.name.substring(0, this.name.lastIndexOf('.')) : "";
/*     */     }
/*     */     
/*     */     public List<ClassFinder.MethodInfo> getConstructors() {
/* 196 */       return this.constructors;
/*     */     }
/*     */     
/*     */     public List<String> getInterfaces() {
/* 200 */       return this.interfaces;
/*     */     }
/*     */     
/*     */     public List<String> getSuperInterfaces() {
/* 204 */       return this.superInterfaces;
/*     */     }
/*     */     
/*     */     public List<ClassFinder.FieldInfo> getFields() {
/* 208 */       return this.fields;
/*     */     }
/*     */     
/*     */     public List<ClassFinder.MethodInfo> getMethods() {
/* 212 */       return this.methods;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 216 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getSuperType() {
/* 220 */       return this.superType;
/*     */     }
/*     */     
/*     */     public Class get() throws ClassNotFoundException {
/* 224 */       if (this.clazz != null) return this.clazz; 
/* 225 */       if (this.notFound != null) throw this.notFound; 
/*     */       try {
/* 227 */         this.clazz = this.classFinder.getClassLoaderInterface().loadClass(this.name);
/* 228 */         return this.clazz;
/* 229 */       } catch (ClassNotFoundException notFound) {
/* 230 */         this.classFinder.getClassesNotLoaded().add(this.name);
/* 231 */         this.notFound = notFound;
/* 232 */         throw notFound;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 238 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MethodInfo extends Annotatable implements Info {
/*     */     private final ClassFinder.ClassInfo declaringClass;
/*     */     private final String returnType;
/*     */     private final String name;
/* 246 */     private final List<List<ClassFinder.AnnotationInfo>> parameterAnnotations = new ArrayList<>();
/*     */     
/*     */     public MethodInfo(ClassFinder.ClassInfo info, Constructor constructor) {
/* 249 */       super(constructor);
/* 250 */       this.declaringClass = info;
/* 251 */       this.name = "<init>";
/* 252 */       this.returnType = void.class.getName();
/*     */     }
/*     */     
/*     */     public MethodInfo(ClassFinder.ClassInfo info, Method method) {
/* 256 */       super(method);
/* 257 */       this.declaringClass = info;
/* 258 */       this.name = method.getName();
/* 259 */       this.returnType = method.getReturnType().getName();
/*     */     }
/*     */     
/*     */     public MethodInfo(ClassFinder.ClassInfo declarignClass, String name, String returnType) {
/* 263 */       this.declaringClass = declarignClass;
/* 264 */       this.name = name;
/* 265 */       this.returnType = returnType;
/*     */     }
/*     */     
/*     */     public List<List<ClassFinder.AnnotationInfo>> getParameterAnnotations() {
/* 269 */       return this.parameterAnnotations;
/*     */     }
/*     */     
/*     */     public List<ClassFinder.AnnotationInfo> getParameterAnnotations(int index) {
/* 273 */       if (index >= this.parameterAnnotations.size()) {
/* 274 */         for (int i = this.parameterAnnotations.size(); i <= index; i++) {
/* 275 */           List<ClassFinder.AnnotationInfo> annotationInfos = new ArrayList<>();
/* 276 */           this.parameterAnnotations.add(i, annotationInfos);
/*     */         } 
/*     */       }
/* 279 */       return this.parameterAnnotations.get(index);
/*     */     }
/*     */     
/*     */     public String getName() {
/* 283 */       return this.name;
/*     */     }
/*     */     
/*     */     public ClassFinder.ClassInfo getDeclaringClass() {
/* 287 */       return this.declaringClass;
/*     */     }
/*     */     
/*     */     public String getReturnType() {
/* 291 */       return this.returnType;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 296 */       return this.declaringClass + "@" + this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FieldInfo extends Annotatable implements Info {
/*     */     private final String name;
/*     */     private final String type;
/*     */     private final ClassFinder.ClassInfo declaringClass;
/*     */     
/*     */     public FieldInfo(ClassFinder.ClassInfo info, Field field) {
/* 306 */       super(field);
/* 307 */       this.declaringClass = info;
/* 308 */       this.name = field.getName();
/* 309 */       this.type = field.getType().getName();
/*     */     }
/*     */     
/*     */     public FieldInfo(ClassFinder.ClassInfo declaringClass, String name, String type) {
/* 313 */       this.declaringClass = declaringClass;
/* 314 */       this.name = name;
/* 315 */       this.type = type;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 319 */       return this.name;
/*     */     }
/*     */     
/*     */     public ClassFinder.ClassInfo getDeclaringClass() {
/* 323 */       return this.declaringClass;
/*     */     }
/*     */     
/*     */     public String getType() {
/* 327 */       return this.type;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 332 */       return this.declaringClass + "#" + this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\finder\ClassFinder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */