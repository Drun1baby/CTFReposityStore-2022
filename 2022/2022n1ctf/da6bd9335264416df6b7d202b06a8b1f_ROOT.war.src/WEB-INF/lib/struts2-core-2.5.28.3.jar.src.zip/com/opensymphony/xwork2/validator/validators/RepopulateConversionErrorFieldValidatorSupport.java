/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RepopulateConversionErrorFieldValidatorSupport
/*     */   extends FieldValidatorSupport
/*     */ {
/* 136 */   private static final Logger LOG = LogManager.getLogger(RepopulateConversionErrorFieldValidatorSupport.class);
/*     */   
/*     */   private boolean repopulateField = false;
/*     */   
/*     */   public boolean isRepopulateField() {
/* 141 */     return this.repopulateField;
/*     */   }
/*     */   
/*     */   public void setRepopulateField(boolean repopulateField) {
/* 145 */     this.repopulateField = repopulateField;
/*     */   }
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/* 149 */     doValidate(object);
/* 150 */     if (this.repopulateField) {
/* 151 */       repopulateField(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void repopulateField(Object object) throws ValidationException {
/* 157 */     ActionInvocation invocation = ActionContext.getContext().getActionInvocation();
/* 158 */     Map<String, Object> conversionErrors = ActionContext.getContext().getConversionErrors();
/*     */     
/* 160 */     String fieldName = getFieldName();
/* 161 */     String fullFieldName = getValidatorContext().getFullFieldName(fieldName);
/* 162 */     if (conversionErrors.containsKey(fullFieldName)) {
/* 163 */       Object value = conversionErrors.get(fullFieldName);
/*     */       
/* 165 */       final Map<Object, Object> fakeParams = new LinkedHashMap<>();
/* 166 */       boolean doExprOverride = false;
/*     */       
/* 168 */       if (value instanceof String[]) {
/*     */         
/* 170 */         String[] tmpValue = (String[])value;
/* 171 */         if (tmpValue.length > 0) {
/* 172 */           doExprOverride = true;
/* 173 */           fakeParams.put(fullFieldName, escape(tmpValue[0]));
/*     */         } else {
/* 175 */           LOG.warn("value is an empty array of String or with first element in it as null [{}], will not repopulate conversion error", value);
/*     */         } 
/* 177 */       } else if (value instanceof String) {
/* 178 */         String tmpValue = (String)value;
/* 179 */         doExprOverride = true;
/* 180 */         fakeParams.put(fullFieldName, escape(tmpValue));
/*     */       } else {
/*     */         
/* 183 */         LOG.warn("conversion error value is not a String or array of String but instead is [{}], will not repopulate conversion error", value);
/*     */       } 
/*     */       
/* 186 */       if (doExprOverride) {
/* 187 */         invocation.addPreResultListener(new PreResultListener() {
/*     */               public void beforeResult(ActionInvocation invocation, String resultCode) {
/* 189 */                 ValueStack stack = ActionContext.getContext().getValueStack();
/* 190 */                 stack.setExprOverrides(fakeParams);
/*     */               }
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String escape(String value) {
/* 198 */     return "\"" + StringEscapeUtils.escapeJava(value) + "\"";
/*     */   }
/*     */   
/*     */   protected abstract void doValidate(Object paramObject) throws ValidationException;
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\RepopulateConversionErrorFieldValidatorSupport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */