/*     */ package com.opensymphony.xwork2.inject.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.ref.Reference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceMap<K, V>
/*     */   implements Map<K, V>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 0L;
/*     */   transient ConcurrentMap<Object, Object> delegate;
/*     */   final ReferenceType keyReferenceType;
/*     */   final ReferenceType valueReferenceType;
/*     */   private static PutStrategy defaultPutStrategy;
/*     */   
/*     */   public ReferenceMap(ReferenceType keyReferenceType, ReferenceType valueReferenceType) {
/*  77 */     ensureNotNull(new Object[] { keyReferenceType, valueReferenceType });
/*     */     
/*  79 */     if (keyReferenceType == ReferenceType.PHANTOM || valueReferenceType == ReferenceType.PHANTOM) {
/*  80 */       throw new IllegalArgumentException("Phantom references not supported.");
/*     */     }
/*     */     
/*  83 */     this.delegate = new ConcurrentHashMap<>();
/*  84 */     this.keyReferenceType = keyReferenceType;
/*  85 */     this.valueReferenceType = valueReferenceType;
/*     */   }
/*     */   
/*     */   V internalGet(K key) {
/*  89 */     Object valueReference = this.delegate.get(makeKeyReferenceAware(key));
/*  90 */     return (valueReference == null) ? null : dereferenceValue(valueReference);
/*     */   }
/*     */   
/*     */   public V get(Object key) {
/*  94 */     ensureNotNull(key);
/*  95 */     return internalGet((K)key);
/*     */   }
/*     */   
/*     */   V execute(Strategy strategy, K key, V value) {
/*  99 */     ensureNotNull(new Object[] { key, value });
/* 100 */     Object keyReference = referenceKey(key);
/* 101 */     Object valueReference = strategy.execute(this, keyReference, referenceValue(keyReference, value));
/* 102 */     return (valueReference == null) ? null : dereferenceValue(valueReference);
/*     */   }
/*     */   
/*     */   public V put(K key, V value) {
/* 106 */     return execute(putStrategy(), key, value);
/*     */   }
/*     */   
/*     */   public V remove(Object key) {
/* 110 */     ensureNotNull(key);
/* 111 */     Object referenceAwareKey = makeKeyReferenceAware(key);
/* 112 */     Object valueReference = this.delegate.remove(referenceAwareKey);
/* 113 */     return (valueReference == null) ? null : dereferenceValue(valueReference);
/*     */   }
/*     */   
/*     */   public int size() {
/* 117 */     return this.delegate.size();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 121 */     return this.delegate.isEmpty();
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 125 */     ensureNotNull(key);
/* 126 */     Object referenceAwareKey = makeKeyReferenceAware(key);
/* 127 */     return this.delegate.containsKey(referenceAwareKey);
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 131 */     ensureNotNull(value);
/* 132 */     for (Object valueReference : this.delegate.values()) {
/* 133 */       if (value.equals(dereferenceValue(valueReference))) {
/* 134 */         return true;
/*     */       }
/*     */     } 
/* 137 */     return false;
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> t) {
/* 141 */     for (Map.Entry<? extends K, ? extends V> entry : t.entrySet()) {
/* 142 */       put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/* 147 */     this.delegate.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 155 */     return Collections.unmodifiableSet(dereferenceKeySet(this.delegate.keySet()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 163 */     return Collections.unmodifiableCollection(dereferenceValues(this.delegate.values()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V putIfAbsent(K key, V value) {
/* 169 */     return execute(putIfAbsentStrategy(), key, value);
/*     */   }
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/* 173 */     ensureNotNull(new Object[] { key, value });
/* 174 */     Object referenceAwareKey = makeKeyReferenceAware(key);
/* 175 */     Object referenceAwareValue = makeValueReferenceAware(value);
/* 176 */     return this.delegate.remove(referenceAwareKey, referenceAwareValue);
/*     */   }
/*     */   
/*     */   public boolean replace(K key, V oldValue, V newValue) {
/* 180 */     ensureNotNull(new Object[] { key, oldValue, newValue });
/* 181 */     Object keyReference = referenceKey(key);
/*     */     
/* 183 */     Object referenceAwareOldValue = makeValueReferenceAware(oldValue);
/* 184 */     return this.delegate.replace(keyReference, referenceAwareOldValue, referenceValue(keyReference, newValue));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V replace(K key, V value) {
/* 190 */     return execute(replaceStrategy(), key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 198 */     Set<Map.Entry<K, V>> entrySet = new HashSet<>();
/* 199 */     for (Map.Entry<Object, Object> entry : this.delegate.entrySet()) {
/* 200 */       Map.Entry<K, V> dereferenced = dereferenceEntry(entry);
/* 201 */       if (dereferenced != null) {
/* 202 */         entrySet.add(dereferenced);
/*     */       }
/*     */     } 
/* 205 */     return Collections.unmodifiableSet(entrySet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Entry dereferenceEntry(Map.Entry<Object, Object> entry) {
/* 212 */     K key = dereferenceKey(entry.getKey());
/* 213 */     V value = dereferenceValue(entry.getValue());
/* 214 */     return (key == null || value == null) ? null : new Entry(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object referenceKey(K key) {
/* 221 */     switch (this.keyReferenceType) {
/*     */       case STRONG:
/* 223 */         return key;
/*     */       case SOFT:
/* 225 */         return new SoftKeyReference(key);
/*     */       case WEAK:
/* 227 */         return new WeakKeyReference(key);
/*     */     } 
/* 229 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   K dereferenceKey(Object o) {
/* 237 */     return (K)dereference(this.keyReferenceType, o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   V dereferenceValue(Object o) {
/* 244 */     return (V)dereference(this.valueReferenceType, o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object dereference(ReferenceType referenceType, Object reference) {
/* 251 */     return (referenceType == ReferenceType.STRONG) ? reference : ((Reference)reference).get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object referenceValue(Object keyReference, Object value) {
/* 258 */     switch (this.valueReferenceType) {
/*     */       case STRONG:
/* 260 */         return value;
/*     */       case SOFT:
/* 262 */         return new SoftValueReference(keyReference, value);
/*     */       case WEAK:
/* 264 */         return new WeakValueReference(keyReference, value);
/*     */     } 
/* 266 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<K> dereferenceKeySet(Set<K> keyReferences) {
/* 274 */     return (this.keyReferenceType == ReferenceType.STRONG) ? keyReferences : dereferenceCollection(this.keyReferenceType, keyReferences, new HashSet<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<V> dereferenceValues(Collection<V> valueReferences) {
/* 283 */     return (this.valueReferenceType == ReferenceType.STRONG) ? valueReferences : dereferenceCollection(this.valueReferenceType, valueReferences, new ArrayList<>(valueReferences.size()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object makeKeyReferenceAware(Object o) {
/* 293 */     return (this.keyReferenceType == ReferenceType.STRONG) ? o : new KeyReferenceAwareWrapper(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object makeValueReferenceAware(Object o) {
/* 300 */     return (this.valueReferenceType == ReferenceType.STRONG) ? o : new ReferenceAwareWrapper(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T extends Collection<Object>> T dereferenceCollection(ReferenceType referenceType, T in, T out) {
/* 309 */     for (Object reference : in) {
/* 310 */       out.add(dereference(referenceType, reference));
/*     */     }
/* 312 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int keyHashCode(Object key) {
/* 322 */     return System.identityHashCode(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean referenceEquals(Reference r, Object o) {
/* 334 */     if (o instanceof InternalReference) {
/*     */       
/* 336 */       if (o == r) {
/* 337 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 341 */       Object referent = ((Reference)o).get();
/* 342 */       return (referent != null && referent == r.get());
/*     */     } 
/*     */ 
/*     */     
/* 346 */     return (((ReferenceAwareWrapper)o).unwrap() == r.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class ReferenceAwareWrapper
/*     */   {
/*     */     Object wrapped;
/*     */ 
/*     */ 
/*     */     
/*     */     ReferenceAwareWrapper(Object wrapped) {
/* 358 */       this.wrapped = wrapped;
/*     */     }
/*     */     
/*     */     Object unwrap() {
/* 362 */       return this.wrapped;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 367 */       return this.wrapped.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 373 */       return obj.equals(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class KeyReferenceAwareWrapper
/*     */     extends ReferenceAwareWrapper
/*     */   {
/*     */     public KeyReferenceAwareWrapper(Object wrapped) {
/* 383 */       super(wrapped);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 388 */       return System.identityHashCode(this.wrapped);
/*     */     }
/*     */   }
/*     */   
/*     */   class SoftKeyReference
/*     */     extends FinalizableSoftReference<Object> implements InternalReference {
/*     */     int hashCode;
/*     */     
/*     */     public SoftKeyReference(Object key) {
/* 397 */       super(key);
/* 398 */       this.hashCode = ReferenceMap.keyHashCode(key);
/*     */     }
/*     */     
/*     */     public void finalizeReferent() {
/* 402 */       ReferenceMap.this.delegate.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 407 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 412 */       return ReferenceMap.referenceEquals(this, o);
/*     */     }
/*     */   }
/*     */   
/*     */   class WeakKeyReference
/*     */     extends FinalizableWeakReference<Object> implements InternalReference {
/*     */     int hashCode;
/*     */     
/*     */     public WeakKeyReference(Object key) {
/* 421 */       super(key);
/* 422 */       this.hashCode = ReferenceMap.keyHashCode(key);
/*     */     }
/*     */     
/*     */     public void finalizeReferent() {
/* 426 */       ReferenceMap.this.delegate.remove(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 431 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 436 */       return ReferenceMap.referenceEquals(this, o);
/*     */     }
/*     */   }
/*     */   
/*     */   class SoftValueReference
/*     */     extends FinalizableSoftReference<Object> implements InternalReference {
/*     */     Object keyReference;
/*     */     
/*     */     public SoftValueReference(Object keyReference, Object value) {
/* 445 */       super(value);
/* 446 */       this.keyReference = keyReference;
/*     */     }
/*     */     
/*     */     public void finalizeReferent() {
/* 450 */       ReferenceMap.this.delegate.remove(this.keyReference, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 455 */       return ReferenceMap.referenceEquals(this, obj);
/*     */     }
/*     */   }
/*     */   
/*     */   class WeakValueReference
/*     */     extends FinalizableWeakReference<Object> implements InternalReference {
/*     */     Object keyReference;
/*     */     
/*     */     public WeakValueReference(Object keyReference, Object value) {
/* 464 */       super(value);
/* 465 */       this.keyReference = keyReference;
/*     */     }
/*     */     
/*     */     public void finalizeReferent() {
/* 469 */       ReferenceMap.this.delegate.remove(this.keyReference, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 474 */       return ReferenceMap.referenceEquals(this, obj);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Strategy putStrategy() {
/* 483 */     return PutStrategy.PUT;
/*     */   }
/*     */   
/*     */   protected Strategy putIfAbsentStrategy() {
/* 487 */     return PutStrategy.PUT_IF_ABSENT;
/*     */   }
/*     */   
/*     */   protected Strategy replaceStrategy() {
/* 491 */     return PutStrategy.REPLACE;
/*     */   }
/*     */   
/*     */   private enum PutStrategy implements Strategy {
/* 495 */     PUT {
/*     */       public Object execute(ReferenceMap map, Object keyReference, Object valueReference) {
/* 497 */         return map.delegate.put(keyReference, valueReference);
/*     */       }
/*     */     },
/*     */     
/* 501 */     REPLACE {
/*     */       public Object execute(ReferenceMap map, Object keyReference, Object valueReference) {
/* 503 */         return map.delegate.replace(keyReference, valueReference);
/*     */       }
/*     */     },
/*     */     
/* 507 */     PUT_IF_ABSENT {
/*     */       public Object execute(ReferenceMap map, Object keyReference, Object valueReference) {
/* 509 */         return map.delegate.putIfAbsent(keyReference, valueReference);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PutStrategy getPutStrategy() {
/* 517 */     return defaultPutStrategy;
/*     */   }
/*     */   
/*     */   class Entry
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     K key;
/*     */     V value;
/*     */     
/*     */     public Entry(K key, V value) {
/* 527 */       this.key = key;
/* 528 */       this.value = value;
/*     */     }
/*     */     
/*     */     public K getKey() {
/* 532 */       return this.key;
/*     */     }
/*     */     
/*     */     public V getValue() {
/* 536 */       return this.value;
/*     */     }
/*     */     
/*     */     public V setValue(V value) {
/* 540 */       return ReferenceMap.this.put(this.key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 545 */       return this.key.hashCode() * 31 + this.value.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 550 */       if (!(o instanceof Entry)) {
/* 551 */         return false;
/*     */       }
/*     */       
/* 554 */       Entry entry = (Entry)o;
/* 555 */       return (this.key.equals(entry.key) && this.value.equals(entry.value));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 560 */       return (new StringBuilder()).append(this.key).append("=").append(this.value).toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static void ensureNotNull(Object o) {
/* 565 */     if (o == null) {
/* 566 */       throw new NullPointerException();
/*     */     }
/*     */   }
/*     */   
/*     */   static void ensureNotNull(Object... array) {
/* 571 */     for (int i = 0; i < array.length; i++) {
/* 572 */       if (array[i] == null) {
/* 573 */         throw new NullPointerException("Argument #" + i + " is null.");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 579 */     out.defaultWriteObject();
/* 580 */     out.writeInt(size());
/* 581 */     for (Map.Entry<Object, Object> entry : this.delegate.entrySet()) {
/* 582 */       Object key = dereferenceKey(entry.getKey());
/* 583 */       Object value = dereferenceValue(entry.getValue());
/*     */ 
/*     */       
/* 586 */       if (key != null && value != null) {
/* 587 */         out.writeObject(key);
/* 588 */         out.writeObject(value);
/*     */       } 
/*     */     } 
/* 591 */     out.writeObject(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 596 */     in.defaultReadObject();
/* 597 */     int size = in.readInt();
/* 598 */     this.delegate = new ConcurrentHashMap<>(size);
/*     */     while (true) {
/* 600 */       K key = (K)in.readObject();
/* 601 */       if (key == null) {
/*     */         break;
/*     */       }
/* 604 */       V value = (V)in.readObject();
/* 605 */       put(key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static interface Strategy {
/*     */     Object execute(ReferenceMap param1ReferenceMap, Object param1Object1, Object param1Object2);
/*     */   }
/*     */   
/*     */   static interface InternalReference {}
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\injec\\util\ReferenceMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */