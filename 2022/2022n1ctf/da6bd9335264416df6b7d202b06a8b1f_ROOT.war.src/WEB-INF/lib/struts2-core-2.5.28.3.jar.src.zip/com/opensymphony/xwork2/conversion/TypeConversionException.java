/*    */ package com.opensymphony.xwork2.conversion;
/*    */ 
/*    */ import com.opensymphony.xwork2.XWorkException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeConversionException
/*    */   extends XWorkException
/*    */ {
/*    */   public TypeConversionException() {}
/*    */   
/*    */   public TypeConversionException(String s) {
/* 45 */     super(s);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeConversionException(Throwable cause) {
/* 53 */     super(cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeConversionException(String s, Throwable cause) {
/* 64 */     super(s, cause);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\conversion\TypeConversionException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */