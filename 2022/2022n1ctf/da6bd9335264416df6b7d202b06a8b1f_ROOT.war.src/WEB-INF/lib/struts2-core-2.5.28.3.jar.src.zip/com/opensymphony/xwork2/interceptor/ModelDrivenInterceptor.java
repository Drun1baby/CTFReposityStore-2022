/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ModelDriven;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelDrivenInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*     */   protected boolean refreshModelBeforeResult = false;
/*     */   
/*     */   public void setRefreshModelBeforeResult(boolean val) {
/*  83 */     this.refreshModelBeforeResult = val;
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/*  88 */     Object action = invocation.getAction();
/*     */     
/*  90 */     if (action instanceof ModelDriven) {
/*  91 */       ModelDriven modelDriven = (ModelDriven)action;
/*  92 */       ValueStack stack = invocation.getStack();
/*  93 */       Object model = modelDriven.getModel();
/*  94 */       if (model != null) {
/*  95 */         stack.push(model);
/*     */       }
/*  97 */       if (this.refreshModelBeforeResult) {
/*  98 */         invocation.addPreResultListener(new RefreshModelBeforeResult(modelDriven, model));
/*     */       }
/*     */     } 
/* 101 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class RefreshModelBeforeResult
/*     */     implements PreResultListener
/*     */   {
/* 108 */     private Object originalModel = null;
/*     */     
/*     */     protected ModelDriven action;
/*     */     
/*     */     public RefreshModelBeforeResult(ModelDriven action, Object model) {
/* 113 */       this.originalModel = model;
/* 114 */       this.action = action;
/*     */     }
/*     */     
/*     */     public void beforeResult(ActionInvocation invocation, String resultCode) {
/* 118 */       ValueStack stack = invocation.getStack();
/* 119 */       CompoundRoot root = stack.getRoot();
/*     */       
/* 121 */       boolean needsRefresh = true;
/* 122 */       Object newModel = this.action.getModel();
/*     */ 
/*     */       
/* 125 */       for (Object item : root) {
/* 126 */         if (item.equals(newModel)) {
/* 127 */           needsRefresh = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 133 */       if (needsRefresh) {
/*     */ 
/*     */         
/* 136 */         if (this.originalModel != null) {
/* 137 */           root.remove(this.originalModel);
/*     */         }
/* 139 */         if (newModel != null)
/* 140 */           stack.push(newModel); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ModelDrivenInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */