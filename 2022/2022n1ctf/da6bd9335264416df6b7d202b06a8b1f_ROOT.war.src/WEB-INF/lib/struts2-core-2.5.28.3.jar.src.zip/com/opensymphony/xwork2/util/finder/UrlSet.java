/*     */ package com.opensymphony.xwork2.util.finder;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlSet
/*     */ {
/*  52 */   private static final Logger LOG = LogManager.getLogger(UrlSet.class);
/*     */   
/*     */   private final Map<String, URL> urls;
/*     */   private Set<String> protocols;
/*     */   
/*     */   private UrlSet() {
/*  58 */     this.urls = new HashMap<>();
/*     */   }
/*     */   
/*     */   public UrlSet(ClassLoaderInterface classLoader) throws IOException {
/*  62 */     this();
/*  63 */     load(getUrls(classLoader));
/*     */   }
/*     */   
/*     */   public UrlSet(ClassLoaderInterface classLoader, Set<String> protocols) throws IOException {
/*  67 */     this();
/*  68 */     this.protocols = protocols;
/*  69 */     load(getUrls(classLoader, protocols));
/*     */   }
/*     */   
/*     */   public UrlSet(URL... urls) {
/*  73 */     this(Arrays.asList(urls));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlSet(Collection<URL> urls) {
/*  80 */     this();
/*  81 */     load(urls);
/*     */   }
/*     */   
/*     */   private UrlSet(Map<String, URL> urls) {
/*  85 */     this.urls = urls;
/*     */   }
/*     */   
/*     */   private void load(Collection<URL> urls) {
/*  89 */     for (URL location : urls) {
/*     */       try {
/*  91 */         this.urls.put(location.toExternalForm(), location);
/*  92 */       } catch (Exception e) {
/*  93 */         LOG.warn("Cannot translate url to external form!", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public UrlSet include(UrlSet urlSet) {
/*  99 */     Map<String, URL> urls = new HashMap<>(this.urls);
/* 100 */     urls.putAll(urlSet.urls);
/* 101 */     return new UrlSet(urls);
/*     */   }
/*     */   
/*     */   public UrlSet exclude(UrlSet urlSet) {
/* 105 */     Map<String, URL> urls = new HashMap<>(this.urls);
/* 106 */     Map<String, URL> parentUrls = urlSet.urls;
/* 107 */     for (String url : parentUrls.keySet()) {
/* 108 */       urls.remove(url);
/*     */     }
/* 110 */     return new UrlSet(urls);
/*     */   }
/*     */   
/*     */   public UrlSet exclude(ClassLoaderInterface parent) throws IOException {
/* 114 */     return exclude(new UrlSet(parent, this.protocols));
/*     */   }
/*     */   
/*     */   public UrlSet exclude(File file) throws MalformedURLException {
/* 118 */     return exclude(relative(file));
/*     */   }
/*     */   
/*     */   public UrlSet exclude(String pattern) throws MalformedURLException {
/* 122 */     return exclude(matching(pattern));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlSet excludeJavaExtDirs() throws MalformedURLException {
/* 131 */     return excludePaths(System.getProperty("java.ext.dirs", ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlSet excludeJavaEndorsedDirs() throws MalformedURLException {
/* 141 */     return excludePaths(System.getProperty("java.endorsed.dirs", ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlSet excludeUserExtensionsDir() throws MalformedURLException {
/* 151 */     return excludePaths(System.getProperty("java.ext.dirs", ""));
/*     */   }
/*     */   
/*     */   public UrlSet excludeJavaHome() throws MalformedURLException {
/* 155 */     String path = System.getProperty("java.home");
/* 156 */     if (path != null) {
/* 157 */       File java = new File(path);
/* 158 */       if (path.matches("/System/Library/Frameworks/JavaVM.framework/Versions/[^/]+/Home")) {
/* 159 */         java = java.getParentFile();
/*     */       }
/* 161 */       return exclude(java);
/*     */     } 
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlSet excludePaths(String pathString) throws MalformedURLException {
/* 168 */     String[] paths = pathString.split(File.pathSeparator);
/* 169 */     UrlSet urlSet = this;
/* 170 */     for (String path : paths) {
/* 171 */       if (StringUtils.isNotEmpty(path)) {
/* 172 */         File file = new File(path);
/* 173 */         urlSet = urlSet.exclude(file);
/*     */       } 
/*     */     } 
/* 176 */     return urlSet;
/*     */   }
/*     */   
/*     */   public UrlSet matching(String pattern) {
/* 180 */     Map<String, URL> urls = new HashMap<>();
/* 181 */     for (Map.Entry<String, URL> entry : this.urls.entrySet()) {
/* 182 */       String url = entry.getKey();
/* 183 */       if (url.matches(pattern)) {
/* 184 */         urls.put(url, entry.getValue());
/*     */       }
/*     */     } 
/* 187 */     return new UrlSet(urls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlSet includeClassesUrl(ClassLoaderInterface classLoaderInterface, FileProtocolNormalizer normalizer) throws IOException {
/* 200 */     Enumeration<URL> rootUrlEnumeration = classLoaderInterface.getResources("");
/* 201 */     while (rootUrlEnumeration.hasMoreElements()) {
/* 202 */       URL url = rootUrlEnumeration.nextElement();
/* 203 */       String externalForm = StringUtils.removeEnd(url.toExternalForm(), "/");
/* 204 */       if (externalForm.endsWith(".war/WEB-INF/classes")) {
/*     */         
/* 206 */         externalForm = StringUtils.substringBefore(externalForm, "/WEB-INF/classes");
/* 207 */         URL warUrl = new URL(externalForm);
/* 208 */         URL normalizedUrl = normalizer.normalizeToFileProtocol(warUrl);
/* 209 */         URL finalUrl = (URL)ObjectUtils.defaultIfNull(normalizedUrl, warUrl);
/*     */         
/* 211 */         Map<String, URL> newUrls = new HashMap<>(this.urls);
/* 212 */         if ("jar".equals(finalUrl.getProtocol()) || "file".equals(finalUrl.getProtocol())) {
/* 213 */           newUrls.put(finalUrl.toExternalForm(), finalUrl);
/*     */         }
/* 215 */         return new UrlSet(newUrls);
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     return this;
/*     */   }
/*     */   
/*     */   public UrlSet relative(File file) throws MalformedURLException {
/* 223 */     String urlPath = file.toURI().toURL().toExternalForm();
/* 224 */     Map<String, URL> urls = new HashMap<>();
/* 225 */     for (Map.Entry<String, URL> entry : this.urls.entrySet()) {
/* 226 */       String url = entry.getKey();
/* 227 */       if (url.startsWith(urlPath) || url.startsWith("jar:" + urlPath)) {
/* 228 */         urls.put(url, entry.getValue());
/*     */       }
/*     */     } 
/* 231 */     return new UrlSet(urls);
/*     */   }
/*     */   
/*     */   public List<URL> getUrls() {
/* 235 */     return new ArrayList<>(this.urls.values());
/*     */   }
/*     */   
/*     */   private List<URL> getUrls(ClassLoaderInterface classLoader) throws IOException {
/* 239 */     List<URL> list = new ArrayList<>();
/*     */ 
/*     */     
/* 242 */     ArrayList<URL> urls = Collections.list(classLoader.getResources("META-INF"));
/*     */     
/* 244 */     for (URL url : urls) {
/* 245 */       if ("jar".equalsIgnoreCase(url.getProtocol())) {
/* 246 */         String externalForm = url.toExternalForm();
/*     */         
/* 248 */         url = new URL(StringUtils.substringBefore(externalForm, "META-INF"));
/* 249 */         list.add(url); continue;
/*     */       } 
/* 251 */       LOG.debug("Ignoring URL [{}] because it is not a jar", url.toExternalForm());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 256 */     list.addAll(Collections.list(classLoader.getResources("")));
/* 257 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<URL> getUrls(ClassLoaderInterface classLoader, Set<String> protocols) throws IOException {
/* 262 */     if (protocols == null) {
/* 263 */       return getUrls(classLoader);
/*     */     }
/*     */     
/* 266 */     List<URL> list = new ArrayList<>();
/*     */ 
/*     */     
/* 269 */     ArrayList<URL> urls = Collections.list(classLoader.getResources("META-INF"));
/*     */     
/* 271 */     for (URL url : urls) {
/* 272 */       if (protocols.contains(url.getProtocol())) {
/* 273 */         String externalForm = url.toExternalForm();
/*     */         
/* 275 */         url = new URL(StringUtils.substringBefore(externalForm, "META-INF"));
/* 276 */         list.add(url); continue;
/*     */       } 
/* 278 */       LOG.debug("Ignoring URL [{}] because it is not a valid protocol", url.toExternalForm());
/*     */     } 
/*     */     
/* 281 */     return list;
/*     */   }
/*     */   
/*     */   public static interface FileProtocolNormalizer {
/*     */     URL normalizeToFileProtocol(URL param1URL);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\finder\UrlSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */