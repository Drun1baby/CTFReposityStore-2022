/*     */ package com.opensymphony.xwork2.ognl.accessor;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import ognl.MethodFailedException;
/*     */ import ognl.ObjectMethodAccessor;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.PropertyAccessor;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XWorkMethodAccessor
/*     */   extends ObjectMethodAccessor
/*     */ {
/*  40 */   private static final Logger LOG = LogManager.getLogger(XWorkMethodAccessor.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object callMethod(Map context, Object object, String string, Object[] objects) throws MethodFailedException {
/*  50 */     if (objects.length == 1 && context instanceof OgnlContext) {
/*     */       try {
/*  52 */         OgnlContext ogContext = (OgnlContext)context;
/*  53 */         if (OgnlRuntime.hasSetProperty(ogContext, object, string)) {
/*  54 */           PropertyDescriptor descriptor = OgnlRuntime.getPropertyDescriptor(object.getClass(), string);
/*  55 */           Class<?> propertyType = descriptor.getPropertyType();
/*  56 */           if (Collection.class.isAssignableFrom(propertyType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  62 */             Object propVal = OgnlRuntime.getProperty(ogContext, object, string);
/*     */ 
/*     */             
/*  65 */             PropertyAccessor accessor = OgnlRuntime.getPropertyAccessor(Collection.class);
/*  66 */             ReflectionContextState.setGettingByKeyProperty((Map)ogContext, true);
/*  67 */             return accessor.getProperty((Map)ogContext, propVal, objects[0]);
/*     */           } 
/*     */         } 
/*  70 */       } catch (Exception oe) {
/*     */ 
/*     */         
/*  73 */         LOG.error("An unexpected exception occurred", oe);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  79 */     if ((objects.length == 2 && string.startsWith("set")) || (objects.length == 1 && string.startsWith("get"))) {
/*  80 */       Boolean bool = (Boolean)context.get("xwork.IndexedPropertyAccessor.denyMethodExecution");
/*  81 */       boolean bool1 = (bool == null) ? false : bool.booleanValue();
/*  82 */       if (!bool1) {
/*  83 */         return callMethodWithDebugInfo(context, object, string, objects);
/*     */       }
/*     */     } 
/*  86 */     Boolean exec = (Boolean)context.get("xwork.MethodAccessor.denyMethodExecution");
/*  87 */     boolean e = (exec == null) ? false : exec.booleanValue();
/*     */     
/*  89 */     if (!e) {
/*  90 */       return callMethodWithDebugInfo(context, object, string, objects);
/*     */     }
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object callMethodWithDebugInfo(Map context, Object object, String methodName, Object[] objects) throws MethodFailedException {
/*     */     try {
/*  98 */       return super.callMethod(context, object, methodName, objects);
/*     */     }
/* 100 */     catch (MethodFailedException e) {
/* 101 */       if (LOG.isDebugEnabled() && 
/* 102 */         !(e.getReason() instanceof NoSuchMethodException))
/*     */       {
/* 104 */         LOG.debug("Error calling method through OGNL: object: [{}] method: [{}] args: [{}]", e.getReason(), object.toString(), methodName, Arrays.toString(objects));
/*     */       }
/*     */       
/* 107 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object callStaticMethod(Map context, Class aClass, String string, Object[] objects) throws MethodFailedException {
/* 113 */     Boolean exec = (Boolean)context.get("xwork.MethodAccessor.denyMethodExecution");
/* 114 */     boolean e = (exec == null) ? false : exec.booleanValue();
/*     */     
/* 116 */     if (!e) {
/* 117 */       return callStaticMethodWithDebugInfo(context, aClass, string, objects);
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object callStaticMethodWithDebugInfo(Map context, Class aClass, String methodName, Object[] objects) throws MethodFailedException {
/*     */     try {
/* 126 */       return super.callStaticMethod(context, aClass, methodName, objects);
/*     */     }
/* 128 */     catch (MethodFailedException e) {
/* 129 */       if (LOG.isDebugEnabled() && 
/* 130 */         !(e.getReason() instanceof NoSuchMethodException))
/*     */       {
/* 132 */         LOG.debug("Error calling method through OGNL, class: [{}] method: [{}] args: [{}]", e.getReason(), aClass.getName(), methodName, Arrays.toString(objects));
/*     */       }
/*     */       
/* 135 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\XWorkMethodAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */