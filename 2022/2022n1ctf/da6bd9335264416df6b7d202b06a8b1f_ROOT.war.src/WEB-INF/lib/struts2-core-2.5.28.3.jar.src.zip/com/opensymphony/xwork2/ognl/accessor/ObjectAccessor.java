/*    */ package com.opensymphony.xwork2.ognl.accessor;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*    */ import java.util.Map;
/*    */ import ognl.ObjectPropertyAccessor;
/*    */ import ognl.OgnlException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectAccessor
/*    */   extends ObjectPropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map<String, Class<?>> map, Object o, Object o1) throws OgnlException {
/* 32 */     Object obj = super.getProperty(map, o, o1);
/*    */     
/* 34 */     map.put("last.bean.accessed", o.getClass());
/* 35 */     map.put("last.property.accessed", o1.toString());
/* 36 */     ReflectionContextState.updateCurrentPropertyPath(map, o1);
/* 37 */     return obj;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(Map map, Object o, Object o1, Object o2) throws OgnlException {
/* 42 */     super.setProperty(map, o, o1, o2);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\ognl\accessor\ObjectAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */