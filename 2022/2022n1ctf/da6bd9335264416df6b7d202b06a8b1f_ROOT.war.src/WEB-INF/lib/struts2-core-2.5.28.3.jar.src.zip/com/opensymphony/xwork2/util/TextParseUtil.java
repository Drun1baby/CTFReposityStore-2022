/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextParseUtil
/*     */ {
/*     */   public static String translateVariables(String expression, ValueStack stack) {
/*  48 */     return translateVariables(new char[] { '$', '%' }, expression, stack, String.class, (ParsedValueEvaluator)null).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String translateVariables(String expression, ValueStack stack, ParsedValueEvaluator evaluator) {
/*  70 */     return translateVariables(new char[] { '$', '%' }, expression, stack, String.class, evaluator).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String translateVariables(char open, String expression, ValueStack stack) {
/*  85 */     return translateVariables(open, expression, stack, String.class, (ParsedValueEvaluator)null).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object translateVariables(char open, String expression, ValueStack stack, Class asType) {
/*  98 */     return translateVariables(open, expression, stack, asType, (ParsedValueEvaluator)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object translateVariables(char open, String expression, ValueStack stack, Class asType, ParsedValueEvaluator evaluator) {
/* 112 */     return translateVariables(new char[] { open }, expression, stack, asType, evaluator, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object translateVariables(char[] openChars, String expression, ValueStack stack, Class asType, ParsedValueEvaluator evaluator) {
/* 126 */     return translateVariables(openChars, expression, stack, asType, evaluator, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object translateVariables(char open, String expression, ValueStack stack, Class asType, ParsedValueEvaluator evaluator, int maxLoopCount) {
/* 141 */     return translateVariables(new char[] { open }, expression, stack, asType, evaluator, maxLoopCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object translateVariables(char[] openChars, String expression, final ValueStack stack, final Class asType, final ParsedValueEvaluator evaluator, int maxLoopCount) {
/* 157 */     ParsedValueEvaluator ognlEval = new ParsedValueEvaluator() {
/*     */         public Object evaluate(String parsedValue) {
/* 159 */           Object o = stack.findValue(parsedValue, asType);
/* 160 */           if (evaluator != null && o != null) {
/* 161 */             o = evaluator.evaluate(o.toString());
/*     */           }
/* 163 */           return o;
/*     */         }
/*     */       };
/*     */     
/* 167 */     TextParser parser = (TextParser)((Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container")).getInstance(TextParser.class);
/*     */     
/* 169 */     return parser.evaluate(openChars, expression, ognlEval, maxLoopCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<String> translateVariablesCollection(String expression, ValueStack stack, boolean excludeEmptyElements, ParsedValueEvaluator evaluator) {
/* 182 */     return translateVariablesCollection(new char[] { '$', '%' }, expression, stack, excludeEmptyElements, evaluator, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<String> translateVariablesCollection(char[] openChars, String expression, final ValueStack stack, boolean excludeEmptyElements, ParsedValueEvaluator evaluator, int maxLoopCount) {
/*     */     Collection<String> resultCol;
/* 202 */     ParsedValueEvaluator ognlEval = new ParsedValueEvaluator() {
/*     */         public Object evaluate(String parsedValue) {
/* 204 */           return stack.findValue(parsedValue);
/*     */         }
/*     */       };
/*     */     
/* 208 */     Map<String, Object> context = stack.getContext();
/* 209 */     TextParser parser = (TextParser)((Container)context.get("com.opensymphony.xwork2.ActionContext.container")).getInstance(TextParser.class);
/*     */     
/* 211 */     Object result = parser.evaluate(openChars, expression, ognlEval, maxLoopCount);
/*     */ 
/*     */     
/* 214 */     if (result instanceof Collection) {
/*     */       
/* 216 */       Collection<Object> casted = (Collection<Object>)result;
/* 217 */       resultCol = new ArrayList<>();
/*     */       
/* 219 */       XWorkConverter conv = (XWorkConverter)((Container)context.get("com.opensymphony.xwork2.ActionContext.container")).getInstance(XWorkConverter.class);
/*     */       
/* 221 */       for (Object element : casted) {
/* 222 */         String stringElement = (String)conv.convertValue(context, element, String.class);
/* 223 */         if (shallBeIncluded(stringElement, excludeEmptyElements)) {
/* 224 */           if (evaluator != null) {
/* 225 */             stringElement = evaluator.evaluate(stringElement).toString();
/*     */           }
/* 227 */           resultCol.add(stringElement);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 231 */       resultCol = new ArrayList<>();
/* 232 */       String resultStr = translateVariables(expression, stack, evaluator);
/* 233 */       if (shallBeIncluded(resultStr, excludeEmptyElements)) {
/* 234 */         resultCol.add(resultStr);
/*     */       }
/*     */     } 
/*     */     
/* 238 */     return resultCol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean shallBeIncluded(String str, boolean excludeEmptyElements) {
/* 250 */     return (!excludeEmptyElements || (str != null && str.length() > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> commaDelimitedStringToSet(String s) {
/* 259 */     Set<String> set = new HashSet<>();
/* 260 */     String[] split = s.split(",");
/* 261 */     for (String aSplit : split) {
/* 262 */       String trimmed = aSplit.trim();
/* 263 */       if (trimmed.length() > 0)
/* 264 */         set.add(trimmed); 
/*     */     } 
/* 266 */     return set;
/*     */   }
/*     */   
/*     */   public static interface ParsedValueEvaluator {
/*     */     Object evaluate(String param1String);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\TextParseUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */