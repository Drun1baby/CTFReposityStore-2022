package com.opensymphony.xwork2;

import com.opensymphony.xwork2.util.ValueStack;
import java.io.Serializable;
import java.util.Locale;
import java.util.ResourceBundle;

public interface LocalizedTextProvider extends Serializable {
  String findDefaultText(String paramString, Locale paramLocale);
  
  String findDefaultText(String paramString, Locale paramLocale, Object[] paramArrayOfObject);
  
  ResourceBundle findResourceBundle(String paramString, Locale paramLocale);
  
  String findText(Class paramClass, String paramString, Locale paramLocale);
  
  String findText(Class paramClass, String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject);
  
  String findText(Class paramClass, String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject, ValueStack paramValueStack);
  
  String findText(ResourceBundle paramResourceBundle, String paramString, Locale paramLocale);
  
  String findText(ResourceBundle paramResourceBundle, String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject);
  
  String findText(ResourceBundle paramResourceBundle, String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject, ValueStack paramValueStack);
  
  void addDefaultResourceBundle(String paramString);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\LocalizedTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */