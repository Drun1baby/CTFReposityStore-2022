/*     */ package com.opensymphony.xwork2.util.profiling;
/*     */ 
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class UtilTimerStack
/*     */ {
/* 295 */   protected static ThreadLocal<ProfilingTimerBean> current = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ACTIVATE_PROPERTY = "xwork.profile.activate";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MIN_TIME = "xwork.profile.mintime";
/*     */ 
/*     */ 
/*     */   
/* 309 */   private static final Logger LOG = LogManager.getLogger(UtilTimerStack.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   private static boolean active = "true".equalsIgnoreCase(System.getProperty("xwork.profile.activate"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(String name) {
/* 327 */     if (!isActive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 332 */     ProfilingTimerBean newTimer = new ProfilingTimerBean(name);
/* 333 */     newTimer.setStartTime();
/*     */ 
/*     */     
/* 336 */     ProfilingTimerBean currentTimer = current.get();
/* 337 */     if (currentTimer != null) {
/* 338 */       currentTimer.addChild(newTimer);
/*     */     }
/*     */ 
/*     */     
/* 342 */     current.set(newTimer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void pop(String name) {
/* 352 */     if (!isActive()) {
/*     */       return;
/*     */     }
/*     */     
/* 356 */     ProfilingTimerBean currentTimer = current.get();
/*     */ 
/*     */     
/* 359 */     if (currentTimer != null && name != null && name.equals(currentTimer.getResource())) {
/* 360 */       currentTimer.setEndTime();
/* 361 */       ProfilingTimerBean parent = currentTimer.getParent();
/*     */       
/* 363 */       if (parent == null) {
/* 364 */         printTimes(currentTimer);
/* 365 */         current.set(null);
/*     */       } else {
/* 367 */         current.set(parent);
/*     */       }
/*     */     
/*     */     }
/* 371 */     else if (currentTimer != null) {
/* 372 */       printTimes(currentTimer);
/* 373 */       current.set(null);
/* 374 */       LOG.warn("Unmatched Timer. Was expecting {}, instead got {}", currentTimer.getResource(), name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void printTimes(ProfilingTimerBean currentTimer) {
/* 385 */     LOG.info(currentTimer.getPrintable(getMinTime()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long getMinTime() {
/*     */     try {
/* 396 */       return Long.parseLong(System.getProperty("xwork.profile.mintime", "0"));
/* 397 */     } catch (NumberFormatException e) {
/* 398 */       return -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isActive() {
/* 409 */     return active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setActive(boolean active) {
/* 416 */     if (active) {
/* 417 */       System.setProperty("xwork.profile.activate", "true");
/*     */     } else {
/* 419 */       System.clearProperty("xwork.profile.activate");
/*     */     } 
/* 421 */     UtilTimerStack.active = active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T profile(String name, ProfilingBlock<T> block) throws Exception {
/* 467 */     push(name);
/*     */     try {
/* 469 */       return block.doProfiling();
/*     */     } finally {
/* 471 */       pop(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface ProfilingBlock<T> {
/*     */     T doProfiling() throws Exception;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\profiling\UtilTimerStack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */