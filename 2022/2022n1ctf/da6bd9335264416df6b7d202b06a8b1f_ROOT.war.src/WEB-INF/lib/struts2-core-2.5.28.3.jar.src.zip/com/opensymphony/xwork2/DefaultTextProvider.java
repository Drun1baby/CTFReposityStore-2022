/*     */ package com.opensymphony.xwork2;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Serializable;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTextProvider
/*     */   implements TextProvider, Serializable, Unchainable
/*     */ {
/*  36 */   private static final Object[] EMPTY_ARGS = new Object[0];
/*     */ 
/*     */   
/*     */   protected LocalizedTextProvider localizedTextProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   @Inject
/*     */   public void setLocalizedTextProvider(LocalizedTextProvider localizedTextProvider) {
/*  45 */     this.localizedTextProvider = localizedTextProvider;
/*     */   }
/*     */   
/*     */   public boolean hasKey(String key) {
/*  49 */     return (getText(key) != null);
/*     */   }
/*     */   
/*     */   public String getText(String key) {
/*  53 */     return this.localizedTextProvider.findDefaultText(key, ActionContext.getContext().getLocale());
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue) {
/*  57 */     String text = getText(key);
/*  58 */     if (text == null) {
/*  59 */       return defaultValue;
/*     */     }
/*  61 */     return text;
/*     */   }
/*     */   
/*     */   public String getText(String key, List<?> args) {
/*     */     Object[] params;
/*  66 */     if (args != null) {
/*  67 */       params = args.toArray();
/*     */     } else {
/*  69 */       params = EMPTY_ARGS;
/*     */     } 
/*     */     
/*  72 */     return this.localizedTextProvider.findDefaultText(key, ActionContext.getContext().getLocale(), params);
/*     */   }
/*     */   
/*     */   public String getText(String key, String[] args) {
/*     */     Object[] params;
/*  77 */     if (args != null) {
/*  78 */       String[] arrayOfString = args;
/*     */     } else {
/*  80 */       params = EMPTY_ARGS;
/*     */     } 
/*     */     
/*  83 */     return this.localizedTextProvider.findDefaultText(key, ActionContext.getContext().getLocale(), params);
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args) {
/*  87 */     String text = getText(key, args);
/*  88 */     if (text == null && defaultValue == null) {
/*  89 */       defaultValue = key;
/*     */     }
/*  91 */     if (text == null && defaultValue != null) {
/*     */       Object[] params;
/*  93 */       MessageFormat format = new MessageFormat(defaultValue);
/*  94 */       format.setLocale(ActionContext.getContext().getLocale());
/*  95 */       format.applyPattern(defaultValue);
/*     */ 
/*     */       
/*  98 */       if (args != null) {
/*  99 */         params = args.toArray();
/*     */       } else {
/* 101 */         params = EMPTY_ARGS;
/*     */       } 
/*     */       
/* 104 */       return format.format(params);
/*     */     } 
/* 106 */     return text;
/*     */   }
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args) {
/* 110 */     String text = getText(key, args);
/* 111 */     if (text == null) {
/* 112 */       MessageFormat format = new MessageFormat(defaultValue);
/* 113 */       format.setLocale(ActionContext.getContext().getLocale());
/* 114 */       format.applyPattern(defaultValue);
/*     */       
/* 116 */       if (args == null) {
/* 117 */         return format.format(EMPTY_ARGS);
/*     */       }
/*     */       
/* 120 */       return format.format(args);
/*     */     } 
/* 122 */     return text;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String obj) {
/* 127 */     List<Object> args = new ArrayList(1);
/* 128 */     args.add(obj);
/* 129 */     return getText(key, defaultValue, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, List<?> args, ValueStack stack) {
/* 134 */     return getText(key, defaultValue, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(String key, String defaultValue, String[] args, ValueStack stack) {
/* 139 */     List<Object> values = new ArrayList(Arrays.asList((Object[])args));
/* 140 */     return getText(key, defaultValue, values);
/*     */   }
/*     */   
/*     */   public ResourceBundle getTexts(String bundleName) {
/* 144 */     return this.localizedTextProvider.findResourceBundle(bundleName, ActionContext.getContext().getLocale());
/*     */   }
/*     */   
/*     */   public ResourceBundle getTexts() {
/* 148 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\DefaultTextProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */