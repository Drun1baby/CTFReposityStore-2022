/*     */ package com.opensymphony.xwork2.mock;
/*     */ 
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import java.util.Map;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MockObjectTypeDeterminer
/*     */   implements ObjectTypeDeterminer
/*     */ {
/*     */   private Class keyClass;
/*     */   private Class elementClass;
/*     */   private String keyProperty;
/*     */   private boolean shouldCreateIfNew;
/*     */   
/*     */   public MockObjectTypeDeterminer() {}
/*     */   
/*     */   public MockObjectTypeDeterminer(Class keyClass, Class elementClass, String keyProperty, boolean shouldCreateIfNew) {
/*  51 */     this.keyClass = keyClass;
/*  52 */     this.elementClass = elementClass;
/*  53 */     this.keyProperty = keyProperty;
/*  54 */     this.shouldCreateIfNew = shouldCreateIfNew;
/*     */   }
/*     */   
/*     */   public Class getKeyClass(Class parentClass, String property) {
/*  58 */     return getKeyClass();
/*     */   }
/*     */   
/*     */   public Class getElementClass(Class parentClass, String property, Object key) {
/*  62 */     return getElementClass();
/*     */   }
/*     */   
/*     */   public String getKeyProperty(Class parentClass, String property) {
/*  66 */     return getKeyProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldCreateIfNew(Class parentClass, String property, Object target, String keyProperty, boolean isIndexAccessed) {
/*     */     try {
/*  72 */       System.out.println("ognl:" + OgnlRuntime.getPropertyAccessor(Map.class) + " this:" + this);
/*  73 */     } catch (OgnlException e) {
/*     */       
/*  75 */       e.printStackTrace();
/*     */     } 
/*  77 */     return isShouldCreateIfNew();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getElementClass() {
/*  84 */     return this.elementClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElementClass(Class elementClass) {
/*  90 */     this.elementClass = elementClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getKeyClass() {
/*  96 */     return this.keyClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyClass(Class keyClass) {
/* 102 */     this.keyClass = keyClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyProperty() {
/* 108 */     return this.keyProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyProperty(String keyProperty) {
/* 114 */     this.keyProperty = keyProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShouldCreateIfNew() {
/* 120 */     return this.shouldCreateIfNew;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShouldCreateIfNew(boolean shouldCreateIfNew) {
/* 126 */     this.shouldCreateIfNew = shouldCreateIfNew;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\mock\MockObjectTypeDeterminer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */