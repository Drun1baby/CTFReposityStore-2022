/*     */ package com.opensymphony.xwork2.spring.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.spring.SpringObjectFactory;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionAutowiringInterceptor
/*     */   extends AbstractInterceptor
/*     */   implements ApplicationContextAware
/*     */ {
/*  67 */   private static final Logger LOG = LogManager.getLogger(ActionAutowiringInterceptor.class);
/*     */   
/*     */   public static final String APPLICATION_CONTEXT = "com.opensymphony.xwork2.spring.interceptor.ActionAutowiringInterceptor.applicationContext";
/*     */   
/*     */   private boolean initialized = false;
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   private SpringObjectFactory factory;
/*     */   
/*     */   private Integer autowireStrategy;
/*     */   
/*     */   public void setAutowireStrategy(Integer autowireStrategy) {
/*  80 */     this.autowireStrategy = autowireStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 103 */     if (!this.initialized) {
/* 104 */       ApplicationContext applicationContext = (ApplicationContext)ActionContext.getContext().getApplication().get(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */ 
/*     */       
/* 107 */       if (applicationContext == null) {
/* 108 */         LOG.warn("ApplicationContext could not be found.  Action classes will not be autowired.");
/*     */       } else {
/* 110 */         setApplicationContext(applicationContext);
/* 111 */         this.factory = new SpringObjectFactory();
/* 112 */         this.factory.setContainer(ActionContext.getContext().getContainer());
/* 113 */         this.factory.setApplicationContext(getApplicationContext());
/* 114 */         if (this.autowireStrategy != null) {
/* 115 */           this.factory.setAutowireStrategy(this.autowireStrategy.intValue());
/*     */         }
/*     */       } 
/* 118 */       this.initialized = true;
/*     */     } 
/*     */     
/* 121 */     if (this.factory != null) {
/* 122 */       Object bean = invocation.getAction();
/* 123 */       this.factory.autoWireBean(bean);
/*     */       
/* 125 */       ActionContext.getContext().put("com.opensymphony.xwork2.spring.interceptor.ActionAutowiringInterceptor.applicationContext", this.context);
/*     */     } 
/* 127 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 135 */     this.context = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ApplicationContext getApplicationContext() {
/* 142 */     return this.context;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\spring\interceptor\ActionAutowiringInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */