/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   protected Map<String, String> params;
/*     */   protected String className;
/*     */   protected String name;
/*     */   
/*     */   protected ResultConfig(String name, String className) {
/*  46 */     this.name = name;
/*  47 */     this.className = className;
/*  48 */     this.params = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   protected ResultConfig(ResultConfig orig) {
/*  52 */     this.params = orig.params;
/*  53 */     this.name = orig.name;
/*  54 */     this.className = orig.className;
/*  55 */     this.location = orig.location;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  59 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  63 */     return this.name;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParams() {
/*  67 */     return this.params;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  72 */     if (this == o) {
/*  73 */       return true;
/*     */     }
/*     */     
/*  76 */     if (!(o instanceof ResultConfig)) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     ResultConfig resultConfig = (ResultConfig)o;
/*     */     
/*  82 */     if ((this.className != null) ? !this.className.equals(resultConfig.className) : (resultConfig.className != null)) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     if ((this.name != null) ? !this.name.equals(resultConfig.name) : (resultConfig.name != null)) {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     if ((this.params != null) ? !this.params.equals(resultConfig.params) : (resultConfig.params != null)) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 100 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 101 */     result = 29 * result + ((this.className != null) ? this.className.hashCode() : 0);
/* 102 */     result = 29 * result + ((this.params != null) ? this.params.hashCode() : 0);
/*     */     
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     return "ResultConfig: [" + this.name + "] => [" + this.className + "] with params " + this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     protected ResultConfig target;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(String name, String className) {
/* 121 */       this.target = new ResultConfig(name, className);
/*     */     }
/*     */     
/*     */     public Builder(ResultConfig orig) {
/* 125 */       this.target = new ResultConfig(orig);
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 129 */       this.target.name = name;
/* 130 */       return this;
/*     */     }
/*     */     
/*     */     public Builder className(String name) {
/* 134 */       this.target.className = name;
/* 135 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, String value) {
/* 139 */       this.target.params.put(name, value);
/* 140 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, String> params) {
/* 144 */       this.target.params.putAll(params);
/* 145 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 149 */       this.target.location = loc;
/* 150 */       return this;
/*     */     }
/*     */     
/*     */     public ResultConfig build() {
/* 154 */       embalmTarget();
/* 155 */       ResultConfig result = this.target;
/* 156 */       this.target = new ResultConfig(this.target);
/* 157 */       return result;
/*     */     }
/*     */     
/*     */     protected void embalmTarget() {
/* 161 */       this.target.params = Collections.unmodifiableMap(this.target.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\ResultConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */