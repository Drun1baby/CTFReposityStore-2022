package com.opensymphony.xwork2.util;

import java.util.Map;

public interface ValueStack {
  public static final String VALUE_STACK = "com.opensymphony.xwork2.util.ValueStack.ValueStack";
  
  public static final String REPORT_ERRORS_ON_NO_PROP = "com.opensymphony.xwork2.util.ValueStack.ReportErrorsOnNoProp";
  
  Map<String, Object> getContext();
  
  void setDefaultType(Class paramClass);
  
  void setExprOverrides(Map<Object, Object> paramMap);
  
  Map<Object, Object> getExprOverrides();
  
  CompoundRoot getRoot();
  
  void setValue(String paramString, Object paramObject);
  
  void setParameter(String paramString, Object paramObject);
  
  void setValue(String paramString, Object paramObject, boolean paramBoolean);
  
  String findString(String paramString);
  
  String findString(String paramString, boolean paramBoolean);
  
  Object findValue(String paramString);
  
  Object findValue(String paramString, boolean paramBoolean);
  
  Object findValue(String paramString, Class paramClass);
  
  Object findValue(String paramString, Class paramClass, boolean paramBoolean);
  
  Object peek();
  
  Object pop();
  
  void push(Object paramObject);
  
  void set(String paramString, Object paramObject);
  
  int size();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\ValueStack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */