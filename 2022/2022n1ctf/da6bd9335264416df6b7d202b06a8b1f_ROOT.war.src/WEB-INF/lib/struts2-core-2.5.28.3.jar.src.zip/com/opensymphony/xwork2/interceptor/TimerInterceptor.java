/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class TimerInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/* 103 */   private static final Logger LOG = LogManager.getLogger(TimerInterceptor.class);
/*     */   
/*     */   protected Logger categoryLogger;
/*     */   protected String logCategory;
/*     */   protected String logLevel;
/*     */   
/*     */   public String getLogCategory() {
/* 110 */     return this.logCategory;
/*     */   }
/*     */   
/*     */   public void setLogCategory(String logCatgory) {
/* 114 */     this.logCategory = logCatgory;
/*     */   }
/*     */   
/*     */   public String getLogLevel() {
/* 118 */     return this.logLevel;
/*     */   }
/*     */   
/*     */   public void setLogLevel(String logLevel) {
/* 122 */     this.logLevel = logLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 127 */     if (!shouldLog()) {
/* 128 */       return invocation.invoke();
/*     */     }
/* 130 */     return invokeUnderTiming(invocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String invokeUnderTiming(ActionInvocation invocation) throws Exception {
/* 142 */     long startTime = System.currentTimeMillis();
/* 143 */     String result = invocation.invoke();
/* 144 */     long executionTime = System.currentTimeMillis() - startTime;
/*     */     
/* 146 */     StringBuilder message = new StringBuilder(100);
/* 147 */     message.append("Executed action [");
/* 148 */     String namespace = invocation.getProxy().getNamespace();
/* 149 */     if (StringUtils.isNotBlank(namespace)) {
/* 150 */       message.append(namespace).append("/");
/*     */     }
/* 152 */     message.append(invocation.getProxy().getActionName());
/* 153 */     message.append("!");
/* 154 */     message.append(invocation.getProxy().getMethod());
/* 155 */     message.append("] took ").append(executionTime).append(" ms.");
/*     */     
/* 157 */     doLog(getLoggerToUse(), message.toString());
/*     */     
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldLog() {
/* 169 */     if (this.logLevel == null && this.logCategory == null) {
/* 170 */       return LOG.isInfoEnabled();
/*     */     }
/*     */ 
/*     */     
/* 174 */     return isLoggerEnabled(getLoggerToUse(), this.logLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Logger getLoggerToUse() {
/* 183 */     if (this.logCategory != null) {
/* 184 */       if (this.categoryLogger == null) {
/*     */         
/* 186 */         this.categoryLogger = LogManager.getLogger(this.logCategory);
/* 187 */         if (this.logLevel == null) {
/* 188 */           this.logLevel = "info";
/*     */         }
/*     */       } 
/* 191 */       return this.categoryLogger;
/*     */     } 
/*     */     
/* 194 */     return LOG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doLog(Logger logger, String message) {
/* 204 */     if (this.logLevel == null) {
/* 205 */       logger.info(message);
/*     */       
/*     */       return;
/*     */     } 
/* 209 */     if ("debug".equalsIgnoreCase(this.logLevel)) {
/* 210 */       logger.debug(message);
/* 211 */     } else if ("info".equalsIgnoreCase(this.logLevel)) {
/* 212 */       logger.info(message);
/* 213 */     } else if ("warn".equalsIgnoreCase(this.logLevel)) {
/* 214 */       logger.warn(message);
/* 215 */     } else if ("error".equalsIgnoreCase(this.logLevel)) {
/* 216 */       logger.error(message);
/* 217 */     } else if ("fatal".equalsIgnoreCase(this.logLevel)) {
/* 218 */       logger.fatal(message);
/* 219 */     } else if ("trace".equalsIgnoreCase(this.logLevel)) {
/* 220 */       logger.trace(message);
/*     */     } else {
/* 222 */       throw new IllegalArgumentException("LogLevel [" + this.logLevel + "] is not supported");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLoggerEnabled(Logger logger, String level) {
/* 234 */     if ("debug".equalsIgnoreCase(level))
/* 235 */       return logger.isDebugEnabled(); 
/* 236 */     if ("info".equalsIgnoreCase(level))
/* 237 */       return logger.isInfoEnabled(); 
/* 238 */     if ("warn".equalsIgnoreCase(level))
/* 239 */       return logger.isWarnEnabled(); 
/* 240 */     if ("error".equalsIgnoreCase(level))
/* 241 */       return logger.isErrorEnabled(); 
/* 242 */     if ("fatal".equalsIgnoreCase(level))
/* 243 */       return logger.isFatalEnabled(); 
/* 244 */     if ("trace".equalsIgnoreCase(level)) {
/* 245 */       return logger.isTraceEnabled();
/*     */     }
/* 247 */     throw new IllegalArgumentException("LogLevel [" + level + "] is not supported");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\TimerInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */