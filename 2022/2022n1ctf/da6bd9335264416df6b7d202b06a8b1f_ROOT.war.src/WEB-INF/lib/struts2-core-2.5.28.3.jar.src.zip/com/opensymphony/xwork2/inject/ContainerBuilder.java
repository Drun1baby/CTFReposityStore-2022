/*     */ package com.opensymphony.xwork2.inject;
/*     */ 
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContainerBuilder
/*     */ {
/*  48 */   final Map<Key<?>, InternalFactory<?>> factories = new HashMap<>();
/*  49 */   final List<InternalFactory<?>> singletonFactories = new ArrayList<>();
/*  50 */   final List<InternalFactory<?>> earlyInitializableFactories = new ArrayList<>();
/*  51 */   final List<Class<?>> staticInjections = new ArrayList<>();
/*     */   boolean created;
/*     */   boolean allowDuplicates = false;
/*     */   
/*  55 */   private static final InternalFactory<Container> CONTAINER_FACTORY = new InternalFactory<Container>()
/*     */     {
/*     */       public Container create(InternalContext context) {
/*  58 */         return context.getContainer();
/*     */       }
/*     */ 
/*     */       
/*     */       public Class<? extends Container> type() {
/*  63 */         return Container.class;
/*     */       }
/*     */     };
/*     */   
/*  67 */   private static final InternalFactory<Logger> LOGGER_FACTORY = new InternalFactory<Logger>()
/*     */     {
/*     */       public Logger create(InternalContext context) {
/*  70 */         Member member = context.getExternalContext().getMember();
/*  71 */         return (member == null) ? Logger.getAnonymousLogger() : Logger.getLogger(member.getDeclaringClass().getName());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public Class<? extends Logger> type() {
/*  77 */         return Logger.class;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder() {
/*  86 */     this.factories.put(Key.newInstance(Container.class, "default"), CONTAINER_FACTORY);
/*     */ 
/*     */     
/*  89 */     this.factories.put(Key.newInstance(Logger.class, "default"), LOGGER_FACTORY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> ContainerBuilder factory(Key<T> key, InternalFactory<? extends T> factory, Scope scope) {
/*  98 */     ensureNotCreated();
/*  99 */     checkKey(key);
/* 100 */     InternalFactory<? extends T> scopedFactory = scope.scopeFactory(key.getType(), key.getName(), factory);
/* 101 */     this.factories.put(key, scopedFactory);
/*     */     
/* 103 */     InternalFactory<T> callableFactory = createCallableFactory(key, scopedFactory);
/* 104 */     if (EarlyInitializable.class.isAssignableFrom(factory.type())) {
/* 105 */       this.earlyInitializableFactories.add(callableFactory);
/* 106 */     } else if (scope == Scope.SINGLETON) {
/* 107 */       this.singletonFactories.add(callableFactory);
/*     */     } 
/*     */     
/* 110 */     return this;
/*     */   }
/*     */   
/*     */   private <T> InternalFactory<T> createCallableFactory(final Key<T> key, final InternalFactory<? extends T> scopedFactory) {
/* 114 */     return new InternalFactory<T>() {
/*     */         public T create(InternalContext context) {
/*     */           try {
/* 117 */             context.setExternalContext(ExternalContext.newInstance(null, key, context.getContainerImpl()));
/* 118 */             return (T)scopedFactory.create(context);
/*     */           } finally {
/* 120 */             context.setExternalContext(null);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends T> type() {
/* 126 */           return scopedFactory.type();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkKey(Key<?> key) {
/* 137 */     if (this.factories.containsKey(key) && !this.allowDuplicates) {
/* 138 */       throw new DependencyException("Dependency mapping for " + key + " already exists.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(final Class<T> type, final String name, final Factory<? extends T> factory, Scope scope) {
/* 154 */     InternalFactory<T> internalFactory = new InternalFactory<T>()
/*     */       {
/*     */         public T create(InternalContext context) {
/*     */           try {
/* 158 */             Context<?> externalContext = context.getExternalContext();
/* 159 */             return factory.create(externalContext);
/* 160 */           } catch (Exception e) {
/* 161 */             throw new RuntimeException(e);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends T> type() {
/* 167 */           return factory.type();
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 172 */           return (new LinkedHashMap<String, Object>() {  }).toString();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     return factory(Key.newInstance(type, name), internalFactory, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, Factory<? extends T> factory, Scope scope) {
/* 195 */     return factory(type, "default", factory, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, String name, Factory<? extends T> factory) {
/* 210 */     return factory(type, name, factory, Scope.PROTOTYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, Factory<? extends T> factory) {
/* 224 */     return factory(type, "default", factory, Scope.PROTOTYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(final Class<T> type, final String name, final Class<? extends T> implementation, final Scope scope) {
/* 243 */     InternalFactory<? extends T> factory = new InternalFactory<T>()
/*     */       {
/*     */         volatile ContainerImpl.ConstructorInjector<? extends T> constructor;
/*     */ 
/*     */         
/*     */         public T create(InternalContext context) {
/* 249 */           if (this.constructor == null) {
/* 250 */             this.constructor = context.getContainerImpl().getConstructor(implementation);
/*     */           }
/*     */           
/* 253 */           return (T)this.constructor.construct(context, type);
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends T> type() {
/* 258 */           return implementation;
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 263 */           return (new LinkedHashMap<String, Object>() {  }).toString();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     return factory(Key.newInstance(type, name), factory, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, String name, Class<? extends T> implementation) {
/* 294 */     Scoped scoped = implementation.<Scoped>getAnnotation(Scoped.class);
/* 295 */     Scope scope = (scoped == null) ? Scope.PROTOTYPE : scoped.value();
/* 296 */     return factory(type, name, implementation, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, Class<? extends T> implementation) {
/* 310 */     return factory(type, "default", implementation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type) {
/* 323 */     return factory(type, "default", type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, String name) {
/* 336 */     return factory(type, name, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, Class<? extends T> implementation, Scope scope) {
/* 351 */     return factory(type, "default", implementation, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, Scope scope) {
/* 365 */     return factory(type, "default", type, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder factory(Class<T> type, String name, Scope scope) {
/* 380 */     return factory(type, name, type, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder alias(Class<T> type, String alias) {
/* 394 */     return alias(type, "default", alias);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ContainerBuilder alias(Class<T> type, String name, String alias) {
/* 407 */     return alias(Key.newInstance(type, name), Key.newInstance(type, alias));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> ContainerBuilder alias(Key<T> key, Key<T> aliasKey) {
/* 420 */     ensureNotCreated();
/* 421 */     checkKey(aliasKey);
/*     */     
/* 423 */     InternalFactory<? extends T> scopedFactory = (InternalFactory<? extends T>)this.factories.get(key);
/* 424 */     if (scopedFactory == null) {
/* 425 */       throw new DependencyException("Dependency mapping for " + key + " doesn't exists.");
/*     */     }
/* 427 */     this.factories.put(aliasKey, scopedFactory);
/* 428 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, String value) {
/* 438 */     return constant(String.class, name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, int value) {
/* 448 */     return constant(int.class, name, Integer.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, long value) {
/* 458 */     return constant(long.class, name, Long.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, boolean value) {
/* 468 */     return constant(boolean.class, name, Boolean.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, double value) {
/* 478 */     return constant(double.class, name, Double.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, float value) {
/* 488 */     return constant(float.class, name, Float.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, short value) {
/* 498 */     return constant(short.class, name, Short.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, char value) {
/* 508 */     return constant(char.class, name, Character.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder constant(String name, Class<?> value) {
/* 518 */     return constant(Class.class, name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Enum<E>> ContainerBuilder constant(String name, E value) {
/* 529 */     return constant(value.getDeclaringClass(), name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> ContainerBuilder constant(final Class<T> type, final String name, final T value) {
/* 540 */     InternalFactory<T> factory = new InternalFactory<T>() {
/*     */         public T create(InternalContext ignored) {
/* 542 */           return (T)value;
/*     */         }
/*     */ 
/*     */         
/*     */         public Class<? extends T> type() {
/* 547 */           return (Class)value.getClass();
/*     */         }
/*     */ 
/*     */         
/*     */         public String toString() {
/* 552 */           return (new LinkedHashMap<String, Object>() {  }).toString();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 562 */     return factory(Key.newInstance(type, name), factory, Scope.PROTOTYPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerBuilder injectStatics(Class<?>... types) {
/* 573 */     this.staticInjections.addAll(Arrays.asList(types));
/* 574 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Class<?> type, String name) {
/* 584 */     return this.factories.containsKey(Key.newInstance(type, name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Class<?> type) {
/* 594 */     return contains(type, "default");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Container create(boolean loadSingletons) {
/* 609 */     ensureNotCreated();
/* 610 */     this.created = true;
/* 611 */     ContainerImpl container = new ContainerImpl(new HashMap<>(this.factories));
/* 612 */     if (loadSingletons) {
/* 613 */       container.callInContext(new ContainerImpl.ContextualCallable<Void>() {
/*     */             public Void call(InternalContext context) {
/* 615 */               for (InternalFactory<?> factory : ContainerBuilder.this.singletonFactories) {
/* 616 */                 factory.create(context);
/*     */               }
/* 618 */               return null;
/*     */             }
/*     */           });
/*     */     }
/*     */     
/* 623 */     container.callInContext(new ContainerImpl.ContextualCallable<Void>() {
/*     */           public Void call(InternalContext context) {
/* 625 */             for (InternalFactory<?> factory : ContainerBuilder.this.earlyInitializableFactories) {
/* 626 */               factory.create(context);
/*     */             }
/* 628 */             return null;
/*     */           }
/*     */         });
/*     */     
/* 632 */     container.injectStatics(this.staticInjections);
/* 633 */     return container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureNotCreated() {
/* 645 */     if (this.created) {
/* 646 */       throw new IllegalStateException("Container already created.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAllowDuplicates(boolean val) {
/* 651 */     this.allowDuplicates = val;
/*     */   }
/*     */   
/*     */   public static interface Command {
/*     */     void build(ContainerBuilder param1ContainerBuilder);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\ContainerBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */