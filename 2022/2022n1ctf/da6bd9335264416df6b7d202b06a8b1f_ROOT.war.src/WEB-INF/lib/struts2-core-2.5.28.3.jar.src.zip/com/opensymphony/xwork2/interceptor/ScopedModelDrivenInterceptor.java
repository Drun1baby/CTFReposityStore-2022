/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScopedModelDrivenInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*  85 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*     */   
/*     */   private static final String GET_MODEL = "getModel";
/*     */   private String scope;
/*     */   private String name;
/*     */   private String className;
/*     */   private ObjectFactory objectFactory;
/*     */   
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory factory) {
/*  95 */     this.objectFactory = factory;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object resolveModel(ObjectFactory factory, ActionContext actionContext, String modelClassName, String modelScope, String modelName) throws Exception {
/* 100 */     Map<String, Object> scopeMap = actionContext.getContextMap();
/* 101 */     if ("session".equals(modelScope)) {
/* 102 */       scopeMap = actionContext.getSession();
/*     */     }
/*     */     
/* 105 */     Object model = scopeMap.get(modelName);
/* 106 */     if (model == null) {
/* 107 */       model = factory.buildBean(modelClassName, null);
/* 108 */       scopeMap.put(modelName, model);
/*     */     } 
/* 110 */     return model;
/*     */   }
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 115 */     Object action = invocation.getAction();
/*     */     
/* 117 */     if (action instanceof ScopedModelDriven) {
/* 118 */       ScopedModelDriven<Object> modelDriven = (ScopedModelDriven)action;
/* 119 */       if (modelDriven.getModel() == null) {
/* 120 */         ActionContext ctx = ActionContext.getContext();
/* 121 */         ActionConfig config = invocation.getProxy().getConfig();
/*     */         
/* 123 */         String cName = this.className;
/* 124 */         if (cName == null) {
/*     */           try {
/* 126 */             Method method = action.getClass().getMethod("getModel", EMPTY_CLASS_ARRAY);
/* 127 */             Class<?> cls = method.getReturnType();
/* 128 */             cName = cls.getName();
/* 129 */           } catch (NoSuchMethodException e) {
/* 130 */             throw new XWorkException("The getModel() is not defined in action " + action.getClass() + "", config);
/*     */           } 
/*     */         }
/* 133 */         String modelName = this.name;
/* 134 */         if (modelName == null) {
/* 135 */           modelName = cName;
/*     */         }
/* 137 */         Object model = resolveModel(this.objectFactory, ctx, cName, this.scope, modelName);
/* 138 */         modelDriven.setModel(model);
/* 139 */         modelDriven.setScopeKey(modelName);
/*     */       } 
/*     */     } 
/* 142 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassName(String className) {
/* 149 */     this.className = className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 156 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 163 */     this.scope = scope;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ScopedModelDrivenInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */