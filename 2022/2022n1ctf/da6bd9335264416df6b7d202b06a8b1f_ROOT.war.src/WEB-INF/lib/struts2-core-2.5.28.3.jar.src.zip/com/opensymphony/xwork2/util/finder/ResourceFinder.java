/*      */ package com.opensymphony.xwork2.util.finder;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.JarURLConnection;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.net.URLDecoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import org.apache.commons.lang3.StringUtils;
/*      */ import org.apache.logging.log4j.LogManager;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResourceFinder
/*      */ {
/*   38 */   private static final Logger LOG = LogManager.getLogger(ResourceFinder.class);
/*      */   
/*      */   private final URL[] urls;
/*      */   private final String path;
/*      */   private final ClassLoaderInterface classLoaderInterface;
/*   43 */   private final List<String> resourcesNotLoaded = new ArrayList<>();
/*      */   
/*      */   public ResourceFinder(URL... urls) {
/*   46 */     this(null, new ClassLoaderInterfaceDelegate(Thread.currentThread().getContextClassLoader()), urls);
/*      */   }
/*      */   
/*      */   public ResourceFinder(String path) {
/*   50 */     this(path, new ClassLoaderInterfaceDelegate(Thread.currentThread().getContextClassLoader()), null);
/*      */   }
/*      */   
/*      */   public ResourceFinder(String path, URL... urls) {
/*   54 */     this(path, new ClassLoaderInterfaceDelegate(Thread.currentThread().getContextClassLoader()), urls);
/*      */   }
/*      */   
/*      */   public ResourceFinder(String path, ClassLoaderInterface classLoaderInterface) {
/*   58 */     this(path, classLoaderInterface, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceFinder(String path, ClassLoaderInterface classLoaderInterface, URL... urls) {
/*   77 */     path = StringUtils.trimToEmpty(path);
/*   78 */     if (!path.isEmpty() && !StringUtils.endsWith(path, "/")) {
/*   79 */       path = path + "/";
/*      */     }
/*   81 */     this.path = path;
/*      */     
/*   83 */     this.classLoaderInterface = (classLoaderInterface == null) ? new ClassLoaderInterfaceDelegate(Thread.currentThread().getContextClassLoader()) : classLoaderInterface;
/*      */     
/*   85 */     for (int i = 0; urls != null && i < urls.length; i++) {
/*   86 */       URL url = urls[i];
/*   87 */       if (url != null && !isDirectory(url) && !"jar".equals(url.getProtocol())) {
/*      */         
/*      */         try {
/*      */           
/*   91 */           urls[i] = new URL("jar", "", -1, url.toString() + "!/");
/*   92 */         } catch (MalformedURLException malformedURLException) {}
/*      */       }
/*      */     } 
/*   95 */     this.urls = (urls == null || urls.length == 0) ? null : urls;
/*      */   }
/*      */   
/*      */   private static boolean isDirectory(URL url) {
/*   99 */     String file = url.getFile();
/*  100 */     return (file.length() > 0 && file.charAt(file.length() - 1) == '/');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getResourcesNotLoaded() {
/*  125 */     return Collections.unmodifiableList(this.resourcesNotLoaded);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL find(String uri) throws IOException {
/*  135 */     String fullUri = this.path + uri;
/*      */     
/*  137 */     return getResource(fullUri);
/*      */   }
/*      */   
/*      */   public List<URL> findAll(String uri) throws IOException {
/*  141 */     String fullUri = this.path + uri;
/*      */     
/*  143 */     Enumeration<URL> resources = getResources(fullUri);
/*  144 */     List<URL> list = new ArrayList<>();
/*  145 */     while (resources.hasMoreElements()) {
/*  146 */       URL url = resources.nextElement();
/*  147 */       list.add(url);
/*      */     } 
/*  149 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findString(String uri) throws IOException {
/*  168 */     String fullUri = this.path + uri;
/*      */     
/*  170 */     URL resource = getResource(fullUri);
/*  171 */     if (resource == null) {
/*  172 */       throw new IOException("Could not find a resource in: " + fullUri);
/*      */     }
/*      */     
/*  175 */     return readContents(resource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findAllStrings(String uri) throws IOException {
/*  186 */     String fulluri = this.path + uri;
/*      */     
/*  188 */     List<String> strings = new ArrayList<>();
/*      */     
/*  190 */     Enumeration<URL> resources = getResources(fulluri);
/*  191 */     while (resources.hasMoreElements()) {
/*  192 */       URL url = resources.nextElement();
/*  193 */       String string = readContents(url);
/*  194 */       strings.add(string);
/*      */     } 
/*  196 */     return strings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findAvailableStrings(String uri) throws IOException {
/*  209 */     this.resourcesNotLoaded.clear();
/*  210 */     String fulluri = this.path + uri;
/*      */     
/*  212 */     List<String> strings = new ArrayList<>();
/*      */     
/*  214 */     Enumeration<URL> resources = getResources(fulluri);
/*  215 */     while (resources.hasMoreElements()) {
/*  216 */       URL url = resources.nextElement();
/*      */       try {
/*  218 */         String string = readContents(url);
/*  219 */         strings.add(string);
/*  220 */       } catch (IOException notAvailable) {
/*  221 */         this.resourcesNotLoaded.add(url.toExternalForm());
/*      */       } 
/*      */     } 
/*  224 */     return strings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> mapAllStrings(String uri) throws IOException {
/*  262 */     Map<String, String> strings = new HashMap<>();
/*  263 */     Map<String, URL> resourcesMap = getResourcesMap(uri);
/*  264 */     for (Map.Entry<String, URL> entry : resourcesMap.entrySet()) {
/*  265 */       String name = entry.getKey();
/*  266 */       URL url = entry.getValue();
/*  267 */       String value = readContents(url);
/*  268 */       strings.put(name, value);
/*      */     } 
/*  270 */     return strings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> mapAvailableStrings(String uri) throws IOException {
/*  309 */     this.resourcesNotLoaded.clear();
/*  310 */     Map<String, String> strings = new HashMap<>();
/*  311 */     Map<String, URL> resourcesMap = getResourcesMap(uri);
/*  312 */     for (Map.Entry<String, URL> entry : resourcesMap.entrySet()) {
/*  313 */       String name = entry.getKey();
/*  314 */       URL url = entry.getValue();
/*      */       try {
/*  316 */         String value = readContents(url);
/*  317 */         strings.put(name, value);
/*  318 */       } catch (IOException notAvailable) {
/*  319 */         this.resourcesNotLoaded.add(url.toExternalForm());
/*      */       } 
/*      */     } 
/*  322 */     return strings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class findClass(String uri) throws IOException, ClassNotFoundException {
/*  341 */     String className = findString(uri);
/*  342 */     return this.classLoaderInterface.loadClass(className);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Class> findAllClasses(String uri) throws IOException, ClassNotFoundException {
/*  361 */     List<Class<?>> classes = new ArrayList<>();
/*  362 */     List<String> strings = findAllStrings(uri);
/*  363 */     for (String className : strings) {
/*  364 */       Class<?> clazz = this.classLoaderInterface.loadClass(className);
/*  365 */       classes.add(clazz);
/*      */     } 
/*  367 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Class> findAvailableClasses(String uri) throws IOException {
/*  386 */     this.resourcesNotLoaded.clear();
/*  387 */     List<Class<?>> classes = new ArrayList<>();
/*  388 */     List<String> strings = findAvailableStrings(uri);
/*  389 */     for (String className : strings) {
/*      */       try {
/*  391 */         Class<?> clazz = this.classLoaderInterface.loadClass(className);
/*  392 */         classes.add(clazz);
/*  393 */       } catch (Exception notAvailable) {
/*  394 */         this.resourcesNotLoaded.add(className);
/*      */       } 
/*      */     } 
/*  397 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Class> mapAllClasses(String uri) throws IOException, ClassNotFoundException {
/*  432 */     Map<String, Class<?>> classes = new HashMap<>();
/*  433 */     Map<String, String> map = mapAllStrings(uri);
/*  434 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*  435 */       String string = entry.getKey();
/*  436 */       String className = entry.getValue();
/*  437 */       Class<?> clazz = this.classLoaderInterface.loadClass(className);
/*  438 */       classes.put(string, clazz);
/*      */     } 
/*  440 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Class> mapAvailableClasses(String uri) throws IOException {
/*  475 */     this.resourcesNotLoaded.clear();
/*  476 */     Map<String, Class<?>> classes = new HashMap<>();
/*  477 */     Map<String, String> map = mapAvailableStrings(uri);
/*  478 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*  479 */       String string = entry.getKey();
/*  480 */       String className = entry.getValue();
/*      */       try {
/*  482 */         Class<?> clazz = this.classLoaderInterface.loadClass(className);
/*  483 */         classes.put(string, clazz);
/*  484 */       } catch (Exception notAvailable) {
/*  485 */         this.resourcesNotLoaded.add(className);
/*      */       } 
/*      */     } 
/*  488 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class findImplementation(Class interfase) throws IOException, ClassNotFoundException {
/*  528 */     String className = findString(interfase.getName());
/*  529 */     Class<?> impl = this.classLoaderInterface.loadClass(className);
/*  530 */     if (!interfase.isAssignableFrom(impl)) {
/*  531 */       throw new ClassCastException("Class not of type: " + interfase.getName());
/*      */     }
/*  533 */     return impl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Class> findAllImplementations(Class interfase) throws IOException, ClassNotFoundException {
/*  572 */     List<Class<?>> implementations = new ArrayList<>();
/*  573 */     List<String> strings = findAllStrings(interfase.getName());
/*  574 */     for (String className : strings) {
/*  575 */       Class<?> impl = this.classLoaderInterface.loadClass(className);
/*  576 */       if (!interfase.isAssignableFrom(impl)) {
/*  577 */         throw new ClassCastException("Class not of type: " + interfase.getName());
/*      */       }
/*  579 */       implementations.add(impl);
/*      */     } 
/*  581 */     return implementations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Class> findAvailableImplementations(Class interfase) throws IOException {
/*  617 */     this.resourcesNotLoaded.clear();
/*  618 */     List<Class<?>> implementations = new ArrayList<>();
/*  619 */     List<String> strings = findAvailableStrings(interfase.getName());
/*  620 */     for (String className : strings) {
/*      */       try {
/*  622 */         Class<?> impl = this.classLoaderInterface.loadClass(className);
/*  623 */         if (interfase.isAssignableFrom(impl)) {
/*  624 */           implementations.add(impl); continue;
/*      */         } 
/*  626 */         this.resourcesNotLoaded.add(className);
/*      */       }
/*  628 */       catch (Exception notAvailable) {
/*  629 */         this.resourcesNotLoaded.add(className);
/*      */       } 
/*      */     } 
/*  632 */     return implementations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Class> mapAllImplementations(Class interfase) throws IOException, ClassNotFoundException {
/*  671 */     Map<String, Class<?>> implementations = new HashMap<>();
/*  672 */     Map<String, String> map = mapAllStrings(interfase.getName());
/*  673 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*  674 */       String string = entry.getKey();
/*  675 */       String className = entry.getValue();
/*  676 */       Class<?> impl = this.classLoaderInterface.loadClass(className);
/*  677 */       if (!interfase.isAssignableFrom(impl)) {
/*  678 */         throw new ClassCastException("Class not of type: " + interfase.getName());
/*      */       }
/*  680 */       implementations.put(string, impl);
/*      */     } 
/*  682 */     return implementations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Class> mapAvailableImplementations(Class interfase) throws IOException {
/*  719 */     this.resourcesNotLoaded.clear();
/*  720 */     Map<String, Class<?>> implementations = new HashMap<>();
/*  721 */     Map<String, String> map = mapAvailableStrings(interfase.getName());
/*  722 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*  723 */       String string = entry.getKey();
/*  724 */       String className = entry.getValue();
/*      */       try {
/*  726 */         Class<?> impl = this.classLoaderInterface.loadClass(className);
/*  727 */         if (interfase.isAssignableFrom(impl)) {
/*  728 */           implementations.put(string, impl); continue;
/*      */         } 
/*  730 */         this.resourcesNotLoaded.add(className);
/*      */       }
/*  732 */       catch (Exception notAvailable) {
/*  733 */         this.resourcesNotLoaded.add(className);
/*      */       } 
/*      */     } 
/*  736 */     return implementations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties findProperties(String uri) throws IOException {
/*  768 */     String fulluri = this.path + uri;
/*      */     
/*  770 */     URL resource = getResource(fulluri);
/*  771 */     if (resource == null) {
/*  772 */       throw new IOException("Could not find command in : " + fulluri);
/*      */     }
/*      */     
/*  775 */     return loadProperties(resource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Properties> findAllProperties(String uri) throws IOException {
/*  807 */     String fulluri = this.path + uri;
/*      */     
/*  809 */     List<Properties> properties = new ArrayList<>();
/*      */     
/*  811 */     Enumeration<URL> resources = getResources(fulluri);
/*  812 */     while (resources.hasMoreElements()) {
/*  813 */       URL url = resources.nextElement();
/*  814 */       Properties props = loadProperties(url);
/*  815 */       properties.add(props);
/*      */     } 
/*  817 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Properties> findAvailableProperties(String uri) throws IOException {
/*  850 */     this.resourcesNotLoaded.clear();
/*  851 */     String fulluri = this.path + uri;
/*      */     
/*  853 */     List<Properties> properties = new ArrayList<>();
/*      */     
/*  855 */     Enumeration<URL> resources = getResources(fulluri);
/*  856 */     while (resources.hasMoreElements()) {
/*  857 */       URL url = resources.nextElement();
/*      */       try {
/*  859 */         Properties props = loadProperties(url);
/*  860 */         properties.add(props);
/*  861 */       } catch (Exception notAvailable) {
/*  862 */         this.resourcesNotLoaded.add(url.toExternalForm());
/*      */       } 
/*      */     } 
/*  865 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Properties> mapAllProperties(String uri) throws IOException {
/*  900 */     Map<String, Properties> propertiesMap = new HashMap<>();
/*  901 */     Map<String, URL> map = getResourcesMap(uri);
/*  902 */     for (Map.Entry<String, URL> entry : map.entrySet()) {
/*  903 */       String string = entry.getKey();
/*  904 */       URL url = entry.getValue();
/*  905 */       Properties properties = loadProperties(url);
/*  906 */       propertiesMap.put(string, properties);
/*      */     } 
/*  908 */     return propertiesMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Properties> mapAvailableProperties(String uri) throws IOException {
/*  944 */     this.resourcesNotLoaded.clear();
/*  945 */     Map<String, Properties> propertiesMap = new HashMap<>();
/*  946 */     Map<String, URL> map = getResourcesMap(uri);
/*  947 */     for (Map.Entry<String, URL> entry : map.entrySet()) {
/*  948 */       String string = entry.getKey();
/*  949 */       URL url = entry.getValue();
/*      */       try {
/*  951 */         Properties properties = loadProperties(url);
/*  952 */         propertiesMap.put(string, properties);
/*  953 */       } catch (Exception notAvailable) {
/*  954 */         this.resourcesNotLoaded.add(url.toExternalForm());
/*      */       } 
/*      */     } 
/*  957 */     return propertiesMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, URL> getResourcesMap(String uri) throws IOException {
/*  967 */     String basePath = this.path + uri;
/*      */     
/*  969 */     Map<String, URL> resources = new HashMap<>();
/*  970 */     if (!basePath.endsWith("/")) {
/*  971 */       basePath = basePath + "/";
/*      */     }
/*  973 */     Enumeration<URL> urls = getResources(basePath);
/*      */     
/*  975 */     while (urls.hasMoreElements()) {
/*  976 */       URL location = urls.nextElement();
/*      */       
/*      */       try {
/*  979 */         if ("jar".equals(location.getProtocol())) {
/*  980 */           readJarEntries(location, basePath, resources); continue;
/*  981 */         }  if ("file".equals(location.getProtocol())) {
/*  982 */           readDirectoryEntries(location, resources);
/*      */         }
/*  984 */       } catch (Exception e) {
/*  985 */         LOG.debug("Got exception loading resources for {}", uri, e);
/*      */       } 
/*      */     } 
/*      */     
/*  989 */     return resources;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> findPackages(String uri) throws IOException {
/*  999 */     String basePath = this.path + uri;
/*      */     
/* 1001 */     Set<String> resources = new HashSet<>();
/* 1002 */     if (!basePath.endsWith("/")) {
/* 1003 */       basePath = basePath + "/";
/*      */     }
/* 1005 */     Enumeration<URL> urls = getResources(basePath);
/*      */     
/* 1007 */     while (urls.hasMoreElements()) {
/* 1008 */       URL location = urls.nextElement();
/*      */       
/*      */       try {
/* 1011 */         if ("jar".equals(location.getProtocol())) {
/* 1012 */           readJarDirectoryEntries(location, basePath, resources); continue;
/* 1013 */         }  if ("file".equals(location.getProtocol())) {
/* 1014 */           readSubDirectories(new File(location.toURI()), uri, resources);
/*      */         }
/* 1016 */       } catch (Exception e) {
/* 1017 */         LOG.debug("Got exception search for subpackages for {}", uri, e);
/*      */       } 
/*      */     } 
/*      */     
/* 1021 */     return convertPathsToPackages(resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<URL, Set<String>> findPackagesMap(String uri) throws IOException {
/* 1031 */     String basePath = this.path + uri;
/*      */     
/* 1033 */     LOG.trace("    basePath(initial): " + basePath);
/*      */     
/* 1035 */     if (!basePath.endsWith("/")) {
/* 1036 */       basePath = basePath + "/";
/*      */     }
/*      */     
/* 1039 */     LOG.trace("    basePath(final): " + basePath);
/*      */     
/* 1041 */     Enumeration<URL> urls = getResources(basePath);
/* 1042 */     Map<URL, Set<String>> result = new HashMap<>();
/*      */     
/* 1044 */     if (!urls.hasMoreElements()) {
/* 1045 */       LOG.debug("    urls enumeration for basePath is empty ?");
/*      */     }
/*      */     
/* 1048 */     while (urls.hasMoreElements()) {
/* 1049 */       URL location = urls.nextElement();
/*      */       
/* 1051 */       LOG.debug("       url (location): " + location);
/*      */       
/*      */       try {
/* 1054 */         if ("jar".equals(location.getProtocol())) {
/* 1055 */           Set<String> resources = new HashSet<>();
/* 1056 */           readJarDirectoryEntries(location, basePath, resources);
/* 1057 */           result.put(location, convertPathsToPackages(resources)); continue;
/* 1058 */         }  if ("file".equals(location.getProtocol())) {
/* 1059 */           Set<String> resources = new HashSet<>();
/* 1060 */           readSubDirectories(new File(location.toURI()), uri, resources);
/* 1061 */           result.put(location, convertPathsToPackages(resources));
/*      */         } 
/* 1063 */       } catch (Exception e) {
/* 1064 */         LOG.debug("Got exception finding subpackages for {}", uri, e);
/*      */       } 
/*      */     } 
/*      */     
/* 1068 */     return result;
/*      */   }
/*      */   
/*      */   private Set<String> convertPathsToPackages(Set<String> resources) {
/* 1072 */     Set<String> packageNames = new HashSet<>(resources.size());
/* 1073 */     for (String resource : resources) {
/* 1074 */       packageNames.add(StringUtils.removeEnd(StringUtils.replace(resource, "/", "."), "."));
/*      */     }
/*      */     
/* 1077 */     return packageNames;
/*      */   }
/*      */   
/*      */   private static void readDirectoryEntries(URL location, Map<String, URL> resources) throws MalformedURLException {
/* 1081 */     File dir = new File(URLDecoder.decode(location.getPath()));
/* 1082 */     if (dir.isDirectory()) {
/* 1083 */       File[] files = dir.listFiles();
/* 1084 */       for (File file : files) {
/* 1085 */         if (!file.isDirectory()) {
/* 1086 */           String name = file.getName();
/* 1087 */           URL url = file.toURL();
/* 1088 */           resources.put(name, url);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void readSubDirectories(File dir, String basePath, Set<String> resources) throws MalformedURLException {
/* 1098 */     if (dir.isDirectory()) {
/* 1099 */       File[] files = dir.listFiles();
/* 1100 */       for (File file : files) {
/* 1101 */         if (file.isDirectory()) {
/* 1102 */           String name = file.getName();
/* 1103 */           String subName = StringUtils.removeEnd(basePath, "/") + "/" + name;
/* 1104 */           resources.add(subName);
/* 1105 */           readSubDirectories(file, subName, resources);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void readJarEntries(URL location, String basePath, Map<String, URL> resources) throws IOException {
/* 1112 */     JarURLConnection conn = (JarURLConnection)location.openConnection();
/*      */     
/* 1114 */     JarFile jarfile = conn.getJarFile();
/*      */     
/* 1116 */     Enumeration<JarEntry> entries = jarfile.entries();
/* 1117 */     while (entries != null && entries.hasMoreElements()) {
/* 1118 */       JarEntry entry = entries.nextElement();
/* 1119 */       String name = entry.getName();
/*      */       
/* 1121 */       if (entry.isDirectory() || !name.startsWith(basePath) || name.length() == basePath.length()) {
/*      */         continue;
/*      */       }
/*      */       
/* 1125 */       name = name.substring(basePath.length());
/*      */       
/* 1127 */       if (name.contains("/")) {
/*      */         continue;
/*      */       }
/*      */       
/* 1131 */       URL resource = new URL(location, name);
/* 1132 */       resources.put(name, resource);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void readJarDirectoryEntries(URL location, String basePath, Set<String> resources) throws IOException {
/* 1138 */     JarURLConnection conn = (JarURLConnection)location.openConnection();
/*      */     
/* 1140 */     JarFile jarfile = conn.getJarFile();
/*      */     
/* 1142 */     Enumeration<JarEntry> entries = jarfile.entries();
/*      */     
/* 1144 */     if (entries == null || !entries.hasMoreElements()) {
/* 1145 */       LOG.debug("           JAR entries null or empty");
/*      */     }
/* 1147 */     LOG.debug("           Looking for entries matching basePath: " + basePath);
/*      */     
/* 1149 */     while (entries != null && entries.hasMoreElements()) {
/* 1150 */       JarEntry entry = entries.nextElement();
/* 1151 */       String name = entry.getName();
/*      */       
/* 1153 */       if (entry.isDirectory() && StringUtils.startsWith(name, basePath)) {
/* 1154 */         resources.add(name); continue;
/* 1155 */       }  if (entry.isDirectory()) {
/* 1156 */         LOG.trace("           entry: " + name + " , isDirectory: " + entry.isDirectory() + " but does not start with basepath");
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private Properties loadProperties(URL resource) throws IOException {
/* 1162 */     try (InputStream reader = new BufferedInputStream(resource.openStream())) {
/* 1163 */       Properties properties = new Properties();
/* 1164 */       properties.load(reader);
/*      */       
/* 1166 */       return properties;
/*      */     } 
/*      */   }
/*      */   
/*      */   private String readContents(URL resource) throws IOException {
/* 1171 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1173 */     try (InputStream reader = new BufferedInputStream(resource.openStream())) {
/* 1174 */       int b = reader.read();
/* 1175 */       while (b != -1) {
/* 1176 */         sb.append((char)b);
/* 1177 */         b = reader.read();
/*      */       } 
/*      */       
/* 1180 */       return sb.toString().trim();
/*      */     } 
/*      */   }
/*      */   
/*      */   private URL getResource(String fullUri) {
/* 1185 */     if (this.urls == null) {
/* 1186 */       return this.classLoaderInterface.getResource(fullUri);
/*      */     }
/* 1188 */     return findResource(fullUri, this.urls);
/*      */   }
/*      */   
/*      */   private Enumeration<URL> getResources(String fulluri) throws IOException {
/* 1192 */     if (this.urls == null) {
/* 1193 */       LOG.debug("    urls (member) null, using classLoaderInterface to get resources");
/*      */       
/* 1195 */       return this.classLoaderInterface.getResources(fulluri);
/*      */     } 
/*      */     
/* 1198 */     LOG.debug("    urls (member) non-null, using findResource to get resources");
/*      */     
/* 1200 */     Vector<URL> resources = new Vector<>();
/* 1201 */     for (URL url : this.urls) {
/* 1202 */       URL resource = findResource(fulluri, new URL[] { url });
/*      */       
/* 1204 */       if (resource != null) {
/* 1205 */         LOG.trace("    resource lookup non-null");
/* 1206 */         resources.add(resource);
/*      */       } else {
/* 1208 */         LOG.trace("    resource lookup is null");
/*      */       } 
/*      */     } 
/* 1211 */     return resources.elements();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private URL findResource(String resourceName, URL... search) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_3
/*      */     //   2: iload_3
/*      */     //   3: aload_2
/*      */     //   4: arraylength
/*      */     //   5: if_icmpge -> 540
/*      */     //   8: aload_2
/*      */     //   9: iload_3
/*      */     //   10: aaload
/*      */     //   11: astore #4
/*      */     //   13: aload #4
/*      */     //   15: ifnonnull -> 21
/*      */     //   18: goto -> 534
/*      */     //   21: aload #4
/*      */     //   23: invokevirtual getProtocol : ()Ljava/lang/String;
/*      */     //   26: astore #6
/*      */     //   28: ldc 'jar'
/*      */     //   30: aload #6
/*      */     //   32: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   35: ifeq -> 262
/*      */     //   38: aload #4
/*      */     //   40: invokevirtual openConnection : ()Ljava/net/URLConnection;
/*      */     //   43: checkcast java/net/JarURLConnection
/*      */     //   46: invokevirtual getJarFileURL : ()Ljava/net/URL;
/*      */     //   49: astore #7
/*      */     //   51: new java/net/URL
/*      */     //   54: dup
/*      */     //   55: ldc 'jar'
/*      */     //   57: ldc ''
/*      */     //   59: new java/lang/StringBuilder
/*      */     //   62: dup
/*      */     //   63: invokespecial <init> : ()V
/*      */     //   66: aload #7
/*      */     //   68: invokevirtual toExternalForm : ()Ljava/lang/String;
/*      */     //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   74: ldc '!/'
/*      */     //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   79: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   82: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   85: invokevirtual openConnection : ()Ljava/net/URLConnection;
/*      */     //   88: checkcast java/net/JarURLConnection
/*      */     //   91: astore #8
/*      */     //   93: aload #8
/*      */     //   95: invokevirtual getJarFile : ()Ljava/util/jar/JarFile;
/*      */     //   98: astore #5
/*      */     //   100: goto -> 112
/*      */     //   103: astore #8
/*      */     //   105: aload_2
/*      */     //   106: iload_3
/*      */     //   107: aconst_null
/*      */     //   108: aastore
/*      */     //   109: aload #8
/*      */     //   111: athrow
/*      */     //   112: aload #4
/*      */     //   114: invokevirtual getFile : ()Ljava/lang/String;
/*      */     //   117: ldc '!/'
/*      */     //   119: invokevirtual endsWith : (Ljava/lang/String;)Z
/*      */     //   122: ifeq -> 131
/*      */     //   125: aload_1
/*      */     //   126: astore #8
/*      */     //   128: goto -> 212
/*      */     //   131: aload #4
/*      */     //   133: invokevirtual getFile : ()Ljava/lang/String;
/*      */     //   136: astore #9
/*      */     //   138: aload #9
/*      */     //   140: ldc '!/'
/*      */     //   142: invokevirtual lastIndexOf : (Ljava/lang/String;)I
/*      */     //   145: istore #10
/*      */     //   147: iload #10
/*      */     //   149: iconst_m1
/*      */     //   150: if_icmpne -> 160
/*      */     //   153: aload_2
/*      */     //   154: iload_3
/*      */     //   155: aconst_null
/*      */     //   156: aastore
/*      */     //   157: goto -> 534
/*      */     //   160: iinc #10, 2
/*      */     //   163: new java/lang/StringBuilder
/*      */     //   166: dup
/*      */     //   167: aload #9
/*      */     //   169: invokevirtual length : ()I
/*      */     //   172: iload #10
/*      */     //   174: isub
/*      */     //   175: aload_1
/*      */     //   176: invokevirtual length : ()I
/*      */     //   179: iadd
/*      */     //   180: invokespecial <init> : (I)V
/*      */     //   183: astore #11
/*      */     //   185: aload #11
/*      */     //   187: aload #9
/*      */     //   189: iload #10
/*      */     //   191: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   197: pop
/*      */     //   198: aload #11
/*      */     //   200: aload_1
/*      */     //   201: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   204: pop
/*      */     //   205: aload #11
/*      */     //   207: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   210: astore #8
/*      */     //   212: ldc 'META-INF/'
/*      */     //   214: aload #8
/*      */     //   216: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   219: ifeq -> 241
/*      */     //   222: aload #5
/*      */     //   224: ldc 'META-INF/MANIFEST.MF'
/*      */     //   226: invokevirtual getEntry : (Ljava/lang/String;)Ljava/util/zip/ZipEntry;
/*      */     //   229: ifnull -> 241
/*      */     //   232: aload_0
/*      */     //   233: aload #4
/*      */     //   235: ldc 'META-INF/MANIFEST.MF'
/*      */     //   237: invokespecial targetURL : (Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;
/*      */     //   240: areturn
/*      */     //   241: aload #5
/*      */     //   243: aload #8
/*      */     //   245: invokevirtual getEntry : (Ljava/lang/String;)Ljava/util/zip/ZipEntry;
/*      */     //   248: ifnull -> 259
/*      */     //   251: aload_0
/*      */     //   252: aload #4
/*      */     //   254: aload_1
/*      */     //   255: invokespecial targetURL : (Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;
/*      */     //   258: areturn
/*      */     //   259: goto -> 529
/*      */     //   262: ldc 'file'
/*      */     //   264: aload #6
/*      */     //   266: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   269: ifeq -> 453
/*      */     //   272: aload #4
/*      */     //   274: invokevirtual getFile : ()Ljava/lang/String;
/*      */     //   277: astore #7
/*      */     //   279: aload #4
/*      */     //   281: invokevirtual getHost : ()Ljava/lang/String;
/*      */     //   284: astore #8
/*      */     //   286: iconst_0
/*      */     //   287: istore #9
/*      */     //   289: aload #8
/*      */     //   291: ifnull -> 301
/*      */     //   294: aload #8
/*      */     //   296: invokevirtual length : ()I
/*      */     //   299: istore #9
/*      */     //   301: new java/lang/StringBuilder
/*      */     //   304: dup
/*      */     //   305: iconst_2
/*      */     //   306: iload #9
/*      */     //   308: iadd
/*      */     //   309: aload #7
/*      */     //   311: invokevirtual length : ()I
/*      */     //   314: iadd
/*      */     //   315: aload_1
/*      */     //   316: invokevirtual length : ()I
/*      */     //   319: iadd
/*      */     //   320: invokespecial <init> : (I)V
/*      */     //   323: astore #10
/*      */     //   325: iload #9
/*      */     //   327: ifle -> 343
/*      */     //   330: aload #10
/*      */     //   332: ldc '//'
/*      */     //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   337: aload #8
/*      */     //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   342: pop
/*      */     //   343: aload #10
/*      */     //   345: aload #7
/*      */     //   347: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   350: pop
/*      */     //   351: aload_1
/*      */     //   352: astore #11
/*      */     //   354: aload #11
/*      */     //   356: ldc '/'
/*      */     //   358: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   361: ifne -> 374
/*      */     //   364: aload #11
/*      */     //   366: ldc '\'
/*      */     //   368: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   371: ifeq -> 385
/*      */     //   374: aload #11
/*      */     //   376: iconst_1
/*      */     //   377: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   380: astore #11
/*      */     //   382: goto -> 354
/*      */     //   385: aload #10
/*      */     //   387: aload #11
/*      */     //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   392: pop
/*      */     //   393: aload #10
/*      */     //   395: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   398: astore #12
/*      */     //   400: new java/io/File
/*      */     //   403: dup
/*      */     //   404: aload #12
/*      */     //   406: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   409: astore #13
/*      */     //   411: new java/io/File
/*      */     //   414: dup
/*      */     //   415: aload #12
/*      */     //   417: invokestatic decode : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   420: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   423: astore #14
/*      */     //   425: aload #13
/*      */     //   427: invokevirtual exists : ()Z
/*      */     //   430: ifne -> 441
/*      */     //   433: aload #14
/*      */     //   435: invokevirtual exists : ()Z
/*      */     //   438: ifeq -> 450
/*      */     //   441: aload_0
/*      */     //   442: aload #4
/*      */     //   444: aload #11
/*      */     //   446: invokespecial targetURL : (Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;
/*      */     //   449: areturn
/*      */     //   450: goto -> 529
/*      */     //   453: aload_0
/*      */     //   454: aload #4
/*      */     //   456: aload_1
/*      */     //   457: invokespecial targetURL : (Ljava/net/URL;Ljava/lang/String;)Ljava/net/URL;
/*      */     //   460: astore #7
/*      */     //   462: aload #7
/*      */     //   464: invokevirtual openConnection : ()Ljava/net/URLConnection;
/*      */     //   467: astore #8
/*      */     //   469: aload #8
/*      */     //   471: invokevirtual getInputStream : ()Ljava/io/InputStream;
/*      */     //   474: invokevirtual close : ()V
/*      */     //   477: goto -> 484
/*      */     //   480: astore #9
/*      */     //   482: aconst_null
/*      */     //   483: areturn
/*      */     //   484: ldc 'http'
/*      */     //   486: aload #7
/*      */     //   488: invokevirtual getProtocol : ()Ljava/lang/String;
/*      */     //   491: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   494: ifne -> 500
/*      */     //   497: aload #7
/*      */     //   499: areturn
/*      */     //   500: aload #8
/*      */     //   502: checkcast java/net/HttpURLConnection
/*      */     //   505: invokevirtual getResponseCode : ()I
/*      */     //   508: istore #9
/*      */     //   510: iload #9
/*      */     //   512: sipush #200
/*      */     //   515: if_icmplt -> 529
/*      */     //   518: iload #9
/*      */     //   520: sipush #300
/*      */     //   523: if_icmpge -> 529
/*      */     //   526: aload #7
/*      */     //   528: areturn
/*      */     //   529: goto -> 534
/*      */     //   532: astore #6
/*      */     //   534: iinc #3, 1
/*      */     //   537: goto -> 2
/*      */     //   540: aconst_null
/*      */     //   541: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1215	-> 0
/*      */     //   #1216	-> 8
/*      */     //   #1217	-> 13
/*      */     //   #1218	-> 18
/*      */     //   #1222	-> 21
/*      */     //   #1223	-> 28
/*      */     //   #1229	-> 38
/*      */     //   #1231	-> 51
/*      */     //   #1232	-> 93
/*      */     //   #1237	-> 100
/*      */     //   #1233	-> 103
/*      */     //   #1235	-> 105
/*      */     //   #1236	-> 109
/*      */     //   #1240	-> 112
/*      */     //   #1241	-> 125
/*      */     //   #1243	-> 131
/*      */     //   #1244	-> 138
/*      */     //   #1245	-> 147
/*      */     //   #1247	-> 153
/*      */     //   #1248	-> 157
/*      */     //   #1250	-> 160
/*      */     //   #1251	-> 163
/*      */     //   #1252	-> 185
/*      */     //   #1253	-> 198
/*      */     //   #1254	-> 205
/*      */     //   #1256	-> 212
/*      */     //   #1257	-> 232
/*      */     //   #1259	-> 241
/*      */     //   #1260	-> 251
/*      */     //   #1262	-> 259
/*      */     //   #1263	-> 272
/*      */     //   #1264	-> 279
/*      */     //   #1265	-> 286
/*      */     //   #1266	-> 289
/*      */     //   #1267	-> 294
/*      */     //   #1269	-> 301
/*      */     //   #1271	-> 325
/*      */     //   #1272	-> 330
/*      */     //   #1275	-> 343
/*      */     //   #1276	-> 351
/*      */     //   #1278	-> 354
/*      */     //   #1279	-> 374
/*      */     //   #1281	-> 385
/*      */     //   #1282	-> 393
/*      */     //   #1283	-> 400
/*      */     //   #1284	-> 411
/*      */     //   #1286	-> 425
/*      */     //   #1287	-> 441
/*      */     //   #1289	-> 450
/*      */     //   #1290	-> 453
/*      */     //   #1291	-> 462
/*      */     //   #1294	-> 469
/*      */     //   #1297	-> 477
/*      */     //   #1295	-> 480
/*      */     //   #1296	-> 482
/*      */     //   #1300	-> 484
/*      */     //   #1301	-> 497
/*      */     //   #1304	-> 500
/*      */     //   #1305	-> 510
/*      */     //   #1306	-> 526
/*      */     //   #1311	-> 529
/*      */     //   #1309	-> 532
/*      */     //   #1215	-> 534
/*      */     //   #1313	-> 540
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   93	7	8	juc	Ljava/net/JarURLConnection;
/*      */     //   100	3	5	jarFile	Ljava/util/jar/JarFile;
/*      */     //   105	7	8	e	Ljava/io/IOException;
/*      */     //   128	3	8	entryName	Ljava/lang/String;
/*      */     //   138	74	9	file	Ljava/lang/String;
/*      */     //   147	65	10	sepIdx	I
/*      */     //   185	27	11	sb	Ljava/lang/StringBuilder;
/*      */     //   51	208	7	jarURL	Ljava/net/URL;
/*      */     //   212	47	8	entryName	Ljava/lang/String;
/*      */     //   112	150	5	jarFile	Ljava/util/jar/JarFile;
/*      */     //   279	171	7	baseFile	Ljava/lang/String;
/*      */     //   286	164	8	host	Ljava/lang/String;
/*      */     //   289	161	9	hostLength	I
/*      */     //   325	125	10	buf	Ljava/lang/StringBuilder;
/*      */     //   354	96	11	fixedResName	Ljava/lang/String;
/*      */     //   400	50	12	filename	Ljava/lang/String;
/*      */     //   411	39	13	file	Ljava/io/File;
/*      */     //   425	25	14	file2	Ljava/io/File;
/*      */     //   482	2	9	e	Ljava/lang/SecurityException;
/*      */     //   462	67	7	resourceURL	Ljava/net/URL;
/*      */     //   469	60	8	urlConnection	Ljava/net/URLConnection;
/*      */     //   510	19	9	code	I
/*      */     //   28	501	6	protocol	Ljava/lang/String;
/*      */     //   13	521	4	currentUrl	Ljava/net/URL;
/*      */     //   2	538	3	i	I
/*      */     //   0	542	0	this	Lcom/opensymphony/xwork2/util/finder/ResourceFinder;
/*      */     //   0	542	1	resourceName	Ljava/lang/String;
/*      */     //   0	542	2	search	[Ljava/net/URL;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   21	157	532	java/io/IOException
/*      */     //   21	157	532	java/lang/SecurityException
/*      */     //   51	100	103	java/io/IOException
/*      */     //   160	240	532	java/io/IOException
/*      */     //   160	240	532	java/lang/SecurityException
/*      */     //   241	258	532	java/io/IOException
/*      */     //   241	258	532	java/lang/SecurityException
/*      */     //   259	449	532	java/io/IOException
/*      */     //   259	449	532	java/lang/SecurityException
/*      */     //   450	483	532	java/io/IOException
/*      */     //   450	483	532	java/lang/SecurityException
/*      */     //   469	477	480	java/lang/SecurityException
/*      */     //   484	499	532	java/io/IOException
/*      */     //   484	499	532	java/lang/SecurityException
/*      */     //   500	528	532	java/io/IOException
/*      */     //   500	528	532	java/lang/SecurityException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private URL targetURL(URL base, String name) throws MalformedURLException {
/* 1317 */     StringBuilder sb = new StringBuilder(base.getFile().length() + name.length());
/* 1318 */     sb.append(base.getFile());
/* 1319 */     sb.append(name);
/* 1320 */     String file = sb.toString();
/* 1321 */     return new URL(base.getProtocol(), base.getHost(), base.getPort(), file, null);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\finder\ResourceFinder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */