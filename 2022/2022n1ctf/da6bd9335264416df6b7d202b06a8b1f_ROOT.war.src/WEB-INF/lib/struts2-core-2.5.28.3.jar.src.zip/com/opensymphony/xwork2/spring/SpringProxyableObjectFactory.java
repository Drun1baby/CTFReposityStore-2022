/*    */ package com.opensymphony.xwork2.spring;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringProxyableObjectFactory
/*    */   extends SpringObjectFactory
/*    */ {
/* 40 */   private static final Logger LOG = LogManager.getLogger(SpringProxyableObjectFactory.class);
/*    */   
/* 42 */   private List<String> skipBeanNames = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object buildBean(String beanName, Map<String, Object> extraContext) throws Exception {
/* 49 */     LOG.debug("Building bean for name {}", beanName);
/* 50 */     if (!this.skipBeanNames.contains(beanName)) {
/* 51 */       ApplicationContext anAppContext = getApplicationContext(extraContext);
/*    */       try {
/* 53 */         LOG.debug("Trying the application context... appContext = {},\n bean name = {}", anAppContext, beanName);
/* 54 */         return anAppContext.getBean(beanName);
/* 55 */       } catch (NoSuchBeanDefinitionException e) {
/* 56 */         LOG.debug("Did not find bean definition for bean named {}, creating a new one...", beanName);
/* 57 */         if (this.autoWiringFactory instanceof BeanDefinitionRegistry) {
/*    */           try {
/* 59 */             Class<?> clazz = Class.forName(beanName);
/* 60 */             BeanDefinitionRegistry registry = (BeanDefinitionRegistry)this.autoWiringFactory;
/* 61 */             RootBeanDefinition def = new RootBeanDefinition(clazz, this.autowireStrategy, true);
/* 62 */             def.setScope("singleton");
/* 63 */             LOG.debug("Registering a new bean definition for class {}", beanName);
/* 64 */             registry.registerBeanDefinition(beanName, (BeanDefinition)def);
/*    */             try {
/* 66 */               return anAppContext.getBean(beanName);
/* 67 */             } catch (NoSuchBeanDefinitionException e2) {
/* 68 */               LOG.warn("Could not register new bean definition for bean {}", beanName);
/* 69 */               this.skipBeanNames.add(beanName);
/*    */             } 
/* 71 */           } catch (ClassNotFoundException e1) {
/* 72 */             this.skipBeanNames.add(beanName);
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/* 77 */     LOG.debug("Returning autowired instance created by default ObjectFactory");
/* 78 */     return autoWireBean(super.buildBean(beanName, extraContext), this.autoWiringFactory);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ApplicationContext getApplicationContext(Map<String, Object> context) {
/* 91 */     return this.appContext;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\spring\SpringProxyableObjectFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */