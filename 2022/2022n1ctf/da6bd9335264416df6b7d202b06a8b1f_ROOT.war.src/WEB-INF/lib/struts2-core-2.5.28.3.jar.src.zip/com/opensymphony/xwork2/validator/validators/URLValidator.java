/*     */ package com.opensymphony.xwork2.validator.validators;
/*     */ 
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLValidator
/*     */   extends FieldValidatorSupport
/*     */ {
/*  52 */   private static final Logger LOG = LogManager.getLogger(URLValidator.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String DEFAULT_URL_REGEX = "^(?:https?|ftp):\\/\\/(?:(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+(?::(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+)?@)?#?(?:(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)*[a-z][a-z0-9-]*[a-z0-9]|(?:(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.){3}(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5]))(?::\\d+)?)(?:(?:\\/(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)*(?:\\?(?:[a-z0-9$_.+!*'(),;:@&=\\-\\/:]|%[0-9a-f]{2})*)?)?(?:#(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)?$";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String urlRegexExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private Pattern urlPattern = Pattern.compile("^(?:https?|ftp):\\/\\/(?:(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+(?::(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+)?@)?#?(?:(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)*[a-z][a-z0-9-]*[a-z0-9]|(?:(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.){3}(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5]))(?::\\d+)?)(?:(?:\\/(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)*(?:\\?(?:[a-z0-9$_.+!*'(),;:@&=\\-\\/:]|%[0-9a-f]{2})*)?)?(?:#(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)?$", 2);
/*     */   
/*     */   public void validate(Object object) throws ValidationException {
/*  72 */     Object value = getFieldValue(this.fieldName, object);
/*     */     
/*  74 */     String stringValue = Objects.toString(value, "").trim();
/*  75 */     if (stringValue.length() == 0) {
/*  76 */       LOG.debug("Value for field {} is empty, won't ba validated, please use a required validator", this.fieldName);
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     if (value.getClass().isArray()) {
/*  81 */       Object[] values = (Object[])value;
/*  82 */       for (Object objValue : values) {
/*  83 */         LOG.debug("Validating element of array: {}", objValue);
/*  84 */         validateValue(object, objValue);
/*     */       } 
/*  86 */     } else if (Collection.class.isAssignableFrom(value.getClass())) {
/*  87 */       Collection values = (Collection)value;
/*  88 */       for (Object objValue : values) {
/*  89 */         LOG.debug("Validating element of collection: {}", objValue);
/*  90 */         validateValue(object, objValue);
/*     */       } 
/*     */     } else {
/*  93 */       LOG.debug("Validating field: {}", value);
/*  94 */       validateValue(object, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateValue(Object object, Object value) {
/*  99 */     String stringValue = Objects.toString(value, "").trim();
/* 100 */     if (stringValue.length() == 0) {
/* 101 */       LOG.debug("Value for field {} is empty, won't ba validated, please use a required validator", this.fieldName);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 106 */       setCurrentValue(value);
/* 107 */       if (!value.getClass().equals(String.class) || !getUrlPattern().matcher(stringValue).matches()) {
/* 108 */         addFieldError(this.fieldName, object);
/*     */       }
/*     */     } finally {
/* 111 */       setCurrentValue((Object)null);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Pattern getUrlPattern() {
/* 116 */     if (StringUtils.isNotEmpty(this.urlRegexExpression)) {
/* 117 */       String regex = (String)parse(this.urlRegexExpression, String.class);
/* 118 */       if (regex == null) {
/* 119 */         LOG.warn("Provided URL Regex expression [{}] was evaluated to null! Falling back to default!", this.urlRegexExpression);
/* 120 */         this.urlPattern = Pattern.compile("^(?:https?|ftp):\\/\\/(?:(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+(?::(?:[a-z0-9$_.+!*'(),;?&=\\-]|%[0-9a-f]{2})+)?@)?#?(?:(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)*[a-z][a-z0-9-]*[a-z0-9]|(?:(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.){3}(?:[1-9]?\\d|1\\d{2}|2[0-4]\\d|25[0-5]))(?::\\d+)?)(?:(?:\\/(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)*(?:\\?(?:[a-z0-9$_.+!*'(),;:@&=\\-\\/:]|%[0-9a-f]{2})*)?)?(?:#(?:[a-z0-9$_.+!*'(),;:@&=\\-]|%[0-9a-f]{2})*)?$", 2);
/*     */       } else {
/* 122 */         this.urlPattern = Pattern.compile(regex, 2);
/*     */       } 
/*     */     } 
/* 125 */     return this.urlPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrlRegex() {
/* 135 */     return getUrlPattern().pattern();
/*     */   }
/*     */   
/*     */   public void setUrlRegex(String urlRegex) {
/* 139 */     this.urlPattern = Pattern.compile(urlRegex, 2);
/*     */   }
/*     */   
/*     */   public void setUrlRegexExpression(String urlRegexExpression) {
/* 143 */     this.urlRegexExpression = urlRegexExpression;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\validator\validators\URLValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */