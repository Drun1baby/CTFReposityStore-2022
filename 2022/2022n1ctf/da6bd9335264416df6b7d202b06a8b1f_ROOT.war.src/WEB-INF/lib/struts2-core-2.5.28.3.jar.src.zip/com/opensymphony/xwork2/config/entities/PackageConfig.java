/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageConfig
/*     */   extends Located
/*     */   implements Comparable, Serializable, InterceptorLocator
/*     */ {
/*  42 */   private static final Logger LOG = LogManager.getLogger(PackageConfig.class);
/*     */   
/*     */   protected Map<String, ActionConfig> actionConfigs;
/*     */   protected Map<String, ResultConfig> globalResultConfigs;
/*     */   protected Set<String> globalAllowedMethods;
/*     */   protected Map<String, Object> interceptorConfigs;
/*     */   protected Map<String, ResultTypeConfig> resultTypeConfigs;
/*     */   protected List<ExceptionMappingConfig> globalExceptionMappingConfigs;
/*     */   protected List<PackageConfig> parents;
/*     */   protected String defaultInterceptorRef;
/*     */   protected String defaultActionRef;
/*     */   protected String defaultResultType;
/*     */   protected String defaultClassRef;
/*     */   protected String name;
/*  56 */   protected String namespace = "";
/*     */   protected boolean isAbstract = false;
/*     */   protected boolean needsRefresh;
/*     */   protected boolean strictMethodInvocation = true;
/*     */   
/*     */   protected PackageConfig(String name) {
/*  62 */     this.name = name;
/*  63 */     this.actionConfigs = new LinkedHashMap<>();
/*  64 */     this.globalResultConfigs = new LinkedHashMap<>();
/*  65 */     this.globalAllowedMethods = new HashSet<>();
/*  66 */     this.interceptorConfigs = new LinkedHashMap<>();
/*  67 */     this.resultTypeConfigs = new LinkedHashMap<>();
/*  68 */     this.globalExceptionMappingConfigs = new ArrayList<>();
/*  69 */     this.parents = new ArrayList<>();
/*     */   }
/*     */   
/*     */   protected PackageConfig(PackageConfig orig) {
/*  73 */     this.defaultInterceptorRef = orig.defaultInterceptorRef;
/*  74 */     this.defaultActionRef = orig.defaultActionRef;
/*  75 */     this.defaultResultType = orig.defaultResultType;
/*  76 */     this.defaultClassRef = orig.defaultClassRef;
/*  77 */     this.name = orig.name;
/*  78 */     this.namespace = orig.namespace;
/*  79 */     this.isAbstract = orig.isAbstract;
/*  80 */     this.needsRefresh = orig.needsRefresh;
/*  81 */     this.actionConfigs = new LinkedHashMap<>(orig.actionConfigs);
/*  82 */     this.globalResultConfigs = new LinkedHashMap<>(orig.globalResultConfigs);
/*  83 */     this.globalAllowedMethods = new LinkedHashSet<>(orig.globalAllowedMethods);
/*  84 */     this.interceptorConfigs = new LinkedHashMap<>(orig.interceptorConfigs);
/*  85 */     this.resultTypeConfigs = new LinkedHashMap<>(orig.resultTypeConfigs);
/*  86 */     this.globalExceptionMappingConfigs = new ArrayList<>(orig.globalExceptionMappingConfigs);
/*  87 */     this.parents = new ArrayList<>(orig.parents);
/*  88 */     this.location = orig.location;
/*  89 */     this.strictMethodInvocation = orig.strictMethodInvocation;
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/*  93 */     return this.isAbstract;
/*     */   }
/*     */   
/*     */   public Map<String, ActionConfig> getActionConfigs() {
/*  97 */     return this.actionConfigs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ActionConfig> getAllActionConfigs() {
/* 108 */     Map<String, ActionConfig> retMap = new LinkedHashMap<>();
/*     */     
/* 110 */     if (!this.parents.isEmpty()) {
/* 111 */       for (PackageConfig parent : this.parents) {
/* 112 */         retMap.putAll(parent.getAllActionConfigs());
/*     */       }
/*     */     }
/*     */     
/* 116 */     retMap.putAll(getActionConfigs());
/*     */     
/* 118 */     return retMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ResultConfig> getAllGlobalResults() {
/* 129 */     Map<String, ResultConfig> retMap = new LinkedHashMap<>();
/*     */     
/* 131 */     if (!this.parents.isEmpty()) {
/* 132 */       for (PackageConfig parentConfig : this.parents) {
/* 133 */         retMap.putAll(parentConfig.getAllGlobalResults());
/*     */       }
/*     */     }
/*     */     
/* 137 */     retMap.putAll(getGlobalResultConfigs());
/*     */     
/* 139 */     return retMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAllInterceptorConfigs() {
/* 151 */     Map<String, Object> retMap = new LinkedHashMap<>();
/*     */     
/* 153 */     if (!this.parents.isEmpty()) {
/* 154 */       for (PackageConfig parentContext : this.parents) {
/* 155 */         retMap.putAll(parentContext.getAllInterceptorConfigs());
/*     */       }
/*     */     }
/*     */     
/* 159 */     retMap.putAll(getInterceptorConfigs());
/*     */     
/* 161 */     return retMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ResultTypeConfig> getAllResultTypeConfigs() {
/* 172 */     Map<String, ResultTypeConfig> retMap = new LinkedHashMap<>();
/*     */     
/* 174 */     if (!this.parents.isEmpty()) {
/* 175 */       for (PackageConfig parentContext : this.parents) {
/* 176 */         retMap.putAll(parentContext.getAllResultTypeConfigs());
/*     */       }
/*     */     }
/*     */     
/* 180 */     retMap.putAll(getResultTypeConfigs());
/*     */     
/* 182 */     return retMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ExceptionMappingConfig> getAllExceptionMappingConfigs() {
/* 193 */     List<ExceptionMappingConfig> allExceptionMappings = new ArrayList<>();
/*     */     
/* 195 */     if (!this.parents.isEmpty()) {
/* 196 */       for (PackageConfig parentContext : this.parents) {
/* 197 */         allExceptionMappings.addAll(parentContext.getAllExceptionMappingConfigs());
/*     */       }
/*     */     }
/*     */     
/* 201 */     allExceptionMappings.addAll(getGlobalExceptionMappingConfigs());
/*     */     
/* 203 */     return allExceptionMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultInterceptorRef() {
/* 208 */     return this.defaultInterceptorRef;
/*     */   }
/*     */   
/*     */   public String getDefaultActionRef() {
/* 212 */     return this.defaultActionRef;
/*     */   }
/*     */   
/*     */   public String getDefaultClassRef() {
/* 216 */     if (this.defaultClassRef == null && !this.parents.isEmpty()) {
/* 217 */       for (PackageConfig parent : this.parents) {
/* 218 */         String parentDefault = parent.getDefaultClassRef();
/* 219 */         if (parentDefault != null) {
/* 220 */           return parentDefault;
/*     */         }
/*     */       } 
/*     */     }
/* 224 */     return this.defaultClassRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultResultType() {
/* 231 */     return this.defaultResultType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullDefaultInterceptorRef() {
/* 239 */     if (this.defaultInterceptorRef == null && !this.parents.isEmpty()) {
/* 240 */       for (PackageConfig parent : this.parents) {
/* 241 */         String parentDefault = parent.getFullDefaultInterceptorRef();
/*     */         
/* 243 */         if (parentDefault != null) {
/* 244 */           return parentDefault;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 249 */     return this.defaultInterceptorRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullDefaultActionRef() {
/* 257 */     if (this.defaultActionRef == null && !this.parents.isEmpty()) {
/* 258 */       for (PackageConfig parent : this.parents) {
/* 259 */         String parentDefault = parent.getFullDefaultActionRef();
/*     */         
/* 261 */         if (parentDefault != null) {
/* 262 */           return parentDefault;
/*     */         }
/*     */       } 
/*     */     }
/* 266 */     return this.defaultActionRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullDefaultResultType() {
/* 282 */     if (this.defaultResultType == null && !this.parents.isEmpty()) {
/* 283 */       for (PackageConfig parent : this.parents) {
/* 284 */         String parentDefault = parent.getFullDefaultResultType();
/*     */         
/* 286 */         if (parentDefault != null) {
/* 287 */           return parentDefault;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 292 */     return this.defaultResultType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ResultConfig> getGlobalResultConfigs() {
/* 302 */     return this.globalResultConfigs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getInterceptorConfigs() {
/* 313 */     return this.interceptorConfigs;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 317 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 321 */     return this.namespace;
/*     */   }
/*     */   
/*     */   public List<PackageConfig> getParents() {
/* 325 */     return new ArrayList<>(this.parents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, ResultTypeConfig> getResultTypeConfigs() {
/* 335 */     return this.resultTypeConfigs;
/*     */   }
/*     */   
/*     */   public boolean isNeedsRefresh() {
/* 339 */     return this.needsRefresh;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ExceptionMappingConfig> getGlobalExceptionMappingConfigs() {
/* 349 */     return this.globalExceptionMappingConfigs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getGlobalAllowedMethods() {
/* 357 */     return Collections.unmodifiableSet(this.globalAllowedMethods);
/*     */   }
/*     */   public boolean isStrictMethodInvocation() {
/* 360 */     return this.strictMethodInvocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 365 */     if (this == o) return true; 
/* 366 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/* 368 */     PackageConfig that = (PackageConfig)o;
/*     */     
/* 370 */     if (this.isAbstract != that.isAbstract) return false; 
/* 371 */     if (this.needsRefresh != that.needsRefresh) return false; 
/* 372 */     if (this.strictMethodInvocation != that.strictMethodInvocation) return false; 
/* 373 */     if ((this.actionConfigs != null) ? !this.actionConfigs.equals(that.actionConfigs) : (that.actionConfigs != null))
/* 374 */       return false; 
/* 375 */     if ((this.globalResultConfigs != null) ? !this.globalResultConfigs.equals(that.globalResultConfigs) : (that.globalResultConfigs != null))
/* 376 */       return false; 
/* 377 */     if ((this.globalAllowedMethods != null) ? !this.globalAllowedMethods.equals(that.globalAllowedMethods) : (that.globalAllowedMethods != null))
/* 378 */       return false; 
/* 379 */     if ((this.interceptorConfigs != null) ? !this.interceptorConfigs.equals(that.interceptorConfigs) : (that.interceptorConfigs != null))
/* 380 */       return false; 
/* 381 */     if ((this.resultTypeConfigs != null) ? !this.resultTypeConfigs.equals(that.resultTypeConfigs) : (that.resultTypeConfigs != null))
/* 382 */       return false; 
/* 383 */     if ((this.globalExceptionMappingConfigs != null) ? !this.globalExceptionMappingConfigs.equals(that.globalExceptionMappingConfigs) : (that.globalExceptionMappingConfigs != null))
/* 384 */       return false; 
/* 385 */     if ((this.parents != null) ? !this.parents.equals(that.parents) : (that.parents != null)) return false; 
/* 386 */     if ((this.defaultInterceptorRef != null) ? !this.defaultInterceptorRef.equals(that.defaultInterceptorRef) : (that.defaultInterceptorRef != null))
/* 387 */       return false; 
/* 388 */     if ((this.defaultActionRef != null) ? !this.defaultActionRef.equals(that.defaultActionRef) : (that.defaultActionRef != null))
/* 389 */       return false; 
/* 390 */     if ((this.defaultResultType != null) ? !this.defaultResultType.equals(that.defaultResultType) : (that.defaultResultType != null))
/* 391 */       return false; 
/* 392 */     if ((this.defaultClassRef != null) ? !this.defaultClassRef.equals(that.defaultClassRef) : (that.defaultClassRef != null))
/* 393 */       return false; 
/* 394 */     if (!this.name.equals(that.name)) return false; 
/* 395 */     if ((this.namespace != null) ? !this.namespace.equals(that.namespace) : (that.namespace != null)) return false;
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 401 */     int result = (this.actionConfigs != null) ? this.actionConfigs.hashCode() : 0;
/* 402 */     result = 31 * result + ((this.globalResultConfigs != null) ? this.globalResultConfigs.hashCode() : 0);
/* 403 */     result = 31 * result + ((this.globalAllowedMethods != null) ? this.globalAllowedMethods.hashCode() : 0);
/* 404 */     result = 31 * result + ((this.interceptorConfigs != null) ? this.interceptorConfigs.hashCode() : 0);
/* 405 */     result = 31 * result + ((this.resultTypeConfigs != null) ? this.resultTypeConfigs.hashCode() : 0);
/* 406 */     result = 31 * result + ((this.globalExceptionMappingConfigs != null) ? this.globalExceptionMappingConfigs.hashCode() : 0);
/* 407 */     result = 31 * result + ((this.parents != null) ? this.parents.hashCode() : 0);
/* 408 */     result = 31 * result + ((this.defaultInterceptorRef != null) ? this.defaultInterceptorRef.hashCode() : 0);
/* 409 */     result = 31 * result + ((this.defaultActionRef != null) ? this.defaultActionRef.hashCode() : 0);
/* 410 */     result = 31 * result + ((this.defaultResultType != null) ? this.defaultResultType.hashCode() : 0);
/* 411 */     result = 31 * result + ((this.defaultClassRef != null) ? this.defaultClassRef.hashCode() : 0);
/* 412 */     result = 31 * result + this.name.hashCode();
/* 413 */     result = 31 * result + ((this.namespace != null) ? this.namespace.hashCode() : 0);
/* 414 */     result = 31 * result + (this.isAbstract ? 1 : 0);
/* 415 */     result = 31 * result + (this.needsRefresh ? 1 : 0);
/* 416 */     result = 31 * result + (this.strictMethodInvocation ? 1 : 0);
/* 417 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 422 */     return "PackageConfig: [" + this.name + "] for namespace [" + this.namespace + "] with parents [" + this.parents + "]";
/*     */   }
/*     */   
/*     */   public int compareTo(Object o) {
/* 426 */     PackageConfig other = (PackageConfig)o;
/* 427 */     String full = this.namespace + "!" + this.name;
/* 428 */     String otherFull = other.namespace + "!" + other.name;
/*     */ 
/*     */     
/* 431 */     return full.compareTo(otherFull);
/*     */   }
/*     */   
/*     */   public Object getInterceptorConfig(String name) {
/* 435 */     return getAllInterceptorConfigs().get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     implements InterceptorLocator
/*     */   {
/*     */     protected PackageConfig target;
/*     */     
/*     */     private boolean strictDMI = true;
/*     */ 
/*     */     
/*     */     public Builder(String name) {
/* 449 */       this.target = new PackageConfig(name);
/*     */     }
/*     */     
/*     */     public Builder(PackageConfig config) {
/* 453 */       this.target = new PackageConfig(config);
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 457 */       this.target.name = name;
/* 458 */       return this;
/*     */     }
/*     */     
/*     */     public Builder isAbstract(boolean isAbstract) {
/* 462 */       this.target.isAbstract = isAbstract;
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultInterceptorRef(String name) {
/* 467 */       this.target.defaultInterceptorRef = name;
/* 468 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultActionRef(String name) {
/* 472 */       this.target.defaultActionRef = name;
/* 473 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultClassRef(String defaultClassRef) {
/* 477 */       this.target.defaultClassRef = defaultClassRef;
/* 478 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder defaultResultType(String defaultResultType) {
/* 489 */       this.target.defaultResultType = defaultResultType;
/* 490 */       return this;
/*     */     }
/*     */     
/*     */     public Builder namespace(String namespace) {
/* 494 */       if (namespace == null) {
/* 495 */         this.target.namespace = "";
/*     */       } else {
/* 497 */         this.target.namespace = namespace;
/*     */       } 
/* 499 */       return this;
/*     */     }
/*     */     
/*     */     public Builder needsRefresh(boolean needsRefresh) {
/* 503 */       this.target.needsRefresh = needsRefresh;
/* 504 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addActionConfig(String name, ActionConfig action) {
/* 508 */       this.target.actionConfigs.put(name, action);
/* 509 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParents(List<PackageConfig> parents) {
/* 513 */       for (PackageConfig config : parents) {
/* 514 */         addParent(config);
/*     */       }
/* 516 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addGlobalResultConfig(ResultConfig resultConfig) {
/* 520 */       this.target.globalResultConfigs.put(resultConfig.getName(), resultConfig);
/* 521 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addGlobalResultConfigs(Map<String, ResultConfig> resultConfigs) {
/* 525 */       this.target.globalResultConfigs.putAll(resultConfigs);
/* 526 */       return this;
/*     */     }
/*     */     
/*     */     public Set<String> getGlobalAllowedMethods() {
/* 530 */       Set<String> allowedMethods = this.target.globalAllowedMethods;
/* 531 */       allowedMethods.addAll(getParentsAllowedMethods(this.target.parents));
/* 532 */       return Collections.unmodifiableSet(allowedMethods);
/*     */     }
/*     */     
/*     */     public Set<String> getParentsAllowedMethods(List<PackageConfig> parents) {
/* 536 */       Set<String> allowedMethods = new HashSet<>();
/* 537 */       for (PackageConfig parent : parents) {
/* 538 */         allowedMethods.addAll(parent.globalAllowedMethods);
/* 539 */         allowedMethods.addAll(getParentsAllowedMethods(parent.getParents()));
/*     */       } 
/* 541 */       return allowedMethods;
/*     */     }
/*     */     
/*     */     public Builder addGlobalAllowedMethods(Set<String> allowedMethods) {
/* 545 */       this.target.globalAllowedMethods.addAll(allowedMethods);
/* 546 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addExceptionMappingConfig(ExceptionMappingConfig exceptionMappingConfig) {
/* 550 */       this.target.globalExceptionMappingConfigs.add(exceptionMappingConfig);
/* 551 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addGlobalExceptionMappingConfigs(List<ExceptionMappingConfig> exceptionMappingConfigs) {
/* 555 */       this.target.globalExceptionMappingConfigs.addAll(exceptionMappingConfigs);
/* 556 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addInterceptorConfig(InterceptorConfig config) {
/* 560 */       this.target.interceptorConfigs.put(config.getName(), config);
/* 561 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addInterceptorStackConfig(InterceptorStackConfig config) {
/* 565 */       this.target.interceptorConfigs.put(config.getName(), config);
/* 566 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParent(PackageConfig parent) {
/* 570 */       this.target.parents.add(0, parent);
/* 571 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addResultTypeConfig(ResultTypeConfig config) {
/* 575 */       this.target.resultTypeConfigs.put(config.getName(), config);
/* 576 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 580 */       this.target.location = loc;
/* 581 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isNeedsRefresh() {
/* 585 */       return this.target.needsRefresh;
/*     */     }
/*     */     
/*     */     public String getDefaultClassRef() {
/* 589 */       return this.target.defaultClassRef;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 593 */       return this.target.name;
/*     */     }
/*     */     
/*     */     public String getNamespace() {
/* 597 */       return this.target.namespace;
/*     */     }
/*     */     
/*     */     public String getFullDefaultResultType() {
/* 601 */       return this.target.getFullDefaultResultType();
/*     */     }
/*     */     
/*     */     public ResultTypeConfig getResultType(String type) {
/* 605 */       return this.target.getAllResultTypeConfigs().get(type);
/*     */     }
/*     */     
/*     */     public Object getInterceptorConfig(String name) {
/* 609 */       return this.target.getAllInterceptorConfigs().get(name);
/*     */     }
/*     */     
/*     */     public Builder strictMethodInvocation(boolean strict) {
/* 613 */       this.target.strictMethodInvocation = strict;
/* 614 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isStrictMethodInvocation() {
/* 618 */       return this.target.strictMethodInvocation;
/*     */     }
/*     */     
/*     */     public PackageConfig build() {
/* 622 */       this.target.actionConfigs = Collections.unmodifiableMap(this.target.actionConfigs);
/* 623 */       this.target.globalResultConfigs = Collections.unmodifiableMap(this.target.globalResultConfigs);
/* 624 */       this.target.interceptorConfigs = Collections.unmodifiableMap(this.target.interceptorConfigs);
/* 625 */       this.target.resultTypeConfigs = Collections.unmodifiableMap(this.target.resultTypeConfigs);
/* 626 */       this.target.globalExceptionMappingConfigs = Collections.unmodifiableList(this.target.globalExceptionMappingConfigs);
/* 627 */       this.target.parents = Collections.unmodifiableList(this.target.parents);
/* 628 */       PackageConfig result = this.target;
/* 629 */       this.target = new PackageConfig(result);
/* 630 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 635 */       return "[BUILDER] " + this.target.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\PackageConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */