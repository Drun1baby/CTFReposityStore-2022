/*     */ package com.opensymphony.xwork2.config.impl;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.math.NumberUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMatcher<E>
/*     */   implements Serializable
/*     */ {
/*  40 */   private static final Logger LOG = LogManager.getLogger(AbstractMatcher.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PatternMatcher<Object> wildcard;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   List<Mapping<E>> compiledPatterns = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean appendNamedParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractMatcher(PatternMatcher<?> helper, boolean appendNamedParameters) {
/*  66 */     this.wildcard = (PatternMatcher)helper;
/*  67 */     this.appendNamedParameters = appendNamedParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AbstractMatcher(PatternMatcher<?> helper) {
/*  78 */     this(helper, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPattern(String name, E target, boolean looseMatch) {
/* 104 */     if (!this.wildcard.isLiteral(name)) {
/* 105 */       if (looseMatch && name.length() > 0 && name.charAt(0) == '/') {
/* 106 */         name = name.substring(1);
/*     */       }
/*     */       
/* 109 */       LOG.debug("Compiling pattern '{}'", name);
/*     */       
/* 111 */       Object pattern = this.wildcard.compilePattern(name);
/* 112 */       this.compiledPatterns.add(new Mapping<>(name, pattern, target));
/*     */       
/* 114 */       if (looseMatch) {
/* 115 */         int lastStar = name.lastIndexOf('*');
/* 116 */         if (lastStar > 1 && lastStar == name.length() - 1 && 
/* 117 */           name.charAt(lastStar - 1) != '*') {
/* 118 */           pattern = this.wildcard.compilePattern(name.substring(0, lastStar - 1));
/* 119 */           this.compiledPatterns.add(new Mapping<>(name, pattern, target));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void freeze() {
/* 127 */     this.compiledPatterns = Collections.unmodifiableList(new ArrayList<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E match(String potentialMatch) {
/* 137 */     E config = null;
/*     */     
/* 139 */     if (this.compiledPatterns.size() > 0) {
/* 140 */       LOG.debug("Attempting to match '{}' to a wildcard pattern, {} available", potentialMatch, Integer.valueOf(this.compiledPatterns.size()));
/*     */       
/* 142 */       Map<String, String> vars = new LinkedHashMap<>();
/* 143 */       for (Mapping<E> m : this.compiledPatterns) {
/* 144 */         if (this.wildcard.match(vars, potentialMatch, m.getPattern())) {
/* 145 */           LOG.debug("Value matches pattern '{}'", m.getOriginalPattern());
/* 146 */           config = convert(potentialMatch, m.getTarget(), vars);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 152 */     return config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract E convert(String paramString, E paramE, Map<String, String> paramMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> replaceParameters(Map<String, String> orig, Map<String, String> vars) {
/* 176 */     Map<String, String> map = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 179 */     for (Map.Entry<String, String> entry : orig.entrySet()) {
/* 180 */       map.put(entry.getKey(), convertParam(entry.getValue(), vars));
/*     */     }
/*     */     
/* 183 */     if (this.appendNamedParameters) {
/* 184 */       LOG.debug("Appending named parameters to the result map");
/*     */ 
/*     */       
/* 187 */       for (Map.Entry<String, String> entry : vars.entrySet()) {
/* 188 */         if (!NumberUtils.isCreatable(entry.getKey())) {
/* 189 */           map.put(entry.getKey(), entry.getValue());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 194 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String convertParam(String val, Map<String, String> vars) {
/* 208 */     if (val == null) {
/* 209 */       return null;
/*     */     }
/*     */     
/* 212 */     int len = val.length();
/* 213 */     StringBuilder ret = new StringBuilder();
/*     */ 
/*     */     
/* 216 */     for (int x = 0; x < len; x++) {
/* 217 */       char c = val.charAt(x);
/* 218 */       if (x < len - 2 && c == '{' && '}' == val.charAt(x + 2)) {
/*     */         
/* 220 */         String varVal = vars.get(String.valueOf(val.charAt(x + 1)));
/* 221 */         if (varVal != null) {
/* 222 */           ret.append(varVal);
/*     */         }
/* 224 */         x += 2;
/*     */       } else {
/* 226 */         ret.append(c);
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     return ret.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Mapping<E>
/*     */     implements Serializable
/*     */   {
/*     */     private final String original;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Object pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final E config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mapping(String original, Object pattern, E config) {
/* 262 */       this.original = original;
/* 263 */       this.pattern = pattern;
/* 264 */       this.config = config;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getPattern() {
/* 273 */       return this.pattern;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public E getTarget() {
/* 282 */       return this.config;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOriginalPattern() {
/* 291 */       return this.original;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\impl\AbstractMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */