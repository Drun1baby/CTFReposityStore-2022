/*     */ package com.opensymphony.xwork2.config.entities;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Located;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultTypeConfig
/*     */   extends Located
/*     */   implements Serializable
/*     */ {
/*     */   protected String className;
/*     */   protected String name;
/*     */   protected String defaultResultParam;
/*     */   protected Map<String, String> params;
/*     */   
/*     */   protected ResultTypeConfig(String name, String className) {
/*  49 */     this.name = name;
/*  50 */     this.className = className;
/*  51 */     this.params = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   protected ResultTypeConfig(ResultTypeConfig orig) {
/*  55 */     this.name = orig.name;
/*  56 */     this.className = orig.className;
/*  57 */     this.defaultResultParam = orig.defaultResultParam;
/*  58 */     this.params = new LinkedHashMap<>(orig.params);
/*  59 */     this.location = orig.location;
/*     */   }
/*     */   
/*     */   public String getDefaultResultParam() {
/*  63 */     return this.defaultResultParam;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  67 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  71 */     return this.name;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParams() {
/*  75 */     return Collections.unmodifiableMap(this.params);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  80 */     if (this == o) return true; 
/*  81 */     if (o == null || getClass() != o.getClass()) return false;
/*     */     
/*  83 */     ResultTypeConfig that = (ResultTypeConfig)o;
/*     */     
/*  85 */     if ((this.className != null) ? !this.className.equals(that.className) : (that.className != null)) return false; 
/*  86 */     if ((this.name != null) ? !this.name.equals(that.name) : (that.name != null)) return false; 
/*  87 */     if ((this.params != null) ? !this.params.equals(that.params) : (that.params != null)) return false;
/*     */     
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  95 */     int result = (this.className != null) ? this.className.hashCode() : 0;
/*  96 */     result = 29 * result + ((this.name != null) ? this.name.hashCode() : 0);
/*  97 */     result = 29 * result + ((this.params != null) ? this.params.hashCode() : 0);
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return "ResultTypeConfig: [" + this.name + "] => [" + this.className + "] " + "with defaultParam [" + this.defaultResultParam + "] with params " + this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     protected ResultTypeConfig target;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(String name, String className) {
/* 116 */       this.target = new ResultTypeConfig(name, className);
/*     */     }
/*     */     
/*     */     public Builder(ResultTypeConfig orig) {
/* 120 */       this.target = new ResultTypeConfig(orig);
/*     */     }
/*     */     
/*     */     public Builder name(String name) {
/* 124 */       this.target.name = name;
/* 125 */       return this;
/*     */     }
/*     */     
/*     */     public Builder className(String name) {
/* 129 */       this.target.className = name;
/* 130 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParam(String name, String value) {
/* 134 */       this.target.params.put(name, value);
/* 135 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addParams(Map<String, String> params) {
/* 139 */       this.target.params.putAll(params);
/* 140 */       return this;
/*     */     }
/*     */     
/*     */     public Builder defaultResultParam(String defaultResultParam) {
/* 144 */       this.target.defaultResultParam = defaultResultParam;
/* 145 */       return this;
/*     */     }
/*     */     
/*     */     public Builder location(Location loc) {
/* 149 */       this.target.location = loc;
/* 150 */       return this;
/*     */     }
/*     */     
/*     */     public ResultTypeConfig build() {
/* 154 */       ResultTypeConfig result = this.target;
/* 155 */       this.target = new ResultTypeConfig(this.target);
/* 156 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\config\entities\ResultTypeConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */