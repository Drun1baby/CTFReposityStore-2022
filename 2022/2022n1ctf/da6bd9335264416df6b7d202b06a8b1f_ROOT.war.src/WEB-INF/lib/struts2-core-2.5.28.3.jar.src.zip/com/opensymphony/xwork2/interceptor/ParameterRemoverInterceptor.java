/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ import org.apache.struts2.dispatcher.Parameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterRemoverInterceptor
/*     */   extends AbstractInterceptor
/*     */ {
/*  86 */   private static final Logger LOG = LogManager.getLogger(ParameterRemoverInterceptor.class);
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*  90 */   private Set<String> paramNames = Collections.emptySet();
/*  91 */   private Set<String> paramValues = Collections.emptySet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 102 */     if (!(invocation.getAction() instanceof NoParameters) && null != this.paramNames) {
/*     */       
/* 104 */       ActionContext ac = invocation.getInvocationContext();
/* 105 */       HttpParameters parameters = ac.getParameters();
/*     */       
/* 107 */       if (parameters != null) {
/* 108 */         for (String removeName : this.paramNames) {
/*     */           try {
/* 110 */             Parameter parameter = parameters.get(removeName);
/* 111 */             if (parameter.isDefined() && this.paramValues.contains(parameter.getValue())) {
/* 112 */               parameters.remove(removeName);
/*     */             }
/* 114 */           } catch (Exception e) {
/* 115 */             LOG.error("Failed to convert parameter to string", e);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 120 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParamNames(String paramNames) {
/* 129 */     this.paramNames = TextParseUtil.commaDelimitedStringToSet(paramNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParamValues(String paramValues) {
/* 139 */     this.paramValues = TextParseUtil.commaDelimitedStringToSet(paramValues);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ParameterRemoverInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */