/*    */ package com.opensymphony.xwork2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.conversion.TypeConverter;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultConverterFactory
/*    */   implements ConverterFactory
/*    */ {
/* 34 */   private static final Logger LOG = LogManager.getLogger(DefaultConverterFactory.class);
/*    */   
/*    */   private Container container;
/*    */   
/*    */   @Inject
/*    */   public void setContainer(Container container) {
/* 40 */     this.container = container;
/*    */   }
/*    */   
/*    */   public TypeConverter buildConverter(Class<? extends TypeConverter> converterClass, Map<String, Object> extraContext) throws Exception {
/* 44 */     LOG.debug("Creating converter of type [{}]", converterClass.getCanonicalName());
/* 45 */     return (TypeConverter)this.container.getInstance(converterClass);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\factory\DefaultConverterFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */