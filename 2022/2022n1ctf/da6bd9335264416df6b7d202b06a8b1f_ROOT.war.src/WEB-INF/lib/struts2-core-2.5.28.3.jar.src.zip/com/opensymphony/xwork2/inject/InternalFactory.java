package com.opensymphony.xwork2.inject;

import java.io.Serializable;

interface InternalFactory<T> extends Serializable {
  T create(InternalContext paramInternalContext);
  
  Class<? extends T> type();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\inject\InternalFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */