/*    */ package com.opensymphony.xwork2.util.classloader;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FileResourceStore
/*    */   extends AbstractResourceStore
/*    */ {
/* 33 */   private static final Logger LOG = LogManager.getLogger(FileResourceStore.class);
/*    */   
/*    */   public FileResourceStore(File file) {
/* 36 */     super(file);
/*    */   }
/*    */   
/*    */   public byte[] read(String pResourceName) {
/* 40 */     FileInputStream fis = null;
/*    */     try {
/* 42 */       File file = getFile(pResourceName);
/* 43 */       byte[] data = new byte[(int)file.length()];
/* 44 */       fis = new FileInputStream(file);
/* 45 */       fis.read(data);
/*    */       
/* 47 */       return data;
/* 48 */     } catch (Exception e) {
/* 49 */       LOG.debug("Unable to read file [{}]", pResourceName, e);
/* 50 */       return null;
/*    */     } finally {
/* 52 */       closeQuietly(fis);
/*    */     } 
/*    */   }
/*    */   
/*    */   private File getFile(String pResourceName) {
/* 57 */     String fileName = pResourceName.replace('/', File.separatorChar);
/* 58 */     return new File(this.file, fileName);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\classloader\FileResourceStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */