/*     */ package com.opensymphony.xwork2.util.location;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationImpl
/*     */   implements Location, Serializable
/*     */ {
/*     */   private final String uri;
/*     */   private final int line;
/*     */   private final int column;
/*     */   private final String description;
/*  42 */   static final LocationImpl UNKNOWN = new LocationImpl(null, null, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationImpl(String description, String uri) {
/*  51 */     this(description, uri, -1, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationImpl(String description, String uri, int line, int column) {
/*  63 */     if (StringUtils.isEmpty(uri)) {
/*  64 */       this.uri = null;
/*  65 */       this.line = -1;
/*  66 */       this.column = -1;
/*     */     } else {
/*  68 */       this.uri = uri;
/*  69 */       this.line = line;
/*  70 */       this.column = column;
/*     */     } 
/*  72 */     this.description = StringUtils.trimToNull(description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationImpl(Location location) {
/*  81 */     this(location.getDescription(), location.getURI(), location.getLineNumber(), location.getColumnNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationImpl(String description, Location location) {
/*  91 */     this(description, location.getURI(), location.getLineNumber(), location.getColumnNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocationImpl get(Location location) {
/* 105 */     if (location instanceof LocationImpl)
/* 106 */       return (LocationImpl)location; 
/* 107 */     if (location == null) {
/* 108 */       return UNKNOWN;
/*     */     }
/* 110 */     return new LocationImpl(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 120 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getURI() {
/* 129 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 138 */     return this.line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNumber() {
/* 147 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getSnippet(int padding) {
/* 155 */     List<String> snippet = new ArrayList<>();
/* 156 */     if (getLineNumber() > 0) {
/*     */       try {
/* 158 */         InputStream in = (new URL(getURI())).openStream();
/* 159 */         BufferedReader reader = new BufferedReader(new InputStreamReader(in));
/*     */         
/* 161 */         int lineno = 0;
/* 162 */         int errno = getLineNumber();
/*     */         String line;
/* 164 */         while ((line = reader.readLine()) != null) {
/* 165 */           lineno++;
/* 166 */           if (lineno >= errno - padding && lineno <= errno + padding) {
/* 167 */             snippet.add(line);
/*     */           }
/*     */         } 
/* 170 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 174 */     return snippet;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 179 */     if (obj == this) {
/* 180 */       return true;
/*     */     }
/*     */     
/* 183 */     if (obj instanceof Location) {
/* 184 */       Location other = (Location)obj;
/* 185 */       return (this.line == other.getLineNumber() && this.column == other.getColumnNumber() && testEquals(this.uri, other.getURI()) && testEquals(this.description, other.getDescription()));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 195 */     int hash = this.line ^ this.column;
/* 196 */     if (this.uri != null) hash ^= this.uri.hashCode(); 
/* 197 */     if (this.description != null) hash ^= this.description.hashCode();
/*     */     
/* 199 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 204 */     return LocationUtils.toString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object readResolve() {
/* 213 */     return equals(Location.UNKNOWN) ? Location.UNKNOWN : this;
/*     */   }
/*     */   
/*     */   private boolean testEquals(Object object1, Object object2) {
/* 217 */     if (object1 == object2) {
/* 218 */       return true;
/*     */     }
/* 220 */     if (object1 == null || object2 == null) {
/* 221 */       return false;
/*     */     }
/* 223 */     return object1.equals(object2);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\location\LocationImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */