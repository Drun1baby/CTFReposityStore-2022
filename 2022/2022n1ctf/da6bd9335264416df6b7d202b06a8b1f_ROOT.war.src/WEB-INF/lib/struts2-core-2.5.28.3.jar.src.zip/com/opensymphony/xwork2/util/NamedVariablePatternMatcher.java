/*     */ package com.opensymphony.xwork2.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedVariablePatternMatcher
/*     */   implements PatternMatcher<NamedVariablePatternMatcher.CompiledPattern>
/*     */ {
/*     */   public boolean isLiteral(String pattern) {
/*  68 */     return (pattern == null || pattern.indexOf('{') == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompiledPattern compilePattern(String data) {
/*  78 */     StringBuilder regex = new StringBuilder();
/*  79 */     if (data != null && data.length() > 0) {
/*  80 */       List<String> varNames = new ArrayList<>();
/*  81 */       StringBuilder varName = null;
/*  82 */       for (int x = 0; x < data.length(); x++) {
/*  83 */         char c = data.charAt(x);
/*  84 */         switch (c) { case '{':
/*  85 */             varName = new StringBuilder(); break;
/*  86 */           case '}': if (varName == null) {
/*  87 */               throw new IllegalArgumentException("Mismatched braces in pattern");
/*     */             }
/*  89 */             varNames.add(varName.toString());
/*  90 */             regex.append("([^/]+)");
/*  91 */             varName = null; break;
/*     */           default:
/*  93 */             if (varName == null) {
/*  94 */               regex.append(c); break;
/*     */             } 
/*  96 */             varName.append(c);
/*     */             break; }
/*     */       
/*     */       } 
/* 100 */       return new CompiledPattern(Pattern.compile(regex.toString()), varNames);
/*     */     } 
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(Map<String, String> map, String data, CompiledPattern expr) {
/* 116 */     if (data != null && data.length() > 0) {
/* 117 */       Matcher matcher = expr.getPattern().matcher(data);
/* 118 */       if (matcher.matches()) {
/* 119 */         for (int x = 0; x < expr.getVariableNames().size(); x++) {
/* 120 */           map.put(expr.getVariableNames().get(x), matcher.group(x + 1));
/*     */         }
/* 122 */         return true;
/*     */       } 
/*     */     } 
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class CompiledPattern
/*     */   {
/*     */     private Pattern pattern;
/*     */     
/*     */     private List<String> variableNames;
/*     */ 
/*     */     
/*     */     public CompiledPattern(Pattern pattern, List<String> variableNames) {
/* 137 */       this.pattern = pattern;
/* 138 */       this.variableNames = variableNames;
/*     */     }
/*     */     
/*     */     public Pattern getPattern() {
/* 142 */       return this.pattern;
/*     */     }
/*     */     
/*     */     public List<String> getVariableNames() {
/* 146 */       return this.variableNames;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork\\util\NamedVariablePatternMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */