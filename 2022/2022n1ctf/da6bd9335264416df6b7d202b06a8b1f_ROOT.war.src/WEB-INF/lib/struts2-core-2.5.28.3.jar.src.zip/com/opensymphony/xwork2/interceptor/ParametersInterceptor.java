/*     */ package com.opensymphony.xwork2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.security.AcceptedPatternsChecker;
/*     */ import com.opensymphony.xwork2.security.ExcludedPatternsChecker;
/*     */ import com.opensymphony.xwork2.util.ClearableValueStack;
/*     */ import com.opensymphony.xwork2.util.MemberAccessValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextState;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.struts2.dispatcher.HttpParameters;
/*     */ import org.apache.struts2.dispatcher.Parameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParametersInterceptor
/*     */   extends MethodFilterInterceptor
/*     */ {
/*  49 */   private static final Logger LOG = LogManager.getLogger(ParametersInterceptor.class);
/*     */   
/*     */   protected static final int PARAM_NAME_MAX_LENGTH = 100;
/*     */   
/*  53 */   private int paramNameMaxLength = 100;
/*     */   
/*     */   private boolean devMode = false;
/*     */   
/*     */   protected boolean ordered = false;
/*     */   private ValueStackFactory valueStackFactory;
/*     */   private ExcludedPatternsChecker excludedPatterns;
/*     */   private AcceptedPatternsChecker acceptedPatterns;
/*     */   
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/*  64 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   
/*     */   @Inject("devMode")
/*     */   public void setDevMode(String mode) {
/*  69 */     this.devMode = BooleanUtils.toBoolean(mode);
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setExcludedPatterns(ExcludedPatternsChecker excludedPatterns) {
/*  74 */     this.excludedPatterns = excludedPatterns;
/*     */   }
/*     */   
/*     */   @Inject
/*     */   public void setAcceptedPatterns(AcceptedPatternsChecker acceptedPatterns) {
/*  79 */     this.acceptedPatterns = acceptedPatterns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParamNameMaxLength(int paramNameMaxLength) {
/*  89 */     this.paramNameMaxLength = paramNameMaxLength;
/*     */   }
/*     */   
/*     */   private static int countOGNLCharacters(String s) {
/*  93 */     int count = 0;
/*  94 */     for (int i = s.length() - 1; i >= 0; i--) {
/*  95 */       char c = s.charAt(i);
/*  96 */       if (c == '.' || c == '[') count++; 
/*     */     } 
/*  98 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   static final Comparator<String> rbCollator = new Comparator<String>() {
/*     */       public int compare(String s1, String s2) {
/* 106 */         int l1 = ParametersInterceptor.countOGNLCharacters(s1);
/* 107 */         int l2 = ParametersInterceptor.countOGNLCharacters(s2);
/* 108 */         return (l1 < l2) ? -1 : ((l2 < l1) ? 1 : s1.compareTo(s2));
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   public String doIntercept(ActionInvocation invocation) throws Exception {
/* 115 */     Object action = invocation.getAction();
/* 116 */     if (!(action instanceof NoParameters)) {
/* 117 */       ActionContext ac = invocation.getInvocationContext();
/* 118 */       HttpParameters parameters = retrieveParameters(ac);
/*     */       
/* 120 */       if (LOG.isDebugEnabled()) {
/* 121 */         LOG.debug("Setting params {}", getParameterLogMap(parameters));
/*     */       }
/*     */       
/* 124 */       if (parameters != null) {
/* 125 */         Map<String, Object> contextMap = ac.getContextMap();
/*     */         try {
/* 127 */           ReflectionContextState.setCreatingNullObjects(contextMap, true);
/* 128 */           ReflectionContextState.setDenyMethodExecution(contextMap, true);
/* 129 */           ReflectionContextState.setReportingConversionErrors(contextMap, true);
/*     */           
/* 131 */           ValueStack stack = ac.getValueStack();
/* 132 */           setParameters(action, stack, parameters);
/*     */         } finally {
/* 134 */           ReflectionContextState.setCreatingNullObjects(contextMap, false);
/* 135 */           ReflectionContextState.setDenyMethodExecution(contextMap, false);
/* 136 */           ReflectionContextState.setReportingConversionErrors(contextMap, false);
/*     */         } 
/*     */       } 
/*     */     } 
/* 140 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpParameters retrieveParameters(ActionContext ac) {
/* 150 */     return ac.getParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addParametersToContext(ActionContext ac, Map<String, ?> newParams) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setParameters(Object action, ValueStack stack, HttpParameters parameters) {
/*     */     HttpParameters params;
/*     */     Map<String, Parameter> acceptableParameters;
/* 170 */     if (this.ordered) {
/* 171 */       params = HttpParameters.create().withComparator(getOrderedComparator()).withParent(parameters).build();
/* 172 */       acceptableParameters = new TreeMap<>(getOrderedComparator());
/*     */     } else {
/* 174 */       params = HttpParameters.create().withParent(parameters).build();
/* 175 */       acceptableParameters = new TreeMap<>();
/*     */     } 
/*     */     
/* 178 */     for (Map.Entry<String, Parameter> entry : (Iterable<Map.Entry<String, Parameter>>)params.entrySet()) {
/* 179 */       String parameterName = entry.getKey();
/*     */       
/* 181 */       if (isAcceptableParameter(parameterName, action)) {
/* 182 */         acceptableParameters.put(parameterName, entry.getValue());
/*     */       }
/*     */     } 
/*     */     
/* 186 */     ValueStack newStack = this.valueStackFactory.createValueStack(stack);
/* 187 */     boolean clearableStack = newStack instanceof ClearableValueStack;
/* 188 */     if (clearableStack) {
/*     */ 
/*     */       
/* 191 */       ((ClearableValueStack)newStack).clearContextValues();
/* 192 */       Map<String, Object> context = newStack.getContext();
/* 193 */       ReflectionContextState.setCreatingNullObjects(context, true);
/* 194 */       ReflectionContextState.setDenyMethodExecution(context, true);
/* 195 */       ReflectionContextState.setReportingConversionErrors(context, true);
/*     */ 
/*     */       
/* 198 */       context.put("com.opensymphony.xwork2.ActionContext.locale", stack.getContext().get("com.opensymphony.xwork2.ActionContext.locale"));
/*     */     } 
/*     */     
/* 201 */     boolean memberAccessStack = newStack instanceof MemberAccessValueStack;
/* 202 */     if (memberAccessStack) {
/*     */ 
/*     */       
/* 205 */       MemberAccessValueStack accessValueStack = (MemberAccessValueStack)newStack;
/* 206 */       accessValueStack.setAcceptProperties(this.acceptedPatterns.getAcceptedPatterns());
/* 207 */       accessValueStack.setExcludeProperties(this.excludedPatterns.getExcludedPatterns());
/*     */     } 
/*     */     
/* 210 */     for (Map.Entry<String, Parameter> entry : acceptableParameters.entrySet()) {
/* 211 */       String name = entry.getKey();
/* 212 */       Parameter value = entry.getValue();
/*     */       try {
/* 214 */         newStack.setParameter(name, value.getObject());
/* 215 */       } catch (RuntimeException e) {
/* 216 */         if (this.devMode) {
/* 217 */           notifyDeveloperParameterException(action, name, e.getMessage());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (clearableStack && stack.getContext() != null && newStack.getContext() != null) {
/* 223 */       stack.getContext().put("com.opensymphony.xwork2.ActionContext.conversionErrors", newStack.getContext().get("com.opensymphony.xwork2.ActionContext.conversionErrors"));
/*     */     }
/* 225 */     addParametersToContext(ActionContext.getContext(), acceptableParameters);
/*     */   }
/*     */   
/*     */   protected void notifyDeveloperParameterException(Object action, String property, String message) {
/* 229 */     String developerNotification = "Unexpected Exception caught setting '" + property + "' on '" + action.getClass() + ": " + message;
/* 230 */     if (action instanceof TextProvider) {
/* 231 */       TextProvider tp = (TextProvider)action;
/* 232 */       developerNotification = tp.getText("devmode.notification", "Developer Notification:\n{0}", new String[] { developerNotification });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     LOG.error(developerNotification);
/*     */     
/* 240 */     if (action instanceof ValidationAware) {
/*     */       
/* 242 */       Collection<String> messages = ((ValidationAware)action).getActionMessages();
/* 243 */       messages.add(message);
/* 244 */       ((ValidationAware)action).setActionMessages(messages);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAcceptableParameter(String name, Object action) {
/* 256 */     ParameterNameAware parameterNameAware = (action instanceof ParameterNameAware) ? (ParameterNameAware)action : null;
/* 257 */     return (acceptableName(name) && (parameterNameAware == null || parameterNameAware.acceptableParameterName(name)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Comparator<String> getOrderedComparator() {
/* 268 */     return rbCollator;
/*     */   }
/*     */   
/*     */   protected String getParameterLogMap(HttpParameters parameters) {
/* 272 */     if (parameters == null) {
/* 273 */       return "NONE";
/*     */     }
/*     */     
/* 276 */     StringBuilder logEntry = new StringBuilder();
/* 277 */     for (Map.Entry<String, Parameter> entry : (Iterable<Map.Entry<String, Parameter>>)parameters.entrySet()) {
/* 278 */       logEntry.append(entry.getKey());
/* 279 */       logEntry.append(" => ");
/* 280 */       logEntry.append(((Parameter)entry.getValue()).getValue());
/* 281 */       logEntry.append(" ");
/*     */     } 
/*     */     
/* 284 */     return logEntry.toString();
/*     */   }
/*     */   
/*     */   protected boolean acceptableName(String name) {
/* 288 */     boolean accepted = (isWithinLengthLimit(name) && !isExcluded(name) && isAccepted(name));
/* 289 */     if (this.devMode && accepted) {
/* 290 */       LOG.debug("Parameter [{}] was accepted and will be appended to action!", name);
/*     */     }
/* 292 */     return accepted;
/*     */   }
/*     */   
/*     */   protected boolean isWithinLengthLimit(String name) {
/* 296 */     boolean matchLength = (name.length() <= this.paramNameMaxLength);
/* 297 */     if (!matchLength) {
/* 298 */       if (this.devMode) {
/* 299 */         LOG.warn("Parameter [{}] is too long, allowed length is [{}]. Use Interceptor Parameter Overriding to override the limit, see more at\nhttps://struts.apache.org/core-developers/interceptors.html#interceptor-parameter-overriding", name, Integer.valueOf(this.paramNameMaxLength));
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 304 */         LOG.warn("Parameter [{}] is too long, allowed length is [{}]", name, Integer.valueOf(this.paramNameMaxLength));
/*     */       } 
/*     */     }
/* 307 */     return matchLength;
/*     */   }
/*     */   
/*     */   protected boolean isAccepted(String paramName) {
/* 311 */     AcceptedPatternsChecker.IsAccepted result = this.acceptedPatterns.isAccepted(paramName);
/* 312 */     if (result.isAccepted())
/* 313 */       return true; 
/* 314 */     if (this.devMode) {
/* 315 */       LOG.warn("Parameter [{}] didn't match accepted pattern [{}]! See Accepted / Excluded patterns at\nhttps://struts.apache.org/security/#accepted--excluded-patterns", paramName, result.getAcceptedPattern());
/*     */     }
/*     */     else {
/*     */       
/* 319 */       LOG.debug("Parameter [{}] didn't match accepted pattern [{}]!", paramName, result.getAcceptedPattern());
/*     */     } 
/* 321 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isExcluded(String paramName) {
/* 325 */     ExcludedPatternsChecker.IsExcluded result = this.excludedPatterns.isExcluded(paramName);
/* 326 */     if (result.isExcluded()) {
/* 327 */       if (this.devMode) {
/* 328 */         LOG.warn("Parameter [{}] matches excluded pattern [{}]! See Accepted / Excluded patterns at\nhttps://struts.apache.org/security/#accepted--excluded-patterns", paramName, result.getExcludedPattern());
/*     */       }
/*     */       else {
/*     */         
/* 332 */         LOG.debug("Parameter [{}] matches excluded pattern [{}]!", paramName, result.getExcludedPattern());
/*     */       } 
/* 334 */       return true;
/*     */     } 
/* 336 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOrdered() {
/* 345 */     return this.ordered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrdered(boolean ordered) {
/* 354 */     this.ordered = ordered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAcceptParamNames(String commaDelim) {
/* 368 */     this.acceptedPatterns.setAcceptedPatterns(commaDelim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcludeParams(String commaDelim) {
/* 378 */     this.excludedPatterns.setExcludedPatterns(commaDelim);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\struts2-core-2.5.28.3.jar!\com\opensymphony\xwork2\interceptor\ParametersInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */