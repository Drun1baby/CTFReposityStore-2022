/*    */ package javax.servlet.jsp.jstl.sql;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultSupport
/*    */ {
/*    */   public static Result toResult(ResultSet rs) {
/*    */     try {
/* 52 */       return new ResultImpl(rs, -1, -1);
/* 53 */     } catch (SQLException ex) {
/* 54 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Result toResult(ResultSet rs, int maxRows) {
/*    */     try {
/* 70 */       return new ResultImpl(rs, -1, maxRows);
/* 71 */     } catch (SQLException ex) {
/* 72 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\sql\ResultSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */