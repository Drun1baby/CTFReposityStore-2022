package javax.servlet.jsp.jstl.sql;

public interface SQLExecutionTag {
  void addSQLParameter(Object paramObject);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\sql\SQLExecutionTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */