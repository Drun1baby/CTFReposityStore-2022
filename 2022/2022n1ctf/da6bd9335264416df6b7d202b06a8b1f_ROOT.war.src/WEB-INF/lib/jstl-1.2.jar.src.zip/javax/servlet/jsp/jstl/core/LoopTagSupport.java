/*     */ package javax.servlet.jsp.jstl.core;
/*     */ 
/*     */ import javax.el.ELException;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.VariableMapper;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.IterationTag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoopTagSupport
/*     */   extends TagSupport
/*     */   implements LoopTag, IterationTag, TryCatchFinally
/*     */ {
/*     */   protected int begin;
/*     */   protected int end;
/*     */   protected int step;
/*     */   protected boolean beginSpecified;
/*     */   protected boolean endSpecified;
/*     */   protected boolean stepSpecified;
/*     */   protected String itemId;
/*     */   protected String statusId;
/*     */   protected ValueExpression deferredExpression;
/*     */   private LoopTagStatus status;
/*     */   private Object item;
/*     */   private int index;
/*     */   private int count;
/*     */   private boolean last;
/*     */   private IteratedExpression iteratedExpression;
/*     */   
/*     */   public LoopTagSupport() {
/* 173 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 235 */     super.release();
/* 236 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 243 */     if (this.end != -1 && this.begin > this.end)
/*     */     {
/* 245 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 249 */     this.index = 0;
/* 250 */     this.count = 1;
/* 251 */     this.last = false;
/* 252 */     this.iteratedExpression = null;
/* 253 */     this.deferredExpression = null;
/*     */ 
/*     */     
/* 256 */     prepare();
/*     */ 
/*     */     
/* 259 */     discardIgnoreSubset(this.begin);
/*     */ 
/*     */     
/* 262 */     if (hasNext()) {
/*     */       
/* 264 */       this.item = next();
/*     */     } else {
/* 266 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     discard(this.step - 1);
/*     */ 
/*     */     
/* 275 */     exposeVariables();
/* 276 */     calibrateLast();
/* 277 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doAfterBody() throws JspException {
/* 287 */     this.index += this.step - 1;
/*     */ 
/*     */     
/* 290 */     this.count++;
/*     */ 
/*     */     
/* 293 */     if (hasNext() && !atEnd()) {
/* 294 */       this.index++;
/* 295 */       this.item = next();
/*     */     } else {
/* 297 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     discard(this.step - 1);
/*     */ 
/*     */     
/* 306 */     exposeVariables();
/* 307 */     calibrateLast();
/* 308 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/* 323 */     unExposeVariables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable t) throws Throwable {
/* 330 */     throw t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCurrent() {
/* 350 */     return this.item;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoopTagStatus getLoopStatus() {
/*     */     class Status
/*     */       implements LoopTagStatus
/*     */     {
/*     */       public Object getCurrent() {
/* 378 */         return LoopTagSupport.this.getCurrent();
/*     */       }
/*     */       public int getIndex() {
/* 381 */         return LoopTagSupport.this.index + LoopTagSupport.this.begin;
/*     */       }
/*     */       public int getCount() {
/* 384 */         return LoopTagSupport.this.count;
/*     */       }
/*     */       public boolean isFirst() {
/* 387 */         return (LoopTagSupport.this.index == 0);
/*     */       }
/*     */       public boolean isLast() {
/* 390 */         return LoopTagSupport.this.last;
/*     */       }
/*     */       public Integer getBegin() {
/* 393 */         if (LoopTagSupport.this.beginSpecified) {
/* 394 */           return new Integer(LoopTagSupport.this.begin);
/*     */         }
/* 396 */         return null;
/*     */       }
/*     */       public Integer getEnd() {
/* 399 */         if (LoopTagSupport.this.endSpecified) {
/* 400 */           return new Integer(LoopTagSupport.this.end);
/*     */         }
/* 402 */         return null;
/*     */       }
/*     */       public Integer getStep() {
/* 405 */         if (LoopTagSupport.this.stepSpecified) {
/* 406 */           return new Integer(LoopTagSupport.this.step);
/*     */         }
/* 408 */         return null;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 417 */     if (this.status == null) {
/* 418 */       this.status = new Status();
/*     */     }
/* 420 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDelims() {
/* 428 */     return ",";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String id) {
/* 449 */     this.itemId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVarStatus(String statusId) {
/* 459 */     this.statusId = statusId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateBegin() throws JspTagException {
/* 477 */     if (this.begin < 0) {
/* 478 */       throw new JspTagException("'begin' < 0");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateEnd() throws JspTagException {
/* 486 */     if (this.end < 0) {
/* 487 */       throw new JspTagException("'end' < 0");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateStep() throws JspTagException {
/* 495 */     if (this.step < 1) {
/* 496 */       throw new JspTagException("'step' <= 0");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 506 */     this.index = 0;
/* 507 */     this.count = 1;
/* 508 */     this.status = null;
/* 509 */     this.item = null;
/* 510 */     this.last = false;
/* 511 */     this.beginSpecified = false;
/* 512 */     this.endSpecified = false;
/* 513 */     this.stepSpecified = false;
/*     */ 
/*     */     
/* 516 */     this.begin = 0;
/* 517 */     this.end = -1;
/* 518 */     this.step = 1;
/* 519 */     this.itemId = null;
/* 520 */     this.statusId = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calibrateLast() throws JspTagException {
/* 529 */     this.last = (!hasNext() || atEnd() || (this.end != -1 && this.begin + this.index + this.step > this.end));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void exposeVariables() throws JspTagException {
/* 557 */     if (this.itemId != null)
/* 558 */       if (getCurrent() == null) {
/* 559 */         this.pageContext.removeAttribute(this.itemId, 1);
/* 560 */       } else if (this.deferredExpression != null) {
/* 561 */         VariableMapper vm = this.pageContext.getELContext().getVariableMapper();
/*     */         
/* 563 */         if (vm != null) {
/* 564 */           ValueExpression ve = getVarExpression(this.deferredExpression);
/* 565 */           vm.setVariable(this.itemId, ve);
/*     */         } 
/*     */       } else {
/* 568 */         this.pageContext.setAttribute(this.itemId, getCurrent());
/*     */       }  
/* 570 */     if (this.statusId != null) {
/* 571 */       if (getLoopStatus() == null) {
/* 572 */         this.pageContext.removeAttribute(this.statusId, 1);
/*     */       } else {
/* 574 */         this.pageContext.setAttribute(this.statusId, getLoopStatus());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unExposeVariables() {
/* 585 */     if (this.itemId != null) {
/* 586 */       this.pageContext.removeAttribute(this.itemId, 1);
/* 587 */       VariableMapper vm = this.pageContext.getELContext().getVariableMapper();
/* 588 */       if (vm != null)
/* 589 */         vm.setVariable(this.itemId, null); 
/*     */     } 
/* 591 */     if (this.statusId != null) {
/* 592 */       this.pageContext.removeAttribute(this.statusId, 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discard(int n) throws JspTagException {
/* 613 */     int oldIndex = this.index;
/* 614 */     while (n-- > 0 && !atEnd() && hasNext()) {
/* 615 */       this.index++;
/* 616 */       next();
/*     */     } 
/* 618 */     this.index = oldIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discardIgnoreSubset(int n) throws JspTagException {
/* 627 */     while (n-- > 0 && hasNext()) {
/* 628 */       next();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean atEnd() {
/* 638 */     return (this.end != -1 && this.begin + this.index >= this.end);
/*     */   }
/*     */   
/*     */   private ValueExpression getVarExpression(ValueExpression expr) {
/* 642 */     Object o = expr.getValue(this.pageContext.getELContext());
/* 643 */     if (o.getClass().isArray() || o instanceof java.util.List) {
/* 644 */       return new IndexedValueExpression(this.deferredExpression, this.index);
/*     */     }
/*     */     
/* 647 */     if (o instanceof java.util.Collection || o instanceof java.util.Iterator || o instanceof java.util.Enumeration || o instanceof java.util.Map || o instanceof String) {
/*     */ 
/*     */ 
/*     */       
/* 651 */       if (this.iteratedExpression == null) {
/* 652 */         this.iteratedExpression = new IteratedExpression(this.deferredExpression, getDelims());
/*     */       }
/*     */       
/* 655 */       return new IteratedValueExpression(this.iteratedExpression, this.index);
/*     */     } 
/*     */     
/* 658 */     throw new ELException(Resources.getMessage("FOREACH_BAD_ITEMS"));
/*     */   }
/*     */   
/*     */   protected abstract Object next() throws JspTagException;
/*     */   
/*     */   protected abstract boolean hasNext() throws JspTagException;
/*     */   
/*     */   protected abstract void prepare() throws JspTagException;
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\LoopTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */