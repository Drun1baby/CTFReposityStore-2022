/*     */ package javax.servlet.jsp.jstl.core;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Config
/*     */ {
/*     */   public static final String FMT_LOCALE = "javax.servlet.jsp.jstl.fmt.locale";
/*     */   public static final String FMT_FALLBACK_LOCALE = "javax.servlet.jsp.jstl.fmt.fallbackLocale";
/*     */   public static final String FMT_LOCALIZATION_CONTEXT = "javax.servlet.jsp.jstl.fmt.localizationContext";
/*     */   public static final String FMT_TIME_ZONE = "javax.servlet.jsp.jstl.fmt.timeZone";
/*     */   public static final String SQL_DATA_SOURCE = "javax.servlet.jsp.jstl.sql.dataSource";
/*     */   public static final String SQL_MAX_ROWS = "javax.servlet.jsp.jstl.sql.maxRows";
/*     */   private static final String PAGE_SCOPE_SUFFIX = ".page";
/*     */   private static final String REQUEST_SCOPE_SUFFIX = ".request";
/*     */   private static final String SESSION_SCOPE_SUFFIX = ".session";
/*     */   private static final String APPLICATION_SCOPE_SUFFIX = ".application";
/*     */   
/*     */   public static Object get(PageContext pc, String name, int scope) {
/* 109 */     switch (scope) {
/*     */       case 1:
/* 111 */         return pc.getAttribute(name + ".page", scope);
/*     */       case 2:
/* 113 */         return pc.getAttribute(name + ".request", scope);
/*     */       case 3:
/* 115 */         return get(pc.getSession(), name);
/*     */       case 4:
/* 117 */         return pc.getAttribute(name + ".application", scope);
/*     */     } 
/* 119 */     throw new IllegalArgumentException("unknown scope");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object get(ServletRequest request, String name) {
/* 138 */     return request.getAttribute(name + ".request");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object get(HttpSession session, String name) {
/* 157 */     Object ret = null;
/* 158 */     if (session != null) {
/*     */       try {
/* 160 */         ret = session.getAttribute(name + ".session");
/* 161 */       } catch (IllegalStateException ex) {}
/*     */     }
/* 163 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object get(ServletContext context, String name) {
/* 181 */     return context.getAttribute(name + ".application");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set(PageContext pc, String name, Object value, int scope) {
/* 199 */     switch (scope) {
/*     */       case 1:
/* 201 */         pc.setAttribute(name + ".page", value, scope);
/*     */         return;
/*     */       case 2:
/* 204 */         pc.setAttribute(name + ".request", value, scope);
/*     */         return;
/*     */       case 3:
/* 207 */         pc.setAttribute(name + ".session", value, scope);
/*     */         return;
/*     */       case 4:
/* 210 */         pc.setAttribute(name + ".application", value, scope);
/*     */         return;
/*     */     } 
/* 213 */     throw new IllegalArgumentException("unknown scope");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set(ServletRequest request, String name, Object value) {
/* 231 */     request.setAttribute(name + ".request", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set(HttpSession session, String name, Object value) {
/* 248 */     session.setAttribute(name + ".session", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set(ServletContext context, String name, Object value) {
/* 265 */     context.setAttribute(name + ".application", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(PageContext pc, String name, int scope) {
/* 282 */     switch (scope) {
/*     */       case 1:
/* 284 */         pc.removeAttribute(name + ".page", scope);
/*     */         return;
/*     */       case 2:
/* 287 */         pc.removeAttribute(name + ".request", scope);
/*     */         return;
/*     */       case 3:
/* 290 */         pc.removeAttribute(name + ".session", scope);
/*     */         return;
/*     */       case 4:
/* 293 */         pc.removeAttribute(name + ".application", scope);
/*     */         return;
/*     */     } 
/* 296 */     throw new IllegalArgumentException("unknown scope");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(ServletRequest request, String name) {
/* 312 */     request.removeAttribute(name + ".request");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(HttpSession session, String name) {
/* 327 */     session.removeAttribute(name + ".session");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(ServletContext context, String name) {
/* 342 */     context.removeAttribute(name + ".application");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object find(PageContext pc, String name) {
/* 364 */     Object ret = get(pc, name, 1);
/* 365 */     if (ret == null) {
/* 366 */       ret = get(pc, name, 2);
/* 367 */       if (ret == null) {
/* 368 */         if (pc.getSession() != null)
/*     */         {
/* 370 */           ret = get(pc, name, 3);
/*     */         }
/* 372 */         if (ret == null) {
/* 373 */           ret = get(pc, name, 4);
/* 374 */           if (ret == null) {
/* 375 */             ret = pc.getServletContext().getInitParameter(name);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 381 */     return ret;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\Config.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */