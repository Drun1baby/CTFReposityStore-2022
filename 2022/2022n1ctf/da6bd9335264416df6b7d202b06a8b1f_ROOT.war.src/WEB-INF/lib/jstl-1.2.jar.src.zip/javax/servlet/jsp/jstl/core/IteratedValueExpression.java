/*    */ package javax.servlet.jsp.jstl.core;
/*    */ 
/*    */ import javax.el.ELContext;
/*    */ import javax.el.ValueExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IteratedValueExpression
/*    */   extends ValueExpression
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final int i;
/*    */   protected final IteratedExpression iteratedExpression;
/*    */   
/*    */   public IteratedValueExpression(IteratedExpression iteratedExpr, int i) {
/* 40 */     this.i = i;
/* 41 */     this.iteratedExpression = iteratedExpr;
/*    */   }
/*    */   
/*    */   public Object getValue(ELContext context) {
/* 45 */     return this.iteratedExpression.getItem(context, this.i);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(ELContext context, Object value) {}
/*    */   
/*    */   public boolean isReadOnly(ELContext context) {
/* 52 */     return true;
/*    */   }
/*    */   
/*    */   public Class getType(ELContext context) {
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   public Class getExpectedType() {
/* 60 */     return Object.class;
/*    */   }
/*    */   
/*    */   public String getExpressionString() {
/* 64 */     return this.iteratedExpression.getValueExpression().getExpressionString();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 68 */     return this.iteratedExpression.getValueExpression().equals(obj);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 72 */     return this.iteratedExpression.getValueExpression().hashCode();
/*    */   }
/*    */   
/*    */   public boolean isLiteralText() {
/* 76 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\IteratedValueExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */