package javax.servlet.jsp.jstl.core;

public interface LoopTagStatus {
  Object getCurrent();
  
  int getIndex();
  
  int getCount();
  
  boolean isFirst();
  
  boolean isLast();
  
  Integer getBegin();
  
  Integer getEnd();
  
  Integer getStep();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\LoopTagStatus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */