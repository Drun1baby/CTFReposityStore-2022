/*     */ package javax.servlet.jsp.jstl.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConditionalTagSupport
/*     */   extends TagSupport
/*     */ {
/*     */   private boolean result;
/*     */   private String var;
/*     */   private int scope;
/*     */   
/*     */   protected abstract boolean condition() throws JspTagException;
/*     */   
/*     */   public ConditionalTagSupport() {
/*  80 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  93 */     this.result = condition();
/*     */ 
/*     */     
/*  96 */     exposeVariables();
/*     */ 
/*     */     
/*  99 */     if (this.result) {
/* 100 */       return 1;
/*     */     }
/* 102 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 109 */     super.release();
/* 110 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 131 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 140 */     if (scope.equalsIgnoreCase("page")) {
/* 141 */       this.scope = 1;
/* 142 */     } else if (scope.equalsIgnoreCase("request")) {
/* 143 */       this.scope = 2;
/* 144 */     } else if (scope.equalsIgnoreCase("session")) {
/* 145 */       this.scope = 3;
/* 146 */     } else if (scope.equalsIgnoreCase("application")) {
/* 147 */       this.scope = 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void exposeVariables() {
/* 157 */     if (this.var != null) {
/* 158 */       this.pageContext.setAttribute(this.var, new Boolean(this.result), this.scope);
/*     */     }
/*     */   }
/*     */   
/*     */   private void init() {
/* 163 */     this.result = false;
/* 164 */     this.var = null;
/* 165 */     this.scope = 1;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\core\ConditionalTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */