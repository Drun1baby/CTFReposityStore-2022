/*    */ package org.apache.taglibs.standard.lang.jstl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EqualityOperator
/*    */   extends BinaryOperator
/*    */ {
/*    */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/* 50 */     return Coercions.applyEqualityOperator(pLeft, pRight, this, pLogger);
/*    */   }
/*    */   
/*    */   public abstract boolean apply(boolean paramBoolean, Logger paramLogger);
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\EqualityOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */