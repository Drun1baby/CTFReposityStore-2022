/*     */ package org.apache.taglibs.standard.tag.el.xml;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.xml.ParamSupport;
/*     */ import org.apache.taglibs.standard.tag.el.core.ExpressionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParamTag
/*     */   extends ParamSupport
/*     */ {
/*     */   private String name_;
/*     */   private String value_;
/*     */   
/*     */   public ParamTag() {
/*  54 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  65 */     evaluateExpressions();
/*     */ 
/*     */     
/*  68 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  74 */     super.release();
/*  75 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name_) {
/*  84 */     this.name_ = name_;
/*     */   }
/*     */   
/*     */   public void setValue(String value_) {
/*  88 */     this.value_ = value_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/*  98 */     this.name_ = this.value_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 111 */     this.name = (String)ExpressionUtil.evalNotNull("param", "name", this.name_, String.class, (Tag)this, this.pageContext);
/*     */     
/* 113 */     this.value = ExpressionUtil.evalNotNull("param", "value", this.value_, Object.class, (Tag)this, this.pageContext);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\xml\ParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */