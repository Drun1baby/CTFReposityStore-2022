/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.core.UrlSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlTag
/*    */   extends UrlSupport
/*    */ {
/*    */   public void setValue(String value) throws JspTagException {
/* 46 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(String context) throws JspTagException {
/* 51 */     this.context = context;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\UrlTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */