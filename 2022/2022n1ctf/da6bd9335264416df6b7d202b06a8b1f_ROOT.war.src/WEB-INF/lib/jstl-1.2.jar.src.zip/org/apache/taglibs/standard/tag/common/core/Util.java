/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   private static final String REQUEST = "request";
/*     */   private static final String SESSION = "session";
/*     */   private static final String APPLICATION = "application";
/*     */   private static final String DEFAULT = "default";
/*     */   private static final String SHORT = "short";
/*     */   private static final String MEDIUM = "medium";
/*     */   private static final String LONG = "long";
/*     */   private static final String FULL = "full";
/*     */   public static final int HIGHEST_SPECIAL = 62;
/*  57 */   public static char[][] specialCharactersRepresentation = new char[63][];
/*     */   static {
/*  59 */     specialCharactersRepresentation[38] = "&amp;".toCharArray();
/*  60 */     specialCharactersRepresentation[60] = "&lt;".toCharArray();
/*  61 */     specialCharactersRepresentation[62] = "&gt;".toCharArray();
/*  62 */     specialCharactersRepresentation[34] = "&#034;".toCharArray();
/*  63 */     specialCharactersRepresentation[39] = "&#039;".toCharArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getScope(String scope) {
/*  78 */     int ret = 1;
/*     */     
/*  80 */     if ("request".equalsIgnoreCase(scope)) {
/*  81 */       ret = 2;
/*  82 */     } else if ("session".equalsIgnoreCase(scope)) {
/*  83 */       ret = 3;
/*  84 */     } else if ("application".equalsIgnoreCase(scope)) {
/*  85 */       ret = 4;
/*     */     } 
/*  87 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getStyle(String style, String errCode) throws JspException {
/* 103 */     int ret = 2;
/*     */     
/* 105 */     if (style != null) {
/* 106 */       if ("default".equalsIgnoreCase(style)) {
/* 107 */         ret = 2;
/* 108 */       } else if ("short".equalsIgnoreCase(style)) {
/* 109 */         ret = 3;
/* 110 */       } else if ("medium".equalsIgnoreCase(style)) {
/* 111 */         ret = 2;
/* 112 */       } else if ("long".equalsIgnoreCase(style)) {
/* 113 */         ret = 1;
/* 114 */       } else if ("full".equalsIgnoreCase(style)) {
/* 115 */         ret = 0;
/*     */       } else {
/* 117 */         throw new JspException(Resources.getMessage(errCode, style));
/*     */       } 
/*     */     }
/*     */     
/* 121 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeXml(String buffer) {
/* 139 */     int start = 0;
/* 140 */     int length = buffer.length();
/* 141 */     char[] arrayBuffer = buffer.toCharArray();
/* 142 */     StringBuffer escapedBuffer = null;
/*     */     
/* 144 */     for (int i = 0; i < length; i++) {
/* 145 */       char c = arrayBuffer[i];
/* 146 */       if (c <= '>') {
/* 147 */         char[] escaped = specialCharactersRepresentation[c];
/* 148 */         if (escaped != null) {
/*     */           
/* 150 */           if (start == 0) {
/* 151 */             escapedBuffer = new StringBuffer(length + 5);
/*     */           }
/*     */           
/* 154 */           if (start < i) {
/* 155 */             escapedBuffer.append(arrayBuffer, start, i - start);
/*     */           }
/* 157 */           start = i + 1;
/*     */           
/* 159 */           escapedBuffer.append(escaped);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 164 */     if (start == 0) {
/* 165 */       return buffer;
/*     */     }
/*     */     
/* 168 */     if (start < length) {
/* 169 */       escapedBuffer.append(arrayBuffer, start, length - start);
/*     */     }
/* 171 */     return escapedBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getContentTypeAttribute(String input, String name) {
/* 181 */     int begin, end, index = input.toUpperCase().indexOf(name.toUpperCase());
/* 182 */     if (index == -1) return null; 
/* 183 */     index += name.length();
/* 184 */     index = input.indexOf('=', index);
/* 185 */     if (index == -1) return null; 
/* 186 */     index++;
/* 187 */     input = input.substring(index).trim();
/*     */     
/* 189 */     if (input.charAt(0) == '"') {
/*     */       
/* 191 */       begin = 1;
/* 192 */       end = input.indexOf('"', begin);
/* 193 */       if (end == -1) return null; 
/*     */     } else {
/* 195 */       begin = 0;
/* 196 */       end = input.indexOf(';');
/* 197 */       if (end == -1) end = input.indexOf(' '); 
/* 198 */       if (end == -1) end = input.length(); 
/*     */     } 
/* 200 */     return input.substring(begin, end).trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String URLEncode(String s, String enc) {
/* 216 */     if (s == null) {
/* 217 */       return "null";
/*     */     }
/*     */     
/* 220 */     if (enc == null) {
/* 221 */       enc = "UTF-8";
/*     */     }
/*     */     
/* 224 */     StringBuffer out = new StringBuffer(s.length());
/* 225 */     ByteArrayOutputStream buf = new ByteArrayOutputStream();
/* 226 */     OutputStreamWriter writer = null;
/*     */     try {
/* 228 */       writer = new OutputStreamWriter(buf, enc);
/* 229 */     } catch (UnsupportedEncodingException ex) {
/*     */       
/* 231 */       writer = new OutputStreamWriter(buf);
/*     */     } 
/*     */     
/* 234 */     for (int i = 0; i < s.length(); i++) {
/* 235 */       int c = s.charAt(i);
/* 236 */       if (c == 32) {
/* 237 */         out.append('+');
/* 238 */       } else if (isSafeChar(c)) {
/* 239 */         out.append((char)c);
/*     */       } else {
/*     */         
/*     */         try {
/* 243 */           writer.write(c);
/* 244 */           writer.flush();
/* 245 */         } catch (IOException e) {
/* 246 */           buf.reset();
/*     */         } 
/*     */         
/* 249 */         byte[] ba = buf.toByteArray();
/* 250 */         for (int j = 0; j < ba.length; j++) {
/* 251 */           out.append('%');
/*     */           
/* 253 */           out.append(Character.forDigit(ba[j] >> 4 & 0xF, 16));
/* 254 */           out.append(Character.forDigit(ba[j] & 0xF, 16));
/*     */         } 
/* 256 */         buf.reset();
/*     */       } 
/*     */     } 
/* 259 */     return out.toString();
/*     */   }
/*     */   
/*     */   private static boolean isSafeChar(int c) {
/* 263 */     if (c >= 97 && c <= 122) {
/* 264 */       return true;
/*     */     }
/* 266 */     if (c >= 65 && c <= 90) {
/* 267 */       return true;
/*     */     }
/* 269 */     if (c >= 48 && c <= 57) {
/* 270 */       return true;
/*     */     }
/* 272 */     if (c == 45 || c == 95 || c == 46 || c == 33 || c == 126 || c == 42 || c == 39 || c == 40 || c == 41)
/*     */     {
/* 274 */       return true;
/*     */     }
/* 276 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enumeration getRequestLocales(HttpServletRequest request) {
/* 289 */     Enumeration values = request.getHeaders("accept-language");
/* 290 */     if (values.hasMoreElements())
/*     */     {
/*     */ 
/*     */       
/* 294 */       return request.getLocales();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 299 */     return values;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */