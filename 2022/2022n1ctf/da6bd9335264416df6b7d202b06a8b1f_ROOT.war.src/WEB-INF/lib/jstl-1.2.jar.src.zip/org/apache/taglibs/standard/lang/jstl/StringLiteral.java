/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringLiteral
/*     */   extends Literal
/*     */ {
/*     */   StringLiteral(Object pValue) {
/*  46 */     super(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringLiteral fromToken(String pToken) {
/*  57 */     return new StringLiteral(getValueFromToken(pToken));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringLiteral fromLiteralValue(String pValue) {
/*  67 */     return new StringLiteral(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getValueFromToken(String pToken) {
/*  77 */     StringBuffer buf = new StringBuffer();
/*  78 */     int len = pToken.length() - 1;
/*  79 */     boolean escaping = false;
/*  80 */     for (int i = 1; i < len; i++) {
/*  81 */       char ch = pToken.charAt(i);
/*  82 */       if (escaping) {
/*  83 */         buf.append(ch);
/*  84 */         escaping = false;
/*     */       }
/*  86 */       else if (ch == '\\') {
/*  87 */         escaping = true;
/*     */       } else {
/*     */         
/*  90 */         buf.append(ch);
/*     */       } 
/*     */     } 
/*  93 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringToken(String pValue) {
/* 105 */     if (pValue.indexOf('"') < 0 && pValue.indexOf('\\') < 0)
/*     */     {
/* 107 */       return "\"" + pValue + "\"";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     StringBuffer buf = new StringBuffer();
/* 113 */     buf.append('"');
/* 114 */     int len = pValue.length();
/* 115 */     for (int i = 0; i < len; i++) {
/* 116 */       char ch = pValue.charAt(i);
/* 117 */       if (ch == '\\') {
/* 118 */         buf.append('\\');
/* 119 */         buf.append('\\');
/*     */       }
/* 121 */       else if (ch == '"') {
/* 122 */         buf.append('\\');
/* 123 */         buf.append('"');
/*     */       } else {
/*     */         
/* 126 */         buf.append(ch);
/*     */       } 
/*     */     } 
/* 129 */     buf.append('"');
/* 130 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toIdentifierToken(String pValue) {
/* 143 */     if (isJavaIdentifier(pValue)) {
/* 144 */       return pValue;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 149 */     return toStringToken(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isJavaIdentifier(String pValue) {
/* 160 */     int len = pValue.length();
/* 161 */     if (len == 0) {
/* 162 */       return false;
/*     */     }
/*     */     
/* 165 */     if (!Character.isJavaIdentifierStart(pValue.charAt(0))) {
/* 166 */       return false;
/*     */     }
/*     */     
/* 169 */     for (int i = 1; i < len; i++) {
/* 170 */       if (!Character.isJavaIdentifierPart(pValue.charAt(i))) {
/* 171 */         return false;
/*     */       }
/*     */     } 
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/* 188 */     return toStringToken((String)getValue());
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\StringLiteral.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */