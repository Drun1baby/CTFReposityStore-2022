/*     */ package org.apache.taglibs.standard.lang.jstl.test;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.taglibs.standard.lang.jstl.Evaluator;
/*     */ import org.apache.taglibs.standard.lang.jstl.test.beans.Factory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EvaluationTest
/*     */ {
/*     */   public static void runTests(DataInput pIn, PrintStream pOut) throws IOException {
/*  97 */     PageContext context = createTestContext();
/*     */     
/*     */     while (true) {
/* 100 */       String str = pIn.readLine();
/* 101 */       if (str == null)
/* 102 */         break;  if (str.startsWith("#") || "".equals(str.trim())) {
/*     */         
/* 104 */         pOut.println(str);
/*     */         continue;
/*     */       } 
/* 107 */       String typeStr = pIn.readLine();
/* 108 */       pOut.println("Expression: " + str);
/*     */       
/*     */       try {
/* 111 */         Class cl = parseClassName(typeStr);
/* 112 */         pOut.println("ExpectedType: " + cl);
/* 113 */         Evaluator e = new Evaluator();
/* 114 */         Object val = e.evaluate("test", str, cl, null, context);
/* 115 */         pOut.println("Evaluates to: " + val);
/* 116 */         if (val != null) {
/* 117 */           pOut.println("With type: " + val.getClass().getName());
/*     */         }
/* 119 */         pOut.println();
/*     */       }
/* 121 */       catch (JspException exc) {
/* 122 */         pOut.println("Causes an error: " + exc);
/*     */       }
/* 124 */       catch (ClassNotFoundException exc) {
/* 125 */         pOut.println("Causes an error: " + exc);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class parseClassName(String pClassName) throws ClassNotFoundException {
/* 140 */     String c = pClassName.trim();
/* 141 */     if ("boolean".equals(c)) {
/* 142 */       return boolean.class;
/*     */     }
/* 144 */     if ("byte".equals(c)) {
/* 145 */       return byte.class;
/*     */     }
/* 147 */     if ("char".equals(c)) {
/* 148 */       return char.class;
/*     */     }
/* 150 */     if ("short".equals(c)) {
/* 151 */       return short.class;
/*     */     }
/* 153 */     if ("int".equals(c)) {
/* 154 */       return int.class;
/*     */     }
/* 156 */     if ("long".equals(c)) {
/* 157 */       return long.class;
/*     */     }
/* 159 */     if ("float".equals(c)) {
/* 160 */       return float.class;
/*     */     }
/* 162 */     if ("double".equals(c)) {
/* 163 */       return double.class;
/*     */     }
/*     */     
/* 166 */     return Class.forName(pClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runTests(File pInputFile, File pOutputFile) throws IOException {
/* 180 */     FileInputStream fin = null;
/* 181 */     FileOutputStream fout = null;
/*     */     try {
/* 183 */       fin = new FileInputStream(pInputFile);
/* 184 */       BufferedInputStream bin = new BufferedInputStream(fin);
/* 185 */       DataInputStream din = new DataInputStream(bin);
/*     */       
/*     */       try {
/* 188 */         fout = new FileOutputStream(pOutputFile);
/* 189 */         BufferedOutputStream bout = new BufferedOutputStream(fout);
/* 190 */         PrintStream pout = new PrintStream(bout);
/*     */         
/* 192 */         runTests(din, pout);
/*     */         
/* 194 */         pout.flush();
/*     */       } finally {
/*     */         
/* 197 */         if (fout != null) {
/* 198 */           fout.close();
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 203 */       if (fin != null) {
/* 204 */         fin.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDifferentFiles(DataInput pIn1, DataInput pIn2) throws IOException {
/*     */     while (true) {
/* 220 */       String str1 = pIn1.readLine();
/* 221 */       String str2 = pIn2.readLine();
/* 222 */       if (str1 == null && str2 == null)
/*     */       {
/* 224 */         return false;
/*     */       }
/* 226 */       if (str1 == null || str2 == null)
/*     */       {
/* 228 */         return true;
/*     */       }
/*     */       
/* 231 */       if (!str1.equals(str2)) {
/* 232 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDifferentFiles(File pFile1, File pFile2) throws IOException {
/* 248 */     FileInputStream fin1 = null;
/*     */     try {
/* 250 */       fin1 = new FileInputStream(pFile1);
/* 251 */       BufferedInputStream bin1 = new BufferedInputStream(fin1);
/* 252 */       DataInputStream din1 = new DataInputStream(bin1);
/*     */       
/* 254 */       FileInputStream fin2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 269 */       if (fin1 != null) {
/* 270 */         fin1.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PageContext createTestContext() {
/* 285 */     PageContext ret = new PageContextImpl();
/*     */ 
/*     */     
/* 288 */     ret.setAttribute("val1a", "page-scoped1", 1);
/* 289 */     ret.setAttribute("val1b", "request-scoped1", 2);
/* 290 */     ret.setAttribute("val1c", "session-scoped1", 3);
/* 291 */     ret.setAttribute("val1d", "app-scoped1", 4);
/*     */ 
/*     */ 
/*     */     
/* 295 */     Bean1 b1 = new Bean1();
/* 296 */     b1.setBoolean1(true);
/* 297 */     b1.setByte1((byte)12);
/* 298 */     b1.setShort1((short)-124);
/* 299 */     b1.setChar1('b');
/* 300 */     b1.setInt1(4);
/* 301 */     b1.setLong1(222423L);
/* 302 */     b1.setFloat1(12.4F);
/* 303 */     b1.setDouble1(89.224D);
/* 304 */     b1.setString1("hello");
/* 305 */     b1.setStringArray1(new String[] { "string1", "string2", "string3", "string4" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     List<Integer> list = new ArrayList();
/* 313 */     list.add(new Integer(14));
/* 314 */     list.add("another value");
/* 315 */     list.add(b1.getStringArray1());
/* 316 */     b1.setList1(list);
/*     */ 
/*     */     
/* 319 */     Map<Object, Object> map1 = new HashMap<Object, Object>();
/* 320 */     map1.put("key1", "value1");
/* 321 */     map1.put(new Integer(14), "value2");
/* 322 */     map1.put(new Long(14L), "value3");
/* 323 */     map1.put("recurse", b1);
/* 324 */     b1.setMap1(map1);
/*     */     
/* 326 */     ret.setAttribute("bean1a", b1);
/*     */     
/* 328 */     Bean1 b2 = new Bean1();
/* 329 */     b2.setInt2(new Integer(-224));
/* 330 */     b2.setString2("bean2's string");
/* 331 */     b1.setBean1(b2);
/*     */     
/* 333 */     Bean1 b3 = new Bean1();
/* 334 */     b3.setDouble1(1422.332D);
/* 335 */     b3.setString2("bean3's string");
/* 336 */     b2.setBean2(b3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     ret.setAttribute("pbean1", Factory.createBean1());
/* 342 */     ret.setAttribute("pbean2", Factory.createBean2());
/* 343 */     ret.setAttribute("pbean3", Factory.createBean3());
/* 344 */     ret.setAttribute("pbean4", Factory.createBean4());
/* 345 */     ret.setAttribute("pbean5", Factory.createBean5());
/* 346 */     ret.setAttribute("pbean6", Factory.createBean6());
/* 347 */     ret.setAttribute("pbean7", Factory.createBean7());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 352 */     Map<Object, Object> m = new HashMap<Object, Object>();
/* 353 */     m.put("emptyArray", new Object[0]);
/* 354 */     m.put("nonemptyArray", new Object[] { "abc" });
/* 355 */     m.put("emptyList", new ArrayList());
/*     */     
/* 357 */     List<String> l = new ArrayList();
/* 358 */     l.add("hello");
/* 359 */     m.put("nonemptyList", l);
/*     */     
/* 361 */     m.put("emptyMap", new HashMap<Object, Object>());
/*     */     
/* 363 */     Map<Object, Object> m2 = new HashMap<Object, Object>();
/* 364 */     m2.put("a", "a");
/* 365 */     m.put("nonemptyMap", m2);
/*     */     
/* 367 */     m.put("emptySet", new HashSet());
/*     */     
/* 369 */     Set<String> s = new HashSet();
/* 370 */     s.add("hello");
/* 371 */     m.put("nonemptySet", s);
/*     */     
/* 373 */     ret.setAttribute("emptyTests", m);
/*     */ 
/*     */     
/* 376 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] pArgs) throws IOException {
/* 389 */     if (pArgs.length != 2 && pArgs.length != 3) {
/*     */       
/* 391 */       usage();
/* 392 */       System.exit(1);
/*     */     } 
/*     */     
/* 395 */     File in = new File(pArgs[0]);
/* 396 */     File out = new File(pArgs[1]);
/*     */     
/* 398 */     runTests(in, out);
/*     */     
/* 400 */     if (pArgs.length > 2) {
/* 401 */       File compare = new File(pArgs[2]);
/* 402 */       if (isDifferentFiles(out, compare)) {
/* 403 */         System.out.println("Test failure - output file " + out + " differs from expected output file " + compare);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 409 */         System.out.println("tests passed");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void usage() {
/* 417 */     System.err.println("usage: java org.apache.taglibs.standard.lang.jstl.test.EvaluationTest {input file} {output file} [{compare file}]");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\EvaluationTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */