/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.xpath.XPathVariableResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSTLXPathVariableResolver
/*     */   implements XPathVariableResolver
/*     */ {
/*     */   private PageContext pageContext;
/*     */   private static final String PAGE_NS_URL = "http://java.sun.com/jstl/xpath/page";
/*     */   private static final String REQUEST_NS_URL = "http://java.sun.com/jstl/xpath/request";
/*     */   private static final String SESSION_NS_URL = "http://java.sun.com/jstl/xpath/session";
/*     */   private static final String APP_NS_URL = "http://java.sun.com/jstl/xpath/app";
/*     */   private static final String PARAM_NS_URL = "http://java.sun.com/jstl/xpath/param";
/*     */   private static final String INITPARAM_NS_URL = "http://java.sun.com/jstl/xpath/initParam";
/*     */   private static final String COOKIE_NS_URL = "http://java.sun.com/jstl/xpath/cookie";
/*     */   private static final String HEADER_NS_URL = "http://java.sun.com/jstl/xpath/header";
/*     */   
/*     */   public JSTLXPathVariableResolver(PageContext pc) {
/*  68 */     this.pageContext = pc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveVariable(QName qname) throws NullPointerException {
/*  82 */     Object varObject = null;
/*     */     
/*  84 */     if (qname == null) {
/*  85 */       throw new NullPointerException("Cannot resolve null variable");
/*     */     }
/*     */     
/*  88 */     String namespace = qname.getNamespaceURI();
/*  89 */     String prefix = qname.getPrefix();
/*  90 */     String localName = qname.getLocalPart();
/*     */ 
/*     */     
/*     */     try {
/*  94 */       varObject = getVariableValue(namespace, prefix, localName);
/*  95 */     } catch (UnresolvableException ue) {
/*  96 */       System.out.println("JSTLXpathVariableResolver.resolveVariable threw UnresolvableException: " + ue);
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return varObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getVariableValue(String namespace, String prefix, String localName) throws UnresolvableException {
/* 115 */     if (namespace == null || namespace.equals("")) {
/* 116 */       return notNull(this.pageContext.findAttribute(localName), namespace, localName);
/*     */     }
/*     */ 
/*     */     
/* 120 */     if (namespace.equals("http://java.sun.com/jstl/xpath/page")) {
/* 121 */       return notNull(this.pageContext.getAttribute(localName, 1), namespace, localName);
/*     */     }
/*     */ 
/*     */     
/* 125 */     if (namespace.equals("http://java.sun.com/jstl/xpath/request")) {
/* 126 */       return notNull(this.pageContext.getAttribute(localName, 2), namespace, localName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (namespace.equals("http://java.sun.com/jstl/xpath/session")) {
/* 132 */       return notNull(this.pageContext.getAttribute(localName, 3), namespace, localName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (namespace.equals("http://java.sun.com/jstl/xpath/app")) {
/* 138 */       return notNull(this.pageContext.getAttribute(localName, 4), namespace, localName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 143 */     if (namespace.equals("http://java.sun.com/jstl/xpath/param")) {
/* 144 */       return notNull(this.pageContext.getRequest().getParameter(localName), namespace, localName);
/*     */     }
/*     */ 
/*     */     
/* 148 */     if (namespace.equals("http://java.sun.com/jstl/xpath/initParam")) {
/* 149 */       return notNull(this.pageContext.getServletContext().getInitParameter(localName), namespace, localName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (namespace.equals("http://java.sun.com/jstl/xpath/header")) {
/* 155 */       HttpServletRequest hsr = (HttpServletRequest)this.pageContext.getRequest();
/*     */       
/* 157 */       return notNull(hsr.getHeader(localName), namespace, localName);
/*     */     } 
/*     */ 
/*     */     
/* 161 */     if (namespace.equals("http://java.sun.com/jstl/xpath/cookie")) {
/* 162 */       HttpServletRequest hsr = (HttpServletRequest)this.pageContext.getRequest();
/*     */       
/* 164 */       Cookie[] c = hsr.getCookies();
/* 165 */       for (int i = 0; i < c.length; i++) {
/* 166 */         if (c[i].getName().equals(localName))
/* 167 */           return c[i].getValue(); 
/* 168 */       }  throw new UnresolvableException("$" + namespace + ":" + localName);
/*     */     } 
/* 170 */     throw new UnresolvableException("$" + namespace + ":" + localName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object notNull(Object o, String namespace, String localName) throws UnresolvableException {
/* 180 */     if (o == null) {
/* 181 */       throw new UnresolvableException("$" + ((namespace == null) ? "" : (namespace + ":")) + localName);
/*     */     }
/*     */     
/* 184 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void p(String s) {
/* 191 */     System.out.println("[JSTLXPathVariableResolver] " + s);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\JSTLXPathVariableResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */