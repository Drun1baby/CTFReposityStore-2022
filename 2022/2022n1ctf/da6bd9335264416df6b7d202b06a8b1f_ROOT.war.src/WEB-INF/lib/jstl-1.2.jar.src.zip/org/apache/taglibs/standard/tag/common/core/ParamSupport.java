/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParamSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected String name;
/*     */   protected String value;
/*     */   protected boolean encode = true;
/*     */   
/*     */   public ParamSupport() {
/*  66 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  70 */     this.name = this.value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  78 */     Tag t = findAncestorWithClass((Tag)this, ParamParent.class);
/*  79 */     if (t == null) {
/*  80 */       throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_PARENT"));
/*     */     }
/*     */ 
/*     */     
/*  84 */     if (this.name == null || this.name.equals("")) {
/*  85 */       return 6;
/*     */     }
/*     */     
/*  88 */     ParamParent parent = (ParamParent)t;
/*  89 */     String value = this.value;
/*  90 */     if (value == null)
/*  91 */       if (this.bodyContent == null || this.bodyContent.getString() == null) {
/*  92 */         value = "";
/*     */       } else {
/*  94 */         value = this.bodyContent.getString().trim();
/*     */       }  
/*  96 */     if (this.encode) {
/*     */ 
/*     */       
/*  99 */       String enc = this.pageContext.getResponse().getCharacterEncoding();
/* 100 */       parent.addParameter(Util.URLEncode(this.name, enc), Util.URLEncode(value, enc));
/*     */     } else {
/*     */       
/* 103 */       parent.addParameter(this.name, value);
/*     */     } 
/* 105 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 110 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ParamManager
/*     */   {
/* 127 */     private List names = new LinkedList();
/* 128 */     private List values = new LinkedList();
/*     */ 
/*     */     
/*     */     private boolean done = false;
/*     */ 
/*     */ 
/*     */     
/*     */     public void addParameter(String name, String value) {
/* 136 */       if (this.done)
/* 137 */         throw new IllegalStateException(); 
/* 138 */       if (name != null) {
/* 139 */         this.names.add(name);
/* 140 */         if (value != null) {
/* 141 */           this.values.add(value);
/*     */         } else {
/* 143 */           this.values.add("");
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String aggregateParams(String url) {
/* 156 */       if (this.done)
/* 157 */         throw new IllegalStateException(); 
/* 158 */       this.done = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       StringBuffer newParams = new StringBuffer();
/* 166 */       for (int i = 0; i < this.names.size(); i++) {
/* 167 */         newParams.append((new StringBuilder()).append(this.names.get(i)).append("=").append(this.values.get(i)).toString());
/* 168 */         if (i < this.names.size() - 1) {
/* 169 */           newParams.append("&");
/*     */         }
/*     */       } 
/*     */       
/* 173 */       if (newParams.length() > 0) {
/* 174 */         int questionMark = url.indexOf('?');
/* 175 */         if (questionMark == -1) {
/* 176 */           return url + "?" + newParams;
/*     */         }
/* 178 */         StringBuffer workingUrl = new StringBuffer(url);
/* 179 */         workingUrl.insert(questionMark + 1, newParams + "&");
/* 180 */         return workingUrl.toString();
/*     */       } 
/*     */       
/* 183 */       return url;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\ParamSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */