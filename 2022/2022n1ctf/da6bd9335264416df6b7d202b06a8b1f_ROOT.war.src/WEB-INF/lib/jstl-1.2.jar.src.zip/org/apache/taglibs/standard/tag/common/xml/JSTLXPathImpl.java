/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import com.sun.org.apache.xalan.internal.res.XSLMessages;
/*     */ import com.sun.org.apache.xpath.internal.XPath;
/*     */ import com.sun.org.apache.xpath.internal.XPathContext;
/*     */ import com.sun.org.apache.xpath.internal.jaxp.JAXPExtensionsProvider;
/*     */ import com.sun.org.apache.xpath.internal.jaxp.JAXPPrefixResolver;
/*     */ import com.sun.org.apache.xpath.internal.jaxp.JAXPVariableStack;
/*     */ import com.sun.org.apache.xpath.internal.objects.XObject;
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.xpath.XPath;
/*     */ import javax.xml.xpath.XPathConstants;
/*     */ import javax.xml.xpath.XPathExpression;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import javax.xml.xpath.XPathFunctionException;
/*     */ import javax.xml.xpath.XPathFunctionResolver;
/*     */ import javax.xml.xpath.XPathVariableResolver;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSTLXPathImpl
/*     */   implements XPath
/*     */ {
/*     */   private XPathVariableResolver variableResolver;
/*     */   private XPathFunctionResolver functionResolver;
/*     */   private XPathVariableResolver origVariableResolver;
/*     */   private XPathFunctionResolver origFunctionResolver;
/*  73 */   private NamespaceContext namespaceContext = null;
/*     */   
/*     */   private JAXPPrefixResolver prefixResolver;
/*     */   
/*     */   private boolean featureSecureProcessing = false;
/*     */ 
/*     */   
/*     */   JSTLXPathImpl(XPathVariableResolver vr, XPathFunctionResolver fr) {
/*  81 */     this.origVariableResolver = this.variableResolver = vr;
/*  82 */     this.origFunctionResolver = this.functionResolver = fr;
/*     */   }
/*     */ 
/*     */   
/*     */   JSTLXPathImpl(XPathVariableResolver vr, XPathFunctionResolver fr, boolean featureSecureProcessing) {
/*  87 */     this.origVariableResolver = this.variableResolver = vr;
/*  88 */     this.origFunctionResolver = this.functionResolver = fr;
/*  89 */     this.featureSecureProcessing = featureSecureProcessing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXPathVariableResolver(XPathVariableResolver resolver) {
/*  98 */     if (resolver == null) {
/*  99 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "XPathVariableResolver" });
/*     */ 
/*     */       
/* 102 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 104 */     this.variableResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPathVariableResolver getXPathVariableResolver() {
/* 113 */     return this.variableResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXPathFunctionResolver(XPathFunctionResolver resolver) {
/* 122 */     if (resolver == null) {
/* 123 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "XPathFunctionResolver" });
/*     */ 
/*     */       
/* 126 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 128 */     this.functionResolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPathFunctionResolver getXPathFunctionResolver() {
/* 137 */     return this.functionResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamespaceContext(NamespaceContext nsContext) {
/* 146 */     if (nsContext == null) {
/* 147 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "NamespaceContext" });
/*     */ 
/*     */       
/* 150 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 152 */     this.namespaceContext = nsContext;
/* 153 */     this.prefixResolver = new JAXPPrefixResolver(nsContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamespaceContext getNamespaceContext() {
/* 162 */     return this.namespaceContext;
/*     */   }
/*     */   
/* 165 */   private static Document d = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DocumentBuilder getParser() {
/*     */     try {
/* 180 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 181 */       dbf.setNamespaceAware(true);
/* 182 */       dbf.setValidating(false);
/* 183 */       return dbf.newDocumentBuilder();
/* 184 */     } catch (ParserConfigurationException e) {
/*     */       
/* 186 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Document getDummyDocument() {
/* 193 */     if (d == null) {
/* 194 */       DOMImplementation dim = getParser().getDOMImplementation();
/* 195 */       d = dim.createDocument("http://java.sun.com/jaxp/xpath", "dummyroot", null);
/*     */     } 
/*     */     
/* 198 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private XObject eval(String expression, Object contextItem) throws TransformerException {
/* 204 */     XPath xpath = new XPath(expression, null, this.prefixResolver, 0);
/*     */     
/* 206 */     XPathContext xpathSupport = null;
/* 207 */     if (this.functionResolver != null) {
/* 208 */       JAXPExtensionsProvider jep = new JAXPExtensionsProvider(this.functionResolver, this.featureSecureProcessing);
/*     */ 
/*     */       
/* 211 */       xpathSupport = new XPathContext(jep);
/*     */     } else {
/* 213 */       xpathSupport = new XPathContext();
/*     */     } 
/*     */     
/* 216 */     XObject xobj = null;
/*     */     
/* 218 */     xpathSupport.setVarStack(new JAXPVariableStack(this.variableResolver));
/*     */ 
/*     */     
/* 221 */     if (contextItem instanceof Node) {
/* 222 */       xobj = xpath.execute(xpathSupport, (Node)contextItem, this.prefixResolver);
/*     */     } else {
/*     */       
/* 225 */       xobj = xpath.execute(xpathSupport, -1, this.prefixResolver);
/*     */     } 
/*     */     
/* 228 */     return xobj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String expression, Object item, QName returnType) throws XPathExpressionException {
/* 264 */     if (expression == null) {
/* 265 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "XPath expression" });
/*     */ 
/*     */       
/* 268 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 270 */     if (returnType == null) {
/* 271 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "returnType" });
/*     */ 
/*     */       
/* 274 */       throw new NullPointerException(fmsg);
/*     */     } 
/*     */ 
/*     */     
/* 278 */     if (!isSupported(returnType)) {
/* 279 */       String fmsg = XSLMessages.createXPATHMessage("ER_UNSUPPORTED_RETURN_TYPE", new Object[] { returnType.toString() });
/*     */ 
/*     */       
/* 282 */       throw new IllegalArgumentException(fmsg);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 287 */       XObject resultObject = eval(expression, item);
/* 288 */       return getResultAsType(resultObject, returnType);
/* 289 */     } catch (NullPointerException npe) {
/*     */ 
/*     */ 
/*     */       
/* 293 */       throw new XPathExpressionException(npe);
/* 294 */     } catch (TransformerException te) {
/* 295 */       Throwable nestedException = te.getException();
/* 296 */       if (nestedException instanceof XPathFunctionException) {
/* 297 */         throw (XPathFunctionException)nestedException;
/*     */       }
/*     */ 
/*     */       
/* 301 */       throw new XPathExpressionException(te);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSupported(QName returnType) {
/* 308 */     if (returnType.equals(XPathConstants.STRING) || returnType.equals(XPathConstants.NUMBER) || returnType.equals(XPathConstants.BOOLEAN) || returnType.equals(XPathConstants.NODE) || returnType.equals(XPathConstants.NODESET) || returnType.equals(JSTLXPathConstants.OBJECT))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 315 */       return true;
/*     */     }
/* 317 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getResultAsType(XObject resultObject, QName returnType) throws TransformerException {
/* 323 */     if (returnType.equals(XPathConstants.STRING)) {
/* 324 */       return resultObject.str();
/*     */     }
/*     */     
/* 327 */     if (returnType.equals(XPathConstants.NUMBER)) {
/* 328 */       return new Double(resultObject.num());
/*     */     }
/*     */     
/* 331 */     if (returnType.equals(XPathConstants.BOOLEAN)) {
/* 332 */       return new Boolean(resultObject.bool());
/*     */     }
/*     */     
/* 335 */     if (returnType.equals(XPathConstants.NODESET)) {
/* 336 */       return resultObject.nodelist();
/*     */     }
/*     */     
/* 339 */     if (returnType.equals(XPathConstants.NODE)) {
/* 340 */       NodeIterator ni = resultObject.nodeset();
/*     */       
/* 342 */       return ni.nextNode();
/*     */     } 
/*     */     
/* 345 */     if (returnType.equals(JSTLXPathConstants.OBJECT)) {
/* 346 */       if (resultObject instanceof com.sun.org.apache.xpath.internal.objects.XNodeSet) {
/* 347 */         return resultObject.nodelist();
/*     */       }
/* 349 */       return resultObject.object();
/*     */     } 
/* 351 */     String fmsg = XSLMessages.createXPATHMessage("ER_UNSUPPORTED_RETURN_TYPE", new Object[] { returnType.toString() });
/*     */ 
/*     */     
/* 354 */     throw new IllegalArgumentException(fmsg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String evaluate(String expression, Object item) throws XPathExpressionException {
/* 385 */     return (String)evaluate(expression, item, XPathConstants.STRING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPathExpression compile(String expression) throws XPathExpressionException {
/* 408 */     if (expression == null) {
/* 409 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "XPath expression" });
/*     */ 
/*     */       
/* 412 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 414 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String expression, InputSource source, QName returnType) throws XPathExpressionException {
/* 463 */     if (source == null) {
/* 464 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "source" });
/*     */ 
/*     */       
/* 467 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 469 */     if (expression == null) {
/* 470 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "XPath expression" });
/*     */ 
/*     */       
/* 473 */       throw new NullPointerException(fmsg);
/*     */     } 
/* 475 */     if (returnType == null) {
/* 476 */       String fmsg = XSLMessages.createXPATHMessage("ER_ARG_CANNOT_BE_NULL", new Object[] { "returnType" });
/*     */ 
/*     */       
/* 479 */       throw new NullPointerException(fmsg);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 484 */     if (!isSupported(returnType)) {
/* 485 */       String fmsg = XSLMessages.createXPATHMessage("ER_UNSUPPORTED_RETURN_TYPE", new Object[] { returnType.toString() });
/*     */ 
/*     */       
/* 488 */       throw new IllegalArgumentException(fmsg);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 493 */       Document document = getParser().parse(source);
/*     */       
/* 495 */       XObject resultObject = eval(expression, document);
/* 496 */       return getResultAsType(resultObject, returnType);
/* 497 */     } catch (SAXException e) {
/* 498 */       throw new XPathExpressionException(e);
/* 499 */     } catch (IOException e) {
/* 500 */       throw new XPathExpressionException(e);
/* 501 */     } catch (TransformerException te) {
/* 502 */       Throwable nestedException = te.getException();
/* 503 */       if (nestedException instanceof XPathFunctionException) {
/* 504 */         throw (XPathFunctionException)nestedException;
/*     */       }
/* 506 */       throw new XPathExpressionException(te);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String evaluate(String expression, InputSource source) throws XPathExpressionException {
/* 540 */     return (String)evaluate(expression, source, XPathConstants.STRING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 559 */     this.variableResolver = this.origVariableResolver;
/* 560 */     this.functionResolver = this.origFunctionResolver;
/* 561 */     this.namespaceContext = null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\JSTLXPathImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */