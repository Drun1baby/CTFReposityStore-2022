/*     */ package org.apache.taglibs.standard.tlv;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JstlSqlTLV
/*     */   extends JstlBaseTLV
/*     */ {
/*  49 */   private final String SETDATASOURCE = "setDataSource";
/*  50 */   private final String QUERY = "query";
/*  51 */   private final String UPDATE = "update";
/*  52 */   private final String TRANSACTION = "transaction";
/*  53 */   private final String PARAM = "param";
/*  54 */   private final String DATEPARAM = "dateParam";
/*     */   
/*  56 */   private final String JSP_TEXT = "jsp:text";
/*     */ 
/*     */   
/*  59 */   private final String SQL = "sql";
/*  60 */   private final String DATASOURCE = "dataSource";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationMessage[] validate(String prefix, String uri, PageData page) {
/*  67 */     return validate(3, prefix, uri, page);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultHandler getHandler() {
/*  75 */     return new Handler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Handler
/*     */     extends DefaultHandler
/*     */   {
/*  86 */     private int depth = 0;
/*  87 */     private Stack queryDepths = new Stack();
/*  88 */     private Stack updateDepths = new Stack();
/*  89 */     private Stack transactionDepths = new Stack();
/*  90 */     private String lastElementName = null;
/*     */ 
/*     */     
/*     */     private boolean bodyNecessary = false;
/*     */     
/*     */     private boolean bodyIllegal = false;
/*     */ 
/*     */     
/*     */     public void startElement(String ns, String ln, String qn, Attributes a) {
/*  99 */       if (ln == null) {
/* 100 */         ln = JstlSqlTLV.this.getLocalPart(qn);
/*     */       }
/*     */ 
/*     */       
/* 104 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 108 */       if (this.bodyIllegal) {
/* 109 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */       
/*     */       Set expAtts;
/* 113 */       if (qn.startsWith(JstlSqlTLV.this.prefix + ":") && (expAtts = (Set)JstlSqlTLV.this.config.get(ln)) != null)
/*     */       {
/* 115 */         for (int i = 0; i < a.getLength(); i++) {
/* 116 */           String attName = a.getLocalName(i);
/* 117 */           if (expAtts.contains(attName)) {
/* 118 */             String vMsg = JstlSqlTLV.this.validateExpression(ln, attName, a.getValue(i));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 123 */             if (vMsg != null) {
/* 124 */               JstlSqlTLV.this.fail(vMsg);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 130 */       if (qn.startsWith(JstlSqlTLV.this.prefix + ":") && !JstlSqlTLV.this.hasNoInvalidScope(a)) {
/* 131 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
/*     */       }
/* 133 */       if (qn.startsWith(JstlSqlTLV.this.prefix + ":") && JstlSqlTLV.this.hasEmptyVar(a))
/* 134 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_EMPTY_VAR", qn)); 
/* 135 */       if (qn.startsWith(JstlSqlTLV.this.prefix + ":") && JstlSqlTLV.this.hasDanglingScope(a) && !qn.startsWith(JstlSqlTLV.this.prefix + ":" + "setDataSource"))
/*     */       {
/* 137 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 153 */       if ((JstlSqlTLV.this.isSqlTag(ns, ln, "param") || JstlSqlTLV.this.isSqlTag(ns, ln, "dateParam")) && this.queryDepths.empty() && this.updateDepths.empty())
/*     */       {
/* 155 */         JstlSqlTLV.this.fail(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
/*     */       }
/*     */ 
/*     */       
/* 159 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "query")) {
/* 160 */         this.queryDepths.push(new Integer(this.depth));
/*     */       }
/*     */       
/* 163 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "update")) {
/* 164 */         this.updateDepths.push(new Integer(this.depth));
/*     */       }
/*     */       
/* 167 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "transaction")) {
/* 168 */         this.transactionDepths.push(new Integer(this.depth));
/*     */       }
/*     */ 
/*     */       
/* 172 */       this.bodyIllegal = false;
/* 173 */       this.bodyNecessary = false;
/*     */       
/* 175 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "query") || JstlSqlTLV.this.isSqlTag(ns, ln, "update")) {
/* 176 */         if (!JstlSqlTLV.this.hasAttribute(a, "sql")) {
/* 177 */           this.bodyNecessary = true;
/*     */         }
/* 179 */         if (JstlSqlTLV.this.hasAttribute(a, "dataSource") && !this.transactionDepths.empty()) {
/* 180 */           JstlSqlTLV.this.fail(Resources.getMessage("ERROR_NESTED_DATASOURCE"));
/*     */         }
/*     */       } 
/*     */       
/* 184 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "dateParam")) {
/* 185 */         this.bodyIllegal = true;
/*     */       }
/*     */ 
/*     */       
/* 189 */       this.lastElementName = qn;
/* 190 */       JstlSqlTLV.this.lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
/*     */ 
/*     */       
/* 193 */       this.depth++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] ch, int start, int length) {
/* 198 */       this.bodyNecessary = false;
/*     */ 
/*     */       
/* 201 */       String s = (new String(ch, start, length)).trim();
/* 202 */       if (s.equals("")) {
/*     */         return;
/*     */       }
/*     */       
/* 206 */       if (this.bodyIllegal) {
/* 207 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void endElement(String ns, String ln, String qn) {
/* 213 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 217 */       if (this.bodyNecessary) {
/* 218 */         JstlSqlTLV.this.fail(Resources.getMessage("TLV_MISSING_BODY", this.lastElementName));
/*     */       }
/* 220 */       this.bodyIllegal = false;
/*     */ 
/*     */       
/* 223 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "query")) {
/* 224 */         this.queryDepths.pop();
/*     */       }
/*     */       
/* 227 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "update")) {
/* 228 */         this.updateDepths.pop();
/*     */       }
/*     */       
/* 231 */       if (JstlSqlTLV.this.isSqlTag(ns, ln, "transaction")) {
/* 232 */         this.transactionDepths.pop();
/*     */       }
/*     */ 
/*     */       
/* 236 */       this.depth--;
/*     */     }
/*     */     
/*     */     private Handler() {}
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tlv\JstlSqlTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */