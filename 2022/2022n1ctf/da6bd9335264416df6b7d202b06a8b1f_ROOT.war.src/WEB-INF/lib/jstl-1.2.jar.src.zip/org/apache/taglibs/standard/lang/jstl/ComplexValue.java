/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComplexValue
/*     */   extends Expression
/*     */ {
/*     */   Expression mPrefix;
/*     */   List mSuffixes;
/*     */   
/*     */   public Expression getPrefix() {
/*  53 */     return this.mPrefix;
/*     */   } public void setPrefix(Expression pPrefix) {
/*  55 */     this.mPrefix = pPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getSuffixes() {
/*  62 */     return this.mSuffixes;
/*     */   } public void setSuffixes(List pSuffixes) {
/*  64 */     this.mSuffixes = pSuffixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComplexValue(Expression pPrefix, List pSuffixes) {
/*  74 */     this.mPrefix = pPrefix;
/*  75 */     this.mSuffixes = pSuffixes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  87 */     StringBuffer buf = new StringBuffer();
/*  88 */     buf.append(this.mPrefix.getExpressionString());
/*     */     
/*  90 */     for (int i = 0; this.mSuffixes != null && i < this.mSuffixes.size(); i++) {
/*  91 */       ValueSuffix suffix = this.mSuffixes.get(i);
/*  92 */       buf.append(suffix.getExpressionString());
/*     */     } 
/*     */     
/*  95 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 110 */     Object ret = this.mPrefix.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (int i = 0; this.mSuffixes != null && i < this.mSuffixes.size(); i++) {
/* 115 */       ValueSuffix suffix = this.mSuffixes.get(i);
/* 116 */       ret = suffix.evaluate(ret, pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     return ret;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ComplexValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */