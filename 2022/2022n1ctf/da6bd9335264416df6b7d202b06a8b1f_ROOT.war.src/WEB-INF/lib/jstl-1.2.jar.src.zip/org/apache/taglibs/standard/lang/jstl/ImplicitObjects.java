/*      */ package org.apache.taglibs.standard.lang.jstl;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.jsp.PageContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ImplicitObjects
/*      */ {
/*      */   static final String sAttributeName = "org.apache.taglibs.standard.ImplicitObjects";
/*      */   PageContext mContext;
/*      */   Map mPage;
/*      */   Map mRequest;
/*      */   Map mSession;
/*      */   Map mApplication;
/*      */   Map mParam;
/*      */   Map mParams;
/*      */   Map mHeader;
/*      */   Map mHeaders;
/*      */   Map mInitParam;
/*      */   Map mCookie;
/*      */   
/*      */   public ImplicitObjects(PageContext pContext) {
/*  140 */     this.mContext = pContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImplicitObjects getImplicitObjects(PageContext pContext) {
/*  162 */     ImplicitObjects objs = (ImplicitObjects)pContext.getAttribute("org.apache.taglibs.standard.ImplicitObjects", 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  170 */     if (objs == null) {
/*      */       
/*  172 */       objs = new ImplicitObjects(pContext);
/*      */       
/*  174 */       pContext.setAttribute("org.apache.taglibs.standard.ImplicitObjects", objs, 1);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  182 */     return objs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getPageScopeMap() {
/*  202 */     if (this.mPage == null)
/*      */     {
/*  204 */       this.mPage = createPageScopeMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  208 */     return this.mPage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getRequestScopeMap() {
/*  228 */     if (this.mRequest == null)
/*      */     {
/*  230 */       this.mRequest = createRequestScopeMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  234 */     return this.mRequest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getSessionScopeMap() {
/*  254 */     if (this.mSession == null)
/*      */     {
/*  256 */       this.mSession = createSessionScopeMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  260 */     return this.mSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getApplicationScopeMap() {
/*  280 */     if (this.mApplication == null)
/*      */     {
/*  282 */       this.mApplication = createApplicationScopeMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  286 */     return this.mApplication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getParamMap() {
/*  308 */     if (this.mParam == null)
/*      */     {
/*  310 */       this.mParam = createParamMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  314 */     return this.mParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getParamsMap() {
/*  336 */     if (this.mParams == null)
/*      */     {
/*  338 */       this.mParams = createParamsMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  342 */     return this.mParams;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getHeaderMap() {
/*  364 */     if (this.mHeader == null)
/*      */     {
/*  366 */       this.mHeader = createHeaderMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  370 */     return this.mHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getHeadersMap() {
/*  392 */     if (this.mHeaders == null)
/*      */     {
/*  394 */       this.mHeaders = createHeadersMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  398 */     return this.mHeaders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getInitParamMap() {
/*  420 */     if (this.mInitParam == null)
/*      */     {
/*  422 */       this.mInitParam = createInitParamMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  426 */     return this.mInitParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getCookieMap() {
/*  448 */     if (this.mCookie == null)
/*      */     {
/*  450 */       this.mCookie = createCookieMap(this.mContext);
/*      */     }
/*      */ 
/*      */     
/*  454 */     return this.mCookie;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createPageScopeMap(PageContext pContext) {
/*  478 */     final PageContext context = pContext;
/*      */     
/*  480 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  488 */           return context.getAttributeNamesInScope(1);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  500 */           if (pKey instanceof String)
/*      */           {
/*  502 */             return context.getAttribute((String)pKey, 1);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  512 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  524 */           return true;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createRequestScopeMap(PageContext pContext) {
/*  548 */     final PageContext context = pContext;
/*      */     
/*  550 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  558 */           return context.getAttributeNamesInScope(2);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  570 */           if (pKey instanceof String)
/*      */           {
/*  572 */             return context.getAttribute((String)pKey, 2);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  582 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  594 */           return true;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createSessionScopeMap(PageContext pContext) {
/*  618 */     final PageContext context = pContext;
/*      */     
/*  620 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  628 */           return context.getAttributeNamesInScope(3);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  640 */           if (pKey instanceof String)
/*      */           {
/*  642 */             return context.getAttribute((String)pKey, 3);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  652 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  664 */           return true;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createApplicationScopeMap(PageContext pContext) {
/*  688 */     final PageContext context = pContext;
/*      */     
/*  690 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  698 */           return context.getAttributeNamesInScope(4);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  710 */           if (pKey instanceof String)
/*      */           {
/*  712 */             return context.getAttribute((String)pKey, 4);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  722 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  734 */           return true;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createParamMap(PageContext pContext) {
/*  760 */     final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
/*      */ 
/*      */ 
/*      */     
/*  764 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  772 */           return request.getParameterNames();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  782 */           if (pKey instanceof String)
/*      */           {
/*  784 */             return request.getParameter((String)pKey);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  790 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  802 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createParamsMap(PageContext pContext) {
/*  828 */     final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
/*      */ 
/*      */ 
/*      */     
/*  832 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  840 */           return request.getParameterNames();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  850 */           if (pKey instanceof String)
/*      */           {
/*  852 */             return request.getParameterValues((String)pKey);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  858 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  870 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createHeaderMap(PageContext pContext) {
/*  896 */     final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
/*      */ 
/*      */ 
/*      */     
/*  900 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  908 */           return request.getHeaderNames();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  918 */           if (pKey instanceof String)
/*      */           {
/*  920 */             return request.getHeader((String)pKey);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  926 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/*  938 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createHeadersMap(PageContext pContext) {
/*  964 */     final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
/*      */ 
/*      */ 
/*      */     
/*  968 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/*  976 */           return request.getHeaderNames();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/*  986 */           if (pKey instanceof String) {
/*      */ 
/*      */ 
/*      */             
/*  990 */             List l = new ArrayList();
/*      */             
/*  992 */             Enumeration enum_ = request.getHeaders((String)pKey);
/*      */             
/*  994 */             if (enum_ != null)
/*      */             {
/*  996 */               while (enum_.hasMoreElements())
/*      */               {
/*  998 */                 l.add(enum_.nextElement());
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 1004 */             String[] ret = (String[])l.toArray((Object[])new String[l.size()]);
/*      */             
/* 1006 */             return ret;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1012 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/* 1024 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createInitParamMap(PageContext pContext) {
/* 1050 */     final ServletContext context = pContext.getServletContext();
/*      */     
/* 1052 */     return new EnumeratedMap()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Enumeration enumerateKeys()
/*      */         {
/* 1060 */           return context.getInitParameterNames();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getValue(Object pKey) {
/* 1070 */           if (pKey instanceof String)
/*      */           {
/* 1072 */             return context.getInitParameter((String)pKey);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1078 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isMutable() {
/* 1090 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map createCookieMap(PageContext pContext) {
/* 1118 */     HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
/*      */     
/* 1120 */     Cookie[] cookies = request.getCookies();
/*      */     
/* 1122 */     Map<Object, Object> ret = new HashMap<Object, Object>();
/*      */     
/* 1124 */     for (int i = 0; cookies != null && i < cookies.length; i++) {
/*      */       
/* 1126 */       Cookie cookie = cookies[i];
/*      */       
/* 1128 */       if (cookie != null) {
/*      */         
/* 1130 */         String name = cookie.getName();
/*      */         
/* 1132 */         if (!ret.containsKey(name))
/*      */         {
/* 1134 */           ret.put(name, cookie);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1142 */     return ret;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ImplicitObjects.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */