/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.core.LoopTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForEachTag
/*     */   extends LoopTagSupport
/*     */ {
/*     */   private String select;
/*     */   private List nodes;
/*     */   private int nodesIndex;
/*     */   private Node current;
/*     */   
/*     */   protected void prepare() throws JspTagException {
/*  57 */     this.nodesIndex = 0;
/*  58 */     XPathUtil xu = new XPathUtil(this.pageContext);
/*  59 */     this.nodes = xu.selectNodes(XPathUtil.getContext((Tag)this), this.select);
/*     */   }
/*     */   
/*     */   protected boolean hasNext() throws JspTagException {
/*  63 */     return (this.nodesIndex < this.nodes.size());
/*     */   }
/*     */   
/*     */   protected Object next() throws JspTagException {
/*  67 */     Object o = this.nodes.get(this.nodesIndex++);
/*  68 */     if (!(o instanceof Node)) {
/*  69 */       throw new JspTagException(Resources.getMessage("FOREACH_NOT_NODESET"));
/*     */     }
/*  71 */     this.current = (Node)o;
/*  72 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  81 */     init();
/*  82 */     super.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelect(String select) {
/*  90 */     this.select = select;
/*     */   }
/*     */   
/*     */   public void setBegin(int begin) throws JspTagException {
/*  94 */     this.beginSpecified = true;
/*  95 */     this.begin = begin;
/*  96 */     validateBegin();
/*     */   }
/*     */   
/*     */   public void setEnd(int end) throws JspTagException {
/* 100 */     this.endSpecified = true;
/* 101 */     this.end = end;
/* 102 */     validateEnd();
/*     */   }
/*     */   
/*     */   public void setStep(int step) throws JspTagException {
/* 106 */     this.stepSpecified = true;
/* 107 */     this.step = step;
/* 108 */     validateStep();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getContext() throws JspTagException {
/* 117 */     return this.current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 125 */     this.select = null;
/* 126 */     this.nodes = null;
/* 127 */     this.nodesIndex = 0;
/* 128 */     this.current = null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\ForEachTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */