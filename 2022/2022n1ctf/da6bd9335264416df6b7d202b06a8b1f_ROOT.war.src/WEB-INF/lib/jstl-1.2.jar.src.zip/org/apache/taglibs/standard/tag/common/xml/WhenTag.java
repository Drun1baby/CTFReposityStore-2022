/*    */ package org.apache.taglibs.standard.tag.common.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhenTag
/*    */   extends WhenTagSupport
/*    */ {
/*    */   private String select;
/*    */   
/*    */   public WhenTag() {
/* 46 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 51 */     super.release();
/* 52 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() throws JspTagException {
/* 60 */     XPathUtil xu = new XPathUtil(this.pageContext);
/* 61 */     return xu.booleanValueOf(XPathUtil.getContext((Tag)this), this.select);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelect(String select) {
/* 74 */     this.select = select;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 83 */     this.select = null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\WhenTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */