/*     */ package org.apache.taglibs.standard.lang.jstl.test;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.taglibs.standard.lang.jstl.Evaluator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticFunctionTests
/*     */ {
/*     */   public static void main(String[] args) throws Exception {
/*  43 */     Map m = getSampleMethodMap();
/*  44 */     Evaluator e = new Evaluator();
/*     */     
/*  46 */     Object o = e.evaluate("", "4", Integer.class, null, null, m, "foo");
/*  47 */     System.out.println(o);
/*  48 */     o = e.evaluate("", "${4}", Integer.class, null, null, m, "foo");
/*  49 */     System.out.println(o);
/*  50 */     o = e.evaluate("", "${2+2}", Integer.class, null, null, m, "foo");
/*  51 */     System.out.println(o);
/*  52 */     o = e.evaluate("", "${foo:add(2, 3)}", Integer.class, null, null, m, "foo");
/*  53 */     System.out.println(o);
/*  54 */     o = e.evaluate("", "${foo:multiply(2, 3)}", Integer.class, null, null, m, "foo");
/*  55 */     System.out.println(o);
/*  56 */     o = e.evaluate("", "${add(2, 3)}", Integer.class, null, null, m, "foo");
/*  57 */     System.out.println(o);
/*  58 */     o = e.evaluate("", "${multiply(2, 3)}", Integer.class, null, null, m, "foo");
/*  59 */     System.out.println(o);
/*  60 */     o = e.evaluate("", "${add(2, 3) + 5}", Integer.class, null, null, m, "foo");
/*  61 */     System.out.println(o);
/*     */     
/*  63 */     System.out.println("---");
/*  64 */     o = e.evaluate("", "${getInt(getInteger(getInt(5)))}", Integer.class, null, null, m, "foo");
/*  65 */     System.out.println(o);
/*  66 */     o = e.evaluate("", "${getInteger(getInt(getInteger(5)))}", Integer.class, null, null, m, "foo");
/*  67 */     System.out.println(o);
/*  68 */     o = e.evaluate("", "${getInt(getInt(getInt(5)))}", Integer.class, null, null, m, "foo");
/*  69 */     System.out.println(o);
/*  70 */     o = e.evaluate("", "${getInteger(getInteger(getInteger(5)))}", Integer.class, null, null, m, "foo");
/*  71 */     System.out.println(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int add(int a, int b) {
/*  76 */     return a + b;
/*     */   }
/*     */   
/*     */   public static int multiply(int a, int b) {
/*  80 */     return a * b;
/*     */   }
/*     */   
/*     */   public static int getInt(Integer i) {
/*  84 */     return i.intValue();
/*     */   }
/*     */   
/*     */   public static Integer getInteger(int i) {
/*  88 */     return new Integer(i);
/*     */   }
/*     */   
/*     */   public static Map getSampleMethodMap() throws Exception {
/*  92 */     Map<Object, Object> m = new HashMap<Object, Object>();
/*  93 */     Class<StaticFunctionTests> c = StaticFunctionTests.class;
/*  94 */     m.put("foo:add", c.getMethod("add", new Class[] { int.class, int.class }));
/*     */     
/*  96 */     m.put("foo:multiply", c.getMethod("multiply", new Class[] { int.class, int.class }));
/*     */     
/*  98 */     m.put("foo:getInt", c.getMethod("getInt", new Class[] { Integer.class }));
/*     */     
/* 100 */     m.put("foo:getInteger", c.getMethod("getInteger", new Class[] { int.class }));
/*     */     
/* 102 */     return m;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\StaticFunctionTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */