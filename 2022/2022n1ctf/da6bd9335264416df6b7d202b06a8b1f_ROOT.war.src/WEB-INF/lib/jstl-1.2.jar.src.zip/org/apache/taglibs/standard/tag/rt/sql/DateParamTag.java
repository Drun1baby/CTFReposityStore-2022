/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.apache.taglibs.standard.tag.common.sql.DateParamTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateParamTag
/*    */   extends DateParamTagSupport
/*    */ {
/*    */   public void setValue(Date value) {
/* 39 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void setType(String type) {
/* 43 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\DateParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */