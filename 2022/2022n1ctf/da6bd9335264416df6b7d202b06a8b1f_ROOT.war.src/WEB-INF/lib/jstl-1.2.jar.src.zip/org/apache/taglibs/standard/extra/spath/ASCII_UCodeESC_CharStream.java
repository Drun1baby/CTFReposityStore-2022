/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ASCII_UCodeESC_CharStream
/*     */ {
/*     */   public static final boolean staticFlag = false;
/*     */   
/*     */   static final int hexval(char c) throws IOException {
/*  34 */     switch (c) {
/*     */       
/*     */       case '0':
/*  37 */         return 0;
/*     */       case '1':
/*  39 */         return 1;
/*     */       case '2':
/*  41 */         return 2;
/*     */       case '3':
/*  43 */         return 3;
/*     */       case '4':
/*  45 */         return 4;
/*     */       case '5':
/*  47 */         return 5;
/*     */       case '6':
/*  49 */         return 6;
/*     */       case '7':
/*  51 */         return 7;
/*     */       case '8':
/*  53 */         return 8;
/*     */       case '9':
/*  55 */         return 9;
/*     */       
/*     */       case 'A':
/*     */       case 'a':
/*  59 */         return 10;
/*     */       case 'B':
/*     */       case 'b':
/*  62 */         return 11;
/*     */       case 'C':
/*     */       case 'c':
/*  65 */         return 12;
/*     */       case 'D':
/*     */       case 'd':
/*  68 */         return 13;
/*     */       case 'E':
/*     */       case 'e':
/*  71 */         return 14;
/*     */       case 'F':
/*     */       case 'f':
/*  74 */         return 15;
/*     */     } 
/*     */     
/*  77 */     throw new IOException();
/*     */   }
/*     */   
/*  80 */   public int bufpos = -1;
/*     */   
/*     */   int bufsize;
/*     */   int available;
/*     */   int tokenBegin;
/*     */   private int[] bufline;
/*     */   private int[] bufcolumn;
/*  87 */   private int column = 0;
/*  88 */   private int line = 1;
/*     */   
/*     */   private Reader inputStream;
/*     */   
/*     */   private boolean prevCharIsCR = false;
/*     */   
/*     */   private boolean prevCharIsLF = false;
/*     */   private char[] nextCharBuf;
/*     */   private char[] buffer;
/*  97 */   private int maxNextCharInd = 0;
/*  98 */   private int nextCharInd = -1;
/*  99 */   private int inBuf = 0;
/*     */ 
/*     */   
/*     */   private final void ExpandBuff(boolean wrapAround) {
/* 103 */     char[] newbuffer = new char[this.bufsize + 2048];
/* 104 */     int[] newbufline = new int[this.bufsize + 2048];
/* 105 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*     */ 
/*     */     
/*     */     try {
/* 109 */       if (wrapAround)
/*     */       {
/* 111 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/* 112 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*     */         
/* 114 */         this.buffer = newbuffer;
/*     */         
/* 116 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/* 117 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/* 118 */         this.bufline = newbufline;
/*     */         
/* 120 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/* 121 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/* 122 */         this.bufcolumn = newbufcolumn;
/*     */         
/* 124 */         this.bufpos += this.bufsize - this.tokenBegin;
/*     */       }
/*     */       else
/*     */       {
/* 128 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/* 129 */         this.buffer = newbuffer;
/*     */         
/* 131 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/* 132 */         this.bufline = newbufline;
/*     */         
/* 134 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/* 135 */         this.bufcolumn = newbufcolumn;
/*     */         
/* 137 */         this.bufpos -= this.tokenBegin;
/*     */       }
/*     */     
/* 140 */     } catch (Throwable t) {
/*     */       
/* 142 */       throw new Error(t.getMessage());
/*     */     } 
/*     */     
/* 145 */     this.available = this.bufsize += 2048;
/* 146 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void FillBuff() throws IOException {
/* 152 */     if (this.maxNextCharInd == 4096)
/* 153 */       this.maxNextCharInd = this.nextCharInd = 0; 
/*     */     try {
/*     */       int i;
/* 156 */       if ((i = this.inputStream.read(this.nextCharBuf, this.maxNextCharInd, 4096 - this.maxNextCharInd)) == -1) {
/*     */ 
/*     */         
/* 159 */         this.inputStream.close();
/* 160 */         throw new IOException();
/*     */       } 
/*     */       
/* 163 */       this.maxNextCharInd += i;
/*     */       
/*     */       return;
/* 166 */     } catch (IOException e) {
/* 167 */       if (this.bufpos != 0) {
/*     */         
/* 169 */         this.bufpos--;
/* 170 */         backup(0);
/*     */       }
/*     */       else {
/*     */         
/* 174 */         this.bufline[this.bufpos] = this.line;
/* 175 */         this.bufcolumn[this.bufpos] = this.column;
/*     */       } 
/* 177 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final char ReadByte() throws IOException {
/* 183 */     if (++this.nextCharInd >= this.maxNextCharInd) {
/* 184 */       FillBuff();
/*     */     }
/* 186 */     return this.nextCharBuf[this.nextCharInd];
/*     */   }
/*     */ 
/*     */   
/*     */   public final char BeginToken() throws IOException {
/* 191 */     if (this.inBuf > 0) {
/*     */       
/* 193 */       this.inBuf--;
/* 194 */       return this.buffer[this.tokenBegin = (this.bufpos == this.bufsize - 1) ? (this.bufpos = 0) : ++this.bufpos];
/*     */     } 
/*     */ 
/*     */     
/* 198 */     this.tokenBegin = 0;
/* 199 */     this.bufpos = -1;
/*     */     
/* 201 */     return readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   private final void AdjustBuffSize() {
/* 206 */     if (this.available == this.bufsize) {
/*     */       
/* 208 */       if (this.tokenBegin > 2048) {
/*     */         
/* 210 */         this.bufpos = 0;
/* 211 */         this.available = this.tokenBegin;
/*     */       } else {
/*     */         
/* 214 */         ExpandBuff(false);
/*     */       } 
/* 216 */     } else if (this.available > this.tokenBegin) {
/* 217 */       this.available = this.bufsize;
/* 218 */     } else if (this.tokenBegin - this.available < 2048) {
/* 219 */       ExpandBuff(true);
/*     */     } else {
/* 221 */       this.available = this.tokenBegin;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void UpdateLineColumn(char c) {
/* 226 */     this.column++;
/*     */     
/* 228 */     if (this.prevCharIsLF) {
/*     */       
/* 230 */       this.prevCharIsLF = false;
/* 231 */       this.line += this.column = 1;
/*     */     }
/* 233 */     else if (this.prevCharIsCR) {
/*     */       
/* 235 */       this.prevCharIsCR = false;
/* 236 */       if (c == '\n') {
/*     */         
/* 238 */         this.prevCharIsLF = true;
/*     */       } else {
/*     */         
/* 241 */         this.line += this.column = 1;
/*     */       } 
/*     */     } 
/* 244 */     switch (c) {
/*     */       
/*     */       case '\r':
/* 247 */         this.prevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 250 */         this.prevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 253 */         this.column--;
/* 254 */         this.column += 8 - (this.column & 0x7);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 260 */     this.bufline[this.bufpos] = this.line;
/* 261 */     this.bufcolumn[this.bufpos] = this.column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final char readChar() throws IOException {
/* 266 */     if (this.inBuf > 0) {
/*     */       
/* 268 */       this.inBuf--;
/* 269 */       return this.buffer[(this.bufpos == this.bufsize - 1) ? (this.bufpos = 0) : ++this.bufpos];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 274 */     if (++this.bufpos == this.available) {
/* 275 */       AdjustBuffSize();
/*     */     }
/* 277 */     char c = (char)(0xFF & ReadByte()); if ((c = (char)(0xFF & ReadByte())) == '\\') {
/*     */       
/* 279 */       UpdateLineColumn(c);
/*     */       
/* 281 */       int backSlashCnt = 1;
/*     */ 
/*     */       
/*     */       label48: while (true) {
/* 285 */         if (++this.bufpos == this.available) {
/* 286 */           AdjustBuffSize();
/*     */         }
/*     */         
/*     */         try {
/* 290 */           this.buffer[this.bufpos] = c = (char)(0xFF & ReadByte()); if ((c = (char)(0xFF & ReadByte())) != '\\')
/*     */           {
/* 292 */             UpdateLineColumn(c);
/*     */             
/* 294 */             if (c == 'u' && (backSlashCnt & 0x1) == 1) {
/*     */               
/* 296 */               if (--this.bufpos < 0) {
/* 297 */                 this.bufpos = this.bufsize - 1;
/*     */                 break label48;
/*     */               } 
/*     */               break;
/*     */             } 
/* 302 */             backup(backSlashCnt);
/* 303 */             return '\\';
/*     */           }
/*     */         
/* 306 */         } catch (IOException e) {
/*     */           
/* 308 */           if (backSlashCnt > 1) {
/* 309 */             backup(backSlashCnt);
/*     */           }
/* 311 */           return '\\';
/*     */         } 
/*     */         
/* 314 */         UpdateLineColumn(c);
/* 315 */         backSlashCnt++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 321 */         while ((c = (char)(0xFF & ReadByte())) == 'u') {
/* 322 */           this.column++;
/*     */         }
/* 324 */         this.buffer[this.bufpos] = c = (char)(hexval(c) << 12 | hexval((char)(0xFF & ReadByte())) << 8 | hexval((char)(0xFF & ReadByte())) << 4 | hexval((char)(0xFF & ReadByte())));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 329 */         this.column += 4;
/*     */       }
/* 331 */       catch (IOException e) {
/*     */         
/* 333 */         throw new Error("Invalid escape character at line " + this.line + " column " + this.column + ".");
/*     */       } 
/*     */ 
/*     */       
/* 337 */       if (backSlashCnt == 1) {
/* 338 */         return c;
/*     */       }
/*     */       
/* 341 */       backup(backSlashCnt - 1);
/* 342 */       return '\\';
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 347 */     UpdateLineColumn(c);
/* 348 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumn() {
/* 358 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLine() {
/* 367 */     return this.bufline[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getEndColumn() {
/* 371 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getEndLine() {
/* 375 */     return this.bufline[this.bufpos];
/*     */   }
/*     */   
/*     */   public final int getBeginColumn() {
/* 379 */     return this.bufcolumn[this.tokenBegin];
/*     */   }
/*     */   
/*     */   public final int getBeginLine() {
/* 383 */     return this.bufline[this.tokenBegin];
/*     */   }
/*     */ 
/*     */   
/*     */   public final void backup(int amount) {
/* 388 */     this.inBuf += amount;
/* 389 */     if ((this.bufpos -= amount) < 0) {
/* 390 */       this.bufpos += this.bufsize;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ASCII_UCodeESC_CharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 396 */     this.inputStream = dstream;
/* 397 */     this.line = startline;
/* 398 */     this.column = startcolumn - 1;
/*     */     
/* 400 */     this.available = this.bufsize = buffersize;
/* 401 */     this.buffer = new char[buffersize];
/* 402 */     this.bufline = new int[buffersize];
/* 403 */     this.bufcolumn = new int[buffersize];
/* 404 */     this.nextCharBuf = new char[4096];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ASCII_UCodeESC_CharStream(Reader dstream, int startline, int startcolumn) {
/* 410 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 415 */     this.inputStream = dstream;
/* 416 */     this.line = startline;
/* 417 */     this.column = startcolumn - 1;
/*     */     
/* 419 */     if (this.buffer == null || buffersize != this.buffer.length) {
/*     */       
/* 421 */       this.available = this.bufsize = buffersize;
/* 422 */       this.buffer = new char[buffersize];
/* 423 */       this.bufline = new int[buffersize];
/* 424 */       this.bufcolumn = new int[buffersize];
/* 425 */       this.nextCharBuf = new char[4096];
/*     */     } 
/* 427 */     this.prevCharIsLF = this.prevCharIsCR = false;
/* 428 */     this.tokenBegin = this.inBuf = this.maxNextCharInd = 0;
/* 429 */     this.nextCharInd = this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn) {
/* 435 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASCII_UCodeESC_CharStream(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 440 */     this(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ASCII_UCodeESC_CharStream(InputStream dstream, int startline, int startcolumn) {
/* 446 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 452 */     ReInit(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn) {
/* 457 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String GetImage() {
/* 462 */     if (this.bufpos >= this.tokenBegin) {
/* 463 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/* 465 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final char[] GetSuffix(int len) {
/* 471 */     char[] ret = new char[len];
/*     */     
/* 473 */     if (this.bufpos + 1 >= len) {
/* 474 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     } else {
/*     */       
/* 477 */       System.arraycopy(this.buffer, this.bufsize - len - this.bufpos - 1, ret, 0, len - this.bufpos - 1);
/*     */       
/* 479 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/*     */     } 
/*     */     
/* 482 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void Done() {
/* 487 */     this.nextCharBuf = null;
/* 488 */     this.buffer = null;
/* 489 */     this.bufline = null;
/* 490 */     this.bufcolumn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustBeginLineColumn(int newLine, int newCol) {
/* 498 */     int len, start = this.tokenBegin;
/*     */ 
/*     */     
/* 501 */     if (this.bufpos >= this.tokenBegin) {
/*     */       
/* 503 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     }
/*     */     else {
/*     */       
/* 507 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 510 */     int i = 0, j = 0, k = 0;
/* 511 */     int nextColDiff = 0, columnDiff = 0;
/*     */ 
/*     */     
/* 514 */     while (i < len && this.bufline[j = start % this.bufsize] == this.bufline[k = ++start % this.bufsize]) {
/*     */       
/* 516 */       this.bufline[j] = newLine;
/* 517 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 518 */       this.bufcolumn[j] = newCol + columnDiff;
/* 519 */       columnDiff = nextColDiff;
/* 520 */       i++;
/*     */     } 
/*     */     
/* 523 */     if (i < len) {
/*     */       
/* 525 */       this.bufline[j] = newLine++;
/* 526 */       this.bufcolumn[j] = newCol + columnDiff;
/*     */       
/* 528 */       while (i++ < len) {
/*     */         
/* 530 */         if (this.bufline[j = start % this.bufsize] != this.bufline[++start % this.bufsize]) {
/* 531 */           this.bufline[j] = newLine++; continue;
/*     */         } 
/* 533 */         this.bufline[j] = newLine;
/*     */       } 
/*     */     } 
/*     */     
/* 537 */     this.line = this.bufline[j];
/* 538 */     this.column = this.bufcolumn[j];
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\ASCII_UCodeESC_CharStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */