/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanInfoIndexedProperty
/*     */ {
/*     */   Method mReadMethod;
/*     */   Method mWriteMethod;
/*     */   IndexedPropertyDescriptor mIndexedPropertyDescriptor;
/*     */   
/*     */   public Method getReadMethod() {
/*  88 */     return this.mReadMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getWriteMethod() {
/* 102 */     return this.mWriteMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexedPropertyDescriptor getIndexedPropertyDescriptor() {
/* 116 */     return this.mIndexedPropertyDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInfoIndexedProperty(Method pReadMethod, Method pWriteMethod, IndexedPropertyDescriptor pIndexedPropertyDescriptor) {
/* 140 */     this.mReadMethod = pReadMethod;
/*     */     
/* 142 */     this.mWriteMethod = pWriteMethod;
/*     */     
/* 144 */     this.mIndexedPropertyDescriptor = pIndexedPropertyDescriptor;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\BeanInfoIndexedProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */