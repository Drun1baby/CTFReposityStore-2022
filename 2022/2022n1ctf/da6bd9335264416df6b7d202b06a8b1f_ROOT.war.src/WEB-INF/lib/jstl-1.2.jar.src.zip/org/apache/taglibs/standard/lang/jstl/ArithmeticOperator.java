/*    */ package org.apache.taglibs.standard.lang.jstl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ArithmeticOperator
/*    */   extends BinaryOperator
/*    */ {
/*    */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/* 50 */     return Coercions.applyArithmeticOperator(pLeft, pRight, this, pLogger);
/*    */   }
/*    */   
/*    */   public abstract double apply(double paramDouble1, double paramDouble2, Logger paramLogger);
/*    */   
/*    */   public abstract long apply(long paramLong1, long paramLong2, Logger paramLogger);
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ArithmeticOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */