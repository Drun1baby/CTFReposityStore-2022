/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Evaluator
/*     */   implements ExpressionEvaluator
/*     */ {
/*  63 */   static ELEvaluator sEvaluator = new ELEvaluator(new JSTLVariableResolver());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String validate(String pAttributeName, String pAttributeValue) {
/*     */     try {
/*  80 */       sEvaluator.parseExpressionString(pAttributeValue);
/*  81 */       return null;
/*     */     }
/*  83 */     catch (ELException exc) {
/*  84 */       return MessageFormat.format(Constants.ATTRIBUTE_PARSE_EXCEPTION, new Object[] { "" + pAttributeName, "" + pAttributeValue, exc.getMessage() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String pAttributeName, String pAttributeValue, Class pExpectedType, Tag pTag, PageContext pPageContext, Map functions, String defaultPrefix) throws JspException {
/*     */     try {
/* 110 */       return sEvaluator.evaluate(pAttributeValue, pPageContext, pExpectedType, functions, defaultPrefix);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 117 */     catch (ELException exc) {
/* 118 */       throw new JspException(MessageFormat.format(Constants.ATTRIBUTE_EVALUATION_EXCEPTION, new Object[] { "" + pAttributeName, "" + pAttributeValue, exc.getMessage(), exc.getRootCause() }), exc.getRootCause());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(String pAttributeName, String pAttributeValue, Class pExpectedType, Tag pTag, PageContext pPageContext) throws JspException {
/* 138 */     return evaluate(pAttributeName, pAttributeValue, pExpectedType, pTag, pPageContext, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseAndRender(String pAttributeValue) throws JspException {
/*     */     try {
/* 160 */       return sEvaluator.parseAndRender(pAttributeValue);
/*     */     }
/* 162 */     catch (ELException exc) {
/* 163 */       throw new JspException(MessageFormat.format(Constants.ATTRIBUTE_PARSE_EXCEPTION, new Object[] { "test", "" + pAttributeValue, exc.getMessage() }));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\Evaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */