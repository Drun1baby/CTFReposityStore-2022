package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.tagext.TagSupport;

public class DeclareTag extends TagSupport {
  public void setType(String x) {}
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\DeclareTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */