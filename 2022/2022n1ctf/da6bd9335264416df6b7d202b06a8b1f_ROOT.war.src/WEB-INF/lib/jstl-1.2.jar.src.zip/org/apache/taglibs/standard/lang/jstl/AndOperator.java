/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndOperator
/*     */   extends BinaryOperator
/*     */ {
/*  43 */   public static final AndOperator SINGLETON = new AndOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  64 */     return "and";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/*  79 */     boolean left = Coercions.coerceToBoolean(pLeft, pLogger).booleanValue();
/*     */     
/*  81 */     boolean right = Coercions.coerceToBoolean(pRight, pLogger).booleanValue();
/*     */ 
/*     */     
/*  84 */     return PrimitiveObjects.getBoolean((left && right));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldEvaluate(Object pLeft) {
/*  95 */     return (pLeft instanceof Boolean && ((Boolean)pLeft).booleanValue() == true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldCoerceToBoolean() {
/* 108 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\AndOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */