/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.MessageSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageTag
/*    */   extends MessageSupport
/*    */ {
/*    */   public void setKey(String key) throws JspTagException {
/* 47 */     this.keyAttrValue = key;
/* 48 */     this.keySpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBundle(LocalizationContext locCtxt) throws JspTagException {
/* 53 */     this.bundleAttrValue = locCtxt;
/* 54 */     this.bundleSpecified = true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\MessageTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */