/*     */ package org.apache.taglibs.standard.tag.el.sql;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.sql.QueryTagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryTag
/*     */   extends QueryTagSupport
/*     */ {
/*     */   private String dataSourceEL;
/*     */   private String sqlEL;
/*     */   private String startRowEL;
/*     */   private String maxRowsEL;
/*     */   
/*     */   public void setDataSource(String dataSourceEL) {
/*  61 */     this.dataSourceEL = dataSourceEL;
/*  62 */     this.dataSourceSpecified = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartRow(String startRowEL) {
/*  70 */     this.startRowEL = startRowEL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxRows(String maxRowsEL) {
/*  78 */     this.maxRowsEL = maxRowsEL;
/*  79 */     this.maxRowsSpecified = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSql(String sqlEL) {
/*  89 */     this.sqlEL = sqlEL;
/*     */   }
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  93 */     evaluateExpressions();
/*  94 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 102 */     Integer tempInt = null;
/*     */     
/* 104 */     if (this.dataSourceEL != null) {
/* 105 */       this.rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", this.dataSourceEL, Object.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/* 109 */     if (this.sqlEL != null) {
/* 110 */       this.sql = (String)ExpressionEvaluatorManager.evaluate("sql", this.sqlEL, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */     
/* 114 */     if (this.startRowEL != null) {
/* 115 */       tempInt = (Integer)ExpressionEvaluatorManager.evaluate("startRow", this.startRowEL, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 117 */       if (tempInt != null) {
/* 118 */         this.startRow = tempInt.intValue();
/*     */       }
/*     */     } 
/* 121 */     if (this.maxRowsEL != null) {
/* 122 */       tempInt = (Integer)ExpressionEvaluatorManager.evaluate("maxRows", this.maxRowsEL, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 124 */       if (tempInt != null)
/* 125 */         this.maxRows = tempInt.intValue(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\sql\QueryTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */