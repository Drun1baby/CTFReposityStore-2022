/*    */ package org.apache.taglibs.standard.tag.common.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.core.ConditionalTagSupport;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfTag
/*    */   extends ConditionalTagSupport
/*    */ {
/*    */   private String select;
/*    */   
/*    */   public IfTag() {
/* 45 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 50 */     super.release();
/* 51 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() throws JspTagException {
/* 59 */     XPathUtil xu = new XPathUtil(this.pageContext);
/* 60 */     return xu.booleanValueOf(XPathUtil.getContext((Tag)this), this.select);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelect(String select) {
/* 74 */     this.select = select;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 83 */     this.select = null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\IfTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */