/*    */ package org.apache.taglibs.standard.extra.spath;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelativePath
/*    */   extends Path
/*    */ {
/*    */   private RelativePath next;
/*    */   private Step step;
/*    */   
/*    */   public RelativePath(Step step, RelativePath next) {
/* 48 */     if (step == null)
/* 49 */       throw new IllegalArgumentException("non-null step required"); 
/* 50 */     this.step = step;
/* 51 */     this.next = next;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List getSteps() {
/*    */     List<Step> l;
/* 58 */     if (this.next != null) {
/* 59 */       l = this.next.getSteps();
/*    */     } else {
/* 61 */       l = new Vector();
/* 62 */     }  l.add(0, this.step);
/* 63 */     return l;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\RelativePath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */