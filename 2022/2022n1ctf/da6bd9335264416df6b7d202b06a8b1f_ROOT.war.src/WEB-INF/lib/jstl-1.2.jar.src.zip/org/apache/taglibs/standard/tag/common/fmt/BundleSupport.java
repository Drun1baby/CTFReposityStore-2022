/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BundleSupport
/*     */   extends BodyTagSupport
/*     */ {
/*  57 */   private static final Locale EMPTY_LOCALE = new Locale("", "");
/*     */ 
/*     */ 
/*     */   
/*     */   protected String basename;
/*     */ 
/*     */ 
/*     */   
/*     */   protected String prefix;
/*     */ 
/*     */ 
/*     */   
/*     */   private Locale fallbackLocale;
/*     */ 
/*     */ 
/*     */   
/*     */   private LocalizationContext locCtxt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleSupport() {
/*  79 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  83 */     this.basename = this.prefix = null;
/*  84 */     this.locCtxt = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalizationContext getLocalizationContext() {
/*  92 */     return this.locCtxt;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  96 */     return this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 104 */     this.locCtxt = getLocalizationContext(this.pageContext, this.basename);
/* 105 */     return 2;
/*     */   }
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 109 */     if (this.bodyContent != null) {
/*     */       try {
/* 111 */         this.pageContext.getOut().print(this.bodyContent.getString());
/* 112 */       } catch (IOException ioe) {
/* 113 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     }
/*     */     
/* 117 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 122 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalizationContext getLocalizationContext(PageContext pc) {
/* 135 */     LocalizationContext locCtxt = null;
/*     */     
/* 137 */     Object obj = Config.find(pc, "javax.servlet.jsp.jstl.fmt.localizationContext");
/* 138 */     if (obj == null) {
/* 139 */       return null;
/*     */     }
/*     */     
/* 142 */     if (obj instanceof LocalizationContext) {
/* 143 */       locCtxt = (LocalizationContext)obj;
/*     */     } else {
/*     */       
/* 146 */       locCtxt = getLocalizationContext(pc, (String)obj);
/*     */     } 
/*     */     
/* 149 */     return locCtxt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalizationContext getLocalizationContext(PageContext pc, String basename) {
/* 178 */     LocalizationContext locCtxt = null;
/* 179 */     ResourceBundle bundle = null;
/*     */     
/* 181 */     if (basename == null || basename.equals("")) {
/* 182 */       return new LocalizationContext();
/*     */     }
/*     */ 
/*     */     
/* 186 */     Locale pref = SetLocaleSupport.getLocale(pc, "javax.servlet.jsp.jstl.fmt.locale");
/* 187 */     if (pref != null) {
/*     */       
/* 189 */       bundle = findMatch(basename, pref);
/* 190 */       if (bundle != null) {
/* 191 */         locCtxt = new LocalizationContext(bundle, pref);
/*     */       }
/*     */     } else {
/*     */       
/* 195 */       locCtxt = findMatch(pc, basename);
/*     */     } 
/*     */     
/* 198 */     if (locCtxt == null) {
/*     */       
/* 200 */       pref = SetLocaleSupport.getLocale(pc, "javax.servlet.jsp.jstl.fmt.fallbackLocale");
/* 201 */       if (pref != null) {
/* 202 */         bundle = findMatch(basename, pref);
/* 203 */         if (bundle != null) {
/* 204 */           locCtxt = new LocalizationContext(bundle, pref);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     if (locCtxt == null) {
/*     */       
/*     */       try {
/* 212 */         bundle = ResourceBundle.getBundle(basename, EMPTY_LOCALE, Thread.currentThread().getContextClassLoader());
/*     */         
/* 214 */         if (bundle != null) {
/* 215 */           locCtxt = new LocalizationContext(bundle, null);
/*     */         }
/* 217 */       } catch (MissingResourceException mre) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (locCtxt != null) {
/*     */       
/* 224 */       if (locCtxt.getLocale() != null) {
/* 225 */         SetLocaleSupport.setResponseLocale(pc, locCtxt.getLocale());
/*     */       }
/*     */     } else {
/*     */       
/* 229 */       locCtxt = new LocalizationContext();
/*     */     } 
/*     */     
/* 232 */     return locCtxt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LocalizationContext findMatch(PageContext pageContext, String basename) {
/* 254 */     LocalizationContext locCtxt = null;
/*     */ 
/*     */ 
/*     */     
/* 258 */     Enumeration<Locale> enum_ = Util.getRequestLocales((HttpServletRequest)pageContext.getRequest());
/* 259 */     while (enum_.hasMoreElements()) {
/* 260 */       Locale pref = enum_.nextElement();
/* 261 */       ResourceBundle match = findMatch(basename, pref);
/* 262 */       if (match != null) {
/* 263 */         locCtxt = new LocalizationContext(match, pref);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 268 */     return locCtxt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResourceBundle findMatch(String basename, Locale pref) {
/* 287 */     ResourceBundle match = null;
/*     */     
/*     */     try {
/* 290 */       ResourceBundle bundle = ResourceBundle.getBundle(basename, pref, Thread.currentThread().getContextClassLoader());
/*     */ 
/*     */       
/* 293 */       Locale avail = bundle.getLocale();
/* 294 */       if (pref.equals(avail))
/*     */       {
/* 296 */         match = bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 312 */       else if (pref.getLanguage().equals(avail.getLanguage()) && ("".equals(avail.getCountry()) || pref.getCountry().equals(avail.getCountry())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 329 */         match = bundle;
/*     */       }
/*     */     
/* 332 */     } catch (MissingResourceException mre) {}
/*     */ 
/*     */     
/* 335 */     return match;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\BundleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */