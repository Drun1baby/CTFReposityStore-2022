/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModulusOperator
/*     */   extends BinaryOperator
/*     */ {
/*  43 */   public static final ModulusOperator SINGLETON = new ModulusOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  64 */     return "%";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/*  78 */     if (pLeft == null && pRight == null) {
/*     */       
/*  80 */       if (pLogger.isLoggingWarning()) {
/*  81 */         pLogger.logWarning(Constants.ARITH_OP_NULL, getOperatorSymbol());
/*     */       }
/*     */ 
/*     */       
/*  85 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */     
/*  88 */     if ((pLeft != null && (Coercions.isFloatingPointType(pLeft) || Coercions.isFloatingPointString(pLeft))) || (pRight != null && (Coercions.isFloatingPointType(pRight) || Coercions.isFloatingPointString(pRight)))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       double d1 = Coercions.coerceToPrimitiveNumber(pLeft, Double.class, pLogger).doubleValue();
/*     */ 
/*     */       
/*  97 */       double d2 = Coercions.coerceToPrimitiveNumber(pRight, Double.class, pLogger).doubleValue();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 102 */         return PrimitiveObjects.getDouble(d1 % d2);
/*     */       }
/* 104 */       catch (Exception exc) {
/* 105 */         if (pLogger.isLoggingError()) {
/* 106 */           pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + d1, "" + d2);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 112 */         return PrimitiveObjects.getInteger(0);
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     long left = Coercions.coerceToPrimitiveNumber(pLeft, Long.class, pLogger).longValue();
/*     */ 
/*     */     
/* 119 */     long right = Coercions.coerceToPrimitiveNumber(pRight, Long.class, pLogger).longValue();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 124 */       return PrimitiveObjects.getLong(left % right);
/*     */     }
/* 126 */     catch (Exception exc) {
/* 127 */       if (pLogger.isLoggingError()) {
/* 128 */         pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + left, "" + right);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\ModulusOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */