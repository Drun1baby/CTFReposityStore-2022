/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.sql.ParamTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamTag
/*    */   extends ParamTagSupport
/*    */ {
/*    */   public void setValue(Object value) {
/* 37 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\ParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */