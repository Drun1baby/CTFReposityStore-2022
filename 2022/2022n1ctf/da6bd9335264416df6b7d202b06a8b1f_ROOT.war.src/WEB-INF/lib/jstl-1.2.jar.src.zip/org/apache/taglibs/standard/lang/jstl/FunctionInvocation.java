/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionInvocation
/*     */   extends Expression
/*     */ {
/*     */   private String functionName;
/*     */   private List argumentList;
/*     */   
/*     */   public String getFunctionName() {
/*  51 */     return this.functionName;
/*  52 */   } public void setFunctionName(String f) { this.functionName = f; }
/*  53 */   public List getArgumentList() { return this.argumentList; } public void setArgumentList(List l) {
/*  54 */     this.argumentList = l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionInvocation(String functionName, List argumentList) {
/*  62 */     this.functionName = functionName;
/*  63 */     this.argumentList = argumentList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  74 */     StringBuffer b = new StringBuffer();
/*  75 */     b.append(this.functionName);
/*  76 */     b.append("(");
/*  77 */     Iterator<Expression> i = this.argumentList.iterator();
/*  78 */     while (i.hasNext()) {
/*  79 */       b.append(((Expression)i.next()).getExpressionString());
/*  80 */       if (i.hasNext())
/*  81 */         b.append(", "); 
/*     */     } 
/*  83 */     b.append(")");
/*  84 */     return b.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 102 */     if (functions == null) {
/* 103 */       pLogger.logError(Constants.UNKNOWN_FUNCTION, this.functionName);
/*     */     }
/*     */     
/* 106 */     String functionName = this.functionName;
/* 107 */     if (functionName.indexOf(":") == -1) {
/* 108 */       if (defaultPrefix == null)
/* 109 */         pLogger.logError(Constants.UNKNOWN_FUNCTION, functionName); 
/* 110 */       functionName = defaultPrefix + ":" + functionName;
/*     */     } 
/*     */ 
/*     */     
/* 114 */     Method target = (Method)functions.get(functionName);
/* 115 */     if (target == null) {
/* 116 */       pLogger.logError(Constants.UNKNOWN_FUNCTION, functionName);
/*     */     }
/*     */     
/* 119 */     Class[] params = target.getParameterTypes();
/* 120 */     if (params.length != this.argumentList.size()) {
/* 121 */       pLogger.logError(Constants.INAPPROPRIATE_FUNCTION_ARG_COUNT, new Integer(params.length), new Integer(this.argumentList.size()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 126 */     Object[] arguments = new Object[this.argumentList.size()];
/* 127 */     for (int i = 0; i < params.length; i++) {
/*     */       
/* 129 */       arguments[i] = ((Expression)this.argumentList.get(i)).evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       arguments[i] = Coercions.coerce(arguments[i], params[i], pLogger);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 140 */       return target.invoke(null, arguments);
/* 141 */     } catch (InvocationTargetException ex) {
/* 142 */       pLogger.logError(Constants.FUNCTION_INVOCATION_ERROR, ex.getTargetException(), functionName);
/*     */ 
/*     */       
/* 145 */       return null;
/* 146 */     } catch (Exception ex) {
/* 147 */       pLogger.logError(Constants.FUNCTION_INVOCATION_ERROR, ex, functionName);
/* 148 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\FunctionInvocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */