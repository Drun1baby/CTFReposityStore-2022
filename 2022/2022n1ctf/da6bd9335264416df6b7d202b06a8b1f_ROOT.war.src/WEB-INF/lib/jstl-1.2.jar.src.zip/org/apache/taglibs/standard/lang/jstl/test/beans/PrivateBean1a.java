package org.apache.taglibs.standard.lang.jstl.test.beans;

class PrivateBean1a extends PublicBean1 {}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PrivateBean1a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */