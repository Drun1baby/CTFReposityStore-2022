/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.jstl.sql.Result;
/*     */ import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class QueryTagSupport
/*     */   extends BodyTagSupport
/*     */   implements TryCatchFinally, SQLExecutionTag
/*     */ {
/*     */   private String var;
/*     */   private int scope;
/*     */   protected Object rawDataSource;
/*     */   protected boolean dataSourceSpecified;
/*     */   protected String sql;
/*     */   protected int maxRows;
/*     */   protected boolean maxRowsSpecified;
/*     */   protected int startRow;
/*     */   private Connection conn;
/*     */   private List parameters;
/*     */   private boolean isPartOfTransaction;
/*     */   
/*     */   public QueryTagSupport() {
/*  87 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  91 */     this.startRow = 0;
/*  92 */     this.maxRows = -1;
/*  93 */     this.maxRowsSpecified = this.dataSourceSpecified = false;
/*  94 */     this.isPartOfTransaction = false;
/*  95 */     this.conn = null;
/*  96 */     this.rawDataSource = null;
/*  97 */     this.parameters = null;
/*  98 */     this.sql = null;
/*  99 */     this.var = null;
/* 100 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 112 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scopeName) {
/* 120 */     this.scope = Util.getScope(scopeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSQLParameter(Object o) {
/* 131 */     if (this.parameters == null) {
/* 132 */       this.parameters = new ArrayList();
/*     */     }
/* 134 */     this.parameters.add(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 146 */     if (!this.maxRowsSpecified) {
/* 147 */       Object obj = Config.find(this.pageContext, "javax.servlet.jsp.jstl.sql.maxRows");
/* 148 */       if (obj != null) {
/* 149 */         if (obj instanceof Integer) {
/* 150 */           this.maxRows = ((Integer)obj).intValue();
/* 151 */         } else if (obj instanceof String) {
/*     */           try {
/* 153 */             this.maxRows = Integer.parseInt((String)obj);
/* 154 */           } catch (NumberFormatException nfe) {
/* 155 */             throw new JspException(Resources.getMessage("SQL_MAXROWS_PARSE_ERROR", (String)obj), nfe);
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 161 */           throw new JspException(Resources.getMessage("SQL_MAXROWS_INVALID"));
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 168 */       this.conn = getConnection();
/* 169 */     } catch (SQLException e) {
/* 170 */       throw new JspException(this.sql + ": " + e.getMessage(), e);
/*     */     } 
/*     */     
/* 173 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 194 */     String sqlStatement = null;
/* 195 */     if (this.sql != null) {
/* 196 */       sqlStatement = this.sql;
/*     */     }
/* 198 */     else if (this.bodyContent != null) {
/* 199 */       sqlStatement = this.bodyContent.getString();
/*     */     } 
/* 201 */     if (sqlStatement == null || sqlStatement.trim().length() == 0) {
/* 202 */       throw new JspTagException(Resources.getMessage("SQL_NO_STATEMENT"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (this.startRow < 0 || this.maxRows < -1) {
/* 209 */       throw new JspException(Resources.getMessage("PARAM_BAD_VALUE"));
/*     */     }
/*     */ 
/*     */     
/* 213 */     Result result = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 222 */       PreparedStatement ps = this.conn.prepareStatement(sqlStatement);
/* 223 */       setParameters(ps, this.parameters);
/* 224 */       ResultSet rs = ps.executeQuery();
/* 225 */       result = new ResultImpl(rs, this.startRow, this.maxRows);
/* 226 */       ps.close();
/*     */     }
/* 228 */     catch (Throwable e) {
/* 229 */       throw new JspException(sqlStatement + ": " + e.getMessage(), e);
/*     */     } 
/* 231 */     this.pageContext.setAttribute(this.var, result, this.scope);
/* 232 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable t) throws Throwable {
/* 239 */     throw t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/* 247 */     if (this.conn != null && !this.isPartOfTransaction) {
/*     */       try {
/* 249 */         this.conn.close();
/* 250 */       } catch (SQLException e) {}
/*     */     }
/*     */     
/* 253 */     this.conn = null;
/* 254 */     this.parameters = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection getConnection() throws JspException, SQLException {
/* 263 */     Connection conn = null;
/* 264 */     this.isPartOfTransaction = false;
/*     */     
/* 266 */     TransactionTagSupport parent = (TransactionTagSupport)findAncestorWithClass((Tag)this, TransactionTagSupport.class);
/*     */     
/* 268 */     if (parent != null) {
/* 269 */       if (this.dataSourceSpecified) {
/* 270 */         throw new JspTagException(Resources.getMessage("ERROR_NESTED_DATASOURCE"));
/*     */       }
/*     */       
/* 273 */       conn = parent.getSharedConnection();
/* 274 */       this.isPartOfTransaction = true;
/*     */     } else {
/* 276 */       if (this.rawDataSource == null && this.dataSourceSpecified) {
/* 277 */         throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
/*     */       }
/*     */       
/* 280 */       DataSource dataSource = DataSourceUtil.getDataSource(this.rawDataSource, this.pageContext);
/*     */       
/*     */       try {
/* 283 */         conn = dataSource.getConnection();
/* 284 */       } catch (Exception ex) {
/* 285 */         throw new JspException(Resources.getMessage("DATASOURCE_INVALID", ex.toString()));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 291 */     return conn;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setParameters(PreparedStatement ps, List parameters) throws SQLException {
/* 297 */     if (parameters != null)
/* 298 */       for (int i = 0; i < parameters.size(); i++)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 304 */         ps.setObject(i + 1, parameters.get(i));
/*     */       } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\QueryTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */