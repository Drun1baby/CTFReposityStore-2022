/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.core.LoopTagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ForTokensSupport
/*     */   extends LoopTagSupport
/*     */ {
/*     */   protected Object items;
/*     */   protected String delims;
/*     */   protected StringTokenizer st;
/*     */   
/*     */   protected void prepare() throws JspTagException {
/*  76 */     if (this.items instanceof ValueExpression) {
/*  77 */       this.deferredExpression = (ValueExpression)this.items;
/*  78 */       this.items = this.deferredExpression.getValue(this.pageContext.getELContext());
/*     */     } 
/*  80 */     if (!(this.items instanceof String)) {
/*  81 */       throw new JspTagException(Resources.getMessage("FORTOKENS_BAD_ITEMS"));
/*     */     }
/*     */     
/*  84 */     this.st = new StringTokenizer((String)this.items, this.delims);
/*     */   }
/*     */   
/*     */   protected boolean hasNext() throws JspTagException {
/*  88 */     return this.st.hasMoreElements();
/*     */   }
/*     */   
/*     */   protected Object next() throws JspTagException {
/*  92 */     return this.st.nextElement();
/*     */   }
/*     */   
/*     */   protected String getDelims() {
/*  96 */     return this.delims;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 105 */     super.release();
/* 106 */     this.items = this.delims = null;
/* 107 */     this.st = null;
/* 108 */     this.deferredExpression = null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\ForTokensSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */