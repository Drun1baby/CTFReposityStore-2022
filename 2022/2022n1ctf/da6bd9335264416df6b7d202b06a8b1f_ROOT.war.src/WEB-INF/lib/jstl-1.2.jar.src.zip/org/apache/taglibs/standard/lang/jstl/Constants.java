/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Constants
/*     */ {
/*  47 */   static ResourceBundle sResources = ResourceBundle.getBundle("org.apache.taglibs.standard.lang.jstl.Resources");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final String EXCEPTION_GETTING_BEANINFO = getStringResource("EXCEPTION_GETTING_BEANINFO");
/*     */ 
/*     */   
/*  57 */   public static final String NULL_EXPRESSION_STRING = getStringResource("NULL_EXPRESSION_STRING");
/*     */ 
/*     */   
/*  60 */   public static final String PARSE_EXCEPTION = getStringResource("PARSE_EXCEPTION");
/*     */ 
/*     */   
/*  63 */   public static final String CANT_GET_PROPERTY_OF_NULL = getStringResource("CANT_GET_PROPERTY_OF_NULL");
/*     */ 
/*     */   
/*  66 */   public static final String NO_SUCH_PROPERTY = getStringResource("NO_SUCH_PROPERTY");
/*     */ 
/*     */   
/*  69 */   public static final String NO_GETTER_METHOD = getStringResource("NO_GETTER_METHOD");
/*     */ 
/*     */   
/*  72 */   public static final String ERROR_GETTING_PROPERTY = getStringResource("ERROR_GETTING_PROPERTY");
/*     */ 
/*     */   
/*  75 */   public static final String CANT_GET_INDEXED_VALUE_OF_NULL = getStringResource("CANT_GET_INDEXED_VALUE_OF_NULL");
/*     */ 
/*     */   
/*  78 */   public static final String CANT_GET_NULL_INDEX = getStringResource("CANT_GET_NULL_INDEX");
/*     */ 
/*     */   
/*  81 */   public static final String NULL_INDEX = getStringResource("NULL_INDEX");
/*     */ 
/*     */   
/*  84 */   public static final String BAD_INDEX_VALUE = getStringResource("BAD_INDEX_VALUE");
/*     */ 
/*     */   
/*  87 */   public static final String EXCEPTION_ACCESSING_LIST = getStringResource("EXCEPTION_ACCESSING_LIST");
/*     */ 
/*     */   
/*  90 */   public static final String EXCEPTION_ACCESSING_ARRAY = getStringResource("EXCEPTION_ACCESSING_ARRAY");
/*     */ 
/*     */   
/*  93 */   public static final String CANT_FIND_INDEX = getStringResource("CANT_FIND_INDEX");
/*     */ 
/*     */   
/*  96 */   public static final String TOSTRING_EXCEPTION = getStringResource("TOSTRING_EXCEPTION");
/*     */ 
/*     */   
/*  99 */   public static final String BOOLEAN_TO_NUMBER = getStringResource("BOOLEAN_TO_NUMBER");
/*     */ 
/*     */   
/* 102 */   public static final String STRING_TO_NUMBER_EXCEPTION = getStringResource("STRING_TO_NUMBER_EXCEPTION");
/*     */ 
/*     */   
/* 105 */   public static final String COERCE_TO_NUMBER = getStringResource("COERCE_TO_NUMBER");
/*     */ 
/*     */   
/* 108 */   public static final String BOOLEAN_TO_CHARACTER = getStringResource("BOOLEAN_TO_CHARACTER");
/*     */ 
/*     */   
/* 111 */   public static final String EMPTY_STRING_TO_CHARACTER = getStringResource("EMPTY_STRING_TO_CHARACTER");
/*     */ 
/*     */   
/* 114 */   public static final String COERCE_TO_CHARACTER = getStringResource("COERCE_TO_CHARACTER");
/*     */ 
/*     */   
/* 117 */   public static final String NULL_TO_BOOLEAN = getStringResource("NULL_TO_BOOLEAN");
/*     */ 
/*     */   
/* 120 */   public static final String STRING_TO_BOOLEAN = getStringResource("STRING_TO_BOOLEAN");
/*     */ 
/*     */   
/* 123 */   public static final String COERCE_TO_BOOLEAN = getStringResource("COERCE_TO_BOOLEAN");
/*     */ 
/*     */   
/* 126 */   public static final String COERCE_TO_OBJECT = getStringResource("COERCE_TO_OBJECT");
/*     */ 
/*     */   
/* 129 */   public static final String NO_PROPERTY_EDITOR = getStringResource("NO_PROPERTY_EDITOR");
/*     */ 
/*     */   
/* 132 */   public static final String PROPERTY_EDITOR_ERROR = getStringResource("PROPERTY_EDITOR_ERROR");
/*     */ 
/*     */   
/* 135 */   public static final String ARITH_OP_NULL = getStringResource("ARITH_OP_NULL");
/*     */ 
/*     */   
/* 138 */   public static final String ARITH_OP_BAD_TYPE = getStringResource("ARITH_OP_BAD_TYPE");
/*     */ 
/*     */   
/* 141 */   public static final String ARITH_ERROR = getStringResource("ARITH_ERROR");
/*     */ 
/*     */   
/* 144 */   public static final String ERROR_IN_EQUALS = getStringResource("ERROR_IN_EQUALS");
/*     */ 
/*     */   
/* 147 */   public static final String UNARY_OP_BAD_TYPE = getStringResource("UNARY_OP_BAD_TYPE");
/*     */ 
/*     */   
/* 150 */   public static final String NAMED_VALUE_NOT_FOUND = getStringResource("NAMED_VALUE_NOT_FOUND");
/*     */ 
/*     */   
/* 153 */   public static final String CANT_GET_INDEXED_PROPERTY = getStringResource("CANT_GET_INDEXED_PROPERTY");
/*     */ 
/*     */   
/* 156 */   public static final String COMPARABLE_ERROR = getStringResource("COMPARABLE_ERROR");
/*     */ 
/*     */   
/* 159 */   public static final String BAD_IMPLICIT_OBJECT = getStringResource("BAD_IMPLICIT_OBJECT");
/*     */ 
/*     */   
/* 162 */   public static final String ATTRIBUTE_EVALUATION_EXCEPTION = getStringResource("ATTRIBUTE_EVALUATION_EXCEPTION");
/*     */ 
/*     */   
/* 165 */   public static final String ATTRIBUTE_PARSE_EXCEPTION = getStringResource("ATTRIBUTE_PARSE_EXCEPTION");
/*     */ 
/*     */   
/* 168 */   public static final String UNKNOWN_FUNCTION = getStringResource("UNKNOWN_FUNCTION");
/*     */ 
/*     */   
/* 171 */   public static final String INAPPROPRIATE_FUNCTION_ARG_COUNT = getStringResource("INAPPROPRIATE_FUNCTION_ARG_COUNT");
/*     */ 
/*     */   
/* 174 */   public static final String FUNCTION_INVOCATION_ERROR = getStringResource("FUNCTION_INVOCATION_ERROR");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStringResource(String pResourceName) throws MissingResourceException {
/*     */     try {
/* 189 */       String ret = sResources.getString(pResourceName);
/* 190 */       if (ret == null) {
/* 191 */         String str = "ERROR: Unable to load resource " + pResourceName;
/* 192 */         System.err.println(str);
/* 193 */         throw new MissingResourceException(str, "org.apache.taglibs.standard.lang.jstl.Constants", pResourceName);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       return ret;
/*     */     
/*     */     }
/* 202 */     catch (MissingResourceException exc) {
/* 203 */       System.err.println("ERROR: Unable to load resource " + pResourceName + ": " + exc);
/*     */ 
/*     */ 
/*     */       
/* 207 */       throw exc;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\Constants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */