/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.core.ImportSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportTag
/*    */   extends ImportSupport
/*    */ {
/*    */   public void setUrl(String url) throws JspTagException {
/* 46 */     this.url = url;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(String context) throws JspTagException {
/* 51 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCharEncoding(String charEncoding) throws JspTagException {
/* 56 */     this.charEncoding = charEncoding;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\ImportTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */