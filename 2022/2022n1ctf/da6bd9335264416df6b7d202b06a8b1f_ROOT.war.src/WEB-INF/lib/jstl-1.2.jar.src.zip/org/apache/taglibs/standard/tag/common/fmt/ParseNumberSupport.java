/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParseNumberSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   private static final String NUMBER = "number";
/*     */   private static final String CURRENCY = "currency";
/*     */   private static final String PERCENT = "percent";
/*     */   protected String value;
/*     */   protected boolean valueSpecified;
/*     */   protected String type;
/*     */   protected String pattern;
/*     */   protected Locale parseLocale;
/*     */   protected boolean isIntegerOnly;
/*     */   protected boolean integerOnlySpecified;
/*     */   private String var;
/*     */   private int scope;
/*     */   
/*     */   public ParseNumberSupport() {
/*  84 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  88 */     this.value = this.type = this.pattern = this.var = null;
/*  89 */     this.valueSpecified = false;
/*  90 */     this.parseLocale = null;
/*  91 */     this.integerOnlySpecified = false;
/*  92 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 100 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 104 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 112 */     String input = null;
/*     */ 
/*     */     
/* 115 */     if (this.valueSpecified) {
/*     */       
/* 117 */       input = this.value;
/*     */     
/*     */     }
/* 120 */     else if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 121 */       input = this.bodyContent.getString().trim();
/*     */     } 
/*     */     
/* 124 */     if (input == null || input.equals("")) {
/* 125 */       if (this.var != null) {
/* 126 */         this.pageContext.removeAttribute(this.var, this.scope);
/*     */       }
/* 128 */       return 6;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     Locale loc = this.parseLocale;
/* 136 */     if (loc == null) {
/* 137 */       loc = SetLocaleSupport.getFormattingLocale(this.pageContext, (Tag)this, false, NumberFormat.getAvailableLocales());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 142 */     if (loc == null) {
/* 143 */       throw new JspException(Resources.getMessage("PARSE_NUMBER_NO_PARSE_LOCALE"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 148 */     NumberFormat parser = null;
/* 149 */     if (this.pattern != null && !this.pattern.equals("")) {
/*     */       
/* 151 */       DecimalFormatSymbols symbols = new DecimalFormatSymbols(loc);
/* 152 */       parser = new DecimalFormat(this.pattern, symbols);
/*     */     } else {
/* 154 */       parser = createParser(loc);
/*     */     } 
/*     */ 
/*     */     
/* 158 */     if (this.integerOnlySpecified) {
/* 159 */       parser.setParseIntegerOnly(this.isIntegerOnly);
/*     */     }
/*     */     
/* 162 */     Number parsed = null;
/*     */     try {
/* 164 */       parsed = parser.parse(input);
/* 165 */     } catch (ParseException pe) {
/* 166 */       throw new JspException(Resources.getMessage("PARSE_NUMBER_PARSE_ERROR", input), pe);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (this.var != null) {
/* 172 */       this.pageContext.setAttribute(this.var, parsed, this.scope);
/*     */     } else {
/*     */       try {
/* 175 */         this.pageContext.getOut().print(parsed);
/* 176 */       } catch (IOException ioe) {
/* 177 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 186 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NumberFormat createParser(Locale loc) throws JspException {
/* 194 */     NumberFormat parser = null;
/*     */     
/* 196 */     if (this.type == null || "number".equalsIgnoreCase(this.type)) {
/* 197 */       parser = NumberFormat.getNumberInstance(loc);
/* 198 */     } else if ("currency".equalsIgnoreCase(this.type)) {
/* 199 */       parser = NumberFormat.getCurrencyInstance(loc);
/* 200 */     } else if ("percent".equalsIgnoreCase(this.type)) {
/* 201 */       parser = NumberFormat.getPercentInstance(loc);
/*     */     } else {
/* 203 */       throw new JspException(Resources.getMessage("PARSE_NUMBER_INVALID_TYPE", this.type));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 208 */     return parser;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\ParseNumberSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */