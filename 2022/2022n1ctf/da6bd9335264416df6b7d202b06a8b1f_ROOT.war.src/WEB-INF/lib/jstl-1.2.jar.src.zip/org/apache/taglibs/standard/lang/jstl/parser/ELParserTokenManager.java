/*      */ package org.apache.taglibs.standard.lang.jstl.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ELParserTokenManager
/*      */   implements ELParserConstants
/*      */ {
/*   27 */   public PrintStream debugStream = System.out; public void setDebugStream(PrintStream ds) {
/*   28 */     this.debugStream = ds;
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0) {
/*   31 */     switch (pos) {
/*      */       
/*      */       case 0:
/*   34 */         if ((active0 & 0x4L) != 0L) {
/*      */           
/*   36 */           this.jjmatchedKind = 1;
/*   37 */           return 2;
/*      */         } 
/*   39 */         return -1;
/*      */     } 
/*   41 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0) {
/*   46 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjStopAtPos(int pos, int kind) {
/*   50 */     this.jjmatchedKind = kind;
/*   51 */     this.jjmatchedPos = pos;
/*   52 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*   56 */     this.jjmatchedKind = kind;
/*   57 */     this.jjmatchedPos = pos; 
/*   58 */     try { this.curChar = this.input_stream.readChar(); }
/*   59 */     catch (IOException e) { return pos + 1; }
/*   60 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa0_0() {
/*   64 */     switch (this.curChar) {
/*      */       
/*      */       case '$':
/*   67 */         return jjMoveStringLiteralDfa1_0(4L);
/*      */     } 
/*   69 */     return jjMoveNfa_0(1, 0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*   74 */       this.curChar = this.input_stream.readChar();
/*   75 */     } catch (IOException e) {
/*   76 */       jjStopStringLiteralDfa_0(0, active0);
/*   77 */       return 1;
/*      */     } 
/*   79 */     switch (this.curChar) {
/*      */       
/*      */       case '{':
/*   82 */         if ((active0 & 0x4L) != 0L) {
/*   83 */           return jjStopAtPos(1, 2);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*   88 */     return jjStartNfa_0(0, active0);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAdd(int state) {
/*   92 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/*   94 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/*   95 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void jjAddStates(int start, int end) {
/*      */     do {
/*  101 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/*  102 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddTwoStates(int state1, int state2) {
/*  106 */     jjCheckNAdd(state1);
/*  107 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start, int end) {
/*      */     do {
/*  112 */       jjCheckNAdd(jjnextStates[start]);
/*  113 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start) {
/*  117 */     jjCheckNAdd(jjnextStates[start]);
/*  118 */     jjCheckNAdd(jjnextStates[start + 1]);
/*      */   }
/*  120 */   static final long[] jjbitVec0 = new long[] { -2L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  123 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int jjMoveNfa_0(int startState, int curPos) {
/*  129 */     int startsAt = 0;
/*  130 */     this.jjnewStateCnt = 3;
/*  131 */     int i = 1;
/*  132 */     this.jjstateSet[0] = startState;
/*  133 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  136 */       if (++this.jjround == Integer.MAX_VALUE)
/*  137 */         ReInitRounds(); 
/*  138 */       if (this.curChar < '@') {
/*      */         
/*  140 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  143 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 1:
/*  146 */               if ((0xFFFFFFEFFFFFFFFFL & l) != 0L) {
/*      */                 
/*  148 */                 if (kind > 1)
/*  149 */                   kind = 1; 
/*  150 */                 jjCheckNAdd(0); break;
/*      */               } 
/*  152 */               if (this.curChar == '$') {
/*      */                 
/*  154 */                 if (kind > 1)
/*  155 */                   kind = 1; 
/*  156 */                 jjCheckNAdd(2);
/*      */               } 
/*      */               break;
/*      */             case 0:
/*  160 */               if ((0xFFFFFFEFFFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  162 */               if (kind > 1)
/*  163 */                 kind = 1; 
/*  164 */               jjCheckNAdd(0);
/*      */               break;
/*      */             case 2:
/*  167 */               if ((0xFFFFFFEFFFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  169 */               if (kind > 1)
/*  170 */                 kind = 1; 
/*  171 */               jjCheckNAdd(2);
/*      */               break;
/*      */           } 
/*      */         
/*  175 */         } while (i != startsAt);
/*      */       }
/*  177 */       else if (this.curChar < '') {
/*      */         
/*  179 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  182 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/*  186 */               if (kind > 1)
/*  187 */                 kind = 1; 
/*  188 */               jjCheckNAdd(0);
/*      */               break;
/*      */             case 2:
/*  191 */               if ((0xF7FFFFFFFFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  193 */               if (kind > 1)
/*  194 */                 kind = 1; 
/*  195 */               this.jjstateSet[this.jjnewStateCnt++] = 2;
/*      */               break;
/*      */           } 
/*      */         
/*  199 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  203 */         int hiByte = this.curChar >> 8;
/*  204 */         int i1 = hiByte >> 6;
/*  205 */         long l1 = 1L << (hiByte & 0x3F);
/*  206 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  207 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  210 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/*  214 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/*  216 */               if (kind > 1)
/*  217 */                 kind = 1; 
/*  218 */               jjCheckNAdd(0);
/*      */               break;
/*      */             case 2:
/*  221 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/*  223 */               if (kind > 1)
/*  224 */                 kind = 1; 
/*  225 */               this.jjstateSet[this.jjnewStateCnt++] = 2;
/*      */               break;
/*      */           } 
/*      */         
/*  229 */         } while (i != startsAt);
/*      */       } 
/*  231 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  233 */         this.jjmatchedKind = kind;
/*  234 */         this.jjmatchedPos = curPos;
/*  235 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  237 */       curPos++;
/*  238 */       if ((i = this.jjnewStateCnt) == (startsAt = 3 - (this.jjnewStateCnt = startsAt)))
/*  239 */         return curPos;  
/*  240 */       try { this.curChar = this.input_stream.readChar(); }
/*  241 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_1(int pos, long active0) {
/*  246 */     switch (pos) {
/*      */       
/*      */       case 0:
/*  249 */         if ((active0 & 0x1568015547000L) != 0L) {
/*      */           
/*  251 */           this.jjmatchedKind = 49;
/*  252 */           return 6;
/*      */         } 
/*  254 */         if ((active0 & 0x10000L) != 0L)
/*  255 */           return 1; 
/*  256 */         return -1;
/*      */       case 1:
/*  258 */         if ((active0 & 0x400015540000L) != 0L)
/*  259 */           return 6; 
/*  260 */         if ((active0 & 0x1168000007000L) != 0L) {
/*      */           
/*  262 */           this.jjmatchedKind = 49;
/*  263 */           this.jjmatchedPos = 1;
/*  264 */           return 6;
/*      */         } 
/*  266 */         return -1;
/*      */       case 2:
/*  268 */         if ((active0 & 0x168000000000L) != 0L)
/*  269 */           return 6; 
/*  270 */         if ((active0 & 0x1000000007000L) != 0L) {
/*      */           
/*  272 */           this.jjmatchedKind = 49;
/*  273 */           this.jjmatchedPos = 2;
/*  274 */           return 6;
/*      */         } 
/*  276 */         return -1;
/*      */       case 3:
/*  278 */         if ((active0 & 0x5000L) != 0L)
/*  279 */           return 6; 
/*  280 */         if ((active0 & 0x1000000002000L) != 0L) {
/*      */           
/*  282 */           this.jjmatchedKind = 49;
/*  283 */           this.jjmatchedPos = 3;
/*  284 */           return 6;
/*      */         } 
/*  286 */         return -1;
/*      */     } 
/*  288 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_1(int pos, long active0) {
/*  293 */     return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjStartNfaWithStates_1(int pos, int kind, int state) {
/*  297 */     this.jjmatchedKind = kind;
/*  298 */     this.jjmatchedPos = pos; 
/*  299 */     try { this.curChar = this.input_stream.readChar(); }
/*  300 */     catch (IOException e) { return pos + 1; }
/*  301 */      return jjMoveNfa_1(state, pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa0_1() {
/*  305 */     switch (this.curChar) {
/*      */       
/*      */       case '!':
/*  308 */         this.jjmatchedKind = 43;
/*  309 */         return jjMoveStringLiteralDfa1_1(134217728L);
/*      */       case '%':
/*  311 */         return jjStopAtPos(0, 40);
/*      */       case '&':
/*  313 */         return jjMoveStringLiteralDfa1_1(35184372088832L);
/*      */       case '(':
/*  315 */         return jjStopAtPos(0, 29);
/*      */       case ')':
/*  317 */         return jjStopAtPos(0, 30);
/*      */       case '*':
/*  319 */         return jjStopAtPos(0, 37);
/*      */       case '+':
/*  321 */         return jjStopAtPos(0, 35);
/*      */       case ',':
/*  323 */         return jjStopAtPos(0, 31);
/*      */       case '-':
/*  325 */         return jjStopAtPos(0, 36);
/*      */       case '.':
/*  327 */         return jjStartNfaWithStates_1(0, 16, 1);
/*      */       case '/':
/*  329 */         return jjStopAtPos(0, 38);
/*      */       case ':':
/*  331 */         return jjStopAtPos(0, 32);
/*      */       case '<':
/*  333 */         this.jjmatchedKind = 19;
/*  334 */         return jjMoveStringLiteralDfa1_1(8388608L);
/*      */       case '=':
/*  336 */         return jjMoveStringLiteralDfa1_1(2097152L);
/*      */       case '>':
/*  338 */         this.jjmatchedKind = 17;
/*  339 */         return jjMoveStringLiteralDfa1_1(33554432L);
/*      */       case '[':
/*  341 */         return jjStopAtPos(0, 33);
/*      */       case ']':
/*  343 */         return jjStopAtPos(0, 34);
/*      */       case 'a':
/*  345 */         return jjMoveStringLiteralDfa1_1(17592186044416L);
/*      */       case 'd':
/*  347 */         return jjMoveStringLiteralDfa1_1(549755813888L);
/*      */       case 'e':
/*  349 */         return jjMoveStringLiteralDfa1_1(281474980904960L);
/*      */       case 'f':
/*  351 */         return jjMoveStringLiteralDfa1_1(8192L);
/*      */       case 'g':
/*  353 */         return jjMoveStringLiteralDfa1_1(67371008L);
/*      */       case 'l':
/*  355 */         return jjMoveStringLiteralDfa1_1(17825792L);
/*      */       case 'm':
/*  357 */         return jjMoveStringLiteralDfa1_1(2199023255552L);
/*      */       case 'n':
/*  359 */         return jjMoveStringLiteralDfa1_1(4398314962944L);
/*      */       case 'o':
/*  361 */         return jjMoveStringLiteralDfa1_1(70368744177664L);
/*      */       case 't':
/*  363 */         return jjMoveStringLiteralDfa1_1(4096L);
/*      */       case '|':
/*  365 */         return jjMoveStringLiteralDfa1_1(140737488355328L);
/*      */       case '}':
/*  367 */         return jjStopAtPos(0, 15);
/*      */     } 
/*  369 */     return jjMoveNfa_1(0, 0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa1_1(long active0) {
/*      */     try {
/*  374 */       this.curChar = this.input_stream.readChar();
/*  375 */     } catch (IOException e) {
/*  376 */       jjStopStringLiteralDfa_1(0, active0);
/*  377 */       return 1;
/*      */     } 
/*  379 */     switch (this.curChar) {
/*      */       
/*      */       case '&':
/*  382 */         if ((active0 & 0x200000000000L) != 0L)
/*  383 */           return jjStopAtPos(1, 45); 
/*      */         break;
/*      */       case '=':
/*  386 */         if ((active0 & 0x200000L) != 0L)
/*  387 */           return jjStopAtPos(1, 21); 
/*  388 */         if ((active0 & 0x800000L) != 0L)
/*  389 */           return jjStopAtPos(1, 23); 
/*  390 */         if ((active0 & 0x2000000L) != 0L)
/*  391 */           return jjStopAtPos(1, 25); 
/*  392 */         if ((active0 & 0x8000000L) != 0L)
/*  393 */           return jjStopAtPos(1, 27); 
/*      */         break;
/*      */       case 'a':
/*  396 */         return jjMoveStringLiteralDfa2_1(active0, 8192L);
/*      */       case 'e':
/*  398 */         if ((active0 & 0x1000000L) != 0L)
/*  399 */           return jjStartNfaWithStates_1(1, 24, 6); 
/*  400 */         if ((active0 & 0x4000000L) != 0L)
/*  401 */           return jjStartNfaWithStates_1(1, 26, 6); 
/*  402 */         if ((active0 & 0x10000000L) != 0L)
/*  403 */           return jjStartNfaWithStates_1(1, 28, 6); 
/*      */         break;
/*      */       case 'i':
/*  406 */         return jjMoveStringLiteralDfa2_1(active0, 549755813888L);
/*      */       case 'm':
/*  408 */         return jjMoveStringLiteralDfa2_1(active0, 281474976710656L);
/*      */       case 'n':
/*  410 */         return jjMoveStringLiteralDfa2_1(active0, 17592186044416L);
/*      */       case 'o':
/*  412 */         return jjMoveStringLiteralDfa2_1(active0, 6597069766656L);
/*      */       case 'q':
/*  414 */         if ((active0 & 0x400000L) != 0L)
/*  415 */           return jjStartNfaWithStates_1(1, 22, 6); 
/*      */         break;
/*      */       case 'r':
/*  418 */         if ((active0 & 0x400000000000L) != 0L)
/*  419 */           return jjStartNfaWithStates_1(1, 46, 6); 
/*  420 */         return jjMoveStringLiteralDfa2_1(active0, 4096L);
/*      */       case 't':
/*  422 */         if ((active0 & 0x40000L) != 0L)
/*  423 */           return jjStartNfaWithStates_1(1, 18, 6); 
/*  424 */         if ((active0 & 0x100000L) != 0L)
/*  425 */           return jjStartNfaWithStates_1(1, 20, 6); 
/*      */         break;
/*      */       case 'u':
/*  428 */         return jjMoveStringLiteralDfa2_1(active0, 16384L);
/*      */       case '|':
/*  430 */         if ((active0 & 0x800000000000L) != 0L) {
/*  431 */           return jjStopAtPos(1, 47);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  436 */     return jjStartNfa_1(0, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa2_1(long old0, long active0) {
/*  440 */     if ((active0 &= old0) == 0L)
/*  441 */       return jjStartNfa_1(0, old0);  try {
/*  442 */       this.curChar = this.input_stream.readChar();
/*  443 */     } catch (IOException e) {
/*  444 */       jjStopStringLiteralDfa_1(1, active0);
/*  445 */       return 2;
/*      */     } 
/*  447 */     switch (this.curChar) {
/*      */       
/*      */       case 'd':
/*  450 */         if ((active0 & 0x20000000000L) != 0L)
/*  451 */           return jjStartNfaWithStates_1(2, 41, 6); 
/*  452 */         if ((active0 & 0x100000000000L) != 0L)
/*  453 */           return jjStartNfaWithStates_1(2, 44, 6); 
/*      */         break;
/*      */       case 'l':
/*  456 */         return jjMoveStringLiteralDfa3_1(active0, 24576L);
/*      */       case 'p':
/*  458 */         return jjMoveStringLiteralDfa3_1(active0, 281474976710656L);
/*      */       case 't':
/*  460 */         if ((active0 & 0x40000000000L) != 0L)
/*  461 */           return jjStartNfaWithStates_1(2, 42, 6); 
/*      */         break;
/*      */       case 'u':
/*  464 */         return jjMoveStringLiteralDfa3_1(active0, 4096L);
/*      */       case 'v':
/*  466 */         if ((active0 & 0x8000000000L) != 0L) {
/*  467 */           return jjStartNfaWithStates_1(2, 39, 6);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  472 */     return jjStartNfa_1(1, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa3_1(long old0, long active0) {
/*  476 */     if ((active0 &= old0) == 0L)
/*  477 */       return jjStartNfa_1(1, old0);  try {
/*  478 */       this.curChar = this.input_stream.readChar();
/*  479 */     } catch (IOException e) {
/*  480 */       jjStopStringLiteralDfa_1(2, active0);
/*  481 */       return 3;
/*      */     } 
/*  483 */     switch (this.curChar) {
/*      */       
/*      */       case 'e':
/*  486 */         if ((active0 & 0x1000L) != 0L)
/*  487 */           return jjStartNfaWithStates_1(3, 12, 6); 
/*      */         break;
/*      */       case 'l':
/*  490 */         if ((active0 & 0x4000L) != 0L)
/*  491 */           return jjStartNfaWithStates_1(3, 14, 6); 
/*      */         break;
/*      */       case 's':
/*  494 */         return jjMoveStringLiteralDfa4_1(active0, 8192L);
/*      */       case 't':
/*  496 */         return jjMoveStringLiteralDfa4_1(active0, 281474976710656L);
/*      */     } 
/*      */ 
/*      */     
/*  500 */     return jjStartNfa_1(2, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa4_1(long old0, long active0) {
/*  504 */     if ((active0 &= old0) == 0L)
/*  505 */       return jjStartNfa_1(2, old0);  try {
/*  506 */       this.curChar = this.input_stream.readChar();
/*  507 */     } catch (IOException e) {
/*  508 */       jjStopStringLiteralDfa_1(3, active0);
/*  509 */       return 4;
/*      */     } 
/*  511 */     switch (this.curChar) {
/*      */       
/*      */       case 'e':
/*  514 */         if ((active0 & 0x2000L) != 0L)
/*  515 */           return jjStartNfaWithStates_1(4, 13, 6); 
/*      */         break;
/*      */       case 'y':
/*  518 */         if ((active0 & 0x1000000000000L) != 0L) {
/*  519 */           return jjStartNfaWithStates_1(4, 48, 6);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  524 */     return jjStartNfa_1(3, active0);
/*      */   }
/*  526 */   static final long[] jjbitVec3 = new long[] { 2301339413881290750L, -16384L, 4294967295L, 432345564227567616L };
/*      */ 
/*      */   
/*  529 */   static final long[] jjbitVec4 = new long[] { 0L, 0L, 0L, -36028797027352577L };
/*      */ 
/*      */   
/*  532 */   static final long[] jjbitVec5 = new long[] { 0L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  535 */   static final long[] jjbitVec6 = new long[] { -1L, -1L, 65535L, 0L };
/*      */ 
/*      */   
/*  538 */   static final long[] jjbitVec7 = new long[] { -1L, -1L, 0L, 0L };
/*      */ 
/*      */   
/*  541 */   static final long[] jjbitVec8 = new long[] { 70368744177663L, 0L, 0L, 0L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int jjMoveNfa_1(int startState, int curPos) {
/*  547 */     int startsAt = 0;
/*  548 */     this.jjnewStateCnt = 35;
/*  549 */     int i = 1;
/*  550 */     this.jjstateSet[0] = startState;
/*  551 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  554 */       if (++this.jjround == Integer.MAX_VALUE)
/*  555 */         ReInitRounds(); 
/*  556 */       if (this.curChar < '@') {
/*      */         
/*  558 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  561 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  564 */               if ((0x3FF000000000000L & l) != 0L) {
/*      */                 
/*  566 */                 if (kind > 7)
/*  567 */                   kind = 7; 
/*  568 */                 jjCheckNAddStates(0, 4); break;
/*      */               } 
/*  570 */               if ((0x1800000000L & l) != 0L) {
/*      */                 
/*  572 */                 if (kind > 49)
/*  573 */                   kind = 49; 
/*  574 */                 jjCheckNAdd(6); break;
/*      */               } 
/*  576 */               if (this.curChar == '\'') {
/*  577 */                 jjCheckNAddStates(5, 9); break;
/*  578 */               }  if (this.curChar == '"') {
/*  579 */                 jjCheckNAddStates(10, 14); break;
/*  580 */               }  if (this.curChar == '.')
/*  581 */                 jjCheckNAdd(1); 
/*      */               break;
/*      */             case 1:
/*  584 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  586 */               if (kind > 8)
/*  587 */                 kind = 8; 
/*  588 */               jjCheckNAddTwoStates(1, 2);
/*      */               break;
/*      */             case 3:
/*  591 */               if ((0x280000000000L & l) != 0L)
/*  592 */                 jjCheckNAdd(4); 
/*      */               break;
/*      */             case 4:
/*  595 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  597 */               if (kind > 8)
/*  598 */                 kind = 8; 
/*  599 */               jjCheckNAdd(4);
/*      */               break;
/*      */             case 5:
/*  602 */               if ((0x1800000000L & l) == 0L)
/*      */                 break; 
/*  604 */               if (kind > 49)
/*  605 */                 kind = 49; 
/*  606 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 6:
/*  609 */               if ((0x3FF001000000000L & l) == 0L)
/*      */                 break; 
/*  611 */               if (kind > 49)
/*  612 */                 kind = 49; 
/*  613 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 7:
/*  616 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  618 */               if (kind > 7)
/*  619 */                 kind = 7; 
/*  620 */               jjCheckNAddStates(0, 4);
/*      */               break;
/*      */             case 8:
/*  623 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  625 */               if (kind > 7)
/*  626 */                 kind = 7; 
/*  627 */               jjCheckNAdd(8);
/*      */               break;
/*      */             case 9:
/*  630 */               if ((0x3FF000000000000L & l) != 0L)
/*  631 */                 jjCheckNAddTwoStates(9, 10); 
/*      */               break;
/*      */             case 10:
/*  634 */               if (this.curChar != '.')
/*      */                 break; 
/*  636 */               if (kind > 8)
/*  637 */                 kind = 8; 
/*  638 */               jjCheckNAddTwoStates(11, 12);
/*      */               break;
/*      */             case 11:
/*  641 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  643 */               if (kind > 8)
/*  644 */                 kind = 8; 
/*  645 */               jjCheckNAddTwoStates(11, 12);
/*      */               break;
/*      */             case 13:
/*  648 */               if ((0x280000000000L & l) != 0L)
/*  649 */                 jjCheckNAdd(14); 
/*      */               break;
/*      */             case 14:
/*  652 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  654 */               if (kind > 8)
/*  655 */                 kind = 8; 
/*  656 */               jjCheckNAdd(14);
/*      */               break;
/*      */             case 15:
/*  659 */               if ((0x3FF000000000000L & l) != 0L)
/*  660 */                 jjCheckNAddTwoStates(15, 16); 
/*      */               break;
/*      */             case 17:
/*  663 */               if ((0x280000000000L & l) != 0L)
/*  664 */                 jjCheckNAdd(18); 
/*      */               break;
/*      */             case 18:
/*  667 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  669 */               if (kind > 8)
/*  670 */                 kind = 8; 
/*  671 */               jjCheckNAdd(18);
/*      */               break;
/*      */             case 19:
/*  674 */               if (this.curChar == '"')
/*  675 */                 jjCheckNAddStates(10, 14); 
/*      */               break;
/*      */             case 20:
/*  678 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  679 */                 jjCheckNAddStates(15, 17); 
/*      */               break;
/*      */             case 22:
/*  682 */               if (this.curChar == '"')
/*  683 */                 jjCheckNAddStates(15, 17); 
/*      */               break;
/*      */             case 23:
/*  686 */               if (this.curChar == '"' && kind > 10)
/*  687 */                 kind = 10; 
/*      */               break;
/*      */             case 24:
/*  690 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  691 */                 jjCheckNAddTwoStates(24, 25); 
/*      */               break;
/*      */             case 26:
/*  694 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L && kind > 11)
/*  695 */                 kind = 11; 
/*      */               break;
/*      */             case 27:
/*  698 */               if (this.curChar == '\'')
/*  699 */                 jjCheckNAddStates(5, 9); 
/*      */               break;
/*      */             case 28:
/*  702 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  703 */                 jjCheckNAddStates(18, 20); 
/*      */               break;
/*      */             case 30:
/*  706 */               if (this.curChar == '\'')
/*  707 */                 jjCheckNAddStates(18, 20); 
/*      */               break;
/*      */             case 31:
/*  710 */               if (this.curChar == '\'' && kind > 10)
/*  711 */                 kind = 10; 
/*      */               break;
/*      */             case 32:
/*  714 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  715 */                 jjCheckNAddTwoStates(32, 33); 
/*      */               break;
/*      */             case 34:
/*  718 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L && kind > 11) {
/*  719 */                 kind = 11;
/*      */               }
/*      */               break;
/*      */           } 
/*  723 */         } while (i != startsAt);
/*      */       }
/*  725 */       else if (this.curChar < '') {
/*      */         
/*  727 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  730 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 6:
/*  734 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  736 */               if (kind > 49)
/*  737 */                 kind = 49; 
/*  738 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 2:
/*  741 */               if ((0x2000000020L & l) != 0L)
/*  742 */                 jjAddStates(21, 22); 
/*      */               break;
/*      */             case 12:
/*  745 */               if ((0x2000000020L & l) != 0L)
/*  746 */                 jjAddStates(23, 24); 
/*      */               break;
/*      */             case 16:
/*  749 */               if ((0x2000000020L & l) != 0L)
/*  750 */                 jjAddStates(25, 26); 
/*      */               break;
/*      */             case 20:
/*  753 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  754 */                 jjCheckNAddStates(15, 17); 
/*      */               break;
/*      */             case 21:
/*  757 */               if (this.curChar == '\\')
/*  758 */                 this.jjstateSet[this.jjnewStateCnt++] = 22; 
/*      */               break;
/*      */             case 22:
/*  761 */               if (this.curChar == '\\')
/*  762 */                 jjCheckNAddStates(15, 17); 
/*      */               break;
/*      */             case 24:
/*  765 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  766 */                 jjAddStates(27, 28); 
/*      */               break;
/*      */             case 25:
/*  769 */               if (this.curChar == '\\')
/*  770 */                 this.jjstateSet[this.jjnewStateCnt++] = 26; 
/*      */               break;
/*      */             case 26:
/*      */             case 34:
/*  774 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L && kind > 11)
/*  775 */                 kind = 11; 
/*      */               break;
/*      */             case 28:
/*  778 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  779 */                 jjCheckNAddStates(18, 20); 
/*      */               break;
/*      */             case 29:
/*  782 */               if (this.curChar == '\\')
/*  783 */                 this.jjstateSet[this.jjnewStateCnt++] = 30; 
/*      */               break;
/*      */             case 30:
/*  786 */               if (this.curChar == '\\')
/*  787 */                 jjCheckNAddStates(18, 20); 
/*      */               break;
/*      */             case 32:
/*  790 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  791 */                 jjAddStates(29, 30); 
/*      */               break;
/*      */             case 33:
/*  794 */               if (this.curChar == '\\') {
/*  795 */                 this.jjstateSet[this.jjnewStateCnt++] = 34;
/*      */               }
/*      */               break;
/*      */           } 
/*  799 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  803 */         int hiByte = this.curChar >> 8;
/*  804 */         int i1 = hiByte >> 6;
/*  805 */         long l1 = 1L << (hiByte & 0x3F);
/*  806 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  807 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  810 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 6:
/*  814 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/*  816 */               if (kind > 49)
/*  817 */                 kind = 49; 
/*  818 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 20:
/*  821 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*  822 */                 jjAddStates(15, 17); 
/*      */               break;
/*      */             case 24:
/*  825 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*  826 */                 jjAddStates(27, 28); 
/*      */               break;
/*      */             case 26:
/*      */             case 34:
/*  830 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2) && kind > 11)
/*  831 */                 kind = 11; 
/*      */               break;
/*      */             case 28:
/*  834 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*  835 */                 jjAddStates(18, 20); 
/*      */               break;
/*      */             case 32:
/*  838 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  839 */                 jjAddStates(29, 30);
/*      */               }
/*      */               break;
/*      */           } 
/*  843 */         } while (i != startsAt);
/*      */       } 
/*  845 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  847 */         this.jjmatchedKind = kind;
/*  848 */         this.jjmatchedPos = curPos;
/*  849 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  851 */       curPos++;
/*  852 */       if ((i = this.jjnewStateCnt) == (startsAt = 35 - (this.jjnewStateCnt = startsAt)))
/*  853 */         return curPos;  
/*  854 */       try { this.curChar = this.input_stream.readChar(); }
/*  855 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*  858 */   } static final int[] jjnextStates = new int[] { 8, 9, 10, 15, 16, 28, 29, 31, 32, 33, 20, 21, 23, 24, 25, 20, 21, 23, 28, 29, 31, 3, 4, 13, 14, 17, 18, 24, 25, 32, 33 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/*  864 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/*  867 */         return ((jjbitVec2[i2] & l2) != 0L);
/*      */     } 
/*  869 */     if ((jjbitVec0[i1] & l1) != 0L)
/*  870 */       return true; 
/*  871 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2) {
/*  876 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/*  879 */         return ((jjbitVec4[i2] & l2) != 0L);
/*      */       case 48:
/*  881 */         return ((jjbitVec5[i2] & l2) != 0L);
/*      */       case 49:
/*  883 */         return ((jjbitVec6[i2] & l2) != 0L);
/*      */       case 51:
/*  885 */         return ((jjbitVec7[i2] & l2) != 0L);
/*      */       case 61:
/*  887 */         return ((jjbitVec8[i2] & l2) != 0L);
/*      */     } 
/*  889 */     if ((jjbitVec3[i1] & l1) != 0L)
/*  890 */       return true; 
/*  891 */     return false;
/*      */   }
/*      */   
/*  894 */   public static final String[] jjstrLiteralImages = new String[] { "", null, "${", null, null, null, null, null, null, null, null, null, "true", "false", "null", "}", ".", ">", "gt", "<", "lt", "==", "eq", "<=", "le", ">=", "ge", "!=", "ne", "(", ")", ",", ":", "[", "]", "+", "-", "*", "/", "div", "%", "mod", "not", "!", "and", "&&", "or", "||", "empty", null, null, null, null, null };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  901 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_EXPRESSION" };
/*      */ 
/*      */ 
/*      */   
/*  905 */   public static final int[] jjnewLexState = new int[] { -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  910 */   static final long[] jjtoToken = new long[] { 10133099161582983L };
/*      */ 
/*      */   
/*  913 */   static final long[] jjtoSkip = new long[] { 120L };
/*      */   
/*      */   private SimpleCharStream input_stream;
/*      */   
/*  917 */   private final int[] jjrounds = new int[35];
/*  918 */   private final int[] jjstateSet = new int[70];
/*      */   protected char curChar;
/*      */   int curLexState;
/*      */   int defaultLexState;
/*      */   int jjnewStateCnt;
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public ELParserTokenManager(SimpleCharStream stream, int lexState) {
/*  928 */     this(stream);
/*  929 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/*  933 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/*  934 */     this.curLexState = this.defaultLexState;
/*  935 */     this.input_stream = stream;
/*  936 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */   
/*      */   private final void ReInitRounds() {
/*  941 */     this.jjround = -2147483647;
/*  942 */     for (int i = 35; i-- > 0;)
/*  943 */       this.jjrounds[i] = Integer.MIN_VALUE; 
/*      */   }
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/*  947 */     ReInit(stream);
/*  948 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */   public void SwitchTo(int lexState) {
/*  952 */     if (lexState >= 2 || lexState < 0) {
/*  953 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/*  955 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */   
/*      */   private final Token jjFillToken() {
/*  960 */     Token t = Token.newToken(this.jjmatchedKind);
/*  961 */     t.kind = this.jjmatchedKind;
/*  962 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/*  963 */     t.image = (im == null) ? this.input_stream.GetImage() : im;
/*  964 */     t.beginLine = this.input_stream.getBeginLine();
/*  965 */     t.beginColumn = this.input_stream.getBeginColumn();
/*  966 */     t.endLine = this.input_stream.getEndLine();
/*  967 */     t.endColumn = this.input_stream.getEndColumn();
/*  968 */     return t;
/*      */   }
/*      */   public ELParserTokenManager(SimpleCharStream stream) {
/*  971 */     this.curLexState = 0;
/*  972 */     this.defaultLexState = 0;
/*      */     this.input_stream = stream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Token getNextToken() {
/*  981 */     Token specialToken = null;
/*      */     
/*  983 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/*  990 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/*  992 */       catch (IOException e) {
/*      */         
/*  994 */         this.jjmatchedKind = 0;
/*  995 */         Token matchedToken = jjFillToken();
/*  996 */         return matchedToken;
/*      */       } 
/*      */       
/*  999 */       switch (this.curLexState) {
/*      */         
/*      */         case 0:
/* 1002 */           this.jjmatchedKind = Integer.MAX_VALUE;
/* 1003 */           this.jjmatchedPos = 0;
/* 1004 */           curPos = jjMoveStringLiteralDfa0_0(); break;
/*      */         case 1:
/*      */           
/* 1007 */           try { this.input_stream.backup(0);
/* 1008 */             while (this.curChar <= ' ' && (0x100002600L & 1L << this.curChar) != 0L) {
/* 1009 */               this.curChar = this.input_stream.BeginToken();
/*      */             } }
/* 1011 */           catch (IOException e1) { continue; }
/* 1012 */            this.jjmatchedKind = Integer.MAX_VALUE;
/* 1013 */           this.jjmatchedPos = 0;
/* 1014 */           curPos = jjMoveStringLiteralDfa0_1();
/* 1015 */           if (this.jjmatchedPos == 0 && this.jjmatchedKind > 53)
/*      */           {
/* 1017 */             this.jjmatchedKind = 53;
/*      */           }
/*      */           break;
/*      */       } 
/* 1021 */       if (this.jjmatchedKind != Integer.MAX_VALUE) {
/*      */         
/* 1023 */         if (this.jjmatchedPos + 1 < curPos)
/* 1024 */           this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1025 */         if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */           
/* 1027 */           Token matchedToken = jjFillToken();
/* 1028 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1029 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1030 */           return matchedToken;
/*      */         } 
/*      */ 
/*      */         
/* 1034 */         if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1035 */           this.curLexState = jjnewLexState[this.jjmatchedKind];  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1039 */     int error_line = this.input_stream.getEndLine();
/* 1040 */     int error_column = this.input_stream.getEndColumn();
/* 1041 */     String error_after = null;
/* 1042 */     boolean EOFSeen = false; try {
/* 1043 */       this.input_stream.readChar(); this.input_stream.backup(1);
/* 1044 */     } catch (IOException e1) {
/* 1045 */       EOFSeen = true;
/* 1046 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/* 1047 */       if (this.curChar == '\n' || this.curChar == '\r') {
/* 1048 */         error_line++;
/* 1049 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1052 */         error_column++;
/*      */       } 
/* 1054 */     }  if (!EOFSeen) {
/* 1055 */       this.input_stream.backup(1);
/* 1056 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/*      */     } 
/* 1058 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\parser\ELParserTokenManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */