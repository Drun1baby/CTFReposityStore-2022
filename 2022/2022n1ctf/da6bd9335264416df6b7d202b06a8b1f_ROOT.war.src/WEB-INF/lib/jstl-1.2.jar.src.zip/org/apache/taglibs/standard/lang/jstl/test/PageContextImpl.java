/*     */ package org.apache.taglibs.standard.lang.jstl.test;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.el.ELContext;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.el.ExpressionEvaluator;
/*     */ import javax.servlet.jsp.el.VariableResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageContextImpl
/*     */   extends PageContext
/*     */ {
/*  64 */   Map mPage = Collections.synchronizedMap(new HashMap<Object, Object>());
/*  65 */   Map mRequest = Collections.synchronizedMap(new HashMap<Object, Object>());
/*  66 */   Map mSession = Collections.synchronizedMap(new HashMap<Object, Object>());
/*  67 */   Map mApp = Collections.synchronizedMap(new HashMap<Object, Object>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Servlet servlet, ServletRequest request, ServletResponse response, String errorPageURL, boolean needSession, int bufferSize, boolean autoFlush) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object attribute) {
/* 100 */     this.mPage.put(name, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, Object attribute, int scope) {
/* 108 */     switch (scope) {
/*     */       case 1:
/* 110 */         this.mPage.put(name, attribute);
/*     */         return;
/*     */       case 2:
/* 113 */         this.mRequest.put(name, attribute);
/*     */         return;
/*     */       case 3:
/* 116 */         this.mSession.put(name, attribute);
/*     */         return;
/*     */       case 4:
/* 119 */         this.mApp.put(name, attribute);
/*     */         return;
/*     */     } 
/* 122 */     throw new IllegalArgumentException("Bad scope " + scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name) {
/* 129 */     return this.mPage.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String name, int scope) {
/* 136 */     switch (scope) {
/*     */       case 1:
/* 138 */         return this.mPage.get(name);
/*     */       case 2:
/* 140 */         return this.mRequest.get(name);
/*     */       case 3:
/* 142 */         return this.mSession.get(name);
/*     */       case 4:
/* 144 */         return this.mApp.get(name);
/*     */     } 
/* 146 */     throw new IllegalArgumentException("Bad scope " + scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findAttribute(String name) {
/* 153 */     if (this.mPage.containsKey(name)) {
/* 154 */       return this.mPage.get(name);
/*     */     }
/* 156 */     if (this.mRequest.containsKey(name)) {
/* 157 */       return this.mRequest.get(name);
/*     */     }
/* 159 */     if (this.mSession.containsKey(name)) {
/* 160 */       return this.mSession.get(name);
/*     */     }
/* 162 */     if (this.mApp.containsKey(name)) {
/* 163 */       return this.mApp.get(name);
/*     */     }
/*     */     
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 173 */     if (this.mPage.containsKey(name)) {
/* 174 */       this.mPage.remove(name);
/*     */     }
/* 176 */     else if (this.mRequest.containsKey(name)) {
/* 177 */       this.mRequest.remove(name);
/*     */     }
/* 179 */     else if (this.mSession.containsKey(name)) {
/* 180 */       this.mSession.remove(name);
/*     */     }
/* 182 */     else if (this.mApp.containsKey(name)) {
/* 183 */       this.mApp.remove(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name, int scope) {
/* 191 */     switch (scope) {
/*     */       case 1:
/* 193 */         this.mPage.remove(name);
/*     */         return;
/*     */       case 2:
/* 196 */         this.mRequest.remove(name);
/*     */         return;
/*     */       case 3:
/* 199 */         this.mSession.remove(name);
/*     */         return;
/*     */       case 4:
/* 202 */         this.mApp.remove(name);
/*     */         return;
/*     */     } 
/* 205 */     throw new IllegalArgumentException("Bad scope " + scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttributesScope(String name) {
/* 212 */     if (this.mPage.containsKey(name)) {
/* 213 */       return 1;
/*     */     }
/* 215 */     if (this.mRequest.containsKey(name)) {
/* 216 */       return 2;
/*     */     }
/* 218 */     if (this.mSession.containsKey(name)) {
/* 219 */       return 3;
/*     */     }
/* 221 */     if (this.mApp.containsKey(name)) {
/* 222 */       return 4;
/*     */     }
/*     */     
/* 225 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration getAttributeNamesInScope(int scope) {
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JspWriter getOut() {
/* 238 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpSession getSession() {
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPage() {
/* 250 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletRequest getRequest() {
/* 256 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletResponse getResponse() {
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Exception getException() {
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletConfig getServletConfig() {
/* 274 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletContext getServletContext() {
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forward(String path) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void include(String path) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlePageException(Exception exc) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void handlePageException(Throwable exc) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void include(String relativeUrlPath, boolean flush) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionEvaluator getExpressionEvaluator() {
/* 307 */     return null; } public VariableResolver getVariableResolver() {
/* 308 */     return null;
/*     */   }
/*     */   public ELContext getELContext() {
/* 311 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\PageContextImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */