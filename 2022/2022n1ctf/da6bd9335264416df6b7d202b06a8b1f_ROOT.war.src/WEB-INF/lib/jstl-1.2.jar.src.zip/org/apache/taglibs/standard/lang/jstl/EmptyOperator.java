/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmptyOperator
/*     */   extends UnaryOperator
/*     */ {
/*  47 */   public static final EmptyOperator SINGLETON = new EmptyOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  68 */     return "empty";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pValue, Object pContext, Logger pLogger) throws ELException {
/*  82 */     if (pValue == null) {
/*  83 */       return PrimitiveObjects.getBoolean(true);
/*     */     }
/*     */ 
/*     */     
/*  87 */     if ("".equals(pValue)) {
/*  88 */       return PrimitiveObjects.getBoolean(true);
/*     */     }
/*     */ 
/*     */     
/*  92 */     if (pValue.getClass().isArray() && Array.getLength(pValue) == 0)
/*     */     {
/*  94 */       return PrimitiveObjects.getBoolean(true);
/*     */     }
/*     */ 
/*     */     
/*  98 */     if (pValue instanceof List && ((List)pValue).isEmpty())
/*     */     {
/* 100 */       return PrimitiveObjects.getBoolean(true);
/*     */     }
/*     */ 
/*     */     
/* 104 */     if (pValue instanceof Map && ((Map)pValue).isEmpty())
/*     */     {
/* 106 */       return PrimitiveObjects.getBoolean(true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 111 */     return PrimitiveObjects.getBoolean(false);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\EmptyOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */