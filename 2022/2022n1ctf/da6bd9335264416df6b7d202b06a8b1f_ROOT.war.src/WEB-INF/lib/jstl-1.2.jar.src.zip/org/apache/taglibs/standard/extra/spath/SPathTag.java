/*    */ package org.apache.taglibs.standard.extra.spath;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.TagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SPathTag
/*    */   extends TagSupport
/*    */ {
/*    */   private String select;
/*    */   private String var;
/*    */   
/*    */   public SPathTag() {
/* 56 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   private void init() {
/* 61 */     this.select = this.var = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int doStartTag() throws JspException {
/*    */     try {
/* 71 */       SPathFilter s = new SPathFilter((new SPathParser(this.select)).expression());
/* 72 */       this.pageContext.setAttribute(this.var, s);
/* 73 */       return 0;
/* 74 */     } catch (ParseException ex) {
/* 75 */       throw new JspTagException(ex.toString(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 81 */     super.release();
/* 82 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelect(String select) {
/* 90 */     this.select = select;
/*    */   }
/*    */   
/*    */   public void setVar(String var) {
/* 94 */     this.var = var;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\SPathTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */