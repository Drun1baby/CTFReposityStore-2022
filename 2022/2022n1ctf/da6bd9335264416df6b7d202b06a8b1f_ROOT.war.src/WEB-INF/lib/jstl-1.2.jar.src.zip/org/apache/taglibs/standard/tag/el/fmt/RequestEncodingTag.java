/*     */ package org.apache.taglibs.standard.tag.el.fmt;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.RequestEncodingSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestEncodingTag
/*     */   extends RequestEncodingSupport
/*     */ {
/*     */   private String value_;
/*     */   
/*     */   public RequestEncodingTag() {
/*  58 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  69 */     evaluateExpressions();
/*     */ 
/*     */     
/*  72 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  77 */     super.release();
/*  78 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  87 */     this.value_ = value_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/*  97 */     this.value_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 110 */     if (this.value_ != null)
/* 111 */       this.value = (String)ExpressionEvaluatorManager.evaluate("value", this.value_, String.class, (Tag)this, this.pageContext); 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\fmt\RequestEncodingTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */