/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FormatNumberSupport
/*     */   extends BodyTagSupport
/*     */ {
/*  55 */   private static final Class[] GET_INSTANCE_PARAM_TYPES = new Class[] { String.class };
/*     */   
/*     */   private static final String NUMBER = "number";
/*     */   
/*     */   private static final String CURRENCY = "currency";
/*     */   
/*     */   private static final String PERCENT = "percent";
/*     */   
/*     */   protected Object value;
/*     */   
/*     */   protected boolean valueSpecified;
/*     */   
/*     */   protected String type;
/*     */   
/*     */   protected String pattern;
/*     */   
/*     */   protected String currencyCode;
/*     */   
/*     */   protected String currencySymbol;
/*     */   
/*     */   protected boolean isGroupingUsed;
/*     */   
/*     */   protected boolean groupingUsedSpecified;
/*     */   
/*     */   protected int maxIntegerDigits;
/*     */   
/*     */   protected boolean maxIntegerDigitsSpecified;
/*     */   
/*     */   protected int minIntegerDigits;
/*     */   
/*     */   protected boolean minIntegerDigitsSpecified;
/*     */   protected int maxFractionDigits;
/*     */   protected boolean maxFractionDigitsSpecified;
/*     */   protected int minFractionDigits;
/*     */   protected boolean minFractionDigitsSpecified;
/*     */   private String var;
/*     */   private int scope;
/*     */   private static Class currencyClass;
/*     */   
/*     */   static {
/*     */     try {
/*  96 */       currencyClass = Class.forName("java.util.Currency");
/*     */     }
/*  98 */     catch (Exception cnfe) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatNumberSupport() {
/* 104 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/* 108 */     this.value = this.type = null;
/* 109 */     this.valueSpecified = false;
/* 110 */     this.pattern = this.var = this.currencyCode = this.currencySymbol = null;
/* 111 */     this.groupingUsedSpecified = false;
/* 112 */     this.maxIntegerDigitsSpecified = this.minIntegerDigitsSpecified = false;
/* 113 */     this.maxFractionDigitsSpecified = this.minFractionDigitsSpecified = false;
/* 114 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 122 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 126 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 134 */     String formatted = null;
/* 135 */     Object input = null;
/*     */ 
/*     */     
/* 138 */     if (this.valueSpecified) {
/*     */       
/* 140 */       input = this.value;
/*     */     
/*     */     }
/* 143 */     else if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 144 */       input = this.bodyContent.getString().trim();
/*     */     } 
/*     */     
/* 147 */     if (input == null || input.equals("")) {
/*     */ 
/*     */ 
/*     */       
/* 151 */       if (this.var != null) {
/* 152 */         this.pageContext.removeAttribute(this.var, this.scope);
/*     */       }
/* 154 */       return 6;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (input instanceof String) {
/*     */       try {
/* 163 */         if (((String)input).indexOf('.') != -1) {
/* 164 */           input = Double.valueOf((String)input);
/*     */         } else {
/* 166 */           input = Long.valueOf((String)input);
/*     */         } 
/* 168 */       } catch (NumberFormatException nfe) {
/* 169 */         throw new JspException(Resources.getMessage("FORMAT_NUMBER_PARSE_ERROR", input), nfe);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     Locale loc = SetLocaleSupport.getFormattingLocale(this.pageContext, (Tag)this, true, NumberFormat.getAvailableLocales());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     if (loc != null) {
/*     */       
/* 184 */       NumberFormat formatter = null;
/* 185 */       if (this.pattern != null && !this.pattern.equals("")) {
/*     */         
/* 187 */         DecimalFormatSymbols symbols = new DecimalFormatSymbols(loc);
/* 188 */         formatter = new DecimalFormat(this.pattern, symbols);
/*     */       } else {
/* 190 */         formatter = createFormatter(loc);
/*     */       } 
/* 192 */       if ((this.pattern != null && !this.pattern.equals("")) || "currency".equalsIgnoreCase(this.type)) {
/*     */         
/*     */         try {
/* 195 */           setCurrency(formatter);
/* 196 */         } catch (Exception e) {
/* 197 */           throw new JspException(Resources.getMessage("FORMAT_NUMBER_CURRENCY_ERROR"), e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 202 */       configureFormatter(formatter);
/* 203 */       formatted = formatter.format(input);
/*     */     } else {
/*     */       
/* 206 */       formatted = input.toString();
/*     */     } 
/*     */     
/* 209 */     if (this.var != null) {
/* 210 */       this.pageContext.setAttribute(this.var, formatted, this.scope);
/*     */     } else {
/*     */       try {
/* 213 */         this.pageContext.getOut().print(formatted);
/* 214 */       } catch (IOException ioe) {
/* 215 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 224 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NumberFormat createFormatter(Locale loc) throws JspException {
/* 232 */     NumberFormat formatter = null;
/*     */     
/* 234 */     if (this.type == null || "number".equalsIgnoreCase(this.type)) {
/* 235 */       formatter = NumberFormat.getNumberInstance(loc);
/* 236 */     } else if ("currency".equalsIgnoreCase(this.type)) {
/* 237 */       formatter = NumberFormat.getCurrencyInstance(loc);
/* 238 */     } else if ("percent".equalsIgnoreCase(this.type)) {
/* 239 */       formatter = NumberFormat.getPercentInstance(loc);
/*     */     } else {
/* 241 */       throw new JspException(Resources.getMessage("FORMAT_NUMBER_INVALID_TYPE", this.type));
/*     */     } 
/*     */ 
/*     */     
/* 245 */     return formatter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureFormatter(NumberFormat formatter) {
/* 254 */     if (this.groupingUsedSpecified)
/* 255 */       formatter.setGroupingUsed(this.isGroupingUsed); 
/* 256 */     if (this.maxIntegerDigitsSpecified)
/* 257 */       formatter.setMaximumIntegerDigits(this.maxIntegerDigits); 
/* 258 */     if (this.minIntegerDigitsSpecified)
/* 259 */       formatter.setMinimumIntegerDigits(this.minIntegerDigits); 
/* 260 */     if (this.maxFractionDigitsSpecified)
/* 261 */       formatter.setMaximumFractionDigits(this.maxFractionDigits); 
/* 262 */     if (this.minFractionDigitsSpecified) {
/* 263 */       formatter.setMinimumFractionDigits(this.minFractionDigits);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCurrency(NumberFormat formatter) throws Exception {
/* 295 */     String code = null;
/* 296 */     String symbol = null;
/*     */     
/* 298 */     if (this.currencyCode == null && this.currencySymbol == null) {
/*     */       return;
/*     */     }
/*     */     
/* 302 */     if (this.currencyCode != null && this.currencySymbol != null) {
/* 303 */       if (currencyClass != null)
/* 304 */       { code = this.currencyCode; }
/*     */       else
/* 306 */       { symbol = this.currencySymbol; } 
/* 307 */     } else if (this.currencyCode == null) {
/* 308 */       symbol = this.currencySymbol;
/*     */     }
/* 310 */     else if (currencyClass != null) {
/* 311 */       code = this.currencyCode;
/*     */     } else {
/* 313 */       symbol = this.currencyCode;
/*     */     } 
/*     */     
/* 316 */     if (code != null) {
/* 317 */       Object[] methodArgs = new Object[1];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 322 */       Method m = currencyClass.getMethod("getInstance", GET_INSTANCE_PARAM_TYPES);
/*     */       
/* 324 */       methodArgs[0] = code;
/* 325 */       Object currency = m.invoke(null, methodArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       Class[] paramTypes = new Class[1];
/* 331 */       paramTypes[0] = currencyClass;
/* 332 */       Class<?> numberFormatClass = Class.forName("java.text.NumberFormat");
/* 333 */       m = numberFormatClass.getMethod("setCurrency", paramTypes);
/* 334 */       methodArgs[0] = currency;
/* 335 */       m.invoke(formatter, methodArgs);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 341 */       DecimalFormat df = (DecimalFormat)formatter;
/* 342 */       DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
/* 343 */       dfs.setCurrencySymbol(symbol);
/* 344 */       df.setDecimalFormatSymbols(dfs);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\FormatNumberSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */