/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSTLXPathNamespaceContext
/*     */   implements NamespaceContext
/*     */ {
/*     */   HashMap namespaces;
/*     */   
/*     */   public JSTLXPathNamespaceContext() {
/*  47 */     this.namespaces = new HashMap<Object, Object>();
/*     */   }
/*     */   
/*     */   public JSTLXPathNamespaceContext(HashMap nses) {
/*  51 */     this.namespaces = nses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI(String prefix) throws IllegalArgumentException {
/*  72 */     if (prefix == null) {
/*  73 */       throw new IllegalArgumentException("Cannot get Namespace URI for null prefix");
/*     */     }
/*     */     
/*  76 */     if (prefix.equals("xml")) {
/*  77 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/*  79 */     if (prefix.equals("xmlns")) {
/*  80 */       return "http://www.w3.org/2000/xmlns/";
/*     */     }
/*     */     
/*  83 */     String namespaceURI = (String)this.namespaces.get(prefix);
/*     */     
/*  85 */     if (namespaceURI != null) {
/*  86 */       return namespaceURI;
/*     */     }
/*     */     
/*  89 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix(String namespaceURI) {
/* 103 */     if (namespaceURI == null) {
/* 104 */       throw new IllegalArgumentException("Cannot get prefix for null NamespaceURI");
/*     */     }
/*     */     
/* 107 */     if (namespaceURI.equals("http://www.w3.org/XML/1998/namespace")) {
/* 108 */       return "xml";
/*     */     }
/* 110 */     if (namespaceURI.equals("http://www.w3.org/2000/xmlns/")) {
/* 111 */       return "xmlns";
/*     */     }
/*     */     
/* 114 */     Iterator<String> iter = this.namespaces.keySet().iterator();
/* 115 */     while (iter.hasNext()) {
/* 116 */       String key = iter.next();
/* 117 */       String value = (String)this.namespaces.get(key);
/* 118 */       if (value.equals(namespaceURI))
/*     */       {
/* 120 */         return value;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getPrefixes(String namespaceURI) {
/* 139 */     if (namespaceURI == null) {
/* 140 */       throw new IllegalArgumentException("Cannot get prefix for null NamespaceURI");
/*     */     }
/*     */     
/* 143 */     if (namespaceURI.equals("http://www.w3.org/XML/1998/namespace")) {
/* 144 */       return Arrays.<String>asList(new String[] { "xml" }).iterator();
/*     */     }
/* 146 */     if (namespaceURI.equals("http://www.w3.org/2000/xmlns/")) {
/* 147 */       return Arrays.<String>asList(new String[] { "xmlns" }).iterator();
/*     */     }
/*     */     
/* 150 */     ArrayList<String> prefixList = new ArrayList();
/* 151 */     Iterator<String> iter = this.namespaces.keySet().iterator();
/* 152 */     while (iter.hasNext()) {
/* 153 */       String key = iter.next();
/* 154 */       String value = (String)this.namespaces.get(key);
/* 155 */       if (value.equals(namespaceURI)) {
/* 156 */         prefixList.add(key);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 161 */     return prefixList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addNamespace(String prefix, String uri) {
/* 168 */     this.namespaces.put(prefix, uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void p(String s) {
/* 175 */     System.out.println("[JSTLXPathNameContext] " + s);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\JSTLXPathNamespaceContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */