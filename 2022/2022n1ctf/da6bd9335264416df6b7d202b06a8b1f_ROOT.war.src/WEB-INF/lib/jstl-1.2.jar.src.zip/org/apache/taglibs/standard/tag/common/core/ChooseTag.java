/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChooseTag
/*     */   extends TagSupport
/*     */ {
/*     */   private boolean subtagGateClosed;
/*     */   
/*     */   public ChooseTag() {
/*  53 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  58 */     super.release();
/*  59 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean gainPermission() {
/*  79 */     return !this.subtagGateClosed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void subtagSucceeded() {
/*  87 */     if (this.subtagGateClosed) {
/*  88 */       throw new IllegalStateException(Resources.getMessage("CHOOSE_EXCLUSIVITY"));
/*     */     }
/*  90 */     this.subtagGateClosed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  99 */     this.subtagGateClosed = false;
/* 100 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 108 */     this.subtagGateClosed = false;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\ChooseTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */