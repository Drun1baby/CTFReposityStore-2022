/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetLocaleTag
/*    */   extends SetLocaleSupport
/*    */ {
/*    */   public void setValue(Object value) throws JspTagException {
/* 46 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVariant(String variant) throws JspTagException {
/* 51 */     this.variant = variant;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\SetLocaleTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */