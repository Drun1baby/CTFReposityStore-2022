/*    */ package org.apache.taglibs.standard.tei;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForEachTEI
/*    */   extends TagExtraInfo
/*    */ {
/*    */   private static final String ITEMS = "items";
/*    */   private static final String BEGIN = "begin";
/*    */   private static final String END = "end";
/*    */   
/*    */   public boolean isValid(TagData us) {
/* 49 */     if (!Util.isSpecified(us, "items") && (
/* 50 */       !Util.isSpecified(us, "begin") || !Util.isSpecified(us, "end")))
/* 51 */       return false; 
/* 52 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tei\ForEachTEI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */