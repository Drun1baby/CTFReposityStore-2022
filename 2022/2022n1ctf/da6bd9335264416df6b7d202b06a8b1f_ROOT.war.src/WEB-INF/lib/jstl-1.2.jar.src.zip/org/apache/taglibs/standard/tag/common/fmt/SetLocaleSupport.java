/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetLocaleSupport
/*     */   extends TagSupport
/*     */ {
/*     */   private static final char HYPHEN = '-';
/*     */   private static final char UNDERSCORE = '_';
/*     */   protected Object value;
/*     */   protected String variant;
/*     */   private int scope;
/*     */   static Locale[] availableFormattingLocales;
/*     */   
/*     */   public SetLocaleSupport() {
/*  81 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  85 */     this.value = this.variant = null;
/*  86 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/*  94 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 102 */     Locale locale = null;
/*     */     
/* 104 */     if (this.value == null) {
/* 105 */       locale = Locale.getDefault();
/* 106 */     } else if (this.value instanceof String) {
/* 107 */       if (((String)this.value).trim().equals("")) {
/* 108 */         locale = Locale.getDefault();
/*     */       } else {
/* 110 */         locale = parseLocale((String)this.value, this.variant);
/*     */       } 
/*     */     } else {
/* 113 */       locale = (Locale)this.value;
/*     */     } 
/*     */     
/* 116 */     Config.set(this.pageContext, "javax.servlet.jsp.jstl.fmt.locale", locale, this.scope);
/* 117 */     setResponseLocale(this.pageContext, locale);
/*     */     
/* 119 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 124 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale parseLocale(String locale) {
/* 135 */     return parseLocale(locale, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale parseLocale(String locale, String variant) {
/* 158 */     Locale ret = null;
/* 159 */     String language = locale;
/* 160 */     String country = null;
/* 161 */     int index = -1;
/*     */     
/* 163 */     if ((index = locale.indexOf('-')) > -1 || (index = locale.indexOf('_')) > -1) {
/*     */       
/* 165 */       language = locale.substring(0, index);
/* 166 */       country = locale.substring(index + 1);
/*     */     } 
/*     */     
/* 169 */     if (language == null || language.length() == 0) {
/* 170 */       throw new IllegalArgumentException(Resources.getMessage("LOCALE_NO_LANGUAGE"));
/*     */     }
/*     */ 
/*     */     
/* 174 */     if (country == null)
/* 175 */     { if (variant != null)
/* 176 */       { ret = new Locale(language, "", variant); }
/*     */       else
/* 178 */       { ret = new Locale(language, ""); }  }
/* 179 */     else if (country.length() > 0)
/* 180 */     { if (variant != null) {
/* 181 */         ret = new Locale(language, country, variant);
/*     */       } else {
/* 183 */         ret = new Locale(language, country);
/*     */       }  }
/* 185 */     else { throw new IllegalArgumentException(Resources.getMessage("LOCALE_EMPTY_COUNTRY")); }
/*     */ 
/*     */ 
/*     */     
/* 189 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setResponseLocale(PageContext pc, Locale locale) {
/* 212 */     ServletResponse response = pc.getResponse();
/* 213 */     response.setLocale(locale);
/*     */ 
/*     */     
/* 216 */     if (pc.getSession() != null) {
/*     */       try {
/* 218 */         pc.setAttribute("javax.servlet.jsp.jstl.fmt.request.charset", response.getCharacterEncoding(), 3);
/*     */       
/*     */       }
/* 221 */       catch (IllegalStateException ex) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Locale getFormattingLocale(PageContext pc, Tag fromTag, boolean format, Locale[] avail) {
/* 245 */     LocalizationContext locCtxt = null;
/*     */ 
/*     */     
/* 248 */     Tag parent = findAncestorWithClass(fromTag, BundleSupport.class);
/* 249 */     if (parent != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       locCtxt = ((BundleSupport)parent).getLocalizationContext();
/* 255 */       if (locCtxt.getLocale() != null) {
/* 256 */         if (format) {
/* 257 */           setResponseLocale(pc, locCtxt.getLocale());
/*     */         }
/* 259 */         return locCtxt.getLocale();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 264 */     if ((locCtxt = BundleSupport.getLocalizationContext(pc)) != null && 
/* 265 */       locCtxt.getLocale() != null) {
/* 266 */       if (format) {
/* 267 */         setResponseLocale(pc, locCtxt.getLocale());
/*     */       }
/* 269 */       return locCtxt.getLocale();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     Locale match = null;
/* 279 */     Locale pref = getLocale(pc, "javax.servlet.jsp.jstl.fmt.locale");
/* 280 */     if (pref != null) {
/*     */       
/* 282 */       match = findFormattingMatch(pref, avail);
/*     */     } else {
/*     */       
/* 285 */       match = findFormattingMatch(pc, avail);
/*     */     } 
/* 287 */     if (match == null) {
/*     */       
/* 289 */       pref = getLocale(pc, "javax.servlet.jsp.jstl.fmt.fallbackLocale");
/* 290 */       if (pref != null) {
/* 291 */         match = findFormattingMatch(pref, avail);
/*     */       }
/*     */     } 
/* 294 */     if (format && match != null) {
/* 295 */       setResponseLocale(pc, match);
/*     */     }
/*     */     
/* 298 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 307 */     Locale[] dateLocales = DateFormat.getAvailableLocales();
/* 308 */     Locale[] numberLocales = NumberFormat.getAvailableLocales();
/* 309 */     Vector<Locale> vec = new Vector(dateLocales.length);
/* 310 */     for (int i = 0; i < dateLocales.length; i++) {
/* 311 */       for (int j = 0; j < numberLocales.length; j++) {
/* 312 */         if (dateLocales[i].equals(numberLocales[j])) {
/* 313 */           vec.add(dateLocales[i]);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 318 */     availableFormattingLocales = new Locale[vec.size()];
/* 319 */     availableFormattingLocales = vec.<Locale>toArray(availableFormattingLocales);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Locale getFormattingLocale(PageContext pc) {
/* 340 */     Locale match = null;
/* 341 */     Locale pref = getLocale(pc, "javax.servlet.jsp.jstl.fmt.locale");
/* 342 */     if (pref != null) {
/*     */       
/* 344 */       match = findFormattingMatch(pref, availableFormattingLocales);
/*     */     } else {
/*     */       
/* 347 */       match = findFormattingMatch(pc, availableFormattingLocales);
/*     */     } 
/* 349 */     if (match == null) {
/*     */       
/* 351 */       pref = getLocale(pc, "javax.servlet.jsp.jstl.fmt.fallbackLocale");
/* 352 */       if (pref != null) {
/* 353 */         match = findFormattingMatch(pref, availableFormattingLocales);
/*     */       }
/*     */     } 
/* 356 */     if (match != null) {
/* 357 */       setResponseLocale(pc, match);
/*     */     }
/*     */     
/* 360 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Locale getLocale(PageContext pageContext, String name) {
/* 382 */     Locale loc = null;
/*     */     
/* 384 */     Object obj = Config.find(pageContext, name);
/* 385 */     if (obj != null) {
/* 386 */       if (obj instanceof Locale) {
/* 387 */         loc = (Locale)obj;
/*     */       } else {
/* 389 */         loc = parseLocale((String)obj);
/*     */       } 
/*     */     }
/*     */     
/* 393 */     return loc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Locale findFormattingMatch(PageContext pageContext, Locale[] avail) {
/* 412 */     Locale match = null;
/* 413 */     Enumeration<Locale> enum_ = Util.getRequestLocales((HttpServletRequest)pageContext.getRequest());
/* 414 */     while (enum_.hasMoreElements()) {
/* 415 */       Locale locale = enum_.nextElement();
/* 416 */       match = findFormattingMatch(locale, avail);
/* 417 */       if (match != null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 422 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Locale findFormattingMatch(Locale pref, Locale[] avail) {
/* 445 */     Locale match = null;
/* 446 */     boolean langAndCountryMatch = false;
/* 447 */     for (int i = 0; i < avail.length; i++) {
/* 448 */       if (pref.equals(avail[i])) {
/*     */         
/* 450 */         match = avail[i]; break;
/*     */       } 
/* 452 */       if (!"".equals(pref.getVariant()) && "".equals(avail[i].getVariant()) && pref.getLanguage().equals(avail[i].getLanguage()) && pref.getCountry().equals(avail[i].getCountry())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 458 */         match = avail[i];
/* 459 */         langAndCountryMatch = true;
/* 460 */       } else if (!langAndCountryMatch && pref.getLanguage().equals(avail[i].getLanguage()) && "".equals(avail[i].getCountry())) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 465 */         if (match == null) {
/* 466 */           match = avail[i];
/*     */         }
/*     */       } 
/*     */     } 
/* 470 */     return match;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\SetLocaleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */