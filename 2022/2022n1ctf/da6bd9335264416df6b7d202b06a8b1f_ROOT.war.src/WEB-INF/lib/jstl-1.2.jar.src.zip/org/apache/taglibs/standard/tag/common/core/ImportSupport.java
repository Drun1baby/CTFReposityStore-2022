/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.TryCatchFinally;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ImportSupport
/*     */   extends BodyTagSupport
/*     */   implements TryCatchFinally, ParamParent
/*     */ {
/*     */   public static final String VALID_SCHEME_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.-";
/*     */   public static final String DEFAULT_ENCODING = "ISO-8859-1";
/*     */   protected String url;
/*     */   protected String context;
/*     */   protected String charEncoding;
/*     */   private String var;
/*     */   private int scope;
/*     */   private String varReader;
/*     */   private Reader r;
/*     */   private boolean isAbsoluteUrl;
/*     */   private ParamSupport.ParamManager params;
/*     */   private String urlWithParams;
/*     */   
/*     */   public ImportSupport() {
/* 115 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/* 119 */     this.url = this.var = this.varReader = this.context = this.charEncoding = this.urlWithParams = null;
/* 120 */     this.params = null;
/* 121 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 131 */     if (this.context != null && (!this.context.startsWith("/") || !this.url.startsWith("/")))
/*     */     {
/* 133 */       throw new JspTagException(Resources.getMessage("IMPORT_BAD_RELATIVE"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 138 */     this.urlWithParams = null;
/* 139 */     this.params = new ParamSupport.ParamManager();
/*     */ 
/*     */     
/* 142 */     if (this.url == null || this.url.equals("")) {
/* 143 */       throw new NullAttributeException("import", "url");
/*     */     }
/*     */     
/* 146 */     this.isAbsoluteUrl = isAbsoluteUrl();
/*     */ 
/*     */     
/*     */     try {
/* 150 */       if (this.varReader != null) {
/* 151 */         this.r = acquireReader();
/* 152 */         this.pageContext.setAttribute(this.varReader, this.r);
/*     */       } 
/* 154 */     } catch (IOException ex) {
/* 155 */       throw new JspTagException(ex.toString(), ex);
/*     */     } 
/*     */     
/* 158 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/* 165 */       if (this.varReader == null)
/*     */       {
/* 167 */         if (this.var != null) {
/* 168 */           this.pageContext.setAttribute(this.var, acquireString(), this.scope);
/*     */         } else {
/*     */           
/* 171 */           this.pageContext.getOut().print(acquireString());
/*     */         }  } 
/* 173 */       return 6;
/* 174 */     } catch (IOException ex) {
/* 175 */       throw new JspTagException(ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doCatch(Throwable t) throws Throwable {
/* 181 */     throw t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFinally() {
/*     */     try {
/* 188 */       if (this.varReader != null) {
/*     */         
/* 190 */         if (this.r != null)
/* 191 */           this.r.close(); 
/* 192 */         this.pageContext.removeAttribute(this.varReader, 1);
/*     */       } 
/* 194 */     } catch (IOException ex) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 201 */     init();
/* 202 */     super.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 209 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setVarReader(String varReader) {
/* 213 */     this.varReader = varReader;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 217 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String name, String value) {
/* 226 */     this.params.addParameter(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String acquireString() throws IOException, JspException {
/* 249 */     if (this.isAbsoluteUrl) {
/*     */       
/* 251 */       BufferedReader r = new BufferedReader(acquireReader());
/* 252 */       StringBuffer sb = new StringBuffer();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */         int i;
/*     */ 
/*     */ 
/*     */         
/* 261 */         while ((i = r.read()) != -1)
/* 262 */           sb.append((char)i); 
/* 263 */       } catch (IOException iox) {
/* 264 */         throw iox;
/*     */       } finally {
/* 266 */         r.close();
/*     */       } 
/*     */       
/* 269 */       return sb.toString();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 274 */     if (!(this.pageContext.getRequest() instanceof HttpServletRequest) || !(this.pageContext.getResponse() instanceof HttpServletResponse))
/*     */     {
/* 276 */       throw new JspTagException(Resources.getMessage("IMPORT_REL_WITHOUT_HTTP"));
/*     */     }
/*     */ 
/*     */     
/* 280 */     ServletContext c = null;
/* 281 */     String targetUrl = targetUrl();
/* 282 */     if (this.context != null) {
/* 283 */       c = this.pageContext.getServletContext().getContext(this.context);
/*     */     } else {
/* 285 */       c = this.pageContext.getServletContext();
/*     */ 
/*     */       
/* 288 */       if (!targetUrl.startsWith("/")) {
/* 289 */         String sp = ((HttpServletRequest)this.pageContext.getRequest()).getServletPath();
/*     */         
/* 291 */         targetUrl = sp.substring(0, sp.lastIndexOf('/')) + '/' + targetUrl;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 296 */     if (c == null) {
/* 297 */       throw new JspTagException(Resources.getMessage("IMPORT_REL_WITHOUT_DISPATCHER", this.context, targetUrl));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     RequestDispatcher rd = c.getRequestDispatcher(stripSession(targetUrl));
/*     */     
/* 305 */     if (rd == null) {
/* 306 */       throw new JspTagException(stripSession(targetUrl));
/*     */     }
/*     */     
/* 309 */     ImportResponseWrapper irw = new ImportResponseWrapper(this.pageContext);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 314 */       rd.include(this.pageContext.getRequest(), (ServletResponse)irw);
/* 315 */     } catch (IOException ex) {
/* 316 */       throw new JspException(ex);
/* 317 */     } catch (RuntimeException ex) {
/* 318 */       throw new JspException(ex);
/* 319 */     } catch (ServletException ex) {
/* 320 */       Throwable rc = ex.getRootCause();
/* 321 */       if (rc == null) {
/* 322 */         throw new JspException(ex);
/*     */       }
/* 324 */       throw new JspException(rc);
/*     */     } 
/*     */ 
/*     */     
/* 328 */     if (irw.getStatus() < 200 || irw.getStatus() > 299) {
/* 329 */       throw new JspTagException(irw.getStatus() + " " + stripSession(targetUrl));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 334 */     return irw.getString();
/*     */   }
/*     */ 
/*     */   
/*     */   private Reader acquireReader() throws IOException, JspException {
/* 339 */     if (!this.isAbsoluteUrl)
/*     */     {
/* 341 */       return new StringReader(acquireString());
/*     */     }
/*     */     
/* 344 */     String target = targetUrl();
/*     */     try {
/*     */       String charSet;
/* 347 */       URL u = new URL(target);
/* 348 */       URLConnection uc = u.openConnection();
/* 349 */       InputStream i = uc.getInputStream();
/*     */ 
/*     */       
/* 352 */       Reader r = null;
/*     */       
/* 354 */       if (this.charEncoding != null && !this.charEncoding.equals("")) {
/* 355 */         charSet = this.charEncoding;
/*     */       } else {
/*     */         
/* 358 */         String contentType = uc.getContentType();
/* 359 */         if (contentType != null) {
/* 360 */           charSet = Util.getContentTypeAttribute(contentType, "charset");
/* 361 */           if (charSet == null) charSet = "ISO-8859-1"; 
/*     */         } else {
/* 363 */           charSet = "ISO-8859-1";
/*     */         } 
/*     */       } 
/*     */       try {
/* 367 */         r = new InputStreamReader(i, charSet);
/* 368 */       } catch (Exception ex) {
/* 369 */         r = new InputStreamReader(i, "ISO-8859-1");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 374 */       if (uc instanceof HttpURLConnection) {
/* 375 */         int status = ((HttpURLConnection)uc).getResponseCode();
/* 376 */         if (status < 200 || status > 299)
/* 377 */           throw new JspTagException(status + " " + target); 
/*     */       } 
/* 379 */       return r;
/* 380 */     } catch (IOException ex) {
/* 381 */       throw new JspException(Resources.getMessage("IMPORT_ABS_ERROR", target, ex), ex);
/*     */     }
/* 383 */     catch (RuntimeException ex) {
/* 384 */       throw new JspException(Resources.getMessage("IMPORT_ABS_ERROR", target, ex), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ImportResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/* 419 */     private StringWriter sw = new StringWriter();
/*     */ 
/*     */     
/* 422 */     private ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */ 
/*     */     
/* 425 */     private ServletOutputStream sos = new ServletOutputStream() {
/*     */         public void write(int b) throws IOException {
/* 427 */           ImportSupport.ImportResponseWrapper.this.bos.write(b);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isWriterUsed;
/*     */ 
/*     */     
/*     */     private boolean isStreamUsed;
/*     */     
/* 438 */     private int status = 200;
/*     */ 
/*     */ 
/*     */     
/*     */     private PageContext pageContext;
/*     */ 
/*     */ 
/*     */     
/*     */     public ImportResponseWrapper(PageContext pageContext) {
/* 447 */       super((HttpServletResponse)pageContext.getResponse());
/* 448 */       this.pageContext = pageContext;
/*     */     }
/*     */ 
/*     */     
/*     */     public PrintWriter getWriter() throws IOException {
/* 453 */       if (this.isStreamUsed) {
/* 454 */         throw new IllegalStateException(Resources.getMessage("IMPORT_ILLEGAL_STREAM"));
/*     */       }
/* 456 */       this.isWriterUsed = true;
/* 457 */       return new ImportSupport.PrintWriterWrapper(this.sw, (Writer)this.pageContext.getOut());
/*     */     }
/*     */ 
/*     */     
/*     */     public ServletOutputStream getOutputStream() {
/* 462 */       if (this.isWriterUsed) {
/* 463 */         throw new IllegalStateException(Resources.getMessage("IMPORT_ILLEGAL_WRITER"));
/*     */       }
/* 465 */       this.isStreamUsed = true;
/* 466 */       return this.sos;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setContentType(String x) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setLocale(Locale x) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setStatus(int status) {
/* 480 */       this.status = status;
/*     */     }
/*     */     
/*     */     public int getStatus() {
/* 484 */       return this.status;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getString() throws UnsupportedEncodingException {
/* 495 */       if (this.isWriterUsed)
/* 496 */         return this.sw.toString(); 
/* 497 */       if (this.isStreamUsed) {
/* 498 */         if (ImportSupport.this.charEncoding != null && !ImportSupport.this.charEncoding.equals("")) {
/* 499 */           return this.bos.toString(ImportSupport.this.charEncoding);
/*     */         }
/* 501 */         return this.bos.toString("ISO-8859-1");
/*     */       } 
/* 503 */       return "";
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrintWriterWrapper
/*     */     extends PrintWriter {
/*     */     private StringWriter out;
/*     */     private Writer parentWriter;
/*     */     
/*     */     public PrintWriterWrapper(StringWriter out, Writer parentWriter) {
/* 513 */       super(out);
/* 514 */       this.out = out;
/* 515 */       this.parentWriter = parentWriter;
/*     */     }
/*     */     
/*     */     public void flush() {
/*     */       try {
/* 520 */         this.parentWriter.write(this.out.toString());
/* 521 */         StringBuffer sb = this.out.getBuffer();
/* 522 */         sb.delete(0, sb.length());
/* 523 */       } catch (IOException ex) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String targetUrl() {
/* 533 */     if (this.urlWithParams == null)
/* 534 */       this.urlWithParams = this.params.aggregateParams(this.url); 
/* 535 */     return this.urlWithParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAbsoluteUrl() throws JspTagException {
/* 543 */     return isAbsoluteUrl(this.url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAbsoluteUrl(String url) {
/* 556 */     if (url == null) {
/* 557 */       return false;
/*     */     }
/*     */     
/*     */     int colonPos;
/* 561 */     if ((colonPos = url.indexOf(":")) == -1) {
/* 562 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 566 */     for (int i = 0; i < colonPos; i++) {
/* 567 */       if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.-".indexOf(url.charAt(i)) == -1) {
/* 568 */         return false;
/*     */       }
/*     */     } 
/* 571 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripSession(String url) {
/* 581 */     StringBuffer u = new StringBuffer(url);
/*     */     int sessionStart;
/* 583 */     while ((sessionStart = u.toString().indexOf(";jsessionid=")) != -1) {
/* 584 */       int sessionEnd = u.toString().indexOf(";", sessionStart + 1);
/* 585 */       if (sessionEnd == -1)
/* 586 */         sessionEnd = u.toString().indexOf("?", sessionStart + 1); 
/* 587 */       if (sessionEnd == -1)
/* 588 */         sessionEnd = u.length(); 
/* 589 */       u.delete(sessionStart, sessionEnd);
/*     */     } 
/* 591 */     return u.toString();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\ImportSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */