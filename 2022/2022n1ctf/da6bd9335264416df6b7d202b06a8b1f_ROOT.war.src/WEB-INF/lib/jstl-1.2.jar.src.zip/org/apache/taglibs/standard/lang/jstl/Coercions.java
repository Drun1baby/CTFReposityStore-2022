/*      */ package org.apache.taglibs.standard.lang.jstl;
/*      */ 
/*      */ import java.beans.PropertyEditor;
/*      */ import java.beans.PropertyEditorManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Coercions
/*      */ {
/*      */   public static Object coerce(Object pValue, Class<String> pClass, Logger pLogger) throws ELException {
/*  253 */     if (pClass == String.class) {
/*  254 */       return coerceToString(pValue, pLogger);
/*      */     }
/*  256 */     if (isPrimitiveNumberClass(pClass)) {
/*  257 */       return coerceToPrimitiveNumber(pValue, pClass, pLogger);
/*      */     }
/*  259 */     if (pClass == Character.class || pClass == char.class)
/*      */     {
/*  261 */       return coerceToCharacter(pValue, pLogger);
/*      */     }
/*  263 */     if (pClass == Boolean.class || pClass == boolean.class)
/*      */     {
/*  265 */       return coerceToBoolean(pValue, pLogger);
/*      */     }
/*      */     
/*  268 */     return coerceToObject(pValue, pClass, pLogger);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isPrimitiveNumberClass(Class<Byte> pClass) {
/*  280 */     return (pClass == Byte.class || pClass == byte.class || pClass == Short.class || pClass == short.class || pClass == Integer.class || pClass == int.class || pClass == Long.class || pClass == long.class || pClass == Float.class || pClass == float.class || pClass == Double.class || pClass == double.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String coerceToString(Object pValue, Logger pLogger) throws ELException {
/*  304 */     if (pValue == null) {
/*  305 */       return "";
/*      */     }
/*  307 */     if (pValue instanceof String) {
/*  308 */       return (String)pValue;
/*      */     }
/*      */     
/*      */     try {
/*  312 */       return pValue.toString();
/*      */     }
/*  314 */     catch (Exception exc) {
/*  315 */       if (pLogger.isLoggingError()) {
/*  316 */         pLogger.logError(Constants.TOSTRING_EXCEPTION, exc, pValue.getClass().getName());
/*      */       }
/*      */ 
/*      */       
/*  320 */       return "";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number coerceToPrimitiveNumber(Object pValue, Class<?> pClass, Logger pLogger) throws ELException {
/*  335 */     if (pValue == null || "".equals(pValue))
/*      */     {
/*  337 */       return coerceToPrimitiveNumber(0L, pClass);
/*      */     }
/*  339 */     if (pValue instanceof Character) {
/*  340 */       char val = ((Character)pValue).charValue();
/*  341 */       return coerceToPrimitiveNumber((short)val, pClass);
/*      */     } 
/*  343 */     if (pValue instanceof Boolean) {
/*  344 */       if (pLogger.isLoggingError()) {
/*  345 */         pLogger.logError(Constants.BOOLEAN_TO_NUMBER, pValue, pClass.getName());
/*      */       }
/*      */ 
/*      */       
/*  349 */       return coerceToPrimitiveNumber(0L, pClass);
/*      */     } 
/*  351 */     if (pValue.getClass() == pClass) {
/*  352 */       return (Number)pValue;
/*      */     }
/*  354 */     if (pValue instanceof Number) {
/*  355 */       return coerceToPrimitiveNumber((Number)pValue, pClass);
/*      */     }
/*  357 */     if (pValue instanceof String) {
/*      */       try {
/*  359 */         return coerceToPrimitiveNumber((String)pValue, pClass);
/*      */       }
/*  361 */       catch (Exception exc) {
/*  362 */         if (pLogger.isLoggingError()) {
/*  363 */           pLogger.logError(Constants.STRING_TO_NUMBER_EXCEPTION, pValue, pClass.getName());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  368 */         return coerceToPrimitiveNumber(0L, pClass);
/*      */       } 
/*      */     }
/*      */     
/*  372 */     if (pLogger.isLoggingError()) {
/*  373 */       pLogger.logError(Constants.COERCE_TO_NUMBER, pValue.getClass().getName(), pClass.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  378 */     return coerceToPrimitiveNumber(0L, pClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer coerceToInteger(Object pValue, Logger pLogger) throws ELException {
/*  392 */     if (pValue == null) {
/*  393 */       return null;
/*      */     }
/*  395 */     if (pValue instanceof Character) {
/*  396 */       return PrimitiveObjects.getInteger(((Character)pValue).charValue());
/*      */     }
/*      */     
/*  399 */     if (pValue instanceof Boolean) {
/*  400 */       if (pLogger.isLoggingWarning()) {
/*  401 */         pLogger.logWarning(Constants.BOOLEAN_TO_NUMBER, pValue, Integer.class.getName());
/*      */       }
/*      */ 
/*      */       
/*  405 */       return PrimitiveObjects.getInteger(((Boolean)pValue).booleanValue() ? 1 : 0);
/*      */     } 
/*      */     
/*  408 */     if (pValue instanceof Integer) {
/*  409 */       return (Integer)pValue;
/*      */     }
/*  411 */     if (pValue instanceof Number) {
/*  412 */       return PrimitiveObjects.getInteger(((Number)pValue).intValue());
/*      */     }
/*  414 */     if (pValue instanceof String) {
/*      */       try {
/*  416 */         return Integer.valueOf((String)pValue);
/*      */       }
/*  418 */       catch (Exception exc) {
/*  419 */         if (pLogger.isLoggingWarning()) {
/*  420 */           pLogger.logWarning(Constants.STRING_TO_NUMBER_EXCEPTION, pValue, Integer.class.getName());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  425 */         return null;
/*      */       } 
/*      */     }
/*      */     
/*  429 */     if (pLogger.isLoggingWarning()) {
/*  430 */       pLogger.logWarning(Constants.COERCE_TO_NUMBER, pValue.getClass().getName(), Integer.class.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  435 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Number coerceToPrimitiveNumber(long pValue, Class<Byte> pClass) throws ELException {
/*  448 */     if (pClass == Byte.class || pClass == byte.class) {
/*  449 */       return PrimitiveObjects.getByte((byte)(int)pValue);
/*      */     }
/*  451 */     if (pClass == Short.class || pClass == short.class) {
/*  452 */       return PrimitiveObjects.getShort((short)(int)pValue);
/*      */     }
/*  454 */     if (pClass == Integer.class || pClass == int.class) {
/*  455 */       return PrimitiveObjects.getInteger((int)pValue);
/*      */     }
/*  457 */     if (pClass == Long.class || pClass == long.class) {
/*  458 */       return PrimitiveObjects.getLong(pValue);
/*      */     }
/*  460 */     if (pClass == Float.class || pClass == float.class) {
/*  461 */       return PrimitiveObjects.getFloat((float)pValue);
/*      */     }
/*  463 */     if (pClass == Double.class || pClass == double.class) {
/*  464 */       return PrimitiveObjects.getDouble(pValue);
/*      */     }
/*      */     
/*  467 */     return PrimitiveObjects.getInteger(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Number coerceToPrimitiveNumber(double pValue, Class<Byte> pClass) throws ELException {
/*  480 */     if (pClass == Byte.class || pClass == byte.class) {
/*  481 */       return PrimitiveObjects.getByte((byte)(int)pValue);
/*      */     }
/*  483 */     if (pClass == Short.class || pClass == short.class) {
/*  484 */       return PrimitiveObjects.getShort((short)(int)pValue);
/*      */     }
/*  486 */     if (pClass == Integer.class || pClass == int.class) {
/*  487 */       return PrimitiveObjects.getInteger((int)pValue);
/*      */     }
/*  489 */     if (pClass == Long.class || pClass == long.class) {
/*  490 */       return PrimitiveObjects.getLong((long)pValue);
/*      */     }
/*  492 */     if (pClass == Float.class || pClass == float.class) {
/*  493 */       return PrimitiveObjects.getFloat((float)pValue);
/*      */     }
/*  495 */     if (pClass == Double.class || pClass == double.class) {
/*  496 */       return PrimitiveObjects.getDouble(pValue);
/*      */     }
/*      */     
/*  499 */     return PrimitiveObjects.getInteger(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Number coerceToPrimitiveNumber(Number pValue, Class<Byte> pClass) throws ELException {
/*  512 */     if (pClass == Byte.class || pClass == byte.class) {
/*  513 */       return PrimitiveObjects.getByte(pValue.byteValue());
/*      */     }
/*  515 */     if (pClass == Short.class || pClass == short.class) {
/*  516 */       return PrimitiveObjects.getShort(pValue.shortValue());
/*      */     }
/*  518 */     if (pClass == Integer.class || pClass == int.class) {
/*  519 */       return PrimitiveObjects.getInteger(pValue.intValue());
/*      */     }
/*  521 */     if (pClass == Long.class || pClass == long.class) {
/*  522 */       return PrimitiveObjects.getLong(pValue.longValue());
/*      */     }
/*  524 */     if (pClass == Float.class || pClass == float.class) {
/*  525 */       return PrimitiveObjects.getFloat(pValue.floatValue());
/*      */     }
/*  527 */     if (pClass == Double.class || pClass == double.class) {
/*  528 */       return PrimitiveObjects.getDouble(pValue.doubleValue());
/*      */     }
/*      */     
/*  531 */     return PrimitiveObjects.getInteger(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Number coerceToPrimitiveNumber(String pValue, Class<Byte> pClass) throws ELException {
/*  544 */     if (pClass == Byte.class || pClass == byte.class) {
/*  545 */       return Byte.valueOf(pValue);
/*      */     }
/*  547 */     if (pClass == Short.class || pClass == short.class) {
/*  548 */       return Short.valueOf(pValue);
/*      */     }
/*  550 */     if (pClass == Integer.class || pClass == int.class) {
/*  551 */       return Integer.valueOf(pValue);
/*      */     }
/*  553 */     if (pClass == Long.class || pClass == long.class) {
/*  554 */       return Long.valueOf(pValue);
/*      */     }
/*  556 */     if (pClass == Float.class || pClass == float.class) {
/*  557 */       return Float.valueOf(pValue);
/*      */     }
/*  559 */     if (pClass == Double.class || pClass == double.class) {
/*  560 */       return Double.valueOf(pValue);
/*      */     }
/*      */     
/*  563 */     return PrimitiveObjects.getInteger(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character coerceToCharacter(Object pValue, Logger pLogger) throws ELException {
/*  576 */     if (pValue == null || "".equals(pValue))
/*      */     {
/*  578 */       return PrimitiveObjects.getCharacter(false);
/*      */     }
/*  580 */     if (pValue instanceof Character) {
/*  581 */       return (Character)pValue;
/*      */     }
/*  583 */     if (pValue instanceof Boolean) {
/*  584 */       if (pLogger.isLoggingError()) {
/*  585 */         pLogger.logError(Constants.BOOLEAN_TO_CHARACTER, pValue);
/*      */       }
/*  587 */       return PrimitiveObjects.getCharacter(false);
/*      */     } 
/*  589 */     if (pValue instanceof Number) {
/*  590 */       return PrimitiveObjects.getCharacter((char)((Number)pValue).shortValue());
/*      */     }
/*      */     
/*  593 */     if (pValue instanceof String) {
/*  594 */       String str = (String)pValue;
/*  595 */       return PrimitiveObjects.getCharacter(str.charAt(0));
/*      */     } 
/*      */     
/*  598 */     if (pLogger.isLoggingError()) {
/*  599 */       pLogger.logError(Constants.COERCE_TO_CHARACTER, pValue.getClass().getName());
/*      */     }
/*      */ 
/*      */     
/*  603 */     return PrimitiveObjects.getCharacter(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean coerceToBoolean(Object pValue, Logger pLogger) throws ELException {
/*  616 */     if (pValue == null || "".equals(pValue))
/*      */     {
/*  618 */       return Boolean.FALSE;
/*      */     }
/*  620 */     if (pValue instanceof Boolean) {
/*  621 */       return (Boolean)pValue;
/*      */     }
/*  623 */     if (pValue instanceof String) {
/*  624 */       String str = (String)pValue;
/*      */       try {
/*  626 */         return Boolean.valueOf(str);
/*      */       }
/*  628 */       catch (Exception exc) {
/*  629 */         if (pLogger.isLoggingError()) {
/*  630 */           pLogger.logError(Constants.STRING_TO_BOOLEAN, exc, pValue);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  635 */         return Boolean.FALSE;
/*      */       } 
/*      */     } 
/*      */     
/*  639 */     if (pLogger.isLoggingError()) {
/*  640 */       pLogger.logError(Constants.COERCE_TO_BOOLEAN, pValue.getClass().getName());
/*      */     }
/*      */ 
/*      */     
/*  644 */     return Boolean.TRUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object coerceToObject(Object pValue, Class<?> pClass, Logger pLogger) throws ELException {
/*  659 */     if (pValue == null) {
/*  660 */       return null;
/*      */     }
/*  662 */     if (pClass.isAssignableFrom(pValue.getClass())) {
/*  663 */       return pValue;
/*      */     }
/*  665 */     if (pValue instanceof String) {
/*  666 */       String str = (String)pValue;
/*  667 */       PropertyEditor pe = PropertyEditorManager.findEditor(pClass);
/*  668 */       if (pe == null) {
/*  669 */         if ("".equals(str)) {
/*  670 */           return null;
/*      */         }
/*      */         
/*  673 */         if (pLogger.isLoggingError()) {
/*  674 */           pLogger.logError(Constants.NO_PROPERTY_EDITOR, str, pClass.getName());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  679 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  683 */         pe.setAsText(str);
/*  684 */         return pe.getValue();
/*      */       }
/*  686 */       catch (IllegalArgumentException exc) {
/*  687 */         if ("".equals(str)) {
/*  688 */           return null;
/*      */         }
/*      */         
/*  691 */         if (pLogger.isLoggingError()) {
/*  692 */           pLogger.logError(Constants.PROPERTY_EDITOR_ERROR, exc, pValue, pClass.getName());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  698 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  703 */     if (pLogger.isLoggingError()) {
/*  704 */       pLogger.logError(Constants.COERCE_TO_OBJECT, pValue.getClass().getName(), pClass.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  709 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object applyArithmeticOperator(Object pLeft, Object pRight, ArithmeticOperator pOperator, Logger pLogger) throws ELException {
/*  728 */     if (pLeft == null && pRight == null) {
/*      */       
/*  730 */       if (pLogger.isLoggingWarning()) {
/*  731 */         pLogger.logWarning(Constants.ARITH_OP_NULL, pOperator.getOperatorSymbol());
/*      */       }
/*      */ 
/*      */       
/*  735 */       return PrimitiveObjects.getInteger(0);
/*      */     } 
/*      */     
/*  738 */     if (isFloatingPointType(pLeft) || isFloatingPointType(pRight) || isFloatingPointString(pLeft) || isFloatingPointString(pRight)) {
/*      */ 
/*      */ 
/*      */       
/*  742 */       double d1 = coerceToPrimitiveNumber(pLeft, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  745 */       double d2 = coerceToPrimitiveNumber(pRight, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  748 */       return PrimitiveObjects.getDouble(pOperator.apply(d1, d2, pLogger));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  753 */     long left = coerceToPrimitiveNumber(pLeft, Long.class, pLogger).longValue();
/*      */ 
/*      */     
/*  756 */     long right = coerceToPrimitiveNumber(pRight, Long.class, pLogger).longValue();
/*      */ 
/*      */     
/*  759 */     return PrimitiveObjects.getLong(pOperator.apply(left, right, pLogger));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object applyRelationalOperator(Object pLeft, Object pRight, RelationalOperator pOperator, Logger pLogger) throws ELException {
/*  777 */     if (isFloatingPointType(pLeft) || isFloatingPointType(pRight)) {
/*      */       
/*  779 */       double left = coerceToPrimitiveNumber(pLeft, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  782 */       double right = coerceToPrimitiveNumber(pRight, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  785 */       return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
/*      */     } 
/*      */ 
/*      */     
/*  789 */     if (isIntegerType(pLeft) || isIntegerType(pRight)) {
/*      */       
/*  791 */       long left = coerceToPrimitiveNumber(pLeft, Long.class, pLogger).longValue();
/*      */ 
/*      */       
/*  794 */       long right = coerceToPrimitiveNumber(pRight, Long.class, pLogger).longValue();
/*      */ 
/*      */       
/*  797 */       return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
/*      */     } 
/*      */ 
/*      */     
/*  801 */     if (pLeft instanceof String || pRight instanceof String) {
/*      */       
/*  803 */       String left = coerceToString(pLeft, pLogger);
/*  804 */       String right = coerceToString(pRight, pLogger);
/*  805 */       return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
/*      */     } 
/*      */ 
/*      */     
/*  809 */     if (pLeft instanceof Comparable) {
/*      */       try {
/*  811 */         int result = ((Comparable<Object>)pLeft).compareTo(pRight);
/*  812 */         return PrimitiveObjects.getBoolean(pOperator.apply(result, -result, pLogger));
/*      */ 
/*      */       
/*      */       }
/*  816 */       catch (Exception exc) {
/*  817 */         if (pLogger.isLoggingError()) {
/*  818 */           pLogger.logError(Constants.COMPARABLE_ERROR, exc, pLeft.getClass().getName(), (pRight == null) ? "null" : pRight.getClass().getName(), pOperator.getOperatorSymbol());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  825 */         return Boolean.FALSE;
/*      */       } 
/*      */     }
/*      */     
/*  829 */     if (pRight instanceof Comparable) {
/*      */       try {
/*  831 */         int result = ((Comparable<Object>)pRight).compareTo(pLeft);
/*  832 */         return PrimitiveObjects.getBoolean(pOperator.apply(-result, result, pLogger));
/*      */ 
/*      */       
/*      */       }
/*  836 */       catch (Exception exc) {
/*  837 */         if (pLogger.isLoggingError()) {
/*  838 */           pLogger.logError(Constants.COMPARABLE_ERROR, exc, pRight.getClass().getName(), (pLeft == null) ? "null" : pLeft.getClass().getName(), pOperator.getOperatorSymbol());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  845 */         return Boolean.FALSE;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  850 */     if (pLogger.isLoggingError()) {
/*  851 */       pLogger.logError(Constants.ARITH_OP_BAD_TYPE, pOperator.getOperatorSymbol(), pLeft.getClass().getName(), pRight.getClass().getName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  857 */     return Boolean.FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object applyEqualityOperator(Object pLeft, Object pRight, EqualityOperator pOperator, Logger pLogger) throws ELException {
/*  874 */     if (pLeft == pRight) {
/*  875 */       return PrimitiveObjects.getBoolean(pOperator.apply(true, pLogger));
/*      */     }
/*      */     
/*  878 */     if (pLeft == null || pRight == null)
/*      */     {
/*  880 */       return PrimitiveObjects.getBoolean(pOperator.apply(false, pLogger));
/*      */     }
/*      */     
/*  883 */     if (isFloatingPointType(pLeft) || isFloatingPointType(pRight)) {
/*      */       
/*  885 */       double left = coerceToPrimitiveNumber(pLeft, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  888 */       double right = coerceToPrimitiveNumber(pRight, Double.class, pLogger).doubleValue();
/*      */ 
/*      */       
/*  891 */       return PrimitiveObjects.getBoolean(pOperator.apply((left == right), pLogger));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  896 */     if (isIntegerType(pLeft) || isIntegerType(pRight)) {
/*      */       
/*  898 */       long left = coerceToPrimitiveNumber(pLeft, Long.class, pLogger).longValue();
/*      */ 
/*      */       
/*  901 */       long right = coerceToPrimitiveNumber(pRight, Long.class, pLogger).longValue();
/*      */ 
/*      */       
/*  904 */       return PrimitiveObjects.getBoolean(pOperator.apply((left == right), pLogger));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  909 */     if (pLeft instanceof Boolean || pRight instanceof Boolean) {
/*      */       
/*  911 */       boolean left = coerceToBoolean(pLeft, pLogger).booleanValue();
/*  912 */       boolean right = coerceToBoolean(pRight, pLogger).booleanValue();
/*  913 */       return PrimitiveObjects.getBoolean(pOperator.apply((left == right), pLogger));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  918 */     if (pLeft instanceof String || pRight instanceof String) {
/*      */       
/*  920 */       String left = coerceToString(pLeft, pLogger);
/*  921 */       String right = coerceToString(pRight, pLogger);
/*  922 */       return PrimitiveObjects.getBoolean(pOperator.apply(left.equals(right), pLogger));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  929 */       return PrimitiveObjects.getBoolean(pOperator.apply(pLeft.equals(pRight), pLogger));
/*      */ 
/*      */     
/*      */     }
/*  933 */     catch (Exception exc) {
/*  934 */       if (pLogger.isLoggingError()) {
/*  935 */         pLogger.logError(Constants.ERROR_IN_EQUALS, exc, pLeft.getClass().getName(), pRight.getClass().getName(), pOperator.getOperatorSymbol());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  942 */       return Boolean.FALSE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFloatingPointType(Object pObject) {
/*  954 */     return (pObject != null && isFloatingPointType(pObject.getClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFloatingPointType(Class<Float> pClass) {
/*  966 */     return (pClass == Float.class || pClass == float.class || pClass == Double.class || pClass == double.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isFloatingPointString(Object pObject) {
/*  981 */     if (pObject instanceof String) {
/*  982 */       String str = (String)pObject;
/*  983 */       int len = str.length();
/*  984 */       for (int i = 0; i < len; i++) {
/*  985 */         char ch = str.charAt(i);
/*  986 */         if (ch == '.' || ch == 'e' || ch == 'E')
/*      */         {
/*      */           
/*  989 */           return true;
/*      */         }
/*      */       } 
/*  992 */       return false;
/*      */     } 
/*      */     
/*  995 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIntegerType(Object pObject) {
/* 1006 */     return (pObject != null && isIntegerType(pObject.getClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isIntegerType(Class<Byte> pClass) {
/* 1018 */     return (pClass == Byte.class || pClass == byte.class || pClass == Short.class || pClass == short.class || pClass == Character.class || pClass == char.class || pClass == Integer.class || pClass == int.class || pClass == Long.class || pClass == long.class);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\Coercions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */