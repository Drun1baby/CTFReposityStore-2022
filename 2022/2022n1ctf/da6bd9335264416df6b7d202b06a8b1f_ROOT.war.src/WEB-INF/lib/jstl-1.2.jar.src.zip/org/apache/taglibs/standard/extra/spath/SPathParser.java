/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPathParser
/*     */   implements SPathParserConstants
/*     */ {
/*     */   public SPathParserTokenManager token_source;
/*     */   ASCII_UCodeESC_CharStream jj_input_stream;
/*     */   public Token token;
/*     */   public Token jj_nt;
/*     */   private int jj_ntk;
/*     */   private Token jj_scanpos;
/*     */   private Token jj_lastpos;
/*     */   private int jj_la;
/*     */   
/*     */   public static void main(String[] args) throws ParseException {
/*  32 */     SPathParser parser = new SPathParser(System.in);
/*  33 */     Path p = parser.expression();
/*  34 */     List<Step> l = p.getSteps();
/*     */ 
/*     */     
/*  37 */     System.out.println();
/*  38 */     if (p instanceof AbsolutePath)
/*  39 */       System.out.println("Root: /"); 
/*  40 */     for (int i = 0; i < l.size(); i++) {
/*  41 */       Step s = l.get(i);
/*  42 */       System.out.print("Step: " + s.getName());
/*  43 */       if (s.isDepthUnlimited())
/*  44 */         System.out.print("(*)"); 
/*  45 */       System.out.println();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public SPathParser(String x) {
/*  51 */     this(new StringReader(x));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Path expression() throws ParseException {
/*     */     Path expr;
/*  58 */     if (jj_2_1(2147483647))
/*  59 */     { expr = absolutePath();
/*  60 */       jj_consume_token(0); }
/*     */     else
/*  62 */     { switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk)
/*     */       { case 2:
/*     */         case 4:
/*     */         case 13:
/*     */         case 14:
/*  67 */           expr = relativePath();
/*  68 */           jj_consume_token(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  76 */           return expr; }  this.jj_la1[0] = this.jj_gen; jj_consume_token(-1); throw new ParseException(); }  return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final AbsolutePath absolutePath() throws ParseException {
/*  82 */     jj_consume_token(13);
/*  83 */     RelativePath relPath = relativePath();
/*  84 */     return new AbsolutePath(relPath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final RelativePath relativePath() throws ParseException {
/*  90 */     RelativePath relPath = null;
/*     */     
/*  92 */     Step step = step();
/*  93 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk)
/*     */     { case 13:
/*  95 */         jj_consume_token(13);
/*  96 */         relPath = relativePath();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 102 */         return new RelativePath(step, relPath); }  this.jj_la1[1] = this.jj_gen; return new RelativePath(step, relPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Step step() throws ParseException {
/* 113 */     Token slash = null;
/*     */     
/* 115 */     Vector<Predicate> pl = null;
/*     */     
/* 117 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*     */       case 13:
/* 119 */         slash = jj_consume_token(13);
/*     */         break;
/*     */       default:
/* 122 */         this.jj_la1[2] = this.jj_gen;
/*     */         break;
/*     */     } 
/* 125 */     String nt = nameTest();
/*     */     
/*     */     while (true) {
/* 128 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*     */         case 16:
/*     */           break;
/*     */         
/*     */         default:
/* 133 */           this.jj_la1[3] = this.jj_gen;
/*     */           break;
/*     */       } 
/* 136 */       Predicate p = predicate();
/* 137 */       if (pl == null) pl = new Vector(); 
/* 138 */       pl.add(p);
/*     */     } 
/*     */     
/* 141 */     return new Step((slash != null), nt, pl);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String nameTest() throws ParseException {
/*     */     Token name;
/* 147 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*     */       case 14:
/* 149 */         name = jj_consume_token(14);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 162 */         return name.toString();case 4: name = jj_consume_token(4); return name.toString();case 2: name = jj_consume_token(2); return name.toString();
/*     */     } 
/*     */     this.jj_la1[4] = this.jj_gen;
/*     */     jj_consume_token(-1);
/*     */     throw new ParseException();
/*     */   } public final Predicate predicate() throws ParseException {
/* 168 */     jj_consume_token(16);
/* 169 */     Predicate p = attributePredicate();
/* 170 */     jj_consume_token(17);
/* 171 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Predicate attributePredicate() throws ParseException {
/* 177 */     jj_consume_token(18);
/* 178 */     Token attname = jj_consume_token(2);
/* 179 */     jj_consume_token(19);
/* 180 */     Token target = jj_consume_token(1);
/* 181 */     return new AttributePredicate(attname.toString(), target.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean jj_2_1(int xla) {
/* 186 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token;
/* 187 */     boolean retval = !jj_3_1();
/* 188 */     jj_save(0, xla);
/* 189 */     return retval;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_13() {
/* 193 */     if (jj_scan_token(18)) return true; 
/* 194 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 195 */     if (jj_scan_token(2)) return true; 
/* 196 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 197 */     if (jj_scan_token(19)) return true; 
/* 198 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 199 */     if (jj_scan_token(1)) return true; 
/* 200 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3_1() {
/* 205 */     if (jj_3R_2()) return true; 
/* 206 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 207 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_10() {
/* 211 */     if (jj_scan_token(4)) return true; 
/* 212 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_11() {
/* 217 */     if (jj_scan_token(2)) return true; 
/* 218 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_2() {
/* 223 */     if (jj_scan_token(13)) return true; 
/* 224 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 225 */     if (jj_3R_3()) return true; 
/* 226 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 227 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_12() {
/* 231 */     if (jj_scan_token(16)) return true; 
/* 232 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 233 */     if (jj_3R_13()) return true; 
/* 234 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 235 */     if (jj_scan_token(17)) return true; 
/* 236 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 237 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_8() {
/* 241 */     if (jj_3R_12()) return true; 
/* 242 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 243 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_5() {
/* 247 */     if (jj_scan_token(13)) return true; 
/* 248 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 249 */     if (jj_3R_3()) return true; 
/* 250 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 251 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_6() {
/* 255 */     if (jj_scan_token(13)) return true; 
/* 256 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 257 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_3() {
/* 261 */     if (jj_3R_4()) return true; 
/* 262 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false;
/*     */     
/* 264 */     Token xsp = this.jj_scanpos;
/* 265 */     if (jj_3R_5()) { this.jj_scanpos = xsp; }
/* 266 */     else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) { return false; }
/* 267 */      return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean jj_3R_4() {
/* 272 */     Token xsp = this.jj_scanpos;
/* 273 */     if (jj_3R_6()) { this.jj_scanpos = xsp; }
/* 274 */     else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) { return false; }
/* 275 */      if (jj_3R_7()) return true; 
/* 276 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*     */     while (true) {
/* 278 */       xsp = this.jj_scanpos;
/* 279 */       if (jj_3R_8()) { this.jj_scanpos = xsp; break; }
/* 280 */        if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/*     */     } 
/* 282 */     return false;
/*     */   }
/*     */   
/*     */   private final boolean jj_3R_9() {
/* 286 */     if (jj_scan_token(14)) return true; 
/* 287 */     if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false; 
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private final boolean jj_3R_7() {
/* 293 */     Token xsp = this.jj_scanpos;
/* 294 */     if (jj_3R_9())
/* 295 */     { this.jj_scanpos = xsp;
/* 296 */       if (jj_3R_10())
/* 297 */       { this.jj_scanpos = xsp;
/* 298 */         if (jj_3R_11()) return true; 
/* 299 */         if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) return false;  }
/* 300 */       else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) { return false; }  }
/* 301 */     else if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) { return false; }
/* 302 */      return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean lookingAhead = false;
/*     */ 
/*     */   
/*     */   private boolean jj_semLA;
/*     */   
/*     */   private int jj_gen;
/*     */   
/* 314 */   private final int[] jj_la1 = new int[5];
/* 315 */   private final int[] jj_la1_0 = new int[] { 24596, 8192, 8192, 65536, 16404 };
/* 316 */   private final JJCalls[] jj_2_rtns = new JJCalls[1];
/*     */   private boolean jj_rescan = false;
/* 318 */   private int jj_gc = 0;
/*     */   
/*     */   private Vector jj_expentries;
/*     */   
/*     */   private int[] jj_expentry;
/*     */   
/*     */   private int jj_kind;
/*     */   
/*     */   private int[] jj_lasttokens;
/*     */   
/*     */   private int jj_endpos;
/*     */   
/*     */   public void ReInit(InputStream stream) {
/* 331 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 332 */     this.token_source.ReInit(this.jj_input_stream);
/* 333 */     this.token = new Token();
/* 334 */     this.jj_ntk = -1;
/* 335 */     this.jj_gen = 0; int i;
/* 336 */     for (i = 0; i < 5; ) { this.jj_la1[i] = -1; i++; }
/* 337 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader stream) {
/* 351 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 352 */     this.token_source.ReInit(this.jj_input_stream);
/* 353 */     this.token = new Token();
/* 354 */     this.jj_ntk = -1;
/* 355 */     this.jj_gen = 0; int i;
/* 356 */     for (i = 0; i < 5; ) { this.jj_la1[i] = -1; i++; }
/* 357 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(SPathParserTokenManager tm) {
/* 370 */     this.token_source = tm;
/* 371 */     this.token = new Token();
/* 372 */     this.jj_ntk = -1;
/* 373 */     this.jj_gen = 0; int i;
/* 374 */     for (i = 0; i < 5; ) { this.jj_la1[i] = -1; i++; }
/* 375 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*     */   
/*     */   }
/*     */   private final Token jj_consume_token(int kind) throws ParseException {
/*     */     Token oldToken;
/* 380 */     if ((oldToken = this.token).next != null) { this.token = this.token.next; }
/* 381 */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/* 382 */      this.jj_ntk = -1;
/* 383 */     if (this.token.kind == kind) {
/* 384 */       this.jj_gen++;
/* 385 */       if (++this.jj_gc > 100) {
/* 386 */         this.jj_gc = 0;
/* 387 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 388 */           JJCalls c = this.jj_2_rtns[i];
/* 389 */           while (c != null) {
/* 390 */             if (c.gen < this.jj_gen) c.first = null; 
/* 391 */             c = c.next;
/*     */           } 
/*     */         } 
/*     */       } 
/* 395 */       return this.token;
/*     */     } 
/* 397 */     this.token = oldToken;
/* 398 */     this.jj_kind = kind;
/* 399 */     throw generateParseException();
/*     */   }
/*     */   
/*     */   private final boolean jj_scan_token(int kind) {
/* 403 */     if (this.jj_scanpos == this.jj_lastpos) {
/* 404 */       this.jj_la--;
/* 405 */       if (this.jj_scanpos.next == null) {
/* 406 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken();
/*     */       } else {
/* 408 */         this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next;
/*     */       } 
/*     */     } else {
/* 411 */       this.jj_scanpos = this.jj_scanpos.next;
/*     */     } 
/* 413 */     if (this.jj_rescan) {
/* 414 */       int i = 0; Token tok = this.token;
/* 415 */       while (tok != null && tok != this.jj_scanpos) { i++; tok = tok.next; }
/* 416 */        if (tok != null) jj_add_error_token(kind, i); 
/*     */     } 
/* 418 */     return (this.jj_scanpos.kind != kind);
/*     */   }
/*     */   
/*     */   public final Token getNextToken() {
/* 422 */     if (this.token.next != null) { this.token = this.token.next; }
/* 423 */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/* 424 */      this.jj_ntk = -1;
/* 425 */     this.jj_gen++;
/* 426 */     return this.token;
/*     */   }
/*     */   
/*     */   public final Token getToken(int index) {
/* 430 */     Token t = this.lookingAhead ? this.jj_scanpos : this.token;
/* 431 */     for (int i = 0; i < index; i++) {
/* 432 */       if (t.next != null) { t = t.next; }
/* 433 */       else { t = t.next = this.token_source.getNextToken(); }
/*     */     
/* 435 */     }  return t;
/*     */   }
/*     */   
/*     */   private final int jj_ntk() {
/* 439 */     if ((this.jj_nt = this.token.next) == null) {
/* 440 */       return this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind;
/*     */     }
/* 442 */     return this.jj_ntk = this.jj_nt.kind;
/*     */   }
/*     */   
/* 445 */   public SPathParser(InputStream stream) { this.jj_expentries = new Vector();
/*     */     
/* 447 */     this.jj_kind = -1;
/* 448 */     this.jj_lasttokens = new int[100]; this.jj_input_stream = new ASCII_UCodeESC_CharStream(stream, 1, 1); this.token_source = new SPathParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 5; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public SPathParser(Reader stream) { this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.jj_input_stream = new ASCII_UCodeESC_CharStream(stream, 1, 1); this.token_source = new SPathParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 5; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public SPathParser(SPathParserTokenManager tm) { this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 5; ) {
/*     */       this.jj_la1[i] = -1; i++;
/*     */     }  for (i = 0; i < this.jj_2_rtns.length; ) {
/*     */       this.jj_2_rtns[i] = new JJCalls(); i++;
/* 452 */     }  } private void jj_add_error_token(int kind, int pos) { if (pos >= 100)
/* 453 */       return;  if (pos == this.jj_endpos + 1) {
/* 454 */       this.jj_lasttokens[this.jj_endpos++] = kind;
/* 455 */     } else if (this.jj_endpos != 0) {
/* 456 */       this.jj_expentry = new int[this.jj_endpos];
/* 457 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 458 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*     */       }
/* 460 */       boolean exists = false;
/* 461 */       for (Enumeration<int[]> enum_ = this.jj_expentries.elements(); enum_.hasMoreElements(); ) {
/* 462 */         int[] oldentry = enum_.nextElement();
/* 463 */         if (oldentry.length == this.jj_expentry.length) {
/* 464 */           exists = true;
/* 465 */           for (int j = 0; j < this.jj_expentry.length; j++) {
/* 466 */             if (oldentry[j] != this.jj_expentry[j]) {
/* 467 */               exists = false;
/*     */               break;
/*     */             } 
/*     */           } 
/* 471 */           if (exists)
/*     */             break; 
/*     */         } 
/* 474 */       }  if (!exists) this.jj_expentries.addElement(this.jj_expentry); 
/* 475 */       if (pos != 0) this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind; 
/*     */     }  }
/*     */ 
/*     */   
/*     */   public final ParseException generateParseException() {
/* 480 */     this.jj_expentries.removeAllElements();
/* 481 */     boolean[] la1tokens = new boolean[20]; int i;
/* 482 */     for (i = 0; i < 20; i++) {
/* 483 */       la1tokens[i] = false;
/*     */     }
/* 485 */     if (this.jj_kind >= 0) {
/* 486 */       la1tokens[this.jj_kind] = true;
/* 487 */       this.jj_kind = -1;
/*     */     } 
/* 489 */     for (i = 0; i < 5; i++) {
/* 490 */       if (this.jj_la1[i] == this.jj_gen) {
/* 491 */         for (int k = 0; k < 32; k++) {
/* 492 */           if ((this.jj_la1_0[i] & 1 << k) != 0) {
/* 493 */             la1tokens[k] = true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 498 */     for (i = 0; i < 20; i++) {
/* 499 */       if (la1tokens[i]) {
/* 500 */         this.jj_expentry = new int[1];
/* 501 */         this.jj_expentry[0] = i;
/* 502 */         this.jj_expentries.addElement(this.jj_expentry);
/*     */       } 
/*     */     } 
/* 505 */     this.jj_endpos = 0;
/* 506 */     jj_rescan_token();
/* 507 */     jj_add_error_token(0, 0);
/* 508 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 509 */     for (int j = 0; j < this.jj_expentries.size(); j++) {
/* 510 */       exptokseq[j] = this.jj_expentries.elementAt(j);
/*     */     }
/* 512 */     return new ParseException(this.token, exptokseq, tokenImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void enable_tracing() {}
/*     */ 
/*     */   
/*     */   public final void disable_tracing() {}
/*     */   
/*     */   private final void jj_rescan_token() {
/* 522 */     this.jj_rescan = true;
/* 523 */     for (int i = 0; i < 1; ) {
/* 524 */       JJCalls p = this.jj_2_rtns[i];
/*     */       while (true)
/* 526 */       { if (p.gen > this.jj_gen) {
/* 527 */           this.jj_la = p.arg; this.jj_lastpos = this.jj_scanpos = p.first;
/* 528 */           switch (i) { case 0:
/* 529 */               jj_3_1(); break; }
/*     */         
/*     */         } 
/* 532 */         p = p.next;
/* 533 */         if (p == null)
/*     */           i++;  } 
/* 535 */     }  this.jj_rescan = false;
/*     */   }
/*     */   
/*     */   private final void jj_save(int index, int xla) {
/* 539 */     JJCalls p = this.jj_2_rtns[index];
/* 540 */     while (p.gen > this.jj_gen) {
/* 541 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 542 */        p = p.next;
/*     */     } 
/* 544 */     p.gen = this.jj_gen + xla - this.jj_la; p.first = this.token; p.arg = xla;
/*     */   }
/*     */   
/*     */   static final class JJCalls {
/*     */     int gen;
/*     */     Token first;
/*     */     int arg;
/*     */     JJCalls next;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\SPathParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */