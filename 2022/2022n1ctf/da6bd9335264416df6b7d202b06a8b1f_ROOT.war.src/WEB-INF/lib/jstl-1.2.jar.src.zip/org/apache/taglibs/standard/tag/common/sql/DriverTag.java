/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverTag
/*     */   extends TagSupport
/*     */ {
/*     */   private static final String DRIVER_CLASS_NAME = "javax.servlet.jsp.jstl.sql.driver";
/*     */   private static final String JDBC_URL = "javax.servlet.jsp.jstl.sql.jdbcURL";
/*     */   private static final String USER_NAME = "javax.servlet.jsp.jstl.sql.userName";
/*     */   private static final String PASSWORD = "javax.servlet.jsp.jstl.sql.password";
/*     */   private String driverClassName;
/*     */   private String jdbcURL;
/*  52 */   private int scope = 1;
/*     */   
/*     */   private String userName;
/*     */   
/*     */   private String var;
/*     */ 
/*     */   
/*     */   public void setDriver(String driverClassName) {
/*  60 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */   public void setJdbcURL(String jdbcURL) {
/*  64 */     this.jdbcURL = jdbcURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scopeName) {
/*  73 */     if ("page".equals(scopeName)) {
/*  74 */       this.scope = 1;
/*     */     }
/*  76 */     else if ("request".equals(scopeName)) {
/*  77 */       this.scope = 2;
/*     */     }
/*  79 */     else if ("session".equals(scopeName)) {
/*  80 */       this.scope = 3;
/*     */     }
/*  82 */     else if ("application".equals(scopeName)) {
/*  83 */       this.scope = 4;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setUserName(String userName) {
/*  88 */     this.userName = userName;
/*     */   }
/*     */   
/*     */   public void setVar(String var) {
/*  92 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  99 */     DataSourceWrapper ds = new DataSourceWrapper();
/*     */     try {
/* 101 */       ds.setDriverClassName(getDriverClassName());
/*     */     }
/* 103 */     catch (Exception e) {
/* 104 */       throw new JspTagException("Invalid driver class name: " + e.toString(), e);
/*     */     } 
/*     */     
/* 107 */     ds.setJdbcURL(getJdbcURL());
/* 108 */     ds.setUserName(getUserName());
/* 109 */     ds.setPassword(getPassword());
/* 110 */     this.pageContext.setAttribute(this.var, ds, this.scope);
/* 111 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDriverClassName() {
/* 119 */     if (this.driverClassName != null) {
/* 120 */       return this.driverClassName;
/*     */     }
/* 122 */     ServletContext application = this.pageContext.getServletContext();
/* 123 */     return application.getInitParameter("javax.servlet.jsp.jstl.sql.driver");
/*     */   }
/*     */   
/*     */   private String getJdbcURL() {
/* 127 */     if (this.jdbcURL != null) {
/* 128 */       return this.jdbcURL;
/*     */     }
/* 130 */     ServletContext application = this.pageContext.getServletContext();
/* 131 */     return application.getInitParameter("javax.servlet.jsp.jstl.sql.jdbcURL");
/*     */   }
/*     */   
/*     */   private String getUserName() {
/* 135 */     if (this.userName != null) {
/* 136 */       return this.userName;
/*     */     }
/* 138 */     ServletContext application = this.pageContext.getServletContext();
/* 139 */     return application.getInitParameter("javax.servlet.jsp.jstl.sql.userName");
/*     */   }
/*     */   
/*     */   private String getPassword() {
/* 143 */     ServletContext application = this.pageContext.getServletContext();
/* 144 */     return application.getInitParameter("javax.servlet.jsp.jstl.sql.password");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\DriverTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */