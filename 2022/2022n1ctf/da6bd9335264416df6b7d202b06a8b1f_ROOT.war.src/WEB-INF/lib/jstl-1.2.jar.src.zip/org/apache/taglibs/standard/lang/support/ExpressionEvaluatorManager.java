/*     */ package org.apache.taglibs.standard.lang.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.jstl.Coercions;
/*     */ import org.apache.taglibs.standard.lang.jstl.ELException;
/*     */ import org.apache.taglibs.standard.lang.jstl.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionEvaluatorManager
/*     */ {
/*     */   public static final String EVALUATOR_CLASS = "org.apache.taglibs.standard.lang.jstl.Evaluator";
/*  62 */   private static HashMap nameMap = new HashMap<Object, Object>();
/*  63 */   private static Logger logger = new Logger(System.out);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object evaluate(String attributeName, String expression, Class expectedType, Tag tag, PageContext pageContext) throws JspException {
/*  81 */     ExpressionEvaluator target = getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
/*     */ 
/*     */     
/*  84 */     return target.evaluate(attributeName, expression, expectedType, tag, pageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object evaluate(String attributeName, String expression, Class expectedType, PageContext pageContext) throws JspException {
/* 100 */     ExpressionEvaluator target = getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
/*     */ 
/*     */     
/* 103 */     return target.evaluate(attributeName, expression, expectedType, null, pageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExpressionEvaluator getEvaluatorByName(String name) throws JspException {
/* 115 */     Object oEvaluator = nameMap.get(name);
/* 116 */     if (oEvaluator != null) {
/* 117 */       return (ExpressionEvaluator)oEvaluator;
/*     */     }
/*     */     try {
/* 120 */       synchronized (nameMap) {
/* 121 */         oEvaluator = nameMap.get(name);
/* 122 */         if (oEvaluator != null) {
/* 123 */           return (ExpressionEvaluator)oEvaluator;
/*     */         }
/* 125 */         ExpressionEvaluator e = (ExpressionEvaluator)Class.forName(name).newInstance();
/*     */         
/* 127 */         nameMap.put(name, e);
/* 128 */         return e;
/*     */       } 
/* 130 */     } catch (ClassCastException ex) {
/*     */       
/* 132 */       throw new JspException("invalid ExpressionEvaluator: " + ex.toString(), ex);
/*     */     }
/* 134 */     catch (ClassNotFoundException ex) {
/* 135 */       throw new JspException("couldn't find ExpressionEvaluator: " + ex.toString(), ex);
/*     */     }
/* 137 */     catch (IllegalAccessException ex) {
/* 138 */       throw new JspException("couldn't access ExpressionEvaluator: " + ex.toString(), ex);
/*     */     }
/* 140 */     catch (InstantiationException ex) {
/* 141 */       throw new JspException("couldn't instantiate ExpressionEvaluator: " + ex.toString(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object coerce(Object value, Class classe) throws JspException {
/*     */     try {
/* 152 */       return Coercions.coerce(value, classe, logger);
/* 153 */     } catch (ELException ex) {
/* 154 */       throw new JspException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\support\ExpressionEvaluatorManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */