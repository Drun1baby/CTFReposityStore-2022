/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import javax.servlet.jsp.PageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSTLVariableResolver
/*     */   implements VariableResolver
/*     */ {
/*     */   public Object resolveVariable(String pName, Object pContext) throws ELException {
/*  53 */     PageContext ctx = (PageContext)pContext;
/*     */ 
/*     */     
/*  56 */     if ("pageContext".equals(pName)) {
/*  57 */       return ctx;
/*     */     }
/*  59 */     if ("pageScope".equals(pName)) {
/*  60 */       return ImplicitObjects.getImplicitObjects(ctx).getPageScopeMap();
/*     */     }
/*     */ 
/*     */     
/*  64 */     if ("requestScope".equals(pName)) {
/*  65 */       return ImplicitObjects.getImplicitObjects(ctx).getRequestScopeMap();
/*     */     }
/*     */ 
/*     */     
/*  69 */     if ("sessionScope".equals(pName)) {
/*  70 */       return ImplicitObjects.getImplicitObjects(ctx).getSessionScopeMap();
/*     */     }
/*     */ 
/*     */     
/*  74 */     if ("applicationScope".equals(pName)) {
/*  75 */       return ImplicitObjects.getImplicitObjects(ctx).getApplicationScopeMap();
/*     */     }
/*     */ 
/*     */     
/*  79 */     if ("param".equals(pName)) {
/*  80 */       return ImplicitObjects.getImplicitObjects(ctx).getParamMap();
/*     */     }
/*     */ 
/*     */     
/*  84 */     if ("paramValues".equals(pName)) {
/*  85 */       return ImplicitObjects.getImplicitObjects(ctx).getParamsMap();
/*     */     }
/*     */ 
/*     */     
/*  89 */     if ("header".equals(pName)) {
/*  90 */       return ImplicitObjects.getImplicitObjects(ctx).getHeaderMap();
/*     */     }
/*     */ 
/*     */     
/*  94 */     if ("headerValues".equals(pName)) {
/*  95 */       return ImplicitObjects.getImplicitObjects(ctx).getHeadersMap();
/*     */     }
/*     */ 
/*     */     
/*  99 */     if ("initParam".equals(pName)) {
/* 100 */       return ImplicitObjects.getImplicitObjects(ctx).getInitParamMap();
/*     */     }
/*     */ 
/*     */     
/* 104 */     if ("cookie".equals(pName)) {
/* 105 */       return ImplicitObjects.getImplicitObjects(ctx).getCookieMap();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     return ctx.findAttribute(pName);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\JSTLVariableResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */