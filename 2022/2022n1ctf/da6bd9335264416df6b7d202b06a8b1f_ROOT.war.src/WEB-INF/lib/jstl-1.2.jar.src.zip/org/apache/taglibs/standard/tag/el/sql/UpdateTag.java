/*    */ package org.apache.taglibs.standard.tag.el.sql;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.sql.UpdateTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateTag
/*    */   extends UpdateTagSupport
/*    */ {
/*    */   private String dataSourceEL;
/*    */   private String sqlEL;
/*    */   
/*    */   public void setDataSource(String dataSourceEL) {
/* 43 */     this.dataSourceEL = dataSourceEL;
/* 44 */     this.dataSourceSpecified = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSql(String sqlEL) {
/* 54 */     this.sqlEL = sqlEL;
/*    */   }
/*    */   
/*    */   public int doStartTag() throws JspException {
/* 58 */     if (this.dataSourceEL != null) {
/* 59 */       this.rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", this.dataSourceEL, Object.class, (Tag)this, this.pageContext);
/*    */     }
/*    */ 
/*    */     
/* 63 */     if (this.sqlEL != null) {
/* 64 */       this.sql = (String)ExpressionEvaluatorManager.evaluate("sql", this.sqlEL, String.class, (Tag)this, this.pageContext);
/*    */     }
/*    */     
/* 67 */     return super.doStartTag();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\sql\UpdateTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */