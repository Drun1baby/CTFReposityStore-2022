/*    */ package org.apache.taglibs.standard.tag.el.sql;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.sql.TransactionTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionTag
/*    */   extends TransactionTagSupport
/*    */ {
/*    */   private String dataSourceEL;
/*    */   private String isolationEL;
/*    */   
/*    */   public void setDataSource(String dataSourceEL) {
/* 44 */     this.dataSourceEL = dataSourceEL;
/* 45 */     this.dataSourceSpecified = true;
/*    */   }
/*    */   
/*    */   public void setIsolation(String isolationEL) {
/* 49 */     this.isolationEL = isolationEL;
/*    */   }
/*    */   
/*    */   public int doStartTag() throws JspException {
/* 53 */     if (this.dataSourceEL != null) {
/* 54 */       this.rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", this.dataSourceEL, Object.class, (Tag)this, this.pageContext);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 59 */     if (this.isolationEL != null) {
/* 60 */       this.isolationEL = (String)ExpressionEvaluatorManager.evaluate("isolation", this.isolationEL, String.class, (Tag)this, this.pageContext);
/*    */ 
/*    */       
/* 63 */       super.setIsolation(this.isolationEL);
/*    */     } 
/*    */     
/* 66 */     return super.doStartTag();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\sql\TransactionTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */