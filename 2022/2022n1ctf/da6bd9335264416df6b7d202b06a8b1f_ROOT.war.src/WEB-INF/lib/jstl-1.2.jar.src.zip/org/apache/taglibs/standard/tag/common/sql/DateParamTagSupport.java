/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DateParamTagSupport
/*     */   extends TagSupport
/*     */ {
/*     */   private static final String TIMESTAMP_TYPE = "timestamp";
/*     */   private static final String TIME_TYPE = "time";
/*     */   private static final String DATE_TYPE = "date";
/*     */   protected String type;
/*     */   protected Date value;
/*     */   
/*     */   public DateParamTagSupport() {
/*  64 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  68 */     this.value = null;
/*  69 */     this.type = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  77 */     SQLExecutionTag parent = (SQLExecutionTag)findAncestorWithClass((Tag)this, SQLExecutionTag.class);
/*     */     
/*  79 */     if (parent == null) {
/*  80 */       throw new JspTagException(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
/*     */     }
/*     */ 
/*     */     
/*  84 */     if (this.value != null) {
/*  85 */       convertValue();
/*     */     }
/*     */     
/*  88 */     parent.addSQLParameter(this.value);
/*  89 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void convertValue() throws JspException {
/*  98 */     if (this.type == null || this.type.equalsIgnoreCase("timestamp")) {
/*  99 */       if (!(this.value instanceof Timestamp)) {
/* 100 */         this.value = new Timestamp(this.value.getTime());
/*     */       }
/* 102 */     } else if (this.type.equalsIgnoreCase("time")) {
/* 103 */       if (!(this.value instanceof Time)) {
/* 104 */         this.value = new Time(this.value.getTime());
/*     */       }
/* 106 */     } else if (this.type.equalsIgnoreCase("date")) {
/* 107 */       if (!(this.value instanceof Date)) {
/* 108 */         this.value = new Date(this.value.getTime());
/*     */       }
/*     */     } else {
/* 111 */       throw new JspException(Resources.getMessage("SQL_DATE_PARAM_INVALID_TYPE", this.type));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\DateParamTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */