/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RedirectSupport
/*     */   extends BodyTagSupport
/*     */   implements ParamParent
/*     */ {
/*     */   protected String url;
/*     */   protected String context;
/*     */   private String var;
/*     */   private int scope;
/*     */   private ParamSupport.ParamManager params;
/*     */   
/*     */   public RedirectSupport() {
/*  62 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  66 */     this.url = this.var = null;
/*  67 */     this.params = null;
/*  68 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/*  76 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/*  80 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String name, String value) {
/*  89 */     this.params.addParameter(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  98 */     this.params = new ParamSupport.ParamManager();
/*  99 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 108 */     String baseUrl = UrlSupport.resolveUrl(this.url, this.context, this.pageContext);
/* 109 */     String result = this.params.aggregateParams(baseUrl);
/*     */ 
/*     */     
/* 112 */     HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/*     */     
/* 114 */     if (!ImportSupport.isAbsoluteUrl(result)) {
/* 115 */       result = response.encodeRedirectURL(result);
/*     */     }
/*     */     
/*     */     try {
/* 119 */       response.sendRedirect(result);
/* 120 */     } catch (IOException ex) {
/* 121 */       throw new JspTagException(ex.toString(), ex);
/*     */     } 
/*     */     
/* 124 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 129 */     init();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\RedirectSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */