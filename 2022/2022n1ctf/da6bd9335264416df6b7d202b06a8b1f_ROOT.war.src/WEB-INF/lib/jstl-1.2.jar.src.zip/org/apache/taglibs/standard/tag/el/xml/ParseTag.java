/*     */ package org.apache.taglibs.standard.tag.el.xml;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ import org.apache.taglibs.standard.tag.common.xml.ParseSupport;
/*     */ import org.apache.taglibs.standard.tag.el.core.ExpressionUtil;
/*     */ import org.xml.sax.XMLFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTag
/*     */   extends ParseSupport
/*     */ {
/*     */   private String xml_;
/*     */   private String systemId_;
/*     */   private String filter_;
/*     */   
/*     */   public ParseTag() {
/*  61 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  72 */     evaluateExpressions();
/*     */ 
/*     */     
/*  75 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  81 */     super.release();
/*  82 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilter(String filter_) {
/*  91 */     this.filter_ = filter_;
/*     */   }
/*     */   
/*     */   public void setXml(String xml_) {
/*  95 */     this.xml_ = xml_;
/*     */   }
/*     */   
/*     */   public void setSystemId(String systemId_) {
/*  99 */     this.systemId_ = systemId_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 109 */     this.filter_ = this.xml_ = this.systemId_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 122 */     this.xml = ExpressionUtil.evalNotNull("parse", "xml", this.xml_, Object.class, (Tag)this, this.pageContext);
/*     */     
/* 124 */     this.systemId = (String)ExpressionUtil.evalNotNull("parse", "systemId", this.systemId_, String.class, (Tag)this, this.pageContext);
/*     */ 
/*     */     
/*     */     try {
/* 128 */       this.filter = (XMLFilter)ExpressionUtil.evalNotNull("parse", "filter", this.filter_, XMLFilter.class, (Tag)this, this.pageContext);
/*     */     }
/* 130 */     catch (NullAttributeException ex) {
/*     */       
/* 132 */       this.filter = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\xml\ParseTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */