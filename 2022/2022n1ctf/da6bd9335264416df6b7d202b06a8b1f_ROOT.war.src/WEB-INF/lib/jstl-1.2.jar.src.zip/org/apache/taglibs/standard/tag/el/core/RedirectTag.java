/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.RedirectSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RedirectTag
/*     */   extends RedirectSupport
/*     */ {
/*     */   private String url_;
/*     */   private String context_;
/*     */   
/*     */   public RedirectTag() {
/*  58 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  69 */     evaluateExpressions();
/*     */ 
/*     */     
/*  72 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  78 */     super.release();
/*  79 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrl(String url_) {
/*  87 */     this.url_ = url_;
/*     */   }
/*     */   
/*     */   public void setContext(String context_) {
/*  91 */     this.context_ = context_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 100 */     this.url_ = this.context_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 113 */     this.url = (String)ExpressionUtil.evalNotNull("redirect", "url", this.url_, String.class, (Tag)this, this.pageContext);
/*     */     
/* 115 */     this.context = (String)ExpressionUtil.evalNotNull("redirect", "context", this.context_, String.class, (Tag)this, this.pageContext);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\RedirectTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */