/*     */ package org.apache.taglibs.standard.tlv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.TagData;
/*     */ import javax.servlet.jsp.tagext.TagLibraryValidator;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluator;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JstlBaseTLV
/*     */   extends TagLibraryValidator
/*     */ {
/*  76 */   private final String EXP_ATT_PARAM = "expressionAttributes";
/*     */   
/*     */   protected static final String VAR = "var";
/*     */   
/*     */   protected static final String SCOPE = "scope";
/*     */   
/*     */   protected static final String PAGE_SCOPE = "page";
/*     */   
/*     */   protected static final String REQUEST_SCOPE = "request";
/*     */   
/*     */   protected static final String SESSION_SCOPE = "session";
/*     */   
/*     */   protected static final String APPLICATION_SCOPE = "application";
/*  89 */   protected final String JSP = "http://java.sun.com/JSP/Page";
/*     */   
/*     */   private static final int TYPE_UNDEFINED = 0;
/*     */   
/*     */   protected static final int TYPE_CORE = 1;
/*     */   
/*     */   protected static final int TYPE_FMT = 2;
/*     */   
/*     */   protected static final int TYPE_SQL = 3;
/*     */   protected static final int TYPE_XML = 4;
/*  99 */   private int tlvType = 0;
/*     */   
/*     */   protected String uri;
/*     */   
/*     */   protected String prefix;
/*     */   
/*     */   protected Vector messageVector;
/*     */   
/*     */   protected Map config;
/*     */   
/*     */   protected boolean failed;
/*     */   
/*     */   protected String lastElementId;
/*     */   
/*     */   protected abstract DefaultHandler getHandler();
/*     */   
/*     */   public JstlBaseTLV() {
/* 116 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/* 120 */     this.messageVector = null;
/* 121 */     this.prefix = null;
/* 122 */     this.config = null;
/*     */   }
/*     */   
/*     */   public void release() {
/* 126 */     super.release();
/* 127 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ValidationMessage[] validate(int type, String prefix, String uri, PageData page) {
/*     */     try {
/* 138 */       this.tlvType = type;
/* 139 */       this.uri = uri;
/*     */       
/* 141 */       this.messageVector = new Vector();
/*     */ 
/*     */       
/* 144 */       this.prefix = prefix;
/*     */ 
/*     */       
/*     */       try {
/* 148 */         if (this.config == null)
/* 149 */           configure((String)getInitParameters().get("expressionAttributes")); 
/* 150 */       } catch (NoSuchElementException ex) {
/*     */         
/* 152 */         return vmFromString(Resources.getMessage("TLV_PARAMETER_ERROR", "expressionAttributes"));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       DefaultHandler h = getHandler();
/*     */ 
/*     */       
/* 161 */       SAXParserFactory f = SAXParserFactory.newInstance();
/* 162 */       f.setValidating(false);
/* 163 */       f.setNamespaceAware(true);
/* 164 */       SAXParser p = f.newSAXParser();
/* 165 */       p.parse(page.getInputStream(), h);
/*     */       
/* 167 */       if (this.messageVector.size() == 0) {
/* 168 */         return null;
/*     */       }
/* 170 */       return vmFromVector(this.messageVector);
/*     */     }
/* 172 */     catch (SAXException ex) {
/* 173 */       return vmFromString(ex.toString());
/* 174 */     } catch (ParserConfigurationException ex) {
/* 175 */       return vmFromString(ex.toString());
/* 176 */     } catch (IOException ex) {
/* 177 */       return vmFromString(ex.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String validateExpression(String elem, String att, String expr) {
/*     */     ExpressionEvaluator current;
/*     */     try {
/* 191 */       current = ExpressionEvaluatorManager.getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
/*     */     
/*     */     }
/* 194 */     catch (JspException ex) {
/*     */       
/* 196 */       return ex.getMessage();
/*     */     } 
/*     */     
/* 199 */     String response = current.validate(att, expr);
/* 200 */     if (response == null) {
/* 201 */       return response;
/*     */     }
/* 203 */     return "tag = '" + elem + "' / attribute = '" + att + "': " + response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTag(String tagUri, String tagLn, String matchUri, String matchLn) {
/* 212 */     if (tagUri == null || tagUri.length() == 0 || tagLn == null || matchUri == null || matchLn == null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     if (tagUri.length() > matchUri.length()) {
/* 221 */       return (tagUri.startsWith(matchUri) && tagLn.equals(matchLn));
/*     */     }
/* 223 */     return (matchUri.startsWith(tagUri) && tagLn.equals(matchLn));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isJspTag(String tagUri, String tagLn, String target) {
/* 228 */     return isTag(tagUri, tagLn, "http://java.sun.com/JSP/Page", target);
/*     */   }
/*     */   
/*     */   private boolean isTag(int type, String tagUri, String tagLn, String target) {
/* 232 */     return (this.tlvType == type && isTag(tagUri, tagLn, this.uri, target));
/*     */   }
/*     */   
/*     */   protected boolean isCoreTag(String tagUri, String tagLn, String target) {
/* 236 */     return isTag(1, tagUri, tagLn, target);
/*     */   }
/*     */   
/*     */   protected boolean isFmtTag(String tagUri, String tagLn, String target) {
/* 240 */     return isTag(2, tagUri, tagLn, target);
/*     */   }
/*     */   
/*     */   protected boolean isSqlTag(String tagUri, String tagLn, String target) {
/* 244 */     return isTag(3, tagUri, tagLn, target);
/*     */   }
/*     */   
/*     */   protected boolean isXmlTag(String tagUri, String tagLn, String target) {
/* 248 */     return isTag(4, tagUri, tagLn, target);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasAttribute(Attributes a, String att) {
/* 253 */     return (a.getValue(att) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fail(String message) {
/* 261 */     this.failed = true;
/* 262 */     this.messageVector.add(new ValidationMessage(this.lastElementId, message));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSpecified(TagData data, String attributeName) {
/* 267 */     return (data.getAttribute(attributeName) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasNoInvalidScope(Attributes a) {
/* 272 */     String scope = a.getValue("scope");
/*     */     
/* 274 */     if (scope != null && !scope.equals("page") && !scope.equals("request") && !scope.equals("session") && !scope.equals("application"))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 279 */       return false;
/*     */     }
/* 281 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasEmptyVar(Attributes a) {
/* 286 */     if ("".equals(a.getValue("var")))
/* 287 */       return true; 
/* 288 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasDanglingScope(Attributes a) {
/* 293 */     return (a.getValue("scope") != null && a.getValue("var") == null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getLocalPart(String qname) {
/* 298 */     int colon = qname.indexOf(":");
/* 299 */     if (colon == -1) {
/* 300 */       return qname;
/*     */     }
/* 302 */     return qname.substring(colon + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configure(String info) {
/* 311 */     this.config = new HashMap<Object, Object>();
/*     */ 
/*     */     
/* 314 */     if (info == null) {
/*     */       return;
/*     */     }
/*     */     
/* 318 */     StringTokenizer st = new StringTokenizer(info);
/* 319 */     while (st.hasMoreTokens()) {
/* 320 */       String pair = st.nextToken();
/* 321 */       StringTokenizer pairTokens = new StringTokenizer(pair, ":");
/* 322 */       String element = pairTokens.nextToken();
/* 323 */       String attribute = pairTokens.nextToken();
/* 324 */       Object atts = this.config.get(element);
/* 325 */       if (atts == null) {
/* 326 */         atts = new HashSet();
/* 327 */         this.config.put(element, atts);
/*     */       } 
/* 329 */       ((Set<String>)atts).add(attribute);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static ValidationMessage[] vmFromString(String message) {
/* 335 */     return new ValidationMessage[] { new ValidationMessage(null, message) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ValidationMessage[] vmFromVector(Vector<ValidationMessage> v) {
/* 342 */     ValidationMessage[] vm = new ValidationMessage[v.size()];
/* 343 */     for (int i = 0; i < vm.length; i++)
/* 344 */       vm[i] = v.get(i); 
/* 345 */     return vm;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tlv\JstlBaseTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */