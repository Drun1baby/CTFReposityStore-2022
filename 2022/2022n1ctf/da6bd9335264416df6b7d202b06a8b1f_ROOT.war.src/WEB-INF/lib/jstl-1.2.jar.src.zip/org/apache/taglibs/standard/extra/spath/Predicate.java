package org.apache.taglibs.standard.extra.spath;

public abstract class Predicate {}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\Predicate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */