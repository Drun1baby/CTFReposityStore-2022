package org.apache.taglibs.standard.lang.support;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public interface ExpressionEvaluator {
  String validate(String paramString1, String paramString2);
  
  Object evaluate(String paramString1, String paramString2, Class paramClass, Tag paramTag, PageContext paramPageContext) throws JspException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\support\ExpressionEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */