/*    */ package org.apache.taglibs.standard.tei;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportTEI
/*    */   extends TagExtraInfo
/*    */ {
/*    */   private static final String VAR = "var";
/*    */   private static final String VAR_READER = "varReader";
/*    */   
/*    */   public boolean isValid(TagData us) {
/* 44 */     if (Util.isSpecified(us, "var") && Util.isSpecified(us, "varReader")) {
/* 45 */       return false;
/*    */     }
/* 47 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tei\ImportTEI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */