/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.FormatNumberSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatNumberTag
/*    */   extends FormatNumberSupport
/*    */ {
/*    */   public void setValue(Object value) throws JspTagException {
/* 46 */     this.value = value;
/* 47 */     this.valueSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(String type) throws JspTagException {
/* 52 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPattern(String pattern) throws JspTagException {
/* 57 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCurrencyCode(String currencyCode) throws JspTagException {
/* 62 */     this.currencyCode = currencyCode;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCurrencySymbol(String currencySymbol) throws JspTagException {
/* 68 */     this.currencySymbol = currencySymbol;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setGroupingUsed(boolean isGroupingUsed) throws JspTagException {
/* 74 */     this.isGroupingUsed = isGroupingUsed;
/* 75 */     this.groupingUsedSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMaxIntegerDigits(int maxDigits) throws JspTagException {
/* 80 */     this.maxIntegerDigits = maxDigits;
/* 81 */     this.maxIntegerDigitsSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMinIntegerDigits(int minDigits) throws JspTagException {
/* 86 */     this.minIntegerDigits = minDigits;
/* 87 */     this.minIntegerDigitsSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMaxFractionDigits(int maxDigits) throws JspTagException {
/* 92 */     this.maxFractionDigits = maxDigits;
/* 93 */     this.maxFractionDigitsSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMinFractionDigits(int minDigits) throws JspTagException {
/* 98 */     this.minFractionDigits = minDigits;
/* 99 */     this.minFractionDigitsSpecified = true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\FormatNumberTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */