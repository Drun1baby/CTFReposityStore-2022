/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnaryMinusOperator
/*     */   extends UnaryOperator
/*     */ {
/*  43 */   public static final UnaryMinusOperator SINGLETON = new UnaryMinusOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  64 */     return "-";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pValue, Object pContext, Logger pLogger) throws ELException {
/*  77 */     if (pValue == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  85 */       return PrimitiveObjects.getInteger(0);
/*     */     }
/*     */     
/*  88 */     if (pValue instanceof String) {
/*  89 */       if (Coercions.isFloatingPointString(pValue)) {
/*  90 */         double dval = Coercions.coerceToPrimitiveNumber(pValue, Double.class, pLogger).doubleValue();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  95 */         return PrimitiveObjects.getDouble(-dval);
/*     */       } 
/*     */       
/*  98 */       long lval = Coercions.coerceToPrimitiveNumber(pValue, Long.class, pLogger).longValue();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       return PrimitiveObjects.getLong(-lval);
/*     */     } 
/*     */ 
/*     */     
/* 107 */     if (pValue instanceof Byte) {
/* 108 */       return PrimitiveObjects.getByte((byte)-((Byte)pValue).byteValue());
/*     */     }
/*     */     
/* 111 */     if (pValue instanceof Short) {
/* 112 */       return PrimitiveObjects.getShort((short)-((Short)pValue).shortValue());
/*     */     }
/*     */     
/* 115 */     if (pValue instanceof Integer) {
/* 116 */       return PrimitiveObjects.getInteger(-((Integer)pValue).intValue());
/*     */     }
/*     */     
/* 119 */     if (pValue instanceof Long) {
/* 120 */       return PrimitiveObjects.getLong(-((Long)pValue).longValue());
/*     */     }
/*     */     
/* 123 */     if (pValue instanceof Float) {
/* 124 */       return PrimitiveObjects.getFloat(-((Float)pValue).floatValue());
/*     */     }
/*     */     
/* 127 */     if (pValue instanceof Double) {
/* 128 */       return PrimitiveObjects.getDouble(-((Double)pValue).doubleValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (pLogger.isLoggingError()) {
/* 134 */       pLogger.logError(Constants.UNARY_OP_BAD_TYPE, getOperatorSymbol(), pValue.getClass().getName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 139 */     return PrimitiveObjects.getInteger(0);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\UnaryMinusOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */