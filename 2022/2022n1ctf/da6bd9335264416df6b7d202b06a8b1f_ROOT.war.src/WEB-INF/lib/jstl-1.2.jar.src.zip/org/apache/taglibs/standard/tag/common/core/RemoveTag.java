/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoveTag
/*     */   extends TagSupport
/*     */ {
/*  45 */   private final String APPLICATION = "application";
/*  46 */   private final String SESSION = "session";
/*  47 */   private final String REQUEST = "request";
/*  48 */   private final String PAGE = "page";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int scope;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean scopeSpecified;
/*     */ 
/*     */ 
/*     */   
/*     */   private String var;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoveTag() {
/*  68 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*  73 */     this.var = null;
/*  74 */     this.scope = 1;
/*  75 */     this.scopeSpecified = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  80 */     super.release();
/*  81 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  90 */     if (!this.scopeSpecified) {
/*  91 */       this.pageContext.removeAttribute(this.var);
/*     */     } else {
/*  93 */       this.pageContext.removeAttribute(this.var, this.scope);
/*  94 */     }  return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 103 */     this.var = var;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 108 */     this.scope = Util.getScope(scope);
/* 109 */     this.scopeSpecified = true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\RemoveTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */