/*    */ package org.apache.taglibs.standard.tag.rt.xml;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.xml.ParamSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamTag
/*    */   extends ParamSupport
/*    */ {
/*    */   public void setName(String name) throws JspTagException {
/* 46 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object value) throws JspTagException {
/* 51 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\xml\ParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */