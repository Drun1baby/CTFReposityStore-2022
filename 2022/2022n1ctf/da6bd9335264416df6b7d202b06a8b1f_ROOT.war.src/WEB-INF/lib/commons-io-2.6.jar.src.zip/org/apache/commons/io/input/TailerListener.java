package org.apache.commons.io.input;

public interface TailerListener {
  void init(Tailer paramTailer);
  
  void fileNotFound();
  
  void fileRotated();
  
  void handle(String paramString);
  
  void handle(Exception paramException);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-io-2.6.jar!\org\apache\commons\io\input\TailerListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */