package org.apache.commons.fileupload;

public interface FileItemFactory {
  FileItem createItem(String paramString1, String paramString2, boolean paramBoolean, String paramString3);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileItemFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */