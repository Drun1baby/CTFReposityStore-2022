/*      */ package org.apache.commons.fileupload;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import org.apache.commons.fileupload.util.Closeable;
/*      */ import org.apache.commons.fileupload.util.Streams;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MultipartStream
/*      */ {
/*      */   public static final byte CR = 13;
/*      */   public static final byte LF = 10;
/*      */   public static final byte DASH = 45;
/*      */   public static final int HEADER_PART_SIZE_MAX = 10240;
/*      */   protected static final int DEFAULT_BUFSIZE = 4096;
/*      */   
/*      */   public static class ProgressNotifier
/*      */   {
/*      */     private final ProgressListener listener;
/*      */     private final long contentLength;
/*      */     private long bytesRead;
/*      */     private int items;
/*      */     
/*      */     ProgressNotifier(ProgressListener pListener, long pContentLength) {
/*  120 */       this.listener = pListener;
/*  121 */       this.contentLength = pContentLength;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void noteBytesRead(int pBytes) {
/*  133 */       this.bytesRead += pBytes;
/*  134 */       notifyListener();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void noteItem() {
/*  141 */       this.items++;
/*  142 */       notifyListener();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void notifyListener() {
/*  149 */       if (this.listener != null) {
/*  150 */         this.listener.update(this.bytesRead, this.contentLength, this.items);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  188 */   protected static final byte[] HEADER_SEPARATOR = new byte[] { 13, 10, 13, 10 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   protected static final byte[] FIELD_SEPARATOR = new byte[] { 13, 10 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  200 */   protected static final byte[] STREAM_TERMINATOR = new byte[] { 45, 45 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  205 */   protected static final byte[] BOUNDARY_PREFIX = new byte[] { 13, 10, 45, 45 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final InputStream input;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int boundaryLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int keepRegion;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte[] boundary;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int[] boundaryTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int bufSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte[] buffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int head;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int tail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String headerEncoding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ProgressNotifier notifier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MultipartStream() {
/*  279 */     this((InputStream)null, (byte[])null, (ProgressNotifier)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MultipartStream(InputStream input, byte[] boundary, int bufSize) {
/*  301 */     this(input, boundary, bufSize, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MultipartStream(InputStream input, byte[] boundary, int bufSize, ProgressNotifier pNotifier) {
/*  328 */     if (boundary == null) {
/*  329 */       throw new IllegalArgumentException("boundary may not be null");
/*      */     }
/*      */ 
/*      */     
/*  333 */     this.boundaryLength = boundary.length + BOUNDARY_PREFIX.length;
/*  334 */     if (bufSize < this.boundaryLength + 1) {
/*  335 */       throw new IllegalArgumentException("The buffer size specified for the MultipartStream is too small");
/*      */     }
/*      */ 
/*      */     
/*  339 */     this.input = input;
/*  340 */     this.bufSize = Math.max(bufSize, this.boundaryLength * 2);
/*  341 */     this.buffer = new byte[this.bufSize];
/*  342 */     this.notifier = pNotifier;
/*      */     
/*  344 */     this.boundary = new byte[this.boundaryLength];
/*  345 */     this.boundaryTable = new int[this.boundaryLength + 1];
/*  346 */     this.keepRegion = this.boundary.length;
/*      */     
/*  348 */     System.arraycopy(BOUNDARY_PREFIX, 0, this.boundary, 0, BOUNDARY_PREFIX.length);
/*      */     
/*  350 */     System.arraycopy(boundary, 0, this.boundary, BOUNDARY_PREFIX.length, boundary.length);
/*      */     
/*  352 */     computeBoundaryTable();
/*      */     
/*  354 */     this.head = 0;
/*  355 */     this.tail = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MultipartStream(InputStream input, byte[] boundary, ProgressNotifier pNotifier) {
/*  372 */     this(input, boundary, 4096, pNotifier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MultipartStream(InputStream input, byte[] boundary) {
/*  388 */     this(input, boundary, 4096, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderEncoding() {
/*  401 */     return this.headerEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeaderEncoding(String encoding) {
/*  412 */     this.headerEncoding = encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte readByte() throws IOException {
/*  425 */     if (this.head == this.tail) {
/*  426 */       this.head = 0;
/*      */       
/*  428 */       this.tail = this.input.read(this.buffer, this.head, this.bufSize);
/*  429 */       if (this.tail == -1)
/*      */       {
/*  431 */         throw new IOException("No more data is available");
/*      */       }
/*  433 */       if (this.notifier != null) {
/*  434 */         this.notifier.noteBytesRead(this.tail);
/*      */       }
/*      */     } 
/*  437 */     return this.buffer[this.head++];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readBoundary() throws FileUploadBase.FileUploadIOException, MalformedStreamException {
/*  453 */     byte[] marker = new byte[2];
/*  454 */     boolean nextChunk = false;
/*      */     
/*  456 */     this.head += this.boundaryLength;
/*      */     try {
/*  458 */       marker[0] = readByte();
/*  459 */       if (marker[0] == 10)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  466 */         return true;
/*      */       }
/*      */       
/*  469 */       marker[1] = readByte();
/*  470 */       if (arrayequals(marker, STREAM_TERMINATOR, 2)) {
/*  471 */         nextChunk = false;
/*  472 */       } else if (arrayequals(marker, FIELD_SEPARATOR, 2)) {
/*  473 */         nextChunk = true;
/*      */       } else {
/*  475 */         throw new MalformedStreamException("Unexpected characters follow a boundary");
/*      */       }
/*      */     
/*  478 */     } catch (FileUploadIOException e) {
/*      */       
/*  480 */       throw e;
/*  481 */     } catch (IOException e) {
/*  482 */       throw new MalformedStreamException("Stream ended unexpectedly");
/*      */     } 
/*  484 */     return nextChunk;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoundary(byte[] boundary) throws IllegalBoundaryException {
/*  508 */     if (boundary.length != this.boundaryLength - BOUNDARY_PREFIX.length) {
/*  509 */       throw new IllegalBoundaryException("The length of a boundary token cannot be changed");
/*      */     }
/*      */     
/*  512 */     System.arraycopy(boundary, 0, this.boundary, BOUNDARY_PREFIX.length, boundary.length);
/*      */     
/*  514 */     computeBoundaryTable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void computeBoundaryTable() {
/*  521 */     int position = 2;
/*  522 */     int candidate = 0;
/*      */     
/*  524 */     this.boundaryTable[0] = -1;
/*  525 */     this.boundaryTable[1] = 0;
/*      */     
/*  527 */     while (position <= this.boundaryLength) {
/*  528 */       if (this.boundary[position - 1] == this.boundary[candidate]) {
/*  529 */         this.boundaryTable[position] = candidate + 1;
/*  530 */         candidate++;
/*  531 */         position++; continue;
/*  532 */       }  if (candidate > 0) {
/*  533 */         candidate = this.boundaryTable[candidate]; continue;
/*      */       } 
/*  535 */       this.boundaryTable[position] = 0;
/*  536 */       position++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String readHeaders() throws FileUploadBase.FileUploadIOException, MalformedStreamException {
/*  558 */     int i = 0;
/*      */ 
/*      */     
/*  561 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  562 */     int size = 0;
/*  563 */     while (i < HEADER_SEPARATOR.length) {
/*      */       byte b; try {
/*  565 */         b = readByte();
/*  566 */       } catch (FileUploadIOException e) {
/*      */         
/*  568 */         throw e;
/*  569 */       } catch (IOException e) {
/*  570 */         throw new MalformedStreamException("Stream ended unexpectedly");
/*      */       } 
/*  572 */       if (++size > 10240)
/*  573 */         throw new MalformedStreamException(
/*  574 */             String.format("Header section has more than %s bytes (maybe it is not properly terminated)", new Object[] {
/*  575 */                 Integer.valueOf(10240)
/*      */               })); 
/*  577 */       if (b == HEADER_SEPARATOR[i]) {
/*  578 */         i++;
/*      */       } else {
/*  580 */         i = 0;
/*      */       } 
/*  582 */       baos.write(b);
/*      */     } 
/*      */     
/*  585 */     String headers = null;
/*  586 */     if (this.headerEncoding != null) {
/*      */       try {
/*  588 */         headers = baos.toString(this.headerEncoding);
/*  589 */       } catch (UnsupportedEncodingException e) {
/*      */ 
/*      */         
/*  592 */         headers = baos.toString();
/*      */       } 
/*      */     } else {
/*  595 */       headers = baos.toString();
/*      */     } 
/*      */     
/*  598 */     return headers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBodyData(OutputStream output) throws MalformedStreamException, IOException {
/*  622 */     return (int)Streams.copy(newInputStream(), output, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ItemInputStream newInputStream() {
/*  630 */     return new ItemInputStream();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int discardBodyData() throws MalformedStreamException, IOException {
/*  646 */     return readBodyData(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean skipPreamble() throws IOException {
/*  659 */     System.arraycopy(this.boundary, 2, this.boundary, 0, this.boundary.length - 2);
/*  660 */     this.boundaryLength = this.boundary.length - 2;
/*  661 */     computeBoundaryTable();
/*      */     
/*      */     try {
/*  664 */       discardBodyData();
/*      */ 
/*      */ 
/*      */       
/*  668 */       return readBoundary();
/*  669 */     } catch (MalformedStreamException e) {
/*  670 */       return false;
/*      */     } finally {
/*      */       
/*  673 */       System.arraycopy(this.boundary, 0, this.boundary, 2, this.boundary.length - 2);
/*  674 */       this.boundaryLength = this.boundary.length;
/*  675 */       this.boundary[0] = 13;
/*  676 */       this.boundary[1] = 10;
/*  677 */       computeBoundaryTable();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean arrayequals(byte[] a, byte[] b, int count) {
/*  695 */     for (int i = 0; i < count; i++) {
/*  696 */       if (a[i] != b[i]) {
/*  697 */         return false;
/*      */       }
/*      */     } 
/*  700 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findByte(byte value, int pos) {
/*  715 */     for (int i = pos; i < this.tail; i++) {
/*  716 */       if (this.buffer[i] == value) {
/*  717 */         return i;
/*      */       }
/*      */     } 
/*      */     
/*  721 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int findSeparator() {
/*  734 */     int bufferPos = this.head;
/*  735 */     int tablePos = 0;
/*      */     
/*  737 */     while (bufferPos < this.tail) {
/*  738 */       while (tablePos >= 0 && this.buffer[bufferPos] != this.boundary[tablePos]) {
/*  739 */         tablePos = this.boundaryTable[tablePos];
/*      */       }
/*  741 */       bufferPos++;
/*  742 */       tablePos++;
/*  743 */       if (tablePos == this.boundaryLength) {
/*  744 */         return bufferPos - this.boundaryLength;
/*      */       }
/*      */     } 
/*  747 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MalformedStreamException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = 6466926458059796677L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MalformedStreamException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MalformedStreamException(String message) {
/*  776 */       super(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IllegalBoundaryException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = -161533165102632918L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IllegalBoundaryException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IllegalBoundaryException(String message) {
/*  806 */       super(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class ItemInputStream
/*      */     extends InputStream
/*      */     implements Closeable
/*      */   {
/*      */     private long total;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int pad;
/*      */ 
/*      */ 
/*      */     
/*      */     private int pos;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean closed;
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int BYTE_POSITIVE_OFFSET = 256;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ItemInputStream() {
/*  841 */       findSeparator();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void findSeparator() {
/*  848 */       this.pos = MultipartStream.this.findSeparator();
/*  849 */       if (this.pos == -1) {
/*  850 */         if (MultipartStream.this.tail - MultipartStream.this.head > MultipartStream.this.keepRegion) {
/*  851 */           this.pad = MultipartStream.this.keepRegion;
/*      */         } else {
/*  853 */           this.pad = MultipartStream.this.tail - MultipartStream.this.head;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getBytesRead() {
/*  865 */       return this.total;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int available() throws IOException {
/*  877 */       if (this.pos == -1) {
/*  878 */         return MultipartStream.this.tail - MultipartStream.this.head - this.pad;
/*      */       }
/*  880 */       return this.pos - MultipartStream.this.head;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read() throws IOException {
/*  897 */       if (this.closed) {
/*  898 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  900 */       if (available() == 0 && makeAvailable() == 0) {
/*  901 */         return -1;
/*      */       }
/*  903 */       this.total++;
/*  904 */       int b = MultipartStream.this.buffer[MultipartStream.this.head++];
/*  905 */       if (b >= 0) {
/*  906 */         return b;
/*      */       }
/*  908 */       return b + 256;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(byte[] b, int off, int len) throws IOException {
/*  923 */       if (this.closed) {
/*  924 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  926 */       if (len == 0) {
/*  927 */         return 0;
/*      */       }
/*  929 */       int res = available();
/*  930 */       if (res == 0) {
/*  931 */         res = makeAvailable();
/*  932 */         if (res == 0) {
/*  933 */           return -1;
/*      */         }
/*      */       } 
/*  936 */       res = Math.min(res, len);
/*  937 */       System.arraycopy(MultipartStream.this.buffer, MultipartStream.this.head, b, off, res);
/*  938 */       MultipartStream.this.head = MultipartStream.this.head + res;
/*  939 */       this.total += res;
/*  940 */       return res;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/*  950 */       close(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close(boolean pCloseUnderlying) throws IOException {
/*  961 */       if (this.closed) {
/*      */         return;
/*      */       }
/*  964 */       if (pCloseUnderlying) {
/*  965 */         this.closed = true;
/*  966 */         MultipartStream.this.input.close();
/*      */       } else {
/*      */         while (true) {
/*  969 */           int av = available();
/*  970 */           if (av == 0) {
/*  971 */             av = makeAvailable();
/*  972 */             if (av == 0) {
/*      */               break;
/*      */             }
/*      */           } 
/*  976 */           skip(av);
/*      */         } 
/*      */       } 
/*  979 */       this.closed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long skip(long bytes) throws IOException {
/*  992 */       if (this.closed) {
/*  993 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  995 */       int av = available();
/*  996 */       if (av == 0) {
/*  997 */         av = makeAvailable();
/*  998 */         if (av == 0) {
/*  999 */           return 0L;
/*      */         }
/*      */       } 
/* 1002 */       long res = Math.min(av, bytes);
/* 1003 */       MultipartStream.this.head = (int)(MultipartStream.this.head + res);
/* 1004 */       return res;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int makeAvailable() throws IOException {
/*      */       int av;
/* 1014 */       if (this.pos != -1) {
/* 1015 */         return 0;
/*      */       }
/*      */ 
/*      */       
/* 1019 */       this.total += (MultipartStream.this.tail - MultipartStream.this.head - this.pad);
/* 1020 */       System.arraycopy(MultipartStream.this.buffer, MultipartStream.this.tail - this.pad, MultipartStream.this.buffer, 0, this.pad);
/*      */ 
/*      */       
/* 1023 */       MultipartStream.this.head = 0;
/* 1024 */       MultipartStream.this.tail = this.pad;
/*      */       
/*      */       do {
/* 1027 */         int bytesRead = MultipartStream.this.input.read(MultipartStream.this.buffer, MultipartStream.this.tail, MultipartStream.this.bufSize - MultipartStream.this.tail);
/* 1028 */         if (bytesRead == -1) {
/*      */ 
/*      */ 
/*      */           
/* 1032 */           String msg = "Stream ended unexpectedly";
/* 1033 */           throw new MultipartStream.MalformedStreamException("Stream ended unexpectedly");
/*      */         } 
/* 1035 */         if (MultipartStream.this.notifier != null) {
/* 1036 */           MultipartStream.this.notifier.noteBytesRead(bytesRead);
/*      */         }
/* 1038 */         MultipartStream.this.tail = MultipartStream.this.tail + bytesRead;
/*      */         
/* 1040 */         findSeparator();
/* 1041 */         av = available();
/*      */       }
/* 1043 */       while (av <= 0 && this.pos == -1);
/* 1044 */       return av;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isClosed() {
/* 1056 */       return this.closed;
/*      */     }
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\MultipartStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */