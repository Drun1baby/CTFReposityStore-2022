package org.apache.commons.fileupload;

import java.io.IOException;
import java.io.InputStream;

public interface RequestContext {
  String getCharacterEncoding();
  
  String getContentType();
  
  @Deprecated
  int getContentLength();
  
  InputStream getInputStream() throws IOException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\RequestContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */