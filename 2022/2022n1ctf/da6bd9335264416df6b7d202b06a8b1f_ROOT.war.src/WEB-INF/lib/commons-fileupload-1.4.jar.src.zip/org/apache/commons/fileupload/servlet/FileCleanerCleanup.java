/*    */ package org.apache.commons.fileupload.servlet;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.io.FileCleaningTracker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileCleanerCleanup
/*    */   implements ServletContextListener
/*    */ {
/* 36 */   public static final String FILE_CLEANING_TRACKER_ATTRIBUTE = FileCleanerCleanup.class
/* 37 */     .getName() + ".FileCleaningTracker";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static FileCleaningTracker getFileCleaningTracker(ServletContext pServletContext) {
/* 48 */     return (FileCleaningTracker)pServletContext
/* 49 */       .getAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setFileCleaningTracker(ServletContext pServletContext, FileCleaningTracker pTracker) {
/* 61 */     pServletContext.setAttribute(FILE_CLEANING_TRACKER_ATTRIBUTE, pTracker);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextInitialized(ServletContextEvent sce) {
/* 73 */     setFileCleaningTracker(sce.getServletContext(), new FileCleaningTracker());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 86 */     getFileCleaningTracker(sce.getServletContext()).exitWhenFinished();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\servlet\FileCleanerCleanup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */