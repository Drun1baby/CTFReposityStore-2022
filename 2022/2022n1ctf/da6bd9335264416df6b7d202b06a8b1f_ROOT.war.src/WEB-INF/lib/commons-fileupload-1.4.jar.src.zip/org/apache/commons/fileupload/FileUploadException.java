/*     */ package org.apache.commons.fileupload;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileUploadException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 8881893724388807504L;
/*     */   private final Throwable cause;
/*     */   
/*     */   public FileUploadException() {
/*  43 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileUploadException(String msg) {
/*  53 */     this(msg, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileUploadException(String msg, Throwable cause) {
/*  64 */     super(msg);
/*  65 */     this.cause = cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream stream) {
/*  75 */     super.printStackTrace(stream);
/*  76 */     if (this.cause != null) {
/*  77 */       stream.println("Caused by:");
/*  78 */       this.cause.printStackTrace(stream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter writer) {
/*  90 */     super.printStackTrace(writer);
/*  91 */     if (this.cause != null) {
/*  92 */       writer.println("Caused by:");
/*  93 */       this.cause.printStackTrace(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getCause() {
/* 102 */     return this.cause;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileUploadException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */