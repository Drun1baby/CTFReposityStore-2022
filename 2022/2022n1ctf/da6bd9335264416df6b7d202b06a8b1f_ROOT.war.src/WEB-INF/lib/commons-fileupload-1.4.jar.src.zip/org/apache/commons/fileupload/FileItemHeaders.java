package org.apache.commons.fileupload;

import java.util.Iterator;

public interface FileItemHeaders {
  String getHeader(String paramString);
  
  Iterator<String> getHeaders(String paramString);
  
  Iterator<String> getHeaderNames();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileItemHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */