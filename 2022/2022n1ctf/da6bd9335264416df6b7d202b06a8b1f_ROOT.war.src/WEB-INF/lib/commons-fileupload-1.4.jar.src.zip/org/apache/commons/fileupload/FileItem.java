package org.apache.commons.fileupload;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

public interface FileItem extends FileItemHeadersSupport {
  InputStream getInputStream() throws IOException;
  
  String getContentType();
  
  String getName();
  
  boolean isInMemory();
  
  long getSize();
  
  byte[] get();
  
  String getString(String paramString) throws UnsupportedEncodingException;
  
  String getString();
  
  void write(File paramFile) throws Exception;
  
  void delete();
  
  String getFieldName();
  
  void setFieldName(String paramString);
  
  boolean isFormField();
  
  void setFormField(boolean paramBoolean);
  
  OutputStream getOutputStream() throws IOException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */