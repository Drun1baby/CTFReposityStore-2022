/*    */ package org.apache.commons.fileupload.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.fileupload.FileItemHeaders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileItemHeadersImpl
/*    */   implements FileItemHeaders, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4455695752627032559L;
/* 46 */   private final Map<String, List<String>> headerNameToValueListMap = new LinkedHashMap<String, List<String>>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHeader(String name) {
/* 53 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 54 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 55 */     if (null == headerValueList) {
/* 56 */       return null;
/*    */     }
/* 58 */     return headerValueList.get(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<String> getHeaderNames() {
/* 66 */     return this.headerNameToValueListMap.keySet().iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<String> getHeaders(String name) {
/* 74 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 75 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 76 */     if (null == headerValueList) {
/* 77 */       headerValueList = Collections.emptyList();
/*    */     }
/* 79 */     return headerValueList.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void addHeader(String name, String value) {
/* 89 */     String nameLower = name.toLowerCase(Locale.ENGLISH);
/* 90 */     List<String> headerValueList = this.headerNameToValueListMap.get(nameLower);
/* 91 */     if (null == headerValueList) {
/* 92 */       headerValueList = new ArrayList<String>();
/* 93 */       this.headerNameToValueListMap.put(nameLower, headerValueList);
/*    */     } 
/* 95 */     headerValueList.add(value);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileuploa\\util\FileItemHeadersImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */