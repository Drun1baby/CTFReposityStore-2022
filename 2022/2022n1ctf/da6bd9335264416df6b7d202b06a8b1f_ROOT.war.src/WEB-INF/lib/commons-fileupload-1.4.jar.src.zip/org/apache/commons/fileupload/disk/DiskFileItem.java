/*     */ package org.apache.commons.fileupload.disk;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileItemHeaders;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.ParameterParser;
/*     */ import org.apache.commons.fileupload.util.Streams;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.io.output.DeferredFileOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiskFileItem
/*     */   implements FileItem
/*     */ {
/*     */   public static final String DEFAULT_CHARSET = "ISO-8859-1";
/*  90 */   private static final String UID = UUID.randomUUID().toString().replace('-', '_');
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final AtomicInteger COUNTER = new AtomicInteger(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fieldName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String contentType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFormField;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String fileName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private long size = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int sizeThreshold;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final File repository;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] cachedContent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient DeferredFileOutputStream dfos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient File tempFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FileItemHeaders headers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   private String defaultCharset = "ISO-8859-1";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiskFileItem(String fieldName, String contentType, boolean isFormField, String fileName, int sizeThreshold, File repository) {
/* 183 */     this.fieldName = fieldName;
/* 184 */     this.contentType = contentType;
/* 185 */     this.isFormField = isFormField;
/* 186 */     this.fileName = fileName;
/* 187 */     this.sizeThreshold = sizeThreshold;
/* 188 */     this.repository = repository;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 205 */     if (!isInMemory()) {
/* 206 */       return new FileInputStream(this.dfos.getFile());
/*     */     }
/*     */     
/* 209 */     if (this.cachedContent == null) {
/* 210 */       this.cachedContent = this.dfos.getData();
/*     */     }
/* 212 */     return new ByteArrayInputStream(this.cachedContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 224 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharSet() {
/* 235 */     ParameterParser parser = new ParameterParser();
/* 236 */     parser.setLowerCaseNames(true);
/*     */     
/* 238 */     Map<String, String> params = parser.parse(getContentType(), ';');
/* 239 */     return params.get("charset");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 253 */     return Streams.checkFileName(this.fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInMemory() {
/* 267 */     if (this.cachedContent != null) {
/* 268 */       return true;
/*     */     }
/* 270 */     return this.dfos.isInMemory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 280 */     if (this.size >= 0L)
/* 281 */       return this.size; 
/* 282 */     if (this.cachedContent != null)
/* 283 */       return this.cachedContent.length; 
/* 284 */     if (this.dfos.isInMemory()) {
/* 285 */       return (this.dfos.getData()).length;
/*     */     }
/* 287 */     return this.dfos.getFile().length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] get() {
/* 301 */     if (isInMemory()) {
/* 302 */       if (this.cachedContent == null && this.dfos != null) {
/* 303 */         this.cachedContent = this.dfos.getData();
/*     */       }
/* 305 */       return this.cachedContent;
/*     */     } 
/*     */     
/* 308 */     byte[] fileData = new byte[(int)getSize()];
/* 309 */     InputStream fis = null;
/*     */     
/*     */     try {
/* 312 */       fis = new FileInputStream(this.dfos.getFile());
/* 313 */       IOUtils.readFully(fis, fileData);
/* 314 */     } catch (IOException e) {
/* 315 */       fileData = null;
/*     */     } finally {
/* 317 */       IOUtils.closeQuietly(fis);
/*     */     } 
/*     */     
/* 320 */     return fileData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String charset) throws UnsupportedEncodingException {
/* 338 */     return new String(get(), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() {
/* 352 */     byte[] rawdata = get();
/* 353 */     String charset = getCharSet();
/* 354 */     if (charset == null) {
/* 355 */       charset = this.defaultCharset;
/*     */     }
/*     */     try {
/* 358 */       return new String(rawdata, charset);
/* 359 */     } catch (UnsupportedEncodingException e) {
/* 360 */       return new String(rawdata);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File file) throws Exception {
/* 386 */     if (isInMemory()) {
/* 387 */       FileOutputStream fout = null;
/*     */       try {
/* 389 */         fout = new FileOutputStream(file);
/* 390 */         fout.write(get());
/* 391 */         fout.close();
/*     */       } finally {
/* 393 */         IOUtils.closeQuietly(fout);
/*     */       } 
/*     */     } else {
/* 396 */       File outputFile = getStoreLocation();
/* 397 */       if (outputFile != null) {
/*     */         
/* 399 */         this.size = outputFile.length();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 405 */         FileUtils.moveFile(outputFile, file);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 411 */         throw new FileUploadException("Cannot write uploaded file to disk!");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/* 426 */     this.cachedContent = null;
/* 427 */     File outputFile = getStoreLocation();
/* 428 */     if (outputFile != null && !isInMemory() && outputFile.exists()) {
/* 429 */       outputFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldName() {
/* 444 */     return this.fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldName(String fieldName) {
/* 457 */     this.fieldName = fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFormField() {
/* 472 */     return this.isFormField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormField(boolean state) {
/* 487 */     this.isFormField = state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 502 */     if (this.dfos == null) {
/* 503 */       File outputFile = getTempFile();
/* 504 */       this.dfos = new DeferredFileOutputStream(this.sizeThreshold, outputFile);
/*     */     } 
/* 506 */     return (OutputStream)this.dfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getStoreLocation() {
/* 525 */     if (this.dfos == null) {
/* 526 */       return null;
/*     */     }
/* 528 */     if (isInMemory()) {
/* 529 */       return null;
/*     */     }
/* 531 */     return this.dfos.getFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 541 */     if (this.dfos == null || this.dfos.isInMemory()) {
/*     */       return;
/*     */     }
/* 544 */     File outputFile = this.dfos.getFile();
/*     */     
/* 546 */     if (outputFile != null && outputFile.exists()) {
/* 547 */       outputFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getTempFile() {
/* 563 */     if (this.tempFile == null) {
/* 564 */       File tempDir = this.repository;
/* 565 */       if (tempDir == null) {
/* 566 */         tempDir = new File(System.getProperty("java.io.tmpdir"));
/*     */       }
/*     */       
/* 569 */       String tempFileName = String.format("upload_%s_%s.tmp", new Object[] { UID, getUniqueId() });
/*     */       
/* 571 */       this.tempFile = new File(tempDir, tempFileName);
/*     */     } 
/* 573 */     return this.tempFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getUniqueId() {
/* 585 */     int limit = 100000000;
/* 586 */     int current = COUNTER.getAndIncrement();
/* 587 */     String id = Integer.toString(current);
/*     */ 
/*     */ 
/*     */     
/* 591 */     if (current < 100000000) {
/* 592 */       id = ("00000000" + id).substring(id.length());
/*     */     }
/* 594 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 604 */     return String.format("name=%s, StoreLocation=%s, size=%s bytes, isFormField=%s, FieldName=%s", new Object[] {
/* 605 */           getName(), getStoreLocation(), Long.valueOf(getSize()), 
/* 606 */           Boolean.valueOf(isFormField()), getFieldName()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileItemHeaders getHeaders() {
/* 615 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaders(FileItemHeaders pHeaders) {
/* 624 */     this.headers = pHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 633 */     return this.defaultCharset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(String charset) {
/* 642 */     this.defaultCharset = charset;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\disk\DiskFileItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */