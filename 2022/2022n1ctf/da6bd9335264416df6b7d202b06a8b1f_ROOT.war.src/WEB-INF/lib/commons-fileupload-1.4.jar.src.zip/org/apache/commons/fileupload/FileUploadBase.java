/*      */ package org.apache.commons.fileupload;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*      */ import org.apache.commons.fileupload.servlet.ServletRequestContext;
/*      */ import org.apache.commons.fileupload.util.Closeable;
/*      */ import org.apache.commons.fileupload.util.FileItemHeadersImpl;
/*      */ import org.apache.commons.fileupload.util.LimitedInputStream;
/*      */ import org.apache.commons.fileupload.util.Streams;
/*      */ import org.apache.commons.io.IOUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class FileUploadBase
/*      */ {
/*      */   public static final String CONTENT_TYPE = "Content-type";
/*      */   public static final String CONTENT_DISPOSITION = "Content-disposition";
/*      */   public static final String CONTENT_LENGTH = "Content-length";
/*      */   public static final String FORM_DATA = "form-data";
/*      */   public static final String ATTACHMENT = "attachment";
/*      */   public static final String MULTIPART = "multipart/";
/*      */   public static final String MULTIPART_FORM_DATA = "multipart/form-data";
/*      */   public static final String MULTIPART_MIXED = "multipart/mixed";
/*      */   @Deprecated
/*      */   public static final int MAX_HEADER_SIZE = 1024;
/*      */   
/*      */   public static final boolean isMultipartContent(RequestContext ctx) {
/*   76 */     String contentType = ctx.getContentType();
/*   77 */     if (contentType == null) {
/*   78 */       return false;
/*      */     }
/*   80 */     if (contentType.toLowerCase(Locale.ENGLISH).startsWith("multipart/")) {
/*   81 */       return true;
/*      */     }
/*   83 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean isMultipartContent(HttpServletRequest req) {
/*   99 */     return ServletFileUpload.isMultipartContent(req);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private long sizeMax = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private long fileSizeMax = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String headerEncoding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ProgressListener listener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getSizeMax() {
/*  205 */     return this.sizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSizeMax(long sizeMax) {
/*  219 */     this.sizeMax = sizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getFileSizeMax() {
/*  230 */     return this.fileSizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFileSizeMax(long fileSizeMax) {
/*  241 */     this.fileSizeMax = fileSizeMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHeaderEncoding() {
/*  253 */     return this.headerEncoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeaderEncoding(String encoding) {
/*  265 */     this.headerEncoding = encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<FileItem> parseRequest(HttpServletRequest req) throws FileUploadException {
/*  287 */     return parseRequest((RequestContext)new ServletRequestContext(req));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FileItemIterator getItemIterator(RequestContext ctx) throws FileUploadException, IOException {
/*      */     try {
/*  309 */       return new FileItemIteratorImpl(ctx);
/*  310 */     } catch (FileUploadIOException e) {
/*      */       
/*  312 */       throw (FileUploadException)e.getCause();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<FileItem> parseRequest(RequestContext ctx) throws FileUploadException {
/*  330 */     List<FileItem> items = new ArrayList<FileItem>();
/*  331 */     boolean successful = false;
/*      */     try {
/*  333 */       FileItemIterator iter = getItemIterator(ctx);
/*  334 */       FileItemFactory fac = getFileItemFactory();
/*  335 */       if (fac == null) {
/*  336 */         throw new NullPointerException("No FileItemFactory has been set.");
/*      */       }
/*  338 */       while (iter.hasNext()) {
/*  339 */         FileItemStream item = iter.next();
/*      */         
/*  341 */         String fileName = ((FileItemIteratorImpl.FileItemStreamImpl)item).name;
/*  342 */         FileItem fileItem = fac.createItem(item.getFieldName(), item.getContentType(), item
/*  343 */             .isFormField(), fileName);
/*  344 */         items.add(fileItem);
/*      */         try {
/*  346 */           Streams.copy(item.openStream(), fileItem.getOutputStream(), true);
/*  347 */         } catch (FileUploadIOException e) {
/*  348 */           throw (FileUploadException)e.getCause();
/*  349 */         } catch (IOException e) {
/*  350 */           throw new IOFileUploadException(String.format("Processing of %s request failed. %s", new Object[] { "multipart/form-data", e
/*  351 */                   .getMessage() }), e);
/*      */         } 
/*  353 */         FileItemHeaders fih = item.getHeaders();
/*  354 */         fileItem.setHeaders(fih);
/*      */       } 
/*  356 */       successful = true;
/*  357 */       return items;
/*  358 */     } catch (FileUploadIOException e) {
/*  359 */       throw (FileUploadException)e.getCause();
/*  360 */     } catch (IOException e) {
/*  361 */       throw new FileUploadException(e.getMessage(), e);
/*      */     } finally {
/*  363 */       if (!successful) {
/*  364 */         for (FileItem fileItem : items) {
/*      */           try {
/*  366 */             fileItem.delete();
/*  367 */           } catch (Exception exception) {}
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, List<FileItem>> parseParameterMap(RequestContext ctx) throws FileUploadException {
/*  390 */     List<FileItem> items = parseRequest(ctx);
/*  391 */     Map<String, List<FileItem>> itemsMap = new HashMap<String, List<FileItem>>(items.size());
/*      */     
/*  393 */     for (FileItem fileItem : items) {
/*  394 */       String fieldName = fileItem.getFieldName();
/*  395 */       List<FileItem> mappedItems = itemsMap.get(fieldName);
/*      */       
/*  397 */       if (mappedItems == null) {
/*  398 */         mappedItems = new ArrayList<FileItem>();
/*  399 */         itemsMap.put(fieldName, mappedItems);
/*      */       } 
/*      */       
/*  402 */       mappedItems.add(fileItem);
/*      */     } 
/*      */     
/*  405 */     return itemsMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBoundary(String contentType) {
/*      */     byte[] boundary;
/*  419 */     ParameterParser parser = new ParameterParser();
/*  420 */     parser.setLowerCaseNames(true);
/*      */     
/*  422 */     Map<String, String> params = parser.parse(contentType, new char[] { ';', ',' });
/*  423 */     String boundaryStr = params.get("boundary");
/*      */     
/*  425 */     if (boundaryStr == null) {
/*  426 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  430 */       boundary = boundaryStr.getBytes("ISO-8859-1");
/*  431 */     } catch (UnsupportedEncodingException e) {
/*  432 */       boundary = boundaryStr.getBytes();
/*      */     } 
/*  434 */     return boundary;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getFileName(Map<String, String> headers) {
/*  448 */     return getFileName(getHeader(headers, "Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFileName(FileItemHeaders headers) {
/*  460 */     return getFileName(headers.getHeader("Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFileName(String pContentDisposition) {
/*  469 */     String fileName = null;
/*  470 */     if (pContentDisposition != null) {
/*  471 */       String cdl = pContentDisposition.toLowerCase(Locale.ENGLISH);
/*  472 */       if (cdl.startsWith("form-data") || cdl.startsWith("attachment")) {
/*  473 */         ParameterParser parser = new ParameterParser();
/*  474 */         parser.setLowerCaseNames(true);
/*      */         
/*  476 */         Map<String, String> params = parser.parse(pContentDisposition, ';');
/*  477 */         if (params.containsKey("filename")) {
/*  478 */           fileName = params.get("filename");
/*  479 */           if (fileName != null) {
/*  480 */             fileName = fileName.trim();
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  485 */             fileName = "";
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  490 */     return fileName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFieldName(FileItemHeaders headers) {
/*  502 */     return getFieldName(headers.getHeader("Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFieldName(String pContentDisposition) {
/*  512 */     String fieldName = null;
/*  513 */     if (pContentDisposition != null && pContentDisposition
/*  514 */       .toLowerCase(Locale.ENGLISH).startsWith("form-data")) {
/*  515 */       ParameterParser parser = new ParameterParser();
/*  516 */       parser.setLowerCaseNames(true);
/*      */       
/*  518 */       Map<String, String> params = parser.parse(pContentDisposition, ';');
/*  519 */       fieldName = params.get("name");
/*  520 */       if (fieldName != null) {
/*  521 */         fieldName = fieldName.trim();
/*      */       }
/*      */     } 
/*  524 */     return fieldName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected String getFieldName(Map<String, String> headers) {
/*  538 */     return getFieldName(getHeader(headers, "Content-disposition"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected FileItem createItem(Map<String, String> headers, boolean isFormField) throws FileUploadException {
/*  559 */     return getFileItemFactory().createItem(getFieldName(headers), 
/*  560 */         getHeader(headers, "Content-type"), isFormField, 
/*      */         
/*  562 */         getFileName(headers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FileItemHeaders getParsedHeaders(String headerPart) {
/*  578 */     int len = headerPart.length();
/*  579 */     FileItemHeadersImpl headers = newFileItemHeaders();
/*  580 */     int start = 0;
/*      */     while (true) {
/*  582 */       int end = parseEndOfLine(headerPart, start);
/*  583 */       if (start == end) {
/*      */         break;
/*      */       }
/*  586 */       StringBuilder header = new StringBuilder(headerPart.substring(start, end));
/*  587 */       start = end + 2;
/*  588 */       while (start < len) {
/*  589 */         int nonWs = start;
/*  590 */         while (nonWs < len) {
/*  591 */           char c = headerPart.charAt(nonWs);
/*  592 */           if (c != ' ' && c != '\t') {
/*      */             break;
/*      */           }
/*  595 */           nonWs++;
/*      */         } 
/*  597 */         if (nonWs == start) {
/*      */           break;
/*      */         }
/*      */         
/*  601 */         end = parseEndOfLine(headerPart, nonWs);
/*  602 */         header.append(" ").append(headerPart.substring(nonWs, end));
/*  603 */         start = end + 2;
/*      */       } 
/*  605 */       parseHeaderLine(headers, header.toString());
/*      */     } 
/*  607 */     return (FileItemHeaders)headers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FileItemHeadersImpl newFileItemHeaders() {
/*  615 */     return new FileItemHeadersImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Map<String, String> parseHeaders(String headerPart) {
/*  633 */     FileItemHeaders headers = getParsedHeaders(headerPart);
/*  634 */     Map<String, String> result = new HashMap<String, String>();
/*  635 */     for (Iterator<String> iter = headers.getHeaderNames(); iter.hasNext(); ) {
/*  636 */       String headerName = iter.next();
/*  637 */       Iterator<String> iter2 = headers.getHeaders(headerName);
/*  638 */       StringBuilder headerValue = new StringBuilder(iter2.next());
/*  639 */       while (iter2.hasNext()) {
/*  640 */         headerValue.append(",").append(iter2.next());
/*      */       }
/*  642 */       result.put(headerName, headerValue.toString());
/*      */     } 
/*  644 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int parseEndOfLine(String headerPart, int end) {
/*  656 */     int index = end;
/*      */     while (true) {
/*  658 */       int offset = headerPart.indexOf('\r', index);
/*  659 */       if (offset == -1 || offset + 1 >= headerPart.length()) {
/*  660 */         throw new IllegalStateException("Expected headers to be terminated by an empty line.");
/*      */       }
/*      */       
/*  663 */       if (headerPart.charAt(offset + 1) == '\n') {
/*  664 */         return offset;
/*      */       }
/*  666 */       index = offset + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void parseHeaderLine(FileItemHeadersImpl headers, String header) {
/*  676 */     int colonOffset = header.indexOf(':');
/*  677 */     if (colonOffset == -1) {
/*      */       return;
/*      */     }
/*      */     
/*  681 */     String headerName = header.substring(0, colonOffset).trim();
/*      */     
/*  683 */     String headerValue = header.substring(header.indexOf(':') + 1).trim();
/*  684 */     headers.addHeader(headerName, headerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final String getHeader(Map<String, String> headers, String name) {
/*  701 */     return headers.get(name.toLowerCase(Locale.ENGLISH));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class FileItemStreamImpl
/*      */     implements FileItemStream
/*      */   {
/*      */     private final String contentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String fieldName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean formField;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final InputStream stream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean opened;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private FileItemHeaders headers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FileItemStreamImpl(String pName, String pFieldName, String pContentType, boolean pFormField, long pContentLength) throws IOException {
/*      */       LimitedInputStream limitedInputStream;
/*  763 */       this.name = pName;
/*  764 */       this.fieldName = pFieldName;
/*  765 */       this.contentType = pContentType;
/*  766 */       this.formField = pFormField;
/*  767 */       if (FileUploadBase.this.fileSizeMax != -1L && 
/*  768 */         pContentLength != -1L && pContentLength > FileUploadBase.this
/*  769 */         .fileSizeMax) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  774 */         FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { this.fieldName, Long.valueOf(FileUploadBase.access$100(this$1.this$0)) }), pContentLength, FileUploadBase.this.fileSizeMax);
/*  775 */         e.setFileName(pName);
/*  776 */         e.setFieldName(pFieldName);
/*  777 */         throw new FileUploadBase.FileUploadIOException(e);
/*      */       } 
/*      */ 
/*      */       
/*  781 */       final MultipartStream.ItemInputStream itemStream = FileUploadBase.FileItemIteratorImpl.this.multi.newInputStream();
/*  782 */       InputStream istream = itemStream;
/*  783 */       if (FileUploadBase.this.fileSizeMax != -1L) {
/*  784 */         limitedInputStream = new LimitedInputStream(istream, FileUploadBase.this.fileSizeMax)
/*      */           {
/*      */             protected void raiseError(long pSizeMax, long pCount) throws IOException
/*      */             {
/*  788 */               itemStream.close(true);
/*      */ 
/*      */               
/*  791 */               FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] {
/*  792 */                       FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.access$300(this.this$2), Long.valueOf(pSizeMax)
/*      */                     }), pCount, pSizeMax);
/*  794 */               e.setFieldName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.fieldName);
/*  795 */               e.setFileName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.name);
/*  796 */               throw new FileUploadBase.FileUploadIOException(e);
/*      */             }
/*      */           };
/*      */       }
/*  800 */       this.stream = (InputStream)limitedInputStream;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getContentType() {
/*  810 */       return this.contentType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFieldName() {
/*  820 */       return this.fieldName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/*  834 */       return Streams.checkFileName(this.name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isFormField() {
/*  845 */       return this.formField;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InputStream openStream() throws IOException {
/*  857 */       if (this.opened) {
/*  858 */         throw new IllegalStateException("The stream was already opened.");
/*      */       }
/*      */       
/*  861 */       if (((Closeable)this.stream).isClosed()) {
/*  862 */         throw new FileItemStream.ItemSkippedException();
/*      */       }
/*  864 */       return this.stream;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void close() throws IOException {
/*  873 */       this.stream.close();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileItemHeaders getHeaders() {
/*  883 */       return this.headers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setHeaders(FileItemHeaders pHeaders)
/*      */     {
/*  893 */       this.headers = pHeaders; } } private class FileItemIteratorImpl implements FileItemIterator { private final MultipartStream multi; private final MultipartStream.ProgressNotifier notifier; private final byte[] boundary; private FileItemStreamImpl currentItem; private String currentFieldName; private boolean skipPreamble; private boolean itemValid; private boolean eof; class FileItemStreamImpl implements FileItemStream { private final String contentType; private final String fieldName; private final String name; public void setHeaders(FileItemHeaders pHeaders) { this.headers = pHeaders; }
/*      */       
/*      */       private final boolean formField; private final InputStream stream; private boolean opened; private FileItemHeaders headers;
/*      */       FileItemStreamImpl(String pName, String pFieldName, String pContentType, boolean pFormField, long pContentLength) throws IOException {
/*      */         LimitedInputStream limitedInputStream;
/*      */         this.name = pName;
/*      */         this.fieldName = pFieldName;
/*      */         this.contentType = pContentType;
/*      */         this.formField = pFormField;
/*      */         if (FileUploadBase.this.fileSizeMax != -1L && pContentLength != -1L && pContentLength > FileUploadBase.this.fileSizeMax) {
/*      */           FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { this.fieldName, Long.valueOf(FileUploadBase.access$100(this$1.this$0)) }), pContentLength, FileUploadBase.this.fileSizeMax);
/*      */           e.setFileName(pName);
/*      */           e.setFieldName(pFieldName);
/*      */           throw new FileUploadBase.FileUploadIOException(e);
/*      */         } 
/*      */         final MultipartStream.ItemInputStream itemStream = FileUploadBase.FileItemIteratorImpl.this.multi.newInputStream();
/*      */         InputStream istream = itemStream;
/*      */         if (FileUploadBase.this.fileSizeMax != -1L)
/*      */           limitedInputStream = new LimitedInputStream(istream, FileUploadBase.this.fileSizeMax) { protected void raiseError(long pSizeMax, long pCount) throws IOException {
/*      */                 itemStream.close(true);
/*      */                 FileUploadBase.FileSizeLimitExceededException e = new FileUploadBase.FileSizeLimitExceededException(String.format("The field %s exceeds its maximum permitted size of %s bytes.", new Object[] { FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.access$300(this.this$2), Long.valueOf(pSizeMax) }), pCount, pSizeMax);
/*      */                 e.setFieldName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.fieldName);
/*      */                 e.setFileName(FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl.this.name);
/*      */                 throw new FileUploadBase.FileUploadIOException(e);
/*      */               } }
/*      */             ; 
/*      */         this.stream = (InputStream)limitedInputStream;
/*      */       }
/*      */       public String getContentType() {
/*      */         return this.contentType;
/*      */       }
/*      */       public String getFieldName() {
/*      */         return this.fieldName;
/*      */       }
/*      */       public String getName() {
/*      */         return Streams.checkFileName(this.name);
/*      */       }
/*      */       public boolean isFormField() {
/*      */         return this.formField;
/*      */       }
/*      */       public InputStream openStream() throws IOException {
/*      */         if (this.opened)
/*      */           throw new IllegalStateException("The stream was already opened."); 
/*      */         if (((Closeable)this.stream).isClosed())
/*      */           throw new FileItemStream.ItemSkippedException(); 
/*      */         return this.stream;
/*      */       }
/*      */       void close() throws IOException {
/*      */         this.stream.close();
/*      */       }
/*      */       public FileItemHeaders getHeaders() {
/*      */         return this.headers;
/*      */       } }
/*      */     
/*      */     FileItemIteratorImpl(RequestContext ctx) throws FileUploadException, IOException {
/*      */       InputStream input;
/*  949 */       if (ctx == null) {
/*  950 */         throw new NullPointerException("ctx parameter");
/*      */       }
/*      */       
/*  953 */       String contentType = ctx.getContentType();
/*  954 */       if (null == contentType || 
/*  955 */         !contentType.toLowerCase(Locale.ENGLISH).startsWith("multipart/")) {
/*  956 */         throw new FileUploadBase.InvalidContentTypeException(
/*  957 */             String.format("the request doesn't contain a %s or %s stream, content type header is %s", new Object[] { "multipart/form-data", "multipart/mixed", contentType }));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  963 */       int contentLengthInt = ctx.getContentLength();
/*      */ 
/*      */ 
/*      */       
/*  967 */       long requestSize = UploadContext.class.isAssignableFrom(ctx.getClass()) ? ((UploadContext)ctx).contentLength() : contentLengthInt;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  972 */       if (FileUploadBase.this.sizeMax >= 0L) {
/*  973 */         if (requestSize != -1L && requestSize > FileUploadBase.this.sizeMax) {
/*  974 */           throw new FileUploadBase.SizeLimitExceededException(
/*  975 */               String.format("the request was rejected because its size (%s) exceeds the configured maximum (%s)", new Object[] {
/*  976 */                   Long.valueOf(requestSize), Long.valueOf(FileUploadBase.access$400(this$0))
/*  977 */                 }), requestSize, FileUploadBase.this.sizeMax);
/*      */         }
/*      */         
/*  980 */         LimitedInputStream limitedInputStream = new LimitedInputStream(ctx.getInputStream(), FileUploadBase.this.sizeMax)
/*      */           {
/*      */             
/*      */             protected void raiseError(long pSizeMax, long pCount) throws IOException
/*      */             {
/*  985 */               FileUploadException ex = new FileUploadBase.SizeLimitExceededException(String.format("the request was rejected because its size (%s) exceeds the configured maximum (%s)", new Object[] {
/*  986 */                       Long.valueOf(pCount), Long.valueOf(pSizeMax)
/*      */                     }), pCount, pSizeMax);
/*  988 */               throw new FileUploadBase.FileUploadIOException(ex);
/*      */             }
/*      */           };
/*      */       } else {
/*  992 */         input = ctx.getInputStream();
/*      */       } 
/*      */       
/*  995 */       String charEncoding = FileUploadBase.this.headerEncoding;
/*  996 */       if (charEncoding == null) {
/*  997 */         charEncoding = ctx.getCharacterEncoding();
/*      */       }
/*      */       
/* 1000 */       this.boundary = FileUploadBase.this.getBoundary(contentType);
/* 1001 */       if (this.boundary == null) {
/* 1002 */         IOUtils.closeQuietly(input);
/* 1003 */         throw new FileUploadException("the request was rejected because no multipart boundary was found");
/*      */       } 
/*      */       
/* 1006 */       this.notifier = new MultipartStream.ProgressNotifier(FileUploadBase.this.listener, requestSize);
/*      */       try {
/* 1008 */         this.multi = new MultipartStream(input, this.boundary, this.notifier);
/* 1009 */       } catch (IllegalArgumentException iae) {
/* 1010 */         IOUtils.closeQuietly(input);
/* 1011 */         throw new FileUploadBase.InvalidContentTypeException(
/* 1012 */             String.format("The boundary specified in the %s header is too long", new Object[] { "Content-type" }), iae);
/*      */       } 
/* 1014 */       this.multi.setHeaderEncoding(charEncoding);
/*      */       
/* 1016 */       this.skipPreamble = true;
/* 1017 */       findNextItem();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean findNextItem() throws IOException {
/* 1027 */       if (this.eof) {
/* 1028 */         return false;
/*      */       }
/* 1030 */       if (this.currentItem != null) {
/* 1031 */         this.currentItem.close();
/* 1032 */         this.currentItem = null;
/*      */       } 
/*      */       while (true) {
/*      */         boolean nextPart;
/* 1036 */         if (this.skipPreamble) {
/* 1037 */           nextPart = this.multi.skipPreamble();
/*      */         } else {
/* 1039 */           nextPart = this.multi.readBoundary();
/*      */         } 
/* 1041 */         if (!nextPart) {
/* 1042 */           if (this.currentFieldName == null) {
/*      */             
/* 1044 */             this.eof = true;
/* 1045 */             return false;
/*      */           } 
/*      */           
/* 1048 */           this.multi.setBoundary(this.boundary);
/* 1049 */           this.currentFieldName = null;
/*      */           continue;
/*      */         } 
/* 1052 */         FileItemHeaders headers = FileUploadBase.this.getParsedHeaders(this.multi.readHeaders());
/* 1053 */         if (this.currentFieldName == null) {
/*      */           
/* 1055 */           String fieldName = FileUploadBase.this.getFieldName(headers);
/* 1056 */           if (fieldName != null) {
/* 1057 */             String subContentType = headers.getHeader("Content-type");
/* 1058 */             if (subContentType != null && subContentType
/* 1059 */               .toLowerCase(Locale.ENGLISH)
/* 1060 */               .startsWith("multipart/mixed")) {
/* 1061 */               this.currentFieldName = fieldName;
/*      */               
/* 1063 */               byte[] subBoundary = FileUploadBase.this.getBoundary(subContentType);
/* 1064 */               this.multi.setBoundary(subBoundary);
/* 1065 */               this.skipPreamble = true;
/*      */               continue;
/*      */             } 
/* 1068 */             String fileName = FileUploadBase.this.getFileName(headers);
/* 1069 */             this
/*      */               
/* 1071 */               .currentItem = new FileItemStreamImpl(fileName, fieldName, headers.getHeader("Content-type"), (fileName == null), getContentLength(headers));
/* 1072 */             this.currentItem.setHeaders(headers);
/* 1073 */             this.notifier.noteItem();
/* 1074 */             this.itemValid = true;
/* 1075 */             return true;
/*      */           } 
/*      */         } else {
/* 1078 */           String fileName = FileUploadBase.this.getFileName(headers);
/* 1079 */           if (fileName != null) {
/* 1080 */             this
/*      */ 
/*      */               
/* 1083 */               .currentItem = new FileItemStreamImpl(fileName, this.currentFieldName, headers.getHeader("Content-type"), false, getContentLength(headers));
/* 1084 */             this.currentItem.setHeaders(headers);
/* 1085 */             this.notifier.noteItem();
/* 1086 */             this.itemValid = true;
/* 1087 */             return true;
/*      */           } 
/*      */         } 
/* 1090 */         this.multi.discardBodyData();
/*      */       } 
/*      */     }
/*      */     
/*      */     private long getContentLength(FileItemHeaders pHeaders) {
/*      */       try {
/* 1096 */         return Long.parseLong(pHeaders.getHeader("Content-length"));
/* 1097 */       } catch (Exception e) {
/* 1098 */         return -1L;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() throws FileUploadException, IOException {
/* 1114 */       if (this.eof) {
/* 1115 */         return false;
/*      */       }
/* 1117 */       if (this.itemValid) {
/* 1118 */         return true;
/*      */       }
/*      */       try {
/* 1121 */         return findNextItem();
/* 1122 */       } catch (FileUploadIOException e) {
/*      */         
/* 1124 */         throw (FileUploadException)e.getCause();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileItemStream next() throws FileUploadException, IOException {
/* 1141 */       if (this.eof || (!this.itemValid && !hasNext())) {
/* 1142 */         throw new NoSuchElementException();
/*      */       }
/* 1144 */       this.itemValid = false;
/* 1145 */       return this.currentItem;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FileUploadIOException
/*      */     extends IOException
/*      */   {
/*      */     private static final long serialVersionUID = -7047616958165584154L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final FileUploadException cause;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileUploadIOException(FileUploadException pCause) {
/* 1176 */       this.cause = pCause;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable getCause() {
/* 1186 */       return this.cause;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InvalidContentTypeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = -9073026332015646668L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException(String message) {
/* 1217 */       super(message);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InvalidContentTypeException(String msg, Throwable cause) {
/* 1230 */       super(msg, cause);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IOFileUploadException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = 1749796615868477269L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final IOException cause;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IOFileUploadException(String pMsg, IOException pException) {
/* 1258 */       super(pMsg);
/* 1259 */       this.cause = pException;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Throwable getCause() {
/* 1269 */       return this.cause;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static abstract class SizeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = -8776225574705254126L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long actual;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long permitted;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected SizeException(String message, long actual, long permitted) {
/* 1303 */       super(message);
/* 1304 */       this.actual = actual;
/* 1305 */       this.permitted = permitted;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getActualSize() {
/* 1315 */       return this.actual;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long getPermittedSize() {
/* 1325 */       return this.permitted;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static class UnknownSizeException
/*      */     extends FileUploadException
/*      */   {
/*      */     private static final long serialVersionUID = 7062279004812015273L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UnknownSizeException() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UnknownSizeException(String message) {
/* 1362 */       super(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SizeLimitExceededException
/*      */     extends SizeException
/*      */   {
/*      */     private static final long serialVersionUID = -2474893167098052828L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public SizeLimitExceededException() {
/* 1384 */       this(null, 0L, 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public SizeLimitExceededException(String message) {
/* 1394 */       this(message, 0L, 0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SizeLimitExceededException(String message, long actual, long permitted) {
/* 1407 */       super(message, actual, permitted);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FileSizeLimitExceededException
/*      */     extends SizeException
/*      */   {
/*      */     private static final long serialVersionUID = 8150776562029630058L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String fileName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String fieldName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FileSizeLimitExceededException(String message, long actual, long permitted) {
/* 1443 */       super(message, actual, permitted);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFileName() {
/* 1453 */       return this.fileName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setFileName(String pFileName) {
/* 1463 */       this.fileName = pFileName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getFieldName() {
/* 1473 */       return this.fieldName;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setFieldName(String pFieldName) {
/* 1484 */       this.fieldName = pFieldName;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProgressListener getProgressListener() {
/* 1495 */     return this.listener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProgressListener(ProgressListener pListener) {
/* 1504 */     this.listener = pListener;
/*      */   }
/*      */   
/*      */   public abstract FileItemFactory getFileItemFactory();
/*      */   
/*      */   public abstract void setFileItemFactory(FileItemFactory paramFileItemFactory);
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileUploadBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */