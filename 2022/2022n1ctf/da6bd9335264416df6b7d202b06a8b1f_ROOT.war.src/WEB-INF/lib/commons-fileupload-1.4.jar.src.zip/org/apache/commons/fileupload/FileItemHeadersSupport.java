package org.apache.commons.fileupload;

public interface FileItemHeadersSupport {
  FileItemHeaders getHeaders();
  
  void setHeaders(FileItemHeaders paramFileItemHeaders);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-fileupload-1.4.jar!\org\apache\commons\fileupload\FileItemHeadersSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */