/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.util.BiConsumer;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.ReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.TriConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultThreadContextMap
/*     */   implements ThreadContextMap, ReadOnlyStringMap
/*     */ {
/*     */   private static final long serialVersionUID = 8218007901108944053L;
/*     */   public static final String INHERITABLE_MAP = "isThreadContextMapInheritable";
/*     */   private final boolean useMap;
/*     */   private final ThreadLocal<Map<String, String>> localMap;
/*     */   private static boolean inheritableMap;
/*     */   
/*     */   static {
/*  49 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ThreadLocal<Map<String, String>> createThreadLocalMap(final boolean isMapEnabled) {
/*  55 */     if (inheritableMap) {
/*  56 */       return new InheritableThreadLocal<Map<String, String>>()
/*     */         {
/*     */           protected Map<String, String> childValue(Map<String, String> parentValue) {
/*  59 */             return (parentValue != null && isMapEnabled) ? 
/*  60 */               Collections.<String, String>unmodifiableMap(new HashMap<>(parentValue)) : null;
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */     
/*  66 */     return new ThreadLocal<>();
/*     */   }
/*     */   
/*     */   static void init() {
/*  70 */     inheritableMap = PropertiesUtil.getProperties().getBooleanProperty("isThreadContextMapInheritable");
/*     */   }
/*     */   
/*     */   public DefaultThreadContextMap() {
/*  74 */     this(true);
/*     */   }
/*     */   
/*     */   public DefaultThreadContextMap(boolean useMap) {
/*  78 */     this.useMap = useMap;
/*  79 */     this.localMap = createThreadLocalMap(useMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, String value) {
/*  84 */     if (!this.useMap) {
/*     */       return;
/*     */     }
/*  87 */     Map<String, String> map = this.localMap.get();
/*  88 */     map = (map == null) ? new HashMap<>(1) : new HashMap<>(map);
/*  89 */     map.put(key, value);
/*  90 */     this.localMap.set(Collections.unmodifiableMap(map));
/*     */   }
/*     */   
/*     */   public void putAll(Map<String, String> m) {
/*  94 */     if (!this.useMap) {
/*     */       return;
/*     */     }
/*  97 */     Map<String, String> map = this.localMap.get();
/*  98 */     map = (map == null) ? new HashMap<>(m.size()) : new HashMap<>(map);
/*  99 */     for (Map.Entry<String, String> e : m.entrySet()) {
/* 100 */       map.put(e.getKey(), e.getValue());
/*     */     }
/* 102 */     this.localMap.set(Collections.unmodifiableMap(map));
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String key) {
/* 107 */     Map<String, String> map = this.localMap.get();
/* 108 */     return (map == null) ? null : map.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 113 */     Map<String, String> map = this.localMap.get();
/* 114 */     if (map != null) {
/* 115 */       Map<String, String> copy = new HashMap<>(map);
/* 116 */       copy.remove(key);
/* 117 */       this.localMap.set(Collections.unmodifiableMap(copy));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeAll(Iterable<String> keys) {
/* 122 */     Map<String, String> map = this.localMap.get();
/* 123 */     if (map != null) {
/* 124 */       Map<String, String> copy = new HashMap<>(map);
/* 125 */       for (String key : keys) {
/* 126 */         copy.remove(key);
/*     */       }
/* 128 */       this.localMap.set(Collections.unmodifiableMap(copy));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 134 */     this.localMap.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toMap() {
/* 139 */     return getCopy();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 144 */     Map<String, String> map = this.localMap.get();
/* 145 */     return (map != null && map.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> void forEach(BiConsumer<String, ? super V> action) {
/* 150 */     Map<String, String> map = this.localMap.get();
/* 151 */     if (map == null) {
/*     */       return;
/*     */     }
/* 154 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*     */ 
/*     */ 
/*     */       
/* 158 */       V value = (V)entry.getValue();
/* 159 */       action.accept(entry.getKey(), value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <V, S> void forEach(TriConsumer<String, ? super V, S> action, S state) {
/* 165 */     Map<String, String> map = this.localMap.get();
/* 166 */     if (map == null) {
/*     */       return;
/*     */     }
/* 169 */     for (Map.Entry<String, String> entry : map.entrySet()) {
/*     */ 
/*     */ 
/*     */       
/* 173 */       V value = (V)entry.getValue();
/* 174 */       action.accept(entry.getKey(), value, state);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 181 */     Map<String, String> map = this.localMap.get();
/* 182 */     return (map == null) ? null : (V)map.get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopy() {
/* 187 */     Map<String, String> map = this.localMap.get();
/* 188 */     return (map == null) ? new HashMap<>() : new HashMap<>(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImmutableMapOrNull() {
/* 193 */     return this.localMap.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 198 */     Map<String, String> map = this.localMap.get();
/* 199 */     return (map == null || map.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 204 */     Map<String, String> map = this.localMap.get();
/* 205 */     return (map == null) ? 0 : map.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 210 */     Map<String, String> map = this.localMap.get();
/* 211 */     return (map == null) ? "{}" : map.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 216 */     int prime = 31;
/* 217 */     int result = 1;
/* 218 */     Map<String, String> map = this.localMap.get();
/* 219 */     result = 31 * result + ((map == null) ? 0 : map.hashCode());
/* 220 */     result = 31 * result + Boolean.valueOf(this.useMap).hashCode();
/* 221 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 226 */     if (this == obj) {
/* 227 */       return true;
/*     */     }
/* 229 */     if (obj == null) {
/* 230 */       return false;
/*     */     }
/* 232 */     if (obj instanceof DefaultThreadContextMap) {
/* 233 */       DefaultThreadContextMap defaultThreadContextMap = (DefaultThreadContextMap)obj;
/* 234 */       if (this.useMap != defaultThreadContextMap.useMap) {
/* 235 */         return false;
/*     */       }
/*     */     } 
/* 238 */     if (!(obj instanceof ThreadContextMap)) {
/* 239 */       return false;
/*     */     }
/* 241 */     ThreadContextMap other = (ThreadContextMap)obj;
/* 242 */     Map<String, String> map = this.localMap.get();
/* 243 */     Map<String, String> otherMap = other.getImmutableMapOrNull();
/* 244 */     if (map == null) {
/* 245 */       if (otherMap != null) {
/* 246 */         return false;
/*     */       }
/* 248 */     } else if (!map.equals(otherMap)) {
/* 249 */       return false;
/*     */     } 
/* 251 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\DefaultThreadContextMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */