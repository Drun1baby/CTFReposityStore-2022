/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParameterizedNoReferenceMessageFactory
/*     */   extends AbstractMessageFactory
/*     */ {
/*     */   private static final long serialVersionUID = 5027639245636870500L;
/*     */   
/*     */   static class StatusMessage
/*     */     implements Message
/*     */   {
/*     */     private static final long serialVersionUID = 4199272162767841280L;
/*     */     private final String formattedMessage;
/*     */     private final Throwable throwable;
/*     */     
/*     */     public StatusMessage(String formattedMessage, Throwable throwable) {
/*  54 */       this.formattedMessage = formattedMessage;
/*  55 */       this.throwable = throwable;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormattedMessage() {
/*  60 */       return this.formattedMessage;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFormat() {
/*  65 */       return this.formattedMessage;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] getParameters() {
/*  70 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Throwable getThrowable() {
/*  75 */       return this.throwable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static final ParameterizedNoReferenceMessageFactory INSTANCE = new ParameterizedNoReferenceMessageFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message newMessage(String message, Object... params) {
/* 102 */     if (params == null) {
/* 103 */       return new SimpleMessage(message);
/*     */     }
/* 105 */     ParameterizedMessage msg = new ParameterizedMessage(message, params);
/* 106 */     return new StatusMessage(msg.getFormattedMessage(), msg.getThrowable());
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\message\ParameterizedNoReferenceMessageFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */