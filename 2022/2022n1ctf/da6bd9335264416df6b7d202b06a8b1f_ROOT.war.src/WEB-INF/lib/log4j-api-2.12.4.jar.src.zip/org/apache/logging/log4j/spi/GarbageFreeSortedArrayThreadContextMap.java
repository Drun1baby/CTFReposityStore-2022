/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.ReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.SortedArrayStringMap;
/*     */ import org.apache.logging.log4j.util.StringMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GarbageFreeSortedArrayThreadContextMap
/*     */   implements ReadOnlyThreadContextMap, ObjectThreadContextMap
/*     */ {
/*     */   public static final String INHERITABLE_MAP = "isThreadContextMapInheritable";
/*     */   protected static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   protected static final String PROPERTY_NAME_INITIAL_CAPACITY = "log4j2.ThreadContext.initial.capacity";
/*     */   protected final ThreadLocal<StringMap> localMap;
/*     */   private static volatile int initialCapacity;
/*     */   private static volatile boolean inheritableMap;
/*     */   
/*     */   static void init() {
/*  65 */     PropertiesUtil properties = PropertiesUtil.getProperties();
/*  66 */     initialCapacity = properties.getIntegerProperty("log4j2.ThreadContext.initial.capacity", 16);
/*  67 */     inheritableMap = properties.getBooleanProperty("isThreadContextMapInheritable");
/*     */   }
/*     */   
/*     */   static {
/*  71 */     init();
/*     */   }
/*     */   
/*     */   public GarbageFreeSortedArrayThreadContextMap() {
/*  75 */     this.localMap = createThreadLocalMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadLocal<StringMap> createThreadLocalMap() {
/*  81 */     if (inheritableMap) {
/*  82 */       return new InheritableThreadLocal<StringMap>()
/*     */         {
/*     */           protected StringMap childValue(StringMap parentValue) {
/*  85 */             return (parentValue != null) ? GarbageFreeSortedArrayThreadContextMap.this.createStringMap((ReadOnlyStringMap)parentValue) : null;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*  90 */     return new ThreadLocal<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringMap createStringMap() {
/* 101 */     return (StringMap)new SortedArrayStringMap(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringMap createStringMap(ReadOnlyStringMap original) {
/* 114 */     return (StringMap)new SortedArrayStringMap(original);
/*     */   }
/*     */   
/*     */   private StringMap getThreadLocalMap() {
/* 118 */     StringMap map = this.localMap.get();
/* 119 */     if (map == null) {
/* 120 */       map = createStringMap();
/* 121 */       this.localMap.set(map);
/*     */     } 
/* 123 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, String value) {
/* 128 */     getThreadLocalMap().putValue(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putValue(String key, Object value) {
/* 133 */     getThreadLocalMap().putValue(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<String, String> values) {
/* 138 */     if (values == null || values.isEmpty()) {
/*     */       return;
/*     */     }
/* 141 */     StringMap map = getThreadLocalMap();
/* 142 */     for (Map.Entry<String, String> entry : values.entrySet()) {
/* 143 */       map.putValue(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> void putAllValues(Map<String, V> values) {
/* 149 */     if (values == null || values.isEmpty()) {
/*     */       return;
/*     */     }
/* 152 */     StringMap map = getThreadLocalMap();
/* 153 */     for (Map.Entry<String, V> entry : values.entrySet()) {
/* 154 */       map.putValue(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String key) {
/* 160 */     return getValue(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 165 */     StringMap map = this.localMap.get();
/* 166 */     return (map == null) ? null : (V)map.getValue(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 171 */     StringMap map = this.localMap.get();
/* 172 */     if (map != null) {
/* 173 */       map.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAll(Iterable<String> keys) {
/* 179 */     StringMap map = this.localMap.get();
/* 180 */     if (map != null) {
/* 181 */       for (String key : keys) {
/* 182 */         map.remove(key);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 189 */     StringMap map = this.localMap.get();
/* 190 */     if (map != null) {
/* 191 */       map.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 197 */     StringMap map = this.localMap.get();
/* 198 */     return (map != null && map.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopy() {
/* 203 */     StringMap map = this.localMap.get();
/* 204 */     return (map == null) ? new HashMap<>() : map.toMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringMap getReadOnlyContextData() {
/* 212 */     StringMap map = this.localMap.get();
/* 213 */     if (map == null) {
/* 214 */       map = createStringMap();
/* 215 */       this.localMap.set(map);
/*     */     } 
/* 217 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImmutableMapOrNull() {
/* 222 */     StringMap map = this.localMap.get();
/* 223 */     return (map == null) ? null : Collections.<String, String>unmodifiableMap(map.toMap());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 228 */     StringMap map = this.localMap.get();
/* 229 */     return (map == null || map.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 234 */     StringMap map = this.localMap.get();
/* 235 */     return (map == null) ? "{}" : map.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 240 */     int prime = 31;
/* 241 */     int result = 1;
/* 242 */     StringMap map = this.localMap.get();
/* 243 */     result = 31 * result + ((map == null) ? 0 : map.hashCode());
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 249 */     if (this == obj) {
/* 250 */       return true;
/*     */     }
/* 252 */     if (obj == null) {
/* 253 */       return false;
/*     */     }
/* 255 */     if (!(obj instanceof ThreadContextMap)) {
/* 256 */       return false;
/*     */     }
/* 258 */     ThreadContextMap other = (ThreadContextMap)obj;
/* 259 */     Map<String, String> map = getImmutableMapOrNull();
/* 260 */     Map<String, String> otherMap = other.getImmutableMapOrNull();
/* 261 */     if (map == null) {
/* 262 */       if (otherMap != null) {
/* 263 */         return false;
/*     */       }
/* 265 */     } else if (!map.equals(otherMap)) {
/* 266 */       return false;
/*     */     } 
/* 268 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\GarbageFreeSortedArrayThreadContextMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */