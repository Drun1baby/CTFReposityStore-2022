/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoaderUtil
/*     */ {
/*     */   public static final String IGNORE_TCCL_PROPERTY = "log4j.ignoreTCL";
/*  48 */   private static final SecurityManager SECURITY_MANAGER = System.getSecurityManager();
/*     */ 
/*     */   
/*     */   private static Boolean ignoreTCCL;
/*     */ 
/*     */   
/*     */   private static final boolean GET_CLASS_LOADER_DISABLED;
/*     */   
/*  56 */   private static final PrivilegedAction<ClassLoader> TCCL_GETTER = new ThreadContextClassLoaderGetter();
/*     */   
/*     */   static {
/*  59 */     if (SECURITY_MANAGER != null) {
/*     */       boolean getClassLoaderDisabled;
/*     */       try {
/*  62 */         SECURITY_MANAGER.checkPermission(new RuntimePermission("getClassLoader"));
/*  63 */         getClassLoaderDisabled = false;
/*  64 */       } catch (SecurityException ignored) {
/*  65 */         getClassLoaderDisabled = true;
/*     */       } 
/*  67 */       GET_CLASS_LOADER_DISABLED = getClassLoaderDisabled;
/*     */     } else {
/*  69 */       GET_CLASS_LOADER_DISABLED = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader getThreadContextClassLoader() {
/*  85 */     if (GET_CLASS_LOADER_DISABLED)
/*     */     {
/*     */       
/*  88 */       return LoaderUtil.class.getClassLoader();
/*     */     }
/*  90 */     return (SECURITY_MANAGER == null) ? TCCL_GETTER.run() : AccessController.<ClassLoader>doPrivileged(TCCL_GETTER);
/*     */   }
/*     */   
/*     */   private static class ThreadContextClassLoaderGetter
/*     */     implements PrivilegedAction<ClassLoader>
/*     */   {
/*     */     private ThreadContextClassLoaderGetter() {}
/*     */     
/*     */     public ClassLoader run() {
/*  99 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 100 */       if (cl != null) {
/* 101 */         return cl;
/*     */       }
/* 103 */       ClassLoader ccl = LoaderUtil.class.getClassLoader();
/* 104 */       return (ccl == null && !LoaderUtil.GET_CLASS_LOADER_DISABLED) ? ClassLoader.getSystemClassLoader() : ccl;
/*     */     }
/*     */   }
/*     */   
/*     */   public static ClassLoader[] getClassLoaders() {
/* 109 */     List<ClassLoader> classLoaders = new ArrayList<>();
/* 110 */     ClassLoader tcl = getThreadContextClassLoader();
/* 111 */     classLoaders.add(tcl);
/*     */     
/* 113 */     ClassLoader current = LoaderUtil.class.getClassLoader();
/* 114 */     if (current != null && current != tcl) {
/* 115 */       classLoaders.add(current);
/* 116 */       ClassLoader classLoader = current.getParent();
/* 117 */       while (classLoader != null && !classLoaders.contains(classLoader)) {
/* 118 */         classLoaders.add(classLoader);
/*     */       }
/*     */     } 
/* 121 */     ClassLoader parent = (tcl == null) ? null : tcl.getParent();
/* 122 */     while (parent != null && !classLoaders.contains(parent)) {
/* 123 */       classLoaders.add(parent);
/* 124 */       parent = parent.getParent();
/*     */     } 
/* 126 */     ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
/* 127 */     if (!classLoaders.contains(systemClassLoader)) {
/* 128 */       classLoaders.add(systemClassLoader);
/*     */     }
/* 130 */     return classLoaders.<ClassLoader>toArray(new ClassLoader[classLoaders.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isClassAvailable(String className) {
/*     */     try {
/* 142 */       Class<?> clazz = loadClass(className);
/* 143 */       return (clazz != null);
/* 144 */     } catch (ClassNotFoundException|LinkageError e) {
/* 145 */       return false;
/* 146 */     } catch (Throwable e) {
/* 147 */       LowLevelLogUtil.logException("Unknown error checking for existence of class: " + className, e);
/* 148 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> loadClass(String className) throws ClassNotFoundException {
/* 162 */     if (isIgnoreTccl()) {
/* 163 */       return Class.forName(className);
/*     */     }
/*     */     try {
/* 166 */       return getThreadContextClassLoader().loadClass(className);
/* 167 */     } catch (Throwable ignored) {
/* 168 */       return Class.forName(className);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOf(Class<T> clazz) throws InstantiationException, IllegalAccessException, InvocationTargetException {
/*     */     try {
/* 185 */       return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 186 */     } catch (NoSuchMethodException ignored) {
/*     */       
/* 188 */       return clazz.newInstance();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstanceOf(String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
/* 207 */     return newInstanceOf((Class)loadClass(className));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newCheckedInstanceOf(String className, Class<T> clazz) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
/* 228 */     return clazz.cast(newInstanceOf(className));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newCheckedInstanceOfProperty(String propertyName, Class<T> clazz) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
/* 249 */     String className = PropertiesUtil.getProperties().getStringProperty(propertyName);
/* 250 */     if (className == null) {
/* 251 */       return null;
/*     */     }
/* 253 */     return newCheckedInstanceOf(className, clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isIgnoreTccl() {
/* 258 */     if (ignoreTCCL == null) {
/* 259 */       String ignoreTccl = PropertiesUtil.getProperties().getStringProperty("log4j.ignoreTCL", null);
/* 260 */       ignoreTCCL = Boolean.valueOf((ignoreTccl != null && !"false".equalsIgnoreCase(ignoreTccl.trim())));
/*     */     } 
/* 262 */     return ignoreTCCL.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<URL> findResources(String resource) {
/* 273 */     Collection<UrlResource> urlResources = findUrlResources(resource);
/* 274 */     Collection<URL> resources = new LinkedHashSet<>(urlResources.size());
/* 275 */     for (UrlResource urlResource : urlResources) {
/* 276 */       resources.add(urlResource.getUrl());
/*     */     }
/* 278 */     return resources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Collection<UrlResource> findUrlResources(String resource) {
/* 286 */     ClassLoader[] candidates = { getThreadContextClassLoader(), LoaderUtil.class.getClassLoader(), GET_CLASS_LOADER_DISABLED ? null : ClassLoader.getSystemClassLoader() };
/*     */     
/* 288 */     Collection<UrlResource> resources = new LinkedHashSet<>();
/* 289 */     for (ClassLoader cl : candidates) {
/* 290 */       if (cl != null) {
/*     */         try {
/* 292 */           Enumeration<URL> resourceEnum = cl.getResources(resource);
/* 293 */           while (resourceEnum.hasMoreElements()) {
/* 294 */             resources.add(new UrlResource(cl, resourceEnum.nextElement()));
/*     */           }
/* 296 */         } catch (IOException e) {
/* 297 */           LowLevelLogUtil.logException(e);
/*     */         } 
/*     */       }
/*     */     } 
/* 301 */     return resources;
/*     */   }
/*     */ 
/*     */   
/*     */   static class UrlResource
/*     */   {
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     private final URL url;
/*     */     
/*     */     UrlResource(ClassLoader classLoader, URL url) {
/* 312 */       this.classLoader = classLoader;
/* 313 */       this.url = url;
/*     */     }
/*     */     
/*     */     public ClassLoader getClassLoader() {
/* 317 */       return this.classLoader;
/*     */     }
/*     */     
/*     */     public URL getUrl() {
/* 321 */       return this.url;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 326 */       if (this == o) {
/* 327 */         return true;
/*     */       }
/* 329 */       if (o == null || getClass() != o.getClass()) {
/* 330 */         return false;
/*     */       }
/*     */       
/* 333 */       UrlResource that = (UrlResource)o;
/*     */       
/* 335 */       if ((this.classLoader != null) ? !this.classLoader.equals(that.classLoader) : (that.classLoader != null)) {
/* 336 */         return false;
/*     */       }
/* 338 */       if ((this.url != null) ? !this.url.equals(that.url) : (that.url != null)) {
/* 339 */         return false;
/*     */       }
/*     */       
/* 342 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 347 */       return Objects.hashCode(this.classLoader) + Objects.hashCode(this.url);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\LoaderUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */