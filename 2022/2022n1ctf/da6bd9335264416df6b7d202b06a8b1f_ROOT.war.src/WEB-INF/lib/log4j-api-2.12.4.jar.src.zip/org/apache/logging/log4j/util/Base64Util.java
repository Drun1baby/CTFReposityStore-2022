/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.logging.log4j.LoggingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Base64Util
/*    */ {
/* 30 */   private static Method encodeMethod = null;
/* 31 */   private static Object encoder = null;
/*    */   
/*    */   static {
/*    */     try {
/* 35 */       Class<?> clazz = LoaderUtil.loadClass("java.util.Base64");
/* 36 */       Class<?> encoderClazz = LoaderUtil.loadClass("java.util.Base64$Encoder");
/* 37 */       Method method = clazz.getMethod("getEncoder", new Class[0]);
/* 38 */       encoder = method.invoke(null, new Object[0]);
/* 39 */       encodeMethod = encoderClazz.getMethod("encodeToString", new Class[] { byte[].class });
/* 40 */     } catch (Exception ex) {
/*    */       try {
/* 42 */         Class<?> clazz = LoaderUtil.loadClass("javax.xml.bind.DataTypeConverter");
/* 43 */         encodeMethod = clazz.getMethod("printBase64Binary", new Class[0]);
/* 44 */       } catch (Exception ex2) {
/* 45 */         LowLevelLogUtil.logException("Unable to create a Base64 Encoder", ex2);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String encode(String str) {
/* 54 */     if (str == null) {
/* 55 */       return null;
/*    */     }
/* 57 */     byte[] data = str.getBytes();
/* 58 */     if (encodeMethod != null) {
/*    */       try {
/* 60 */         return (String)encodeMethod.invoke(encoder, new Object[] { data });
/* 61 */       } catch (Exception ex) {
/* 62 */         throw new LoggingException("Unable to encode String", ex);
/*    */       } 
/*    */     }
/* 65 */     throw new LoggingException("No Encoder, unable to encode string");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\Base64Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */