/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertiesUtil
/*     */ {
/*     */   private static final String LOG4J_PROPERTIES_FILE_NAME = "log4j2.component.properties";
/*     */   private static final String LOG4J_SYSTEM_PROPERTIES_FILE_NAME = "log4j2.system.properties";
/*     */   private static final String SYSTEM = "system:";
/*  51 */   private static final PropertiesUtil LOG4J_PROPERTIES = new PropertiesUtil("log4j2.component.properties");
/*     */ 
/*     */ 
/*     */   
/*     */   private final Environment environment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesUtil(Properties props) {
/*  61 */     this.environment = new Environment(new PropertiesPropertySource(props));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesUtil(String propertiesFileName) {
/*  71 */     this.environment = new Environment(new PropertyFilePropertySource(propertiesFileName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Properties loadClose(InputStream in, Object source) {
/*  82 */     Properties props = new Properties();
/*  83 */     if (null != in) {
/*     */       try {
/*  85 */         props.load(in);
/*  86 */       } catch (IOException e) {
/*  87 */         LowLevelLogUtil.logException("Unable to read " + source, e);
/*     */       } finally {
/*     */         try {
/*  90 */           in.close();
/*  91 */         } catch (IOException e) {
/*  92 */           LowLevelLogUtil.logException("Unable to close " + source, e);
/*     */         } 
/*     */       } 
/*     */     }
/*  96 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertiesUtil getProperties() {
/* 105 */     return LOG4J_PROPERTIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(String name) {
/* 115 */     return this.environment.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name) {
/* 127 */     return getBooleanProperty(name, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name, boolean defaultValue) {
/* 138 */     String prop = getStringProperty(name);
/* 139 */     return (prop == null) ? defaultValue : "true".equalsIgnoreCase(prop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBooleanProperty(String name, boolean defaultValueIfAbsent, boolean defaultValueIfPresent) {
/* 152 */     String prop = getStringProperty(name);
/* 153 */     return (prop == null) ? defaultValueIfAbsent : (
/* 154 */       prop.isEmpty() ? defaultValueIfPresent : "true".equalsIgnoreCase(prop));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharsetProperty(String name) {
/* 164 */     return getCharsetProperty(name, Charset.defaultCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharsetProperty(String name, Charset defaultValue) {
/* 176 */     String charsetName = getStringProperty(name);
/* 177 */     if (charsetName == null) {
/* 178 */       return defaultValue;
/*     */     }
/* 180 */     if (Charset.isSupported(charsetName)) {
/* 181 */       return Charset.forName(charsetName);
/*     */     }
/* 183 */     ResourceBundle bundle = getCharsetsResourceBundle();
/* 184 */     if (bundle.containsKey(name)) {
/* 185 */       String mapped = bundle.getString(name);
/* 186 */       if (Charset.isSupported(mapped)) {
/* 187 */         return Charset.forName(mapped);
/*     */       }
/*     */     } 
/* 190 */     LowLevelLogUtil.log("Unable to get Charset '" + charsetName + "' for property '" + name + "', using default " + defaultValue + " and continuing.");
/*     */     
/* 192 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleProperty(String name, double defaultValue) {
/* 203 */     String prop = getStringProperty(name);
/* 204 */     if (prop != null) {
/*     */       try {
/* 206 */         return Double.parseDouble(prop);
/* 207 */       } catch (Exception ignored) {
/* 208 */         return defaultValue;
/*     */       } 
/*     */     }
/* 211 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerProperty(String name, int defaultValue) {
/* 223 */     String prop = getStringProperty(name);
/* 224 */     if (prop != null) {
/*     */       try {
/* 226 */         return Integer.parseInt(prop);
/* 227 */       } catch (Exception ignored) {
/* 228 */         return defaultValue;
/*     */       } 
/*     */     }
/* 231 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLongProperty(String name, long defaultValue) {
/* 242 */     String prop = getStringProperty(name);
/* 243 */     if (prop != null) {
/*     */       try {
/* 245 */         return Long.parseLong(prop);
/* 246 */       } catch (Exception ignored) {
/* 247 */         return defaultValue;
/*     */       } 
/*     */     }
/* 250 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String name) {
/* 260 */     return this.environment.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringProperty(String name, String defaultValue) {
/* 271 */     String prop = getStringProperty(name);
/* 272 */     return (prop == null) ? defaultValue : prop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getSystemProperties() {
/*     */     try {
/* 282 */       return new Properties(System.getProperties());
/* 283 */     } catch (SecurityException ex) {
/* 284 */       LowLevelLogUtil.logException("Unable to access system properties.", ex);
/*     */       
/* 286 */       return new Properties();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reload() {
/* 296 */     this.environment.reload();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Environment
/*     */   {
/* 314 */     private final Set<PropertySource> sources = new TreeSet<>(new PropertySource.Comparator());
/* 315 */     private final Map<CharSequence, String> literal = new ConcurrentHashMap<>();
/* 316 */     private final Map<CharSequence, String> normalized = new ConcurrentHashMap<>();
/* 317 */     private final Map<List<CharSequence>, String> tokenized = new ConcurrentHashMap<>();
/*     */     
/*     */     private Environment(PropertySource propertySource) {
/* 320 */       PropertyFilePropertySource sysProps = new PropertyFilePropertySource("log4j2.system.properties");
/*     */       try {
/* 322 */         sysProps.forEach(new BiConsumer<String, String>()
/*     */             {
/*     */               public void accept(String key, String value) {
/* 325 */                 if (System.getProperty(key) == null) {
/* 326 */                   System.setProperty(key, value);
/*     */                 }
/*     */               }
/*     */             });
/* 330 */       } catch (SecurityException securityException) {}
/*     */ 
/*     */       
/* 333 */       this.sources.add(propertySource);
/* 334 */       for (ClassLoader classLoader : LoaderUtil.getClassLoaders()) {
/*     */         try {
/* 336 */           for (PropertySource source : ServiceLoader.<PropertySource>load(PropertySource.class, classLoader)) {
/* 337 */             this.sources.add(source);
/*     */           }
/* 339 */         } catch (Throwable throwable) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 346 */       reload();
/*     */     }
/*     */     
/*     */     private synchronized void reload() {
/* 350 */       this.literal.clear();
/* 351 */       this.normalized.clear();
/* 352 */       this.tokenized.clear();
/* 353 */       for (PropertySource source : this.sources) {
/* 354 */         source.forEach(new BiConsumer<String, String>()
/*     */             {
/*     */               public void accept(String key, String value) {
/* 357 */                 if (key != null && value != null) {
/* 358 */                   PropertiesUtil.Environment.this.literal.put(key, value);
/* 359 */                   List<CharSequence> tokens = PropertySource.Util.tokenize(key);
/* 360 */                   if (tokens.isEmpty()) {
/* 361 */                     PropertiesUtil.Environment.this.normalized.put(source.getNormalForm(Collections.singleton(key)), value);
/*     */                   } else {
/* 363 */                     PropertiesUtil.Environment.this.normalized.put(source.getNormalForm(tokens), value);
/* 364 */                     PropertiesUtil.Environment.this.tokenized.put(tokens, value);
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */     }
/*     */     
/*     */     private static boolean hasSystemProperty(String key) {
/*     */       try {
/* 374 */         return System.getProperties().containsKey(key);
/* 375 */       } catch (SecurityException ignored) {
/* 376 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     private String get(String key) {
/* 381 */       if (this.normalized.containsKey(key)) {
/* 382 */         return this.normalized.get(key);
/*     */       }
/* 384 */       if (this.literal.containsKey(key)) {
/* 385 */         return this.literal.get(key);
/*     */       }
/* 387 */       if (hasSystemProperty(key)) {
/* 388 */         return System.getProperty(key);
/*     */       }
/* 390 */       return this.tokenized.get(PropertySource.Util.tokenize(key));
/*     */     }
/*     */     
/*     */     private boolean containsKey(String key) {
/* 394 */       return (this.normalized.containsKey(key) || this.literal
/* 395 */         .containsKey(key) || 
/* 396 */         hasSystemProperty(key) || this.tokenized
/* 397 */         .containsKey(PropertySource.Util.tokenize(key)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties extractSubset(Properties properties, String prefix) {
/* 410 */     Properties subset = new Properties();
/*     */     
/* 412 */     if (prefix == null || prefix.length() == 0) {
/* 413 */       return subset;
/*     */     }
/*     */     
/* 416 */     String prefixToMatch = (prefix.charAt(prefix.length() - 1) != '.') ? (prefix + '.') : prefix;
/*     */     
/* 418 */     List<String> keys = new ArrayList<>();
/*     */     
/* 420 */     for (String key : properties.stringPropertyNames()) {
/* 421 */       if (key.startsWith(prefixToMatch)) {
/* 422 */         subset.setProperty(key.substring(prefixToMatch.length()), properties.getProperty(key));
/* 423 */         keys.add(key);
/*     */       } 
/*     */     } 
/* 426 */     for (String key : keys) {
/* 427 */       properties.remove(key);
/*     */     }
/*     */     
/* 430 */     return subset;
/*     */   }
/*     */   
/*     */   static ResourceBundle getCharsetsResourceBundle() {
/* 434 */     return ResourceBundle.getBundle("Log4j-charsets");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Properties> partitionOnCommonPrefixes(Properties properties) {
/* 446 */     Map<String, Properties> parts = new ConcurrentHashMap<>();
/* 447 */     for (String key : properties.stringPropertyNames()) {
/* 448 */       String prefix = key.substring(0, key.indexOf('.'));
/* 449 */       if (!parts.containsKey(prefix)) {
/* 450 */         parts.put(prefix, new Properties());
/*     */       }
/* 452 */       ((Properties)parts.get(prefix)).setProperty(key.substring(key.indexOf('.') + 1), properties.getProperty(key));
/*     */     } 
/* 454 */     return parts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOsWindows() {
/* 463 */     return getStringProperty("os.name", "").startsWith("Windows");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\PropertiesUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */