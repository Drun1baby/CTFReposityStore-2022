/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.apache.logging.log4j.status.StatusLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortedArrayStringMap
/*     */   implements IndexedStringMap
/*     */ {
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 4;
/*     */   private static final long serialVersionUID = -5748905872274478116L;
/*     */   private static final int HASHVAL = 31;
/*     */   
/*  70 */   private static final TriConsumer<String, Object, StringMap> PUT_ALL = new TriConsumer<String, Object, StringMap>()
/*     */     {
/*     */       public void accept(String key, Object value, StringMap contextData) {
/*  73 */         contextData.putValue(key, value);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private static final String[] EMPTY = new String[0];
/*     */   
/*     */   private static final String FROZEN = "Frozen collection cannot be modified";
/*  83 */   private transient String[] keys = EMPTY;
/*  84 */   private transient Object[] values = (Object[])EMPTY;
/*     */   
/*     */   private transient int size;
/*     */   
/*     */   private static final Method setObjectInputFilter;
/*     */   private static final Method getObjectInputFilter;
/*     */   private static final Method newObjectInputFilter;
/*     */   private int threshold;
/*     */   private boolean immutable;
/*     */   private transient boolean iterating;
/*     */   
/*     */   static {
/*  96 */     Method[] methods = ObjectInputStream.class.getMethods();
/*  97 */     Method setMethod = null;
/*  98 */     Method getMethod = null;
/*  99 */     for (Method method : methods) {
/* 100 */       if (method.getName().equals("setObjectInputFilter")) {
/* 101 */         setMethod = method;
/* 102 */       } else if (method.getName().equals("getObjectInputFilter")) {
/* 103 */         getMethod = method;
/*     */       } 
/*     */     } 
/* 106 */     Method newMethod = null;
/*     */     try {
/* 108 */       if (setMethod != null) {
/* 109 */         Class<?> clazz = Class.forName("org.apache.logging.log4j.util.internal.DefaultObjectInputFilter");
/* 110 */         methods = clazz.getMethods();
/* 111 */         for (Method method : methods) {
/* 112 */           if (method.getName().equals("newInstance") && Modifier.isStatic(method.getModifiers())) {
/* 113 */             newMethod = method;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 118 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/* 121 */     newObjectInputFilter = newMethod;
/* 122 */     setObjectInputFilter = setMethod;
/* 123 */     getObjectInputFilter = getMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedArrayStringMap() {
/* 137 */     this(4);
/*     */   }
/*     */   
/*     */   public SortedArrayStringMap(int initialCapacity) {
/* 141 */     if (initialCapacity < 0) {
/* 142 */       throw new IllegalArgumentException("Initial capacity must be at least zero but was " + initialCapacity);
/*     */     }
/* 144 */     this.threshold = ceilingNextPowerOfTwo((initialCapacity == 0) ? 1 : initialCapacity);
/*     */   }
/*     */   
/*     */   public SortedArrayStringMap(ReadOnlyStringMap other) {
/* 148 */     if (other instanceof SortedArrayStringMap) {
/* 149 */       initFrom0((SortedArrayStringMap)other);
/* 150 */     } else if (other != null) {
/* 151 */       resize(ceilingNextPowerOfTwo(other.size()));
/* 152 */       other.forEach(PUT_ALL, this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public SortedArrayStringMap(Map<String, ?> map) {
/* 157 */     resize(ceilingNextPowerOfTwo(map.size()));
/* 158 */     for (Map.Entry<String, ?> entry : map.entrySet()) {
/* 159 */       putValue(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void assertNotFrozen() {
/* 164 */     if (this.immutable) {
/* 165 */       throw new UnsupportedOperationException("Frozen collection cannot be modified");
/*     */     }
/*     */   }
/*     */   
/*     */   private void assertNoConcurrentModification() {
/* 170 */     if (this.iterating) {
/* 171 */       throw new ConcurrentModificationException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 177 */     if (this.keys == EMPTY) {
/*     */       return;
/*     */     }
/* 180 */     assertNotFrozen();
/* 181 */     assertNoConcurrentModification();
/*     */     
/* 183 */     Arrays.fill((Object[])this.keys, 0, this.size, (Object)null);
/* 184 */     Arrays.fill(this.values, 0, this.size, (Object)null);
/* 185 */     this.size = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 190 */     return (indexOfKey(key) >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> toMap() {
/* 195 */     Map<String, String> result = new HashMap<>(size());
/* 196 */     for (int i = 0; i < size(); i++) {
/* 197 */       Object value = getValueAt(i);
/* 198 */       result.put(getKeyAt(i), (value == null) ? null : String.valueOf(value));
/*     */     } 
/* 200 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void freeze() {
/* 205 */     this.immutable = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFrozen() {
/* 210 */     return this.immutable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 216 */     int index = indexOfKey(key);
/* 217 */     if (index < 0) {
/* 218 */       return null;
/*     */     }
/* 220 */     return (V)this.values[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 225 */     return (this.size == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOfKey(String key) {
/* 230 */     if (this.keys == EMPTY) {
/* 231 */       return -1;
/*     */     }
/* 233 */     if (key == null) {
/* 234 */       return nullKeyIndex();
/*     */     }
/* 236 */     int start = (this.size > 0 && this.keys[0] == null) ? 1 : 0;
/* 237 */     return Arrays.binarySearch((Object[])this.keys, start, this.size, key);
/*     */   }
/*     */   
/*     */   private int nullKeyIndex() {
/* 241 */     return (this.size > 0 && this.keys[0] == null) ? 0 : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putValue(String key, Object value) {
/* 246 */     assertNotFrozen();
/* 247 */     assertNoConcurrentModification();
/*     */     
/* 249 */     if (this.keys == EMPTY) {
/* 250 */       inflateTable(this.threshold);
/*     */     }
/* 252 */     int index = indexOfKey(key);
/* 253 */     if (index >= 0) {
/* 254 */       this.keys[index] = key;
/* 255 */       this.values[index] = value;
/*     */     } else {
/* 257 */       insertAt(index ^ 0xFFFFFFFF, key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void insertAt(int index, String key, Object value) {
/* 262 */     ensureCapacity();
/* 263 */     System.arraycopy(this.keys, index, this.keys, index + 1, this.size - index);
/* 264 */     System.arraycopy(this.values, index, this.values, index + 1, this.size - index);
/* 265 */     this.keys[index] = key;
/* 266 */     this.values[index] = value;
/* 267 */     this.size++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(ReadOnlyStringMap source) {
/* 272 */     if (source == this || source == null || source.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 278 */     assertNotFrozen();
/* 279 */     assertNoConcurrentModification();
/*     */     
/* 281 */     if (source instanceof SortedArrayStringMap) {
/* 282 */       if (this.size == 0) {
/* 283 */         initFrom0((SortedArrayStringMap)source);
/*     */       } else {
/* 285 */         merge((SortedArrayStringMap)source);
/*     */       } 
/* 287 */     } else if (source != null) {
/* 288 */       source.forEach(PUT_ALL, this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initFrom0(SortedArrayStringMap other) {
/* 293 */     if (this.keys.length < other.size) {
/* 294 */       this.keys = new String[other.threshold];
/* 295 */       this.values = new Object[other.threshold];
/*     */     } 
/* 297 */     System.arraycopy(other.keys, 0, this.keys, 0, other.size);
/* 298 */     System.arraycopy(other.values, 0, this.values, 0, other.size);
/*     */     
/* 300 */     this.size = other.size;
/* 301 */     this.threshold = other.threshold;
/*     */   }
/*     */   
/*     */   private void merge(SortedArrayStringMap other) {
/* 305 */     String[] myKeys = this.keys;
/* 306 */     Object[] myVals = this.values;
/* 307 */     int newSize = other.size + this.size;
/* 308 */     this.threshold = ceilingNextPowerOfTwo(newSize);
/* 309 */     if (this.keys.length < this.threshold) {
/* 310 */       this.keys = new String[this.threshold];
/* 311 */       this.values = new Object[this.threshold];
/*     */     } 
/*     */     
/* 314 */     boolean overwrite = true;
/* 315 */     if (other.size() > size()) {
/*     */       
/* 317 */       System.arraycopy(myKeys, 0, this.keys, other.size, this.size);
/* 318 */       System.arraycopy(myVals, 0, this.values, other.size, this.size);
/*     */ 
/*     */       
/* 321 */       System.arraycopy(other.keys, 0, this.keys, 0, other.size);
/* 322 */       System.arraycopy(other.values, 0, this.values, 0, other.size);
/* 323 */       this.size = other.size;
/*     */ 
/*     */       
/* 326 */       overwrite = false;
/*     */     } else {
/* 328 */       System.arraycopy(myKeys, 0, this.keys, 0, this.size);
/* 329 */       System.arraycopy(myVals, 0, this.values, 0, this.size);
/*     */ 
/*     */       
/* 332 */       System.arraycopy(other.keys, 0, this.keys, this.size, other.size);
/* 333 */       System.arraycopy(other.values, 0, this.values, this.size, other.size);
/*     */     } 
/*     */ 
/*     */     
/* 337 */     for (int i = this.size; i < newSize; i++) {
/* 338 */       int index = indexOfKey(this.keys[i]);
/* 339 */       if (index < 0) {
/* 340 */         insertAt(index ^ 0xFFFFFFFF, this.keys[i], this.values[i]);
/* 341 */       } else if (overwrite) {
/* 342 */         this.keys[index] = this.keys[i];
/* 343 */         this.values[index] = this.values[i];
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     Arrays.fill((Object[])this.keys, this.size, newSize, (Object)null);
/* 348 */     Arrays.fill(this.values, this.size, newSize, (Object)null);
/*     */   }
/*     */   
/*     */   private void ensureCapacity() {
/* 352 */     if (this.size >= this.threshold) {
/* 353 */       resize(this.threshold * 2);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resize(int newCapacity) {
/* 358 */     String[] oldKeys = this.keys;
/* 359 */     Object[] oldValues = this.values;
/*     */     
/* 361 */     this.keys = new String[newCapacity];
/* 362 */     this.values = new Object[newCapacity];
/*     */     
/* 364 */     System.arraycopy(oldKeys, 0, this.keys, 0, this.size);
/* 365 */     System.arraycopy(oldValues, 0, this.values, 0, this.size);
/*     */     
/* 367 */     this.threshold = newCapacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void inflateTable(int toSize) {
/* 374 */     this.threshold = toSize;
/* 375 */     this.keys = new String[toSize];
/* 376 */     this.values = new Object[toSize];
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 381 */     if (this.keys == EMPTY) {
/*     */       return;
/*     */     }
/*     */     
/* 385 */     int index = indexOfKey(key);
/* 386 */     if (index >= 0) {
/* 387 */       assertNotFrozen();
/* 388 */       assertNoConcurrentModification();
/*     */       
/* 390 */       System.arraycopy(this.keys, index + 1, this.keys, index, this.size - 1 - index);
/* 391 */       System.arraycopy(this.values, index + 1, this.values, index, this.size - 1 - index);
/* 392 */       this.keys[this.size - 1] = null;
/* 393 */       this.values[this.size - 1] = null;
/* 394 */       this.size--;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKeyAt(int index) {
/* 400 */     if (index < 0 || index >= this.size) {
/* 401 */       return null;
/*     */     }
/* 403 */     return this.keys[index];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> V getValueAt(int index) {
/* 409 */     if (index < 0 || index >= this.size) {
/* 410 */       return null;
/*     */     }
/* 412 */     return (V)this.values[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 417 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V> void forEach(BiConsumer<String, ? super V> action) {
/* 423 */     this.iterating = true;
/*     */     try {
/* 425 */       for (int i = 0; i < this.size; i++) {
/* 426 */         action.accept(this.keys[i], (V)this.values[i]);
/*     */       }
/*     */     } finally {
/* 429 */       this.iterating = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <V, T> void forEach(TriConsumer<String, ? super V, T> action, T state) {
/* 436 */     this.iterating = true;
/*     */     try {
/* 438 */       for (int i = 0; i < this.size; i++) {
/* 439 */         action.accept(this.keys[i], (V)this.values[i], state);
/*     */       }
/*     */     } finally {
/* 442 */       this.iterating = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 448 */     if (obj == this) {
/* 449 */       return true;
/*     */     }
/* 451 */     if (!(obj instanceof SortedArrayStringMap)) {
/* 452 */       return false;
/*     */     }
/* 454 */     SortedArrayStringMap other = (SortedArrayStringMap)obj;
/* 455 */     if (size() != other.size()) {
/* 456 */       return false;
/*     */     }
/* 458 */     for (int i = 0; i < size(); i++) {
/* 459 */       if (!Objects.equals(this.keys[i], other.keys[i])) {
/* 460 */         return false;
/*     */       }
/* 462 */       if (!Objects.equals(this.values[i], other.values[i])) {
/* 463 */         return false;
/*     */       }
/*     */     } 
/* 466 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 471 */     int result = 37;
/* 472 */     result = 31 * result + this.size;
/* 473 */     result = 31 * result + hashCode((Object[])this.keys, this.size);
/* 474 */     result = 31 * result + hashCode(this.values, this.size);
/* 475 */     return result;
/*     */   }
/*     */   
/*     */   private static int hashCode(Object[] values, int length) {
/* 479 */     int result = 1;
/* 480 */     for (int i = 0; i < length; i++) {
/* 481 */       result = 31 * result + ((values[i] == null) ? 0 : values[i].hashCode());
/*     */     }
/* 483 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 488 */     StringBuilder sb = new StringBuilder(256);
/* 489 */     sb.append('{');
/* 490 */     for (int i = 0; i < this.size; i++) {
/* 491 */       if (i > 0) {
/* 492 */         sb.append(", ");
/*     */       }
/* 494 */       sb.append(this.keys[i]).append('=');
/* 495 */       sb.append((this.values[i] == this) ? "(this map)" : this.values[i]);
/*     */     } 
/* 497 */     sb.append('}');
/* 498 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 514 */     s.defaultWriteObject();
/*     */ 
/*     */     
/* 517 */     if (this.keys == EMPTY) {
/* 518 */       s.writeInt(ceilingNextPowerOfTwo(this.threshold));
/*     */     } else {
/* 520 */       s.writeInt(this.keys.length);
/*     */     } 
/*     */ 
/*     */     
/* 524 */     s.writeInt(this.size);
/*     */ 
/*     */     
/* 527 */     if (this.size > 0) {
/* 528 */       for (int i = 0; i < this.size; i++) {
/* 529 */         s.writeObject(this.keys[i]);
/*     */         try {
/* 531 */           s.writeObject(marshall(this.values[i]));
/* 532 */         } catch (Exception e) {
/* 533 */           handleSerializationException(e, i, this.keys[i]);
/* 534 */           s.writeObject(null);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static byte[] marshall(Object obj) throws IOException {
/* 541 */     if (obj == null) {
/* 542 */       return null;
/*     */     }
/* 544 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 545 */     try (ObjectOutputStream oos = new ObjectOutputStream(bout)) {
/* 546 */       oos.writeObject(obj);
/* 547 */       oos.flush();
/* 548 */       return bout.toByteArray();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object unmarshall(byte[] data, ObjectInputStream inputStream) throws IOException, ClassNotFoundException {
/*     */     ObjectInputStream ois;
/* 554 */     ByteArrayInputStream bin = new ByteArrayInputStream(data);
/* 555 */     Collection<String> allowedClasses = null;
/*     */     
/* 557 */     if (inputStream instanceof FilteredObjectInputStream) {
/* 558 */       allowedClasses = ((FilteredObjectInputStream)inputStream).getAllowedClasses();
/* 559 */       ois = new FilteredObjectInputStream(bin, allowedClasses);
/*     */     } else {
/*     */       try {
/* 562 */         Object obj = getObjectInputFilter.invoke(inputStream, new Object[0]);
/* 563 */         Object filter = newObjectInputFilter.invoke(null, new Object[] { obj });
/* 564 */         ois = new ObjectInputStream(bin);
/* 565 */         setObjectInputFilter.invoke(ois, new Object[] { filter });
/* 566 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException ex) {
/* 567 */         throw new StreamCorruptedException("Unable to set ObjectInputFilter on stream");
/*     */       } 
/*     */     } 
/*     */     try {
/* 571 */       return ois.readObject();
/*     */     } finally {
/* 573 */       ois.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int ceilingNextPowerOfTwo(int x) {
/* 586 */     int BITS_PER_INT = 32;
/* 587 */     return 1 << 32 - Integer.numberOfLeadingZeros(x - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 595 */     if (!(s instanceof FilteredObjectInputStream) && setObjectInputFilter == null) {
/* 596 */       throw new IllegalArgumentException("readObject requires a FilteredObjectInputStream or an ObjectInputStream that accepts an ObjectInputFilter");
/*     */     }
/*     */     
/* 599 */     s.defaultReadObject();
/*     */ 
/*     */     
/* 602 */     this.keys = EMPTY;
/* 603 */     this.values = (Object[])EMPTY;
/*     */ 
/*     */     
/* 606 */     int capacity = s.readInt();
/* 607 */     if (capacity < 0) {
/* 608 */       throw new InvalidObjectException("Illegal capacity: " + capacity);
/*     */     }
/*     */ 
/*     */     
/* 612 */     int mappings = s.readInt();
/* 613 */     if (mappings < 0) {
/* 614 */       throw new InvalidObjectException("Illegal mappings count: " + mappings);
/*     */     }
/*     */ 
/*     */     
/* 618 */     if (mappings > 0) {
/* 619 */       inflateTable(capacity);
/*     */     } else {
/* 621 */       this.threshold = capacity;
/*     */     } 
/*     */ 
/*     */     
/* 625 */     for (int i = 0; i < mappings; i++) {
/* 626 */       this.keys[i] = (String)s.readObject();
/*     */       try {
/* 628 */         byte[] marshalledObject = (byte[])s.readObject();
/* 629 */         this.values[i] = (marshalledObject == null) ? null : unmarshall(marshalledObject, s);
/* 630 */       } catch (Exception|LinkageError error) {
/* 631 */         handleSerializationException(error, i, this.keys[i]);
/* 632 */         this.values[i] = null;
/*     */       } 
/*     */     } 
/* 635 */     this.size = mappings;
/*     */   }
/*     */   
/*     */   private void handleSerializationException(Throwable t, int i, String key) {
/* 639 */     StatusLogger.getLogger().warn("Ignoring {} for key[{}] ('{}')", String.valueOf(t), Integer.valueOf(i), this.keys[i]);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\SortedArrayStringMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */