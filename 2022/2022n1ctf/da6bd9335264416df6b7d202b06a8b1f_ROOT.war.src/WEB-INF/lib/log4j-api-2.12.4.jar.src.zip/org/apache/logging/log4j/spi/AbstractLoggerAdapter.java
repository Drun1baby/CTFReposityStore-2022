/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.util.LoaderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoggerAdapter<L>
/*     */   implements LoggerAdapter<L>, LoggerContextShutdownAware
/*     */ {
/*  42 */   protected final Map<LoggerContext, ConcurrentMap<String, L>> registry = new ConcurrentHashMap<>();
/*     */   
/*  44 */   private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*     */ 
/*     */   
/*     */   public L getLogger(String name) {
/*  48 */     LoggerContext context = getContext();
/*  49 */     ConcurrentMap<String, L> loggers = getLoggersInContext(context);
/*  50 */     L logger = loggers.get(name);
/*  51 */     if (logger != null) {
/*  52 */       return logger;
/*     */     }
/*  54 */     loggers.putIfAbsent(name, newLogger(name, context));
/*  55 */     return loggers.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void contextShutdown(LoggerContext loggerContext) {
/*  60 */     this.registry.remove(loggerContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConcurrentMap<String, L> getLoggersInContext(LoggerContext context) {
/*     */     ConcurrentMap<String, L> loggers;
/*  71 */     this.lock.readLock().lock();
/*     */     try {
/*  73 */       loggers = this.registry.get(context);
/*     */     } finally {
/*  75 */       this.lock.readLock().unlock();
/*     */     } 
/*     */     
/*  78 */     if (loggers != null) {
/*  79 */       return loggers;
/*     */     }
/*  81 */     this.lock.writeLock().lock();
/*     */     try {
/*  83 */       loggers = this.registry.get(context);
/*  84 */       if (loggers == null) {
/*  85 */         loggers = new ConcurrentHashMap<>();
/*  86 */         this.registry.put(context, loggers);
/*  87 */         if (context instanceof LoggerContextShutdownEnabled) {
/*  88 */           ((LoggerContextShutdownEnabled)context).addShutdownListener(this);
/*     */         }
/*     */       } 
/*  91 */       return loggers;
/*     */     } finally {
/*  93 */       this.lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<LoggerContext> getLoggerContexts() {
/* 101 */     return new HashSet<>(this.registry.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract L newLogger(String paramString, LoggerContext paramLoggerContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract LoggerContext getContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LoggerContext getContext(Class<?> callerClass) {
/* 131 */     ClassLoader cl = null;
/* 132 */     if (callerClass != null) {
/* 133 */       cl = callerClass.getClassLoader();
/*     */     }
/* 135 */     if (cl == null) {
/* 136 */       cl = LoaderUtil.getThreadContextClassLoader();
/*     */     }
/* 138 */     return LogManager.getContext(cl, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 143 */     this.lock.writeLock().lock();
/*     */     try {
/* 145 */       this.registry.clear();
/*     */     } finally {
/* 147 */       this.lock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\AbstractLoggerAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */