/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.ReadOnlyStringMap;
/*     */ import org.apache.logging.log4j.util.SortedArrayStringMap;
/*     */ import org.apache.logging.log4j.util.StringMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CopyOnWriteSortedArrayThreadContextMap
/*     */   implements ReadOnlyThreadContextMap, ObjectThreadContextMap, CopyOnWrite
/*     */ {
/*     */   public static final String INHERITABLE_MAP = "isThreadContextMapInheritable";
/*     */   protected static final int DEFAULT_INITIAL_CAPACITY = 16;
/*     */   protected static final String PROPERTY_NAME_INITIAL_CAPACITY = "log4j2.ThreadContext.initial.capacity";
/*  55 */   private static final StringMap EMPTY_CONTEXT_DATA = (StringMap)new SortedArrayStringMap(1);
/*     */   
/*     */   private static volatile int initialCapacity;
/*     */   
/*     */   private static volatile boolean inheritableMap;
/*     */   
/*     */   private final ThreadLocal<StringMap> localMap;
/*     */ 
/*     */   
/*     */   static void init() {
/*  65 */     PropertiesUtil properties = PropertiesUtil.getProperties();
/*  66 */     initialCapacity = properties.getIntegerProperty("log4j2.ThreadContext.initial.capacity", 16);
/*  67 */     inheritableMap = properties.getBooleanProperty("isThreadContextMapInheritable");
/*     */   }
/*     */   
/*     */   static {
/*  71 */     EMPTY_CONTEXT_DATA.freeze();
/*  72 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteSortedArrayThreadContextMap() {
/*  78 */     this.localMap = createThreadLocalMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadLocal<StringMap> createThreadLocalMap() {
/*  84 */     if (inheritableMap) {
/*  85 */       return new InheritableThreadLocal<StringMap>()
/*     */         {
/*     */           protected StringMap childValue(StringMap parentValue) {
/*  88 */             if (parentValue == null) {
/*  89 */               return null;
/*     */             }
/*  91 */             StringMap stringMap = CopyOnWriteSortedArrayThreadContextMap.this.createStringMap((ReadOnlyStringMap)parentValue);
/*  92 */             stringMap.freeze();
/*  93 */             return stringMap;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*  98 */     return new ThreadLocal<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringMap createStringMap() {
/* 109 */     return (StringMap)new SortedArrayStringMap(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringMap createStringMap(ReadOnlyStringMap original) {
/* 122 */     return (StringMap)new SortedArrayStringMap(original);
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String key, String value) {
/* 127 */     putValue(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putValue(String key, Object value) {
/* 132 */     StringMap map = this.localMap.get();
/* 133 */     map = (map == null) ? createStringMap() : createStringMap((ReadOnlyStringMap)map);
/* 134 */     map.putValue(key, value);
/* 135 */     map.freeze();
/* 136 */     this.localMap.set(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<String, String> values) {
/* 141 */     if (values == null || values.isEmpty()) {
/*     */       return;
/*     */     }
/* 144 */     StringMap map = this.localMap.get();
/* 145 */     map = (map == null) ? createStringMap() : createStringMap((ReadOnlyStringMap)map);
/* 146 */     for (Map.Entry<String, String> entry : values.entrySet()) {
/* 147 */       map.putValue(entry.getKey(), entry.getValue());
/*     */     }
/* 149 */     map.freeze();
/* 150 */     this.localMap.set(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> void putAllValues(Map<String, V> values) {
/* 155 */     if (values == null || values.isEmpty()) {
/*     */       return;
/*     */     }
/* 158 */     StringMap map = this.localMap.get();
/* 159 */     map = (map == null) ? createStringMap() : createStringMap((ReadOnlyStringMap)map);
/* 160 */     for (Map.Entry<String, V> entry : values.entrySet()) {
/* 161 */       map.putValue(entry.getKey(), entry.getValue());
/*     */     }
/* 163 */     map.freeze();
/* 164 */     this.localMap.set(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String key) {
/* 169 */     return getValue(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public <V> V getValue(String key) {
/* 174 */     StringMap map = this.localMap.get();
/* 175 */     return (map == null) ? null : (V)map.getValue(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 180 */     StringMap map = this.localMap.get();
/* 181 */     if (map != null) {
/* 182 */       StringMap copy = createStringMap((ReadOnlyStringMap)map);
/* 183 */       copy.remove(key);
/* 184 */       copy.freeze();
/* 185 */       this.localMap.set(copy);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAll(Iterable<String> keys) {
/* 191 */     StringMap map = this.localMap.get();
/* 192 */     if (map != null) {
/* 193 */       StringMap copy = createStringMap((ReadOnlyStringMap)map);
/* 194 */       for (String key : keys) {
/* 195 */         copy.remove(key);
/*     */       }
/* 197 */       copy.freeze();
/* 198 */       this.localMap.set(copy);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 204 */     this.localMap.remove();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) {
/* 209 */     StringMap map = this.localMap.get();
/* 210 */     return (map != null && map.containsKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopy() {
/* 215 */     StringMap map = this.localMap.get();
/* 216 */     return (map == null) ? new HashMap<>() : map.toMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringMap getReadOnlyContextData() {
/* 224 */     StringMap map = this.localMap.get();
/* 225 */     return (map == null) ? EMPTY_CONTEXT_DATA : map;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImmutableMapOrNull() {
/* 230 */     StringMap map = this.localMap.get();
/* 231 */     return (map == null) ? null : Collections.<String, String>unmodifiableMap(map.toMap());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 236 */     StringMap map = this.localMap.get();
/* 237 */     return (map == null || map.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     StringMap map = this.localMap.get();
/* 243 */     return (map == null) ? "{}" : map.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 248 */     int prime = 31;
/* 249 */     int result = 1;
/* 250 */     StringMap map = this.localMap.get();
/* 251 */     result = 31 * result + ((map == null) ? 0 : map.hashCode());
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 257 */     if (this == obj) {
/* 258 */       return true;
/*     */     }
/* 260 */     if (obj == null) {
/* 261 */       return false;
/*     */     }
/* 263 */     if (!(obj instanceof ThreadContextMap)) {
/* 264 */       return false;
/*     */     }
/* 266 */     ThreadContextMap other = (ThreadContextMap)obj;
/* 267 */     Map<String, String> map = getImmutableMapOrNull();
/* 268 */     Map<String, String> otherMap = other.getImmutableMapOrNull();
/* 269 */     if (map == null) {
/* 270 */       if (otherMap != null) {
/* 271 */         return false;
/*     */       }
/* 273 */     } else if (!map.equals(otherMap)) {
/* 274 */       return false;
/*     */     } 
/* 276 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\CopyOnWriteSortedArrayThreadContextMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */