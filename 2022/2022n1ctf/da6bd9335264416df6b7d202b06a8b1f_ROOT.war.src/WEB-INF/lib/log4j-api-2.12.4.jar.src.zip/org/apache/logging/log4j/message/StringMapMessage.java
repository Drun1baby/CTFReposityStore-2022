/*    */ package org.apache.logging.log4j.message;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @AsynchronouslyFormattable
/*    */ @PerformanceSensitive({"allocation"})
/*    */ public class StringMapMessage
/*    */   extends MapMessage<StringMapMessage, String>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public StringMapMessage() {}
/*    */   
/*    */   public StringMapMessage(int initialCapacity) {
/* 49 */     super(initialCapacity);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringMapMessage(Map<String, String> map) {
/* 59 */     super(map);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringMapMessage newInstance(Map<String, String> map) {
/* 69 */     return new StringMapMessage(map);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\message\StringMapMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */