/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackLocator
/*     */ {
/*     */   static final int JDK_7u25_OFFSET;
/*     */   private static final Method GET_CALLER_CLASS;
/*     */   private static final StackLocator INSTANCE;
/*     */   
/*     */   static {
/*     */     Method getCallerClass;
/*  60 */     int java7u25CompensationOffset = 0;
/*     */     try {
/*  62 */       Class<?> sunReflectionClass = LoaderUtil.loadClass("sun.reflect.Reflection");
/*  63 */       getCallerClass = sunReflectionClass.getDeclaredMethod("getCallerClass", new Class[] { int.class });
/*  64 */       Object o = getCallerClass.invoke(null, new Object[] { Integer.valueOf(0) });
/*  65 */       getCallerClass.invoke(null, new Object[] { Integer.valueOf(0) });
/*  66 */       if (o == null || o != sunReflectionClass) {
/*  67 */         getCallerClass = null;
/*  68 */         java7u25CompensationOffset = -1;
/*     */       } else {
/*  70 */         o = getCallerClass.invoke(null, new Object[] { Integer.valueOf(1) });
/*  71 */         if (o == sunReflectionClass) {
/*  72 */           System.out.println("WARNING: Java 1.7.0_25 is in use which has a broken implementation of Reflection.getCallerClass().  Please consider upgrading to Java 1.7.0_40 or later.");
/*     */           
/*  74 */           java7u25CompensationOffset = 1;
/*     */         } 
/*     */       } 
/*  77 */     } catch (Exception|LinkageError e) {
/*  78 */       System.out.println("WARNING: sun.reflect.Reflection.getCallerClass is not supported. This will impact performance.");
/*  79 */       getCallerClass = null;
/*  80 */       java7u25CompensationOffset = -1;
/*     */     } 
/*     */     
/*  83 */     GET_CALLER_CLASS = getCallerClass;
/*  84 */     JDK_7u25_OFFSET = java7u25CompensationOffset;
/*     */     
/*  86 */     INSTANCE = new StackLocator();
/*     */   }
/*     */   
/*     */   public static StackLocator getInstance() {
/*  90 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(int depth) {
/* 102 */     if (depth < 0) {
/* 103 */       throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 108 */       return (Class)GET_CALLER_CLASS.invoke(null, new Object[] { Integer.valueOf(depth + 1 + JDK_7u25_OFFSET) });
/* 109 */     } catch (Exception e) {
/*     */ 
/*     */       
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(String fqcn, String pkg) {
/* 119 */     boolean next = false;
/*     */     Class<?> clazz;
/* 121 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 122 */       if (fqcn.equals(clazz.getName())) {
/* 123 */         next = true;
/*     */       
/*     */       }
/* 126 */       else if (next && clazz.getName().startsWith(pkg)) {
/* 127 */         return clazz;
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(Class<?> anchor) {
/* 137 */     boolean next = false;
/*     */     Class<?> clazz;
/* 139 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 140 */       if (anchor.equals(clazz)) {
/* 141 */         next = true;
/*     */       
/*     */       }
/* 144 */       else if (next) {
/* 145 */         return clazz;
/*     */       } 
/*     */     } 
/* 148 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Stack<Class<?>> getCurrentStackTrace() {
/* 155 */     if (PrivateSecurityManagerStackTraceUtil.isEnabled()) {
/* 156 */       return PrivateSecurityManagerStackTraceUtil.getCurrentStackTrace();
/*     */     }
/*     */     
/* 159 */     Stack<Class<?>> classes = new Stack<>();
/*     */     Class<?> clazz;
/* 161 */     for (int i = 1; null != (clazz = getCallerClass(i)); i++) {
/* 162 */       classes.push(clazz);
/*     */     }
/* 164 */     return classes;
/*     */   }
/*     */   
/*     */   public StackTraceElement calcLocation(String fqcnOfLogger) {
/* 168 */     if (fqcnOfLogger == null) {
/* 169 */       return null;
/*     */     }
/*     */     
/* 172 */     StackTraceElement[] stackTrace = (new Throwable()).getStackTrace();
/* 173 */     boolean found = false;
/* 174 */     for (int i = 0; i < stackTrace.length; i++) {
/* 175 */       String className = stackTrace[i].getClassName();
/* 176 */       if (fqcnOfLogger.equals(className)) {
/*     */         
/* 178 */         found = true;
/*     */       
/*     */       }
/* 181 */       else if (found && !fqcnOfLogger.equals(className)) {
/* 182 */         return stackTrace[i];
/*     */       } 
/*     */     } 
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StackTraceElement getStackTraceElement(int depth) {
/* 191 */     StackTraceElement[] elements = (new Throwable()).getStackTrace();
/* 192 */     int i = 0;
/* 193 */     for (StackTraceElement element : elements) {
/* 194 */       if (isValid(element)) {
/* 195 */         if (i == depth) {
/* 196 */           return element;
/*     */         }
/* 198 */         i++;
/*     */       } 
/*     */     } 
/* 201 */     throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isValid(StackTraceElement element) {
/* 206 */     if (element.isNativeMethod()) {
/* 207 */       return false;
/*     */     }
/* 209 */     String cn = element.getClassName();
/*     */     
/* 211 */     if (cn.startsWith("sun.reflect.")) {
/* 212 */       return false;
/*     */     }
/* 214 */     String mn = element.getMethodName();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 219 */     if (cn.startsWith("java.lang.reflect.") && (mn.equals("invoke") || mn.equals("newInstance"))) {
/* 220 */       return false;
/*     */     }
/*     */     
/* 223 */     if (cn.startsWith("jdk.internal.reflect.")) {
/* 224 */       return false;
/*     */     }
/*     */     
/* 227 */     if (cn.equals("java.lang.Class") && mn.equals("newInstance")) {
/* 228 */       return false;
/*     */     }
/*     */     
/* 231 */     if (cn.equals("java.lang.invoke.MethodHandle") && mn.startsWith("invoke")) {
/* 232 */       return false;
/*     */     }
/*     */     
/* 235 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\StackLocator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */