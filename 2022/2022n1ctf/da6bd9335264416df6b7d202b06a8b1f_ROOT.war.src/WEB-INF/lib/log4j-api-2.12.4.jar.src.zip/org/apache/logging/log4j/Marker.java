package org.apache.logging.log4j;

import java.io.Serializable;

public interface Marker extends Serializable {
  Marker addParents(Marker... paramVarArgs);
  
  boolean equals(Object paramObject);
  
  String getName();
  
  Marker[] getParents();
  
  int hashCode();
  
  boolean hasParents();
  
  boolean isInstanceOf(Marker paramMarker);
  
  boolean isInstanceOf(String paramString);
  
  boolean remove(Marker paramMarker);
  
  Marker setParents(Marker... paramVarArgs);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\Marker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */