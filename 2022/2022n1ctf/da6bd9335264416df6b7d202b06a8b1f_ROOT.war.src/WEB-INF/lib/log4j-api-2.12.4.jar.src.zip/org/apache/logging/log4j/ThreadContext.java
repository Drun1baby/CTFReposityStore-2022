/*     */ package org.apache.logging.log4j;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*     */ import org.apache.logging.log4j.spi.CleanableThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.DefaultThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.DefaultThreadContextStack;
/*     */ import org.apache.logging.log4j.spi.NoOpThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.ReadOnlyThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMap;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMap2;
/*     */ import org.apache.logging.log4j.spi.ThreadContextMapFactory;
/*     */ import org.apache.logging.log4j.spi.ThreadContextStack;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThreadContext
/*     */ {
/*     */   private static class EmptyThreadContextStack
/*     */     extends AbstractCollection<String>
/*     */     implements ThreadContextStack
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private EmptyThreadContextStack() {}
/*     */     
/*  58 */     private static final Iterator<String> EMPTY_ITERATOR = new ThreadContext.EmptyIterator<>();
/*     */ 
/*     */     
/*     */     public String pop() {
/*  62 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String peek() {
/*  67 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void push(String message) {
/*  72 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getDepth() {
/*  77 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> asList() {
/*  82 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void trim(int depth) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*  93 */       return (o instanceof Collection && ((Collection)o).isEmpty());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  99 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public ThreadContext.ContextStack copy() {
/* 104 */       return (ThreadContext.ContextStack)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] a) {
/* 109 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(String e) {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> c) {
/* 119 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends String> c) {
/* 124 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> c) {
/* 129 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> c) {
/* 134 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<String> iterator() {
/* 139 */       return EMPTY_ITERATOR;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 144 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public ThreadContext.ContextStack getImmutableStackOrNull() {
/* 149 */       return (ThreadContext.ContextStack)this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EmptyIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private EmptyIterator() {}
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 162 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 167 */       throw new NoSuchElementException("This is an empty iterator!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public static final Map<String, String> EMPTY_MAP = Collections.emptyMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public static final ThreadContextStack EMPTY_STACK = new EmptyThreadContextStack();
/*     */   
/*     */   private static final String DISABLE_MAP = "disableThreadContextMap";
/*     */   
/*     */   private static final String DISABLE_STACK = "disableThreadContextStack";
/*     */   private static final String DISABLE_ALL = "disableThreadContext";
/*     */   private static boolean disableAll;
/*     */   private static boolean useMap;
/*     */   private static boolean useStack;
/*     */   private static ThreadContextMap contextMap;
/*     */   private static ThreadContextStack contextStack;
/*     */   private static ReadOnlyThreadContextMap readOnlyContextMap;
/*     */   
/*     */   static {
/* 203 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void init() {
/* 214 */     ThreadContextMapFactory.init();
/* 215 */     contextMap = null;
/* 216 */     PropertiesUtil managerProps = PropertiesUtil.getProperties();
/* 217 */     disableAll = managerProps.getBooleanProperty("disableThreadContext");
/* 218 */     useStack = (!managerProps.getBooleanProperty("disableThreadContextStack") && !disableAll);
/* 219 */     useMap = (!managerProps.getBooleanProperty("disableThreadContextMap") && !disableAll);
/*     */     
/* 221 */     contextStack = (ThreadContextStack)new DefaultThreadContextStack(useStack);
/* 222 */     if (!useMap) {
/* 223 */       contextMap = (ThreadContextMap)new NoOpThreadContextMap();
/*     */     } else {
/* 225 */       contextMap = ThreadContextMapFactory.createThreadContextMap();
/*     */     } 
/* 227 */     if (contextMap instanceof ReadOnlyThreadContextMap) {
/* 228 */       readOnlyContextMap = (ReadOnlyThreadContextMap)contextMap;
/*     */     } else {
/* 230 */       readOnlyContextMap = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void put(String key, String value) {
/* 246 */     contextMap.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void putAll(Map<String, String> m) {
/* 259 */     if (contextMap instanceof ThreadContextMap2) {
/* 260 */       ((ThreadContextMap2)contextMap).putAll(m);
/* 261 */     } else if (contextMap instanceof DefaultThreadContextMap) {
/* 262 */       ((DefaultThreadContextMap)contextMap).putAll(m);
/*     */     } else {
/* 264 */       for (Map.Entry<String, String> entry : m.entrySet()) {
/* 265 */         contextMap.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String key) {
/* 281 */     return contextMap.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String key) {
/* 290 */     contextMap.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeAll(Iterable<String> keys) {
/* 301 */     if (contextMap instanceof CleanableThreadContextMap) {
/* 302 */       ((CleanableThreadContextMap)contextMap).removeAll(keys);
/* 303 */     } else if (contextMap instanceof DefaultThreadContextMap) {
/* 304 */       ((DefaultThreadContextMap)contextMap).removeAll(keys);
/*     */     } else {
/* 306 */       for (String key : keys) {
/* 307 */         contextMap.remove(key);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearMap() {
/* 316 */     contextMap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearAll() {
/* 323 */     clearMap();
/* 324 */     clearStack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containsKey(String key) {
/* 334 */     return contextMap.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getContext() {
/* 343 */     return contextMap.getCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getImmutableContext() {
/* 352 */     Map<String, String> map = contextMap.getImmutableMapOrNull();
/* 353 */     return (map == null) ? EMPTY_MAP : map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyThreadContextMap getThreadContextMap() {
/* 373 */     return readOnlyContextMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty() {
/* 382 */     return contextMap.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearStack() {
/* 389 */     contextStack.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextStack cloneStack() {
/* 398 */     return contextStack.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContextStack getImmutableStack() {
/* 407 */     ContextStack result = contextStack.getImmutableStackOrNull();
/* 408 */     return (result == null) ? (ContextStack)EMPTY_STACK : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStack(Collection<String> stack) {
/* 417 */     if (stack.isEmpty() || !useStack) {
/*     */       return;
/*     */     }
/* 420 */     contextStack.clear();
/* 421 */     contextStack.addAll(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDepth() {
/* 432 */     return contextStack.getDepth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String pop() {
/* 446 */     return contextStack.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String peek() {
/* 460 */     return contextStack.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(String message) {
/* 473 */     contextStack.push(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void push(String message, Object... args) {
/* 489 */     contextStack.push(ParameterizedMessage.format(message, args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeStack() {
/* 509 */     contextStack.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void trim(int depth) {
/* 545 */     contextStack.trim(depth);
/*     */   }
/*     */   
/*     */   public static interface ContextStack extends Serializable, Collection<String> {
/*     */     String pop();
/*     */     
/*     */     String peek();
/*     */     
/*     */     void push(String param1String);
/*     */     
/*     */     int getDepth();
/*     */     
/*     */     List<String> asList();
/*     */     
/*     */     void trim(int param1Int);
/*     */     
/*     */     ContextStack copy();
/*     */     
/*     */     ContextStack getImmutableStackOrNull();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\ThreadContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */