package org.apache.logging.log4j.util;

import java.io.Serializable;
import java.util.Map;

public interface ReadOnlyStringMap extends Serializable {
  Map<String, String> toMap();
  
  boolean containsKey(String paramString);
  
  <V> void forEach(BiConsumer<String, ? super V> paramBiConsumer);
  
  <V, S> void forEach(TriConsumer<String, ? super V, S> paramTriConsumer, S paramS);
  
  <V> V getValue(String paramString);
  
  boolean isEmpty();
  
  int size();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\ReadOnlyStringMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */