/*    */ package org.apache.logging.log4j.spi;
/*    */ 
/*    */ import org.apache.logging.log4j.message.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class LoggerContextKey
/*    */ {
/*    */   public static String create(String name) {
/* 32 */     return create(name, AbstractLogger.DEFAULT_MESSAGE_FACTORY_CLASS);
/*    */   }
/*    */   
/*    */   public static String create(String name, MessageFactory messageFactory) {
/* 36 */     Class<? extends MessageFactory> messageFactoryClass = (messageFactory != null) ? (Class)messageFactory.getClass() : AbstractLogger.DEFAULT_MESSAGE_FACTORY_CLASS;
/*    */     
/* 38 */     return create(name, messageFactoryClass);
/*    */   }
/*    */   
/*    */   public static String create(String name, Class<? extends MessageFactory> messageFactoryClass) {
/* 42 */     Class<? extends MessageFactory> mfClass = (messageFactoryClass != null) ? messageFactoryClass : AbstractLogger.DEFAULT_MESSAGE_FACTORY_CLASS;
/*    */     
/* 44 */     return name + "." + mfClass.getName();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\LoggerContextKey.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */