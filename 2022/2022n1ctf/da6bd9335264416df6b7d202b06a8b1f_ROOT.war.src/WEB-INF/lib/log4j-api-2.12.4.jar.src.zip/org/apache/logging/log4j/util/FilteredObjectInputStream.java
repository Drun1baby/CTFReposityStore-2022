/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilteredObjectInputStream
/*    */   extends ObjectInputStream
/*    */ {
/* 36 */   private static final List<String> REQUIRED_JAVA_CLASSES = Arrays.asList(new String[] { "java.math.BigDecimal", "java.math.BigInteger", "java.rmi.MarshalledObject", "[B" });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   private static final List<String> REQUIRED_JAVA_PACKAGES = Arrays.asList(new String[] { "java.lang.", "java.time", "java.util.", "org.apache.logging.log4j.", "[Lorg.apache.logging.log4j." });
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final Collection<String> allowedClasses;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilteredObjectInputStream() throws IOException, SecurityException {
/* 56 */     this.allowedClasses = new HashSet<>();
/*    */   }
/*    */   
/*    */   public FilteredObjectInputStream(InputStream in) throws IOException {
/* 60 */     super(in);
/* 61 */     this.allowedClasses = new HashSet<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public FilteredObjectInputStream(Collection<String> allowedClasses) throws IOException, SecurityException {
/* 66 */     this.allowedClasses = allowedClasses;
/*    */   }
/*    */   
/*    */   public FilteredObjectInputStream(InputStream in, Collection<String> allowedClasses) throws IOException {
/* 70 */     super(in);
/* 71 */     this.allowedClasses = allowedClasses;
/*    */   }
/*    */   
/*    */   public Collection<String> getAllowedClasses() {
/* 75 */     return this.allowedClasses;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
/* 80 */     String name = desc.getName();
/* 81 */     if (!isAllowedByDefault(name) && !this.allowedClasses.contains(name)) {
/* 82 */       throw new InvalidObjectException("Class is not allowed for deserialization: " + name);
/*    */     }
/* 84 */     return super.resolveClass(desc);
/*    */   }
/*    */   
/*    */   private static boolean isAllowedByDefault(String name) {
/* 88 */     return (isRequiredPackage(name) || REQUIRED_JAVA_CLASSES.contains(name));
/*    */   }
/*    */   
/*    */   private static boolean isRequiredPackage(String name) {
/* 92 */     for (String packageName : REQUIRED_JAVA_PACKAGES) {
/* 93 */       if (name.startsWith(packageName)) {
/* 94 */         return true;
/*    */       }
/*    */     } 
/* 97 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\FilteredObjectInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */