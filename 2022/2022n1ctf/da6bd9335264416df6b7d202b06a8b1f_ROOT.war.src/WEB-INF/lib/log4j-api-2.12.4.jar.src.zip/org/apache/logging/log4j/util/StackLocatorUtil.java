/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Stack;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StackLocatorUtil
/*    */ {
/* 28 */   private static StackLocator stackLocator = null;
/*    */   private static volatile boolean errorLogged = false;
/*    */   
/*    */   static {
/* 32 */     stackLocator = StackLocator.getInstance();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(int depth) {
/* 44 */     return stackLocator.getCallerClass(depth + 1);
/*    */   }
/*    */   
/*    */   public static StackTraceElement getStackTraceElement(int depth) {
/* 48 */     return stackLocator.getStackTraceElement(depth + 1);
/*    */   }
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(String fqcn) {
/* 53 */     return getCallerClass(fqcn, "");
/*    */   }
/*    */ 
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(String fqcn, String pkg) {
/* 59 */     return stackLocator.getCallerClass(fqcn, pkg);
/*    */   }
/*    */ 
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(Class<?> anchor) {
/* 65 */     return stackLocator.getCallerClass(anchor);
/*    */   }
/*    */ 
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Stack<Class<?>> getCurrentStackTrace() {
/* 71 */     return stackLocator.getCurrentStackTrace();
/*    */   }
/*    */   
/*    */   public static StackTraceElement calcLocation(String fqcnOfLogger) {
/*    */     try {
/* 76 */       return stackLocator.calcLocation(fqcnOfLogger);
/* 77 */     } catch (NoSuchElementException ex) {
/* 78 */       if (!errorLogged) {
/* 79 */         errorLogged = true;
/* 80 */         StatusLogger.getLogger().warn("Unable to locate stack trace element for {}", fqcnOfLogger, ex);
/*    */       } 
/* 82 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\StackLocatorUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */