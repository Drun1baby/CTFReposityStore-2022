/*     */ package org.apache.logging.log4j.message;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.apache.logging.log4j.util.Constants;
/*     */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*     */ import org.apache.logging.log4j.util.StringBuilders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PerformanceSensitive({"allocation"})
/*     */ public class ReusableParameterizedMessage
/*     */   implements ReusableMessage, ParameterVisitable, Clearable
/*     */ {
/*     */   private static final int MIN_BUILDER_SIZE = 512;
/*     */   private static final int MAX_PARMS = 10;
/*     */   private static final long serialVersionUID = 7800075879295123856L;
/*     */   private transient ThreadLocal<StringBuilder> buffer;
/*     */   private String messagePattern;
/*     */   private int argCount;
/*     */   private int usedCount;
/*  43 */   private final int[] indices = new int[256];
/*     */   private transient Object[] varargs;
/*  45 */   private transient Object[] params = new Object[10];
/*     */ 
/*     */   
/*     */   private transient Throwable throwable;
/*     */ 
/*     */   
/*     */   transient boolean reserved = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] getTrimmedParams() {
/*  56 */     return (this.varargs == null) ? Arrays.<Object>copyOf(this.params, this.argCount) : this.varargs;
/*     */   }
/*     */   
/*     */   private Object[] getParams() {
/*  60 */     return (this.varargs == null) ? this.params : this.varargs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] swapParameters(Object[] emptyReplacement) {
/*     */     Object[] result;
/*  67 */     if (this.varargs == null) {
/*  68 */       result = this.params;
/*  69 */       if (emptyReplacement.length >= 10) {
/*  70 */         this.params = emptyReplacement;
/*     */       
/*     */       }
/*  73 */       else if (this.argCount <= emptyReplacement.length) {
/*     */         
/*  75 */         System.arraycopy(this.params, 0, emptyReplacement, 0, this.argCount);
/*     */         
/*  77 */         for (int i = 0; i < this.argCount; i++) {
/*  78 */           this.params[i] = null;
/*     */         }
/*  80 */         result = emptyReplacement;
/*     */       } else {
/*     */         
/*  83 */         this.params = new Object[10];
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  94 */       if (this.argCount <= emptyReplacement.length) {
/*  95 */         result = emptyReplacement;
/*     */       } else {
/*  97 */         result = new Object[this.argCount];
/*     */       } 
/*     */       
/* 100 */       System.arraycopy(this.varargs, 0, result, 0, this.argCount);
/*     */     } 
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public short getParameterCount() {
/* 108 */     return (short)this.argCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S> void forEachParameter(ParameterConsumer<S> action, S state) {
/* 113 */     Object[] parameters = getParams(); short i;
/* 114 */     for (i = 0; i < this.argCount; i = (short)(i + 1)) {
/* 115 */       action.accept(parameters[i], i, state);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Message memento() {
/* 121 */     return new ParameterizedMessage(this.messagePattern, getTrimmedParams());
/*     */   }
/*     */   
/*     */   private void init(String messagePattern, int argCount, Object[] paramArray) {
/* 125 */     this.varargs = null;
/* 126 */     this.messagePattern = messagePattern;
/* 127 */     this.argCount = argCount;
/* 128 */     int placeholderCount = count(messagePattern, this.indices);
/* 129 */     initThrowable(paramArray, argCount, placeholderCount);
/* 130 */     this.usedCount = Math.min(placeholderCount, argCount);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int count(String messagePattern, int[] indices) {
/*     */     try {
/* 136 */       return ParameterFormatter.countArgumentPlaceholders2(messagePattern, indices);
/* 137 */     } catch (Exception ex) {
/* 138 */       return ParameterFormatter.countArgumentPlaceholders(messagePattern);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initThrowable(Object[] params, int argCount, int usedParams) {
/* 143 */     if (usedParams < argCount && params[argCount - 1] instanceof Throwable) {
/* 144 */       this.throwable = (Throwable)params[argCount - 1];
/*     */     } else {
/* 146 */       this.throwable = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object... arguments) {
/* 151 */     init(messagePattern, (arguments == null) ? 0 : arguments.length, arguments);
/* 152 */     this.varargs = arguments;
/* 153 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0) {
/* 157 */     this.params[0] = p0;
/* 158 */     init(messagePattern, 1, this.params);
/* 159 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1) {
/* 163 */     this.params[0] = p0;
/* 164 */     this.params[1] = p1;
/* 165 */     init(messagePattern, 2, this.params);
/* 166 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2) {
/* 170 */     this.params[0] = p0;
/* 171 */     this.params[1] = p1;
/* 172 */     this.params[2] = p2;
/* 173 */     init(messagePattern, 3, this.params);
/* 174 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3) {
/* 178 */     this.params[0] = p0;
/* 179 */     this.params[1] = p1;
/* 180 */     this.params[2] = p2;
/* 181 */     this.params[3] = p3;
/* 182 */     init(messagePattern, 4, this.params);
/* 183 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 187 */     this.params[0] = p0;
/* 188 */     this.params[1] = p1;
/* 189 */     this.params[2] = p2;
/* 190 */     this.params[3] = p3;
/* 191 */     this.params[4] = p4;
/* 192 */     init(messagePattern, 5, this.params);
/* 193 */     return this;
/*     */   }
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 197 */     this.params[0] = p0;
/* 198 */     this.params[1] = p1;
/* 199 */     this.params[2] = p2;
/* 200 */     this.params[3] = p3;
/* 201 */     this.params[4] = p4;
/* 202 */     this.params[5] = p5;
/* 203 */     init(messagePattern, 6, this.params);
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 209 */     this.params[0] = p0;
/* 210 */     this.params[1] = p1;
/* 211 */     this.params[2] = p2;
/* 212 */     this.params[3] = p3;
/* 213 */     this.params[4] = p4;
/* 214 */     this.params[5] = p5;
/* 215 */     this.params[6] = p6;
/* 216 */     init(messagePattern, 7, this.params);
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 222 */     this.params[0] = p0;
/* 223 */     this.params[1] = p1;
/* 224 */     this.params[2] = p2;
/* 225 */     this.params[3] = p3;
/* 226 */     this.params[4] = p4;
/* 227 */     this.params[5] = p5;
/* 228 */     this.params[6] = p6;
/* 229 */     this.params[7] = p7;
/* 230 */     init(messagePattern, 8, this.params);
/* 231 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 236 */     this.params[0] = p0;
/* 237 */     this.params[1] = p1;
/* 238 */     this.params[2] = p2;
/* 239 */     this.params[3] = p3;
/* 240 */     this.params[4] = p4;
/* 241 */     this.params[5] = p5;
/* 242 */     this.params[6] = p6;
/* 243 */     this.params[7] = p7;
/* 244 */     this.params[8] = p8;
/* 245 */     init(messagePattern, 9, this.params);
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage set(String messagePattern, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 251 */     this.params[0] = p0;
/* 252 */     this.params[1] = p1;
/* 253 */     this.params[2] = p2;
/* 254 */     this.params[3] = p3;
/* 255 */     this.params[4] = p4;
/* 256 */     this.params[5] = p5;
/* 257 */     this.params[6] = p6;
/* 258 */     this.params[7] = p7;
/* 259 */     this.params[8] = p8;
/* 260 */     this.params[9] = p9;
/* 261 */     init(messagePattern, 10, this.params);
/* 262 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 271 */     return this.messagePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters() {
/* 280 */     return getTrimmedParams();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable() {
/* 294 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 303 */     StringBuilder sb = getBuffer();
/* 304 */     formatTo(sb);
/* 305 */     String result = sb.toString();
/* 306 */     StringBuilders.trimToMaxSize(sb, Constants.MAX_REUSABLE_MESSAGE_SIZE);
/* 307 */     return result;
/*     */   }
/*     */   
/*     */   private StringBuilder getBuffer() {
/* 311 */     if (this.buffer == null) {
/* 312 */       this.buffer = new ThreadLocal<>();
/*     */     }
/* 314 */     StringBuilder result = this.buffer.get();
/* 315 */     if (result == null) {
/* 316 */       int currentPatternLength = (this.messagePattern == null) ? 0 : this.messagePattern.length();
/* 317 */       result = new StringBuilder(Math.max(512, currentPatternLength * 2));
/* 318 */       this.buffer.set(result);
/*     */     } 
/* 320 */     result.setLength(0);
/* 321 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void formatTo(StringBuilder builder) {
/* 326 */     if (this.indices[0] < 0) {
/* 327 */       ParameterFormatter.formatMessage(builder, this.messagePattern, getParams(), this.argCount);
/*     */     } else {
/* 329 */       ParameterFormatter.formatMessage2(builder, this.messagePattern, getParams(), this.usedCount, this.indices);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReusableParameterizedMessage reserve() {
/* 339 */     this.reserved = true;
/* 340 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 345 */     return "ReusableParameterizedMessage[messagePattern=" + getFormat() + ", stringArgs=" + 
/* 346 */       Arrays.toString(getParameters()) + ", throwable=" + getThrowable() + ']';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 353 */     this.reserved = false;
/* 354 */     this.varargs = null;
/* 355 */     this.messagePattern = null;
/* 356 */     this.throwable = null;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\message\ReusableParameterizedMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */