/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Constants
/*     */ {
/*  30 */   public static final boolean IS_WEB_APP = PropertiesUtil.getProperties().getBooleanProperty("log4j2.is.webapp", 
/*  31 */       isClassAvailable("javax.servlet.Servlet"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static final boolean ENABLE_THREADLOCALS = (!IS_WEB_APP && PropertiesUtil.getProperties().getBooleanProperty("log4j2.enable.threadlocals", true));
/*     */ 
/*     */   
/*  43 */   public static final int JAVA_MAJOR_VERSION = getMajorVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final int MAX_REUSABLE_MESSAGE_SIZE = size("log4j.maxReusableMsgSize", 518);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOG4J2_DEBUG = "log4j2.debug";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int size(String property, int defaultValue) {
/*  68 */     return PropertiesUtil.getProperties().getIntegerProperty(property, defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isClassAvailable(String className) {
/*     */     try {
/*  79 */       return (LoaderUtil.loadClass(className) != null);
/*  80 */     } catch (Throwable e) {
/*  81 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getMajorVersion() {
/*  92 */     return getMajorVersion(System.getProperty("java.version"));
/*     */   }
/*     */   
/*     */   static int getMajorVersion(String version) {
/*  96 */     String[] parts = version.split("-|\\.");
/*     */     
/*     */     try {
/*  99 */       int token = Integer.parseInt(parts[0]);
/* 100 */       boolean isJEP223 = (token != 1);
/* 101 */       if (isJEP223) {
/* 102 */         return token;
/*     */       }
/* 104 */       return Integer.parseInt(parts[1]);
/* 105 */     } catch (Exception ex) {
/* 106 */       return 0;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\Constants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */