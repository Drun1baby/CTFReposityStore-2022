package org.apache.logging.log4j.spi;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.message.Message;

public interface LocationAwareLogger {
  void logMessage(Level paramLevel, Marker paramMarker, String paramString, StackTraceElement paramStackTraceElement, Message paramMessage, Throwable paramThrowable);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\LocationAwareLogger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */