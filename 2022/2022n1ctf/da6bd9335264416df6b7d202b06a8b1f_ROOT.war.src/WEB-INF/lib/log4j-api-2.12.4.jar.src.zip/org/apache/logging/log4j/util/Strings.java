/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Strings
/*     */ {
/*     */   public static final String EMPTY = "";
/*  39 */   public static final String LINE_SEPARATOR = PropertiesUtil.getProperties().getStringProperty("line.separator", "\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String dquote(String str) {
/*  49 */     return '"' + str + '"';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBlank(String s) {
/*  60 */     return (s == null || s.trim().isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(CharSequence cs) {
/*  89 */     return (cs == null || cs.length() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotBlank(String s) {
/*  99 */     return !isBlank(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(CharSequence cs) {
/* 123 */     return !isEmpty(cs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Iterable<?> iterable, char separator) {
/* 138 */     if (iterable == null) {
/* 139 */       return null;
/*     */     }
/* 141 */     return join(iterable.iterator(), separator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String join(Iterator<?> iterator, char separator) {
/* 158 */     if (iterator == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     if (!iterator.hasNext()) {
/* 162 */       return "";
/*     */     }
/* 164 */     Object first = iterator.next();
/* 165 */     if (!iterator.hasNext()) {
/* 166 */       return Objects.toString(first, "");
/*     */     }
/*     */ 
/*     */     
/* 170 */     StringBuilder buf = new StringBuilder(256);
/* 171 */     if (first != null) {
/* 172 */       buf.append(first);
/*     */     }
/*     */     
/* 175 */     while (iterator.hasNext()) {
/* 176 */       buf.append(separator);
/* 177 */       Object obj = iterator.next();
/* 178 */       if (obj != null) {
/* 179 */         buf.append(obj);
/*     */       }
/*     */     } 
/*     */     
/* 183 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String left(String str, int len) {
/* 211 */     if (str == null) {
/* 212 */       return null;
/*     */     }
/* 214 */     if (len < 0) {
/* 215 */       return "";
/*     */     }
/* 217 */     if (str.length() <= len) {
/* 218 */       return str;
/*     */     }
/* 220 */     return str.substring(0, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String str) {
/* 230 */     return '\'' + str + '\'';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String trimToNull(String str) {
/* 258 */     String ts = (str == null) ? null : str.trim();
/* 259 */     return isEmpty(ts) ? null : ts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toRootUpperCase(String str) {
/* 273 */     return str.toUpperCase(Locale.ROOT);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4\\util\Strings.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */