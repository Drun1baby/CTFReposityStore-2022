/*      */ package org.apache.logging.log4j.spi;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import org.apache.logging.log4j.Level;
/*      */ import org.apache.logging.log4j.LoggingException;
/*      */ import org.apache.logging.log4j.Marker;
/*      */ import org.apache.logging.log4j.MarkerManager;
/*      */ import org.apache.logging.log4j.message.DefaultFlowMessageFactory;
/*      */ import org.apache.logging.log4j.message.EntryMessage;
/*      */ import org.apache.logging.log4j.message.FlowMessageFactory;
/*      */ import org.apache.logging.log4j.message.Message;
/*      */ import org.apache.logging.log4j.message.MessageFactory;
/*      */ import org.apache.logging.log4j.message.MessageFactory2;
/*      */ import org.apache.logging.log4j.message.ParameterizedMessage;
/*      */ import org.apache.logging.log4j.message.ParameterizedMessageFactory;
/*      */ import org.apache.logging.log4j.message.ReusableMessageFactory;
/*      */ import org.apache.logging.log4j.message.SimpleMessage;
/*      */ import org.apache.logging.log4j.message.StringFormattedMessage;
/*      */ import org.apache.logging.log4j.status.StatusLogger;
/*      */ import org.apache.logging.log4j.util.Constants;
/*      */ import org.apache.logging.log4j.util.LambdaUtil;
/*      */ import org.apache.logging.log4j.util.LoaderUtil;
/*      */ import org.apache.logging.log4j.util.MessageSupplier;
/*      */ import org.apache.logging.log4j.util.PerformanceSensitive;
/*      */ import org.apache.logging.log4j.util.PropertiesUtil;
/*      */ import org.apache.logging.log4j.util.StackLocatorUtil;
/*      */ import org.apache.logging.log4j.util.Strings;
/*      */ import org.apache.logging.log4j.util.Supplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractLogger
/*      */   implements ExtendedLogger, LocationAwareLogger, Serializable
/*      */ {
/*   59 */   public static final Marker FLOW_MARKER = MarkerManager.getMarker("FLOW");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   64 */   public static final Marker ENTRY_MARKER = MarkerManager.getMarker("ENTER").setParents(new Marker[] { FLOW_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   public static final Marker EXIT_MARKER = MarkerManager.getMarker("EXIT").setParents(new Marker[] { FLOW_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   public static final Marker EXCEPTION_MARKER = MarkerManager.getMarker("EXCEPTION");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   79 */   public static final Marker THROWING_MARKER = MarkerManager.getMarker("THROWING").setParents(new Marker[] { EXCEPTION_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   84 */   public static final Marker CATCHING_MARKER = MarkerManager.getMarker("CATCHING").setParents(new Marker[] { EXCEPTION_MARKER });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   public static final Class<? extends MessageFactory> DEFAULT_MESSAGE_FACTORY_CLASS = createClassForProperty("log4j2.messageFactory", ReusableMessageFactory.class, ParameterizedMessageFactory.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   public static final Class<? extends FlowMessageFactory> DEFAULT_FLOW_MESSAGE_FACTORY_CLASS = createFlowClassForProperty("log4j2.flowMessageFactory", DefaultFlowMessageFactory.class);
/*      */   
/*      */   private static final long serialVersionUID = 2L;
/*      */   
/*  101 */   private static final String FQCN = AbstractLogger.class.getName();
/*      */   
/*      */   private static final String THROWING = "Throwing";
/*      */   private static final String CATCHING = "Catching";
/*      */   protected final String name;
/*      */   private final MessageFactory2 messageFactory;
/*      */   private final FlowMessageFactory flowMessageFactory;
/*  108 */   private static ThreadLocal<int[]> recursionDepthHolder = (ThreadLocal)new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger() {
/*  114 */     this.name = getClass().getName();
/*  115 */     this.messageFactory = createDefaultMessageFactory();
/*  116 */     this.flowMessageFactory = createDefaultFlowMessageFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger(String name) {
/*  125 */     this(name, (MessageFactory)createDefaultMessageFactory());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractLogger(String name, MessageFactory messageFactory) {
/*  135 */     this.name = name;
/*  136 */     this.messageFactory = (messageFactory == null) ? createDefaultMessageFactory() : narrow(messageFactory);
/*  137 */     this.flowMessageFactory = createDefaultFlowMessageFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkMessageFactory(ExtendedLogger logger, MessageFactory messageFactory) {
/*  149 */     String name = logger.getName();
/*  150 */     MessageFactory loggerMessageFactory = logger.getMessageFactory();
/*  151 */     if (messageFactory != null && !loggerMessageFactory.equals(messageFactory)) {
/*  152 */       StatusLogger.getLogger().warn("The Logger {} was created with the message factory {} and is now requested with the message factory {}, which may create log events with unexpected formatting.", name, loggerMessageFactory, messageFactory);
/*      */ 
/*      */     
/*      */     }
/*  156 */     else if (messageFactory == null && !loggerMessageFactory.getClass().equals(DEFAULT_MESSAGE_FACTORY_CLASS)) {
/*      */       
/*  158 */       StatusLogger.getLogger()
/*  159 */         .warn("The Logger {} was created with the message factory {} and is now requested with a null message factory (defaults to {}), which may create log events with unexpected formatting.", name, loggerMessageFactory, DEFAULT_MESSAGE_FACTORY_CLASS
/*      */ 
/*      */           
/*  162 */           .getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void catching(Level level, Throwable t) {
/*  168 */     catching(FQCN, level, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void catching(String fqcn, Level level, Throwable t) {
/*  179 */     if (isEnabled(level, CATCHING_MARKER, (Object)null, (Throwable)null)) {
/*  180 */       logMessageSafely(fqcn, level, CATCHING_MARKER, catchingMsg(t), t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void catching(Throwable t) {
/*  186 */     if (isEnabled(Level.ERROR, CATCHING_MARKER, (Object)null, (Throwable)null)) {
/*  187 */       logMessageSafely(FQCN, Level.ERROR, CATCHING_MARKER, catchingMsg(t), t);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Message catchingMsg(Throwable t) {
/*  192 */     return this.messageFactory.newMessage("Catching");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class<? extends MessageFactory> createClassForProperty(String property, Class<ReusableMessageFactory> reusableParameterizedMessageFactoryClass, Class<ParameterizedMessageFactory> parameterizedMessageFactoryClass) {
/*      */     try {
/*  200 */       String fallback = Constants.ENABLE_THREADLOCALS ? reusableParameterizedMessageFactoryClass.getName() : parameterizedMessageFactoryClass.getName();
/*  201 */       String clsName = PropertiesUtil.getProperties().getStringProperty(property, fallback);
/*  202 */       return LoaderUtil.loadClass(clsName).asSubclass(MessageFactory.class);
/*  203 */     } catch (Throwable t) {
/*  204 */       return (Class)parameterizedMessageFactoryClass;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static Class<? extends FlowMessageFactory> createFlowClassForProperty(String property, Class<DefaultFlowMessageFactory> defaultFlowMessageFactoryClass) {
/*      */     try {
/*  211 */       String clsName = PropertiesUtil.getProperties().getStringProperty(property, defaultFlowMessageFactoryClass.getName());
/*  212 */       return LoaderUtil.loadClass(clsName).asSubclass(FlowMessageFactory.class);
/*  213 */     } catch (Throwable t) {
/*  214 */       return (Class)defaultFlowMessageFactoryClass;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static MessageFactory2 createDefaultMessageFactory() {
/*      */     try {
/*  220 */       MessageFactory result = DEFAULT_MESSAGE_FACTORY_CLASS.newInstance();
/*  221 */       return narrow(result);
/*  222 */     } catch (InstantiationException|IllegalAccessException e) {
/*  223 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static MessageFactory2 narrow(MessageFactory result) {
/*  228 */     if (result instanceof MessageFactory2) {
/*  229 */       return (MessageFactory2)result;
/*      */     }
/*  231 */     return new MessageFactory2Adapter(result);
/*      */   }
/*      */   
/*      */   private static FlowMessageFactory createDefaultFlowMessageFactory() {
/*      */     try {
/*  236 */       return DEFAULT_FLOW_MESSAGE_FACTORY_CLASS.newInstance();
/*  237 */     } catch (InstantiationException|IllegalAccessException e) {
/*  238 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, CharSequence message) {
/*  244 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, CharSequence message, Throwable t) {
/*  249 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Message msg) {
/*  254 */     logIfEnabled(FQCN, Level.DEBUG, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Message msg, Throwable t) {
/*  259 */     logIfEnabled(FQCN, Level.DEBUG, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Object message) {
/*  264 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Object message, Throwable t) {
/*  269 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message) {
/*  274 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object... params) {
/*  279 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Throwable t) {
/*  284 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Message msg) {
/*  289 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Message msg, Throwable t) {
/*  294 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(CharSequence message) {
/*  299 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(CharSequence message, Throwable t) {
/*  304 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message) {
/*  309 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Object message, Throwable t) {
/*  314 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message) {
/*  319 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object... params) {
/*  324 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Throwable t) {
/*  329 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Supplier<?> msgSupplier) {
/*  334 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Supplier<?> msgSupplier, Throwable t) {
/*  339 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Supplier<?> msgSupplier) {
/*  344 */     logIfEnabled(FQCN, Level.DEBUG, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Supplier<?>... paramSuppliers) {
/*  349 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/*  354 */     logIfEnabled(FQCN, Level.DEBUG, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Supplier<?>... paramSuppliers) {
/*  359 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, MessageSupplier msgSupplier) {
/*  364 */     logIfEnabled(FQCN, Level.DEBUG, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/*  369 */     logIfEnabled(FQCN, Level.DEBUG, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(MessageSupplier msgSupplier) {
/*  374 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(MessageSupplier msgSupplier, Throwable t) {
/*  379 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0) {
/*  384 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1) {
/*  389 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2) {
/*  394 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/*  400 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  406 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  412 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  419 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  426 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  433 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  440 */     logIfEnabled(FQCN, Level.DEBUG, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0) {
/*  445 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1) {
/*  450 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2) {
/*  455 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3) {
/*  460 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  466 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  472 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  478 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  485 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  492 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  499 */     logIfEnabled(FQCN, Level.DEBUG, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, String format, Supplier<?>... paramSuppliers) {
/*  510 */     EntryMessage entryMsg = null;
/*  511 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  512 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(entryMsg = entryMsg(format, paramSuppliers)), (Throwable)null);
/*      */     }
/*  514 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected EntryMessage enter(String fqcn, String format, MessageSupplier... paramSuppliers) {
/*  526 */     EntryMessage entryMsg = null;
/*  527 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  528 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(entryMsg = entryMsg(format, paramSuppliers)), (Throwable)null);
/*      */     }
/*  530 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, String format, Object... params) {
/*  541 */     EntryMessage entryMsg = null;
/*  542 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  543 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(entryMsg = entryMsg(format, params)), (Throwable)null);
/*      */     }
/*  545 */     return entryMsg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected EntryMessage enter(String fqcn, MessageSupplier msgSupplier) {
/*  556 */     EntryMessage message = null;
/*  557 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  558 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(message = this.flowMessageFactory.newEntryMessage(msgSupplier
/*  559 */             .get())), (Throwable)null);
/*      */     }
/*  561 */     return message;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EntryMessage enter(String fqcn, Message message) {
/*  574 */     EntryMessage flowMessage = null;
/*  575 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  576 */       logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)(flowMessage = this.flowMessageFactory.newEntryMessage(message)), (Throwable)null);
/*      */     }
/*      */     
/*  579 */     return flowMessage;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void entry() {
/*  585 */     entry(FQCN, (Object[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void entry(Object... params) {
/*  590 */     entry(FQCN, params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void entry(String fqcn, Object... params) {
/*  600 */     if (isEnabled(Level.TRACE, ENTRY_MARKER, (Object)null, (Throwable)null)) {
/*  601 */       if (params == null) {
/*  602 */         logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)entryMsg((String)null, (Supplier<?>[])null), (Throwable)null);
/*      */       } else {
/*  604 */         logMessageSafely(fqcn, Level.TRACE, ENTRY_MARKER, (Message)entryMsg((String)null, params), (Throwable)null);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   protected EntryMessage entryMsg(String format, Object... params) {
/*  610 */     int count = (params == null) ? 0 : params.length;
/*  611 */     if (count == 0) {
/*  612 */       if (Strings.isEmpty(format)) {
/*  613 */         return this.flowMessageFactory.newEntryMessage(null);
/*      */       }
/*  615 */       return this.flowMessageFactory.newEntryMessage((Message)new SimpleMessage(format));
/*      */     } 
/*  617 */     if (format != null) {
/*  618 */       return this.flowMessageFactory.newEntryMessage((Message)new ParameterizedMessage(format, params));
/*      */     }
/*  620 */     StringBuilder sb = new StringBuilder();
/*  621 */     sb.append("params(");
/*  622 */     for (int i = 0; i < count; i++) {
/*  623 */       if (i > 0) {
/*  624 */         sb.append(", ");
/*      */       }
/*  626 */       Object parm = params[i];
/*  627 */       sb.append((parm instanceof Message) ? ((Message)parm).getFormattedMessage() : String.valueOf(parm));
/*      */     } 
/*  629 */     sb.append(')');
/*  630 */     return this.flowMessageFactory.newEntryMessage((Message)new SimpleMessage(sb));
/*      */   }
/*      */   
/*      */   protected EntryMessage entryMsg(String format, MessageSupplier... paramSuppliers) {
/*  634 */     int count = (paramSuppliers == null) ? 0 : paramSuppliers.length;
/*  635 */     Object[] params = new Object[count];
/*  636 */     for (int i = 0; i < count; i++) {
/*  637 */       params[i] = paramSuppliers[i].get();
/*  638 */       params[i] = (params[i] != null) ? ((Message)params[i]).getFormattedMessage() : null;
/*      */     } 
/*  640 */     return entryMsg(format, params);
/*      */   }
/*      */   
/*      */   protected EntryMessage entryMsg(String format, Supplier<?>... paramSuppliers) {
/*  644 */     int count = (paramSuppliers == null) ? 0 : paramSuppliers.length;
/*  645 */     Object[] params = new Object[count];
/*  646 */     for (int i = 0; i < count; i++) {
/*  647 */       params[i] = paramSuppliers[i].get();
/*  648 */       if (params[i] instanceof Message) {
/*  649 */         params[i] = ((Message)params[i]).getFormattedMessage();
/*      */       }
/*      */     } 
/*  652 */     return entryMsg(format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Message msg) {
/*  657 */     logIfEnabled(FQCN, Level.ERROR, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Message msg, Throwable t) {
/*  662 */     logIfEnabled(FQCN, Level.ERROR, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, CharSequence message) {
/*  667 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, CharSequence message, Throwable t) {
/*  672 */     logIfEnabled(FQCN, Level.ERROR, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Object message) {
/*  677 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Object message, Throwable t) {
/*  682 */     logIfEnabled(FQCN, Level.ERROR, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message) {
/*  687 */     logIfEnabled(FQCN, Level.ERROR, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object... params) {
/*  692 */     logIfEnabled(FQCN, Level.ERROR, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Throwable t) {
/*  697 */     logIfEnabled(FQCN, Level.ERROR, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Message msg) {
/*  702 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Message msg, Throwable t) {
/*  707 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(CharSequence message) {
/*  712 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(CharSequence message, Throwable t) {
/*  717 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message) {
/*  722 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Object message, Throwable t) {
/*  727 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message) {
/*  732 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object... params) {
/*  737 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Throwable t) {
/*  742 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Supplier<?> msgSupplier) {
/*  747 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Supplier<?> msgSupplier, Throwable t) {
/*  752 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Supplier<?> msgSupplier) {
/*  757 */     logIfEnabled(FQCN, Level.ERROR, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Supplier<?>... paramSuppliers) {
/*  762 */     logIfEnabled(FQCN, Level.ERROR, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/*  767 */     logIfEnabled(FQCN, Level.ERROR, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Supplier<?>... paramSuppliers) {
/*  772 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, MessageSupplier msgSupplier) {
/*  777 */     logIfEnabled(FQCN, Level.ERROR, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/*  782 */     logIfEnabled(FQCN, Level.ERROR, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(MessageSupplier msgSupplier) {
/*  787 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(MessageSupplier msgSupplier, Throwable t) {
/*  792 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0) {
/*  797 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1) {
/*  802 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2) {
/*  807 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/*  813 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  819 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  825 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  832 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  839 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  846 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  853 */     logIfEnabled(FQCN, Level.ERROR, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0) {
/*  858 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1) {
/*  863 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2) {
/*  868 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3) {
/*  873 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/*  879 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/*  885 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/*  891 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/*  897 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/*  903 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/*  909 */     logIfEnabled(FQCN, Level.ERROR, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void exit() {
/*  915 */     exit(FQCN, (Object)null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <R> R exit(R result) {
/*  921 */     return exit(FQCN, result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <R> R exit(String fqcn, R result) {
/*  933 */     if (isEnabled(Level.TRACE, EXIT_MARKER, (CharSequence)null, (Throwable)null)) {
/*  934 */       logMessageSafely(fqcn, Level.TRACE, EXIT_MARKER, exitMsg((String)null, result), (Throwable)null);
/*      */     }
/*  936 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <R> R exit(String fqcn, String format, R result) {
/*  948 */     if (isEnabled(Level.TRACE, EXIT_MARKER, (CharSequence)null, (Throwable)null)) {
/*  949 */       logMessageSafely(fqcn, Level.TRACE, EXIT_MARKER, exitMsg(format, result), (Throwable)null);
/*      */     }
/*  951 */     return result;
/*      */   }
/*      */   
/*      */   protected Message exitMsg(String format, Object result) {
/*  955 */     if (result == null) {
/*  956 */       if (format == null) {
/*  957 */         return this.messageFactory.newMessage("Exit");
/*      */       }
/*  959 */       return this.messageFactory.newMessage("Exit: " + format);
/*      */     } 
/*  961 */     if (format == null) {
/*  962 */       return this.messageFactory.newMessage("Exit with(" + result + ')');
/*      */     }
/*  964 */     return this.messageFactory.newMessage("Exit: " + format, result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Message msg) {
/*  970 */     logIfEnabled(FQCN, Level.FATAL, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Message msg, Throwable t) {
/*  975 */     logIfEnabled(FQCN, Level.FATAL, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, CharSequence message) {
/*  980 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, CharSequence message, Throwable t) {
/*  985 */     logIfEnabled(FQCN, Level.FATAL, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Object message) {
/*  990 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Object message, Throwable t) {
/*  995 */     logIfEnabled(FQCN, Level.FATAL, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message) {
/* 1000 */     logIfEnabled(FQCN, Level.FATAL, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object... params) {
/* 1005 */     logIfEnabled(FQCN, Level.FATAL, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Throwable t) {
/* 1010 */     logIfEnabled(FQCN, Level.FATAL, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Message msg) {
/* 1015 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Message msg, Throwable t) {
/* 1020 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(CharSequence message) {
/* 1025 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(CharSequence message, Throwable t) {
/* 1030 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message) {
/* 1035 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Object message, Throwable t) {
/* 1040 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message) {
/* 1045 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object... params) {
/* 1050 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Throwable t) {
/* 1055 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Supplier<?> msgSupplier) {
/* 1060 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Supplier<?> msgSupplier, Throwable t) {
/* 1065 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Supplier<?> msgSupplier) {
/* 1070 */     logIfEnabled(FQCN, Level.FATAL, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1075 */     logIfEnabled(FQCN, Level.FATAL, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 1080 */     logIfEnabled(FQCN, Level.FATAL, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Supplier<?>... paramSuppliers) {
/* 1085 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, MessageSupplier msgSupplier) {
/* 1090 */     logIfEnabled(FQCN, Level.FATAL, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 1095 */     logIfEnabled(FQCN, Level.FATAL, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(MessageSupplier msgSupplier) {
/* 1100 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(MessageSupplier msgSupplier, Throwable t) {
/* 1105 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0) {
/* 1110 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1) {
/* 1115 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1120 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1126 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1132 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1138 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1144 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1150 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1157 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1164 */     logIfEnabled(FQCN, Level.FATAL, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0) {
/* 1169 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1) {
/* 1174 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2) {
/* 1179 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3) {
/* 1184 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1190 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1196 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1202 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1208 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1214 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1221 */     logIfEnabled(FQCN, Level.FATAL, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <MF extends MessageFactory> MF getMessageFactory() {
/* 1227 */     return (MF)this.messageFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getName() {
/* 1232 */     return this.name;
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Message msg) {
/* 1237 */     logIfEnabled(FQCN, Level.INFO, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Message msg, Throwable t) {
/* 1242 */     logIfEnabled(FQCN, Level.INFO, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, CharSequence message) {
/* 1247 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, CharSequence message, Throwable t) {
/* 1252 */     logIfEnabled(FQCN, Level.INFO, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Object message) {
/* 1257 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Object message, Throwable t) {
/* 1262 */     logIfEnabled(FQCN, Level.INFO, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message) {
/* 1267 */     logIfEnabled(FQCN, Level.INFO, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object... params) {
/* 1272 */     logIfEnabled(FQCN, Level.INFO, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Throwable t) {
/* 1277 */     logIfEnabled(FQCN, Level.INFO, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Message msg) {
/* 1282 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Message msg, Throwable t) {
/* 1287 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(CharSequence message) {
/* 1292 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(CharSequence message, Throwable t) {
/* 1297 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message) {
/* 1302 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Object message, Throwable t) {
/* 1307 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message) {
/* 1312 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object... params) {
/* 1317 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Throwable t) {
/* 1322 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Supplier<?> msgSupplier) {
/* 1327 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Supplier<?> msgSupplier, Throwable t) {
/* 1332 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Supplier<?> msgSupplier) {
/* 1337 */     logIfEnabled(FQCN, Level.INFO, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1342 */     logIfEnabled(FQCN, Level.INFO, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 1347 */     logIfEnabled(FQCN, Level.INFO, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Supplier<?>... paramSuppliers) {
/* 1352 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, MessageSupplier msgSupplier) {
/* 1357 */     logIfEnabled(FQCN, Level.INFO, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 1362 */     logIfEnabled(FQCN, Level.INFO, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(MessageSupplier msgSupplier) {
/* 1367 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(MessageSupplier msgSupplier, Throwable t) {
/* 1372 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0) {
/* 1377 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1) {
/* 1382 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1387 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1393 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1399 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1405 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1411 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1417 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1424 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1431 */     logIfEnabled(FQCN, Level.INFO, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0) {
/* 1436 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1) {
/* 1441 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2) {
/* 1446 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3) {
/* 1451 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1457 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1463 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1469 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1476 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1483 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1490 */     logIfEnabled(FQCN, Level.INFO, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled() {
/* 1495 */     return isEnabled(Level.DEBUG, (Marker)null, (String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled(Marker marker) {
/* 1500 */     return isEnabled(Level.DEBUG, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled(Level level) {
/* 1505 */     return isEnabled(level, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled(Level level, Marker marker) {
/* 1510 */     return isEnabled(level, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isErrorEnabled() {
/* 1515 */     return isEnabled(Level.ERROR, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isErrorEnabled(Marker marker) {
/* 1520 */     return isEnabled(Level.ERROR, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFatalEnabled() {
/* 1525 */     return isEnabled(Level.FATAL, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFatalEnabled(Marker marker) {
/* 1530 */     return isEnabled(Level.FATAL, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled() {
/* 1535 */     return isEnabled(Level.INFO, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled(Marker marker) {
/* 1540 */     return isEnabled(Level.INFO, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled() {
/* 1545 */     return isEnabled(Level.TRACE, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled(Marker marker) {
/* 1550 */     return isEnabled(Level.TRACE, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWarnEnabled() {
/* 1555 */     return isEnabled(Level.WARN, (Marker)null, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWarnEnabled(Marker marker) {
/* 1560 */     return isEnabled(Level.WARN, marker, (Object)null, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Message msg) {
/* 1565 */     logIfEnabled(FQCN, level, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Message msg, Throwable t) {
/* 1570 */     logIfEnabled(FQCN, level, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, CharSequence message) {
/* 1575 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, CharSequence message, Throwable t) {
/* 1580 */     if (isEnabled(level, marker, message, t)) {
/* 1581 */       logMessage(FQCN, level, marker, message, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Object message) {
/* 1587 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Object message, Throwable t) {
/* 1592 */     if (isEnabled(level, marker, message, t)) {
/* 1593 */       logMessage(FQCN, level, marker, message, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message) {
/* 1599 */     logIfEnabled(FQCN, level, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object... params) {
/* 1604 */     logIfEnabled(FQCN, level, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Throwable t) {
/* 1609 */     logIfEnabled(FQCN, level, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Message msg) {
/* 1614 */     logIfEnabled(FQCN, level, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Message msg, Throwable t) {
/* 1619 */     logIfEnabled(FQCN, level, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, CharSequence message) {
/* 1624 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, CharSequence message, Throwable t) {
/* 1629 */     logIfEnabled(FQCN, level, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Object message) {
/* 1634 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Object message, Throwable t) {
/* 1639 */     logIfEnabled(FQCN, level, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message) {
/* 1644 */     logIfEnabled(FQCN, level, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object... params) {
/* 1649 */     logIfEnabled(FQCN, level, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Throwable t) {
/* 1654 */     logIfEnabled(FQCN, level, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Supplier<?> msgSupplier) {
/* 1659 */     logIfEnabled(FQCN, level, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Supplier<?> msgSupplier, Throwable t) {
/* 1664 */     logIfEnabled(FQCN, level, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Supplier<?> msgSupplier) {
/* 1669 */     logIfEnabled(FQCN, level, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1674 */     logIfEnabled(FQCN, level, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 1679 */     logIfEnabled(FQCN, level, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Supplier<?>... paramSuppliers) {
/* 1684 */     logIfEnabled(FQCN, level, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, MessageSupplier msgSupplier) {
/* 1689 */     logIfEnabled(FQCN, level, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 1694 */     logIfEnabled(FQCN, level, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, MessageSupplier msgSupplier) {
/* 1699 */     logIfEnabled(FQCN, level, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, MessageSupplier msgSupplier, Throwable t) {
/* 1704 */     logIfEnabled(FQCN, level, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0) {
/* 1709 */     logIfEnabled(FQCN, level, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1) {
/* 1714 */     logIfEnabled(FQCN, level, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1720 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1726 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1732 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1738 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1744 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1751 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1758 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1765 */     logIfEnabled(FQCN, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0) {
/* 1770 */     logIfEnabled(FQCN, level, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1) {
/* 1775 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2) {
/* 1780 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1785 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1791 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1797 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1803 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1809 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1815 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void log(Level level, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1821 */     logIfEnabled(FQCN, level, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Message msg, Throwable t) {
/* 1827 */     if (isEnabled(level, marker, msg, t)) {
/* 1828 */       logMessageSafely(fqcn, level, marker, msg, t);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 1835 */     if (isEnabled(level, marker, msgSupplier, t)) {
/* 1836 */       logMessage(fqcn, level, marker, msgSupplier, t);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Object message, Throwable t) {
/* 1843 */     if (isEnabled(level, marker, message, t)) {
/* 1844 */       logMessage(fqcn, level, marker, message, t);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, CharSequence message, Throwable t) {
/* 1851 */     if (isEnabled(level, marker, message, t)) {
/* 1852 */       logMessage(fqcn, level, marker, message, t);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 1859 */     if (isEnabled(level, marker, msgSupplier, t)) {
/* 1860 */       logMessage(fqcn, level, marker, msgSupplier, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message) {
/* 1866 */     if (isEnabled(level, marker, message)) {
/* 1867 */       logMessage(fqcn, level, marker, message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 1874 */     if (isEnabled(level, marker, message)) {
/* 1875 */       logMessage(fqcn, level, marker, message, paramSuppliers);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object... params) {
/* 1882 */     if (isEnabled(level, marker, message, params)) {
/* 1883 */       logMessage(fqcn, level, marker, message, params);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0) {
/* 1890 */     if (isEnabled(level, marker, message, p0)) {
/* 1891 */       logMessage(fqcn, level, marker, message, p0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1) {
/* 1898 */     if (isEnabled(level, marker, message, p0, p1)) {
/* 1899 */       logMessage(fqcn, level, marker, message, p0, p1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 1906 */     if (isEnabled(level, marker, message, p0, p1, p2)) {
/* 1907 */       logMessage(fqcn, level, marker, message, p0, p1, p2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 1914 */     if (isEnabled(level, marker, message, p0, p1, p2, p3)) {
/* 1915 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 1922 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4)) {
/* 1923 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 1930 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5)) {
/* 1931 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 1939 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6)) {
/* 1940 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 1948 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7)) {
/* 1949 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 1957 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8)) {
/* 1958 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 1966 */     if (isEnabled(level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9)) {
/* 1967 */       logMessage(fqcn, level, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logIfEnabled(String fqcn, Level level, Marker marker, String message, Throwable t) {
/* 1974 */     if (isEnabled(level, marker, message, t)) {
/* 1975 */       logMessage(fqcn, level, marker, message, t);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, CharSequence message, Throwable t) {
/* 1981 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), t);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, Object message, Throwable t) {
/* 1986 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), t);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 1991 */     Message message = LambdaUtil.get(msgSupplier);
/* 1992 */     logMessageSafely(fqcn, level, marker, message, (t == null && message != null) ? message.getThrowable() : t);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 1997 */     Message message = LambdaUtil.getMessage(msgSupplier, (MessageFactory)this.messageFactory);
/* 1998 */     logMessageSafely(fqcn, level, marker, message, (t == null && message != null) ? message.getThrowable() : t);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Throwable t) {
/* 2003 */     logMessageSafely(fqcn, level, marker, this.messageFactory.newMessage(message), t);
/*      */   }
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message) {
/* 2007 */     Message msg = this.messageFactory.newMessage(message);
/* 2008 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object... params) {
/* 2013 */     Message msg = this.messageFactory.newMessage(message, params);
/* 2014 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0) {
/* 2019 */     Message msg = this.messageFactory.newMessage(message, p0);
/* 2020 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1) {
/* 2025 */     Message msg = this.messageFactory.newMessage(message, p0, p1);
/* 2026 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2031 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2);
/* 2032 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2037 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3);
/* 2038 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2043 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4);
/* 2044 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2049 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5);
/* 2050 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2056 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6);
/* 2057 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2063 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7);
/* 2064 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2070 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/* 2071 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2077 */     Message msg = this.messageFactory.newMessage(message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/* 2078 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void logMessage(String fqcn, Level level, Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2083 */     Message msg = this.messageFactory.newMessage(message, LambdaUtil.getAll((Supplier[])paramSuppliers));
/* 2084 */     logMessageSafely(fqcn, level, marker, msg, msg.getThrowable());
/*      */   }
/*      */ 
/*      */   
/*      */   public void logMessage(Level level, Marker marker, String fqcn, StackTraceElement location, Message message, Throwable throwable) {
/*      */     try {
/* 2090 */       incrementRecursionDepth();
/* 2091 */       log(level, marker, fqcn, location, message, throwable);
/* 2092 */     } catch (Throwable t) {
/* 2093 */       handleLogMessageException(t, fqcn, message);
/*      */     } finally {
/* 2095 */       decrementRecursionDepth();
/* 2096 */       ReusableMessageFactory.release(message);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void log(Level level, Marker marker, String fqcn, StackTraceElement location, Message message, Throwable throwable) {
/* 2102 */     logMessage(fqcn, level, marker, message, throwable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void printf(Level level, Marker marker, String format, Object... params) {
/* 2107 */     if (isEnabled(level, marker, format, params)) {
/* 2108 */       StringFormattedMessage stringFormattedMessage = new StringFormattedMessage(format, params);
/* 2109 */       logMessageSafely(FQCN, level, marker, (Message)stringFormattedMessage, stringFormattedMessage.getThrowable());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void printf(Level level, String format, Object... params) {
/* 2115 */     if (isEnabled(level, (Marker)null, format, params)) {
/* 2116 */       StringFormattedMessage stringFormattedMessage = new StringFormattedMessage(format, params);
/* 2117 */       logMessageSafely(FQCN, level, (Marker)null, (Message)stringFormattedMessage, stringFormattedMessage.getThrowable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void logMessageSafely(String fqcn, Level level, Marker marker, Message msg, Throwable throwable) {
/*      */     try {
/* 2127 */       logMessageTrackRecursion(fqcn, level, marker, msg, throwable);
/*      */     } finally {
/*      */       
/* 2130 */       ReusableMessageFactory.release(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void logMessageTrackRecursion(String fqcn, Level level, Marker marker, Message msg, Throwable throwable) {
/*      */     try {
/* 2143 */       incrementRecursionDepth();
/* 2144 */       tryLogMessage(fqcn, getLocation(fqcn), level, marker, msg, throwable);
/*      */     } finally {
/* 2146 */       decrementRecursionDepth();
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int[] getRecursionDepthHolder() {
/* 2151 */     int[] result = recursionDepthHolder.get();
/* 2152 */     if (result == null) {
/* 2153 */       result = new int[1];
/* 2154 */       recursionDepthHolder.set(result);
/*      */     } 
/* 2156 */     return result;
/*      */   }
/*      */   
/*      */   private static void incrementRecursionDepth() {
/* 2160 */     getRecursionDepthHolder()[0] = getRecursionDepthHolder()[0] + 1;
/*      */   }
/*      */   private static void decrementRecursionDepth() {
/* 2163 */     int[] depth = getRecursionDepthHolder();
/* 2164 */     depth[0] = depth[0] - 1;
/* 2165 */     if (depth[0] < 0) {
/* 2166 */       throw new IllegalStateException("Recursion depth became negative: " + depth[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getRecursionDepth() {
/* 2177 */     return getRecursionDepthHolder()[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private void tryLogMessage(String fqcn, StackTraceElement location, Level level, Marker marker, Message msg, Throwable throwable) {
/*      */     try {
/* 2190 */       log(level, marker, fqcn, location, msg, throwable);
/* 2191 */     } catch (Throwable t) {
/*      */       
/* 2193 */       handleLogMessageException(t, fqcn, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @PerformanceSensitive
/*      */   private StackTraceElement getLocation(String fqcn) {
/* 2201 */     return requiresLocation() ? StackLocatorUtil.calcLocation(fqcn) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleLogMessageException(Throwable exception, String fqcn, Message msg) {
/* 2207 */     if (exception instanceof LoggingException) {
/* 2208 */       throw (LoggingException)exception;
/*      */     }
/* 2210 */     String format = msg.getFormat();
/* 2211 */     int formatLength = (format == null) ? 4 : format.length();
/* 2212 */     StringBuilder sb = new StringBuilder(formatLength + 100);
/* 2213 */     sb.append(fqcn);
/* 2214 */     sb.append(" caught ");
/* 2215 */     sb.append(exception.getClass().getName());
/* 2216 */     sb.append(" logging ");
/* 2217 */     sb.append(msg.getClass().getSimpleName());
/* 2218 */     sb.append(": ");
/* 2219 */     sb.append(format);
/* 2220 */     StatusLogger.getLogger().warn(sb.toString(), exception);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends Throwable> T throwing(T t) {
/* 2225 */     return throwing(FQCN, Level.ERROR, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends Throwable> T throwing(Level level, T t) {
/* 2230 */     return throwing(FQCN, level, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Throwable> T throwing(String fqcn, Level level, T t) {
/* 2243 */     if (isEnabled(level, THROWING_MARKER, (Object)null, (Throwable)null)) {
/* 2244 */       logMessageSafely(fqcn, level, THROWING_MARKER, throwingMsg((Throwable)t), (Throwable)t);
/*      */     }
/* 2246 */     return t;
/*      */   }
/*      */   
/*      */   protected Message throwingMsg(Throwable t) {
/* 2250 */     return this.messageFactory.newMessage("Throwing");
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Message msg) {
/* 2255 */     logIfEnabled(FQCN, Level.TRACE, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Message msg, Throwable t) {
/* 2260 */     logIfEnabled(FQCN, Level.TRACE, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, CharSequence message) {
/* 2265 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, CharSequence message, Throwable t) {
/* 2270 */     logIfEnabled(FQCN, Level.TRACE, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Object message) {
/* 2275 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Object message, Throwable t) {
/* 2280 */     logIfEnabled(FQCN, Level.TRACE, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message) {
/* 2285 */     logIfEnabled(FQCN, Level.TRACE, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object... params) {
/* 2290 */     logIfEnabled(FQCN, Level.TRACE, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Throwable t) {
/* 2295 */     logIfEnabled(FQCN, Level.TRACE, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Message msg) {
/* 2300 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Message msg, Throwable t) {
/* 2305 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(CharSequence message) {
/* 2310 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(CharSequence message, Throwable t) {
/* 2315 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message) {
/* 2320 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Object message, Throwable t) {
/* 2325 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message) {
/* 2330 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object... params) {
/* 2335 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Throwable t) {
/* 2340 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Supplier<?> msgSupplier) {
/* 2345 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Supplier<?> msgSupplier, Throwable t) {
/* 2350 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Supplier<?> msgSupplier) {
/* 2355 */     logIfEnabled(FQCN, Level.TRACE, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2360 */     logIfEnabled(FQCN, Level.TRACE, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 2365 */     logIfEnabled(FQCN, Level.TRACE, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Supplier<?>... paramSuppliers) {
/* 2370 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, MessageSupplier msgSupplier) {
/* 2375 */     logIfEnabled(FQCN, Level.TRACE, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 2380 */     logIfEnabled(FQCN, Level.TRACE, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(MessageSupplier msgSupplier) {
/* 2385 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(MessageSupplier msgSupplier, Throwable t) {
/* 2390 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0) {
/* 2395 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1) {
/* 2400 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2405 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2411 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2417 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2423 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2429 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2435 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2442 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2449 */     logIfEnabled(FQCN, Level.TRACE, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0) {
/* 2454 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1) {
/* 2459 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2) {
/* 2464 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3) {
/* 2469 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2475 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2481 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2487 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2493 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2499 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2505 */     logIfEnabled(FQCN, Level.TRACE, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry() {
/* 2510 */     return enter(FQCN, (String)null, (Object[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(String format, Object... params) {
/* 2515 */     return enter(FQCN, format, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(Supplier<?>... paramSuppliers) {
/* 2520 */     return enter(FQCN, (String)null, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(String format, Supplier<?>... paramSuppliers) {
/* 2525 */     return enter(FQCN, format, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntryMessage traceEntry(Message message) {
/* 2530 */     return enter(FQCN, message);
/*      */   }
/*      */ 
/*      */   
/*      */   public void traceExit() {
/* 2535 */     exit(FQCN, (String)null, (Object)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> R traceExit(R result) {
/* 2540 */     return exit(FQCN, (String)null, result);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> R traceExit(String format, R result) {
/* 2545 */     return exit(FQCN, format, result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void traceExit(EntryMessage message) {
/* 2551 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, (Message)message, (Throwable)null)) {
/* 2552 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(message), (Throwable)null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> R traceExit(EntryMessage message, R result) {
/* 2559 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, (Message)message, (Throwable)null)) {
/* 2560 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(result, message), (Throwable)null);
/*      */     }
/* 2562 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> R traceExit(Message message, R result) {
/* 2568 */     if (message != null && isEnabled(Level.TRACE, EXIT_MARKER, message, (Throwable)null)) {
/* 2569 */       logMessageSafely(FQCN, Level.TRACE, EXIT_MARKER, (Message)this.flowMessageFactory.newExitMessage(result, message), (Throwable)null);
/*      */     }
/* 2571 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Message msg) {
/* 2576 */     logIfEnabled(FQCN, Level.WARN, marker, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Message msg, Throwable t) {
/* 2581 */     logIfEnabled(FQCN, Level.WARN, marker, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, CharSequence message) {
/* 2586 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, CharSequence message, Throwable t) {
/* 2591 */     logIfEnabled(FQCN, Level.WARN, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Object message) {
/* 2596 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Object message, Throwable t) {
/* 2601 */     logIfEnabled(FQCN, Level.WARN, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message) {
/* 2606 */     logIfEnabled(FQCN, Level.WARN, marker, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object... params) {
/* 2611 */     logIfEnabled(FQCN, Level.WARN, marker, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Throwable t) {
/* 2616 */     logIfEnabled(FQCN, Level.WARN, marker, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Message msg) {
/* 2621 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msg, (msg != null) ? msg.getThrowable() : null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Message msg, Throwable t) {
/* 2626 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msg, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(CharSequence message) {
/* 2631 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(CharSequence message, Throwable t) {
/* 2636 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message) {
/* 2641 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Object message, Throwable t) {
/* 2646 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message) {
/* 2651 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object... params) {
/* 2656 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, params);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Throwable t) {
/* 2661 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Supplier<?> msgSupplier) {
/* 2666 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Supplier<?> msgSupplier, Throwable t) {
/* 2671 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Supplier<?> msgSupplier) {
/* 2676 */     logIfEnabled(FQCN, Level.WARN, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Supplier<?>... paramSuppliers) {
/* 2681 */     logIfEnabled(FQCN, Level.WARN, marker, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, Supplier<?> msgSupplier, Throwable t) {
/* 2686 */     logIfEnabled(FQCN, Level.WARN, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Supplier<?>... paramSuppliers) {
/* 2691 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, paramSuppliers);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, MessageSupplier msgSupplier) {
/* 2696 */     logIfEnabled(FQCN, Level.WARN, marker, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, MessageSupplier msgSupplier, Throwable t) {
/* 2701 */     logIfEnabled(FQCN, Level.WARN, marker, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(MessageSupplier msgSupplier) {
/* 2706 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msgSupplier, (Throwable)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(MessageSupplier msgSupplier, Throwable t) {
/* 2711 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, msgSupplier, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0) {
/* 2716 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1) {
/* 2721 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2) {
/* 2726 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3) {
/* 2732 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2738 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2744 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2750 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2756 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2762 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2769 */     logIfEnabled(FQCN, Level.WARN, marker, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0) {
/* 2774 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1) {
/* 2779 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2) {
/* 2784 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3) {
/* 2789 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {
/* 2795 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 2801 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {
/* 2807 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {
/* 2813 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {
/* 2819 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {
/* 2826 */     logIfEnabled(FQCN, Level.WARN, (Marker)null, message, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9);
/*      */   }
/*      */   
/*      */   protected boolean requiresLocation() {
/* 2830 */     return false;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\org\apache\logging\log4j\spi\AbstractLogger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */