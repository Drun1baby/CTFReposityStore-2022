module org.apache.logging.log4j {
  requires java.base;
  
  exports org.apache.logging.log4j;
  exports org.apache.logging.log4j.message;
  exports org.apache.logging.log4j.simple;
  exports org.apache.logging.log4j.spi;
  exports org.apache.logging.log4j.status;
  exports org.apache.logging.log4j.util;
  
  uses org.apache.logging.log4j.spi.Provider;
  uses org.apache.logging.log4j.util.PropertySource;
  uses org.apache.logging.log4j.message.ThreadDumpMessage$ThreadInfoFactory;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */