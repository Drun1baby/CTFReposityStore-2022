/*    */ package META-INF.versions.9.org.apache.logging.log4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessIdUtil
/*    */ {
/*    */   public static final String DEFAULT_PROCESSID = "-";
/*    */   
/*    */   public static String getProcessId() {
/*    */     try {
/* 25 */       return Long.toString(ProcessHandle.current().pid());
/* 26 */     } catch (Exception ex) {
/* 27 */       return "-";
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\META-INF\versions\9\org\apache\logging\log4\\util\ProcessIdUtil.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */