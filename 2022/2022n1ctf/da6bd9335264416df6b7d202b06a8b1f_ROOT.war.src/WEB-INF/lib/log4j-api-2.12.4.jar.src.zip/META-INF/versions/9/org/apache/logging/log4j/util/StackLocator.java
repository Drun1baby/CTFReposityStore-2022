/*    */ package META-INF.versions.9.org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.Stack;
/*    */ import java.util.function.Function;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.apache.logging.log4j.util.PrivateSecurityManagerStackTraceUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StackLocator
/*    */ {
/* 31 */   private static final StackWalker walker = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE);
/*    */   
/* 33 */   private static final StackWalker stackWalker = StackWalker.getInstance();
/*    */   
/* 35 */   private static final org.apache.logging.log4j.util.StackLocator INSTANCE = new org.apache.logging.log4j.util.StackLocator();
/*    */   
/* 37 */   private static final ThreadLocal<String> FQCN = new ThreadLocal<>();
/* 38 */   private static final FqcnCallerLocator LOCATOR = new FqcnCallerLocator();
/*    */   
/*    */   public static org.apache.logging.log4j.util.StackLocator getInstance() {
/* 41 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getCallerClass(String fqcn) {
/* 48 */     return getCallerClass(fqcn, "");
/*    */   }
/*    */   
/*    */   public Class<?> getCallerClass(String fqcn, String pkg) {
/* 52 */     return ((Optional)walker.<Optional>walk(s -> s.dropWhile(()).dropWhile(()).dropWhile(()).findFirst()))
/*    */       
/* 54 */       .map(StackWalker.StackFrame::getDeclaringClass).orElse(null);
/*    */   }
/*    */   
/*    */   public Class<?> getCallerClass(Class<?> anchor) {
/* 58 */     return ((Optional)walker.<Optional>walk(s -> s.dropWhile(()).dropWhile(()).findFirst()))
/*    */       
/* 60 */       .map(StackWalker.StackFrame::getDeclaringClass).orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getCallerClass(int depth) {
/* 65 */     return ((Optional)walker.<Optional>walk(s -> s.skip(depth).findFirst())).map(StackWalker.StackFrame::getDeclaringClass).orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Stack<Class<?>> getCurrentStackTrace() {
/* 70 */     if (PrivateSecurityManagerStackTraceUtil.isEnabled()) {
/* 71 */       return PrivateSecurityManagerStackTraceUtil.getCurrentStackTrace();
/*    */     }
/* 73 */     Stack<Class<?>> stack = new Stack<>();
/* 74 */     List<Class<?>> classes = walker.<List<Class<?>>>walk(s -> (List)s.map(()).collect(Collectors.toList()));
/* 75 */     stack.addAll(classes);
/* 76 */     return stack;
/*    */   }
/*    */   
/*    */   public StackTraceElement calcLocation(String fqcnOfLogger) {
/* 80 */     FQCN.set(fqcnOfLogger);
/* 81 */     StackTraceElement element = ((StackWalker.StackFrame)walker.<StackWalker.StackFrame>walk((Function<? super Stream<StackWalker.StackFrame>, ? extends StackWalker.StackFrame>)LOCATOR)).toStackTraceElement();
/* 82 */     FQCN.set(null);
/* 83 */     return element;
/*    */   }
/*    */   
/*    */   public StackTraceElement getStackTraceElement(int depth) {
/* 87 */     return ((StackWalker.StackFrame)((Optional<StackWalker.StackFrame>)stackWalker.<Optional<StackWalker.StackFrame>>walk(s -> s.skip(depth).findFirst())).get()).toStackTraceElement();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-api-2.12.4.jar!\META-INF\versions\9\org\apache\logging\log4\\util\StackLocator.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */