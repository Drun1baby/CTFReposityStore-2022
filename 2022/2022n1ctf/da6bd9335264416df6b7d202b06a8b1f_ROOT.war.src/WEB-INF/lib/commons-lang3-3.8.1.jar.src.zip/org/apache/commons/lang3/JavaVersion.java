/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import org.apache.commons.lang3.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaVersion
/*     */ {
/*  33 */   JAVA_0_9(1.5F, "0.9"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   JAVA_1_1(1.1F, "1.1"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   JAVA_1_2(1.2F, "1.2"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   JAVA_1_3(1.3F, "1.3"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   JAVA_1_4(1.4F, "1.4"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   JAVA_1_5(1.5F, "1.5"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   JAVA_1_6(1.6F, "1.6"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   JAVA_1_7(1.7F, "1.7"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   JAVA_1_8(1.8F, "1.8"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   JAVA_1_9(9.0F, "9"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   JAVA_9(9.0F, "9"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   JAVA_10(10.0F, "10"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   JAVA_11(11.0F, "11"),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   JAVA_RECENT(maxVersion(), Float.toString(maxVersion()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JavaVersion(float value, String name) {
/* 126 */     this.value = value;
/* 127 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean atLeast(JavaVersion requiredVersion) {
/* 141 */     return (this.value >= requiredVersion.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JavaVersion getJavaVersion(String nom) {
/* 155 */     return get(nom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JavaVersion get(String nom) {
/* 168 */     if ("0.9".equals(nom))
/* 169 */       return JAVA_0_9; 
/* 170 */     if ("1.1".equals(nom))
/* 171 */       return JAVA_1_1; 
/* 172 */     if ("1.2".equals(nom))
/* 173 */       return JAVA_1_2; 
/* 174 */     if ("1.3".equals(nom))
/* 175 */       return JAVA_1_3; 
/* 176 */     if ("1.4".equals(nom))
/* 177 */       return JAVA_1_4; 
/* 178 */     if ("1.5".equals(nom))
/* 179 */       return JAVA_1_5; 
/* 180 */     if ("1.6".equals(nom))
/* 181 */       return JAVA_1_6; 
/* 182 */     if ("1.7".equals(nom))
/* 183 */       return JAVA_1_7; 
/* 184 */     if ("1.8".equals(nom))
/* 185 */       return JAVA_1_8; 
/* 186 */     if ("9".equals(nom))
/* 187 */       return JAVA_9; 
/* 188 */     if ("10".equals(nom))
/* 189 */       return JAVA_10; 
/* 190 */     if ("11".equals(nom)) {
/* 191 */       return JAVA_11;
/*     */     }
/* 193 */     if (nom == null) {
/* 194 */       return null;
/*     */     }
/* 196 */     float v = toFloatVersion(nom);
/* 197 */     if (v - 1.0D < 1.0D) {
/* 198 */       int firstComma = Math.max(nom.indexOf('.'), nom.indexOf(','));
/* 199 */       int end = Math.max(nom.length(), nom.indexOf(',', firstComma));
/* 200 */       if (Float.parseFloat(nom.substring(firstComma + 1, end)) > 0.9F) {
/* 201 */         return JAVA_RECENT;
/*     */       }
/* 203 */     } else if (v > 10.0F) {
/* 204 */       return JAVA_RECENT;
/*     */     } 
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 219 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float maxVersion() {
/* 228 */     float v = toFloatVersion(System.getProperty("java.specification.version", "99.0"));
/* 229 */     if (v > 0.0F) {
/* 230 */       return v;
/*     */     }
/* 232 */     return 99.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float toFloatVersion(String value) {
/* 242 */     int defaultReturnValue = -1;
/* 243 */     if (value.contains(".")) {
/* 244 */       String[] toParse = value.split("\\.");
/* 245 */       if (toParse.length >= 2) {
/* 246 */         return NumberUtils.toFloat(toParse[0] + '.' + toParse[1], -1.0F);
/*     */       }
/*     */     } else {
/* 249 */       return NumberUtils.toFloat(value, -1.0F);
/*     */     } 
/* 251 */     return -1.0F;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\JavaVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */