/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomStringUtils
/*     */ {
/*  46 */   private static final Random RANDOM = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count) {
/*  72 */     return random(count, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAscii(int count) {
/*  86 */     return random(count, 32, 127, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAscii(int minLengthInclusive, int maxLengthExclusive) {
/* 102 */     return randomAscii(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAlphabetic(int count) {
/* 116 */     return random(count, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAlphabetic(int minLengthInclusive, int maxLengthExclusive) {
/* 131 */     return randomAlphabetic(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAlphanumeric(int count) {
/* 145 */     return random(count, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomAlphanumeric(int minLengthInclusive, int maxLengthExclusive) {
/* 161 */     return randomAlphanumeric(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomGraph(int count) {
/* 176 */     return random(count, 33, 126, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomGraph(int minLengthInclusive, int maxLengthExclusive) {
/* 191 */     return randomGraph(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomNumeric(int count) {
/* 205 */     return random(count, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomNumeric(int minLengthInclusive, int maxLengthExclusive) {
/* 220 */     return randomNumeric(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomPrint(int count) {
/* 235 */     return random(count, 32, 126, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String randomPrint(int minLengthInclusive, int maxLengthExclusive) {
/* 250 */     return randomPrint(RandomUtils.nextInt(minLengthInclusive, maxLengthExclusive));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, boolean letters, boolean numbers) {
/* 268 */     return random(count, 0, 0, letters, numbers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, int start, int end, boolean letters, boolean numbers) {
/* 288 */     return random(count, start, end, letters, numbers, null, RANDOM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, int start, int end, boolean letters, boolean numbers, char... chars) {
/* 312 */     return random(count, start, end, letters, numbers, chars, RANDOM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, int start, int end, boolean letters, boolean numbers, char[] chars, Random random) {
/* 350 */     if (count == 0)
/* 351 */       return ""; 
/* 352 */     if (count < 0) {
/* 353 */       throw new IllegalArgumentException("Requested random string length " + count + " is less than 0.");
/*     */     }
/* 355 */     if (chars != null && chars.length == 0) {
/* 356 */       throw new IllegalArgumentException("The chars array must not be empty");
/*     */     }
/*     */     
/* 359 */     if (start == 0 && end == 0) {
/* 360 */       if (chars != null) {
/* 361 */         end = chars.length;
/*     */       }
/* 363 */       else if (!letters && !numbers) {
/* 364 */         end = 1114111;
/*     */       } else {
/* 366 */         end = 123;
/* 367 */         start = 32;
/*     */       }
/*     */     
/*     */     }
/* 371 */     else if (end <= start) {
/* 372 */       throw new IllegalArgumentException("Parameter end (" + end + ") must be greater than start (" + start + ")");
/*     */     } 
/*     */ 
/*     */     
/* 376 */     int zero_digit_ascii = 48;
/* 377 */     int first_letter_ascii = 65;
/*     */     
/* 379 */     if (chars == null && ((numbers && end <= 48) || (letters && end <= 65)))
/*     */     {
/* 381 */       throw new IllegalArgumentException("Parameter end (" + end + ") must be greater then (" + '0' + ") for generating digits or greater then (" + 'A' + ") for generating letters.");
/*     */     }
/*     */ 
/*     */     
/* 385 */     StringBuilder builder = new StringBuilder(count);
/* 386 */     int gap = end - start;
/*     */     
/* 388 */     while (count-- != 0) {
/*     */       int codePoint;
/* 390 */       if (chars == null) {
/* 391 */         codePoint = random.nextInt(gap) + start;
/*     */         
/* 393 */         switch (Character.getType(codePoint)) {
/*     */           case 0:
/*     */           case 18:
/*     */           case 19:
/* 397 */             count++;
/*     */             continue;
/*     */         } 
/*     */       
/*     */       } else {
/* 402 */         codePoint = chars[random.nextInt(gap) + start];
/*     */       } 
/*     */       
/* 405 */       int numberOfChars = Character.charCount(codePoint);
/* 406 */       if (count == 0 && numberOfChars > 1) {
/* 407 */         count++;
/*     */         
/*     */         continue;
/*     */       } 
/* 411 */       if ((letters && Character.isLetter(codePoint)) || (numbers && 
/* 412 */         Character.isDigit(codePoint)) || (!letters && !numbers)) {
/*     */         
/* 414 */         builder.appendCodePoint(codePoint);
/*     */         
/* 416 */         if (numberOfChars == 2) {
/* 417 */           count--;
/*     */         }
/*     */         continue;
/*     */       } 
/* 421 */       count++;
/*     */     } 
/*     */     
/* 424 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, String chars) {
/* 443 */     if (chars == null) {
/* 444 */       return random(count, 0, 0, false, false, null, RANDOM);
/*     */     }
/* 446 */     return random(count, chars.toCharArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, char... chars) {
/* 462 */     if (chars == null) {
/* 463 */       return random(count, 0, 0, false, false, null, RANDOM);
/*     */     }
/* 465 */     return random(count, 0, chars.length, false, false, chars, RANDOM);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\RandomStringUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */