package org.apache.commons.lang3.reflect;

import java.lang.reflect.Type;

public interface Typed<T> {
  Type getType();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\reflect\Typed.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */