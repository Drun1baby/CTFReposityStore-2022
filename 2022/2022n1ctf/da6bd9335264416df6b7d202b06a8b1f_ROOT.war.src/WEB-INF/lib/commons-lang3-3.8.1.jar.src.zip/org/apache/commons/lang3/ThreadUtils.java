/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadUtils
/*     */ {
/*     */   public static Thread findThreadById(long threadId, ThreadGroup threadGroup) {
/*  53 */     Validate.isTrue((threadGroup != null), "The thread group must not be null", new Object[0]);
/*  54 */     Thread thread = findThreadById(threadId);
/*  55 */     if (thread != null && threadGroup.equals(thread.getThreadGroup())) {
/*  56 */       return thread;
/*     */     }
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Thread findThreadById(long threadId, String threadGroupName) {
/*  76 */     Validate.isTrue((threadGroupName != null), "The thread group name must not be null", new Object[0]);
/*  77 */     Thread thread = findThreadById(threadId);
/*  78 */     if (thread != null && thread.getThreadGroup() != null && thread.getThreadGroup().getName().equals(threadGroupName)) {
/*  79 */       return thread;
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> findThreadsByName(String threadName, ThreadGroup threadGroup) {
/*  99 */     return findThreads(threadGroup, false, new NamePredicate(threadName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> findThreadsByName(String threadName, String threadGroupName) {
/* 117 */     Validate.isTrue((threadName != null), "The thread name must not be null", new Object[0]);
/* 118 */     Validate.isTrue((threadGroupName != null), "The thread group name must not be null", new Object[0]);
/*     */     
/* 120 */     Collection<ThreadGroup> threadGroups = findThreadGroups(new NamePredicate(threadGroupName));
/*     */     
/* 122 */     if (threadGroups.isEmpty()) {
/* 123 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 126 */     Collection<Thread> result = new ArrayList<>();
/* 127 */     NamePredicate threadNamePredicate = new NamePredicate(threadName);
/* 128 */     for (ThreadGroup group : threadGroups) {
/* 129 */       result.addAll(findThreads(group, false, threadNamePredicate));
/*     */     }
/* 131 */     return Collections.unmodifiableCollection(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<ThreadGroup> findThreadGroupsByName(String threadGroupName) {
/* 147 */     return findThreadGroups(new NamePredicate(threadGroupName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<ThreadGroup> getAllThreadGroups() {
/* 161 */     return findThreadGroups(ALWAYS_TRUE_PREDICATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadGroup getSystemThreadGroup() {
/* 172 */     ThreadGroup threadGroup = Thread.currentThread().getThreadGroup();
/* 173 */     while (threadGroup.getParent() != null) {
/* 174 */       threadGroup = threadGroup.getParent();
/*     */     }
/* 176 */     return threadGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> getAllThreads() {
/* 190 */     return findThreads(ALWAYS_TRUE_PREDICATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> findThreadsByName(String threadName) {
/* 206 */     return findThreads(new NamePredicate(threadName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Thread findThreadById(long threadId) {
/* 222 */     Collection<Thread> result = findThreads(new ThreadIdPredicate(threadId));
/* 223 */     return result.isEmpty() ? null : result.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public static final AlwaysTruePredicate ALWAYS_TRUE_PREDICATE = new AlwaysTruePredicate();
/*     */   
/*     */   public static interface ThreadPredicate {
/*     */     boolean test(Thread param1Thread); }
/*     */   
/*     */   public static interface ThreadGroupPredicate {
/*     */     boolean test(ThreadGroup param1ThreadGroup); }
/*     */   
/*     */   private static final class AlwaysTruePredicate implements ThreadPredicate, ThreadGroupPredicate {
/*     */     private AlwaysTruePredicate() {}
/*     */     
/*     */     public boolean test(ThreadGroup threadGroup) {
/* 282 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Thread thread) {
/* 287 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NamePredicate
/*     */     implements ThreadPredicate, ThreadGroupPredicate
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NamePredicate(String name) {
/* 306 */       Validate.isTrue((name != null), "The name must not be null", new Object[0]);
/* 307 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(ThreadGroup threadGroup) {
/* 312 */       return (threadGroup != null && threadGroup.getName().equals(this.name));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Thread thread) {
/* 317 */       return (thread != null && thread.getName().equals(this.name));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ThreadIdPredicate
/*     */     implements ThreadPredicate
/*     */   {
/*     */     private final long threadId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ThreadIdPredicate(long threadId) {
/* 336 */       if (threadId <= 0L) {
/* 337 */         throw new IllegalArgumentException("The thread id must be greater than zero");
/*     */       }
/* 339 */       this.threadId = threadId;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Thread thread) {
/* 344 */       return (thread != null && thread.getId() == this.threadId);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> findThreads(ThreadPredicate predicate) {
/* 361 */     return findThreads(getSystemThreadGroup(), true, predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<ThreadGroup> findThreadGroups(ThreadGroupPredicate predicate) {
/* 376 */     return findThreadGroups(getSystemThreadGroup(), true, predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Thread> findThreads(ThreadGroup group, boolean recurse, ThreadPredicate predicate) {
/*     */     Thread[] threads;
/* 391 */     Validate.isTrue((group != null), "The group must not be null", new Object[0]);
/* 392 */     Validate.isTrue((predicate != null), "The predicate must not be null", new Object[0]);
/*     */     
/* 394 */     int count = group.activeCount();
/*     */     
/*     */     do {
/* 397 */       threads = new Thread[count + count / 2 + 1];
/* 398 */       count = group.enumerate(threads, recurse);
/*     */     }
/* 400 */     while (count >= threads.length);
/*     */     
/* 402 */     List<Thread> result = new ArrayList<>(count);
/* 403 */     for (int i = 0; i < count; i++) {
/* 404 */       if (predicate.test(threads[i])) {
/* 405 */         result.add(threads[i]);
/*     */       }
/*     */     } 
/* 408 */     return Collections.unmodifiableCollection(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<ThreadGroup> findThreadGroups(ThreadGroup group, boolean recurse, ThreadGroupPredicate predicate) {
/*     */     ThreadGroup[] threadGroups;
/* 423 */     Validate.isTrue((group != null), "The group must not be null", new Object[0]);
/* 424 */     Validate.isTrue((predicate != null), "The predicate must not be null", new Object[0]);
/*     */     
/* 426 */     int count = group.activeGroupCount();
/*     */     
/*     */     do {
/* 429 */       threadGroups = new ThreadGroup[count + count / 2 + 1];
/* 430 */       count = group.enumerate(threadGroups, recurse);
/*     */     }
/* 432 */     while (count >= threadGroups.length);
/*     */     
/* 434 */     List<ThreadGroup> result = new ArrayList<>(count);
/* 435 */     for (int i = 0; i < count; i++) {
/* 436 */       if (predicate.test(threadGroups[i])) {
/* 437 */         result.add(threadGroups[i]);
/*     */       }
/*     */     } 
/* 440 */     return Collections.unmodifiableCollection(result);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\ThreadUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */