/*    */ package org.apache.commons.lang3.reflect;
/*    */ 
/*    */ import org.apache.commons.lang3.BooleanUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InheritanceUtils
/*    */ {
/*    */   public static int distance(Class<?> child, Class<?> parent) {
/* 50 */     if (child == null || parent == null) {
/* 51 */       return -1;
/*    */     }
/*    */     
/* 54 */     if (child.equals(parent)) {
/* 55 */       return 0;
/*    */     }
/*    */     
/* 58 */     Class<?> cParent = child.getSuperclass();
/* 59 */     int d = BooleanUtils.toInteger(parent.equals(cParent));
/*    */     
/* 61 */     if (d == 1) {
/* 62 */       return d;
/*    */     }
/* 64 */     d += distance(cParent, parent);
/* 65 */     return (d > 0) ? (d + 1) : -1;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\reflect\InheritanceUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */