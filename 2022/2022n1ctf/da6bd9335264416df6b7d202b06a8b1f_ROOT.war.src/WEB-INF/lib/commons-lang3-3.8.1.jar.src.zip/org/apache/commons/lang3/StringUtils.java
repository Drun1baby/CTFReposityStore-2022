/*      */ package org.apache.commons.lang3;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.Normalizer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   private static final int STRING_BUILDER_SIZE = 256;
/*      */   public static final String SPACE = " ";
/*      */   public static final String EMPTY = "";
/*      */   public static final String LF = "\n";
/*      */   public static final String CR = "\r";
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   private static final int PAD_LIMIT = 8192;
/*      */   
/*      */   public static boolean isEmpty(CharSequence cs) {
/*  213 */     return (cs == null || cs.length() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(CharSequence cs) {
/*  232 */     return !isEmpty(cs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAnyEmpty(CharSequence... css) {
/*  256 */     if (ArrayUtils.isEmpty((Object[])css)) {
/*  257 */       return false;
/*      */     }
/*  259 */     for (CharSequence cs : css) {
/*  260 */       if (isEmpty(cs)) {
/*  261 */         return true;
/*      */       }
/*      */     } 
/*  264 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNoneEmpty(CharSequence... css) {
/*  288 */     return !isAnyEmpty(css);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllEmpty(CharSequence... css) {
/*  311 */     if (ArrayUtils.isEmpty((Object[])css)) {
/*  312 */       return true;
/*      */     }
/*  314 */     for (CharSequence cs : css) {
/*  315 */       if (isNotEmpty(cs)) {
/*  316 */         return false;
/*      */       }
/*      */     } 
/*  319 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBlank(CharSequence cs) {
/*      */     int strLen;
/*  342 */     if (cs == null || (strLen = cs.length()) == 0) {
/*  343 */       return true;
/*      */     }
/*  345 */     for (int i = 0; i < strLen; i++) {
/*  346 */       if (!Character.isWhitespace(cs.charAt(i))) {
/*  347 */         return false;
/*      */       }
/*      */     } 
/*  350 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotBlank(CharSequence cs) {
/*  373 */     return !isBlank(cs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAnyBlank(CharSequence... css) {
/*  400 */     if (ArrayUtils.isEmpty((Object[])css)) {
/*  401 */       return false;
/*      */     }
/*  403 */     for (CharSequence cs : css) {
/*  404 */       if (isBlank(cs)) {
/*  405 */         return true;
/*      */       }
/*      */     } 
/*  408 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNoneBlank(CharSequence... css) {
/*  435 */     return !isAnyBlank(css);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllBlank(CharSequence... css) {
/*  460 */     if (ArrayUtils.isEmpty((Object[])css)) {
/*  461 */       return true;
/*      */     }
/*  463 */     for (CharSequence cs : css) {
/*  464 */       if (isNotBlank(cs)) {
/*  465 */         return false;
/*      */       }
/*      */     } 
/*  468 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trim(String str) {
/*  497 */     return (str == null) ? null : str.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimToNull(String str) {
/*  523 */     String ts = trim(str);
/*  524 */     return isEmpty(ts) ? null : ts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimToEmpty(String str) {
/*  549 */     return (str == null) ? "" : str.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String truncate(String str, int maxWidth) {
/*  584 */     return truncate(str, 0, maxWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String truncate(String str, int offset, int maxWidth) {
/*  647 */     if (offset < 0) {
/*  648 */       throw new IllegalArgumentException("offset cannot be negative");
/*      */     }
/*  650 */     if (maxWidth < 0) {
/*  651 */       throw new IllegalArgumentException("maxWith cannot be negative");
/*      */     }
/*  653 */     if (str == null) {
/*  654 */       return null;
/*      */     }
/*  656 */     if (offset > str.length()) {
/*  657 */       return "";
/*      */     }
/*  659 */     if (str.length() > maxWidth) {
/*  660 */       int ix = (offset + maxWidth > str.length()) ? str.length() : (offset + maxWidth);
/*  661 */       return str.substring(offset, ix);
/*      */     } 
/*  663 */     return str.substring(offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String strip(String str) {
/*  691 */     return strip(str, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripToNull(String str) {
/*  718 */     if (str == null) {
/*  719 */       return null;
/*      */     }
/*  721 */     str = strip(str, null);
/*  722 */     return str.isEmpty() ? null : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripToEmpty(String str) {
/*  748 */     return (str == null) ? "" : strip(str, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String strip(String str, String stripChars) {
/*  778 */     if (isEmpty(str)) {
/*  779 */       return str;
/*      */     }
/*  781 */     str = stripStart(str, stripChars);
/*  782 */     return stripEnd(str, stripChars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripStart(String str, String stripChars) {
/*      */     int strLen;
/*  811 */     if (str == null || (strLen = str.length()) == 0) {
/*  812 */       return str;
/*      */     }
/*  814 */     int start = 0;
/*  815 */     if (stripChars == null) {
/*  816 */       while (start != strLen && Character.isWhitespace(str.charAt(start)))
/*  817 */         start++; 
/*      */     } else {
/*  819 */       if (stripChars.isEmpty()) {
/*  820 */         return str;
/*      */       }
/*  822 */       while (start != strLen && stripChars.indexOf(str.charAt(start)) != -1) {
/*  823 */         start++;
/*      */       }
/*      */     } 
/*  826 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripEnd(String str, String stripChars) {
/*      */     int end;
/*  856 */     if (str == null || (end = str.length()) == 0) {
/*  857 */       return str;
/*      */     }
/*      */     
/*  860 */     if (stripChars == null) {
/*  861 */       while (end != 0 && Character.isWhitespace(str.charAt(end - 1)))
/*  862 */         end--; 
/*      */     } else {
/*  864 */       if (stripChars.isEmpty()) {
/*  865 */         return str;
/*      */       }
/*  867 */       while (end != 0 && stripChars.indexOf(str.charAt(end - 1)) != -1) {
/*  868 */         end--;
/*      */       }
/*      */     } 
/*  871 */     return str.substring(0, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] stripAll(String... strs) {
/*  896 */     return stripAll(strs, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] stripAll(String[] strs, String stripChars) {
/*      */     int strsLen;
/*  926 */     if (strs == null || (strsLen = strs.length) == 0) {
/*  927 */       return strs;
/*      */     }
/*  929 */     String[] newArr = new String[strsLen];
/*  930 */     for (int i = 0; i < strsLen; i++) {
/*  931 */       newArr[i] = strip(strs[i], stripChars);
/*      */     }
/*  933 */     return newArr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripAccents(String input) {
/*  955 */     if (input == null) {
/*  956 */       return null;
/*      */     }
/*  958 */     Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
/*  959 */     StringBuilder decomposed = new StringBuilder(Normalizer.normalize(input, Normalizer.Form.NFD));
/*  960 */     convertRemainingAccentCharacters(decomposed);
/*      */     
/*  962 */     return pattern.matcher(decomposed).replaceAll("");
/*      */   }
/*      */   
/*      */   private static void convertRemainingAccentCharacters(StringBuilder decomposed) {
/*  966 */     for (int i = 0; i < decomposed.length(); i++) {
/*  967 */       if (decomposed.charAt(i) == 'Ł') {
/*  968 */         decomposed.deleteCharAt(i);
/*  969 */         decomposed.insert(i, 'L');
/*  970 */       } else if (decomposed.charAt(i) == 'ł') {
/*  971 */         decomposed.deleteCharAt(i);
/*  972 */         decomposed.insert(i, 'l');
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(CharSequence cs1, CharSequence cs2) {
/* 1001 */     if (cs1 == cs2) {
/* 1002 */       return true;
/*      */     }
/* 1004 */     if (cs1 == null || cs2 == null) {
/* 1005 */       return false;
/*      */     }
/* 1007 */     if (cs1.length() != cs2.length()) {
/* 1008 */       return false;
/*      */     }
/* 1010 */     if (cs1 instanceof String && cs2 instanceof String) {
/* 1011 */       return cs1.equals(cs2);
/*      */     }
/* 1013 */     return CharSequenceUtils.regionMatches(cs1, false, 0, cs2, 0, cs1.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equalsIgnoreCase(CharSequence str1, CharSequence str2) {
/* 1038 */     if (str1 == null || str2 == null)
/* 1039 */       return (str1 == str2); 
/* 1040 */     if (str1 == str2)
/* 1041 */       return true; 
/* 1042 */     if (str1.length() != str2.length()) {
/* 1043 */       return false;
/*      */     }
/* 1045 */     return CharSequenceUtils.regionMatches(str1, true, 0, str2, 0, str1.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(String str1, String str2) {
/* 1084 */     return compare(str1, str2, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(String str1, String str2, boolean nullIsLess) {
/* 1122 */     if (str1 == str2) {
/* 1123 */       return 0;
/*      */     }
/* 1125 */     if (str1 == null) {
/* 1126 */       return nullIsLess ? -1 : 1;
/*      */     }
/* 1128 */     if (str2 == null) {
/* 1129 */       return nullIsLess ? 1 : -1;
/*      */     }
/* 1131 */     return str1.compareTo(str2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compareIgnoreCase(String str1, String str2) {
/* 1172 */     return compareIgnoreCase(str1, str2, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compareIgnoreCase(String str1, String str2, boolean nullIsLess) {
/* 1215 */     if (str1 == str2) {
/* 1216 */       return 0;
/*      */     }
/* 1218 */     if (str1 == null) {
/* 1219 */       return nullIsLess ? -1 : 1;
/*      */     }
/* 1221 */     if (str2 == null) {
/* 1222 */       return nullIsLess ? 1 : -1;
/*      */     }
/* 1224 */     return str1.compareToIgnoreCase(str2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equalsAny(CharSequence string, CharSequence... searchStrings) {
/* 1247 */     if (ArrayUtils.isNotEmpty(searchStrings)) {
/* 1248 */       for (CharSequence next : searchStrings) {
/* 1249 */         if (equals(string, next)) {
/* 1250 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/* 1254 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equalsAnyIgnoreCase(CharSequence string, CharSequence... searchStrings) {
/* 1278 */     if (ArrayUtils.isNotEmpty(searchStrings)) {
/* 1279 */       for (CharSequence next : searchStrings) {
/* 1280 */         if (equalsIgnoreCase(string, next)) {
/* 1281 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/* 1285 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, int searchChar) {
/* 1328 */     if (isEmpty(seq)) {
/* 1329 */       return -1;
/*      */     }
/* 1331 */     return CharSequenceUtils.indexOf(seq, searchChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, int searchChar, int startPos) {
/* 1388 */     if (isEmpty(seq)) {
/* 1389 */       return -1;
/*      */     }
/* 1391 */     return CharSequenceUtils.indexOf(seq, searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq) {
/* 1419 */     if (seq == null || searchSeq == null) {
/* 1420 */       return -1;
/*      */     }
/* 1422 */     return CharSequenceUtils.indexOf(seq, searchSeq, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq, int startPos) {
/* 1459 */     if (seq == null || searchSeq == null) {
/* 1460 */       return -1;
/*      */     }
/* 1462 */     return CharSequenceUtils.indexOf(seq, searchSeq, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal) {
/* 1516 */     return ordinalIndexOf(str, searchStr, ordinal, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal, boolean lastIndex) {
/* 1535 */     if (str == null || searchStr == null || ordinal <= 0) {
/* 1536 */       return -1;
/*      */     }
/* 1538 */     if (searchStr.length() == 0) {
/* 1539 */       return lastIndex ? str.length() : 0;
/*      */     }
/* 1541 */     int found = 0;
/*      */ 
/*      */     
/* 1544 */     int index = lastIndex ? str.length() : -1;
/*      */     while (true) {
/* 1546 */       if (lastIndex) {
/* 1547 */         index = CharSequenceUtils.lastIndexOf(str, searchStr, index - 1);
/*      */       } else {
/* 1549 */         index = CharSequenceUtils.indexOf(str, searchStr, index + 1);
/*      */       } 
/* 1551 */       if (index < 0) {
/* 1552 */         return index;
/*      */       }
/* 1554 */       found++;
/* 1555 */       if (found >= ordinal) {
/* 1556 */         return index;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr) {
/* 1585 */     return indexOfIgnoreCase(str, searchStr, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos) {
/* 1621 */     if (str == null || searchStr == null) {
/* 1622 */       return -1;
/*      */     }
/* 1624 */     if (startPos < 0) {
/* 1625 */       startPos = 0;
/*      */     }
/* 1627 */     int endLimit = str.length() - searchStr.length() + 1;
/* 1628 */     if (startPos > endLimit) {
/* 1629 */       return -1;
/*      */     }
/* 1631 */     if (searchStr.length() == 0) {
/* 1632 */       return startPos;
/*      */     }
/* 1634 */     for (int i = startPos; i < endLimit; i++) {
/* 1635 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1636 */         return i;
/*      */       }
/*      */     } 
/* 1639 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar) {
/* 1679 */     if (isEmpty(seq)) {
/* 1680 */       return -1;
/*      */     }
/* 1682 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, seq.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar, int startPos) {
/* 1730 */     if (isEmpty(seq)) {
/* 1731 */       return -1;
/*      */     }
/* 1733 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq) {
/* 1760 */     if (seq == null || searchSeq == null) {
/* 1761 */       return -1;
/*      */     }
/* 1763 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, seq.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastOrdinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal) {
/* 1801 */     return ordinalIndexOf(str, searchStr, ordinal, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq, int startPos) {
/* 1840 */     if (seq == null || searchSeq == null) {
/* 1841 */       return -1;
/*      */     }
/* 1843 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr) {
/* 1870 */     if (str == null || searchStr == null) {
/* 1871 */       return -1;
/*      */     }
/* 1873 */     return lastIndexOfIgnoreCase(str, searchStr, str.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos) {
/* 1909 */     if (str == null || searchStr == null) {
/* 1910 */       return -1;
/*      */     }
/* 1912 */     if (startPos > str.length() - searchStr.length()) {
/* 1913 */       startPos = str.length() - searchStr.length();
/*      */     }
/* 1915 */     if (startPos < 0) {
/* 1916 */       return -1;
/*      */     }
/* 1918 */     if (searchStr.length() == 0) {
/* 1919 */       return startPos;
/*      */     }
/*      */     
/* 1922 */     for (int i = startPos; i >= 0; i--) {
/* 1923 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1924 */         return i;
/*      */       }
/*      */     } 
/* 1927 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(CharSequence seq, int searchChar) {
/* 1953 */     if (isEmpty(seq)) {
/* 1954 */       return false;
/*      */     }
/* 1956 */     return (CharSequenceUtils.indexOf(seq, searchChar, 0) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(CharSequence seq, CharSequence searchSeq) {
/* 1982 */     if (seq == null || searchSeq == null) {
/* 1983 */       return false;
/*      */     }
/* 1985 */     return (CharSequenceUtils.indexOf(seq, searchSeq, 0) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsIgnoreCase(CharSequence str, CharSequence searchStr) {
/* 2013 */     if (str == null || searchStr == null) {
/* 2014 */       return false;
/*      */     }
/* 2016 */     int len = searchStr.length();
/* 2017 */     int max = str.length() - len;
/* 2018 */     for (int i = 0; i <= max; i++) {
/* 2019 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, len)) {
/* 2020 */         return true;
/*      */       }
/*      */     } 
/* 2023 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsWhitespace(CharSequence seq) {
/* 2038 */     if (isEmpty(seq)) {
/* 2039 */       return false;
/*      */     }
/* 2041 */     int strLen = seq.length();
/* 2042 */     for (int i = 0; i < strLen; i++) {
/* 2043 */       if (Character.isWhitespace(seq.charAt(i))) {
/* 2044 */         return true;
/*      */       }
/*      */     } 
/* 2047 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence cs, char... searchChars) {
/* 2076 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 2077 */       return -1;
/*      */     }
/* 2079 */     int csLen = cs.length();
/* 2080 */     int csLast = csLen - 1;
/* 2081 */     int searchLen = searchChars.length;
/* 2082 */     int searchLast = searchLen - 1;
/* 2083 */     for (int i = 0; i < csLen; i++) {
/* 2084 */       char ch = cs.charAt(i);
/* 2085 */       for (int j = 0; j < searchLen; j++) {
/* 2086 */         if (searchChars[j] == ch) {
/* 2087 */           if (i < csLast && j < searchLast && Character.isHighSurrogate(ch)) {
/*      */             
/* 2089 */             if (searchChars[j + 1] == cs.charAt(i + 1)) {
/* 2090 */               return i;
/*      */             }
/*      */           } else {
/* 2093 */             return i;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 2098 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence cs, String searchChars) {
/* 2125 */     if (isEmpty(cs) || isEmpty(searchChars)) {
/* 2126 */       return -1;
/*      */     }
/* 2128 */     return indexOfAny(cs, searchChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(CharSequence cs, char... searchChars) {
/* 2159 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 2160 */       return false;
/*      */     }
/* 2162 */     int csLength = cs.length();
/* 2163 */     int searchLength = searchChars.length;
/* 2164 */     int csLast = csLength - 1;
/* 2165 */     int searchLast = searchLength - 1;
/* 2166 */     for (int i = 0; i < csLength; i++) {
/* 2167 */       char ch = cs.charAt(i);
/* 2168 */       for (int j = 0; j < searchLength; j++) {
/* 2169 */         if (searchChars[j] == ch) {
/* 2170 */           if (Character.isHighSurrogate(ch)) {
/* 2171 */             if (j == searchLast)
/*      */             {
/* 2173 */               return true;
/*      */             }
/* 2175 */             if (i < csLast && searchChars[j + 1] == cs.charAt(i + 1)) {
/* 2176 */               return true;
/*      */             }
/*      */           } else {
/*      */             
/* 2180 */             return true;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 2185 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(CharSequence cs, CharSequence searchChars) {
/* 2220 */     if (searchChars == null) {
/* 2221 */       return false;
/*      */     }
/* 2223 */     return containsAny(cs, CharSequenceUtils.toCharArray(searchChars));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(CharSequence cs, CharSequence... searchCharSequences) {
/* 2252 */     if (isEmpty(cs) || ArrayUtils.isEmpty((Object[])searchCharSequences)) {
/* 2253 */       return false;
/*      */     }
/* 2255 */     for (CharSequence searchCharSequence : searchCharSequences) {
/* 2256 */       if (contains(cs, searchCharSequence)) {
/* 2257 */         return true;
/*      */       }
/*      */     } 
/* 2260 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(CharSequence cs, char... searchChars) {
/* 2290 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 2291 */       return -1;
/*      */     }
/* 2293 */     int csLen = cs.length();
/* 2294 */     int csLast = csLen - 1;
/* 2295 */     int searchLen = searchChars.length;
/* 2296 */     int searchLast = searchLen - 1;
/*      */     
/* 2298 */     for (int i = 0; i < csLen; i++) {
/* 2299 */       char ch = cs.charAt(i);
/* 2300 */       int j = 0; while (true) { if (j < searchLen) {
/* 2301 */           if (searchChars[j] == ch && (
/* 2302 */             i >= csLast || j >= searchLast || !Character.isHighSurrogate(ch) || 
/* 2303 */             searchChars[j + 1] == cs.charAt(i + 1))) {
/*      */             break;
/*      */           }
/*      */           
/*      */           j++;
/*      */           
/*      */           continue;
/*      */         } 
/* 2311 */         return i; }
/*      */     
/* 2313 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(CharSequence seq, CharSequence searchChars) {
/* 2340 */     if (isEmpty(seq) || isEmpty(searchChars)) {
/* 2341 */       return -1;
/*      */     }
/* 2343 */     int strLen = seq.length();
/* 2344 */     for (int i = 0; i < strLen; i++) {
/* 2345 */       char ch = seq.charAt(i);
/* 2346 */       boolean chFound = (CharSequenceUtils.indexOf(searchChars, ch, 0) >= 0);
/* 2347 */       if (i + 1 < strLen && Character.isHighSurrogate(ch)) {
/* 2348 */         char ch2 = seq.charAt(i + 1);
/* 2349 */         if (chFound && CharSequenceUtils.indexOf(searchChars, ch2, 0) < 0) {
/* 2350 */           return i;
/*      */         }
/*      */       }
/* 2353 */       else if (!chFound) {
/* 2354 */         return i;
/*      */       } 
/*      */     } 
/*      */     
/* 2358 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(CharSequence cs, char... valid) {
/* 2387 */     if (valid == null || cs == null) {
/* 2388 */       return false;
/*      */     }
/* 2390 */     if (cs.length() == 0) {
/* 2391 */       return true;
/*      */     }
/* 2393 */     if (valid.length == 0) {
/* 2394 */       return false;
/*      */     }
/* 2396 */     return (indexOfAnyBut(cs, valid) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(CharSequence cs, String validChars) {
/* 2423 */     if (cs == null || validChars == null) {
/* 2424 */       return false;
/*      */     }
/* 2426 */     return containsOnly(cs, validChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(CharSequence cs, char... searchChars) {
/* 2455 */     if (cs == null || searchChars == null) {
/* 2456 */       return true;
/*      */     }
/* 2458 */     int csLen = cs.length();
/* 2459 */     int csLast = csLen - 1;
/* 2460 */     int searchLen = searchChars.length;
/* 2461 */     int searchLast = searchLen - 1;
/* 2462 */     for (int i = 0; i < csLen; i++) {
/* 2463 */       char ch = cs.charAt(i);
/* 2464 */       for (int j = 0; j < searchLen; j++) {
/* 2465 */         if (searchChars[j] == ch) {
/* 2466 */           if (Character.isHighSurrogate(ch)) {
/* 2467 */             if (j == searchLast)
/*      */             {
/* 2469 */               return false;
/*      */             }
/* 2471 */             if (i < csLast && searchChars[j + 1] == cs.charAt(i + 1)) {
/* 2472 */               return false;
/*      */             }
/*      */           } else {
/*      */             
/* 2476 */             return false;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 2481 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(CharSequence cs, String invalidChars) {
/* 2508 */     if (cs == null || invalidChars == null) {
/* 2509 */       return true;
/*      */     }
/* 2511 */     return containsNone(cs, invalidChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence str, CharSequence... searchStrs) {
/* 2544 */     if (str == null || searchStrs == null) {
/* 2545 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 2549 */     int ret = Integer.MAX_VALUE;
/*      */     
/* 2551 */     int tmp = 0;
/* 2552 */     for (CharSequence search : searchStrs) {
/* 2553 */       if (search != null) {
/*      */ 
/*      */         
/* 2556 */         tmp = CharSequenceUtils.indexOf(str, search, 0);
/* 2557 */         if (tmp != -1)
/*      */         {
/*      */ 
/*      */           
/* 2561 */           if (tmp < ret)
/* 2562 */             ret = tmp; 
/*      */         }
/*      */       } 
/*      */     } 
/* 2566 */     return (ret == Integer.MAX_VALUE) ? -1 : ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfAny(CharSequence str, CharSequence... searchStrs) {
/* 2596 */     if (str == null || searchStrs == null) {
/* 2597 */       return -1;
/*      */     }
/* 2599 */     int ret = -1;
/* 2600 */     int tmp = 0;
/* 2601 */     for (CharSequence search : searchStrs) {
/* 2602 */       if (search != null) {
/*      */ 
/*      */         
/* 2605 */         tmp = CharSequenceUtils.lastIndexOf(str, search, str.length());
/* 2606 */         if (tmp > ret)
/* 2607 */           ret = tmp; 
/*      */       } 
/*      */     } 
/* 2610 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start) {
/* 2640 */     if (str == null) {
/* 2641 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2645 */     if (start < 0) {
/* 2646 */       start = str.length() + start;
/*      */     }
/*      */     
/* 2649 */     if (start < 0) {
/* 2650 */       start = 0;
/*      */     }
/* 2652 */     if (start > str.length()) {
/* 2653 */       return "";
/*      */     }
/*      */     
/* 2656 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start, int end) {
/* 2695 */     if (str == null) {
/* 2696 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2700 */     if (end < 0) {
/* 2701 */       end = str.length() + end;
/*      */     }
/* 2703 */     if (start < 0) {
/* 2704 */       start = str.length() + start;
/*      */     }
/*      */ 
/*      */     
/* 2708 */     if (end > str.length()) {
/* 2709 */       end = str.length();
/*      */     }
/*      */ 
/*      */     
/* 2713 */     if (start > end) {
/* 2714 */       return "";
/*      */     }
/*      */     
/* 2717 */     if (start < 0) {
/* 2718 */       start = 0;
/*      */     }
/* 2720 */     if (end < 0) {
/* 2721 */       end = 0;
/*      */     }
/*      */     
/* 2724 */     return str.substring(start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String left(String str, int len) {
/* 2750 */     if (str == null) {
/* 2751 */       return null;
/*      */     }
/* 2753 */     if (len < 0) {
/* 2754 */       return "";
/*      */     }
/* 2756 */     if (str.length() <= len) {
/* 2757 */       return str;
/*      */     }
/* 2759 */     return str.substring(0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String right(String str, int len) {
/* 2783 */     if (str == null) {
/* 2784 */       return null;
/*      */     }
/* 2786 */     if (len < 0) {
/* 2787 */       return "";
/*      */     }
/* 2789 */     if (str.length() <= len) {
/* 2790 */       return str;
/*      */     }
/* 2792 */     return str.substring(str.length() - len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mid(String str, int pos, int len) {
/* 2821 */     if (str == null) {
/* 2822 */       return null;
/*      */     }
/* 2824 */     if (len < 0 || pos > str.length()) {
/* 2825 */       return "";
/*      */     }
/* 2827 */     if (pos < 0) {
/* 2828 */       pos = 0;
/*      */     }
/* 2830 */     if (str.length() <= pos + len) {
/* 2831 */       return str.substring(pos);
/*      */     }
/* 2833 */     return str.substring(pos, pos + len);
/*      */   }
/*      */   
/*      */   private static StringBuilder newStringBuilder(int noOfItems) {
/* 2837 */     return new StringBuilder(noOfItems * 16);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBefore(String str, String separator) {
/* 2870 */     if (isEmpty(str) || separator == null) {
/* 2871 */       return str;
/*      */     }
/* 2873 */     if (separator.isEmpty()) {
/* 2874 */       return "";
/*      */     }
/* 2876 */     int pos = str.indexOf(separator);
/* 2877 */     if (pos == -1) {
/* 2878 */       return str;
/*      */     }
/* 2880 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfter(String str, String separator) {
/* 2912 */     if (isEmpty(str)) {
/* 2913 */       return str;
/*      */     }
/* 2915 */     if (separator == null) {
/* 2916 */       return "";
/*      */     }
/* 2918 */     int pos = str.indexOf(separator);
/* 2919 */     if (pos == -1) {
/* 2920 */       return "";
/*      */     }
/* 2922 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBeforeLast(String str, String separator) {
/* 2953 */     if (isEmpty(str) || isEmpty(separator)) {
/* 2954 */       return str;
/*      */     }
/* 2956 */     int pos = str.lastIndexOf(separator);
/* 2957 */     if (pos == -1) {
/* 2958 */       return str;
/*      */     }
/* 2960 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfterLast(String str, String separator) {
/* 2993 */     if (isEmpty(str)) {
/* 2994 */       return str;
/*      */     }
/* 2996 */     if (isEmpty(separator)) {
/* 2997 */       return "";
/*      */     }
/* 2999 */     int pos = str.lastIndexOf(separator);
/* 3000 */     if (pos == -1 || pos == str.length() - separator.length()) {
/* 3001 */       return "";
/*      */     }
/* 3003 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String tag) {
/* 3030 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String open, String close) {
/* 3061 */     if (str == null || open == null || close == null) {
/* 3062 */       return null;
/*      */     }
/* 3064 */     int start = str.indexOf(open);
/* 3065 */     if (start != -1) {
/* 3066 */       int end = str.indexOf(close, start + open.length());
/* 3067 */       if (end != -1) {
/* 3068 */         return str.substring(start + open.length(), end);
/*      */       }
/*      */     } 
/* 3071 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] substringsBetween(String str, String open, String close) {
/* 3097 */     if (str == null || isEmpty(open) || isEmpty(close)) {
/* 3098 */       return null;
/*      */     }
/* 3100 */     int strLen = str.length();
/* 3101 */     if (strLen == 0) {
/* 3102 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3104 */     int closeLen = close.length();
/* 3105 */     int openLen = open.length();
/* 3106 */     List<String> list = new ArrayList<>();
/* 3107 */     int pos = 0;
/* 3108 */     while (pos < strLen - closeLen) {
/* 3109 */       int start = str.indexOf(open, pos);
/* 3110 */       if (start < 0) {
/*      */         break;
/*      */       }
/* 3113 */       start += openLen;
/* 3114 */       int end = str.indexOf(close, start);
/* 3115 */       if (end < 0) {
/*      */         break;
/*      */       }
/* 3118 */       list.add(str.substring(start, end));
/* 3119 */       pos = end + closeLen;
/*      */     } 
/* 3121 */     if (list.isEmpty()) {
/* 3122 */       return null;
/*      */     }
/* 3124 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str) {
/* 3155 */     return split(str, null, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, char separatorChar) {
/* 3183 */     return splitWorker(str, separatorChar, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, String separatorChars) {
/* 3212 */     return splitWorker(str, separatorChars, -1, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, String separatorChars, int max) {
/* 3246 */     return splitWorker(str, separatorChars, max, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparator(String str, String separator) {
/* 3273 */     return splitByWholeSeparatorWorker(str, separator, -1, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparator(String str, String separator, int max) {
/* 3304 */     return splitByWholeSeparatorWorker(str, separator, max, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator) {
/* 3333 */     return splitByWholeSeparatorWorker(str, separator, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator, int max) {
/* 3366 */     return splitByWholeSeparatorWorker(str, separator, max, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitByWholeSeparatorWorker(String str, String separator, int max, boolean preserveAllTokens) {
/* 3385 */     if (str == null) {
/* 3386 */       return null;
/*      */     }
/*      */     
/* 3389 */     int len = str.length();
/*      */     
/* 3391 */     if (len == 0) {
/* 3392 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*      */     
/* 3395 */     if (separator == null || "".equals(separator))
/*      */     {
/* 3397 */       return splitWorker(str, null, max, preserveAllTokens);
/*      */     }
/*      */     
/* 3400 */     int separatorLength = separator.length();
/*      */     
/* 3402 */     ArrayList<String> substrings = new ArrayList<>();
/* 3403 */     int numberOfSubstrings = 0;
/* 3404 */     int beg = 0;
/* 3405 */     int end = 0;
/* 3406 */     while (end < len) {
/* 3407 */       end = str.indexOf(separator, beg);
/*      */       
/* 3409 */       if (end > -1) {
/* 3410 */         if (end > beg) {
/* 3411 */           numberOfSubstrings++;
/*      */           
/* 3413 */           if (numberOfSubstrings == max) {
/* 3414 */             end = len;
/* 3415 */             substrings.add(str.substring(beg));
/*      */             
/*      */             continue;
/*      */           } 
/* 3419 */           substrings.add(str.substring(beg, end));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3424 */           beg = end + separatorLength;
/*      */           
/*      */           continue;
/*      */         } 
/* 3428 */         if (preserveAllTokens) {
/* 3429 */           numberOfSubstrings++;
/* 3430 */           if (numberOfSubstrings == max) {
/* 3431 */             end = len;
/* 3432 */             substrings.add(str.substring(beg));
/*      */           } else {
/* 3434 */             substrings.add("");
/*      */           } 
/*      */         } 
/* 3437 */         beg = end + separatorLength;
/*      */         
/*      */         continue;
/*      */       } 
/* 3441 */       substrings.add(str.substring(beg));
/* 3442 */       end = len;
/*      */     } 
/*      */ 
/*      */     
/* 3446 */     return substrings.<String>toArray(new String[substrings.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str) {
/* 3475 */     return splitWorker(str, null, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, char separatorChar) {
/* 3511 */     return splitWorker(str, separatorChar, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens) {
/* 3529 */     if (str == null) {
/* 3530 */       return null;
/*      */     }
/* 3532 */     int len = str.length();
/* 3533 */     if (len == 0) {
/* 3534 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3536 */     List<String> list = new ArrayList<>();
/* 3537 */     int i = 0, start = 0;
/* 3538 */     boolean match = false;
/* 3539 */     boolean lastMatch = false;
/* 3540 */     while (i < len) {
/* 3541 */       if (str.charAt(i) == separatorChar) {
/* 3542 */         if (match || preserveAllTokens) {
/* 3543 */           list.add(str.substring(start, i));
/* 3544 */           match = false;
/* 3545 */           lastMatch = true;
/*      */         } 
/* 3547 */         start = ++i;
/*      */         continue;
/*      */       } 
/* 3550 */       lastMatch = false;
/* 3551 */       match = true;
/* 3552 */       i++;
/*      */     } 
/* 3554 */     if (match || (preserveAllTokens && lastMatch)) {
/* 3555 */       list.add(str.substring(start, i));
/*      */     }
/* 3557 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars) {
/* 3594 */     return splitWorker(str, separatorChars, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars, int max) {
/* 3634 */     return splitWorker(str, separatorChars, max, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens) {
/* 3656 */     if (str == null) {
/* 3657 */       return null;
/*      */     }
/* 3659 */     int len = str.length();
/* 3660 */     if (len == 0) {
/* 3661 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3663 */     List<String> list = new ArrayList<>();
/* 3664 */     int sizePlus1 = 1;
/* 3665 */     int i = 0, start = 0;
/* 3666 */     boolean match = false;
/* 3667 */     boolean lastMatch = false;
/* 3668 */     if (separatorChars == null) {
/*      */       
/* 3670 */       while (i < len) {
/* 3671 */         if (Character.isWhitespace(str.charAt(i))) {
/* 3672 */           if (match || preserveAllTokens) {
/* 3673 */             lastMatch = true;
/* 3674 */             if (sizePlus1++ == max) {
/* 3675 */               i = len;
/* 3676 */               lastMatch = false;
/*      */             } 
/* 3678 */             list.add(str.substring(start, i));
/* 3679 */             match = false;
/*      */           } 
/* 3681 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3684 */         lastMatch = false;
/* 3685 */         match = true;
/* 3686 */         i++;
/*      */       } 
/* 3688 */     } else if (separatorChars.length() == 1) {
/*      */       
/* 3690 */       char sep = separatorChars.charAt(0);
/* 3691 */       while (i < len) {
/* 3692 */         if (str.charAt(i) == sep) {
/* 3693 */           if (match || preserveAllTokens) {
/* 3694 */             lastMatch = true;
/* 3695 */             if (sizePlus1++ == max) {
/* 3696 */               i = len;
/* 3697 */               lastMatch = false;
/*      */             } 
/* 3699 */             list.add(str.substring(start, i));
/* 3700 */             match = false;
/*      */           } 
/* 3702 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3705 */         lastMatch = false;
/* 3706 */         match = true;
/* 3707 */         i++;
/*      */       } 
/*      */     } else {
/*      */       
/* 3711 */       while (i < len) {
/* 3712 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/* 3713 */           if (match || preserveAllTokens) {
/* 3714 */             lastMatch = true;
/* 3715 */             if (sizePlus1++ == max) {
/* 3716 */               i = len;
/* 3717 */               lastMatch = false;
/*      */             } 
/* 3719 */             list.add(str.substring(start, i));
/* 3720 */             match = false;
/*      */           } 
/* 3722 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3725 */         lastMatch = false;
/* 3726 */         match = true;
/* 3727 */         i++;
/*      */       } 
/*      */     } 
/* 3730 */     if (match || (preserveAllTokens && lastMatch)) {
/* 3731 */       list.add(str.substring(start, i));
/*      */     }
/* 3733 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByCharacterType(String str) {
/* 3756 */     return splitByCharacterType(str, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByCharacterTypeCamelCase(String str) {
/* 3784 */     return splitByCharacterType(str, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitByCharacterType(String str, boolean camelCase) {
/* 3802 */     if (str == null) {
/* 3803 */       return null;
/*      */     }
/* 3805 */     if (str.isEmpty()) {
/* 3806 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3808 */     char[] c = str.toCharArray();
/* 3809 */     List<String> list = new ArrayList<>();
/* 3810 */     int tokenStart = 0;
/* 3811 */     int currentType = Character.getType(c[tokenStart]);
/* 3812 */     for (int pos = tokenStart + 1; pos < c.length; pos++) {
/* 3813 */       int type = Character.getType(c[pos]);
/* 3814 */       if (type != currentType) {
/*      */ 
/*      */         
/* 3817 */         if (camelCase && type == 2 && currentType == 1) {
/* 3818 */           int newTokenStart = pos - 1;
/* 3819 */           if (newTokenStart != tokenStart) {
/* 3820 */             list.add(new String(c, tokenStart, newTokenStart - tokenStart));
/* 3821 */             tokenStart = newTokenStart;
/*      */           } 
/*      */         } else {
/* 3824 */           list.add(new String(c, tokenStart, pos - tokenStart));
/* 3825 */           tokenStart = pos;
/*      */         } 
/* 3827 */         currentType = type;
/*      */       } 
/* 3829 */     }  list.add(new String(c, tokenStart, c.length - tokenStart));
/* 3830 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T> String join(T... elements) {
/* 3859 */     return join((Object[])elements, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, char separator) {
/* 3885 */     if (array == null) {
/* 3886 */       return null;
/*      */     }
/* 3888 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(long[] array, char separator) {
/* 3917 */     if (array == null) {
/* 3918 */       return null;
/*      */     }
/* 3920 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(int[] array, char separator) {
/* 3949 */     if (array == null) {
/* 3950 */       return null;
/*      */     }
/* 3952 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(short[] array, char separator) {
/* 3981 */     if (array == null) {
/* 3982 */       return null;
/*      */     }
/* 3984 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(byte[] array, char separator) {
/* 4013 */     if (array == null) {
/* 4014 */       return null;
/*      */     }
/* 4016 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(char[] array, char separator) {
/* 4045 */     if (array == null) {
/* 4046 */       return null;
/*      */     }
/* 4048 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(float[] array, char separator) {
/* 4077 */     if (array == null) {
/* 4078 */       return null;
/*      */     }
/* 4080 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(double[] array, char separator) {
/* 4109 */     if (array == null) {
/* 4110 */       return null;
/*      */     }
/* 4112 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, char separator, int startIndex, int endIndex) {
/* 4143 */     if (array == null) {
/* 4144 */       return null;
/*      */     }
/* 4146 */     int noOfItems = endIndex - startIndex;
/* 4147 */     if (noOfItems <= 0) {
/* 4148 */       return "";
/*      */     }
/* 4150 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4151 */     for (int i = startIndex; i < endIndex; i++) {
/* 4152 */       if (i > startIndex) {
/* 4153 */         buf.append(separator);
/*      */       }
/* 4155 */       if (array[i] != null) {
/* 4156 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 4159 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(long[] array, char separator, int startIndex, int endIndex) {
/* 4194 */     if (array == null) {
/* 4195 */       return null;
/*      */     }
/* 4197 */     int noOfItems = endIndex - startIndex;
/* 4198 */     if (noOfItems <= 0) {
/* 4199 */       return "";
/*      */     }
/* 4201 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4202 */     for (int i = startIndex; i < endIndex; i++) {
/* 4203 */       if (i > startIndex) {
/* 4204 */         buf.append(separator);
/*      */       }
/* 4206 */       buf.append(array[i]);
/*      */     } 
/* 4208 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(int[] array, char separator, int startIndex, int endIndex) {
/* 4243 */     if (array == null) {
/* 4244 */       return null;
/*      */     }
/* 4246 */     int noOfItems = endIndex - startIndex;
/* 4247 */     if (noOfItems <= 0) {
/* 4248 */       return "";
/*      */     }
/* 4250 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4251 */     for (int i = startIndex; i < endIndex; i++) {
/* 4252 */       if (i > startIndex) {
/* 4253 */         buf.append(separator);
/*      */       }
/* 4255 */       buf.append(array[i]);
/*      */     } 
/* 4257 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(byte[] array, char separator, int startIndex, int endIndex) {
/* 4292 */     if (array == null) {
/* 4293 */       return null;
/*      */     }
/* 4295 */     int noOfItems = endIndex - startIndex;
/* 4296 */     if (noOfItems <= 0) {
/* 4297 */       return "";
/*      */     }
/* 4299 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4300 */     for (int i = startIndex; i < endIndex; i++) {
/* 4301 */       if (i > startIndex) {
/* 4302 */         buf.append(separator);
/*      */       }
/* 4304 */       buf.append(array[i]);
/*      */     } 
/* 4306 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(short[] array, char separator, int startIndex, int endIndex) {
/* 4341 */     if (array == null) {
/* 4342 */       return null;
/*      */     }
/* 4344 */     int noOfItems = endIndex - startIndex;
/* 4345 */     if (noOfItems <= 0) {
/* 4346 */       return "";
/*      */     }
/* 4348 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4349 */     for (int i = startIndex; i < endIndex; i++) {
/* 4350 */       if (i > startIndex) {
/* 4351 */         buf.append(separator);
/*      */       }
/* 4353 */       buf.append(array[i]);
/*      */     } 
/* 4355 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(char[] array, char separator, int startIndex, int endIndex) {
/* 4390 */     if (array == null) {
/* 4391 */       return null;
/*      */     }
/* 4393 */     int noOfItems = endIndex - startIndex;
/* 4394 */     if (noOfItems <= 0) {
/* 4395 */       return "";
/*      */     }
/* 4397 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4398 */     for (int i = startIndex; i < endIndex; i++) {
/* 4399 */       if (i > startIndex) {
/* 4400 */         buf.append(separator);
/*      */       }
/* 4402 */       buf.append(array[i]);
/*      */     } 
/* 4404 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(double[] array, char separator, int startIndex, int endIndex) {
/* 4439 */     if (array == null) {
/* 4440 */       return null;
/*      */     }
/* 4442 */     int noOfItems = endIndex - startIndex;
/* 4443 */     if (noOfItems <= 0) {
/* 4444 */       return "";
/*      */     }
/* 4446 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4447 */     for (int i = startIndex; i < endIndex; i++) {
/* 4448 */       if (i > startIndex) {
/* 4449 */         buf.append(separator);
/*      */       }
/* 4451 */       buf.append(array[i]);
/*      */     } 
/* 4453 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(float[] array, char separator, int startIndex, int endIndex) {
/* 4488 */     if (array == null) {
/* 4489 */       return null;
/*      */     }
/* 4491 */     int noOfItems = endIndex - startIndex;
/* 4492 */     if (noOfItems <= 0) {
/* 4493 */       return "";
/*      */     }
/* 4495 */     StringBuilder buf = newStringBuilder(noOfItems);
/* 4496 */     for (int i = startIndex; i < endIndex; i++) {
/* 4497 */       if (i > startIndex) {
/* 4498 */         buf.append(separator);
/*      */       }
/* 4500 */       buf.append(array[i]);
/*      */     } 
/* 4502 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, String separator) {
/* 4530 */     if (array == null) {
/* 4531 */       return null;
/*      */     }
/* 4533 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, String separator, int startIndex, int endIndex) {
/* 4572 */     if (array == null) {
/* 4573 */       return null;
/*      */     }
/* 4575 */     if (separator == null) {
/* 4576 */       separator = "";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4581 */     int noOfItems = endIndex - startIndex;
/* 4582 */     if (noOfItems <= 0) {
/* 4583 */       return "";
/*      */     }
/*      */     
/* 4586 */     StringBuilder buf = newStringBuilder(noOfItems);
/*      */     
/* 4588 */     for (int i = startIndex; i < endIndex; i++) {
/* 4589 */       if (i > startIndex) {
/* 4590 */         buf.append(separator);
/*      */       }
/* 4592 */       if (array[i] != null) {
/* 4593 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 4596 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator<?> iterator, char separator) {
/* 4616 */     if (iterator == null) {
/* 4617 */       return null;
/*      */     }
/* 4619 */     if (!iterator.hasNext()) {
/* 4620 */       return "";
/*      */     }
/* 4622 */     Object first = iterator.next();
/* 4623 */     if (!iterator.hasNext()) {
/* 4624 */       return Objects.toString(first, "");
/*      */     }
/*      */ 
/*      */     
/* 4628 */     StringBuilder buf = new StringBuilder(256);
/* 4629 */     if (first != null) {
/* 4630 */       buf.append(first);
/*      */     }
/*      */     
/* 4633 */     while (iterator.hasNext()) {
/* 4634 */       buf.append(separator);
/* 4635 */       Object obj = iterator.next();
/* 4636 */       if (obj != null) {
/* 4637 */         buf.append(obj);
/*      */       }
/*      */     } 
/*      */     
/* 4641 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator<?> iterator, String separator) {
/* 4660 */     if (iterator == null) {
/* 4661 */       return null;
/*      */     }
/* 4663 */     if (!iterator.hasNext()) {
/* 4664 */       return "";
/*      */     }
/* 4666 */     Object first = iterator.next();
/* 4667 */     if (!iterator.hasNext()) {
/* 4668 */       return Objects.toString(first, "");
/*      */     }
/*      */ 
/*      */     
/* 4672 */     StringBuilder buf = new StringBuilder(256);
/* 4673 */     if (first != null) {
/* 4674 */       buf.append(first);
/*      */     }
/*      */     
/* 4677 */     while (iterator.hasNext()) {
/* 4678 */       if (separator != null) {
/* 4679 */         buf.append(separator);
/*      */       }
/* 4681 */       Object obj = iterator.next();
/* 4682 */       if (obj != null) {
/* 4683 */         buf.append(obj);
/*      */       }
/*      */     } 
/* 4686 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterable<?> iterable, char separator) {
/* 4704 */     if (iterable == null) {
/* 4705 */       return null;
/*      */     }
/* 4707 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterable<?> iterable, String separator) {
/* 4725 */     if (iterable == null) {
/* 4726 */       return null;
/*      */     }
/* 4728 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(List<?> list, char separator, int startIndex, int endIndex) {
/* 4758 */     if (list == null) {
/* 4759 */       return null;
/*      */     }
/* 4761 */     int noOfItems = endIndex - startIndex;
/* 4762 */     if (noOfItems <= 0) {
/* 4763 */       return "";
/*      */     }
/* 4765 */     List<?> subList = list.subList(startIndex, endIndex);
/* 4766 */     return join(subList.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(List<?> list, String separator, int startIndex, int endIndex) {
/* 4796 */     if (list == null) {
/* 4797 */       return null;
/*      */     }
/* 4799 */     int noOfItems = endIndex - startIndex;
/* 4800 */     if (noOfItems <= 0) {
/* 4801 */       return "";
/*      */     }
/* 4803 */     List<?> subList = list.subList(startIndex, endIndex);
/* 4804 */     return join(subList.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String joinWith(String separator, Object... objects) {
/* 4828 */     if (objects == null) {
/* 4829 */       throw new IllegalArgumentException("Object varargs must not be null");
/*      */     }
/*      */     
/* 4832 */     String sanitizedSeparator = defaultString(separator);
/*      */     
/* 4834 */     StringBuilder result = new StringBuilder();
/*      */     
/* 4836 */     Iterator<Object> iterator = Arrays.<Object>asList(objects).iterator();
/* 4837 */     while (iterator.hasNext()) {
/* 4838 */       String value = Objects.toString(iterator.next(), "");
/* 4839 */       result.append(value);
/*      */       
/* 4841 */       if (iterator.hasNext()) {
/* 4842 */         result.append(sanitizedSeparator);
/*      */       }
/*      */     } 
/*      */     
/* 4846 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String deleteWhitespace(String str) {
/* 4866 */     if (isEmpty(str)) {
/* 4867 */       return str;
/*      */     }
/* 4869 */     int sz = str.length();
/* 4870 */     char[] chs = new char[sz];
/* 4871 */     int count = 0;
/* 4872 */     for (int i = 0; i < sz; i++) {
/* 4873 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 4874 */         chs[count++] = str.charAt(i);
/*      */       }
/*      */     } 
/* 4877 */     if (count == sz) {
/* 4878 */       return str;
/*      */     }
/* 4880 */     return new String(chs, 0, count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeStart(String str, String remove) {
/* 4910 */     if (isEmpty(str) || isEmpty(remove)) {
/* 4911 */       return str;
/*      */     }
/* 4913 */     if (str.startsWith(remove)) {
/* 4914 */       return str.substring(remove.length());
/*      */     }
/* 4916 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeStartIgnoreCase(String str, String remove) {
/* 4945 */     if (isEmpty(str) || isEmpty(remove)) {
/* 4946 */       return str;
/*      */     }
/* 4948 */     if (startsWithIgnoreCase(str, remove)) {
/* 4949 */       return str.substring(remove.length());
/*      */     }
/* 4951 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeEnd(String str, String remove) {
/* 4979 */     if (isEmpty(str) || isEmpty(remove)) {
/* 4980 */       return str;
/*      */     }
/* 4982 */     if (str.endsWith(remove)) {
/* 4983 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 4985 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeEndIgnoreCase(String str, String remove) {
/* 5015 */     if (isEmpty(str) || isEmpty(remove)) {
/* 5016 */       return str;
/*      */     }
/* 5018 */     if (endsWithIgnoreCase(str, remove)) {
/* 5019 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 5021 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, String remove) {
/* 5048 */     if (isEmpty(str) || isEmpty(remove)) {
/* 5049 */       return str;
/*      */     }
/* 5051 */     return replace(str, remove, "", -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeIgnoreCase(String str, String remove) {
/* 5088 */     if (isEmpty(str) || isEmpty(remove)) {
/* 5089 */       return str;
/*      */     }
/* 5091 */     return replaceIgnoreCase(str, remove, "", -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, char remove) {
/* 5114 */     if (isEmpty(str) || str.indexOf(remove) == -1) {
/* 5115 */       return str;
/*      */     }
/* 5117 */     char[] chars = str.toCharArray();
/* 5118 */     int pos = 0;
/* 5119 */     for (int i = 0; i < chars.length; i++) {
/* 5120 */       if (chars[i] != remove) {
/* 5121 */         chars[pos++] = chars[i];
/*      */       }
/*      */     } 
/* 5124 */     return new String(chars, 0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String removeAll(String text, String regex) {
/* 5174 */     return RegExUtils.removeAll(text, regex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String removeFirst(String text, String regex) {
/* 5223 */     return replaceFirst(text, regex, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceOnce(String text, String searchString, String replacement) {
/* 5252 */     return replace(text, searchString, replacement, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceOnceIgnoreCase(String text, String searchString, String replacement) {
/* 5281 */     return replaceIgnoreCase(text, searchString, replacement, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String replacePattern(String source, String regex, String replacement) {
/* 5327 */     return RegExUtils.replacePattern(source, regex, replacement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String removePattern(String source, String regex) {
/* 5364 */     return RegExUtils.removePattern(source, regex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String replaceAll(String text, String regex, String replacement) {
/* 5419 */     return RegExUtils.replaceAll(text, regex, replacement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String replaceFirst(String text, String regex, String replacement) {
/* 5472 */     return RegExUtils.replaceFirst(text, regex, replacement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replace(String text, String searchString, String replacement) {
/* 5499 */     return replace(text, searchString, replacement, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceIgnoreCase(String text, String searchString, String replacement) {
/* 5527 */     return replaceIgnoreCase(text, searchString, replacement, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replace(String text, String searchString, String replacement, int max) {
/* 5559 */     return replace(text, searchString, replacement, max, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String replace(String text, String searchString, String replacement, int max, boolean ignoreCase) {
/* 5594 */     if (isEmpty(text) || isEmpty(searchString) || replacement == null || max == 0) {
/* 5595 */       return text;
/*      */     }
/* 5597 */     String searchText = text;
/* 5598 */     if (ignoreCase) {
/* 5599 */       searchText = text.toLowerCase();
/* 5600 */       searchString = searchString.toLowerCase();
/*      */     } 
/* 5602 */     int start = 0;
/* 5603 */     int end = searchText.indexOf(searchString, start);
/* 5604 */     if (end == -1) {
/* 5605 */       return text;
/*      */     }
/* 5607 */     int replLength = searchString.length();
/* 5608 */     int increase = replacement.length() - replLength;
/* 5609 */     increase = (increase < 0) ? 0 : increase;
/* 5610 */     increase *= (max < 0) ? 16 : ((max > 64) ? 64 : max);
/* 5611 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/* 5612 */     while (end != -1) {
/* 5613 */       buf.append(text, start, end).append(replacement);
/* 5614 */       start = end + replLength;
/* 5615 */       if (--max == 0) {
/*      */         break;
/*      */       }
/* 5618 */       end = searchText.indexOf(searchString, start);
/*      */     } 
/* 5620 */     buf.append(text, start, text.length());
/* 5621 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceIgnoreCase(String text, String searchString, String replacement, int max) {
/* 5654 */     return replace(text, searchString, replacement, max, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceEach(String text, String[] searchList, String[] replacementList) {
/* 5697 */     return replaceEach(text, searchList, replacementList, false, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceEachRepeatedly(String text, String[] searchList, String[] replacementList) {
/* 5745 */     int timeToLive = (searchList == null) ? 0 : searchList.length;
/* 5746 */     return replaceEach(text, searchList, replacementList, true, timeToLive);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String replaceEach(String text, String[] searchList, String[] replacementList, boolean repeat, int timeToLive) {
/* 5805 */     if (text == null || text.isEmpty() || searchList == null || searchList.length == 0 || replacementList == null || replacementList.length == 0)
/*      */     {
/* 5807 */       return text;
/*      */     }
/*      */ 
/*      */     
/* 5811 */     if (timeToLive < 0) {
/* 5812 */       throw new IllegalStateException("Aborting to protect against StackOverflowError - output of one loop is the input of another");
/*      */     }
/*      */ 
/*      */     
/* 5816 */     int searchLength = searchList.length;
/* 5817 */     int replacementLength = replacementList.length;
/*      */ 
/*      */     
/* 5820 */     if (searchLength != replacementLength) {
/* 5821 */       throw new IllegalArgumentException("Search and Replace array lengths don't match: " + searchLength + " vs " + replacementLength);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5828 */     boolean[] noMoreMatchesForReplIndex = new boolean[searchLength];
/*      */ 
/*      */     
/* 5831 */     int textIndex = -1;
/* 5832 */     int replaceIndex = -1;
/* 5833 */     int tempIndex = -1;
/*      */ 
/*      */ 
/*      */     
/* 5837 */     for (int i = 0; i < searchLength; i++) {
/* 5838 */       if (!noMoreMatchesForReplIndex[i] && searchList[i] != null && 
/* 5839 */         !searchList[i].isEmpty() && replacementList[i] != null) {
/*      */ 
/*      */         
/* 5842 */         tempIndex = text.indexOf(searchList[i]);
/*      */ 
/*      */         
/* 5845 */         if (tempIndex == -1) {
/* 5846 */           noMoreMatchesForReplIndex[i] = true;
/*      */         }
/* 5848 */         else if (textIndex == -1 || tempIndex < textIndex) {
/* 5849 */           textIndex = tempIndex;
/* 5850 */           replaceIndex = i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 5857 */     if (textIndex == -1) {
/* 5858 */       return text;
/*      */     }
/*      */     
/* 5861 */     int start = 0;
/*      */ 
/*      */     
/* 5864 */     int increase = 0;
/*      */ 
/*      */     
/* 5867 */     for (int j = 0; j < searchList.length; j++) {
/* 5868 */       if (searchList[j] != null && replacementList[j] != null) {
/*      */ 
/*      */         
/* 5871 */         int greater = replacementList[j].length() - searchList[j].length();
/* 5872 */         if (greater > 0) {
/* 5873 */           increase += 3 * greater;
/*      */         }
/*      */       } 
/*      */     } 
/* 5877 */     increase = Math.min(increase, text.length() / 5);
/*      */     
/* 5879 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/*      */     
/* 5881 */     while (textIndex != -1) {
/*      */       int m;
/* 5883 */       for (m = start; m < textIndex; m++) {
/* 5884 */         buf.append(text.charAt(m));
/*      */       }
/* 5886 */       buf.append(replacementList[replaceIndex]);
/*      */       
/* 5888 */       start = textIndex + searchList[replaceIndex].length();
/*      */       
/* 5890 */       textIndex = -1;
/* 5891 */       replaceIndex = -1;
/* 5892 */       tempIndex = -1;
/*      */ 
/*      */       
/* 5895 */       for (m = 0; m < searchLength; m++) {
/* 5896 */         if (!noMoreMatchesForReplIndex[m] && searchList[m] != null && 
/* 5897 */           !searchList[m].isEmpty() && replacementList[m] != null) {
/*      */ 
/*      */           
/* 5900 */           tempIndex = text.indexOf(searchList[m], start);
/*      */ 
/*      */           
/* 5903 */           if (tempIndex == -1) {
/* 5904 */             noMoreMatchesForReplIndex[m] = true;
/*      */           }
/* 5906 */           else if (textIndex == -1 || tempIndex < textIndex) {
/* 5907 */             textIndex = tempIndex;
/* 5908 */             replaceIndex = m;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5915 */     int textLength = text.length();
/* 5916 */     for (int k = start; k < textLength; k++) {
/* 5917 */       buf.append(text.charAt(k));
/*      */     }
/* 5919 */     String result = buf.toString();
/* 5920 */     if (!repeat) {
/* 5921 */       return result;
/*      */     }
/*      */     
/* 5924 */     return replaceEach(result, searchList, replacementList, repeat, timeToLive - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, char searchChar, char replaceChar) {
/* 5950 */     if (str == null) {
/* 5951 */       return null;
/*      */     }
/* 5953 */     return str.replace(searchChar, replaceChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, String searchChars, String replaceChars) {
/* 5993 */     if (isEmpty(str) || isEmpty(searchChars)) {
/* 5994 */       return str;
/*      */     }
/* 5996 */     if (replaceChars == null) {
/* 5997 */       replaceChars = "";
/*      */     }
/* 5999 */     boolean modified = false;
/* 6000 */     int replaceCharsLength = replaceChars.length();
/* 6001 */     int strLength = str.length();
/* 6002 */     StringBuilder buf = new StringBuilder(strLength);
/* 6003 */     for (int i = 0; i < strLength; i++) {
/* 6004 */       char ch = str.charAt(i);
/* 6005 */       int index = searchChars.indexOf(ch);
/* 6006 */       if (index >= 0) {
/* 6007 */         modified = true;
/* 6008 */         if (index < replaceCharsLength) {
/* 6009 */           buf.append(replaceChars.charAt(index));
/*      */         }
/*      */       } else {
/* 6012 */         buf.append(ch);
/*      */       } 
/*      */     } 
/* 6015 */     if (modified) {
/* 6016 */       return buf.toString();
/*      */     }
/* 6018 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String overlay(String str, String overlay, int start, int end) {
/* 6053 */     if (str == null) {
/* 6054 */       return null;
/*      */     }
/* 6056 */     if (overlay == null) {
/* 6057 */       overlay = "";
/*      */     }
/* 6059 */     int len = str.length();
/* 6060 */     if (start < 0) {
/* 6061 */       start = 0;
/*      */     }
/* 6063 */     if (start > len) {
/* 6064 */       start = len;
/*      */     }
/* 6066 */     if (end < 0) {
/* 6067 */       end = 0;
/*      */     }
/* 6069 */     if (end > len) {
/* 6070 */       end = len;
/*      */     }
/* 6072 */     if (start > end) {
/* 6073 */       int temp = start;
/* 6074 */       start = end;
/* 6075 */       end = temp;
/*      */     } 
/* 6077 */     return str.substring(0, start) + overlay + str
/*      */       
/* 6079 */       .substring(end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chomp(String str) {
/* 6110 */     if (isEmpty(str)) {
/* 6111 */       return str;
/*      */     }
/*      */     
/* 6114 */     if (str.length() == 1) {
/* 6115 */       char ch = str.charAt(0);
/* 6116 */       if (ch == '\r' || ch == '\n') {
/* 6117 */         return "";
/*      */       }
/* 6119 */       return str;
/*      */     } 
/*      */     
/* 6122 */     int lastIdx = str.length() - 1;
/* 6123 */     char last = str.charAt(lastIdx);
/*      */     
/* 6125 */     if (last == '\n') {
/* 6126 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 6127 */         lastIdx--;
/*      */       }
/* 6129 */     } else if (last != '\r') {
/* 6130 */       lastIdx++;
/*      */     } 
/* 6132 */     return str.substring(0, lastIdx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String chomp(String str, String separator) {
/* 6164 */     return removeEnd(str, separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chop(String str) {
/* 6193 */     if (str == null) {
/* 6194 */       return null;
/*      */     }
/* 6196 */     int strLen = str.length();
/* 6197 */     if (strLen < 2) {
/* 6198 */       return "";
/*      */     }
/* 6200 */     int lastIdx = strLen - 1;
/* 6201 */     String ret = str.substring(0, lastIdx);
/* 6202 */     char last = str.charAt(lastIdx);
/* 6203 */     if (last == '\n' && ret.charAt(lastIdx - 1) == '\r') {
/* 6204 */       return ret.substring(0, lastIdx - 1);
/*      */     }
/* 6206 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(String str, int repeat) {
/*      */     char ch0, ch1, output2[];
/*      */     int i;
/* 6235 */     if (str == null) {
/* 6236 */       return null;
/*      */     }
/* 6238 */     if (repeat <= 0) {
/* 6239 */       return "";
/*      */     }
/* 6241 */     int inputLength = str.length();
/* 6242 */     if (repeat == 1 || inputLength == 0) {
/* 6243 */       return str;
/*      */     }
/* 6245 */     if (inputLength == 1 && repeat <= 8192) {
/* 6246 */       return repeat(str.charAt(0), repeat);
/*      */     }
/*      */     
/* 6249 */     int outputLength = inputLength * repeat;
/* 6250 */     switch (inputLength) {
/*      */       case 1:
/* 6252 */         return repeat(str.charAt(0), repeat);
/*      */       case 2:
/* 6254 */         ch0 = str.charAt(0);
/* 6255 */         ch1 = str.charAt(1);
/* 6256 */         output2 = new char[outputLength];
/* 6257 */         for (i = repeat * 2 - 2; i >= 0; i--, i--) {
/* 6258 */           output2[i] = ch0;
/* 6259 */           output2[i + 1] = ch1;
/*      */         } 
/* 6261 */         return new String(output2);
/*      */     } 
/* 6263 */     StringBuilder buf = new StringBuilder(outputLength);
/* 6264 */     for (int j = 0; j < repeat; j++) {
/* 6265 */       buf.append(str);
/*      */     }
/* 6267 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(String str, String separator, int repeat) {
/* 6292 */     if (str == null || separator == null) {
/* 6293 */       return repeat(str, repeat);
/*      */     }
/*      */     
/* 6296 */     String result = repeat(str + separator, repeat);
/* 6297 */     return removeEnd(result, separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(char ch, int repeat) {
/* 6323 */     if (repeat <= 0) {
/* 6324 */       return "";
/*      */     }
/* 6326 */     char[] buf = new char[repeat];
/* 6327 */     for (int i = repeat - 1; i >= 0; i--) {
/* 6328 */       buf[i] = ch;
/*      */     }
/* 6330 */     return new String(buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size) {
/* 6353 */     return rightPad(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, char padChar) {
/* 6378 */     if (str == null) {
/* 6379 */       return null;
/*      */     }
/* 6381 */     int pads = size - str.length();
/* 6382 */     if (pads <= 0) {
/* 6383 */       return str;
/*      */     }
/* 6385 */     if (pads > 8192) {
/* 6386 */       return rightPad(str, size, String.valueOf(padChar));
/*      */     }
/* 6388 */     return str.concat(repeat(padChar, pads));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, String padStr) {
/* 6415 */     if (str == null) {
/* 6416 */       return null;
/*      */     }
/* 6418 */     if (isEmpty(padStr)) {
/* 6419 */       padStr = " ";
/*      */     }
/* 6421 */     int padLen = padStr.length();
/* 6422 */     int strLen = str.length();
/* 6423 */     int pads = size - strLen;
/* 6424 */     if (pads <= 0) {
/* 6425 */       return str;
/*      */     }
/* 6427 */     if (padLen == 1 && pads <= 8192) {
/* 6428 */       return rightPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 6431 */     if (pads == padLen)
/* 6432 */       return str.concat(padStr); 
/* 6433 */     if (pads < padLen) {
/* 6434 */       return str.concat(padStr.substring(0, pads));
/*      */     }
/* 6436 */     char[] padding = new char[pads];
/* 6437 */     char[] padChars = padStr.toCharArray();
/* 6438 */     for (int i = 0; i < pads; i++) {
/* 6439 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 6441 */     return str.concat(new String(padding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size) {
/* 6465 */     return leftPad(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, char padChar) {
/* 6490 */     if (str == null) {
/* 6491 */       return null;
/*      */     }
/* 6493 */     int pads = size - str.length();
/* 6494 */     if (pads <= 0) {
/* 6495 */       return str;
/*      */     }
/* 6497 */     if (pads > 8192) {
/* 6498 */       return leftPad(str, size, String.valueOf(padChar));
/*      */     }
/* 6500 */     return repeat(padChar, pads).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, String padStr) {
/* 6527 */     if (str == null) {
/* 6528 */       return null;
/*      */     }
/* 6530 */     if (isEmpty(padStr)) {
/* 6531 */       padStr = " ";
/*      */     }
/* 6533 */     int padLen = padStr.length();
/* 6534 */     int strLen = str.length();
/* 6535 */     int pads = size - strLen;
/* 6536 */     if (pads <= 0) {
/* 6537 */       return str;
/*      */     }
/* 6539 */     if (padLen == 1 && pads <= 8192) {
/* 6540 */       return leftPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 6543 */     if (pads == padLen)
/* 6544 */       return padStr.concat(str); 
/* 6545 */     if (pads < padLen) {
/* 6546 */       return padStr.substring(0, pads).concat(str);
/*      */     }
/* 6548 */     char[] padding = new char[pads];
/* 6549 */     char[] padChars = padStr.toCharArray();
/* 6550 */     for (int i = 0; i < pads; i++) {
/* 6551 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 6553 */     return (new String(padding)).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int length(CharSequence cs) {
/* 6569 */     return (cs == null) ? 0 : cs.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size) {
/* 6598 */     return center(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, char padChar) {
/* 6626 */     if (str == null || size <= 0) {
/* 6627 */       return str;
/*      */     }
/* 6629 */     int strLen = str.length();
/* 6630 */     int pads = size - strLen;
/* 6631 */     if (pads <= 0) {
/* 6632 */       return str;
/*      */     }
/* 6634 */     str = leftPad(str, strLen + pads / 2, padChar);
/* 6635 */     str = rightPad(str, size, padChar);
/* 6636 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, String padStr) {
/* 6666 */     if (str == null || size <= 0) {
/* 6667 */       return str;
/*      */     }
/* 6669 */     if (isEmpty(padStr)) {
/* 6670 */       padStr = " ";
/*      */     }
/* 6672 */     int strLen = str.length();
/* 6673 */     int pads = size - strLen;
/* 6674 */     if (pads <= 0) {
/* 6675 */       return str;
/*      */     }
/* 6677 */     str = leftPad(str, strLen + pads / 2, padStr);
/* 6678 */     str = rightPad(str, size, padStr);
/* 6679 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String upperCase(String str) {
/* 6704 */     if (str == null) {
/* 6705 */       return null;
/*      */     }
/* 6707 */     return str.toUpperCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String upperCase(String str, Locale locale) {
/* 6727 */     if (str == null) {
/* 6728 */       return null;
/*      */     }
/* 6730 */     return str.toUpperCase(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lowerCase(String str) {
/* 6753 */     if (str == null) {
/* 6754 */       return null;
/*      */     }
/* 6756 */     return str.toLowerCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lowerCase(String str, Locale locale) {
/* 6776 */     if (str == null) {
/* 6777 */       return null;
/*      */     }
/* 6779 */     return str.toLowerCase(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String capitalize(String str) {
/*      */     int strLen;
/* 6805 */     if (str == null || (strLen = str.length()) == 0) {
/* 6806 */       return str;
/*      */     }
/*      */     
/* 6809 */     int firstCodepoint = str.codePointAt(0);
/* 6810 */     int newCodePoint = Character.toTitleCase(firstCodepoint);
/* 6811 */     if (firstCodepoint == newCodePoint)
/*      */     {
/* 6813 */       return str;
/*      */     }
/*      */     
/* 6816 */     int[] newCodePoints = new int[strLen];
/* 6817 */     int outOffset = 0;
/* 6818 */     newCodePoints[outOffset++] = newCodePoint; int inOffset;
/* 6819 */     for (inOffset = Character.charCount(firstCodepoint); inOffset < strLen; ) {
/* 6820 */       int codepoint = str.codePointAt(inOffset);
/* 6821 */       newCodePoints[outOffset++] = codepoint;
/* 6822 */       inOffset += Character.charCount(codepoint);
/*      */     } 
/* 6824 */     return new String(newCodePoints, 0, outOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String uncapitalize(String str) {
/*      */     int strLen;
/* 6850 */     if (str == null || (strLen = str.length()) == 0) {
/* 6851 */       return str;
/*      */     }
/*      */     
/* 6854 */     int firstCodepoint = str.codePointAt(0);
/* 6855 */     int newCodePoint = Character.toLowerCase(firstCodepoint);
/* 6856 */     if (firstCodepoint == newCodePoint)
/*      */     {
/* 6858 */       return str;
/*      */     }
/*      */     
/* 6861 */     int[] newCodePoints = new int[strLen];
/* 6862 */     int outOffset = 0;
/* 6863 */     newCodePoints[outOffset++] = newCodePoint; int inOffset;
/* 6864 */     for (inOffset = Character.charCount(firstCodepoint); inOffset < strLen; ) {
/* 6865 */       int codepoint = str.codePointAt(inOffset);
/* 6866 */       newCodePoints[outOffset++] = codepoint;
/* 6867 */       inOffset += Character.charCount(codepoint);
/*      */     } 
/* 6869 */     return new String(newCodePoints, 0, outOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String swapCase(String str) {
/* 6900 */     if (isEmpty(str)) {
/* 6901 */       return str;
/*      */     }
/*      */     
/* 6904 */     int strLen = str.length();
/* 6905 */     int[] newCodePoints = new int[strLen];
/* 6906 */     int outOffset = 0; int i;
/* 6907 */     for (i = 0; i < strLen; ) {
/* 6908 */       int newCodePoint, oldCodepoint = str.codePointAt(i);
/*      */       
/* 6910 */       if (Character.isUpperCase(oldCodepoint)) {
/* 6911 */         newCodePoint = Character.toLowerCase(oldCodepoint);
/* 6912 */       } else if (Character.isTitleCase(oldCodepoint)) {
/* 6913 */         newCodePoint = Character.toLowerCase(oldCodepoint);
/* 6914 */       } else if (Character.isLowerCase(oldCodepoint)) {
/* 6915 */         newCodePoint = Character.toUpperCase(oldCodepoint);
/*      */       } else {
/* 6917 */         newCodePoint = oldCodepoint;
/*      */       } 
/* 6919 */       newCodePoints[outOffset++] = newCodePoint;
/* 6920 */       i += Character.charCount(newCodePoint);
/*      */     } 
/* 6922 */     return new String(newCodePoints, 0, outOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int countMatches(CharSequence str, CharSequence sub) {
/* 6948 */     if (isEmpty(str) || isEmpty(sub)) {
/* 6949 */       return 0;
/*      */     }
/* 6951 */     int count = 0;
/* 6952 */     int idx = 0;
/* 6953 */     while ((idx = CharSequenceUtils.indexOf(str, sub, idx)) != -1) {
/* 6954 */       count++;
/* 6955 */       idx += sub.length();
/*      */     } 
/* 6957 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int countMatches(CharSequence str, char ch) {
/* 6980 */     if (isEmpty(str)) {
/* 6981 */       return 0;
/*      */     }
/* 6983 */     int count = 0;
/*      */     
/* 6985 */     for (int i = 0; i < str.length(); i++) {
/* 6986 */       if (ch == str.charAt(i)) {
/* 6987 */         count++;
/*      */       }
/*      */     } 
/* 6990 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlpha(CharSequence cs) {
/* 7016 */     if (isEmpty(cs)) {
/* 7017 */       return false;
/*      */     }
/* 7019 */     int sz = cs.length();
/* 7020 */     for (int i = 0; i < sz; i++) {
/* 7021 */       if (!Character.isLetter(cs.charAt(i))) {
/* 7022 */         return false;
/*      */       }
/*      */     } 
/* 7025 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphaSpace(CharSequence cs) {
/* 7051 */     if (cs == null) {
/* 7052 */       return false;
/*      */     }
/* 7054 */     int sz = cs.length();
/* 7055 */     for (int i = 0; i < sz; i++) {
/* 7056 */       if (!Character.isLetter(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 7057 */         return false;
/*      */       }
/*      */     } 
/* 7060 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumeric(CharSequence cs) {
/* 7086 */     if (isEmpty(cs)) {
/* 7087 */       return false;
/*      */     }
/* 7089 */     int sz = cs.length();
/* 7090 */     for (int i = 0; i < sz; i++) {
/* 7091 */       if (!Character.isLetterOrDigit(cs.charAt(i))) {
/* 7092 */         return false;
/*      */       }
/*      */     } 
/* 7095 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumericSpace(CharSequence cs) {
/* 7121 */     if (cs == null) {
/* 7122 */       return false;
/*      */     }
/* 7124 */     int sz = cs.length();
/* 7125 */     for (int i = 0; i < sz; i++) {
/* 7126 */       if (!Character.isLetterOrDigit(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 7127 */         return false;
/*      */       }
/*      */     } 
/* 7130 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAsciiPrintable(CharSequence cs) {
/* 7160 */     if (cs == null) {
/* 7161 */       return false;
/*      */     }
/* 7163 */     int sz = cs.length();
/* 7164 */     for (int i = 0; i < sz; i++) {
/* 7165 */       if (!CharUtils.isAsciiPrintable(cs.charAt(i))) {
/* 7166 */         return false;
/*      */       }
/*      */     } 
/* 7169 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumeric(CharSequence cs) {
/* 7204 */     if (isEmpty(cs)) {
/* 7205 */       return false;
/*      */     }
/* 7207 */     int sz = cs.length();
/* 7208 */     for (int i = 0; i < sz; i++) {
/* 7209 */       if (!Character.isDigit(cs.charAt(i))) {
/* 7210 */         return false;
/*      */       }
/*      */     } 
/* 7213 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumericSpace(CharSequence cs) {
/* 7243 */     if (cs == null) {
/* 7244 */       return false;
/*      */     }
/* 7246 */     int sz = cs.length();
/* 7247 */     for (int i = 0; i < sz; i++) {
/* 7248 */       if (!Character.isDigit(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 7249 */         return false;
/*      */       }
/*      */     } 
/* 7252 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDigits(String str) {
/* 7278 */     if (isEmpty(str)) {
/* 7279 */       return str;
/*      */     }
/* 7281 */     int sz = str.length();
/* 7282 */     StringBuilder strDigits = new StringBuilder(sz);
/* 7283 */     for (int i = 0; i < sz; i++) {
/* 7284 */       char tempChar = str.charAt(i);
/* 7285 */       if (Character.isDigit(tempChar)) {
/* 7286 */         strDigits.append(tempChar);
/*      */       }
/*      */     } 
/* 7289 */     return strDigits.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWhitespace(CharSequence cs) {
/* 7315 */     if (cs == null) {
/* 7316 */       return false;
/*      */     }
/* 7318 */     int sz = cs.length();
/* 7319 */     for (int i = 0; i < sz; i++) {
/* 7320 */       if (!Character.isWhitespace(cs.charAt(i))) {
/* 7321 */         return false;
/*      */       }
/*      */     } 
/* 7324 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllLowerCase(CharSequence cs) {
/* 7350 */     if (cs == null || isEmpty(cs)) {
/* 7351 */       return false;
/*      */     }
/* 7353 */     int sz = cs.length();
/* 7354 */     for (int i = 0; i < sz; i++) {
/* 7355 */       if (!Character.isLowerCase(cs.charAt(i))) {
/* 7356 */         return false;
/*      */       }
/*      */     } 
/* 7359 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllUpperCase(CharSequence cs) {
/* 7385 */     if (cs == null || isEmpty(cs)) {
/* 7386 */       return false;
/*      */     }
/* 7388 */     int sz = cs.length();
/* 7389 */     for (int i = 0; i < sz; i++) {
/* 7390 */       if (!Character.isUpperCase(cs.charAt(i))) {
/* 7391 */         return false;
/*      */       }
/*      */     } 
/* 7394 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isMixedCase(CharSequence cs) {
/* 7420 */     if (isEmpty(cs) || cs.length() == 1) {
/* 7421 */       return false;
/*      */     }
/* 7423 */     boolean containsUppercase = false;
/* 7424 */     boolean containsLowercase = false;
/* 7425 */     int sz = cs.length();
/* 7426 */     for (int i = 0; i < sz; i++) {
/* 7427 */       if (containsUppercase && containsLowercase)
/* 7428 */         return true; 
/* 7429 */       if (Character.isUpperCase(cs.charAt(i))) {
/* 7430 */         containsUppercase = true;
/* 7431 */       } else if (Character.isLowerCase(cs.charAt(i))) {
/* 7432 */         containsLowercase = true;
/*      */       } 
/*      */     } 
/* 7435 */     return (containsUppercase && containsLowercase);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String defaultString(String str) {
/* 7457 */     return defaultString(str, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String defaultString(String str, String defaultStr) {
/* 7478 */     return (str == null) ? defaultStr : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T extends CharSequence> T firstNonBlank(T... values) {
/* 7508 */     if (values != null) {
/* 7509 */       for (T val : values) {
/* 7510 */         if (isNotBlank((CharSequence)val)) {
/* 7511 */           return val;
/*      */         }
/*      */       } 
/*      */     }
/* 7515 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SafeVarargs
/*      */   public static <T extends CharSequence> T firstNonEmpty(T... values) {
/* 7543 */     if (values != null) {
/* 7544 */       for (T val : values) {
/* 7545 */         if (isNotEmpty((CharSequence)val)) {
/* 7546 */           return val;
/*      */         }
/*      */       } 
/*      */     }
/* 7550 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends CharSequence> T defaultIfBlank(T str, T defaultStr) {
/* 7574 */     return isBlank((CharSequence)str) ? defaultStr : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends CharSequence> T defaultIfEmpty(T str, T defaultStr) {
/* 7596 */     return isEmpty((CharSequence)str) ? defaultStr : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rotate(String str, int shift) {
/* 7628 */     if (str == null) {
/* 7629 */       return null;
/*      */     }
/*      */     
/* 7632 */     int strLen = str.length();
/* 7633 */     if (shift == 0 || strLen == 0 || shift % strLen == 0) {
/* 7634 */       return str;
/*      */     }
/*      */     
/* 7637 */     StringBuilder builder = new StringBuilder(strLen);
/* 7638 */     int offset = -(shift % strLen);
/* 7639 */     builder.append(substring(str, offset));
/* 7640 */     builder.append(substring(str, 0, offset));
/* 7641 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverse(String str) {
/* 7661 */     if (str == null) {
/* 7662 */       return null;
/*      */     }
/* 7664 */     return (new StringBuilder(str)).reverse().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverseDelimited(String str, char separatorChar) {
/* 7687 */     if (str == null) {
/* 7688 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 7692 */     String[] strs = split(str, separatorChar);
/* 7693 */     ArrayUtils.reverse((Object[])strs);
/* 7694 */     return join((Object[])strs, separatorChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, int maxWidth) {
/* 7731 */     String defaultAbbrevMarker = "...";
/* 7732 */     return abbreviate(str, "...", 0, maxWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, int offset, int maxWidth) {
/* 7771 */     String defaultAbbrevMarker = "...";
/* 7772 */     return abbreviate(str, "...", offset, maxWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, String abbrevMarker, int maxWidth) {
/* 7812 */     return abbreviate(str, abbrevMarker, 0, maxWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, String abbrevMarker, int offset, int maxWidth) {
/* 7853 */     if (isEmpty(str) || isEmpty(abbrevMarker)) {
/* 7854 */       return str;
/*      */     }
/*      */     
/* 7857 */     int abbrevMarkerLength = abbrevMarker.length();
/* 7858 */     int minAbbrevWidth = abbrevMarkerLength + 1;
/* 7859 */     int minAbbrevWidthOffset = abbrevMarkerLength + abbrevMarkerLength + 1;
/*      */     
/* 7861 */     if (maxWidth < minAbbrevWidth) {
/* 7862 */       throw new IllegalArgumentException(String.format("Minimum abbreviation width is %d", new Object[] { Integer.valueOf(minAbbrevWidth) }));
/*      */     }
/* 7864 */     if (str.length() <= maxWidth) {
/* 7865 */       return str;
/*      */     }
/* 7867 */     if (offset > str.length()) {
/* 7868 */       offset = str.length();
/*      */     }
/* 7870 */     if (str.length() - offset < maxWidth - abbrevMarkerLength) {
/* 7871 */       offset = str.length() - maxWidth - abbrevMarkerLength;
/*      */     }
/* 7873 */     if (offset <= abbrevMarkerLength + 1) {
/* 7874 */       return str.substring(0, maxWidth - abbrevMarkerLength) + abbrevMarker;
/*      */     }
/* 7876 */     if (maxWidth < minAbbrevWidthOffset) {
/* 7877 */       throw new IllegalArgumentException(String.format("Minimum abbreviation width with offset is %d", new Object[] { Integer.valueOf(minAbbrevWidthOffset) }));
/*      */     }
/* 7879 */     if (offset + maxWidth - abbrevMarkerLength < str.length()) {
/* 7880 */       return abbrevMarker + abbreviate(str.substring(offset), abbrevMarker, maxWidth - abbrevMarkerLength);
/*      */     }
/* 7882 */     return abbrevMarker + str.substring(str.length() - maxWidth - abbrevMarkerLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviateMiddle(String str, String middle, int length) {
/* 7915 */     if (isEmpty(str) || isEmpty(middle)) {
/* 7916 */       return str;
/*      */     }
/*      */     
/* 7919 */     if (length >= str.length() || length < middle.length() + 2) {
/* 7920 */       return str;
/*      */     }
/*      */     
/* 7923 */     int targetSting = length - middle.length();
/* 7924 */     int startOffset = targetSting / 2 + targetSting % 2;
/* 7925 */     int endOffset = str.length() - targetSting / 2;
/*      */     
/* 7927 */     return str.substring(0, startOffset) + middle + str
/*      */       
/* 7929 */       .substring(endOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String difference(String str1, String str2) {
/* 7963 */     if (str1 == null) {
/* 7964 */       return str2;
/*      */     }
/* 7966 */     if (str2 == null) {
/* 7967 */       return str1;
/*      */     }
/* 7969 */     int at = indexOfDifference(str1, str2);
/* 7970 */     if (at == -1) {
/* 7971 */       return "";
/*      */     }
/* 7973 */     return str2.substring(at);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfDifference(CharSequence cs1, CharSequence cs2) {
/* 8002 */     if (cs1 == cs2) {
/* 8003 */       return -1;
/*      */     }
/* 8005 */     if (cs1 == null || cs2 == null) {
/* 8006 */       return 0;
/*      */     }
/*      */     int i;
/* 8009 */     for (i = 0; i < cs1.length() && i < cs2.length() && 
/* 8010 */       cs1.charAt(i) == cs2.charAt(i); i++);
/*      */ 
/*      */ 
/*      */     
/* 8014 */     if (i < cs2.length() || i < cs1.length()) {
/* 8015 */       return i;
/*      */     }
/* 8017 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfDifference(CharSequence... css) {
/* 8053 */     if (css == null || css.length <= 1) {
/* 8054 */       return -1;
/*      */     }
/* 8056 */     boolean anyStringNull = false;
/* 8057 */     boolean allStringsNull = true;
/* 8058 */     int arrayLen = css.length;
/* 8059 */     int shortestStrLen = Integer.MAX_VALUE;
/* 8060 */     int longestStrLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 8065 */     for (CharSequence cs : css) {
/* 8066 */       if (cs == null) {
/* 8067 */         anyStringNull = true;
/* 8068 */         shortestStrLen = 0;
/*      */       } else {
/* 8070 */         allStringsNull = false;
/* 8071 */         shortestStrLen = Math.min(cs.length(), shortestStrLen);
/* 8072 */         longestStrLen = Math.max(cs.length(), longestStrLen);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 8077 */     if (allStringsNull || (longestStrLen == 0 && !anyStringNull)) {
/* 8078 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 8082 */     if (shortestStrLen == 0) {
/* 8083 */       return 0;
/*      */     }
/*      */ 
/*      */     
/* 8087 */     int firstDiff = -1;
/* 8088 */     for (int stringPos = 0; stringPos < shortestStrLen; stringPos++) {
/* 8089 */       char comparisonChar = css[0].charAt(stringPos);
/* 8090 */       for (int arrayPos = 1; arrayPos < arrayLen; arrayPos++) {
/* 8091 */         if (css[arrayPos].charAt(stringPos) != comparisonChar) {
/* 8092 */           firstDiff = stringPos;
/*      */           break;
/*      */         } 
/*      */       } 
/* 8096 */       if (firstDiff != -1) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 8101 */     if (firstDiff == -1 && shortestStrLen != longestStrLen)
/*      */     {
/*      */ 
/*      */       
/* 8105 */       return shortestStrLen;
/*      */     }
/* 8107 */     return firstDiff;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getCommonPrefix(String... strs) {
/* 8144 */     if (strs == null || strs.length == 0) {
/* 8145 */       return "";
/*      */     }
/* 8147 */     int smallestIndexOfDiff = indexOfDifference((CharSequence[])strs);
/* 8148 */     if (smallestIndexOfDiff == -1) {
/*      */       
/* 8150 */       if (strs[0] == null) {
/* 8151 */         return "";
/*      */       }
/* 8153 */       return strs[0];
/* 8154 */     }  if (smallestIndexOfDiff == 0)
/*      */     {
/* 8156 */       return "";
/*      */     }
/*      */     
/* 8159 */     return strs[0].substring(0, smallestIndexOfDiff);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t) {
/* 8202 */     if (s == null || t == null) {
/* 8203 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */     
/* 8206 */     int n = s.length();
/* 8207 */     int m = t.length();
/*      */     
/* 8209 */     if (n == 0)
/* 8210 */       return m; 
/* 8211 */     if (m == 0) {
/* 8212 */       return n;
/*      */     }
/*      */     
/* 8215 */     if (n > m) {
/*      */       
/* 8217 */       CharSequence tmp = s;
/* 8218 */       s = t;
/* 8219 */       t = tmp;
/* 8220 */       n = m;
/* 8221 */       m = t.length();
/*      */     } 
/*      */     
/* 8224 */     int[] p = new int[n + 1];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int i;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 8234 */     for (i = 0; i <= n; i++) {
/* 8235 */       p[i] = i;
/*      */     }
/*      */     
/* 8238 */     for (int j = 1; j <= m; j++) {
/* 8239 */       int upper_left = p[0];
/* 8240 */       char t_j = t.charAt(j - 1);
/* 8241 */       p[0] = j;
/*      */       
/* 8243 */       for (i = 1; i <= n; i++) {
/* 8244 */         int upper = p[i];
/* 8245 */         int cost = (s.charAt(i - 1) == t_j) ? 0 : 1;
/*      */         
/* 8247 */         p[i] = Math.min(Math.min(p[i - 1] + 1, p[i] + 1), upper_left + cost);
/* 8248 */         upper_left = upper;
/*      */       } 
/*      */     } 
/*      */     
/* 8252 */     return p[n];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t, int threshold) {
/* 8292 */     if (s == null || t == null) {
/* 8293 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/* 8295 */     if (threshold < 0) {
/* 8296 */       throw new IllegalArgumentException("Threshold must not be negative");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 8343 */     int n = s.length();
/* 8344 */     int m = t.length();
/*      */ 
/*      */     
/* 8347 */     if (n == 0)
/* 8348 */       return (m <= threshold) ? m : -1; 
/* 8349 */     if (m == 0)
/* 8350 */       return (n <= threshold) ? n : -1; 
/* 8351 */     if (Math.abs(n - m) > threshold)
/*      */     {
/* 8353 */       return -1;
/*      */     }
/*      */     
/* 8356 */     if (n > m) {
/*      */       
/* 8358 */       CharSequence tmp = s;
/* 8359 */       s = t;
/* 8360 */       t = tmp;
/* 8361 */       n = m;
/* 8362 */       m = t.length();
/*      */     } 
/*      */     
/* 8365 */     int[] p = new int[n + 1];
/* 8366 */     int[] d = new int[n + 1];
/*      */ 
/*      */ 
/*      */     
/* 8370 */     int boundary = Math.min(n, threshold) + 1;
/* 8371 */     for (int i = 0; i < boundary; i++) {
/* 8372 */       p[i] = i;
/*      */     }
/*      */ 
/*      */     
/* 8376 */     Arrays.fill(p, boundary, p.length, 2147483647);
/* 8377 */     Arrays.fill(d, 2147483647);
/*      */ 
/*      */     
/* 8380 */     for (int j = 1; j <= m; j++) {
/* 8381 */       char t_j = t.charAt(j - 1);
/* 8382 */       d[0] = j;
/*      */ 
/*      */       
/* 8385 */       int min = Math.max(1, j - threshold);
/* 8386 */       int max = (j > Integer.MAX_VALUE - threshold) ? n : Math.min(n, j + threshold);
/*      */ 
/*      */       
/* 8389 */       if (min > max) {
/* 8390 */         return -1;
/*      */       }
/*      */ 
/*      */       
/* 8394 */       if (min > 1) {
/* 8395 */         d[min - 1] = Integer.MAX_VALUE;
/*      */       }
/*      */ 
/*      */       
/* 8399 */       for (int k = min; k <= max; k++) {
/* 8400 */         if (s.charAt(k - 1) == t_j) {
/*      */           
/* 8402 */           d[k] = p[k - 1];
/*      */         } else {
/*      */           
/* 8405 */           d[k] = 1 + Math.min(Math.min(d[k - 1], p[k]), p[k - 1]);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 8410 */       int[] _d = p;
/* 8411 */       p = d;
/* 8412 */       d = _d;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 8417 */     if (p[n] <= threshold) {
/* 8418 */       return p[n];
/*      */     }
/* 8420 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static double getJaroWinklerDistance(CharSequence first, CharSequence second) {
/* 8460 */     double DEFAULT_SCALING_FACTOR = 0.1D;
/*      */     
/* 8462 */     if (first == null || second == null) {
/* 8463 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */     
/* 8466 */     int[] mtp = matches(first, second);
/* 8467 */     double m = mtp[0];
/* 8468 */     if (m == 0.0D) {
/* 8469 */       return 0.0D;
/*      */     }
/* 8471 */     double j = (m / first.length() + m / second.length() + (m - mtp[1]) / m) / 3.0D;
/* 8472 */     double jw = (j < 0.7D) ? j : (j + Math.min(0.1D, 1.0D / mtp[3]) * mtp[2] * (1.0D - j));
/* 8473 */     return Math.round(jw * 100.0D) / 100.0D;
/*      */   }
/*      */   
/*      */   private static int[] matches(CharSequence first, CharSequence second) {
/*      */     CharSequence max, min;
/* 8478 */     if (first.length() > second.length()) {
/* 8479 */       max = first;
/* 8480 */       min = second;
/*      */     } else {
/* 8482 */       max = second;
/* 8483 */       min = first;
/*      */     } 
/* 8485 */     int range = Math.max(max.length() / 2 - 1, 0);
/* 8486 */     int[] matchIndexes = new int[min.length()];
/* 8487 */     Arrays.fill(matchIndexes, -1);
/* 8488 */     boolean[] matchFlags = new boolean[max.length()];
/* 8489 */     int matches = 0;
/* 8490 */     for (int mi = 0; mi < min.length(); mi++) {
/* 8491 */       char c1 = min.charAt(mi);
/* 8492 */       for (int xi = Math.max(mi - range, 0), xn = Math.min(mi + range + 1, max.length()); xi < xn; xi++) {
/* 8493 */         if (!matchFlags[xi] && c1 == max.charAt(xi)) {
/* 8494 */           matchIndexes[mi] = xi;
/* 8495 */           matchFlags[xi] = true;
/* 8496 */           matches++;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 8501 */     char[] ms1 = new char[matches];
/* 8502 */     char[] ms2 = new char[matches]; int i, si;
/* 8503 */     for (i = 0, si = 0; i < min.length(); i++) {
/* 8504 */       if (matchIndexes[i] != -1) {
/* 8505 */         ms1[si] = min.charAt(i);
/* 8506 */         si++;
/*      */       } 
/*      */     } 
/* 8509 */     for (i = 0, si = 0; i < max.length(); i++) {
/* 8510 */       if (matchFlags[i]) {
/* 8511 */         ms2[si] = max.charAt(i);
/* 8512 */         si++;
/*      */       } 
/*      */     } 
/* 8515 */     int transpositions = 0;
/* 8516 */     for (int j = 0; j < ms1.length; j++) {
/* 8517 */       if (ms1[j] != ms2[j]) {
/* 8518 */         transpositions++;
/*      */       }
/*      */     } 
/* 8521 */     int prefix = 0;
/* 8522 */     for (int k = 0; k < min.length() && 
/* 8523 */       first.charAt(k) == second.charAt(k); k++) {
/* 8524 */       prefix++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 8529 */     return new int[] { matches, transpositions / 2, prefix, max.length() };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int getFuzzyDistance(CharSequence term, CharSequence query, Locale locale) {
/* 8563 */     if (term == null || query == null)
/* 8564 */       throw new IllegalArgumentException("Strings must not be null"); 
/* 8565 */     if (locale == null) {
/* 8566 */       throw new IllegalArgumentException("Locale must not be null");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 8573 */     String termLowerCase = term.toString().toLowerCase(locale);
/* 8574 */     String queryLowerCase = query.toString().toLowerCase(locale);
/*      */ 
/*      */     
/* 8577 */     int score = 0;
/*      */ 
/*      */ 
/*      */     
/* 8581 */     int termIndex = 0;
/*      */ 
/*      */     
/* 8584 */     int previousMatchingCharacterIndex = Integer.MIN_VALUE;
/*      */     
/* 8586 */     for (int queryIndex = 0; queryIndex < queryLowerCase.length(); queryIndex++) {
/* 8587 */       char queryChar = queryLowerCase.charAt(queryIndex);
/*      */       
/* 8589 */       boolean termCharacterMatchFound = false;
/* 8590 */       for (; termIndex < termLowerCase.length() && !termCharacterMatchFound; termIndex++) {
/* 8591 */         char termChar = termLowerCase.charAt(termIndex);
/*      */         
/* 8593 */         if (queryChar == termChar) {
/*      */           
/* 8595 */           score++;
/*      */ 
/*      */ 
/*      */           
/* 8599 */           if (previousMatchingCharacterIndex + 1 == termIndex) {
/* 8600 */             score += 2;
/*      */           }
/*      */           
/* 8603 */           previousMatchingCharacterIndex = termIndex;
/*      */ 
/*      */ 
/*      */           
/* 8607 */           termCharacterMatchFound = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 8612 */     return score;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWith(CharSequence str, CharSequence prefix) {
/* 8641 */     return startsWith(str, prefix, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithIgnoreCase(CharSequence str, CharSequence prefix) {
/* 8667 */     return startsWith(str, prefix, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean startsWith(CharSequence str, CharSequence prefix, boolean ignoreCase) {
/* 8682 */     if (str == null || prefix == null) {
/* 8683 */       return (str == prefix);
/*      */     }
/* 8685 */     if (prefix.length() > str.length()) {
/* 8686 */       return false;
/*      */     }
/* 8688 */     return CharSequenceUtils.regionMatches(str, ignoreCase, 0, prefix, 0, prefix.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithAny(CharSequence sequence, CharSequence... searchStrings) {
/* 8714 */     if (isEmpty(sequence) || ArrayUtils.isEmpty((Object[])searchStrings)) {
/* 8715 */       return false;
/*      */     }
/* 8717 */     for (CharSequence searchString : searchStrings) {
/* 8718 */       if (startsWith(sequence, searchString)) {
/* 8719 */         return true;
/*      */       }
/*      */     } 
/* 8722 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean endsWith(CharSequence str, CharSequence suffix) {
/* 8753 */     return endsWith(str, suffix, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean endsWithIgnoreCase(CharSequence str, CharSequence suffix) {
/* 8780 */     return endsWith(str, suffix, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean endsWith(CharSequence str, CharSequence suffix, boolean ignoreCase) {
/* 8795 */     if (str == null || suffix == null) {
/* 8796 */       return (str == suffix);
/*      */     }
/* 8798 */     if (suffix.length() > str.length()) {
/* 8799 */       return false;
/*      */     }
/* 8801 */     int strOffset = str.length() - suffix.length();
/* 8802 */     return CharSequenceUtils.regionMatches(str, ignoreCase, strOffset, suffix, 0, suffix.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String normalizeSpace(String str) {
/* 8849 */     if (isEmpty(str)) {
/* 8850 */       return str;
/*      */     }
/* 8852 */     int size = str.length();
/* 8853 */     char[] newChars = new char[size];
/* 8854 */     int count = 0;
/* 8855 */     int whitespacesCount = 0;
/* 8856 */     boolean startWhitespaces = true;
/* 8857 */     for (int i = 0; i < size; i++) {
/* 8858 */       char actualChar = str.charAt(i);
/* 8859 */       boolean isWhitespace = Character.isWhitespace(actualChar);
/* 8860 */       if (isWhitespace) {
/* 8861 */         if (whitespacesCount == 0 && !startWhitespaces) {
/* 8862 */           newChars[count++] = " ".charAt(0);
/*      */         }
/* 8864 */         whitespacesCount++;
/*      */       } else {
/* 8866 */         startWhitespaces = false;
/* 8867 */         newChars[count++] = (actualChar == ' ') ? ' ' : actualChar;
/* 8868 */         whitespacesCount = 0;
/*      */       } 
/*      */     } 
/* 8871 */     if (startWhitespaces) {
/* 8872 */       return "";
/*      */     }
/* 8874 */     return (new String(newChars, 0, count - ((whitespacesCount > 0) ? 1 : 0))).trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean endsWithAny(CharSequence sequence, CharSequence... searchStrings) {
/* 8899 */     if (isEmpty(sequence) || ArrayUtils.isEmpty((Object[])searchStrings)) {
/* 8900 */       return false;
/*      */     }
/* 8902 */     for (CharSequence searchString : searchStrings) {
/* 8903 */       if (endsWith(sequence, searchString)) {
/* 8904 */         return true;
/*      */       }
/*      */     } 
/* 8907 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String appendIfMissing(String str, CharSequence suffix, boolean ignoreCase, CharSequence... suffixes) {
/* 8922 */     if (str == null || isEmpty(suffix) || endsWith(str, suffix, ignoreCase)) {
/* 8923 */       return str;
/*      */     }
/* 8925 */     if (suffixes != null && suffixes.length > 0) {
/* 8926 */       for (CharSequence s : suffixes) {
/* 8927 */         if (endsWith(str, s, ignoreCase)) {
/* 8928 */           return str;
/*      */         }
/*      */       } 
/*      */     }
/* 8932 */     return str + suffix.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String appendIfMissing(String str, CharSequence suffix, CharSequence... suffixes) {
/* 8970 */     return appendIfMissing(str, suffix, false, suffixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String appendIfMissingIgnoreCase(String str, CharSequence suffix, CharSequence... suffixes) {
/* 9008 */     return appendIfMissing(str, suffix, true, suffixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String prependIfMissing(String str, CharSequence prefix, boolean ignoreCase, CharSequence... prefixes) {
/* 9023 */     if (str == null || isEmpty(prefix) || startsWith(str, prefix, ignoreCase)) {
/* 9024 */       return str;
/*      */     }
/* 9026 */     if (prefixes != null && prefixes.length > 0) {
/* 9027 */       for (CharSequence p : prefixes) {
/* 9028 */         if (startsWith(str, p, ignoreCase)) {
/* 9029 */           return str;
/*      */         }
/*      */       } 
/*      */     }
/* 9033 */     return prefix.toString() + str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String prependIfMissing(String str, CharSequence prefix, CharSequence... prefixes) {
/* 9071 */     return prependIfMissing(str, prefix, false, prefixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String prependIfMissingIgnoreCase(String str, CharSequence prefix, CharSequence... prefixes) {
/* 9109 */     return prependIfMissing(str, prefix, true, prefixes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String toString(byte[] bytes, String charsetName) throws UnsupportedEncodingException {
/* 9129 */     return (charsetName != null) ? new String(bytes, charsetName) : new String(bytes, Charset.defaultCharset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toEncodedString(byte[] bytes, Charset charset) {
/* 9146 */     return new String(bytes, (charset != null) ? charset : Charset.defaultCharset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String wrap(String str, char wrapWith) {
/* 9172 */     if (isEmpty(str) || wrapWith == '\000') {
/* 9173 */       return str;
/*      */     }
/*      */     
/* 9176 */     return wrapWith + str + wrapWith;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String wrap(String str, String wrapWith) {
/* 9210 */     if (isEmpty(str) || isEmpty(wrapWith)) {
/* 9211 */       return str;
/*      */     }
/*      */     
/* 9214 */     return wrapWith.concat(str).concat(wrapWith);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String wrapIfMissing(String str, char wrapWith) {
/* 9243 */     if (isEmpty(str) || wrapWith == '\000') {
/* 9244 */       return str;
/*      */     }
/* 9246 */     StringBuilder builder = new StringBuilder(str.length() + 2);
/* 9247 */     if (str.charAt(0) != wrapWith) {
/* 9248 */       builder.append(wrapWith);
/*      */     }
/* 9250 */     builder.append(str);
/* 9251 */     if (str.charAt(str.length() - 1) != wrapWith) {
/* 9252 */       builder.append(wrapWith);
/*      */     }
/* 9254 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String wrapIfMissing(String str, String wrapWith) {
/* 9287 */     if (isEmpty(str) || isEmpty(wrapWith)) {
/* 9288 */       return str;
/*      */     }
/* 9290 */     StringBuilder builder = new StringBuilder(str.length() + wrapWith.length() + wrapWith.length());
/* 9291 */     if (!str.startsWith(wrapWith)) {
/* 9292 */       builder.append(wrapWith);
/*      */     }
/* 9294 */     builder.append(str);
/* 9295 */     if (!str.endsWith(wrapWith)) {
/* 9296 */       builder.append(wrapWith);
/*      */     }
/* 9298 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unwrap(String str, String wrapToken) {
/* 9327 */     if (isEmpty(str) || isEmpty(wrapToken)) {
/* 9328 */       return str;
/*      */     }
/*      */     
/* 9331 */     if (startsWith(str, wrapToken) && endsWith(str, wrapToken)) {
/* 9332 */       int startIndex = str.indexOf(wrapToken);
/* 9333 */       int endIndex = str.lastIndexOf(wrapToken);
/* 9334 */       int wrapLength = wrapToken.length();
/* 9335 */       if (startIndex != -1 && endIndex != -1) {
/* 9336 */         return str.substring(startIndex + wrapLength, endIndex);
/*      */       }
/*      */     } 
/*      */     
/* 9340 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unwrap(String str, char wrapChar) {
/* 9368 */     if (isEmpty(str) || wrapChar == '\000') {
/* 9369 */       return str;
/*      */     }
/*      */     
/* 9372 */     if (str.charAt(0) == wrapChar && str.charAt(str.length() - 1) == wrapChar) {
/* 9373 */       int startIndex = 0;
/* 9374 */       int endIndex = str.length() - 1;
/* 9375 */       if (endIndex != -1) {
/* 9376 */         return str.substring(1, endIndex);
/*      */       }
/*      */     } 
/*      */     
/* 9380 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] toCodePoints(CharSequence str) {
/* 9400 */     if (str == null) {
/* 9401 */       return null;
/*      */     }
/* 9403 */     if (str.length() == 0) {
/* 9404 */       return ArrayUtils.EMPTY_INT_ARRAY;
/*      */     }
/*      */     
/* 9407 */     String s = str.toString();
/* 9408 */     int[] result = new int[s.codePointCount(0, s.length())];
/* 9409 */     int index = 0;
/* 9410 */     for (int i = 0; i < result.length; i++) {
/* 9411 */       result[i] = s.codePointAt(index);
/* 9412 */       index += Character.charCount(result[i]);
/*      */     } 
/* 9414 */     return result;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\commons-lang3-3.8.1.jar!\org\apache\commons\lang3\StringUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */