/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTConst
/*     */   extends SimpleNode
/*     */   implements NodeType
/*     */ {
/*     */   private Object value;
/*     */   private Class _getterClass;
/*     */   
/*     */   public ASTConst(int id) {
/*  51 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTConst(OgnlParser p, int id) {
/*  56 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object value) {
/*  66 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/*  71 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  77 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeConstant(OgnlContext context) throws OgnlException {
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  88 */     if (this._getterClass == null) {
/*  89 */       return null;
/*     */     }
/*  91 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     String result;
/* 103 */     if (this.value == null) {
/*     */       
/* 105 */       result = "null";
/*     */     
/*     */     }
/* 108 */     else if (this.value instanceof String) {
/*     */       
/* 110 */       result = '"' + OgnlOps.getEscapeString(this.value.toString()) + '"';
/*     */     }
/* 112 */     else if (this.value instanceof Character) {
/*     */       
/* 114 */       result = '\'' + OgnlOps.getEscapedChar(((Character)this.value).charValue()) + '\'';
/*     */     } else {
/*     */       
/* 117 */       result = this.value.toString();
/*     */       
/* 119 */       if (this.value instanceof Long) {
/*     */         
/* 121 */         result = result + "L";
/*     */       
/*     */       }
/* 124 */       else if (this.value instanceof java.math.BigDecimal) {
/*     */         
/* 126 */         result = result + "B";
/*     */       
/*     */       }
/* 129 */       else if (this.value instanceof java.math.BigInteger) {
/*     */         
/* 131 */         result = result + "H";
/*     */       
/*     */       }
/* 134 */       else if (this.value instanceof Node) {
/*     */         
/* 136 */         result = ":[ " + result + " ]";
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 149 */     if (this.value == null && this._parent != null && ExpressionNode.class.isInstance(this._parent)) {
/*     */       
/* 151 */       context.setCurrentType(null);
/* 152 */       return "null";
/* 153 */     }  if (this.value == null) {
/*     */       
/* 155 */       context.setCurrentType(null);
/* 156 */       return "";
/*     */     } 
/*     */     
/* 159 */     this._getterClass = this.value.getClass();
/*     */     
/* 161 */     Object retval = this.value;
/* 162 */     if (this._parent != null && ASTProperty.class.isInstance(this._parent)) {
/*     */       
/* 164 */       context.setCurrentObject(this.value);
/*     */       
/* 166 */       return this.value.toString();
/* 167 */     }  if (this.value != null && Number.class.isAssignableFrom(this.value.getClass())) {
/*     */       
/* 169 */       context.setCurrentType(OgnlRuntime.getPrimitiveWrapperClass(this.value.getClass()));
/* 170 */       context.setCurrentObject(this.value);
/*     */       
/* 172 */       return this.value.toString();
/* 173 */     }  if ((this._parent == null || this.value == null || !NumericExpression.class.isAssignableFrom(this._parent.getClass())) && String.class.isAssignableFrom(this.value.getClass())) {
/*     */ 
/*     */ 
/*     */       
/* 177 */       context.setCurrentType(String.class);
/*     */       
/* 179 */       retval = '"' + OgnlOps.getEscapeString(this.value.toString()) + '"';
/*     */       
/* 181 */       context.setCurrentObject(retval.toString());
/*     */       
/* 183 */       return retval.toString();
/* 184 */     }  if (Character.class.isInstance(this.value)) {
/*     */       
/* 186 */       Character val = (Character)this.value;
/*     */       
/* 188 */       context.setCurrentType(Character.class);
/*     */       
/* 190 */       if (Character.isLetterOrDigit(val.charValue())) {
/* 191 */         retval = "'" + ((Character)this.value).charValue() + "'";
/*     */       } else {
/* 193 */         retval = "'" + OgnlOps.getEscapedChar(((Character)this.value).charValue()) + "'";
/*     */       } 
/* 195 */       context.setCurrentObject(retval);
/* 196 */       return retval.toString();
/*     */     } 
/*     */     
/* 199 */     if (Boolean.class.isAssignableFrom(this.value.getClass())) {
/*     */       
/* 201 */       this._getterClass = boolean.class;
/*     */       
/* 203 */       context.setCurrentType(boolean.class);
/* 204 */       context.setCurrentObject(this.value);
/*     */       
/* 206 */       return this.value.toString();
/*     */     } 
/*     */     
/* 209 */     return this.value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 214 */     if (this._parent == null) {
/* 215 */       throw new UnsupportedCompilationException("Can't modify constant values.");
/*     */     }
/* 217 */     return toGetSourceString(context, target);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTConst.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */