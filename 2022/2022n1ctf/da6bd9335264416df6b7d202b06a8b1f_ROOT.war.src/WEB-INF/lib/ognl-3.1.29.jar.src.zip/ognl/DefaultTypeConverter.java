/*    */ package ognl;
/*    */ 
/*    */ import java.lang.reflect.Member;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultTypeConverter
/*    */   implements TypeConverter
/*    */ {
/*    */   public Object convertValue(Map context, Object value, Class toType) {
/* 50 */     return OgnlOps.convertValue(value, toType);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object convertValue(Map context, Object target, Member member, String propertyName, Object value, Class toType) {
/* 55 */     return convertValue(context, value, toType);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\DefaultTypeConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */