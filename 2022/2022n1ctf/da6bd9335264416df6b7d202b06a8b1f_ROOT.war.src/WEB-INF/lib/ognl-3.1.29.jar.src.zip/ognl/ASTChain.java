/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import ognl.enhance.OrderedReturn;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTChain
/*     */   extends SimpleNode
/*     */   implements NodeType, OrderedReturn
/*     */ {
/*     */   private Class _getterClass;
/*     */   private Class _setterClass;
/*     */   private String _lastExpression;
/*     */   private String _coreExpression;
/*     */   
/*     */   public ASTChain(int id) {
/*  55 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTChain(OgnlParser p, int id) {
/*  60 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLastExpression() {
/*  65 */     return this._lastExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoreExpression() {
/*  70 */     return this._coreExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public void jjtClose() {
/*  75 */     flattenTree();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  81 */     Object result = source;
/*     */     
/*  83 */     for (int i = 0, ilast = this._children.length - 1; i <= ilast; i++) {
/*     */       
/*  85 */       boolean handled = false;
/*     */       
/*  87 */       if (i < ilast && 
/*  88 */         this._children[i] instanceof ASTProperty) {
/*  89 */         ASTProperty propertyNode = (ASTProperty)this._children[i];
/*  90 */         int indexType = propertyNode.getIndexedPropertyType(context, result);
/*     */         
/*  92 */         if (indexType != OgnlRuntime.INDEXED_PROPERTY_NONE && this._children[i + 1] instanceof ASTProperty) {
/*  93 */           ASTProperty indexNode = (ASTProperty)this._children[i + 1];
/*     */           
/*  95 */           if (indexNode.isIndexedAccess()) {
/*  96 */             Object index = indexNode.getProperty(context, result);
/*     */             
/*  98 */             if (index instanceof DynamicSubscript) {
/*  99 */               if (indexType == OgnlRuntime.INDEXED_PROPERTY_INT)
/* 100 */               { Object array = propertyNode.getValue(context, result);
/* 101 */                 int len = Array.getLength(array);
/*     */                 
/* 103 */                 switch (((DynamicSubscript)index).getFlag()) {
/*     */                   case 3:
/* 105 */                     result = Array.newInstance(array.getClass().getComponentType(), len);
/* 106 */                     System.arraycopy(array, 0, result, 0, len);
/* 107 */                     handled = true;
/* 108 */                     i++;
/*     */                     break;
/*     */                   case 0:
/* 111 */                     index = new Integer((len > 0) ? 0 : -1);
/*     */                     break;
/*     */                   case 1:
/* 114 */                     index = new Integer((len > 0) ? (len / 2) : -1);
/*     */                     break;
/*     */                   case 2:
/* 117 */                     index = new Integer((len > 0) ? (len - 1) : -1);
/*     */                     break;
/*     */                 } 
/*     */                  }
/* 121 */               else if (indexType == OgnlRuntime.INDEXED_PROPERTY_OBJECT) { throw new OgnlException("DynamicSubscript '" + indexNode + "' not allowed for object indexed property '" + propertyNode + "'"); }
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 127 */             if (!handled) {
/*     */               
/* 129 */               result = OgnlRuntime.getIndexedProperty(context, result, propertyNode.getProperty(context, result).toString(), index);
/*     */ 
/*     */               
/* 132 */               handled = true;
/* 133 */               i++;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 139 */       if (!handled)
/*     */       {
/* 141 */         result = this._children[i].getValue(context, result);
/*     */       }
/*     */     } 
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 150 */     boolean handled = false;
/*     */     
/* 152 */     for (int i = 0, ilast = this._children.length - 2; i <= ilast; i++) {
/*     */       
/* 154 */       if (i <= ilast && 
/* 155 */         this._children[i] instanceof ASTProperty) {
/*     */         
/* 157 */         ASTProperty propertyNode = (ASTProperty)this._children[i];
/* 158 */         int indexType = propertyNode.getIndexedPropertyType(context, target);
/*     */         
/* 160 */         if (indexType != OgnlRuntime.INDEXED_PROPERTY_NONE && this._children[i + 1] instanceof ASTProperty) {
/*     */           
/* 162 */           ASTProperty indexNode = (ASTProperty)this._children[i + 1];
/*     */           
/* 164 */           if (indexNode.isIndexedAccess()) {
/*     */             
/* 166 */             Object index = indexNode.getProperty(context, target);
/*     */             
/* 168 */             if (index instanceof DynamicSubscript)
/*     */             {
/* 170 */               if (indexType == OgnlRuntime.INDEXED_PROPERTY_INT) {
/*     */                 
/* 172 */                 Object array = propertyNode.getValue(context, target);
/* 173 */                 int len = Array.getLength(array);
/*     */                 
/* 175 */                 switch (((DynamicSubscript)index).getFlag()) {
/*     */                   
/*     */                   case 3:
/* 178 */                     System.arraycopy(target, 0, value, 0, len);
/* 179 */                     handled = true;
/* 180 */                     i++;
/*     */                     break;
/*     */                   case 0:
/* 183 */                     index = new Integer((len > 0) ? 0 : -1);
/*     */                     break;
/*     */                   case 1:
/* 186 */                     index = new Integer((len > 0) ? (len / 2) : -1);
/*     */                     break;
/*     */                   case 2:
/* 189 */                     index = new Integer((len > 0) ? (len - 1) : -1);
/*     */                     break;
/*     */                 } 
/*     */ 
/*     */               
/* 194 */               } else if (indexType == OgnlRuntime.INDEXED_PROPERTY_OBJECT) {
/*     */                 
/* 196 */                 throw new OgnlException("DynamicSubscript '" + indexNode + "' not allowed for object indexed property '" + propertyNode + "'");
/*     */               } 
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 202 */             if (!handled && i == ilast) {
/*     */               
/* 204 */               OgnlRuntime.setIndexedProperty(context, target, propertyNode.getProperty(context, target).toString(), index, value);
/*     */ 
/*     */               
/* 207 */               handled = true;
/* 208 */               i++;
/* 209 */             } else if (!handled) {
/* 210 */               target = OgnlRuntime.getIndexedProperty(context, target, propertyNode.getProperty(context, target).toString(), index);
/*     */ 
/*     */               
/* 213 */               i++;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 220 */       if (!handled)
/*     */       {
/* 222 */         target = this._children[i].getValue(context, target); } 
/*     */       continue;
/*     */     } 
/* 225 */     if (!handled)
/*     */     {
/* 227 */       this._children[this._children.length - 1].setValue(context, target, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSimpleNavigationChain(OgnlContext context) throws OgnlException {
/* 234 */     boolean result = false;
/*     */     
/* 236 */     if (this._children != null && this._children.length > 0) {
/* 237 */       result = true;
/* 238 */       for (int i = 0; result && i < this._children.length; i++) {
/* 239 */         if (this._children[i] instanceof SimpleNode) {
/* 240 */           result = ((SimpleNode)this._children[i]).isSimpleProperty(context);
/*     */         } else {
/* 242 */           result = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 246 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/* 251 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/* 256 */     return this._setterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 261 */     String result = "";
/*     */     
/* 263 */     if (this._children != null && this._children.length > 0) {
/* 264 */       for (int i = 0; i < this._children.length; i++) {
/* 265 */         if (i > 0 && (
/* 266 */           !(this._children[i] instanceof ASTProperty) || !((ASTProperty)this._children[i]).isIndexedAccess())) {
/* 267 */           result = result + ".";
/*     */         }
/*     */         
/* 270 */         result = result + this._children[i].toString();
/*     */       } 
/*     */     }
/* 273 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 278 */     String prevChain = (String)context.get("_currentChain");
/*     */     
/* 280 */     if (target != null) {
/*     */       
/* 282 */       context.setCurrentObject(target);
/* 283 */       context.setCurrentType(target.getClass());
/*     */     } 
/*     */     
/* 286 */     String result = "";
/* 287 */     NodeType _lastType = null;
/* 288 */     boolean ordered = false;
/* 289 */     boolean constructor = false;
/*     */     try {
/* 291 */       if (this._children != null && this._children.length > 0)
/*     */       {
/* 293 */         for (int i = 0; i < this._children.length; i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 299 */           String value = this._children[i].toGetSourceString(context, context.getCurrentObject());
/*     */ 
/*     */ 
/*     */           
/* 303 */           if (ASTCtor.class.isInstance(this._children[i])) {
/* 304 */             constructor = true;
/*     */           }
/* 306 */           if (NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null)
/*     */           {
/*     */             
/* 309 */             _lastType = (NodeType)this._children[i];
/*     */           }
/*     */ 
/*     */           
/* 313 */           if (!ASTVarRef.class.isInstance(this._children[i]) && !constructor && (!OrderedReturn.class.isInstance(this._children[i]) || ((OrderedReturn)this._children[i]).getLastExpression() == null) && (this._parent == null || !ASTSequence.class.isInstance(this._parent)))
/*     */           {
/*     */ 
/*     */             
/* 317 */             value = OgnlRuntime.getCompiler().castExpression(context, this._children[i], value);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 324 */           if (OrderedReturn.class.isInstance(this._children[i]) && ((OrderedReturn)this._children[i]).getLastExpression() != null) {
/*     */             
/* 326 */             ordered = true;
/* 327 */             OrderedReturn or = (OrderedReturn)this._children[i];
/*     */             
/* 329 */             if (or.getCoreExpression() == null || or.getCoreExpression().trim().length() <= 0) {
/* 330 */               result = "";
/*     */             } else {
/* 332 */               result = result + or.getCoreExpression();
/*     */             } 
/* 334 */             this._lastExpression = or.getLastExpression();
/*     */             
/* 336 */             if (context.get("_preCast") != null)
/*     */             {
/* 338 */               this._lastExpression = context.remove("_preCast") + this._lastExpression;
/*     */             }
/* 340 */           } else if (ASTOr.class.isInstance(this._children[i]) || ASTAnd.class.isInstance(this._children[i]) || ASTCtor.class.isInstance(this._children[i]) || (ASTStaticField.class.isInstance(this._children[i]) && this._parent == null)) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 345 */             context.put("_noRoot", "true");
/* 346 */             result = value;
/*     */           } else {
/*     */             
/* 349 */             result = result + value;
/*     */           } 
/*     */           
/* 352 */           context.put("_currentChain", result);
/*     */         } 
/*     */       }
/* 355 */     } catch (Throwable t) {
/*     */       
/* 357 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 360 */     if (_lastType != null) {
/*     */       
/* 362 */       this._getterClass = _lastType.getGetterClass();
/* 363 */       this._setterClass = _lastType.getSetterClass();
/*     */     } 
/*     */     
/* 366 */     if (ordered)
/*     */     {
/* 368 */       this._coreExpression = result;
/*     */     }
/*     */     
/* 371 */     context.put("_currentChain", prevChain);
/*     */     
/* 373 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 378 */     String prevChain = (String)context.get("_currentChain");
/* 379 */     String prevChild = (String)context.get("_lastChild");
/*     */     
/* 381 */     if (prevChain != null) {
/* 382 */       throw new UnsupportedCompilationException("Can't compile nested chain expressions.");
/*     */     }
/* 384 */     if (target != null) {
/*     */       
/* 386 */       context.setCurrentObject(target);
/* 387 */       context.setCurrentType(target.getClass());
/*     */     } 
/*     */     
/* 390 */     String result = "";
/* 391 */     NodeType _lastType = null;
/* 392 */     boolean constructor = false;
/*     */     try {
/* 394 */       if (this._children != null && this._children.length > 0) {
/*     */         
/* 396 */         if (ASTConst.class.isInstance(this._children[0]))
/*     */         {
/* 398 */           throw new UnsupportedCompilationException("Can't modify constant values.");
/*     */         }
/*     */         
/* 401 */         for (int i = 0; i < this._children.length; i++) {
/*     */ 
/*     */ 
/*     */           
/* 405 */           if (i == this._children.length - 1)
/*     */           {
/* 407 */             context.put("_lastChild", "true");
/*     */           }
/*     */           
/* 410 */           String value = this._children[i].toSetSourceString(context, context.getCurrentObject());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 416 */           if (ASTCtor.class.isInstance(this._children[i])) {
/* 417 */             constructor = true;
/*     */           }
/* 419 */           if (NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null)
/*     */           {
/*     */             
/* 422 */             _lastType = (NodeType)this._children[i];
/*     */           }
/*     */           
/* 425 */           if (!ASTVarRef.class.isInstance(this._children[i]) && !constructor && (!OrderedReturn.class.isInstance(this._children[i]) || ((OrderedReturn)this._children[i]).getLastExpression() == null) && (this._parent == null || !ASTSequence.class.isInstance(this._parent)))
/*     */           {
/*     */ 
/*     */             
/* 429 */             value = OgnlRuntime.getCompiler().castExpression(context, this._children[i], value);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 440 */           if (ASTOr.class.isInstance(this._children[i]) || ASTAnd.class.isInstance(this._children[i]) || ASTCtor.class.isInstance(this._children[i]) || ASTStaticField.class.isInstance(this._children[i])) {
/*     */ 
/*     */ 
/*     */             
/* 444 */             context.put("_noRoot", "true");
/* 445 */             result = value;
/*     */           } else {
/* 447 */             result = result + value;
/*     */           } 
/* 449 */           context.put("_currentChain", result);
/*     */         } 
/*     */       } 
/* 452 */     } catch (Throwable t) {
/*     */       
/* 454 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 457 */     context.put("_lastChild", prevChild);
/* 458 */     context.put("_currentChain", prevChain);
/*     */     
/* 460 */     if (_lastType != null) {
/* 461 */       this._setterClass = _lastType.getSetterClass();
/*     */     }
/* 463 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isChain(OgnlContext context) {
/* 468 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTChain.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */