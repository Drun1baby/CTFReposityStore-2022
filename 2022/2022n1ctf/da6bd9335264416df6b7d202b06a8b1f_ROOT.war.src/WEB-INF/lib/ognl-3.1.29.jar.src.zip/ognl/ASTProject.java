/*    */ package ognl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTProject
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTProject(int id) {
/* 48 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public ASTProject(OgnlParser p, int id) {
/* 53 */     super(p, id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 59 */     Node expr = this._children[0];
/* 60 */     List<Object> answer = new ArrayList();
/*    */     
/* 62 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(source));
/*    */     
/* 64 */     for (Enumeration e = elementsAccessor.getElements(source); e.hasMoreElements();)
/*    */     {
/* 66 */       answer.add(expr.getValue(context, e.nextElement()));
/*    */     }
/*    */     
/* 69 */     return answer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return "{ " + this._children[0] + " }";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 79 */     throw new UnsupportedCompilationException("Projection expressions not supported as native java yet.");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 84 */     throw new UnsupportedCompilationException("Projection expressions not supported as native java yet.");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTProject.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */