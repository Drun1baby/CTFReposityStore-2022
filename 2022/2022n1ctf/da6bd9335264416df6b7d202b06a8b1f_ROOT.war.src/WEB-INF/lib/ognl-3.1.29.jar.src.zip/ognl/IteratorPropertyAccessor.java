/*    */ package ognl;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*    */     Object result;
/* 47 */     Iterator iterator = (Iterator)target;
/*    */     
/* 49 */     if (name instanceof String) {
/* 50 */       if (name.equals("next")) {
/* 51 */         result = iterator.next();
/*    */       }
/* 53 */       else if (name.equals("hasNext")) {
/* 54 */         result = iterator.hasNext() ? Boolean.TRUE : Boolean.FALSE;
/*    */       } else {
/* 56 */         result = super.getProperty(context, target, name);
/*    */       } 
/*    */     } else {
/*    */       
/* 60 */       result = super.getProperty(context, target, name);
/*    */     } 
/* 62 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 67 */     throw new IllegalArgumentException("can't set property " + name + " on Iterator");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\IteratorPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */