/*     */ package ognl;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlException
/*     */   extends Exception
/*     */ {
/*     */   static Method _initCause;
/*     */   private Evaluation _evaluation;
/*     */   private Throwable _reason;
/*     */   
/*     */   static {
/*     */     try {
/*  50 */       _initCause = OgnlException.class.getMethod("initCause", new Class[] { Throwable.class });
/*  51 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlException() {
/*  68 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlException(String msg) {
/*  77 */     this(msg, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlException(String msg, Throwable reason) {
/*  87 */     super(msg);
/*  88 */     this._reason = reason;
/*     */     
/*  90 */     if (_initCause != null) {
/*     */       
/*     */       try {
/*  93 */         _initCause.invoke(this, new Object[] { reason });
/*  94 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getReason() {
/* 104 */     return this._reason;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getEvaluation() {
/* 114 */     return this._evaluation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEvaluation(Evaluation value) {
/* 124 */     this._evaluation = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     if (this._reason == null) {
/* 134 */       return super.toString();
/*     */     }
/* 136 */     return super.toString() + " [" + this._reason + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/* 146 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream s) {
/* 155 */     synchronized (s) {
/*     */       
/* 157 */       super.printStackTrace(s);
/* 158 */       if (this._reason != null) {
/* 159 */         s.println("/-- Encapsulated exception ------------\\");
/* 160 */         this._reason.printStackTrace(s);
/* 161 */         s.println("\\--------------------------------------/");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter s) {
/* 172 */     synchronized (s) {
/*     */       
/* 174 */       super.printStackTrace(s);
/* 175 */       if (this._reason != null) {
/* 176 */         s.println("/-- Encapsulated exception ------------\\");
/* 177 */         this._reason.printStackTrace(s);
/* 178 */         s.println("\\--------------------------------------/");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */