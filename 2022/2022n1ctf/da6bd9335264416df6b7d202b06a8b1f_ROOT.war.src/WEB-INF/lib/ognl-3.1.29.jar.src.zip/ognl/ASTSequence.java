/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.OrderedReturn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTSequence
/*     */   extends SimpleNode
/*     */   implements NodeType, OrderedReturn
/*     */ {
/*     */   private Class _getterClass;
/*     */   private String _lastExpression;
/*     */   private String _coreExpression;
/*     */   
/*     */   public ASTSequence(int id) {
/*  47 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTSequence(OgnlParser p, int id) {
/*  51 */     super(p, id);
/*     */   }
/*     */   
/*     */   public void jjtClose() {
/*  55 */     flattenTree();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  60 */     Object result = null;
/*  61 */     for (int i = 0; i < this._children.length; i++)
/*     */     {
/*  63 */       result = this._children[i].getValue(context, source);
/*     */     }
/*     */     
/*  66 */     return result;
/*     */   }
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/*  70 */     int last = this._children.length - 1;
/*  71 */     for (int i = 0; i < last; i++) {
/*  72 */       this._children[i].getValue(context, target);
/*     */     }
/*  74 */     this._children[last].setValue(context, target, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  79 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLastExpression() {
/*  89 */     return this._lastExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoreExpression() {
/*  94 */     return this._coreExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     String result = "";
/*     */     
/* 101 */     for (int i = 0; i < this._children.length; i++) {
/* 102 */       if (i > 0) {
/* 103 */         result = result + ", ";
/*     */       }
/* 105 */       result = result + this._children[i];
/*     */     } 
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 112 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 117 */     String result = "";
/*     */     
/* 119 */     NodeType _lastType = null;
/*     */     
/* 121 */     for (int i = 0; i < this._children.length; i++) {
/*     */ 
/*     */       
/* 124 */       String seqValue = this._children[i].toGetSourceString(context, target);
/*     */       
/* 126 */       if (i + 1 < this._children.length && ASTOr.class.isInstance(this._children[i]))
/*     */       {
/* 128 */         seqValue = "(" + seqValue + ")";
/*     */       }
/*     */       
/* 131 */       if (i > 0 && ASTProperty.class.isInstance(this._children[i]) && seqValue != null && seqValue.trim().length() > 0) {
/*     */ 
/*     */         
/* 134 */         String pre = (String)context.get("_currentChain");
/* 135 */         if (pre == null) {
/* 136 */           pre = "";
/*     */         }
/* 138 */         seqValue = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + pre + seqValue;
/* 139 */         context.setCurrentAccessor(context.getRoot().getClass());
/*     */       } 
/*     */       
/* 142 */       if (i + 1 >= this._children.length) {
/*     */         
/* 144 */         this._coreExpression = result;
/* 145 */         this._lastExpression = seqValue;
/*     */       } 
/*     */       
/* 148 */       if (seqValue != null && seqValue.trim().length() > 0 && i + 1 < this._children.length) {
/* 149 */         result = result + seqValue + ";";
/* 150 */       } else if (seqValue != null && seqValue.trim().length() > 0) {
/* 151 */         result = result + seqValue;
/*     */       } 
/*     */ 
/*     */       
/* 155 */       if (NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null) {
/* 156 */         _lastType = (NodeType)this._children[i];
/*     */       }
/*     */     } 
/* 159 */     if (_lastType != null)
/*     */     {
/* 161 */       this._getterClass = _lastType.getGetterClass();
/*     */     }
/*     */     
/* 164 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isSequence(OgnlContext context) {
/* 168 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTSequence.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */