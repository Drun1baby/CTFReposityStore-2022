/*    */ package ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorEnumeration
/*    */   implements Enumeration
/*    */ {
/*    */   private Iterator it;
/*    */   
/*    */   public IteratorEnumeration(Iterator it) {
/* 47 */     this.it = it;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements() {
/* 51 */     return this.it.hasNext();
/*    */   }
/*    */   
/*    */   public Object nextElement() {
/* 55 */     return this.it.next();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\IteratorEnumeration.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */