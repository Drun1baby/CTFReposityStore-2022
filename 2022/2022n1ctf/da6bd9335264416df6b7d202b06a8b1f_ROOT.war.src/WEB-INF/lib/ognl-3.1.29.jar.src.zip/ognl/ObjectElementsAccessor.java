/*    */ package ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(Object target) {
/* 45 */     final Object object = target;
/*    */     
/* 47 */     return new Enumeration() {
/*    */         private boolean seen = false;
/*    */         
/*    */         public boolean hasMoreElements() {
/* 51 */           return !this.seen;
/*    */         }
/*    */         
/*    */         public Object nextElement() {
/* 55 */           Object result = null;
/*    */           
/* 57 */           if (!this.seen) {
/* 58 */             result = object;
/* 59 */             this.seen = true;
/*    */           } 
/* 61 */           return result;
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectElementsAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */