/*      */ package ognl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OgnlParserTokenManager
/*      */   implements OgnlParserConstants
/*      */ {
/*      */   Object literalValue;
/*      */   private char charValue;
/*      */   private char charLiteralStartQuote;
/*      */   private StringBuffer stringBuffer;
/*      */   
/*      */   private char escapeChar() {
/*   22 */     int ofs = this.image.length() - 1;
/*   23 */     switch (this.image.charAt(ofs)) { case 'n':
/*   24 */         return '\n';
/*   25 */       case 'r': return '\r';
/*   26 */       case 't': return '\t';
/*   27 */       case 'b': return '\b';
/*   28 */       case 'f': return '\f';
/*   29 */       case '\\': return '\\';
/*   30 */       case '\'': return '\'';
/*   31 */       case '"': return '"'; }
/*      */ 
/*      */ 
/*      */     
/*   35 */     while (this.image.charAt(--ofs) != '\\');
/*      */     
/*   37 */     int value = 0;
/*   38 */     while (++ofs < this.image.length())
/*   39 */       value = value << 3 | this.image.charAt(ofs) - 48; 
/*   40 */     return (char)value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object makeInt() {
/*   46 */     String s = this.image.toString();
/*   47 */     int base = 10;
/*      */     
/*   49 */     if (s.charAt(0) == '0')
/*   50 */       base = (s.length() > 1 && (s.charAt(1) == 'x' || s.charAt(1) == 'X')) ? 16 : 8; 
/*   51 */     if (base == 16)
/*   52 */       s = s.substring(2); 
/*   53 */     switch (s.charAt(s.length() - 1)) { case 'L':
/*      */       case 'l':
/*   55 */         result = Long.valueOf(s.substring(0, s.length() - 1), base);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*   66 */         return result;case 'H': case 'h': result = new BigInteger(s.substring(0, s.length() - 1), base); return result; }  Object result = Integer.valueOf(s, base); return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private Object makeFloat() {
/*   71 */     String s = this.image.toString();
/*   72 */     switch (s.charAt(s.length() - 1)) { case 'F':
/*      */       case 'f':
/*   74 */         return Float.valueOf(s);
/*      */       case 'B':
/*      */       case 'b':
/*   77 */         return new BigDecimal(s.substring(0, s.length() - 1)); }
/*      */ 
/*      */ 
/*      */     
/*   81 */     return Double.valueOf(s);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*   86 */   public PrintStream debugStream = System.out;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDebugStream(PrintStream ds) {
/*   93 */     this.debugStream = ds;
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0, long active1) {
/*   97 */     switch (pos) {
/*      */       
/*      */       case 0:
/*  100 */         if ((active0 & 0x201C4055D555540L) != 0L) {
/*      */           
/*  102 */           this.jjmatchedKind = 64;
/*  103 */           return 1;
/*      */         } 
/*  105 */         if ((active0 & 0x400000000000000L) != 0L)
/*  106 */           return 1; 
/*  107 */         if ((active0 & 0x10000000000000L) != 0L)
/*  108 */           return 3; 
/*  109 */         if ((active0 & 0x80000000000L) != 0L)
/*  110 */           return 9; 
/*  111 */         return -1;
/*      */       case 1:
/*  113 */         if ((active0 & 0x201C00550045500L) != 0L) {
/*      */           
/*  115 */           if (this.jjmatchedPos != 1) {
/*      */             
/*  117 */             this.jjmatchedKind = 64;
/*  118 */             this.jjmatchedPos = 1;
/*      */           } 
/*  120 */           return 1;
/*      */         } 
/*  122 */         if ((active0 & 0x4000D510040L) != 0L)
/*  123 */           return 1; 
/*  124 */         return -1;
/*      */       case 2:
/*  126 */         if ((active0 & 0x1C40400004000L) != 0L) {
/*      */           
/*  128 */           this.jjmatchedKind = 64;
/*  129 */           this.jjmatchedPos = 2;
/*  130 */           return 1;
/*      */         } 
/*  132 */         if ((active0 & 0x200000155041500L) != 0L)
/*  133 */           return 1; 
/*  134 */         return -1;
/*      */       case 3:
/*  136 */         if ((active0 & 0x1400400004000L) != 0L)
/*  137 */           return 1; 
/*  138 */         if ((active0 & 0x840000000000L) != 0L) {
/*      */           
/*  140 */           this.jjmatchedKind = 64;
/*  141 */           this.jjmatchedPos = 3;
/*  142 */           return 1;
/*      */         } 
/*  144 */         return -1;
/*      */       case 4:
/*  146 */         if ((active0 & 0x800000000000L) != 0L)
/*  147 */           return 1; 
/*  148 */         if ((active0 & 0x40000000000L) != 0L) {
/*      */           
/*  150 */           this.jjmatchedKind = 64;
/*  151 */           this.jjmatchedPos = 4;
/*  152 */           return 1;
/*      */         } 
/*  154 */         return -1;
/*      */       case 5:
/*  156 */         if ((active0 & 0x40000000000L) != 0L) {
/*      */           
/*  158 */           this.jjmatchedKind = 64;
/*  159 */           this.jjmatchedPos = 5;
/*  160 */           return 1;
/*      */         } 
/*  162 */         return -1;
/*      */       case 6:
/*  164 */         if ((active0 & 0x40000000000L) != 0L) {
/*      */           
/*  166 */           this.jjmatchedKind = 64;
/*  167 */           this.jjmatchedPos = 6;
/*  168 */           return 1;
/*      */         } 
/*  170 */         return -1;
/*      */       case 7:
/*  172 */         if ((active0 & 0x40000000000L) != 0L) {
/*      */           
/*  174 */           this.jjmatchedKind = 64;
/*  175 */           this.jjmatchedPos = 7;
/*  176 */           return 1;
/*      */         } 
/*  178 */         return -1;
/*      */       case 8:
/*  180 */         if ((active0 & 0x40000000000L) != 0L) {
/*      */           
/*  182 */           this.jjmatchedKind = 64;
/*  183 */           this.jjmatchedPos = 8;
/*  184 */           return 1;
/*      */         } 
/*  186 */         return -1;
/*      */     } 
/*  188 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0, long active1) {
/*  193 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*  197 */     this.jjmatchedKind = kind;
/*  198 */     this.jjmatchedPos = pos;
/*  199 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*  203 */     switch (this.curChar) {
/*      */       
/*      */       case '!':
/*  206 */         this.jjmatchedKind = 41;
/*  207 */         return jjMoveStringLiteralDfa1_0(131072L);
/*      */       case '"':
/*  209 */         return jjStopAtPos(0, 70);
/*      */       case '#':
/*  211 */         this.jjmatchedKind = 51;
/*  212 */         return jjMoveStringLiteralDfa1_0(1688849860263936L);
/*      */       case '$':
/*  214 */         return jjStartNfaWithStates_0(0, 58, 1);
/*      */       case '%':
/*  216 */         return jjStopAtPos(0, 39);
/*      */       case '&':
/*  218 */         this.jjmatchedKind = 13;
/*  219 */         return jjMoveStringLiteralDfa1_0(128L);
/*      */       case '\'':
/*  221 */         return jjStopAtPos(0, 69);
/*      */       case '(':
/*  223 */         return jjStopAtPos(0, 44);
/*      */       case ')':
/*  225 */         return jjStopAtPos(0, 45);
/*      */       case '*':
/*  227 */         return jjStopAtPos(0, 37);
/*      */       case '+':
/*  229 */         return jjStopAtPos(0, 35);
/*      */       case ',':
/*  231 */         return jjStopAtPos(0, 1);
/*      */       case '-':
/*  233 */         return jjStopAtPos(0, 36);
/*      */       case '.':
/*  235 */         return jjStartNfaWithStates_0(0, 43, 9);
/*      */       case '/':
/*  237 */         return jjStopAtPos(0, 38);
/*      */       case ':':
/*  239 */         return jjStopAtPos(0, 4);
/*      */       case '<':
/*  241 */         this.jjmatchedKind = 19;
/*  242 */         return jjMoveStringLiteralDfa1_0(545259520L);
/*      */       case '=':
/*  244 */         this.jjmatchedKind = 2;
/*  245 */         return jjMoveStringLiteralDfa1_0(32768L);
/*      */       case '>':
/*  247 */         this.jjmatchedKind = 21;
/*  248 */         return jjMoveStringLiteralDfa1_0(10770972672L);
/*      */       case '?':
/*  250 */         return jjStopAtPos(0, 3);
/*      */       case '@':
/*  252 */         return jjStopAtPos(0, 56);
/*      */       case '[':
/*  254 */         return jjStartNfaWithStates_0(0, 52, 3);
/*      */       case ']':
/*  256 */         return jjStopAtPos(0, 53);
/*      */       case '^':
/*  258 */         return jjStopAtPos(0, 11);
/*      */       case '`':
/*  260 */         return jjStopAtPos(0, 68);
/*      */       case 'a':
/*  262 */         return jjMoveStringLiteralDfa1_0(256L);
/*      */       case 'b':
/*  264 */         return jjMoveStringLiteralDfa1_0(17408L);
/*      */       case 'e':
/*  266 */         return jjMoveStringLiteralDfa1_0(65536L);
/*      */       case 'f':
/*  268 */         return jjMoveStringLiteralDfa1_0(140737488355328L);
/*      */       case 'g':
/*  270 */         return jjMoveStringLiteralDfa1_0(71303168L);
/*      */       case 'i':
/*  272 */         return jjMoveStringLiteralDfa1_0(4398180728832L);
/*      */       case 'l':
/*  274 */         return jjMoveStringLiteralDfa1_0(17825792L);
/*      */       case 'n':
/*  276 */         return jjMoveStringLiteralDfa1_0(144396663321264128L);
/*      */       case 'o':
/*  278 */         return jjMoveStringLiteralDfa1_0(64L);
/*      */       case 's':
/*  280 */         return jjMoveStringLiteralDfa1_0(5368709120L);
/*      */       case 't':
/*  282 */         return jjMoveStringLiteralDfa1_0(70368744177664L);
/*      */       case 'u':
/*  284 */         return jjMoveStringLiteralDfa1_0(17179869184L);
/*      */       case 'x':
/*  286 */         return jjMoveStringLiteralDfa1_0(4096L);
/*      */       case '{':
/*  288 */         return jjStopAtPos(0, 54);
/*      */       case '|':
/*  290 */         this.jjmatchedKind = 9;
/*  291 */         return jjMoveStringLiteralDfa1_0(32L);
/*      */       case '}':
/*  293 */         return jjStopAtPos(0, 55);
/*      */       case '~':
/*  295 */         return jjStopAtPos(0, 40);
/*      */     } 
/*  297 */     return jjMoveNfa_0(0, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*  302 */       this.curChar = this.input_stream.readChar();
/*  303 */     } catch (IOException e) {
/*  304 */       jjStopStringLiteralDfa_0(0, active0, 0L);
/*  305 */       return 1;
/*      */     } 
/*  307 */     switch (this.curChar) {
/*      */       
/*      */       case '&':
/*  310 */         if ((active0 & 0x80L) != 0L)
/*  311 */           return jjStopAtPos(1, 7); 
/*      */         break;
/*      */       case '<':
/*  314 */         if ((active0 & 0x20000000L) != 0L)
/*  315 */           return jjStopAtPos(1, 29); 
/*      */         break;
/*      */       case '=':
/*  318 */         if ((active0 & 0x8000L) != 0L)
/*  319 */           return jjStopAtPos(1, 15); 
/*  320 */         if ((active0 & 0x20000L) != 0L)
/*  321 */           return jjStopAtPos(1, 17); 
/*  322 */         if ((active0 & 0x800000L) != 0L)
/*  323 */           return jjStopAtPos(1, 23); 
/*  324 */         if ((active0 & 0x2000000L) != 0L)
/*  325 */           return jjStopAtPos(1, 25); 
/*      */         break;
/*      */       case '>':
/*  328 */         if ((active0 & 0x80000000L) != 0L) {
/*      */           
/*  330 */           this.jjmatchedKind = 31;
/*  331 */           this.jjmatchedPos = 1;
/*      */         } 
/*  333 */         return jjMoveStringLiteralDfa2_0(active0, 8589934592L);
/*      */       case 'a':
/*  335 */         return jjMoveStringLiteralDfa2_0(active0, 140737488371712L);
/*      */       case 'e':
/*  337 */         return jjMoveStringLiteralDfa2_0(active0, 144115188076118016L);
/*      */       case 'h':
/*  339 */         return jjMoveStringLiteralDfa2_0(active0, 5368709120L);
/*      */       case 'n':
/*  341 */         if ((active0 & 0x8000000L) != 0L) {
/*      */           
/*  343 */           this.jjmatchedKind = 27;
/*  344 */           this.jjmatchedPos = 1;
/*      */         } 
/*  346 */         return jjMoveStringLiteralDfa2_0(active0, 4398046511360L);
/*      */       case 'o':
/*  348 */         return jjMoveStringLiteralDfa2_0(active0, 268440576L);
/*      */       case 'q':
/*  350 */         if ((active0 & 0x10000L) != 0L)
/*  351 */           return jjStartNfaWithStates_0(1, 16, 1); 
/*      */         break;
/*      */       case 'r':
/*  354 */         if ((active0 & 0x40L) != 0L)
/*  355 */           return jjStartNfaWithStates_0(1, 6, 1); 
/*  356 */         return jjMoveStringLiteralDfa2_0(active0, 1196268651020288L);
/*      */       case 's':
/*  358 */         return jjMoveStringLiteralDfa2_0(active0, 17179869184L);
/*      */       case 't':
/*  360 */         if ((active0 & 0x100000L) != 0L) {
/*      */           
/*  362 */           this.jjmatchedKind = 20;
/*  363 */           this.jjmatchedPos = 1;
/*      */         }
/*  365 */         else if ((active0 & 0x400000L) != 0L) {
/*      */           
/*  367 */           this.jjmatchedKind = 22;
/*  368 */           this.jjmatchedPos = 1;
/*      */         } 
/*  370 */         return jjMoveStringLiteralDfa2_0(active0, 562950037307392L);
/*      */       case 'u':
/*  372 */         return jjMoveStringLiteralDfa2_0(active0, 281474976710656L);
/*      */       case '|':
/*  374 */         if ((active0 & 0x20L) != 0L) {
/*  375 */           return jjStopAtPos(1, 5);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  380 */     return jjStartNfa_0(0, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_0(long old0, long active0) {
/*  384 */     if ((active0 &= old0) == 0L)
/*  385 */       return jjStartNfa_0(0, old0, 0L);  try {
/*  386 */       this.curChar = this.input_stream.readChar();
/*  387 */     } catch (IOException e) {
/*  388 */       jjStopStringLiteralDfa_0(1, active0, 0L);
/*  389 */       return 2;
/*      */     } 
/*  391 */     switch (this.curChar) {
/*      */       
/*      */       case '>':
/*  394 */         if ((active0 & 0x200000000L) != 0L)
/*  395 */           return jjStopAtPos(2, 33); 
/*      */         break;
/*      */       case 'd':
/*  398 */         if ((active0 & 0x100L) != 0L)
/*  399 */           return jjStartNfaWithStates_0(2, 8, 1); 
/*      */         break;
/*      */       case 'e':
/*  402 */         if ((active0 & 0x1000000L) != 0L)
/*  403 */           return jjStartNfaWithStates_0(2, 24, 1); 
/*  404 */         if ((active0 & 0x4000000L) != 0L)
/*  405 */           return jjStartNfaWithStates_0(2, 26, 1); 
/*      */         break;
/*      */       case 'h':
/*  408 */         return jjMoveStringLiteralDfa3_0(active0, 562967133290496L);
/*      */       case 'l':
/*  410 */         if ((active0 & 0x40000000L) != 0L)
/*  411 */           return jjStartNfaWithStates_0(2, 30, 1); 
/*  412 */         return jjMoveStringLiteralDfa3_0(active0, 422212465065984L);
/*      */       case 'n':
/*  414 */         return jjMoveStringLiteralDfa3_0(active0, 16384L);
/*      */       case 'o':
/*  416 */         return jjMoveStringLiteralDfa3_0(active0, 1125899906842624L);
/*      */       case 'q':
/*  418 */         if ((active0 & 0x40000L) != 0L)
/*  419 */           return jjStartNfaWithStates_0(2, 18, 1); 
/*      */         break;
/*      */       case 'r':
/*  422 */         if ((active0 & 0x400L) != 0L)
/*  423 */           return jjStartNfaWithStates_0(2, 10, 1); 
/*  424 */         if ((active0 & 0x1000L) != 0L)
/*  425 */           return jjStartNfaWithStates_0(2, 12, 1); 
/*  426 */         if ((active0 & 0x100000000L) != 0L)
/*  427 */           return jjStartNfaWithStates_0(2, 32, 1); 
/*      */         break;
/*      */       case 's':
/*  430 */         return jjMoveStringLiteralDfa3_0(active0, 4398046511104L);
/*      */       case 't':
/*  432 */         if ((active0 & 0x10000000L) != 0L)
/*  433 */           return jjStartNfaWithStates_0(2, 28, 1); 
/*      */         break;
/*      */       case 'u':
/*  436 */         return jjMoveStringLiteralDfa3_0(active0, 70368744177664L);
/*      */       case 'w':
/*  438 */         if ((active0 & 0x200000000000000L) != 0L) {
/*  439 */           return jjStartNfaWithStates_0(2, 57, 1);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  444 */     return jjStartNfa_0(1, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_0(long old0, long active0) {
/*  448 */     if ((active0 &= old0) == 0L)
/*  449 */       return jjStartNfa_0(1, old0, 0L);  try {
/*  450 */       this.curChar = this.input_stream.readChar();
/*  451 */     } catch (IOException e) {
/*  452 */       jjStopStringLiteralDfa_0(2, active0, 0L);
/*  453 */       return 3;
/*      */     } 
/*  455 */     switch (this.curChar) {
/*      */       
/*      */       case 'd':
/*  458 */         if ((active0 & 0x4000L) != 0L)
/*  459 */           return jjStartNfaWithStates_0(3, 14, 1); 
/*      */         break;
/*      */       case 'e':
/*  462 */         if ((active0 & 0x400000000000L) != 0L)
/*  463 */           return jjStartNfaWithStates_0(3, 46, 1); 
/*      */         break;
/*      */       case 'i':
/*  466 */         return jjMoveStringLiteralDfa4_0(active0, 562949953421312L);
/*      */       case 'l':
/*  468 */         if ((active0 & 0x1000000000000L) != 0L)
/*  469 */           return jjStartNfaWithStates_0(3, 48, 1); 
/*      */         break;
/*      */       case 'o':
/*  472 */         return jjMoveStringLiteralDfa4_0(active0, 1125899906842624L);
/*      */       case 'r':
/*  474 */         if ((active0 & 0x400000000L) != 0L)
/*  475 */           return jjStartNfaWithStates_0(3, 34, 1); 
/*      */         break;
/*      */       case 's':
/*  478 */         return jjMoveStringLiteralDfa4_0(active0, 140737488355328L);
/*      */       case 't':
/*  480 */         return jjMoveStringLiteralDfa4_0(active0, 4398046511104L);
/*      */     } 
/*      */ 
/*      */     
/*  484 */     return jjStartNfa_0(2, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
/*  488 */     if ((active0 &= old0) == 0L)
/*  489 */       return jjStartNfa_0(2, old0, 0L);  try {
/*  490 */       this.curChar = this.input_stream.readChar();
/*  491 */     } catch (IOException e) {
/*  492 */       jjStopStringLiteralDfa_0(3, active0, 0L);
/*  493 */       return 4;
/*      */     } 
/*  495 */     switch (this.curChar) {
/*      */       
/*      */       case 'a':
/*  498 */         return jjMoveStringLiteralDfa5_0(active0, 4398046511104L);
/*      */       case 'e':
/*  500 */         if ((active0 & 0x800000000000L) != 0L)
/*  501 */           return jjStartNfaWithStates_0(4, 47, 1); 
/*      */         break;
/*      */       case 's':
/*  504 */         if ((active0 & 0x2000000000000L) != 0L)
/*  505 */           return jjStopAtPos(4, 49); 
/*      */         break;
/*      */       case 't':
/*  508 */         if ((active0 & 0x4000000000000L) != 0L) {
/*  509 */           return jjStopAtPos(4, 50);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  514 */     return jjStartNfa_0(3, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
/*  518 */     if ((active0 &= old0) == 0L)
/*  519 */       return jjStartNfa_0(3, old0, 0L);  try {
/*  520 */       this.curChar = this.input_stream.readChar();
/*  521 */     } catch (IOException e) {
/*  522 */       jjStopStringLiteralDfa_0(4, active0, 0L);
/*  523 */       return 5;
/*      */     } 
/*  525 */     switch (this.curChar) {
/*      */       
/*      */       case 'n':
/*  528 */         return jjMoveStringLiteralDfa6_0(active0, 4398046511104L);
/*      */     } 
/*      */ 
/*      */     
/*  532 */     return jjStartNfa_0(4, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
/*  536 */     if ((active0 &= old0) == 0L)
/*  537 */       return jjStartNfa_0(4, old0, 0L);  try {
/*  538 */       this.curChar = this.input_stream.readChar();
/*  539 */     } catch (IOException e) {
/*  540 */       jjStopStringLiteralDfa_0(5, active0, 0L);
/*  541 */       return 6;
/*      */     } 
/*  543 */     switch (this.curChar) {
/*      */       
/*      */       case 'c':
/*  546 */         return jjMoveStringLiteralDfa7_0(active0, 4398046511104L);
/*      */     } 
/*      */ 
/*      */     
/*  550 */     return jjStartNfa_0(5, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa7_0(long old0, long active0) {
/*  554 */     if ((active0 &= old0) == 0L)
/*  555 */       return jjStartNfa_0(5, old0, 0L);  try {
/*  556 */       this.curChar = this.input_stream.readChar();
/*  557 */     } catch (IOException e) {
/*  558 */       jjStopStringLiteralDfa_0(6, active0, 0L);
/*  559 */       return 7;
/*      */     } 
/*  561 */     switch (this.curChar) {
/*      */       
/*      */       case 'e':
/*  564 */         return jjMoveStringLiteralDfa8_0(active0, 4398046511104L);
/*      */     } 
/*      */ 
/*      */     
/*  568 */     return jjStartNfa_0(6, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa8_0(long old0, long active0) {
/*  572 */     if ((active0 &= old0) == 0L)
/*  573 */       return jjStartNfa_0(6, old0, 0L);  try {
/*  574 */       this.curChar = this.input_stream.readChar();
/*  575 */     } catch (IOException e) {
/*  576 */       jjStopStringLiteralDfa_0(7, active0, 0L);
/*  577 */       return 8;
/*      */     } 
/*  579 */     switch (this.curChar) {
/*      */       
/*      */       case 'o':
/*  582 */         return jjMoveStringLiteralDfa9_0(active0, 4398046511104L);
/*      */     } 
/*      */ 
/*      */     
/*  586 */     return jjStartNfa_0(7, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa9_0(long old0, long active0) {
/*  590 */     if ((active0 &= old0) == 0L)
/*  591 */       return jjStartNfa_0(7, old0, 0L);  try {
/*  592 */       this.curChar = this.input_stream.readChar();
/*  593 */     } catch (IOException e) {
/*  594 */       jjStopStringLiteralDfa_0(8, active0, 0L);
/*  595 */       return 9;
/*      */     } 
/*  597 */     switch (this.curChar) {
/*      */       
/*      */       case 'f':
/*  600 */         if ((active0 & 0x40000000000L) != 0L) {
/*  601 */           return jjStartNfaWithStates_0(9, 42, 1);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  606 */     return jjStartNfa_0(8, active0, 0L);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  610 */     this.jjmatchedKind = kind;
/*  611 */     this.jjmatchedPos = pos; 
/*  612 */     try { this.curChar = this.input_stream.readChar(); }
/*  613 */     catch (IOException e) { return pos + 1; }
/*  614 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*  616 */   static final long[] jjbitVec0 = new long[] { 2301339413881290750L, -16384L, 4294967295L, 432345564227567616L };
/*      */ 
/*      */   
/*  619 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, 0L, -36028797027352577L };
/*      */ 
/*      */   
/*  622 */   static final long[] jjbitVec3 = new long[] { 0L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  625 */   static final long[] jjbitVec4 = new long[] { -1L, -1L, 65535L, 0L };
/*      */ 
/*      */   
/*  628 */   static final long[] jjbitVec5 = new long[] { -1L, -1L, 0L, 0L };
/*      */ 
/*      */   
/*  631 */   static final long[] jjbitVec6 = new long[] { 70368744177663L, 0L, 0L, 0L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_0(int startState, int curPos) {
/*  637 */     int startsAt = 0;
/*  638 */     this.jjnewStateCnt = 27;
/*  639 */     int i = 1;
/*  640 */     this.jjstateSet[0] = startState;
/*      */     
/*  642 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  645 */       if (++this.jjround == Integer.MAX_VALUE)
/*  646 */         ReInitRounds(); 
/*  647 */       if (this.curChar < '@') {
/*      */         
/*  649 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  652 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  655 */               if ((0x3FF000000000000L & l) != 0L) {
/*  656 */                 jjCheckNAddStates(0, 5);
/*  657 */               } else if (this.curChar == '.') {
/*  658 */                 jjCheckNAdd(9);
/*  659 */               } else if (this.curChar == '$') {
/*      */                 
/*  661 */                 if (kind > 64)
/*  662 */                   kind = 64; 
/*  663 */                 jjCheckNAdd(1);
/*      */               } 
/*  665 */               if ((0x3FE000000000000L & l) != 0L) {
/*      */                 
/*  667 */                 if (kind > 80)
/*  668 */                   kind = 80; 
/*  669 */                 jjCheckNAddTwoStates(6, 7); break;
/*      */               } 
/*  671 */               if (this.curChar == '0') {
/*      */                 
/*  673 */                 if (kind > 80)
/*  674 */                   kind = 80; 
/*  675 */                 jjCheckNAddStates(6, 8);
/*      */               } 
/*      */               break;
/*      */             case 1:
/*  679 */               if ((0x3FF001000000000L & l) == 0L)
/*      */                 break; 
/*  681 */               if (kind > 64)
/*  682 */                 kind = 64; 
/*  683 */               jjCheckNAdd(1);
/*      */               break;
/*      */             case 3:
/*  686 */               if ((0x41000000000L & l) != 0L)
/*  687 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 5:
/*  690 */               if ((0x3FE000000000000L & l) == 0L)
/*      */                 break; 
/*  692 */               if (kind > 80)
/*  693 */                 kind = 80; 
/*  694 */               jjCheckNAddTwoStates(6, 7);
/*      */               break;
/*      */             case 6:
/*  697 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  699 */               if (kind > 80)
/*  700 */                 kind = 80; 
/*  701 */               jjCheckNAddTwoStates(6, 7);
/*      */               break;
/*      */             case 8:
/*  704 */               if (this.curChar == '.')
/*  705 */                 jjCheckNAdd(9); 
/*      */               break;
/*      */             case 9:
/*  708 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  710 */               if (kind > 81)
/*  711 */                 kind = 81; 
/*  712 */               jjCheckNAddStates(9, 11);
/*      */               break;
/*      */             case 11:
/*  715 */               if ((0x280000000000L & l) != 0L)
/*  716 */                 jjCheckNAdd(12); 
/*      */               break;
/*      */             case 12:
/*  719 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  721 */               if (kind > 81)
/*  722 */                 kind = 81; 
/*  723 */               jjCheckNAddTwoStates(12, 13);
/*      */               break;
/*      */             case 14:
/*  726 */               if ((0x3FF000000000000L & l) != 0L)
/*  727 */                 jjCheckNAddStates(0, 5); 
/*      */               break;
/*      */             case 15:
/*  730 */               if ((0x3FF000000000000L & l) != 0L)
/*  731 */                 jjCheckNAddTwoStates(15, 16); 
/*      */               break;
/*      */             case 16:
/*  734 */               if (this.curChar != '.')
/*      */                 break; 
/*  736 */               if (kind > 81)
/*  737 */                 kind = 81; 
/*  738 */               jjCheckNAddStates(12, 14);
/*      */               break;
/*      */             case 17:
/*  741 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  743 */               if (kind > 81)
/*  744 */                 kind = 81; 
/*  745 */               jjCheckNAddStates(12, 14);
/*      */               break;
/*      */             case 18:
/*  748 */               if ((0x3FF000000000000L & l) != 0L)
/*  749 */                 jjCheckNAddTwoStates(18, 19); 
/*      */               break;
/*      */             case 20:
/*  752 */               if ((0x280000000000L & l) != 0L)
/*  753 */                 jjCheckNAdd(21); 
/*      */               break;
/*      */             case 21:
/*  756 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  758 */               if (kind > 81)
/*  759 */                 kind = 81; 
/*  760 */               jjCheckNAddTwoStates(21, 13);
/*      */               break;
/*      */             case 22:
/*  763 */               if ((0x3FF000000000000L & l) != 0L)
/*  764 */                 jjCheckNAddTwoStates(22, 13); 
/*      */               break;
/*      */             case 23:
/*  767 */               if (this.curChar != '0')
/*      */                 break; 
/*  769 */               if (kind > 80)
/*  770 */                 kind = 80; 
/*  771 */               jjCheckNAddStates(6, 8);
/*      */               break;
/*      */             case 24:
/*  774 */               if ((0xFF000000000000L & l) == 0L)
/*      */                 break; 
/*  776 */               if (kind > 80)
/*  777 */                 kind = 80; 
/*  778 */               jjCheckNAddTwoStates(24, 7);
/*      */               break;
/*      */             case 26:
/*  781 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  783 */               if (kind > 80)
/*  784 */                 kind = 80; 
/*  785 */               jjCheckNAddTwoStates(26, 7);
/*      */               break;
/*      */           } 
/*      */         
/*  789 */         } while (i != startsAt);
/*      */       }
/*  791 */       else if (this.curChar < '') {
/*      */         
/*  793 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  796 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  799 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L) {
/*      */                 
/*  801 */                 if (kind > 64)
/*  802 */                   kind = 64; 
/*  803 */                 jjCheckNAdd(1); break;
/*      */               } 
/*  805 */               if (this.curChar == '[')
/*  806 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 1:
/*  809 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  811 */               if (kind > 64)
/*  812 */                 kind = 64; 
/*  813 */               jjCheckNAdd(1);
/*      */               break;
/*      */             case 2:
/*  816 */               if (this.curChar == '[')
/*  817 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 3:
/*  820 */               if ((0x1000000040000000L & l) != 0L)
/*  821 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 4:
/*  824 */               if (this.curChar == ']')
/*  825 */                 kind = 67; 
/*      */               break;
/*      */             case 7:
/*  828 */               if ((0x110000001100L & l) != 0L && kind > 80)
/*  829 */                 kind = 80; 
/*      */               break;
/*      */             case 10:
/*  832 */               if ((0x2000000020L & l) != 0L)
/*  833 */                 jjAddStates(15, 16); 
/*      */               break;
/*      */             case 13:
/*  836 */               if ((0x5400000054L & l) != 0L && kind > 81)
/*  837 */                 kind = 81; 
/*      */               break;
/*      */             case 19:
/*  840 */               if ((0x2000000020L & l) != 0L)
/*  841 */                 jjAddStates(17, 18); 
/*      */               break;
/*      */             case 25:
/*  844 */               if ((0x100000001000000L & l) != 0L)
/*  845 */                 jjCheckNAdd(26); 
/*      */               break;
/*      */             case 26:
/*  848 */               if ((0x7E0000007EL & l) == 0L)
/*      */                 break; 
/*  850 */               if (kind > 80)
/*  851 */                 kind = 80; 
/*  852 */               jjCheckNAddTwoStates(26, 7);
/*      */               break;
/*      */           } 
/*      */         
/*  856 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  860 */         int hiByte = this.curChar >> 8;
/*  861 */         int i1 = hiByte >> 6;
/*  862 */         long l1 = 1L << (hiByte & 0x3F);
/*  863 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  864 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  867 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 1:
/*  871 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/*  873 */               if (kind > 64)
/*  874 */                 kind = 64; 
/*  875 */               jjCheckNAdd(1);
/*      */               break;
/*      */           } 
/*      */         
/*  879 */         } while (i != startsAt);
/*      */       } 
/*  881 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  883 */         this.jjmatchedKind = kind;
/*  884 */         this.jjmatchedPos = curPos;
/*  885 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  887 */       curPos++;
/*  888 */       if ((i = this.jjnewStateCnt) == (startsAt = 27 - (this.jjnewStateCnt = startsAt)))
/*  889 */         return curPos;  
/*  890 */       try { this.curChar = this.input_stream.readChar(); }
/*  891 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_2(int pos, long active0, long active1) {
/*  896 */     switch (pos) {
/*      */     
/*      */     } 
/*  899 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_2(int pos, long active0, long active1) {
/*  904 */     return jjMoveNfa_2(jjStopStringLiteralDfa_2(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_2() {
/*  908 */     switch (this.curChar) {
/*      */       
/*      */       case '`':
/*  911 */         return jjStopAtPos(0, 76);
/*      */     } 
/*  913 */     return jjMoveNfa_2(0, 0);
/*      */   }
/*      */   
/*  916 */   static final long[] jjbitVec7 = new long[] { -2L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  919 */   static final long[] jjbitVec8 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_2(int startState, int curPos) {
/*  925 */     int startsAt = 0;
/*  926 */     this.jjnewStateCnt = 6;
/*  927 */     int i = 1;
/*  928 */     this.jjstateSet[0] = startState;
/*      */     
/*  930 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  933 */       if (++this.jjround == Integer.MAX_VALUE)
/*  934 */         ReInitRounds(); 
/*  935 */       if (this.curChar < '@') {
/*      */         
/*  937 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  940 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  943 */               if (kind > 75)
/*  944 */                 kind = 75; 
/*      */               break;
/*      */             case 1:
/*  947 */               if ((0x8400000000L & l) != 0L && kind > 74)
/*  948 */                 kind = 74; 
/*      */               break;
/*      */             case 2:
/*  951 */               if ((0xF000000000000L & l) != 0L)
/*  952 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 3:
/*  955 */               if ((0xFF000000000000L & l) == 0L)
/*      */                 break; 
/*  957 */               if (kind > 74)
/*  958 */                 kind = 74; 
/*  959 */               this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               break;
/*      */             case 4:
/*  962 */               if ((0xFF000000000000L & l) != 0L && kind > 74) {
/*  963 */                 kind = 74;
/*      */               }
/*      */               break;
/*      */           } 
/*  967 */         } while (i != startsAt);
/*      */       }
/*  969 */       else if (this.curChar < '') {
/*      */         
/*  971 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  974 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  977 */               if ((0xFFFFFFFEEFFFFFFFL & l) != 0L) {
/*      */                 
/*  979 */                 if (kind > 75)
/*  980 */                   kind = 75;  break;
/*      */               } 
/*  982 */               if (this.curChar == '\\')
/*  983 */                 jjAddStates(19, 21); 
/*      */               break;
/*      */             case 1:
/*  986 */               if ((0x14404510000000L & l) != 0L && kind > 74)
/*  987 */                 kind = 74; 
/*      */               break;
/*      */             case 5:
/*  990 */               if ((0xFFFFFFFEEFFFFFFFL & l) != 0L && kind > 75) {
/*  991 */                 kind = 75;
/*      */               }
/*      */               break;
/*      */           } 
/*  995 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  999 */         int hiByte = this.curChar >> 8;
/* 1000 */         int i1 = hiByte >> 6;
/* 1001 */         long l1 = 1L << (hiByte & 0x3F);
/* 1002 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1003 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1006 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1009 */               if (jjCanMove_1(hiByte, i1, i2, l1, l2) && kind > 75) {
/* 1010 */                 kind = 75;
/*      */               }
/*      */               break;
/*      */           } 
/* 1014 */         } while (i != startsAt);
/*      */       } 
/* 1016 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1018 */         this.jjmatchedKind = kind;
/* 1019 */         this.jjmatchedPos = curPos;
/* 1020 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1022 */       curPos++;
/* 1023 */       if ((i = this.jjnewStateCnt) == (startsAt = 6 - (this.jjnewStateCnt = startsAt)))
/* 1024 */         return curPos;  
/* 1025 */       try { this.curChar = this.input_stream.readChar(); }
/* 1026 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_1(int pos, long active0, long active1) {
/* 1031 */     switch (pos) {
/*      */     
/*      */     } 
/* 1034 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_1(int pos, long active0, long active1) {
/* 1039 */     return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_1() {
/* 1043 */     switch (this.curChar) {
/*      */       
/*      */       case '\'':
/* 1046 */         return jjStopAtPos(0, 73);
/*      */     } 
/* 1048 */     return jjMoveNfa_1(0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/* 1054 */     int startsAt = 0;
/* 1055 */     this.jjnewStateCnt = 6;
/* 1056 */     int i = 1;
/* 1057 */     this.jjstateSet[0] = startState;
/*      */     
/* 1059 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1062 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1063 */         ReInitRounds(); 
/* 1064 */       if (this.curChar < '@') {
/*      */         
/* 1066 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1069 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1072 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L && kind > 72)
/* 1073 */                 kind = 72; 
/*      */               break;
/*      */             case 1:
/* 1076 */               if ((0x8400000000L & l) != 0L && kind > 71)
/* 1077 */                 kind = 71; 
/*      */               break;
/*      */             case 2:
/* 1080 */               if ((0xF000000000000L & l) != 0L)
/* 1081 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 3:
/* 1084 */               if ((0xFF000000000000L & l) == 0L)
/*      */                 break; 
/* 1086 */               if (kind > 71)
/* 1087 */                 kind = 71; 
/* 1088 */               this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               break;
/*      */             case 4:
/* 1091 */               if ((0xFF000000000000L & l) != 0L && kind > 71) {
/* 1092 */                 kind = 71;
/*      */               }
/*      */               break;
/*      */           } 
/* 1096 */         } while (i != startsAt);
/*      */       }
/* 1098 */       else if (this.curChar < '') {
/*      */         
/* 1100 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1103 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1106 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*      */                 
/* 1108 */                 if (kind > 72)
/* 1109 */                   kind = 72;  break;
/*      */               } 
/* 1111 */               if (this.curChar == '\\')
/* 1112 */                 jjAddStates(19, 21); 
/*      */               break;
/*      */             case 1:
/* 1115 */               if ((0x14404510000000L & l) != 0L && kind > 71)
/* 1116 */                 kind = 71; 
/*      */               break;
/*      */             case 5:
/* 1119 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L && kind > 72) {
/* 1120 */                 kind = 72;
/*      */               }
/*      */               break;
/*      */           } 
/* 1124 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1128 */         int hiByte = this.curChar >> 8;
/* 1129 */         int i1 = hiByte >> 6;
/* 1130 */         long l1 = 1L << (hiByte & 0x3F);
/* 1131 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1132 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1135 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1138 */               if (jjCanMove_1(hiByte, i1, i2, l1, l2) && kind > 72) {
/* 1139 */                 kind = 72;
/*      */               }
/*      */               break;
/*      */           } 
/* 1143 */         } while (i != startsAt);
/*      */       } 
/* 1145 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1147 */         this.jjmatchedKind = kind;
/* 1148 */         this.jjmatchedPos = curPos;
/* 1149 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1151 */       curPos++;
/* 1152 */       if ((i = this.jjnewStateCnt) == (startsAt = 6 - (this.jjnewStateCnt = startsAt)))
/* 1153 */         return curPos;  
/* 1154 */       try { this.curChar = this.input_stream.readChar(); }
/* 1155 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_3(int pos, long active0, long active1) {
/* 1160 */     switch (pos) {
/*      */     
/*      */     } 
/* 1163 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int jjStartNfa_3(int pos, long active0, long active1) {
/* 1168 */     return jjMoveNfa_3(jjStopStringLiteralDfa_3(pos, active0, active1), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_3() {
/* 1172 */     switch (this.curChar) {
/*      */       
/*      */       case '"':
/* 1175 */         return jjStopAtPos(0, 79);
/*      */     } 
/* 1177 */     return jjMoveNfa_3(0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int jjMoveNfa_3(int startState, int curPos) {
/* 1183 */     int startsAt = 0;
/* 1184 */     this.jjnewStateCnt = 6;
/* 1185 */     int i = 1;
/* 1186 */     this.jjstateSet[0] = startState;
/*      */     
/* 1188 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/* 1191 */       if (++this.jjround == Integer.MAX_VALUE)
/* 1192 */         ReInitRounds(); 
/* 1193 */       if (this.curChar < '@') {
/*      */         
/* 1195 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/* 1198 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1201 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L && kind > 78)
/* 1202 */                 kind = 78; 
/*      */               break;
/*      */             case 1:
/* 1205 */               if ((0x8400000000L & l) != 0L && kind > 77)
/* 1206 */                 kind = 77; 
/*      */               break;
/*      */             case 2:
/* 1209 */               if ((0xF000000000000L & l) != 0L)
/* 1210 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*      */               break;
/*      */             case 3:
/* 1213 */               if ((0xFF000000000000L & l) == 0L)
/*      */                 break; 
/* 1215 */               if (kind > 77)
/* 1216 */                 kind = 77; 
/* 1217 */               this.jjstateSet[this.jjnewStateCnt++] = 4;
/*      */               break;
/*      */             case 4:
/* 1220 */               if ((0xFF000000000000L & l) != 0L && kind > 77) {
/* 1221 */                 kind = 77;
/*      */               }
/*      */               break;
/*      */           } 
/* 1225 */         } while (i != startsAt);
/*      */       }
/* 1227 */       else if (this.curChar < '') {
/*      */         
/* 1229 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1232 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1235 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*      */                 
/* 1237 */                 if (kind > 78)
/* 1238 */                   kind = 78;  break;
/*      */               } 
/* 1240 */               if (this.curChar == '\\')
/* 1241 */                 jjAddStates(19, 21); 
/*      */               break;
/*      */             case 1:
/* 1244 */               if ((0x14404510000000L & l) != 0L && kind > 77)
/* 1245 */                 kind = 77; 
/*      */               break;
/*      */             case 5:
/* 1248 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L && kind > 78) {
/* 1249 */                 kind = 78;
/*      */               }
/*      */               break;
/*      */           } 
/* 1253 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1257 */         int hiByte = this.curChar >> 8;
/* 1258 */         int i1 = hiByte >> 6;
/* 1259 */         long l1 = 1L << (hiByte & 0x3F);
/* 1260 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1261 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1264 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/* 1267 */               if (jjCanMove_1(hiByte, i1, i2, l1, l2) && kind > 78) {
/* 1268 */                 kind = 78;
/*      */               }
/*      */               break;
/*      */           } 
/* 1272 */         } while (i != startsAt);
/*      */       } 
/* 1274 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1276 */         this.jjmatchedKind = kind;
/* 1277 */         this.jjmatchedPos = curPos;
/* 1278 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1280 */       curPos++;
/* 1281 */       if ((i = this.jjnewStateCnt) == (startsAt = 6 - (this.jjnewStateCnt = startsAt)))
/* 1282 */         return curPos;  
/* 1283 */       try { this.curChar = this.input_stream.readChar(); }
/* 1284 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/* 1287 */   } static final int[] jjnextStates = new int[] { 15, 16, 18, 19, 22, 13, 24, 25, 7, 9, 10, 13, 17, 10, 13, 11, 12, 20, 21, 1, 2, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/* 1293 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/* 1296 */         return ((jjbitVec2[i2] & l2) != 0L);
/*      */       case 48:
/* 1298 */         return ((jjbitVec3[i2] & l2) != 0L);
/*      */       case 49:
/* 1300 */         return ((jjbitVec4[i2] & l2) != 0L);
/*      */       case 51:
/* 1302 */         return ((jjbitVec5[i2] & l2) != 0L);
/*      */       case 61:
/* 1304 */         return ((jjbitVec6[i2] & l2) != 0L);
/*      */     } 
/* 1306 */     if ((jjbitVec0[i1] & l1) != 0L)
/* 1307 */       return true; 
/* 1308 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2) {
/* 1313 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/* 1316 */         return ((jjbitVec8[i2] & l2) != 0L);
/*      */     } 
/* 1318 */     if ((jjbitVec7[i1] & l1) != 0L)
/* 1319 */       return true; 
/* 1320 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1325 */   public static final String[] jjstrLiteralImages = new String[] { "", ",", "=", "?", ":", "||", "or", "&&", "and", "|", "bor", "^", "xor", "&", "band", "==", "eq", "!=", "neq", "<", "lt", ">", "gt", "<=", "lte", ">=", "gte", "in", "not", "<<", "shl", ">>", "shr", ">>>", "ushr", "+", "-", "*", "/", "%", "~", "!", "instanceof", ".", "(", ")", "true", "false", "null", "#this", "#root", "#", "[", "]", "{", "}", "@", "new", "$", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1339 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "WithinCharLiteral", "WithinBackCharLiteral", "WithinStringLiteral" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1347 */   public static final int[] jjnewLexState = new int[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 1, 3, -1, -1, 0, -1, -1, 0, -1, -1, 0, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1353 */   static final long[] jjtoToken = new long[] { 576460752303423487L, 233993L };
/*      */ 
/*      */   
/* 1356 */   static final long[] jjtoSkip = new long[] { -576460752303423488L, 0L };
/*      */ 
/*      */   
/* 1359 */   static final long[] jjtoMore = new long[] { 0L, 28144L };
/*      */   
/*      */   protected JavaCharStream input_stream;
/*      */   
/* 1363 */   private final int[] jjrounds = new int[27];
/* 1364 */   private final int[] jjstateSet = new int[54];
/* 1365 */   private final StringBuffer image = new StringBuffer();
/*      */ 
/*      */   
/*      */   private int jjimageLen;
/*      */   
/*      */   private int lengthOfMatch;
/*      */   
/*      */   protected char curChar;
/*      */   
/*      */   int curLexState;
/*      */   
/*      */   int defaultLexState;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   
/*      */   int jjmatchedPos;
/*      */   
/*      */   int jjmatchedKind;
/*      */ 
/*      */   
/*      */   public OgnlParserTokenManager(JavaCharStream stream, int lexState) {
/* 1388 */     this(stream);
/* 1389 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(JavaCharStream stream) {
/* 1399 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/* 1400 */     this.curLexState = this.defaultLexState;
/* 1401 */     this.input_stream = stream;
/* 1402 */     ReInitRounds();
/*      */   }
/*      */ 
/*      */   
/*      */   private void ReInitRounds() {
/* 1407 */     this.jjround = -2147483647;
/* 1408 */     for (int i = 27; i-- > 0;) {
/* 1409 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(JavaCharStream stream, int lexState) {
/* 1420 */     ReInit(stream);
/* 1421 */     SwitchTo(lexState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void SwitchTo(int lexState) {
/* 1432 */     if (lexState >= 4 || lexState < 0) {
/* 1433 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 1435 */     this.curLexState = lexState;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Token jjFillToken() {
/* 1446 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1447 */     String tokenImage = (im == null) ? this.input_stream.GetImage() : im;
/* 1448 */     int beginLine = this.input_stream.getBeginLine();
/* 1449 */     int beginColumn = this.input_stream.getBeginColumn();
/* 1450 */     int endLine = this.input_stream.getEndLine();
/* 1451 */     int endColumn = this.input_stream.getEndColumn();
/* 1452 */     Token t = Token.newToken(this.jjmatchedKind, tokenImage);
/*      */     
/* 1454 */     t.beginLine = beginLine;
/* 1455 */     t.endLine = endLine;
/* 1456 */     t.beginColumn = beginColumn;
/* 1457 */     t.endColumn = endColumn;
/*      */     
/* 1459 */     return t;
/*      */   }
/*      */   public OgnlParserTokenManager(JavaCharStream stream) {
/* 1462 */     this.curLexState = 0;
/* 1463 */     this.defaultLexState = 0;
/*      */     this.input_stream = stream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token getNextToken() {
/* 1477 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label70: while (true) {
/*      */       try {
/* 1484 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/* 1486 */       catch (IOException e) {
/*      */         
/* 1488 */         this.jjmatchedKind = 0;
/* 1489 */         Token matchedToken = jjFillToken();
/* 1490 */         return matchedToken;
/*      */       } 
/* 1492 */       this.image.setLength(0);
/* 1493 */       this.jjimageLen = 0;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1497 */         switch (this.curLexState) {
/*      */           case 0:
/*      */             
/* 1500 */             try { this.input_stream.backup(0);
/* 1501 */               while (this.curChar <= ' ' && (0x100003600L & 1L << this.curChar) != 0L) {
/* 1502 */                 this.curChar = this.input_stream.BeginToken();
/*      */               } }
/* 1504 */             catch (IOException e1) { continue label70; }
/* 1505 */              this.jjmatchedKind = Integer.MAX_VALUE;
/* 1506 */             this.jjmatchedPos = 0;
/* 1507 */             curPos = jjMoveStringLiteralDfa0_0();
/*      */             break;
/*      */           case 1:
/* 1510 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1511 */             this.jjmatchedPos = 0;
/* 1512 */             curPos = jjMoveStringLiteralDfa0_1();
/*      */             break;
/*      */           case 2:
/* 1515 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1516 */             this.jjmatchedPos = 0;
/* 1517 */             curPos = jjMoveStringLiteralDfa0_2();
/*      */             break;
/*      */           case 3:
/* 1520 */             this.jjmatchedKind = Integer.MAX_VALUE;
/* 1521 */             this.jjmatchedPos = 0;
/* 1522 */             curPos = jjMoveStringLiteralDfa0_3();
/*      */             break;
/*      */         } 
/* 1525 */         if (this.jjmatchedKind != Integer.MAX_VALUE)
/*      */         
/* 1527 */         { if (this.jjmatchedPos + 1 < curPos)
/* 1528 */             this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1529 */           if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1531 */             Token matchedToken = jjFillToken();
/* 1532 */             TokenLexicalActions(matchedToken);
/* 1533 */             if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1534 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1535 */             return matchedToken;
/*      */           } 
/* 1537 */           if ((jjtoSkip[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/* 1539 */             if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1540 */               this.curLexState = jjnewLexState[this.jjmatchedKind]; continue label70;
/*      */             }  continue label70;
/*      */           } 
/* 1543 */           MoreLexicalActions();
/* 1544 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1545 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1546 */           curPos = 0;
/* 1547 */           this.jjmatchedKind = Integer.MAX_VALUE;
/*      */           
/* 1549 */           try { this.curChar = this.input_stream.readChar();
/*      */             
/*      */             continue; }
/* 1552 */           catch (IOException iOException) { break; }  }  break;
/*      */       }  break;
/* 1554 */     }  int error_line = this.input_stream.getEndLine();
/* 1555 */     int error_column = this.input_stream.getEndColumn();
/* 1556 */     String error_after = null;
/* 1557 */     boolean EOFSeen = false; try {
/* 1558 */       this.input_stream.readChar(); this.input_stream.backup(1);
/* 1559 */     } catch (IOException e1) {
/* 1560 */       EOFSeen = true;
/* 1561 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/* 1562 */       if (this.curChar == '\n' || this.curChar == '\r') {
/* 1563 */         error_line++;
/* 1564 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1567 */         error_column++;
/*      */       } 
/* 1569 */     }  if (!EOFSeen) {
/* 1570 */       this.input_stream.backup(1);
/* 1571 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/*      */     } 
/* 1573 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void MoreLexicalActions() {
/* 1580 */     this.jjimageLen += this.lengthOfMatch = this.jjmatchedPos + 1;
/* 1581 */     switch (this.jjmatchedKind) {
/*      */       
/*      */       case 69:
/* 1584 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1585 */         this.jjimageLen = 0;
/* 1586 */         this.stringBuffer = new StringBuffer();
/*      */         break;
/*      */       case 70:
/* 1589 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1590 */         this.jjimageLen = 0;
/* 1591 */         this.stringBuffer = new StringBuffer();
/*      */         break;
/*      */       case 71:
/* 1594 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1595 */         this.jjimageLen = 0;
/* 1596 */         this.charValue = escapeChar(); this.stringBuffer.append(this.charValue);
/*      */         break;
/*      */       case 72:
/* 1599 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1600 */         this.jjimageLen = 0;
/* 1601 */         this.charValue = this.image.charAt(this.image.length() - 1); this.stringBuffer.append(this.charValue);
/*      */         break;
/*      */       case 74:
/* 1604 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1605 */         this.jjimageLen = 0;
/* 1606 */         this.charValue = escapeChar();
/*      */         break;
/*      */       case 75:
/* 1609 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1610 */         this.jjimageLen = 0;
/* 1611 */         this.charValue = this.image.charAt(this.image.length() - 1);
/*      */         break;
/*      */       case 77:
/* 1614 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1615 */         this.jjimageLen = 0;
/* 1616 */         this.stringBuffer.append(escapeChar());
/*      */         break;
/*      */       case 78:
/* 1619 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 1620 */         this.jjimageLen = 0;
/* 1621 */         this.stringBuffer.append(this.image.charAt(this.image.length() - 1));
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void TokenLexicalActions(Token matchedToken) {
/* 1629 */     switch (this.jjmatchedKind) {
/*      */       
/*      */       case 67:
/* 1632 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1633 */         switch (this.image.charAt(1)) { case '^':
/* 1634 */             this.literalValue = DynamicSubscript.first; break;
/* 1635 */           case '|': this.literalValue = DynamicSubscript.mid; break;
/* 1636 */           case '$': this.literalValue = DynamicSubscript.last; break;
/* 1637 */           case '*': this.literalValue = DynamicSubscript.all; break; }
/*      */         
/*      */         break;
/*      */       case 73:
/* 1641 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1642 */         if (this.stringBuffer.length() == 1) {
/* 1643 */           this.literalValue = new Character(this.charValue); break;
/*      */         } 
/* 1645 */         this.literalValue = new String(this.stringBuffer);
/*      */         break;
/*      */       
/*      */       case 76:
/* 1649 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1650 */         this.literalValue = new Character(this.charValue);
/*      */         break;
/*      */       case 79:
/* 1653 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1654 */         this.literalValue = new String(this.stringBuffer);
/*      */         break;
/*      */       case 80:
/* 1657 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1658 */         this.literalValue = makeInt();
/*      */         break;
/*      */       
/*      */       case 81:
/* 1662 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen + (this.lengthOfMatch = this.jjmatchedPos + 1)));
/* 1663 */         this.literalValue = makeFloat();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jjCheckNAdd(int state) {
/* 1671 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/* 1673 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/* 1674 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 1680 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/* 1681 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 1685 */     jjCheckNAdd(state1);
/* 1686 */     jjCheckNAdd(state2);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end) {
/*      */     do {
/* 1692 */       jjCheckNAdd(jjnextStates[start]);
/* 1693 */     } while (start++ != end);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlParserTokenManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */