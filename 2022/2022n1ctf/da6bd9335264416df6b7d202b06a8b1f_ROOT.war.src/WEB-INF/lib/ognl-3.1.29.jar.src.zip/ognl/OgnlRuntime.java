/*      */ package ognl;
/*      */ 
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.IndexedPropertyDescriptor;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.MethodDescriptor;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.security.Permissions;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import ognl.enhance.ExpressionCompiler;
/*      */ import ognl.enhance.OgnlExpressionCompiler;
/*      */ import ognl.internal.ClassCache;
/*      */ import ognl.internal.ClassCacheImpl;
/*      */ import ognl.security.OgnlSecurityManagerFactory;
/*      */ import ognl.security.UserMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OgnlRuntime
/*      */ {
/*   67 */   public static final Object NotFound = new Object();
/*   68 */   public static final List NotFoundList = new ArrayList();
/*   69 */   public static final Map NotFoundMap = new HashMap<>();
/*   70 */   public static final Object[] NoArguments = new Object[0];
/*   71 */   public static final Class[] NoArgumentTypes = new Class[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   76 */   public static final Object NoConversionPossible = "ognl.NoConversionPossible";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   public static int INDEXED_PROPERTY_NONE = 0;
/*      */ 
/*      */ 
/*      */   
/*   85 */   public static int INDEXED_PROPERTY_INT = 1;
/*      */ 
/*      */ 
/*      */   
/*   89 */   public static int INDEXED_PROPERTY_OBJECT = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   94 */   public static final String NULL_STRING = "" + null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String SET_PREFIX = "set";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String GET_PREFIX = "get";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String IS_PREFIX = "is";
/*      */ 
/*      */ 
/*      */   
/*  112 */   private static final Map HEX_PADDING = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int HEX_LENGTH = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String NULL_OBJECT_STRING = "<null>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _jdk15 = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _jdkChecked = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String USE_JDK9PLUS_ACESS_HANDLER = "ognl.UseJDK9PlusAccessHandler";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String USE_STRICTER_INVOCATION = "ognl.UseStricterInvocation";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean _useJDK9PlusAccessHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean _useStricterInvocation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  165 */     boolean bool1 = false;
/*      */     try {
/*  167 */       String propertyString = System.getProperty("ognl.UseJDK9PlusAccessHandler");
/*  168 */       if (propertyString != null && propertyString.length() > 0) {
/*  169 */         bool1 = Boolean.parseBoolean(propertyString);
/*      */       }
/*  171 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  174 */     _useJDK9PlusAccessHandler = bool1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  183 */     bool1 = true;
/*      */     try {
/*  185 */       String propertyString = System.getProperty("ognl.UseStricterInvocation");
/*  186 */       if (propertyString != null && propertyString.length() > 0) {
/*  187 */         bool1 = Boolean.parseBoolean(propertyString);
/*      */       }
/*  189 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  192 */     _useStricterInvocation = bool1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   private static final int _majorJavaVersion = detectMajorJavaVersion();
/*  199 */   private static final boolean _jdk9Plus = (_majorJavaVersion >= 9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  210 */   private static final AccessibleObjectHandler _accessibleObjectHandler = usingJDK9PlusAccessHandler() ? AccessibleObjectHandlerJDK9Plus.createHandler() : AccessibleObjectHandlerPreJDK9.createHandler();
/*      */   
/*      */   private static final Method SYS_CONSOLE_REF;
/*      */   
/*      */   private static final Method SYS_EXIT_REF;
/*      */   
/*      */   private static final Method AO_SETACCESSIBLE_REF;
/*      */   
/*      */   private static final Method AO_SETACCESSIBLE_ARR_REF;
/*      */   static final String OGNL_SECURITY_MANAGER = "ognl.security.manager";
/*      */   static final String OGNL_SM_FORCE_DISABLE_ON_INIT = "forceDisableOnInit";
/*      */   private static final boolean _disableOgnlSecurityManagerOnInit;
/*      */   static final String USE_FIRSTMATCH_GETSET_LOOKUP = "ognl.UseFirstMatchGetSetLookup";
/*      */   private static final boolean _useFirstMatchGetSetLookup;
/*      */   
/*      */   static {
/*  226 */     Method setAccessibleMethod = null;
/*  227 */     Method setAccessibleMethodArray = null;
/*  228 */     Method systemExitMethod = null;
/*  229 */     Method systemConsoleMethod = null;
/*      */     try {
/*  231 */       setAccessibleMethod = AccessibleObject.class.getMethod("setAccessible", new Class[] { boolean.class });
/*  232 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */     
/*  235 */     } catch (SecurityException securityException) {
/*      */ 
/*      */     
/*      */     } finally {
/*  239 */       AO_SETACCESSIBLE_REF = setAccessibleMethod;
/*      */     } 
/*      */     
/*      */     try {
/*  243 */       setAccessibleMethodArray = AccessibleObject.class.getMethod("setAccessible", new Class[] { AccessibleObject[].class, boolean.class });
/*  244 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */     
/*  247 */     } catch (SecurityException securityException) {
/*      */ 
/*      */     
/*      */     } finally {
/*  251 */       AO_SETACCESSIBLE_ARR_REF = setAccessibleMethodArray;
/*      */     } 
/*      */     
/*      */     try {
/*  255 */       systemExitMethod = System.class.getMethod("exit", new Class[] { int.class });
/*  256 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */     
/*  259 */     } catch (SecurityException securityException) {
/*      */ 
/*      */     
/*      */     } finally {
/*  263 */       SYS_EXIT_REF = systemExitMethod;
/*      */     } 
/*      */     
/*      */     try {
/*  267 */       systemConsoleMethod = System.class.getMethod("console", new Class[0]);
/*  268 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */ 
/*      */     
/*  271 */     } catch (SecurityException securityException) {
/*      */ 
/*      */     
/*      */     } finally {
/*  275 */       SYS_CONSOLE_REF = systemConsoleMethod;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     boolean initialFlagState = false;
/*      */     try {
/*  304 */       String propertyString = System.getProperty("ognl.security.manager");
/*  305 */       if (propertyString != null && propertyString.length() > 0) {
/*  306 */         initialFlagState = "forceDisableOnInit".equalsIgnoreCase(propertyString);
/*      */       }
/*  308 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  311 */     _disableOgnlSecurityManagerOnInit = initialFlagState;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  332 */     initialFlagState = false;
/*      */     try {
/*  334 */       String propertyString = System.getProperty("ognl.UseFirstMatchGetSetLookup");
/*  335 */       if (propertyString != null && propertyString.length() > 0) {
/*  336 */         initialFlagState = Boolean.parseBoolean(propertyString);
/*      */       }
/*  338 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  341 */     _useFirstMatchGetSetLookup = initialFlagState;
/*      */   }
/*      */   
/*  344 */   static final ClassCache _methodAccessors = (ClassCache)new ClassCacheImpl();
/*  345 */   static final ClassCache _propertyAccessors = (ClassCache)new ClassCacheImpl();
/*  346 */   static final ClassCache _elementsAccessors = (ClassCache)new ClassCacheImpl();
/*  347 */   static final ClassCache _nullHandlers = (ClassCache)new ClassCacheImpl();
/*      */   
/*  349 */   static final ClassCache _propertyDescriptorCache = (ClassCache)new ClassCacheImpl();
/*  350 */   static final ClassCache _constructorCache = (ClassCache)new ClassCacheImpl();
/*  351 */   static final ClassCache _staticMethodCache = (ClassCache)new ClassCacheImpl();
/*  352 */   static final ClassCache _instanceMethodCache = (ClassCache)new ClassCacheImpl();
/*  353 */   static final ClassCache _invokePermissionCache = (ClassCache)new ClassCacheImpl();
/*  354 */   static final ClassCache _fieldCache = (ClassCache)new ClassCacheImpl();
/*  355 */   static final List _superclasses = new ArrayList();
/*  356 */   static final ClassCache[] _declaredMethods = new ClassCache[] { (ClassCache)new ClassCacheImpl(), (ClassCache)new ClassCacheImpl() };
/*      */   
/*  358 */   static final Map _primitiveTypes = new HashMap<>(101);
/*  359 */   static final ClassCache _primitiveDefaults = (ClassCache)new ClassCacheImpl();
/*  360 */   static final Map _methodParameterTypesCache = new HashMap<>(101);
/*  361 */   static final Map _genericMethodParameterTypesCache = new HashMap<>(101);
/*  362 */   static final Map _ctorParameterTypesCache = new HashMap<>(101);
/*  363 */   static SecurityManager _securityManager = System.getSecurityManager();
/*  364 */   static final EvaluationPool _evaluationPool = new EvaluationPool();
/*  365 */   static final ObjectArrayPool _objectArrayPool = new ObjectArrayPool();
/*      */   
/*  367 */   static final Map<Method, Boolean> _methodAccessCache = new ConcurrentHashMap<>();
/*  368 */   static final Map<Method, Boolean> _methodPermCache = new ConcurrentHashMap<>();
/*      */   
/*  370 */   static final ClassPropertyMethodCache cacheSetMethod = new ClassPropertyMethodCache();
/*  371 */   static final ClassPropertyMethodCache cacheGetMethod = new ClassPropertyMethodCache();
/*      */ 
/*      */ 
/*      */   
/*      */   static ClassCacheInspector _cacheInspector;
/*      */ 
/*      */ 
/*      */   
/*      */   private static OgnlExpressionCompiler _compiler;
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  385 */       Class.forName("javassist.ClassPool");
/*  386 */       _compiler = (OgnlExpressionCompiler)new ExpressionCompiler();
/*  387 */     } catch (ClassNotFoundException classNotFoundException) {
/*  388 */       throw new IllegalArgumentException("Javassist library is missing in classpath! Please add missed dependency!", classNotFoundException);
/*  389 */     } catch (RuntimeException rt) {
/*  390 */       throw new IllegalStateException("Javassist library cannot be loaded, is it restricted by runtime environment?");
/*      */     } 
/*      */   }
/*      */   
/*  394 */   private static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*      */   
/*  396 */   private static IdentityHashMap PRIMITIVE_WRAPPER_CLASSES = new IdentityHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  403 */     PRIMITIVE_WRAPPER_CLASSES.put(boolean.class, Boolean.class);
/*  404 */     PRIMITIVE_WRAPPER_CLASSES.put(Boolean.class, boolean.class);
/*  405 */     PRIMITIVE_WRAPPER_CLASSES.put(byte.class, Byte.class);
/*  406 */     PRIMITIVE_WRAPPER_CLASSES.put(Byte.class, byte.class);
/*  407 */     PRIMITIVE_WRAPPER_CLASSES.put(char.class, Character.class);
/*  408 */     PRIMITIVE_WRAPPER_CLASSES.put(Character.class, char.class);
/*  409 */     PRIMITIVE_WRAPPER_CLASSES.put(short.class, Short.class);
/*  410 */     PRIMITIVE_WRAPPER_CLASSES.put(Short.class, short.class);
/*  411 */     PRIMITIVE_WRAPPER_CLASSES.put(int.class, Integer.class);
/*  412 */     PRIMITIVE_WRAPPER_CLASSES.put(Integer.class, int.class);
/*  413 */     PRIMITIVE_WRAPPER_CLASSES.put(long.class, Long.class);
/*  414 */     PRIMITIVE_WRAPPER_CLASSES.put(Long.class, long.class);
/*  415 */     PRIMITIVE_WRAPPER_CLASSES.put(float.class, Float.class);
/*  416 */     PRIMITIVE_WRAPPER_CLASSES.put(Float.class, float.class);
/*  417 */     PRIMITIVE_WRAPPER_CLASSES.put(double.class, Double.class);
/*  418 */     PRIMITIVE_WRAPPER_CLASSES.put(Double.class, double.class);
/*      */   }
/*      */   
/*  421 */   private static final Map NUMERIC_CASTS = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  427 */     NUMERIC_CASTS.put(Double.class, "(double)");
/*  428 */     NUMERIC_CASTS.put(Float.class, "(float)");
/*  429 */     NUMERIC_CASTS.put(Integer.class, "(int)");
/*  430 */     NUMERIC_CASTS.put(Long.class, "(long)");
/*  431 */     NUMERIC_CASTS.put(BigDecimal.class, "(double)");
/*  432 */     NUMERIC_CASTS.put(BigInteger.class, "");
/*      */   }
/*      */   
/*  435 */   private static final Map NUMERIC_VALUES = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  443 */     NUMERIC_VALUES.put(Double.class, "doubleValue()");
/*  444 */     NUMERIC_VALUES.put(Float.class, "floatValue()");
/*  445 */     NUMERIC_VALUES.put(Integer.class, "intValue()");
/*  446 */     NUMERIC_VALUES.put(Long.class, "longValue()");
/*  447 */     NUMERIC_VALUES.put(Short.class, "shortValue()");
/*  448 */     NUMERIC_VALUES.put(Byte.class, "byteValue()");
/*  449 */     NUMERIC_VALUES.put(BigDecimal.class, "doubleValue()");
/*  450 */     NUMERIC_VALUES.put(BigInteger.class, "doubleValue()");
/*  451 */     NUMERIC_VALUES.put(Boolean.class, "booleanValue()");
/*      */   }
/*      */   
/*  454 */   private static final Map NUMERIC_LITERALS = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  460 */     NUMERIC_LITERALS.put(Integer.class, "");
/*  461 */     NUMERIC_LITERALS.put(int.class, "");
/*  462 */     NUMERIC_LITERALS.put(Long.class, "l");
/*  463 */     NUMERIC_LITERALS.put(long.class, "l");
/*  464 */     NUMERIC_LITERALS.put(BigInteger.class, "d");
/*  465 */     NUMERIC_LITERALS.put(Float.class, "f");
/*  466 */     NUMERIC_LITERALS.put(float.class, "f");
/*  467 */     NUMERIC_LITERALS.put(Double.class, "d");
/*  468 */     NUMERIC_LITERALS.put(double.class, "d");
/*  469 */     NUMERIC_LITERALS.put(BigInteger.class, "d");
/*  470 */     NUMERIC_LITERALS.put(BigDecimal.class, "d");
/*      */   }
/*      */   
/*  473 */   private static final Map NUMERIC_DEFAULTS = new HashMap<>();
/*      */   
/*      */   static {
/*  476 */     NUMERIC_DEFAULTS.put(Boolean.class, Boolean.FALSE);
/*  477 */     NUMERIC_DEFAULTS.put(Byte.class, new Byte((byte)0));
/*  478 */     NUMERIC_DEFAULTS.put(Short.class, new Short((short)0));
/*  479 */     NUMERIC_DEFAULTS.put(Character.class, new Character(false));
/*  480 */     NUMERIC_DEFAULTS.put(Integer.class, new Integer(0));
/*  481 */     NUMERIC_DEFAULTS.put(Long.class, new Long(0L));
/*  482 */     NUMERIC_DEFAULTS.put(Float.class, new Float(0.0F));
/*  483 */     NUMERIC_DEFAULTS.put(Double.class, new Double(0.0D));
/*      */     
/*  485 */     NUMERIC_DEFAULTS.put(BigInteger.class, new BigInteger("0"));
/*  486 */     NUMERIC_DEFAULTS.put(BigDecimal.class, new BigDecimal(0.0D));
/*      */ 
/*      */ 
/*      */     
/*  490 */     PropertyAccessor p = new ArrayPropertyAccessor();
/*      */     
/*  492 */     setPropertyAccessor(Object.class, new ObjectPropertyAccessor());
/*  493 */     setPropertyAccessor(byte[].class, p);
/*  494 */     setPropertyAccessor(short[].class, p);
/*  495 */     setPropertyAccessor(char[].class, p);
/*  496 */     setPropertyAccessor(int[].class, p);
/*  497 */     setPropertyAccessor(long[].class, p);
/*  498 */     setPropertyAccessor(float[].class, p);
/*  499 */     setPropertyAccessor(double[].class, p);
/*  500 */     setPropertyAccessor(Object[].class, p);
/*  501 */     setPropertyAccessor(List.class, new ListPropertyAccessor());
/*  502 */     setPropertyAccessor(Map.class, new MapPropertyAccessor());
/*  503 */     setPropertyAccessor(Set.class, new SetPropertyAccessor());
/*  504 */     setPropertyAccessor(Iterator.class, new IteratorPropertyAccessor());
/*  505 */     setPropertyAccessor(Enumeration.class, new EnumerationPropertyAccessor());
/*      */     
/*  507 */     ElementsAccessor e = new ArrayElementsAccessor();
/*      */     
/*  509 */     setElementsAccessor(Object.class, new ObjectElementsAccessor());
/*  510 */     setElementsAccessor(byte[].class, e);
/*  511 */     setElementsAccessor(short[].class, e);
/*  512 */     setElementsAccessor(char[].class, e);
/*  513 */     setElementsAccessor(int[].class, e);
/*  514 */     setElementsAccessor(long[].class, e);
/*  515 */     setElementsAccessor(float[].class, e);
/*  516 */     setElementsAccessor(double[].class, e);
/*  517 */     setElementsAccessor(Object[].class, e);
/*  518 */     setElementsAccessor(Collection.class, new CollectionElementsAccessor());
/*  519 */     setElementsAccessor(Map.class, new MapElementsAccessor());
/*  520 */     setElementsAccessor(Iterator.class, new IteratorElementsAccessor());
/*  521 */     setElementsAccessor(Enumeration.class, new EnumerationElementsAccessor());
/*  522 */     setElementsAccessor(Number.class, new NumberElementsAccessor());
/*      */     
/*  524 */     NullHandler nh = new ObjectNullHandler();
/*      */     
/*  526 */     setNullHandler(Object.class, nh);
/*  527 */     setNullHandler(byte[].class, nh);
/*  528 */     setNullHandler(short[].class, nh);
/*  529 */     setNullHandler(char[].class, nh);
/*  530 */     setNullHandler(int[].class, nh);
/*  531 */     setNullHandler(long[].class, nh);
/*  532 */     setNullHandler(float[].class, nh);
/*  533 */     setNullHandler(double[].class, nh);
/*  534 */     setNullHandler(Object[].class, nh);
/*      */     
/*  536 */     MethodAccessor ma = new ObjectMethodAccessor();
/*      */     
/*  538 */     setMethodAccessor(Object.class, ma);
/*  539 */     setMethodAccessor(byte[].class, ma);
/*  540 */     setMethodAccessor(short[].class, ma);
/*  541 */     setMethodAccessor(char[].class, ma);
/*  542 */     setMethodAccessor(int[].class, ma);
/*  543 */     setMethodAccessor(long[].class, ma);
/*  544 */     setMethodAccessor(float[].class, ma);
/*  545 */     setMethodAccessor(double[].class, ma);
/*  546 */     setMethodAccessor(Object[].class, ma);
/*      */     
/*  548 */     _primitiveTypes.put("boolean", boolean.class);
/*  549 */     _primitiveTypes.put("byte", byte.class);
/*  550 */     _primitiveTypes.put("short", short.class);
/*  551 */     _primitiveTypes.put("char", char.class);
/*  552 */     _primitiveTypes.put("int", int.class);
/*  553 */     _primitiveTypes.put("long", long.class);
/*  554 */     _primitiveTypes.put("float", float.class);
/*  555 */     _primitiveTypes.put("double", double.class);
/*      */     
/*  557 */     _primitiveDefaults.put(boolean.class, Boolean.FALSE);
/*  558 */     _primitiveDefaults.put(Boolean.class, Boolean.FALSE);
/*  559 */     _primitiveDefaults.put(byte.class, new Byte((byte)0));
/*  560 */     _primitiveDefaults.put(Byte.class, new Byte((byte)0));
/*  561 */     _primitiveDefaults.put(short.class, new Short((short)0));
/*  562 */     _primitiveDefaults.put(Short.class, new Short((short)0));
/*  563 */     _primitiveDefaults.put(char.class, new Character(false));
/*  564 */     _primitiveDefaults.put(int.class, new Integer(0));
/*  565 */     _primitiveDefaults.put(long.class, new Long(0L));
/*  566 */     _primitiveDefaults.put(float.class, new Float(0.0F));
/*  567 */     _primitiveDefaults.put(double.class, new Double(0.0D));
/*      */     
/*  569 */     _primitiveDefaults.put(BigInteger.class, new BigInteger("0"));
/*  570 */     _primitiveDefaults.put(BigDecimal.class, new BigDecimal(0.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearCache() {
/*  585 */     synchronized (_methodParameterTypesCache) {
/*  586 */       _methodParameterTypesCache.clear();
/*      */     } 
/*  588 */     synchronized (_ctorParameterTypesCache) {
/*  589 */       _ctorParameterTypesCache.clear();
/*      */     } 
/*  591 */     synchronized (_propertyDescriptorCache) {
/*  592 */       _propertyDescriptorCache.clear();
/*      */     } 
/*  594 */     synchronized (_constructorCache) {
/*  595 */       _constructorCache.clear();
/*      */     } 
/*  597 */     synchronized (_staticMethodCache) {
/*  598 */       _staticMethodCache.clear();
/*      */     } 
/*  600 */     synchronized (_instanceMethodCache) {
/*  601 */       _instanceMethodCache.clear();
/*      */     } 
/*  603 */     synchronized (_invokePermissionCache) {
/*  604 */       _invokePermissionCache.clear();
/*      */     } 
/*  606 */     synchronized (_fieldCache) {
/*  607 */       _fieldCache.clear();
/*  608 */       _superclasses.clear();
/*      */     } 
/*  610 */     synchronized (_declaredMethods[0]) {
/*  611 */       _declaredMethods[0].clear();
/*      */     } 
/*  613 */     synchronized (_declaredMethods[1]) {
/*  614 */       _declaredMethods[1].clear();
/*      */     } 
/*  616 */     _methodAccessCache.clear();
/*  617 */     _methodPermCache.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clearAdditionalCache() {
/*  637 */     cacheSetMethod.clear();
/*  638 */     cacheGetMethod.clear();
/*  639 */     synchronized (_genericMethodParameterTypesCache) {
/*  640 */       _genericMethodParameterTypesCache.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJdk15() {
/*  651 */     if (_jdkChecked) {
/*  652 */       return _jdk15;
/*      */     }
/*      */     
/*      */     try {
/*  656 */       Class.forName("java.lang.annotation.Annotation");
/*  657 */       _jdk15 = true;
/*  658 */     } catch (Exception exception) {}
/*      */     
/*  660 */     _jdkChecked = true;
/*      */     
/*  662 */     return _jdk15;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getMajorJavaVersion() {
/*  671 */     return _majorJavaVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJdk9Plus() {
/*  680 */     return _jdk9Plus;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getNumericValueGetter(Class type) {
/*  685 */     return (String)NUMERIC_VALUES.get(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Class getPrimitiveWrapperClass(Class primitiveClass) {
/*  690 */     return (Class)PRIMITIVE_WRAPPER_CLASSES.get(primitiveClass);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getNumericCast(Class type) {
/*  695 */     return (String)NUMERIC_CASTS.get(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getNumericLiteral(Class type) {
/*  700 */     return (String)NUMERIC_LITERALS.get(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setCompiler(OgnlExpressionCompiler compiler) {
/*  705 */     _compiler = compiler;
/*      */   }
/*      */ 
/*      */   
/*      */   public static OgnlExpressionCompiler getCompiler() {
/*  710 */     return _compiler;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void compileExpression(OgnlContext context, Node expression, Object root) throws Exception {
/*  716 */     _compiler.compileExpression(context, expression, root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class getTargetClass(Object o) {
/*  729 */     return (o == null) ? null : ((o instanceof Class) ? (Class)o : o.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getBaseName(Object o) {
/*  741 */     return (o == null) ? null : getClassBaseName(o.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getClassBaseName(Class c) {
/*  752 */     String s = c.getName();
/*      */     
/*  754 */     return s.substring(s.lastIndexOf('.') + 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getClassName(Object<?> o, boolean fullyQualified) {
/*  759 */     if (!(o instanceof Class))
/*      */     {
/*  761 */       o = (Object<?>)o.getClass();
/*      */     }
/*      */     
/*  764 */     return getClassName((Class)o, fullyQualified);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String getClassName(Class c, boolean fullyQualified) {
/*  769 */     return fullyQualified ? c.getName() : getClassBaseName(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageName(Object o) {
/*  780 */     return (o == null) ? null : getClassPackageName(o.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getClassPackageName(Class c) {
/*  791 */     String s = c.getName();
/*  792 */     int i = s.lastIndexOf('.');
/*      */     
/*  794 */     return (i < 0) ? null : s.substring(0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPointerString(int num) {
/*  805 */     StringBuffer result = new StringBuffer();
/*  806 */     String hex = Integer.toHexString(num);
/*  807 */     Integer l = new Integer(hex.length());
/*      */     
/*      */     String pad;
/*  810 */     if ((pad = (String)HEX_PADDING.get(l)) == null) {
/*  811 */       StringBuffer pb = new StringBuffer();
/*      */       
/*  813 */       for (int i = hex.length(); i < 8; i++) {
/*  814 */         pb.append('0');
/*      */       }
/*  816 */       pad = new String(pb);
/*  817 */       HEX_PADDING.put(l, pad);
/*      */     } 
/*  819 */     result.append(pad);
/*  820 */     result.append(hex);
/*  821 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPointerString(Object o) {
/*  833 */     return getPointerString((o == null) ? 0 : System.identityHashCode(o));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUniqueDescriptor(Object object, boolean fullyQualified) {
/*  847 */     StringBuffer result = new StringBuffer();
/*      */     
/*  849 */     if (object != null) {
/*  850 */       if (object instanceof Proxy) {
/*  851 */         Class<?> interfaceClass = object.getClass().getInterfaces()[0];
/*      */         
/*  853 */         result.append(getClassName(interfaceClass, fullyQualified));
/*  854 */         result.append('^');
/*  855 */         object = Proxy.getInvocationHandler(object);
/*      */       } 
/*  857 */       result.append(getClassName(object, fullyQualified));
/*  858 */       result.append('@');
/*  859 */       result.append(getPointerString(object));
/*      */     } else {
/*  861 */       result.append("<null>");
/*      */     } 
/*  863 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUniqueDescriptor(Object object) {
/*  875 */     return getUniqueDescriptor(object, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] toArray(List list) {
/*      */     Object[] result;
/*  889 */     int size = list.size();
/*      */     
/*  891 */     if (size == 0) {
/*  892 */       result = NoArguments;
/*      */     } else {
/*  894 */       result = getObjectArrayPool().create(list.size());
/*  895 */       for (int i = 0; i < size; i++) {
/*  896 */         result[i] = list.get(i);
/*      */       }
/*      */     } 
/*  899 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class[] getParameterTypes(Method m) {
/*  910 */     synchronized (_methodParameterTypesCache) {
/*      */       Class[] result;
/*      */ 
/*      */       
/*  914 */       if ((result = (Class[])_methodParameterTypesCache.get(m)) == null)
/*      */       {
/*  916 */         _methodParameterTypesCache.put(m, result = m.getParameterTypes());
/*      */       }
/*  918 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class[] findParameterTypes(Class type, Method m) {
/*  933 */     Type[] genTypes = m.getGenericParameterTypes();
/*  934 */     Class[] types = new Class[genTypes.length];
/*  935 */     boolean noGenericParameter = true;
/*  936 */     for (int i = 0; i < genTypes.length; i++) {
/*      */       
/*  938 */       if (Class.class.isInstance(genTypes[i])) {
/*      */         
/*  940 */         types[i] = (Class)genTypes[i];
/*      */       } else {
/*      */         
/*  943 */         noGenericParameter = false; break;
/*      */       } 
/*      */     } 
/*  946 */     if (noGenericParameter)
/*      */     {
/*  948 */       return types;
/*      */     }
/*      */     
/*  951 */     if (type == null || !isJdk15())
/*      */     {
/*  953 */       return getParameterTypes(m);
/*      */     }
/*      */     
/*  956 */     Type typeGenericSuperclass = type.getGenericSuperclass();
/*  957 */     if (typeGenericSuperclass == null || !ParameterizedType.class.isInstance(typeGenericSuperclass) || m.getDeclaringClass().getTypeParameters() == null)
/*      */     {
/*      */ 
/*      */       
/*  961 */       return getParameterTypes(m);
/*      */     }
/*      */     
/*  964 */     if ((types = (Class[])_genericMethodParameterTypesCache.get(m)) != null) {
/*      */       
/*  966 */       ParameterizedType genericSuperclass = (ParameterizedType)typeGenericSuperclass;
/*  967 */       if (Arrays.equals((Object[])types, (Object[])genericSuperclass.getActualTypeArguments())) {
/*  968 */         return types;
/*      */       }
/*      */     } 
/*      */     
/*  972 */     ParameterizedType param = (ParameterizedType)typeGenericSuperclass;
/*  973 */     TypeVariable[] declaredTypes = (TypeVariable[])m.getDeclaringClass().getTypeParameters();
/*      */     
/*  975 */     types = new Class[genTypes.length];
/*      */     
/*  977 */     for (int j = 0; j < genTypes.length; j++) {
/*      */       
/*  979 */       TypeVariable paramType = null;
/*      */       
/*  981 */       if (TypeVariable.class.isInstance(genTypes[j])) {
/*      */         
/*  983 */         paramType = (TypeVariable)genTypes[j];
/*  984 */       } else if (GenericArrayType.class.isInstance(genTypes[j])) {
/*      */         
/*  986 */         paramType = (TypeVariable)((GenericArrayType)genTypes[j]).getGenericComponentType();
/*      */       } else {
/*  988 */         if (ParameterizedType.class.isInstance(genTypes[j])) {
/*      */           
/*  990 */           types[j] = (Class)((ParameterizedType)genTypes[j]).getRawType(); continue;
/*      */         } 
/*  992 */         if (Class.class.isInstance(genTypes[j])) {
/*      */           
/*  994 */           types[j] = (Class)genTypes[j];
/*      */           continue;
/*      */         } 
/*      */       } 
/*  998 */       Class<?> resolved = resolveType(param, paramType, declaredTypes);
/*      */       
/* 1000 */       if (resolved != null) {
/*      */         
/* 1002 */         if (GenericArrayType.class.isInstance(genTypes[j]))
/*      */         {
/* 1004 */           resolved = Array.newInstance(resolved, 0).getClass();
/*      */         }
/*      */         
/* 1007 */         types[j] = resolved;
/*      */       }
/*      */       else {
/*      */         
/* 1011 */         types[j] = m.getParameterTypes()[j];
/*      */       }  continue;
/*      */     } 
/* 1014 */     synchronized (_genericMethodParameterTypesCache) {
/*      */       
/* 1016 */       _genericMethodParameterTypesCache.put(m, types);
/*      */     } 
/*      */     
/* 1019 */     return types;
/*      */   }
/*      */ 
/*      */   
/*      */   static Class resolveType(ParameterizedType param, TypeVariable var, TypeVariable[] declaredTypes) {
/* 1024 */     if ((param.getActualTypeArguments()).length < 1) {
/* 1025 */       return null;
/*      */     }
/* 1027 */     for (int i = 0; i < declaredTypes.length; i++) {
/*      */       
/* 1029 */       if (!TypeVariable.class.isInstance(param.getActualTypeArguments()[i]) && declaredTypes[i].getName().equals(var.getName()))
/*      */       {
/*      */         
/* 1032 */         return (Class)param.getActualTypeArguments()[i];
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1062 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   static Class findType(Type[] types, Class type) {
/* 1067 */     for (int i = 0; i < types.length; i++) {
/*      */       
/* 1069 */       if (Class.class.isInstance(types[i]) && type.isAssignableFrom((Class)types[i])) {
/* 1070 */         return (Class)types[i];
/*      */       }
/*      */     } 
/* 1073 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class[] getParameterTypes(Constructor c) {
/*      */     Class[] result;
/* 1085 */     if ((result = (Class[])_ctorParameterTypesCache.get(c)) == null) {
/* 1086 */       synchronized (_ctorParameterTypesCache) {
/* 1087 */         if ((result = (Class[])_ctorParameterTypesCache.get(c)) == null) {
/* 1088 */           _ctorParameterTypesCache.put(c, result = c.getParameterTypes());
/*      */         }
/*      */       } 
/*      */     }
/* 1092 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SecurityManager getSecurityManager() {
/* 1102 */     return _securityManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setSecurityManager(SecurityManager value) {
/* 1112 */     _securityManager = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Permission getPermission(Method method) {
/*      */     Permission result;
/* 1124 */     Class<?> mc = method.getDeclaringClass();
/*      */     
/* 1126 */     synchronized (_invokePermissionCache) {
/* 1127 */       Map<Object, Object> permissions = (Map)_invokePermissionCache.get(mc);
/*      */       
/* 1129 */       if (permissions == null) {
/* 1130 */         _invokePermissionCache.put(mc, permissions = new HashMap<>(101));
/*      */       }
/* 1132 */       if ((result = (Permission)permissions.get(method.getName())) == null) {
/* 1133 */         result = new OgnlInvokePermission("invoke." + mc.getName() + "." + method.getName());
/* 1134 */         permissions.put(method.getName(), result);
/*      */       } 
/*      */     } 
/* 1137 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object invokeMethod(Object target, Method method, Object[] argsArray) throws InvocationTargetException, IllegalAccessException {
/*      */     boolean syncInvoke;
/*      */     boolean checkPermission;
/*      */     Object result;
/* 1148 */     if (_useStricterInvocation) {
/* 1149 */       Class<?> methodDeclaringClass = method.getDeclaringClass();
/* 1150 */       if ((AO_SETACCESSIBLE_REF != null && AO_SETACCESSIBLE_REF.equals(method)) || (AO_SETACCESSIBLE_ARR_REF != null && AO_SETACCESSIBLE_ARR_REF.equals(method)) || (SYS_EXIT_REF != null && SYS_EXIT_REF.equals(method)) || (SYS_CONSOLE_REF != null && SYS_CONSOLE_REF.equals(method)) || AccessibleObjectHandler.class.isAssignableFrom(methodDeclaringClass) || ClassResolver.class.isAssignableFrom(methodDeclaringClass) || MethodAccessor.class.isAssignableFrom(methodDeclaringClass) || MemberAccess.class.isAssignableFrom(methodDeclaringClass) || OgnlContext.class.isAssignableFrom(methodDeclaringClass) || Runtime.class.isAssignableFrom(methodDeclaringClass) || ClassLoader.class.isAssignableFrom(methodDeclaringClass) || ProcessBuilder.class.isAssignableFrom(methodDeclaringClass) || AccessibleObjectHandlerJDK9Plus.unsafeOrDescendant(methodDeclaringClass))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1165 */         throw new IllegalAccessException("Method [" + method + "] cannot be called from within OGNL invokeMethod() " + "under stricter invocation mode.");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1172 */     synchronized (method) {
/* 1173 */       Boolean methodAccessCacheValue = _methodAccessCache.get(method);
/* 1174 */       if (methodAccessCacheValue == null) {
/* 1175 */         if (!Modifier.isPublic(method.getModifiers()) || !Modifier.isPublic(method.getDeclaringClass().getModifiers())) {
/*      */           
/* 1177 */           if (!method.isAccessible()) {
/*      */             
/* 1179 */             methodAccessCacheValue = Boolean.TRUE;
/* 1180 */             _methodAccessCache.put(method, methodAccessCacheValue);
/*      */           } else {
/*      */             
/* 1183 */             methodAccessCacheValue = Boolean.FALSE;
/* 1184 */             _methodAccessCache.put(method, methodAccessCacheValue);
/*      */           } 
/*      */         } else {
/*      */           
/* 1188 */           methodAccessCacheValue = Boolean.FALSE;
/* 1189 */           _methodAccessCache.put(method, methodAccessCacheValue);
/*      */         } 
/*      */       }
/* 1192 */       syncInvoke = Boolean.TRUE.equals(methodAccessCacheValue);
/*      */       
/* 1194 */       Boolean methodPermCacheValue = _methodPermCache.get(method);
/* 1195 */       if (methodPermCacheValue == null) {
/* 1196 */         if (_securityManager != null) {
/*      */           
/*      */           try {
/* 1199 */             _securityManager.checkPermission(getPermission(method));
/* 1200 */             methodPermCacheValue = Boolean.TRUE;
/* 1201 */             _methodPermCache.put(method, methodPermCacheValue);
/* 1202 */           } catch (SecurityException ex) {
/* 1203 */             methodPermCacheValue = Boolean.FALSE;
/* 1204 */             _methodPermCache.put(method, methodPermCacheValue);
/* 1205 */             throw new IllegalAccessException("Method [" + method + "] cannot be accessed.");
/*      */           } 
/*      */         } else {
/*      */           
/* 1209 */           methodPermCacheValue = Boolean.TRUE;
/* 1210 */           _methodPermCache.put(method, methodPermCacheValue);
/*      */         } 
/*      */       }
/* 1213 */       checkPermission = Boolean.FALSE.equals(methodPermCacheValue);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1218 */     if (syncInvoke) {
/*      */       
/* 1220 */       synchronized (method) {
/*      */         
/* 1222 */         if (checkPermission) {
/*      */           
/*      */           try {
/*      */             
/* 1226 */             _securityManager.checkPermission(getPermission(method));
/* 1227 */           } catch (SecurityException ex) {
/* 1228 */             throw new IllegalAccessException("Method [" + method + "] cannot be accessed.");
/*      */           } 
/*      */         }
/*      */         
/* 1232 */         _accessibleObjectHandler.setAccessible(method, true);
/*      */         try {
/* 1234 */           result = invokeMethodInsideSandbox(target, method, argsArray);
/*      */         } finally {
/* 1236 */           _accessibleObjectHandler.setAccessible(method, false);
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1241 */       if (checkPermission) {
/*      */         
/*      */         try {
/*      */           
/* 1245 */           _securityManager.checkPermission(getPermission(method));
/* 1246 */         } catch (SecurityException ex) {
/* 1247 */           throw new IllegalAccessException("Method [" + method + "] cannot be accessed.");
/*      */         } 
/*      */       }
/*      */       
/* 1251 */       result = invokeMethodInsideSandbox(target, method, argsArray);
/*      */     } 
/*      */     
/* 1254 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Object invokeMethodInsideSandbox(Object target, Method method, Object[] argsArray) throws InvocationTargetException, IllegalAccessException {
/*      */     Long token;
/* 1260 */     if (_disableOgnlSecurityManagerOnInit) {
/* 1261 */       return method.invoke(target, argsArray);
/*      */     }
/*      */     
/*      */     try {
/* 1265 */       if (System.getProperty("ognl.security.manager") == null) {
/* 1266 */         return method.invoke(target, argsArray);
/*      */       }
/* 1268 */     } catch (SecurityException securityException) {}
/*      */ 
/*      */ 
/*      */     
/* 1272 */     if (ClassLoader.class.isAssignableFrom(method.getDeclaringClass()))
/*      */     {
/* 1274 */       throw new IllegalAccessException("OGNL direct access to class loader denied!");
/*      */     }
/*      */ 
/*      */     
/* 1278 */     UserMethod userMethod = new UserMethod(target, method, argsArray);
/* 1279 */     Permissions p = new Permissions();
/* 1280 */     ProtectionDomain pd = new ProtectionDomain(null, p);
/* 1281 */     AccessControlContext acc = new AccessControlContext(new ProtectionDomain[] { pd });
/*      */     
/* 1283 */     Object ognlSecurityManager = OgnlSecurityManagerFactory.getOgnlSecurityManager();
/*      */ 
/*      */     
/*      */     try {
/* 1287 */       token = (Long)ognlSecurityManager.getClass().getMethod("enter", new Class[0]).invoke(ognlSecurityManager, new Object[0]);
/* 1288 */     } catch (NoSuchMethodException e) {
/* 1289 */       throw new InvocationTargetException(e);
/*      */     } 
/* 1291 */     if (token == null)
/*      */     {
/* 1293 */       return method.invoke(target, argsArray);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1298 */       return AccessController.doPrivileged((PrivilegedExceptionAction<Object>)userMethod, acc);
/* 1299 */     } catch (PrivilegedActionException e) {
/* 1300 */       if (e.getException() instanceof InvocationTargetException) {
/* 1301 */         throw (InvocationTargetException)e.getException();
/*      */       }
/* 1303 */       throw new InvocationTargetException(e);
/*      */     } finally {
/*      */       try {
/* 1306 */         ognlSecurityManager.getClass().getMethod("leave", new Class[] { long.class }).invoke(ognlSecurityManager, new Object[] { token });
/* 1307 */       } catch (NoSuchMethodException e) {
/* 1308 */         throw new InvocationTargetException(e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Class getArgClass(Object arg) {
/* 1323 */     if (arg == null)
/* 1324 */       return null; 
/* 1325 */     Class<?> c = arg.getClass();
/* 1326 */     if (c == Boolean.class)
/* 1327 */       return boolean.class; 
/* 1328 */     if (c.getSuperclass() == Number.class) {
/* 1329 */       if (c == Integer.class)
/* 1330 */         return int.class; 
/* 1331 */       if (c == Double.class)
/* 1332 */         return double.class; 
/* 1333 */       if (c == Byte.class)
/* 1334 */         return byte.class; 
/* 1335 */       if (c == Long.class)
/* 1336 */         return long.class; 
/* 1337 */       if (c == Float.class)
/* 1338 */         return float.class; 
/* 1339 */       if (c == Short.class)
/* 1340 */         return short.class; 
/* 1341 */     } else if (c == Character.class) {
/* 1342 */       return char.class;
/* 1343 */     }  return c;
/*      */   }
/*      */   
/*      */   public static Class[] getArgClasses(Object[] args) {
/* 1347 */     if (args == null)
/* 1348 */       return null; 
/* 1349 */     Class[] argClasses = new Class[args.length];
/* 1350 */     for (int i = 0; i < args.length; i++)
/* 1351 */       argClasses[i] = getArgClass(args[i]); 
/* 1352 */     return argClasses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isTypeCompatible(Object object, Class c) {
/* 1366 */     if (object == null)
/* 1367 */       return true; 
/* 1368 */     ArgsCompatbilityReport report = new ArgsCompatbilityReport(0, new boolean[1]);
/* 1369 */     if (!isTypeCompatible(getArgClass(object), c, 0, report))
/* 1370 */       return false; 
/* 1371 */     if (report.conversionNeeded[0])
/* 1372 */       return false; 
/* 1373 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public static final boolean isTypeCompatible(Class<?> parameterClass, Class<?> methodArgumentClass, int index, ArgsCompatbilityReport report) {
/* 1378 */     if (parameterClass == null) {
/*      */       
/* 1380 */       report.score += 500;
/* 1381 */       return true;
/*      */     } 
/* 1383 */     if (parameterClass == methodArgumentClass) {
/* 1384 */       return true;
/*      */     }
/*      */     
/* 1387 */     if (methodArgumentClass.isArray()) {
/* 1388 */       if (parameterClass.isArray()) {
/* 1389 */         Class<?> pct = parameterClass.getComponentType();
/* 1390 */         Class<?> mct = methodArgumentClass.getComponentType();
/* 1391 */         if (mct.isAssignableFrom(pct)) {
/*      */           
/* 1393 */           report.score += 25;
/* 1394 */           return true;
/*      */         } 
/*      */       } 
/*      */       
/* 1398 */       if (Collection.class.isAssignableFrom(parameterClass))
/*      */       {
/*      */         
/* 1401 */         Class<?> mct = methodArgumentClass.getComponentType();
/* 1402 */         if (mct == Object.class) {
/* 1403 */           report.conversionNeeded[index] = true;
/* 1404 */           report.score += 30;
/* 1405 */           return true;
/*      */         } 
/*      */         
/* 1408 */         return false;
/*      */       }
/*      */     
/* 1411 */     } else if (Collection.class.isAssignableFrom(methodArgumentClass)) {
/* 1412 */       if (parameterClass.isArray()) {
/*      */         
/* 1414 */         report.conversionNeeded[index] = true;
/* 1415 */         report.score += 50;
/* 1416 */         return true;
/*      */       } 
/* 1418 */       if (Collection.class.isAssignableFrom(parameterClass)) {
/* 1419 */         if (methodArgumentClass.isAssignableFrom(parameterClass)) {
/*      */           
/* 1421 */           report.score += 2;
/* 1422 */           return true;
/*      */         } 
/*      */         
/* 1425 */         report.conversionNeeded[index] = true;
/* 1426 */         report.score += 50;
/* 1427 */         return true;
/*      */       } 
/*      */     } 
/* 1430 */     if (methodArgumentClass.isAssignableFrom(parameterClass)) {
/* 1431 */       report.score += 40;
/* 1432 */       return true;
/*      */     } 
/* 1434 */     if (parameterClass.isPrimitive()) {
/* 1435 */       Class<?> ptc = (Class)PRIMITIVE_WRAPPER_CLASSES.get(parameterClass);
/* 1436 */       if (methodArgumentClass == ptc) {
/* 1437 */         report.score += 2;
/* 1438 */         return true;
/*      */       } 
/* 1440 */       if (methodArgumentClass.isAssignableFrom(ptc)) {
/* 1441 */         report.score += 10;
/* 1442 */         return true;
/*      */       } 
/*      */     } 
/* 1445 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ArgsCompatbilityReport
/*      */   {
/*      */     int score;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean[] conversionNeeded;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ArgsCompatbilityReport(int score, boolean[] conversionNeeded) {
/* 1471 */       this.score = score;
/* 1472 */       this.conversionNeeded = conversionNeeded;
/*      */     }
/*      */   }
/*      */   
/* 1476 */   public static final ArgsCompatbilityReport NoArgsReport = new ArgsCompatbilityReport(0, new boolean[0]);
/*      */ 
/*      */   
/*      */   public static boolean areArgsCompatible(Object[] args, Class[] classes) {
/* 1480 */     ArgsCompatbilityReport report = areArgsCompatible(getArgClasses(args), classes, null);
/* 1481 */     if (report == null)
/* 1482 */       return false; 
/* 1483 */     for (boolean conversionNeeded : report.conversionNeeded) {
/* 1484 */       if (conversionNeeded)
/* 1485 */         return false; 
/* 1486 */     }  return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public static ArgsCompatbilityReport areArgsCompatible(Class[] args, Class[] classes, Method m) {
/* 1491 */     boolean varArgs = (m != null && isJdk15() && m.isVarArgs());
/*      */     
/* 1493 */     if (args == null || args.length == 0) {
/* 1494 */       if (classes == null || classes.length == 0) {
/* 1495 */         return NoArgsReport;
/*      */       }
/* 1497 */       return null;
/*      */     } 
/* 1499 */     if (args.length != classes.length && !varArgs)
/* 1500 */       return null; 
/* 1501 */     if (varArgs) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1509 */       ArgsCompatbilityReport argsCompatbilityReport = new ArgsCompatbilityReport(1000, new boolean[args.length]);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1514 */       if (classes.length - 1 > args.length)
/*      */       {
/* 1516 */         return null;
/*      */       }
/*      */       
/* 1519 */       for (int i = 0, k = classes.length - 1; i < k; i++) {
/* 1520 */         if (!isTypeCompatible(args[i], classes[i], i, argsCompatbilityReport)) {
/* 1521 */           return null;
/*      */         }
/*      */       } 
/* 1524 */       Class<?> varArgsType = classes[classes.length - 1].getComponentType();
/* 1525 */       for (int j = classes.length - 1, n = args.length; j < n; j++) {
/* 1526 */         if (!isTypeCompatible(args[j], varArgsType, j, argsCompatbilityReport))
/* 1527 */           return null; 
/*      */       } 
/* 1529 */       return argsCompatbilityReport;
/*      */     } 
/* 1531 */     ArgsCompatbilityReport report = new ArgsCompatbilityReport(0, new boolean[args.length]);
/* 1532 */     for (int index = 0, count = args.length; index < count; index++) {
/* 1533 */       if (!isTypeCompatible(args[index], classes[index], index, report))
/* 1534 */         return null; 
/* 1535 */     }  return report;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isMoreSpecific(Class[] classes1, Class[] classes2) {
/* 1549 */     for (int index = 0, count = classes1.length; index < count; index++) {
/* 1550 */       Class<?> c1 = classes1[index], c2 = classes2[index];
/* 1551 */       if (c1 != c2) {
/*      */         
/* 1553 */         if (c1.isPrimitive())
/* 1554 */           return true; 
/* 1555 */         if (c1.isAssignableFrom(c2))
/* 1556 */           return false; 
/* 1557 */         if (c2.isAssignableFrom(c1)) {
/* 1558 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/* 1562 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getModifierString(int modifiers) {
/*      */     String result;
/* 1569 */     if (Modifier.isPublic(modifiers)) {
/* 1570 */       result = "public";
/* 1571 */     } else if (Modifier.isProtected(modifiers)) {
/* 1572 */       result = "protected";
/* 1573 */     } else if (Modifier.isPrivate(modifiers)) {
/* 1574 */       result = "private";
/*      */     } else {
/* 1576 */       result = "";
/* 1577 */     }  if (Modifier.isStatic(modifiers))
/* 1578 */       result = "static " + result; 
/* 1579 */     if (Modifier.isFinal(modifiers))
/* 1580 */       result = "final " + result; 
/* 1581 */     if (Modifier.isNative(modifiers))
/* 1582 */       result = "native " + result; 
/* 1583 */     if (Modifier.isSynchronized(modifiers))
/* 1584 */       result = "synchronized " + result; 
/* 1585 */     if (Modifier.isTransient(modifiers))
/* 1586 */       result = "transient " + result; 
/* 1587 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class classForName(OgnlContext context, String className) throws ClassNotFoundException {
/* 1593 */     Class result = (Class)_primitiveTypes.get(className);
/*      */     
/* 1595 */     if (result == null) {
/*      */       ClassResolver resolver;
/*      */       
/* 1598 */       if (context == null || (resolver = context.getClassResolver()) == null) {
/* 1599 */         resolver = OgnlContext.DEFAULT_CLASS_RESOLVER;
/*      */       }
/* 1601 */       result = resolver.classForName(className, context);
/*      */     } 
/*      */     
/* 1604 */     if (result == null) {
/* 1605 */       throw new ClassNotFoundException("Unable to resolve class: " + className);
/*      */     }
/* 1607 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInstance(OgnlContext context, Object value, String className) throws OgnlException {
/*      */     try {
/* 1614 */       Class c = classForName(context, className);
/* 1615 */       return c.isInstance(value);
/* 1616 */     } catch (ClassNotFoundException e) {
/* 1617 */       throw new OgnlException("No such class: " + className, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getPrimitiveDefaultValue(Class forClass) {
/* 1623 */     return _primitiveDefaults.get(forClass);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object getNumericDefaultValue(Class forClass) {
/* 1628 */     return NUMERIC_DEFAULTS.get(forClass);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getConvertedType(OgnlContext context, Object target, Member member, String propertyName, Object value, Class type) {
/* 1634 */     return context.getTypeConverter().convertValue(context, target, member, propertyName, value, type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getConvertedTypes(OgnlContext context, Object target, Member member, String propertyName, Class[] parameterTypes, Object[] args, Object[] newArgs) {
/* 1640 */     boolean result = false;
/*      */     
/* 1642 */     if (parameterTypes.length == args.length) {
/* 1643 */       result = true;
/* 1644 */       for (int i = 0, ilast = parameterTypes.length - 1; result && i <= ilast; i++) {
/* 1645 */         Object arg = args[i];
/* 1646 */         Class type = parameterTypes[i];
/*      */         
/* 1648 */         if (isTypeCompatible(arg, type)) {
/* 1649 */           newArgs[i] = arg;
/*      */         } else {
/* 1651 */           Object v = getConvertedType(context, target, member, propertyName, arg, type);
/*      */           
/* 1653 */           if (v == NoConversionPossible) {
/* 1654 */             result = false;
/*      */           } else {
/* 1656 */             newArgs[i] = v;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1661 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Constructor getConvertedConstructorAndArgs(OgnlContext context, Object target, List<Constructor> constructors, Object[] args, Object[] newArgs) {
/* 1667 */     Constructor result = null;
/* 1668 */     TypeConverter converter = context.getTypeConverter();
/*      */     
/* 1670 */     if (converter != null && constructors != null) {
/* 1671 */       for (int i = 0, icount = constructors.size(); result == null && i < icount; i++) {
/* 1672 */         Constructor ctor = constructors.get(i);
/* 1673 */         Class[] parameterTypes = getParameterTypes(ctor);
/*      */         
/* 1675 */         if (getConvertedTypes(context, target, ctor, null, parameterTypes, args, newArgs)) {
/* 1676 */           result = ctor;
/*      */         }
/*      */       } 
/*      */     }
/* 1680 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getAppropriateMethod(OgnlContext context, Object source, Object target, String propertyName, String methodName, List methods, Object[] args, Object[] actualArgs) {
/* 1703 */     Method result = null;
/*      */     
/* 1705 */     if (methods != null) {
/*      */       
/* 1707 */       Class<?> typeClass = (target != null) ? target.getClass() : null;
/* 1708 */       if (typeClass == null && source != null && Class.class.isInstance(source))
/*      */       {
/* 1710 */         typeClass = (Class)source;
/*      */       }
/* 1712 */       Class[] argClasses = getArgClasses(args);
/*      */       
/* 1714 */       MatchingMethod mm = findBestMethod(methods, typeClass, methodName, argClasses);
/* 1715 */       if (mm != null) {
/* 1716 */         result = mm.mMethod;
/* 1717 */         Class[] mParameterTypes = mm.mParameterTypes;
/* 1718 */         System.arraycopy(args, 0, actualArgs, 0, args.length);
/*      */         
/* 1720 */         for (int j = 0; j < mParameterTypes.length; j++) {
/*      */           
/* 1722 */           Class type = mParameterTypes[j];
/*      */           
/* 1724 */           if (mm.report.conversionNeeded[j] || (type.isPrimitive() && actualArgs[j] == null))
/*      */           {
/* 1726 */             actualArgs[j] = getConvertedType(context, source, result, propertyName, args[j], type);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1732 */     if (result == null)
/*      */     {
/* 1734 */       result = getConvertedMethodAndArgs(context, target, propertyName, methods, args, actualArgs);
/*      */     }
/*      */     
/* 1737 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Method getConvertedMethodAndArgs(OgnlContext context, Object target, String propertyName, List<Method> methods, Object[] args, Object[] newArgs) {
/* 1742 */     Method result = null;
/* 1743 */     TypeConverter converter = context.getTypeConverter();
/*      */     
/* 1745 */     if (converter != null && methods != null) {
/* 1746 */       for (int i = 0, icount = methods.size(); result == null && i < icount; i++) {
/* 1747 */         Method m = methods.get(i);
/* 1748 */         Class[] parameterTypes = findParameterTypes((target != null) ? target.getClass() : null, m);
/*      */         
/* 1750 */         if (getConvertedTypes(context, target, m, propertyName, parameterTypes, args, newArgs)) {
/* 1751 */           result = m;
/*      */         }
/*      */       } 
/*      */     }
/* 1755 */     return result;
/*      */   }
/*      */   
/*      */   private static class MatchingMethod {
/*      */     Method mMethod;
/*      */     int score;
/*      */     OgnlRuntime.ArgsCompatbilityReport report;
/*      */     Class[] mParameterTypes;
/*      */     
/*      */     private MatchingMethod(Method method, int score, OgnlRuntime.ArgsCompatbilityReport report, Class[] mParameterTypes) {
/* 1765 */       this.mMethod = method;
/* 1766 */       this.score = score;
/* 1767 */       this.report = report;
/* 1768 */       this.mParameterTypes = mParameterTypes;
/*      */     }
/*      */   }
/*      */   
/*      */   private static MatchingMethod findBestMethod(List<Method> methods, Class typeClass, String name, Class[] argClasses) {
/* 1773 */     MatchingMethod mm = null;
/* 1774 */     IllegalArgumentException failure = null;
/* 1775 */     for (int i = 0, icount = methods.size(); i < icount; i++) {
/* 1776 */       Method m = methods.get(i);
/*      */       
/* 1778 */       Class[] mParameterTypes = findParameterTypes(typeClass, m);
/* 1779 */       ArgsCompatbilityReport report = areArgsCompatible(argClasses, mParameterTypes, m);
/* 1780 */       if (report != null) {
/*      */ 
/*      */         
/* 1783 */         String methodName = m.getName();
/* 1784 */         int score = report.score;
/* 1785 */         if (!name.equals(methodName))
/*      */         {
/* 1787 */           if (name.equalsIgnoreCase(methodName)) {
/*      */             
/* 1789 */             score += 200;
/* 1790 */           } else if (methodName.toLowerCase().endsWith(name.toLowerCase())) {
/*      */             
/* 1792 */             score += 500;
/*      */           } else {
/*      */             
/* 1795 */             score += 5000;
/*      */           }  } 
/* 1797 */         if (mm == null || mm.score > score) {
/* 1798 */           mm = new MatchingMethod(m, score, report, mParameterTypes);
/* 1799 */           failure = null;
/* 1800 */         } else if (mm.score == score) {
/*      */ 
/*      */ 
/*      */           
/* 1804 */           if (Arrays.equals((Object[])mm.mMethod.getParameterTypes(), (Object[])m.getParameterTypes()) && mm.mMethod.getName().equals(m.getName())) {
/* 1805 */             boolean retsAreEqual = mm.mMethod.getReturnType().equals(m.getReturnType());
/*      */             
/* 1807 */             if (mm.mMethod.getDeclaringClass().isAssignableFrom(m.getDeclaringClass())) {
/* 1808 */               if (!retsAreEqual && !mm.mMethod.getReturnType().isAssignableFrom(m.getReturnType())) {
/* 1809 */                 System.err.println("Two methods with same method signature but return types conflict? \"" + mm.mMethod + "\" and \"" + m + "\" please report!");
/*      */               }
/* 1811 */               mm = new MatchingMethod(m, score, report, mParameterTypes);
/* 1812 */               failure = null;
/* 1813 */             } else if (!m.getDeclaringClass().isAssignableFrom(mm.mMethod.getDeclaringClass())) {
/*      */               
/* 1815 */               System.err.println("Two methods with same method signature but not providing classes assignable? \"" + mm.mMethod + "\" and \"" + m + "\" please report!");
/* 1816 */             } else if (!retsAreEqual && !m.getReturnType().isAssignableFrom(mm.mMethod.getReturnType())) {
/* 1817 */               System.err.println("Two methods with same method signature but return types conflict? \"" + mm.mMethod + "\" and \"" + m + "\" please report!");
/*      */             }
/*      */           
/*      */           }
/* 1821 */           else if (isJdk15() && (m.isVarArgs() || mm.mMethod.isVarArgs())) {
/* 1822 */             if (!m.isVarArgs() || mm.mMethod.isVarArgs())
/*      */             {
/* 1824 */               if (!m.isVarArgs() && mm.mMethod.isVarArgs()) {
/*      */                 
/* 1826 */                 mm = new MatchingMethod(m, score, report, mParameterTypes);
/* 1827 */                 failure = null;
/*      */               } else {
/*      */                 
/* 1830 */                 System.err.println("Two vararg methods with same score(" + score + "): \"" + mm.mMethod + "\" and \"" + m + "\" please report!");
/*      */               }  } 
/*      */           } else {
/* 1833 */             int scoreCurr = 0;
/* 1834 */             int scoreOther = 0;
/* 1835 */             for (int j = 0; j < argClasses.length; j++) {
/* 1836 */               Class<?> argClass = argClasses[j];
/* 1837 */               Class<?> mcClass = mm.mParameterTypes[j];
/* 1838 */               Class<?> moClass = mParameterTypes[j];
/* 1839 */               if (argClass == null) {
/*      */                 
/* 1841 */                 if (mcClass != moClass)
/*      */                 {
/* 1843 */                   if (mcClass.isAssignableFrom(moClass)) {
/* 1844 */                     scoreOther += 1000;
/* 1845 */                   } else if (moClass.isAssignableFrom(moClass)) {
/* 1846 */                     scoreCurr += 1000;
/*      */                   } else {
/*      */                     
/* 1849 */                     failure = new IllegalArgumentException("Can't decide wich method to use: \"" + mm.mMethod + "\" or \"" + m + "\"");
/*      */                   }
/*      */                 
/*      */                 }
/* 1853 */               } else if (mcClass != moClass) {
/*      */                 
/* 1855 */                 if (mcClass == argClass) {
/* 1856 */                   scoreOther += 100;
/* 1857 */                 } else if (moClass == argClass) {
/* 1858 */                   scoreCurr += 100;
/*      */                 }
/*      */                 else {
/*      */                   
/* 1862 */                   failure = new IllegalArgumentException("Can't decide wich method to use: \"" + mm.mMethod + "\" or \"" + m + "\"");
/*      */                 } 
/*      */               } 
/*      */             } 
/* 1866 */             if (scoreCurr == scoreOther) {
/* 1867 */               if (failure == null) {
/* 1868 */                 boolean currentIsAbstract = Modifier.isAbstract(mm.mMethod.getModifiers());
/* 1869 */                 boolean otherIsAbstract = Modifier.isAbstract(m.getModifiers());
/* 1870 */                 if (!(currentIsAbstract ^ otherIsAbstract))
/*      */                 {
/*      */ 
/*      */                   
/* 1874 */                   System.err.println("Two methods with same score(" + score + "): \"" + mm.mMethod + "\" and \"" + m + "\" please report!");
/*      */                 }
/*      */               } 
/* 1877 */             } else if (scoreCurr > scoreOther) {
/*      */               
/* 1879 */               mm = new MatchingMethod(m, score, report, mParameterTypes);
/* 1880 */               failure = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1886 */     if (failure != null)
/* 1887 */       throw failure; 
/* 1888 */     return mm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callAppropriateMethod(OgnlContext context, Object source, Object target, String methodName, String propertyName, List methods, Object[] args) throws MethodFailedException {
/* 1895 */     Throwable reason = null;
/* 1896 */     Object[] actualArgs = _objectArrayPool.create(args.length);
/*      */     
/*      */     try {
/* 1899 */       Method method = getAppropriateMethod(context, source, target, propertyName, methodName, methods, args, actualArgs);
/*      */       
/* 1901 */       if (method == null || !isMethodAccessible(context, source, method, propertyName)) {
/*      */         
/* 1903 */         StringBuffer buffer = new StringBuffer();
/* 1904 */         String className = "";
/*      */         
/* 1906 */         if (target != null)
/*      */         {
/* 1908 */           className = target.getClass().getName() + ".";
/*      */         }
/*      */         
/* 1911 */         for (int i = 0, ilast = args.length - 1; i <= ilast; i++) {
/*      */           
/* 1913 */           Object arg = args[i];
/*      */           
/* 1915 */           buffer.append((arg == null) ? NULL_STRING : arg.getClass().getName());
/* 1916 */           if (i < ilast)
/*      */           {
/* 1918 */             buffer.append(", ");
/*      */           }
/*      */         } 
/*      */         
/* 1922 */         throw new NoSuchMethodException(className + methodName + "(" + buffer + ")");
/*      */       } 
/*      */       
/* 1925 */       Object[] convertedArgs = actualArgs;
/*      */       
/* 1927 */       if (isJdk15() && method.isVarArgs()) {
/*      */         
/* 1929 */         Class[] parmTypes = method.getParameterTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1935 */         for (int i = 0; i < parmTypes.length; i++) {
/*      */           
/* 1937 */           if (parmTypes[i].isArray()) {
/*      */             Object[] varArgs;
/* 1939 */             convertedArgs = new Object[i + 1];
/* 1940 */             System.arraycopy(actualArgs, 0, convertedArgs, 0, convertedArgs.length);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1946 */             if (actualArgs.length > i) {
/*      */               
/* 1948 */               ArrayList<Object> varArgsList = new ArrayList();
/* 1949 */               for (int j = i; j < actualArgs.length; j++) {
/*      */                 
/* 1951 */                 if (actualArgs[j] != null)
/*      */                 {
/* 1953 */                   varArgsList.add(actualArgs[j]);
/*      */                 }
/*      */               } 
/*      */               
/* 1957 */               varArgs = varArgsList.toArray();
/*      */             } else {
/*      */               
/* 1960 */               varArgs = new Object[0];
/*      */             } 
/*      */             
/* 1963 */             convertedArgs[i] = varArgs;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1969 */       return invokeMethod(target, method, convertedArgs);
/*      */     }
/* 1971 */     catch (NoSuchMethodException e) {
/* 1972 */       reason = e;
/* 1973 */     } catch (IllegalAccessException e) {
/* 1974 */       reason = e;
/* 1975 */     } catch (InvocationTargetException e) {
/* 1976 */       reason = e.getTargetException();
/*      */     } finally {
/* 1978 */       _objectArrayPool.recycle(actualArgs);
/*      */     } 
/*      */     
/* 1981 */     throw new MethodFailedException(source, methodName, reason);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callStaticMethod(OgnlContext context, String className, String methodName, Object[] args) throws OgnlException {
/*      */     try {
/* 1988 */       Class targetClass = classForName(context, className);
/* 1989 */       if (targetClass == null) {
/* 1990 */         throw new ClassNotFoundException("Unable to resolve class with name " + className);
/*      */       }
/* 1992 */       MethodAccessor ma = getMethodAccessor(targetClass);
/*      */       
/* 1994 */       return ma.callStaticMethod(context, targetClass, methodName, args);
/* 1995 */     } catch (ClassNotFoundException ex) {
/* 1996 */       throw new MethodFailedException(className, methodName, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callMethod(OgnlContext context, Object target, String methodName, String propertyName, Object[] args) throws OgnlException {
/* 2021 */     return callMethod(context, target, (methodName == null) ? propertyName : methodName, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callMethod(OgnlContext context, Object target, String methodName, Object[] args) throws OgnlException {
/* 2042 */     if (target == null) {
/* 2043 */       throw new NullPointerException("target is null for method " + methodName);
/*      */     }
/* 2045 */     return getMethodAccessor(target.getClass()).callMethod(context, target, methodName, args);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object callConstructor(OgnlContext context, String className, Object[] args) throws OgnlException {
/* 2051 */     Throwable reason = null;
/* 2052 */     Object[] actualArgs = args;
/*      */ 
/*      */     
/* 2055 */     try { Constructor<int> ctor = null;
/* 2056 */       Class[] ctorParameterTypes = null;
/* 2057 */       Class target = classForName(context, className);
/* 2058 */       List<Constructor> constructors = getConstructors(target);
/*      */       int i, icount;
/* 2060 */       for (i = 0, icount = constructors.size(); i < icount; i++) {
/* 2061 */         Constructor<int> c = constructors.get(i);
/* 2062 */         Class[] cParameterTypes = getParameterTypes(c);
/*      */         
/* 2064 */         if (areArgsCompatible(args, cParameterTypes) && (ctor == null || isMoreSpecific(cParameterTypes, ctorParameterTypes))) {
/*      */           
/* 2066 */           ctor = c;
/* 2067 */           ctorParameterTypes = cParameterTypes;
/*      */         } 
/*      */       } 
/*      */       
/* 2071 */       actualArgs = _objectArrayPool.create(args.length);
/* 2072 */       if (ctor == null && (ctor = getConvertedConstructorAndArgs(context, target, constructors, args, actualArgs)) == null) {
/* 2073 */         throw new NoSuchMethodException();
/*      */       }
/*      */       
/* 2076 */       if (!context.getMemberAccess().isAccessible(context, target, ctor, null)) {
/* 2077 */         throw new IllegalAccessException("access denied to " + target.getName() + "()");
/*      */       }
/*      */       
/* 2080 */       i = ctor.newInstance(actualArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2093 */       return i; } catch (ClassNotFoundException e) { reason = e; } catch (NoSuchMethodException e) { reason = e; } catch (IllegalAccessException e) { reason = e; } catch (InvocationTargetException e) { reason = e.getTargetException(); } catch (InstantiationException e) { reason = e; } finally { if (actualArgs != args) _objectArrayPool.recycle(actualArgs);
/*      */        }
/*      */ 
/*      */     
/* 2097 */     throw new MethodFailedException(className, "new", reason);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static final Object getMethodValue(OgnlContext context, Object target, String propertyName) throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException {
/* 2116 */     return getMethodValue(context, target, propertyName, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Object getMethodValue(OgnlContext context, Object target, String propertyName, boolean checkAccessAndExistence) throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException {
/* 2138 */     Object result = null;
/* 2139 */     Method m = getGetMethod(context, (target == null) ? null : target.getClass(), propertyName);
/* 2140 */     if (m == null) {
/* 2141 */       m = getReadMethod((target == null) ? null : target.getClass(), propertyName, null);
/*      */     }
/* 2143 */     if (checkAccessAndExistence)
/*      */     {
/* 2145 */       if (m == null || !context.getMemberAccess().isAccessible(context, target, m, propertyName))
/*      */       {
/* 2147 */         result = NotFound;
/*      */       }
/*      */     }
/* 2150 */     if (result == null) {
/* 2151 */       if (m != null) {
/*      */         try {
/* 2153 */           result = invokeMethod(target, m, NoArguments);
/* 2154 */         } catch (InvocationTargetException ex) {
/* 2155 */           throw new OgnlException(propertyName, ex.getTargetException());
/*      */         } 
/*      */       } else {
/* 2158 */         throw new NoSuchMethodException(propertyName);
/*      */       } 
/*      */     }
/* 2161 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean setMethodValue(OgnlContext context, Object target, String propertyName, Object value) throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException {
/* 2181 */     return setMethodValue(context, target, propertyName, value, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean setMethodValue(OgnlContext context, Object target, String propertyName, Object value, boolean checkAccessAndExistence) throws OgnlException, IllegalAccessException, NoSuchMethodException, IntrospectionException {
/* 2188 */     boolean result = true;
/* 2189 */     Method m = getSetMethod(context, (target == null) ? null : target.getClass(), propertyName);
/*      */     
/* 2191 */     if (checkAccessAndExistence)
/*      */     {
/* 2193 */       if (m == null || !context.getMemberAccess().isAccessible(context, target, m, propertyName))
/*      */       {
/* 2195 */         result = false;
/*      */       }
/*      */     }
/*      */     
/* 2199 */     if (result)
/*      */     {
/* 2201 */       if (m != null) {
/*      */         
/* 2203 */         Object[] args = _objectArrayPool.create(value);
/*      */ 
/*      */         
/*      */         try {
/* 2207 */           callAppropriateMethod(context, target, target, m.getName(), propertyName, Collections.nCopies(1, m), args);
/*      */         }
/*      */         finally {
/*      */           
/* 2211 */           _objectArrayPool.recycle(args);
/*      */         } 
/*      */       } else {
/*      */         
/* 2215 */         result = false;
/*      */       } 
/*      */     }
/*      */     
/* 2219 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static List getConstructors(Class targetClass) {
/*      */     List<Constructor<?>> result;
/* 2225 */     if ((result = (List)_constructorCache.get(targetClass)) == null) {
/* 2226 */       synchronized (_constructorCache) {
/* 2227 */         if ((result = (List)_constructorCache.get(targetClass)) == null) {
/* 2228 */           _constructorCache.put(targetClass, result = Arrays.asList(targetClass.getConstructors()));
/*      */         }
/*      */       } 
/*      */     }
/* 2232 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Map getMethods(Class targetClass, boolean staticMethods) {
/* 2237 */     ClassCache cache = staticMethods ? _staticMethodCache : _instanceMethodCache;
/*      */     
/*      */     Map<Object, Object> result;
/* 2240 */     if ((result = (Map)cache.get(targetClass)) == null) {
/* 2241 */       synchronized (cache) {
/*      */         
/* 2243 */         if ((result = (Map)cache.get(targetClass)) == null) {
/*      */           
/* 2245 */           result = new HashMap<>(23);
/* 2246 */           collectMethods(targetClass, result, staticMethods);
/* 2247 */           cache.put(targetClass, result);
/*      */         } 
/*      */       } 
/*      */     }
/* 2251 */     return result;
/*      */   }
/*      */   
/*      */   private static void collectMethods(Class c, Map result, boolean staticMethods) {
/*      */     Method[] ma;
/*      */     try {
/* 2257 */       ma = c.getDeclaredMethods();
/* 2258 */     } catch (SecurityException ignored) {
/* 2259 */       ma = c.getMethods();
/*      */     } 
/* 2261 */     for (int i = 0, icount = ma.length; i < icount; i++) {
/*      */       
/* 2263 */       if (c.isInterface()) {
/*      */         
/* 2265 */         if (isDefaultMethod(ma[i])) {
/* 2266 */           addMethodToResult(result, ma[i]);
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2271 */       else if (isMethodCallable(ma[i])) {
/*      */ 
/*      */         
/* 2274 */         if (Modifier.isStatic(ma[i].getModifiers()) == staticMethods)
/* 2275 */           addMethodToResult(result, ma[i]); 
/*      */       } 
/*      */     } 
/* 2278 */     Class superclass = c.getSuperclass();
/* 2279 */     if (superclass != null) {
/* 2280 */       collectMethods(superclass, result, staticMethods);
/*      */     }
/* 2282 */     for (Class<?> iface : c.getInterfaces()) {
/* 2283 */       collectMethods(iface, result, staticMethods);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void addMethodToResult(Map<String, List> result, Method method) {
/* 2288 */     List<Method> ml = (List)result.get(method.getName());
/* 2289 */     if (ml == null)
/* 2290 */       result.put(method.getName(), ml = new ArrayList()); 
/* 2291 */     ml.add(method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isDefaultMethod(Method method) {
/* 2306 */     return ((method.getModifiers() & 0x409) == 1 && method.getDeclaringClass().isInterface());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isNonDefaultPublicInterfaceMethod(Method method) {
/* 2324 */     return ((method.getModifiers() & 0x409) == 1025 && method.getDeclaringClass().isInterface());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map getAllMethods(Class targetClass, boolean staticMethods) {
/* 2331 */     ClassCache cache = staticMethods ? _staticMethodCache : _instanceMethodCache;
/*      */     
/*      */     Map<Object, Object> result;
/* 2334 */     if ((result = (Map)cache.get(targetClass)) == null) {
/* 2335 */       synchronized (cache) {
/*      */         
/* 2337 */         if ((result = (Map)cache.get(targetClass)) == null) {
/*      */           
/* 2339 */           result = new HashMap<>(23);
/*      */           
/* 2341 */           for (Class c = targetClass; c != null; c = c.getSuperclass()) {
/*      */             
/* 2343 */             Method[] ma = c.getMethods();
/*      */             
/* 2345 */             for (int i = 0, icount = ma.length; i < icount; i++) {
/*      */ 
/*      */ 
/*      */               
/* 2349 */               if (isMethodCallable(ma[i]))
/*      */               {
/*      */                 
/* 2352 */                 if (Modifier.isStatic(ma[i].getModifiers()) == staticMethods) {
/*      */                   
/* 2354 */                   List<Method> ml = (List)result.get(ma[i].getName());
/*      */                   
/* 2356 */                   if (ml == null) {
/* 2357 */                     result.put(ma[i].getName(), ml = new ArrayList());
/*      */                   }
/* 2359 */                   ml.add(ma[i]);
/*      */                 }  } 
/*      */             } 
/*      */           } 
/* 2363 */           cache.put(targetClass, result);
/*      */         } 
/*      */       } 
/*      */     }
/* 2367 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static List getMethods(Class targetClass, String name, boolean staticMethods) {
/* 2372 */     return (List)getMethods(targetClass, staticMethods).get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public static List getAllMethods(Class targetClass, String name, boolean staticMethods) {
/* 2377 */     return (List)getAllMethods(targetClass, staticMethods).get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map getFields(Class targetClass) {
/*      */     Map<Object, Object> result;
/* 2384 */     if ((result = (Map)_fieldCache.get(targetClass)) == null) {
/* 2385 */       synchronized (_fieldCache) {
/* 2386 */         if ((result = (Map)_fieldCache.get(targetClass)) == null) {
/*      */           Field[] fa;
/*      */           
/* 2389 */           result = new HashMap<>(23);
/*      */           try {
/* 2391 */             fa = targetClass.getDeclaredFields();
/* 2392 */           } catch (SecurityException ignored) {
/* 2393 */             fa = targetClass.getFields();
/*      */           } 
/* 2395 */           for (int i = 0; i < fa.length; i++) {
/* 2396 */             result.put(fa[i].getName(), fa[i]);
/*      */           }
/* 2398 */           _fieldCache.put(targetClass, result);
/*      */         } 
/*      */       } 
/*      */     }
/* 2402 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Field getField(Class<?> inClass, String name) {
/* 2407 */     Field result = null;
/*      */     
/* 2409 */     Object o = getFields(inClass).get(name);
/* 2410 */     if (o == null) {
/* 2411 */       synchronized (_fieldCache) {
/* 2412 */         o = getFields(inClass).get(name);
/*      */         
/* 2414 */         if (o == null) {
/* 2415 */           _superclasses.clear();
/* 2416 */           for (Class<?> sc = inClass; sc != null && (
/* 2417 */             o = getFields(sc).get(name)) != NotFound; sc = sc.getSuperclass()) {
/*      */ 
/*      */             
/* 2420 */             _superclasses.add(sc);
/*      */             
/* 2422 */             if ((result = (Field)o) != null) {
/*      */               break;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 2429 */           for (int i = 0, icount = _superclasses.size(); i < icount; i++) {
/* 2430 */             getFields(_superclasses.get(i)).put(name, (result == null) ? NotFound : result);
/*      */           }
/*      */         }
/* 2433 */         else if (o instanceof Field) {
/* 2434 */           result = (Field)o;
/*      */         }
/* 2436 */         else if (result == NotFound) {
/* 2437 */           result = null;
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2443 */     else if (o instanceof Field) {
/* 2444 */       result = (Field)o;
/*      */     }
/* 2446 */     else if (result == NotFound) {
/* 2447 */       result = null;
/*      */     } 
/*      */     
/* 2450 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Object getFieldValue(OgnlContext context, Object target, String propertyName) throws NoSuchFieldException {
/* 2466 */     return getFieldValue(context, target, propertyName, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getFieldValue(OgnlContext context, Object target, String propertyName, boolean checkAccessAndExistence) throws NoSuchFieldException {
/* 2473 */     Object result = null;
/* 2474 */     Field f = getField((target == null) ? null : target.getClass(), propertyName);
/*      */     
/* 2476 */     if (checkAccessAndExistence && (
/* 2477 */       f == null || !context.getMemberAccess().isAccessible(context, target, f, propertyName))) {
/* 2478 */       result = NotFound;
/*      */     }
/*      */     
/* 2481 */     if (result == null) {
/* 2482 */       if (f == null) {
/* 2483 */         throw new NoSuchFieldException(propertyName);
/*      */       }
/*      */       
/*      */       try {
/* 2487 */         if (!Modifier.isStatic(f.getModifiers())) {
/* 2488 */           Object state = context.getMemberAccess().setup(context, target, f, propertyName);
/*      */           try {
/* 2490 */             result = f.get(target);
/*      */           } finally {
/* 2492 */             context.getMemberAccess().restore(context, target, f, propertyName, state);
/*      */           } 
/*      */         } else {
/* 2495 */           throw new NoSuchFieldException(propertyName);
/*      */         }
/*      */       
/* 2498 */       } catch (IllegalAccessException ex) {
/* 2499 */         throw new NoSuchFieldException(propertyName);
/*      */       } 
/*      */     } 
/*      */     
/* 2503 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean setFieldValue(OgnlContext context, Object target, String propertyName, Object value) throws OgnlException {
/* 2509 */     boolean result = false;
/*      */     
/*      */     try {
/* 2512 */       Field f = getField((target == null) ? null : target.getClass(), propertyName);
/*      */       
/* 2514 */       if (f != null) {
/* 2515 */         int fModifiers = f.getModifiers();
/* 2516 */         if (!Modifier.isStatic(fModifiers) && !Modifier.isFinal(fModifiers)) {
/* 2517 */           Object state = context.getMemberAccess().setup(context, target, f, propertyName);
/*      */           try {
/* 2519 */             if (isTypeCompatible(value, f.getType()) || (value = getConvertedType(context, target, f, propertyName, value, f.getType())) != null) {
/*      */               
/* 2521 */               f.set(target, value);
/* 2522 */               result = true;
/*      */             } 
/*      */           } finally {
/* 2525 */             context.getMemberAccess().restore(context, target, f, propertyName, state);
/*      */           } 
/*      */         } 
/*      */       } 
/* 2529 */     } catch (IllegalAccessException ex) {
/* 2530 */       throw new NoSuchPropertyException(target, propertyName, ex);
/*      */     } 
/* 2532 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isFieldAccessible(OgnlContext context, Object target, Class inClass, String propertyName) {
/* 2537 */     return isFieldAccessible(context, target, getField(inClass, propertyName), propertyName);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isFieldAccessible(OgnlContext context, Object target, Field field, String propertyName) {
/* 2542 */     return context.getMemberAccess().isAccessible(context, target, field, propertyName);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasField(OgnlContext context, Object target, Class inClass, String propertyName) {
/* 2547 */     Field f = getField(inClass, propertyName);
/*      */     
/* 2549 */     return (f != null && isFieldAccessible(context, target, f, propertyName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getStaticField(OgnlContext context, String className, String fieldName) throws OgnlException {
/* 2569 */     Exception reason = null; try {
/*      */       Field f; Object result;
/* 2571 */       Class<Enum> c = classForName(context, className);
/*      */       
/* 2573 */       if (c == null) {
/* 2574 */         throw new OgnlException("Unable to find class " + className + " when resolving field name of " + fieldName);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2581 */       if (fieldName.equals("class"))
/*      */       {
/* 2583 */         return c; } 
/* 2584 */       if (isJdk15() && c.isEnum()) {
/*      */         
/*      */         try {
/* 2587 */           return Enum.valueOf(c, fieldName);
/* 2588 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2595 */         f = c.getField(fieldName);
/* 2596 */       } catch (NoSuchFieldException nsfe) {
/* 2597 */         f = getField(c, fieldName);
/* 2598 */         if (f == null) {
/* 2599 */           throw new NoSuchFieldException(fieldName);
/*      */         }
/*      */       } 
/* 2602 */       int fModifiers = f.getModifiers();
/* 2603 */       if (!Modifier.isStatic(fModifiers)) {
/* 2604 */         throw new OgnlException("Field " + fieldName + " of class " + className + " is not static");
/*      */       }
/*      */ 
/*      */       
/* 2608 */       if (Modifier.isPublic(fModifiers)) {
/* 2609 */         result = f.get(null);
/*      */       }
/* 2611 */       else if (context.getMemberAccess().isAccessible(context, null, f, null)) {
/* 2612 */         Object state = context.getMemberAccess().setup(context, null, f, null);
/*      */         try {
/* 2614 */           result = f.get(null);
/*      */         } finally {
/* 2616 */           context.getMemberAccess().restore(context, null, f, null, state);
/*      */         } 
/*      */       } else {
/* 2619 */         throw new IllegalAccessException("Access to " + fieldName + " of class " + className + " is forbidden");
/*      */       } 
/*      */ 
/*      */       
/* 2623 */       return result;
/* 2624 */     } catch (ClassNotFoundException e) {
/* 2625 */       reason = e;
/* 2626 */     } catch (NoSuchFieldException e) {
/* 2627 */       reason = e;
/* 2628 */     } catch (SecurityException e) {
/* 2629 */       reason = e;
/* 2630 */     } catch (IllegalAccessException e) {
/* 2631 */       reason = e;
/*      */     } 
/*      */     
/* 2634 */     throw new OgnlException("Could not get static field " + fieldName + " from class " + className, reason);
/*      */   }
/*      */   
/*      */   private static String capitalizeBeanPropertyName(String propertyName) {
/* 2638 */     if (propertyName.length() == 1) {
/* 2639 */       return propertyName.toUpperCase();
/*      */     }
/*      */     
/* 2642 */     if (propertyName.startsWith("get") && propertyName.endsWith("()") && 
/* 2643 */       Character.isUpperCase(propertyName.substring(3, 4).charAt(0))) {
/* 2644 */       return propertyName;
/*      */     }
/*      */     
/* 2647 */     if (propertyName.startsWith("set") && propertyName.endsWith(")") && 
/* 2648 */       Character.isUpperCase(propertyName.substring(3, 4).charAt(0))) {
/* 2649 */       return propertyName;
/*      */     }
/*      */     
/* 2652 */     if (propertyName.startsWith("is") && propertyName.endsWith("()") && 
/* 2653 */       Character.isUpperCase(propertyName.substring(2, 3).charAt(0))) {
/* 2654 */       return propertyName;
/*      */     }
/*      */     
/* 2657 */     char first = propertyName.charAt(0);
/* 2658 */     char second = propertyName.charAt(1);
/* 2659 */     if (Character.isLowerCase(first) && Character.isUpperCase(second)) {
/* 2660 */       return propertyName;
/*      */     }
/* 2662 */     char[] chars = propertyName.toCharArray();
/* 2663 */     chars[0] = Character.toUpperCase(chars[0]);
/* 2664 */     return new String(chars);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static List getDeclaredMethods(Class targetClass, String propertyName, boolean findSets) {
/* 2670 */     List result = null;
/* 2671 */     ClassCache cache = _declaredMethods[findSets ? 0 : 1];
/*      */     
/* 2673 */     Map<Object, Object> propertyCache = (Map)cache.get(targetClass);
/* 2674 */     if (propertyCache == null || (result = (List)propertyCache.get(propertyName)) == null) {
/* 2675 */       synchronized (cache) {
/* 2676 */         propertyCache = (Map)cache.get(targetClass);
/*      */         
/* 2678 */         if (propertyCache == null || (result = (List)propertyCache.get(propertyName)) == null) {
/*      */           
/* 2680 */           String baseName = capitalizeBeanPropertyName(propertyName);
/* 2681 */           result = new ArrayList();
/* 2682 */           collectAccessors(targetClass, baseName, result, findSets);
/*      */           
/* 2684 */           if (propertyCache == null) {
/* 2685 */             cache.put(targetClass, propertyCache = new HashMap<>(101));
/*      */           }
/* 2687 */           propertyCache.put(propertyName, result.isEmpty() ? NotFoundList : result);
/*      */           
/* 2689 */           return result.isEmpty() ? null : result;
/*      */         } 
/*      */       } 
/*      */     }
/* 2693 */     return (result == NotFoundList) ? null : result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void collectAccessors(Class c, String baseName, List result, boolean findSets) {
/*      */     Method[] methods;
/*      */     try {
/* 2700 */       methods = c.getDeclaredMethods();
/* 2701 */     } catch (SecurityException ignored) {
/* 2702 */       methods = c.getMethods();
/*      */     } 
/* 2704 */     for (int i = 0; i < methods.length; i++) {
/* 2705 */       if (c.isInterface()) {
/* 2706 */         if (isDefaultMethod(methods[i]) || isNonDefaultPublicInterfaceMethod(methods[i])) {
/* 2707 */           addIfAccessor(result, methods[i], baseName, findSets);
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2712 */       else if (isMethodCallable(methods[i])) {
/*      */ 
/*      */         
/* 2715 */         addIfAccessor(result, methods[i], baseName, findSets);
/*      */       } 
/*      */     } 
/* 2718 */     Class superclass = c.getSuperclass();
/* 2719 */     if (superclass != null) {
/* 2720 */       collectAccessors(superclass, baseName, result, findSets);
/*      */     }
/* 2722 */     for (Class<?> iface : c.getInterfaces()) {
/* 2723 */       collectAccessors(iface, baseName, result, findSets);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void addIfAccessor(List<Method> result, Method method, String baseName, boolean findSets) {
/* 2728 */     String ms = method.getName();
/*      */     
/* 2730 */     boolean isSet = false, isIs = false;
/* 2731 */     if (ms.endsWith(baseName) && ((isSet = ms.startsWith("set")) || ms.startsWith("get") || (isIs = ms.startsWith("is")))) {
/*      */       
/* 2733 */       int prefixLength = isIs ? 2 : 3;
/* 2734 */       if (isSet == findSets && 
/* 2735 */         baseName.length() == ms.length() - prefixLength) {
/* 2736 */         result.add(method);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isMethodCallable(Method m) {
/* 2752 */     if ((isJdk15() && m.isSynthetic()) || Modifier.isVolatile(m.getModifiers())) {
/* 2753 */       return false;
/*      */     }
/* 2755 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getGetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2772 */     Method method = cacheGetMethod.get(targetClass, propertyName);
/* 2773 */     if (method != null) {
/* 2774 */       return method;
/*      */     }
/*      */     
/* 2777 */     if (cacheGetMethod.containsKey(targetClass, propertyName)) {
/* 2778 */       return null;
/*      */     }
/* 2780 */     method = _getGetMethod(context, targetClass, propertyName);
/* 2781 */     cacheGetMethod.put(targetClass, propertyName, method);
/*      */     
/* 2783 */     return method;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Method _getGetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2809 */     Method result = null;
/*      */     
/* 2811 */     List<Method> methods = getDeclaredMethods(targetClass, propertyName, false);
/*      */     
/* 2813 */     if (methods != null) {
/*      */       
/* 2815 */       Method firstGetter = null;
/* 2816 */       Method firstPublicGetter = null;
/* 2817 */       Method firstNonDefaultPublicInterfaceGetter = null;
/* 2818 */       for (int i = 0, icount = methods.size(); i < icount; i++) {
/*      */         
/* 2820 */         Method m = methods.get(i);
/* 2821 */         Class[] mParameterTypes = findParameterTypes(targetClass, m);
/*      */         
/* 2823 */         if (mParameterTypes.length == 0) {
/*      */           
/* 2825 */           boolean declaringClassIsPublic = Modifier.isPublic(m.getDeclaringClass().getModifiers());
/* 2826 */           if (firstGetter == null) {
/* 2827 */             firstGetter = m;
/* 2828 */             if (_useFirstMatchGetSetLookup) {
/*      */               break;
/*      */             }
/*      */           } 
/* 2832 */           if (firstPublicGetter == null && Modifier.isPublic(m.getModifiers()) && declaringClassIsPublic) {
/* 2833 */             firstPublicGetter = m;
/*      */             break;
/*      */           } 
/* 2836 */           if (firstNonDefaultPublicInterfaceGetter == null && isNonDefaultPublicInterfaceMethod(m) && declaringClassIsPublic) {
/* 2837 */             firstNonDefaultPublicInterfaceGetter = m;
/*      */           }
/*      */         } 
/*      */       } 
/* 2841 */       result = (firstPublicGetter != null) ? firstPublicGetter : ((firstNonDefaultPublicInterfaceGetter != null) ? firstNonDefaultPublicInterfaceGetter : firstGetter);
/*      */     } 
/*      */ 
/*      */     
/* 2845 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isMethodAccessible(OgnlContext context, Object target, Method method, String propertyName) {
/* 2850 */     return (method != null && context.getMemberAccess().isAccessible(context, target, method, propertyName));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasGetMethod(OgnlContext context, Object target, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2856 */     return isMethodAccessible(context, target, getGetMethod(context, targetClass, propertyName), propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getSetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2873 */     Method method = cacheSetMethod.get(targetClass, propertyName);
/* 2874 */     if (method != null) {
/* 2875 */       return method;
/*      */     }
/*      */     
/* 2878 */     if (cacheSetMethod.containsKey(targetClass, propertyName)) {
/* 2879 */       return null;
/*      */     }
/* 2881 */     method = _getSetMethod(context, targetClass, propertyName);
/* 2882 */     cacheSetMethod.put(targetClass, propertyName, method);
/*      */     
/* 2884 */     return method;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Method _getSetMethod(OgnlContext context, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2910 */     Method result = null;
/*      */     
/* 2912 */     List<Method> methods = getDeclaredMethods(targetClass, propertyName, true);
/*      */     
/* 2914 */     if (methods != null) {
/*      */       
/* 2916 */       Method firstSetter = null;
/* 2917 */       Method firstPublicSetter = null;
/* 2918 */       Method firstNonDefaultPublicInterfaceSetter = null;
/* 2919 */       for (int i = 0, icount = methods.size(); i < icount; i++) {
/*      */         
/* 2921 */         Method m = methods.get(i);
/* 2922 */         Class[] mParameterTypes = findParameterTypes(targetClass, m);
/*      */         
/* 2924 */         if (mParameterTypes.length == 1) {
/* 2925 */           boolean declaringClassIsPublic = Modifier.isPublic(m.getDeclaringClass().getModifiers());
/* 2926 */           if (firstSetter == null) {
/* 2927 */             firstSetter = m;
/* 2928 */             if (_useFirstMatchGetSetLookup) {
/*      */               break;
/*      */             }
/*      */           } 
/* 2932 */           if (firstPublicSetter == null && Modifier.isPublic(m.getModifiers()) && declaringClassIsPublic) {
/* 2933 */             firstPublicSetter = m;
/*      */             break;
/*      */           } 
/* 2936 */           if (firstNonDefaultPublicInterfaceSetter == null && isNonDefaultPublicInterfaceMethod(m) && declaringClassIsPublic) {
/* 2937 */             firstNonDefaultPublicInterfaceSetter = m;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 2942 */       result = (firstPublicSetter != null) ? firstPublicSetter : ((firstNonDefaultPublicInterfaceSetter != null) ? firstNonDefaultPublicInterfaceSetter : firstSetter);
/*      */     } 
/*      */ 
/*      */     
/* 2946 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean hasSetMethod(OgnlContext context, Object target, Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 2952 */     return isMethodAccessible(context, target, getSetMethod(context, targetClass, propertyName), propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean hasGetProperty(OgnlContext context, Object target, Object oname) throws IntrospectionException, OgnlException {
/* 2958 */     Class<?> targetClass = (target == null) ? null : target.getClass();
/* 2959 */     String name = oname.toString();
/*      */     
/* 2961 */     return (hasGetMethod(context, target, targetClass, name) || hasField(context, target, targetClass, name));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean hasSetProperty(OgnlContext context, Object target, Object oname) throws IntrospectionException, OgnlException {
/* 2967 */     Class<?> targetClass = (target == null) ? null : target.getClass();
/* 2968 */     String name = oname.toString();
/*      */     
/* 2970 */     return (hasSetMethod(context, target, targetClass, name) || hasField(context, target, targetClass, name));
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean indexMethodCheck(List<Method> methods) {
/* 2975 */     boolean result = false;
/*      */     
/* 2977 */     if (methods.size() > 0) {
/* 2978 */       Method fm = methods.get(0);
/* 2979 */       Class[] fmpt = getParameterTypes(fm);
/* 2980 */       int fmpc = fmpt.length;
/* 2981 */       Class<?> lastMethodClass = fm.getDeclaringClass();
/*      */       
/* 2983 */       result = true;
/* 2984 */       for (int i = 1; result && i < methods.size(); i++) {
/* 2985 */         Method m = methods.get(i);
/* 2986 */         Class<?> c = m.getDeclaringClass();
/*      */ 
/*      */         
/* 2989 */         if (lastMethodClass == c) {
/* 2990 */           result = false;
/*      */         } else {
/* 2992 */           Class[] mpt = getParameterTypes(fm);
/* 2993 */           int mpc = fmpt.length;
/*      */           
/* 2995 */           if (fmpc != mpc) {
/* 2996 */             result = false;
/*      */           }
/* 2998 */           for (int j = 0; j < fmpc; j++) {
/* 2999 */             if (fmpt[j] != mpt[j]) {
/* 3000 */               result = false;
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/* 3005 */         lastMethodClass = c;
/*      */       } 
/*      */     } 
/* 3008 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void findObjectIndexedPropertyDescriptors(Class targetClass, Map<String, ObjectIndexedPropertyDescriptor> intoMap) throws OgnlException {
/* 3014 */     Map allMethods = getMethods(targetClass, false);
/* 3015 */     Map<Object, Object> pairs = new HashMap<>(101);
/*      */     
/* 3017 */     for (Iterator<String> iterator1 = allMethods.keySet().iterator(); iterator1.hasNext(); ) {
/* 3018 */       String methodName = iterator1.next();
/* 3019 */       List<Method> methods = (List)allMethods.get(methodName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3026 */       boolean isGet = false, isSet = false;
/* 3027 */       Method m = methods.get(0);
/*      */       
/* 3029 */       if (indexMethodCheck(methods) && ((isSet = methodName.startsWith("set")) || (isGet = methodName.startsWith("get"))) && methodName.length() > 3) {
/*      */         
/* 3031 */         String propertyName = Introspector.decapitalize(methodName.substring(3));
/* 3032 */         Class[] parameterTypes = getParameterTypes(m);
/* 3033 */         int parameterCount = parameterTypes.length;
/*      */         
/* 3035 */         if (isGet && parameterCount == 1 && m.getReturnType() != void.class) {
/* 3036 */           List<Method> pair = (List)pairs.get(propertyName);
/*      */           
/* 3038 */           if (pair == null) {
/* 3039 */             pairs.put(propertyName, pair = new ArrayList());
/*      */           }
/* 3041 */           pair.add(m);
/*      */         } 
/* 3043 */         if (isSet && parameterCount == 2 && m.getReturnType() == void.class) {
/* 3044 */           List<Method> pair = (List)pairs.get(propertyName);
/*      */           
/* 3046 */           if (pair == null) {
/* 3047 */             pairs.put(propertyName, pair = new ArrayList());
/*      */           }
/* 3049 */           pair.add(m);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3055 */     for (Iterator<String> it = pairs.keySet().iterator(); it.hasNext(); ) {
/* 3056 */       String propertyName = it.next();
/* 3057 */       List<Method> methods = (List)pairs.get(propertyName);
/*      */       
/* 3059 */       if (methods.size() == 2) {
/* 3060 */         Method method1 = methods.get(0), method2 = methods.get(1), setMethod = ((method1.getParameterTypes()).length == 2) ? method1 : method2;
/* 3061 */         Method getMethod = (setMethod == method1) ? method2 : method1;
/*      */         
/* 3063 */         Class<?> keyType = getMethod.getParameterTypes()[0], propertyType = getMethod.getReturnType();
/*      */         
/* 3065 */         if (keyType == setMethod.getParameterTypes()[0] && 
/* 3066 */           propertyType == setMethod.getParameterTypes()[1]) {
/*      */           ObjectIndexedPropertyDescriptor propertyDescriptor;
/*      */           
/*      */           try {
/* 3070 */             propertyDescriptor = new ObjectIndexedPropertyDescriptor(propertyName, propertyType, getMethod, setMethod);
/*      */           }
/* 3072 */           catch (Exception ex) {
/* 3073 */             throw new OgnlException("creating object indexed property descriptor for '" + propertyName + "' in " + targetClass, ex);
/*      */           } 
/*      */           
/* 3076 */           intoMap.put(propertyName, propertyDescriptor);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map getPropertyDescriptors(Class<?> targetClass) throws IntrospectionException, OgnlException {
/*      */     Map<Object, Object> result;
/* 3098 */     if ((result = (Map)_propertyDescriptorCache.get(targetClass)) == null)
/*      */     {
/* 3100 */       synchronized (_propertyDescriptorCache) {
/* 3101 */         if ((result = (Map)_propertyDescriptorCache.get(targetClass)) == null) {
/*      */           
/* 3103 */           PropertyDescriptor[] pda = Introspector.getBeanInfo(targetClass).getPropertyDescriptors();
/*      */           
/* 3105 */           result = new HashMap<>(101);
/* 3106 */           for (int i = 0, icount = pda.length; i < icount; i++) {
/*      */ 
/*      */             
/* 3109 */             if (pda[i].getReadMethod() != null && !isMethodCallable(pda[i].getReadMethod()))
/*      */             {
/* 3111 */               pda[i].setReadMethod(findClosestMatchingMethod(targetClass, pda[i].getReadMethod(), pda[i].getName(), pda[i].getPropertyType(), true));
/*      */             }
/*      */             
/* 3114 */             if (pda[i].getWriteMethod() != null && !isMethodCallable(pda[i].getWriteMethod()))
/*      */             {
/* 3116 */               pda[i].setWriteMethod(findClosestMatchingMethod(targetClass, pda[i].getWriteMethod(), pda[i].getName(), pda[i].getPropertyType(), false));
/*      */             }
/*      */ 
/*      */             
/* 3120 */             result.put(pda[i].getName(), pda[i]);
/*      */           } 
/*      */           
/* 3123 */           findObjectIndexedPropertyDescriptors(targetClass, result);
/* 3124 */           _propertyDescriptorCache.put(targetClass, result);
/*      */         } 
/*      */       } 
/*      */     }
/* 3128 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor getPropertyDescriptor(Class targetClass, String propertyName) throws IntrospectionException, OgnlException {
/* 3144 */     if (targetClass == null) {
/* 3145 */       return null;
/*      */     }
/* 3147 */     return (PropertyDescriptor)getPropertyDescriptors(targetClass).get(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Method findClosestMatchingMethod(Class targetClass, Method m, String propertyName, Class<?> propertyType, boolean isReadMethod) {
/* 3153 */     List methods = getDeclaredMethods(targetClass, propertyName, !isReadMethod);
/*      */     
/* 3155 */     if (methods != null)
/*      */     {
/* 3157 */       for (Object method1 : methods) {
/*      */         
/* 3159 */         Method method = (Method)method1;
/*      */         
/* 3161 */         if (method.getName().equals(m.getName()) && m.getReturnType().isAssignableFrom(m.getReturnType()) && method.getReturnType() == propertyType && (method.getParameterTypes()).length == (m.getParameterTypes()).length)
/*      */         {
/*      */ 
/*      */           
/* 3165 */           return method;
/*      */         }
/*      */       } 
/*      */     }
/* 3169 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor[] getPropertyDescriptorsArray(Class<?> targetClass) throws IntrospectionException {
/* 3175 */     PropertyDescriptor[] result = null;
/*      */     
/* 3177 */     if (targetClass != null && (
/* 3178 */       result = (PropertyDescriptor[])_propertyDescriptorCache.get(targetClass)) == null) {
/* 3179 */       synchronized (_propertyDescriptorCache) {
/* 3180 */         if ((result = (PropertyDescriptor[])_propertyDescriptorCache.get(targetClass)) == null) {
/* 3181 */           _propertyDescriptorCache.put(targetClass, result = Introspector.getBeanInfo(targetClass).getPropertyDescriptors());
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3187 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor getPropertyDescriptorFromArray(Class targetClass, String name) throws IntrospectionException {
/* 3202 */     PropertyDescriptor result = null;
/* 3203 */     PropertyDescriptor[] pda = getPropertyDescriptorsArray(targetClass);
/*      */     
/* 3205 */     for (int i = 0, icount = pda.length; result == null && i < icount; i++) {
/* 3206 */       if (pda[i].getName().compareTo(name) == 0) {
/* 3207 */         result = pda[i];
/*      */       }
/*      */     } 
/* 3210 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setMethodAccessor(Class cls, MethodAccessor accessor) {
/* 3215 */     synchronized (_methodAccessors) {
/* 3216 */       _methodAccessors.put(cls, accessor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static MethodAccessor getMethodAccessor(Class cls) throws OgnlException {
/* 3223 */     MethodAccessor answer = (MethodAccessor)getHandler(cls, _methodAccessors);
/* 3224 */     if (answer != null)
/* 3225 */       return answer; 
/* 3226 */     throw new OgnlException("No method accessor for " + cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setPropertyAccessor(Class cls, PropertyAccessor accessor) {
/* 3231 */     synchronized (_propertyAccessors) {
/* 3232 */       _propertyAccessors.put(cls, accessor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static PropertyAccessor getPropertyAccessor(Class cls) throws OgnlException {
/* 3239 */     PropertyAccessor answer = (PropertyAccessor)getHandler(cls, _propertyAccessors);
/* 3240 */     if (answer != null) {
/* 3241 */       return answer;
/*      */     }
/* 3243 */     throw new OgnlException("No property accessor for class " + cls);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static ElementsAccessor getElementsAccessor(Class cls) throws OgnlException {
/* 3249 */     ElementsAccessor answer = (ElementsAccessor)getHandler(cls, _elementsAccessors);
/* 3250 */     if (answer != null)
/* 3251 */       return answer; 
/* 3252 */     throw new OgnlException("No elements accessor for class " + cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setElementsAccessor(Class cls, ElementsAccessor accessor) {
/* 3257 */     synchronized (_elementsAccessors) {
/* 3258 */       _elementsAccessors.put(cls, accessor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static NullHandler getNullHandler(Class cls) throws OgnlException {
/* 3265 */     NullHandler answer = (NullHandler)getHandler(cls, _nullHandlers);
/* 3266 */     if (answer != null)
/* 3267 */       return answer; 
/* 3268 */     throw new OgnlException("No null handler for class " + cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void setNullHandler(Class cls, NullHandler handler) {
/* 3273 */     synchronized (_nullHandlers) {
/* 3274 */       _nullHandlers.put(cls, handler);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static Object getHandler(Class forClass, ClassCache handlers) {
/* 3280 */     Object answer = null;
/*      */     
/* 3282 */     if ((answer = handlers.get(forClass)) == null) {
/* 3283 */       synchronized (handlers) {
/* 3284 */         if ((answer = handlers.get(forClass)) == null) {
/*      */           Class keyFound;
/*      */           
/* 3287 */           if (forClass.isArray()) {
/* 3288 */             answer = handlers.get(Object[].class);
/* 3289 */             keyFound = null;
/*      */           } else {
/* 3291 */             keyFound = forClass;
/*      */             
/* 3293 */             for (Class c = forClass; c != null; c = c.getSuperclass()) {
/* 3294 */               answer = handlers.get(c);
/* 3295 */               if (answer == null) {
/* 3296 */                 Class[] interfaces = c.getInterfaces();
/* 3297 */                 for (int index = 0, count = interfaces.length; index < count; index++) {
/* 3298 */                   Class iface = interfaces[index];
/*      */                   
/* 3300 */                   answer = handlers.get(iface);
/* 3301 */                   if (answer == null)
/*      */                   {
/* 3303 */                     answer = getHandler(iface, handlers);
/*      */                   }
/* 3305 */                   if (answer != null) {
/* 3306 */                     keyFound = iface;
/*      */                     // Byte code: goto -> 163
/*      */                   } 
/*      */                 } 
/*      */               } else {
/* 3311 */                 keyFound = c;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/* 3316 */           if (answer != null && 
/* 3317 */             keyFound != forClass) {
/* 3318 */             handlers.put(forClass, answer);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 3324 */     return answer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getProperty(OgnlContext context, Object source, Object name) throws OgnlException {
/* 3332 */     if (source == null)
/*      */     {
/* 3334 */       throw new OgnlException("source is null for getProperty(null, \"" + name + "\")"); } 
/*      */     PropertyAccessor accessor;
/* 3336 */     if ((accessor = getPropertyAccessor(getTargetClass(source))) == null)
/*      */     {
/* 3338 */       throw new OgnlException("No property accessor for " + getTargetClass(source).getName());
/*      */     }
/*      */     
/* 3341 */     return accessor.getProperty(context, source, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setProperty(OgnlContext context, Object target, Object name, Object value) throws OgnlException {
/* 3349 */     if (target == null)
/* 3350 */       throw new OgnlException("target is null for setProperty(null, \"" + name + "\", " + value + ")"); 
/*      */     PropertyAccessor accessor;
/* 3352 */     if ((accessor = getPropertyAccessor(getTargetClass(target))) == null) {
/* 3353 */       throw new OgnlException("No property accessor for " + getTargetClass(target).getName());
/*      */     }
/*      */     
/* 3356 */     accessor.setProperty(context, target, name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getIndexedPropertyType(OgnlContext context, Class sourceClass, String name) throws OgnlException {
/* 3375 */     int result = INDEXED_PROPERTY_NONE;
/*      */     
/*      */     try {
/* 3378 */       PropertyDescriptor pd = getPropertyDescriptor(sourceClass, name);
/* 3379 */       if (pd != null) {
/* 3380 */         if (pd instanceof IndexedPropertyDescriptor) {
/* 3381 */           result = INDEXED_PROPERTY_INT;
/*      */         }
/* 3383 */         else if (pd instanceof ObjectIndexedPropertyDescriptor) {
/* 3384 */           result = INDEXED_PROPERTY_OBJECT;
/*      */         }
/*      */       
/*      */       }
/* 3388 */     } catch (Exception ex) {
/* 3389 */       throw new OgnlException("problem determining if '" + name + "' is an indexed property", ex);
/*      */     } 
/* 3391 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getIndexedProperty(OgnlContext context, Object source, String name, Object index) throws OgnlException {
/* 3397 */     Object[] args = _objectArrayPool.create(index);
/*      */     try {
/*      */       Method m;
/* 3400 */       PropertyDescriptor pd = getPropertyDescriptor((source == null) ? null : source.getClass(), name);
/*      */ 
/*      */       
/* 3403 */       if (pd instanceof IndexedPropertyDescriptor) {
/* 3404 */         m = ((IndexedPropertyDescriptor)pd).getIndexedReadMethod();
/*      */       }
/* 3406 */       else if (pd instanceof ObjectIndexedPropertyDescriptor) {
/* 3407 */         m = ((ObjectIndexedPropertyDescriptor)pd).getIndexedReadMethod();
/*      */       } else {
/* 3409 */         throw new OgnlException("property '" + name + "' is not an indexed property");
/*      */       } 
/*      */ 
/*      */       
/* 3413 */       return callMethod(context, source, m.getName(), args);
/*      */     }
/* 3415 */     catch (OgnlException ex) {
/* 3416 */       throw ex;
/* 3417 */     } catch (Exception ex) {
/* 3418 */       throw new OgnlException("getting indexed property descriptor for '" + name + "'", ex);
/*      */     } finally {
/* 3420 */       _objectArrayPool.recycle(args);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setIndexedProperty(OgnlContext context, Object source, String name, Object index, Object value) throws OgnlException {
/* 3428 */     Object[] args = _objectArrayPool.create(index, value);
/*      */     try {
/*      */       Method m;
/* 3431 */       PropertyDescriptor pd = getPropertyDescriptor((source == null) ? null : source.getClass(), name);
/*      */ 
/*      */       
/* 3434 */       if (pd instanceof IndexedPropertyDescriptor) {
/* 3435 */         m = ((IndexedPropertyDescriptor)pd).getIndexedWriteMethod();
/*      */       }
/* 3437 */       else if (pd instanceof ObjectIndexedPropertyDescriptor) {
/* 3438 */         m = ((ObjectIndexedPropertyDescriptor)pd).getIndexedWriteMethod();
/*      */       } else {
/* 3440 */         throw new OgnlException("property '" + name + "' is not an indexed property");
/*      */       } 
/*      */ 
/*      */       
/* 3444 */       callMethod(context, source, m.getName(), args);
/*      */     }
/* 3446 */     catch (OgnlException ex) {
/* 3447 */       throw ex;
/* 3448 */     } catch (Exception ex) {
/* 3449 */       throw new OgnlException("getting indexed property descriptor for '" + name + "'", ex);
/*      */     } finally {
/* 3451 */       _objectArrayPool.recycle(args);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static EvaluationPool getEvaluationPool() {
/* 3457 */     return _evaluationPool;
/*      */   }
/*      */ 
/*      */   
/*      */   public static ObjectArrayPool getObjectArrayPool() {
/* 3462 */     return _objectArrayPool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClassCacheInspector(ClassCacheInspector inspector) {
/* 3474 */     _cacheInspector = inspector;
/*      */     
/* 3476 */     _propertyDescriptorCache.setClassInspector(_cacheInspector);
/* 3477 */     _constructorCache.setClassInspector(_cacheInspector);
/* 3478 */     _staticMethodCache.setClassInspector(_cacheInspector);
/* 3479 */     _instanceMethodCache.setClassInspector(_cacheInspector);
/* 3480 */     _invokePermissionCache.setClassInspector(_cacheInspector);
/* 3481 */     _fieldCache.setClassInspector(_cacheInspector);
/* 3482 */     _declaredMethods[0].setClassInspector(_cacheInspector);
/* 3483 */     _declaredMethods[1].setClassInspector(_cacheInspector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getMethod(OgnlContext context, Class target, String name, Node[] children, boolean includeStatic) throws Exception {
/*      */     Class[] parms;
/* 3491 */     if (children != null && children.length > 0) {
/*      */       
/* 3493 */       parms = new Class[children.length];
/*      */ 
/*      */       
/* 3496 */       Class currType = context.getCurrentType();
/* 3497 */       Class currAccessor = context.getCurrentAccessor();
/* 3498 */       Object cast = context.get("_preCast");
/*      */       
/* 3500 */       context.setCurrentObject(context.getRoot());
/* 3501 */       context.setCurrentType((context.getRoot() != null) ? context.getRoot().getClass() : null);
/* 3502 */       context.setCurrentAccessor(null);
/* 3503 */       context.setPreviousType(null);
/*      */       
/* 3505 */       for (int j = 0; j < children.length; j++) {
/*      */         
/* 3507 */         children[j].toGetSourceString(context, context.getRoot());
/* 3508 */         parms[j] = context.getCurrentType();
/*      */       } 
/*      */       
/* 3511 */       context.put("_preCast", cast);
/*      */       
/* 3513 */       context.setCurrentType(currType);
/* 3514 */       context.setCurrentAccessor(currAccessor);
/* 3515 */       context.setCurrentObject(target);
/*      */     } else {
/*      */       
/* 3518 */       parms = EMPTY_CLASS_ARRAY;
/*      */     } 
/*      */     
/* 3521 */     List<Method> methods = getMethods(target, name, includeStatic);
/* 3522 */     if (methods == null) {
/* 3523 */       return null;
/*      */     }
/* 3525 */     for (int i = 0; i < methods.size(); i++) {
/*      */       
/* 3527 */       Method m = methods.get(i);
/* 3528 */       boolean varArgs = (isJdk15() && m.isVarArgs());
/*      */       
/* 3530 */       if (parms.length == (m.getParameterTypes()).length || varArgs) {
/*      */ 
/*      */         
/* 3533 */         Class[] mparms = m.getParameterTypes();
/* 3534 */         boolean matched = true;
/* 3535 */         for (int p = 0; p < mparms.length; p++) {
/*      */           
/* 3537 */           if (!varArgs || !mparms[p].isArray()) {
/*      */ 
/*      */ 
/*      */             
/* 3541 */             if (parms[p] == null) {
/*      */               
/* 3543 */               matched = false;
/*      */               
/*      */               break;
/*      */             } 
/* 3547 */             if (parms[p] != mparms[p])
/*      */             {
/*      */               
/* 3550 */               if (!mparms[p].isPrimitive() || char.class == mparms[p] || byte.class == mparms[p] || !Number.class.isAssignableFrom(parms[p]) || getPrimitiveWrapperClass(parms[p]) != mparms[p]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 3558 */                 matched = false; break;
/*      */               }  } 
/*      */           } 
/*      */         } 
/* 3562 */         if (matched)
/* 3563 */           return m; 
/*      */       } 
/*      */     } 
/* 3566 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getReadMethod(Class target, String name) {
/* 3585 */     return getReadMethod(target, name, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Method getReadMethod(Class target, String name, Class[] argClasses) {
/*      */     try {
/* 3591 */       if (name.indexOf('"') >= 0) {
/* 3592 */         name = name.replaceAll("\"", "");
/*      */       }
/* 3594 */       name = name.toLowerCase();
/*      */       
/* 3596 */       Method[] methods = target.getMethods();
/*      */ 
/*      */       
/* 3599 */       ArrayList<Method> candidates = new ArrayList<>();
/*      */       int i;
/* 3601 */       for (i = 0; i < methods.length; i++) {
/*      */         
/* 3603 */         if (isMethodCallable(methods[i]))
/*      */         {
/*      */           
/* 3606 */           if ((methods[i].getName().equalsIgnoreCase(name) || methods[i].getName().toLowerCase().equals("get" + name) || methods[i].getName().toLowerCase().equals("has" + name) || methods[i].getName().toLowerCase().equals("is" + name)) && !methods[i].getName().startsWith("set"))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3612 */             candidates.add(methods[i]); } 
/*      */         }
/*      */       } 
/* 3615 */       if (!candidates.isEmpty()) {
/* 3616 */         MatchingMethod mm = findBestMethod(candidates, target, name, argClasses);
/* 3617 */         if (mm != null) {
/* 3618 */           return mm.mMethod;
/*      */         }
/*      */       } 
/* 3621 */       for (i = 0; i < methods.length; i++) {
/*      */         
/* 3623 */         if (isMethodCallable(methods[i]))
/*      */         {
/*      */           
/* 3626 */           if (methods[i].getName().equalsIgnoreCase(name) && !methods[i].getName().startsWith("set") && !methods[i].getName().startsWith("get") && !methods[i].getName().startsWith("is") && !methods[i].getName().startsWith("has") && methods[i].getReturnType() != void.class) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3633 */             Method m = methods[i];
/* 3634 */             if (!candidates.contains(m))
/* 3635 */               candidates.add(m); 
/*      */           } 
/*      */         }
/*      */       } 
/* 3639 */       if (!candidates.isEmpty()) {
/* 3640 */         MatchingMethod mm = findBestMethod(candidates, target, name, argClasses);
/* 3641 */         if (mm != null) {
/* 3642 */           return mm.mMethod;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3647 */       if (!name.startsWith("get")) {
/* 3648 */         Method ret = getReadMethod(target, "get" + name, argClasses);
/* 3649 */         if (ret != null) {
/* 3650 */           return ret;
/*      */         }
/*      */       } 
/* 3653 */       if (!candidates.isEmpty()) {
/*      */ 
/*      */         
/* 3656 */         int reqArgCount = (argClasses == null) ? 0 : argClasses.length;
/* 3657 */         for (Method m : candidates) {
/* 3658 */           if ((m.getParameterTypes()).length == reqArgCount) {
/* 3659 */             return m;
/*      */           }
/*      */         } 
/*      */       } 
/* 3663 */     } catch (Throwable t) {
/*      */       
/* 3665 */       throw OgnlOps.castToRuntime(t);
/*      */     } 
/*      */     
/* 3668 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Method getWriteMethod(Class target, String name) {
/* 3673 */     return getWriteMethod(target, name, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Method getWriteMethod(Class<?> target, String name, Class[] argClasses) {
/*      */     try {
/* 3679 */       if (name.indexOf('"') >= 0) {
/* 3680 */         name = name.replaceAll("\"", "");
/*      */       }
/* 3682 */       BeanInfo info = Introspector.getBeanInfo(target);
/* 3683 */       MethodDescriptor[] methods = info.getMethodDescriptors();
/*      */       
/* 3685 */       ArrayList<Method> candidates = new ArrayList<>();
/*      */       
/* 3687 */       for (int i = 0; i < methods.length; i++) {
/* 3688 */         if (isMethodCallable(methods[i].getMethod()))
/*      */         {
/*      */           
/* 3691 */           if ((methods[i].getName().equalsIgnoreCase(name) || methods[i].getName().toLowerCase().equals(name.toLowerCase()) || methods[i].getName().toLowerCase().equals("set" + name.toLowerCase())) && !methods[i].getName().startsWith("get"))
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 3696 */             candidates.add(methods[i].getMethod());
/*      */           }
/*      */         }
/*      */       } 
/* 3700 */       if (!candidates.isEmpty()) {
/* 3701 */         MatchingMethod mm = findBestMethod(candidates, target, name, argClasses);
/* 3702 */         if (mm != null) {
/* 3703 */           return mm.mMethod;
/*      */         }
/*      */       } 
/*      */       
/* 3707 */       Method[] cmethods = target.getClass().getMethods();
/* 3708 */       for (int j = 0; j < cmethods.length; j++) {
/* 3709 */         if (isMethodCallable(cmethods[j]))
/*      */         {
/*      */           
/* 3712 */           if ((cmethods[j].getName().equalsIgnoreCase(name) || cmethods[j].getName().toLowerCase().equals(name.toLowerCase()) || cmethods[j].getName().toLowerCase().equals("set" + name.toLowerCase())) && !cmethods[j].getName().startsWith("get")) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3717 */             Method m = methods[j].getMethod();
/* 3718 */             if (!candidates.contains(m))
/* 3719 */               candidates.add(m); 
/*      */           } 
/*      */         }
/*      */       } 
/* 3723 */       if (!candidates.isEmpty()) {
/* 3724 */         MatchingMethod mm = findBestMethod(candidates, target, name, argClasses);
/* 3725 */         if (mm != null) {
/* 3726 */           return mm.mMethod;
/*      */         }
/*      */       } 
/*      */       
/* 3730 */       if (!name.startsWith("set")) {
/* 3731 */         Method ret = getReadMethod(target, "set" + name, argClasses);
/* 3732 */         if (ret != null) {
/* 3733 */           return ret;
/*      */         }
/*      */       } 
/* 3736 */       if (!candidates.isEmpty()) {
/*      */ 
/*      */         
/* 3739 */         int reqArgCount = (argClasses == null) ? 0 : argClasses.length;
/* 3740 */         for (Method m : candidates) {
/* 3741 */           if ((m.getParameterTypes()).length == reqArgCount) {
/* 3742 */             return m;
/*      */           }
/*      */         } 
/* 3745 */         if (argClasses == null && candidates.size() == 1)
/*      */         {
/* 3747 */           return candidates.get(0);
/*      */         }
/*      */       } 
/* 3750 */     } catch (Throwable t) {
/*      */       
/* 3752 */       throw OgnlOps.castToRuntime(t);
/*      */     } 
/*      */     
/* 3755 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static PropertyDescriptor getProperty(Class<?> target, String name) {
/*      */     try {
/* 3761 */       BeanInfo info = Introspector.getBeanInfo(target);
/*      */       
/* 3763 */       PropertyDescriptor[] pds = info.getPropertyDescriptors();
/*      */       
/* 3765 */       for (int i = 0; i < pds.length; i++) {
/*      */         
/* 3767 */         if (pds[i].getName().equalsIgnoreCase(name) || pds[i].getName().toLowerCase().equals(name.toLowerCase()) || pds[i].getName().toLowerCase().endsWith(name.toLowerCase()))
/*      */         {
/*      */           
/* 3770 */           return pds[i];
/*      */         }
/*      */       } 
/* 3773 */     } catch (Throwable t) {
/*      */       
/* 3775 */       throw OgnlOps.castToRuntime(t);
/*      */     } 
/*      */     
/* 3778 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isBoolean(String expression) {
/* 3783 */     if (expression == null) {
/* 3784 */       return false;
/*      */     }
/* 3786 */     if ("true".equals(expression) || "false".equals(expression) || "!true".equals(expression) || "!false".equals(expression) || "(true)".equals(expression) || "!(true)".equals(expression) || "(false)".equals(expression) || "!(false)".equals(expression) || expression.startsWith("ognl.OgnlOps"))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3793 */       return true;
/*      */     }
/* 3795 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean shouldConvertNumericTypes(OgnlContext context) {
/* 3811 */     if (context.getCurrentType() == null || context.getPreviousType() == null) {
/* 3812 */       return true;
/*      */     }
/* 3814 */     if (context.getCurrentType() == context.getPreviousType() && context.getCurrentType().isPrimitive() && context.getPreviousType().isPrimitive())
/*      */     {
/* 3816 */       return false;
/*      */     }
/* 3818 */     return (context.getCurrentType() != null && !context.getCurrentType().isArray() && context.getPreviousType() != null && !context.getPreviousType().isArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getChildSource(OgnlContext context, Object target, Node child) throws OgnlException {
/* 3836 */     return getChildSource(context, target, child, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getChildSource(OgnlContext context, Object target, Node child, boolean forceConversion) throws OgnlException {
/* 3854 */     String pre = (String)context.get("_currentChain");
/* 3855 */     if (pre == null) {
/* 3856 */       pre = "";
/*      */     }
/*      */     
/*      */     try {
/* 3860 */       child.getValue(context, target);
/* 3861 */     } catch (NullPointerException nullPointerException) {
/*      */ 
/*      */     
/* 3864 */     } catch (ArithmeticException e) {
/*      */       
/* 3866 */       context.setCurrentType(int.class);
/* 3867 */       return "0";
/* 3868 */     } catch (Throwable t) {
/*      */       
/* 3870 */       throw OgnlOps.castToRuntime(t);
/*      */     } 
/*      */     
/* 3873 */     String source = null;
/*      */ 
/*      */     
/*      */     try {
/* 3877 */       source = child.toGetSourceString(context, target);
/*      */     }
/* 3879 */     catch (Throwable t) {
/*      */       
/* 3881 */       throw OgnlOps.castToRuntime(t);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3886 */     if (!ASTConst.class.isInstance(child) && (target == null || context.getRoot() != target))
/*      */     {
/*      */       
/* 3889 */       source = pre + source;
/*      */     }
/*      */     
/* 3892 */     if (context.getRoot() != null) {
/*      */       
/* 3894 */       source = ExpressionCompiler.getRootExpression(child, context.getRoot(), context) + source;
/* 3895 */       context.setCurrentAccessor(context.getRoot().getClass());
/*      */     } 
/*      */     
/* 3898 */     if (ASTChain.class.isInstance(child)) {
/*      */       
/* 3900 */       String cast = (String)context.remove("_preCast");
/* 3901 */       if (cast == null) {
/* 3902 */         cast = "";
/*      */       }
/* 3904 */       source = cast + source;
/*      */     } 
/*      */     
/* 3907 */     if (source == null || source.trim().length() < 1) {
/* 3908 */       source = "null";
/*      */     }
/* 3910 */     return source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ClassPropertyMethodCache
/*      */   {
/*      */     private static final Method NULL_REPLACEMENT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3935 */     private final ConcurrentHashMap<Class<?>, ConcurrentHashMap<String, Method>> cache = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/*      */       try {
/* 3942 */         NULL_REPLACEMENT = ClassPropertyMethodCache.class.getDeclaredMethod("get", new Class[] { Class.class, String.class });
/*      */       }
/* 3944 */       catch (NoSuchMethodException e) {
/*      */         
/* 3946 */         throw new RuntimeException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Method get(Class<?> clazz, String propertyName) {
/* 3957 */       ConcurrentHashMap<String, Method> methodsByPropertyName = this.cache.get(clazz);
/* 3958 */       if (methodsByPropertyName == null) {
/*      */         
/* 3960 */         methodsByPropertyName = new ConcurrentHashMap<>();
/* 3961 */         this.cache.put(clazz, methodsByPropertyName);
/*      */       } 
/* 3963 */       Method method = methodsByPropertyName.get(propertyName);
/* 3964 */       if (method == NULL_REPLACEMENT)
/* 3965 */         return null; 
/* 3966 */       return method;
/*      */     }
/*      */ 
/*      */     
/*      */     void put(Class<?> clazz, String propertyName, Method method) {
/* 3971 */       ConcurrentHashMap<String, Method> methodsByPropertyName = this.cache.get(clazz);
/* 3972 */       if (methodsByPropertyName == null) {
/*      */         
/* 3974 */         methodsByPropertyName = new ConcurrentHashMap<>();
/* 3975 */         this.cache.put(clazz, methodsByPropertyName);
/*      */       } 
/* 3977 */       methodsByPropertyName.put(propertyName, (method == null) ? NULL_REPLACEMENT : method);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean containsKey(Class clazz, String propertyName) {
/* 3982 */       ConcurrentHashMap<String, Method> methodsByPropertyName = this.cache.get(clazz);
/* 3983 */       if (methodsByPropertyName == null) {
/* 3984 */         return false;
/*      */       }
/* 3986 */       return methodsByPropertyName.containsKey(propertyName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 3995 */       this.cache.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int detectMajorJavaVersion() {
/* 4011 */     int majorVersion = -1;
/*      */     try {
/* 4013 */       majorVersion = parseMajorJavaVersion(System.getProperty("java.version"));
/* 4014 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/* 4017 */     if (majorVersion == -1) {
/* 4018 */       majorVersion = 5;
/*      */     }
/*      */     
/* 4021 */     return majorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int parseMajorJavaVersion(String versionString) {
/* 4035 */     int majorVersion = -1;
/*      */     try {
/* 4037 */       if (versionString != null && versionString.length() > 0) {
/* 4038 */         String[] sections = versionString.split("[\\.\\-\\+]");
/*      */ 
/*      */         
/* 4041 */         if (sections.length > 0 && 
/* 4042 */           sections[0].length() > 0) {
/* 4043 */           int firstSection; int secondSection; if (sections.length > 1 && sections[1].length() > 0) {
/* 4044 */             firstSection = Integer.parseInt(sections[0]);
/* 4045 */             if (sections[1].matches("\\d+")) {
/* 4046 */               secondSection = Integer.parseInt(sections[1]);
/*      */             } else {
/* 4048 */               secondSection = -1;
/*      */             } 
/*      */           } else {
/* 4051 */             firstSection = Integer.parseInt(sections[0]);
/* 4052 */             secondSection = -1;
/*      */           } 
/* 4054 */           if (firstSection == 1 && secondSection != -1) {
/* 4055 */             majorVersion = secondSection;
/*      */           } else {
/* 4057 */             majorVersion = firstSection;
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/* 4062 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/* 4065 */     if (majorVersion == -1) {
/* 4066 */       majorVersion = 5;
/*      */     }
/*      */     
/* 4069 */     return majorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getUseJDK9PlusAccessHandlerValue() {
/* 4083 */     return _useJDK9PlusAccessHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getUseStricterInvocationValue() {
/* 4097 */     return _useStricterInvocation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getDisableOgnlSecurityManagerOnInitValue() {
/* 4113 */     return _disableOgnlSecurityManagerOnInit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean usingJDK9PlusAccessHandler() {
/* 4127 */     return (_jdk9Plus && _useJDK9PlusAccessHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getUseFirstMatchGetSetLookupValue() {
/* 4141 */     return _useFirstMatchGetSetLookup;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlRuntime.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */