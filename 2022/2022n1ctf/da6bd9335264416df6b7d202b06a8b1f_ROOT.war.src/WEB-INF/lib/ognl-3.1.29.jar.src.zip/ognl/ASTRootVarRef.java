/*    */ package ognl;
/*    */ 
/*    */ import ognl.enhance.ExpressionCompiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTRootVarRef
/*    */   extends ASTVarRef
/*    */ {
/*    */   public ASTRootVarRef(int id) {
/* 43 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public ASTRootVarRef(OgnlParser p, int id) {
/* 48 */     super(p, id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 54 */     return context.getRoot();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 60 */     context.setRoot(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "#root";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 70 */     if (target != null) {
/* 71 */       this._getterClass = target.getClass();
/*    */     }
/* 73 */     if (this._getterClass != null)
/*    */     {
/* 75 */       context.setCurrentType(this._getterClass);
/*    */     }
/*    */     
/* 78 */     if (this._parent == null || (this._getterClass != null && this._getterClass.isArray())) {
/* 79 */       return "";
/*    */     }
/* 81 */     return ExpressionCompiler.getRootExpression(this, target, context);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 86 */     if (this._parent == null || (this._getterClass != null && this._getterClass.isArray())) {
/* 87 */       return "";
/*    */     }
/* 89 */     return "$3";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTRootVarRef.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */