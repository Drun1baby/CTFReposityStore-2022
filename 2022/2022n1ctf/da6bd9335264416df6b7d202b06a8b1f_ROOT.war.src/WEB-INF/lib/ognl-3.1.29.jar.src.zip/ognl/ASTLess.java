/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTLess
/*    */   extends ComparisonExpression
/*    */ {
/*    */   public ASTLess(int id) {
/* 41 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTLess(OgnlParser p, int id) {
/* 45 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 50 */     Object v1 = this._children[0].getValue(context, source);
/*    */     
/* 52 */     Object v2 = this._children[1].getValue(context, source);
/* 53 */     return OgnlOps.less(v1, v2) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 58 */     return "<";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComparisonFunction() {
/* 63 */     return "ognl.OgnlOps.less";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTLess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */