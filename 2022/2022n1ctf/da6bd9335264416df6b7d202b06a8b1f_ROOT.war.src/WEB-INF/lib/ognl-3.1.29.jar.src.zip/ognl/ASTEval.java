/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTEval
/*     */   extends SimpleNode
/*     */ {
/*     */   public ASTEval(int id) {
/*  44 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTEval(OgnlParser p, int id) {
/*  49 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  55 */     Object result, expr = this._children[0].getValue(context, source), previousRoot = context.getRoot();
/*     */ 
/*     */     
/*  58 */     source = this._children[1].getValue(context, source);
/*  59 */     Node node = (expr instanceof Node) ? (Node)expr : (Node)Ognl.parseExpression(expr.toString());
/*     */     try {
/*  61 */       context.setRoot(source);
/*  62 */       result = node.getValue(context, source);
/*     */     } finally {
/*  64 */       context.setRoot(previousRoot);
/*     */     } 
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/*  72 */     Object expr = this._children[0].getValue(context, target), previousRoot = context.getRoot();
/*     */ 
/*     */     
/*  75 */     target = this._children[1].getValue(context, target);
/*  76 */     Node node = (expr instanceof Node) ? (Node)expr : (Node)Ognl.parseExpression(expr.toString());
/*     */     try {
/*  78 */       context.setRoot(target);
/*  79 */       node.setValue(context, target, value);
/*     */     } finally {
/*  81 */       context.setRoot(previousRoot);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEvalChain(OgnlContext context) throws OgnlException {
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  92 */     return "(" + this._children[0] + ")(" + this._children[1] + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  97 */     throw new UnsupportedCompilationException("Eval expressions not supported as native java yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 102 */     throw new UnsupportedCompilationException("Map expressions not supported as native java yet.");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTEval.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */