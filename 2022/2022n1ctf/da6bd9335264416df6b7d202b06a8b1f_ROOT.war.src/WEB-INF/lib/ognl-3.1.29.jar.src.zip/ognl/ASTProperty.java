/*     */ package ognl;
/*     */ 
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTProperty
/*     */   extends SimpleNode
/*     */   implements NodeType
/*     */ {
/*     */   private boolean _indexedAccess = false;
/*     */   private Class _getterClass;
/*     */   private Class _setterClass;
/*     */   
/*     */   public ASTProperty(int id) {
/*  54 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIndexedAccess(boolean value) {
/*  59 */     this._indexedAccess = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIndexedAccess() {
/*  69 */     return this._indexedAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndexedPropertyType(OgnlContext context, Object source) throws OgnlException {
/*  85 */     Class type = context.getCurrentType();
/*  86 */     Class prevType = context.getPreviousType();
/*     */     
/*     */     try {
/*  89 */       if (!isIndexedAccess()) {
/*     */         
/*  91 */         Object property = getProperty(context, source);
/*     */         
/*  93 */         if (property instanceof String)
/*     */         {
/*  95 */           return OgnlRuntime.getIndexedPropertyType(context, (source == null) ? null : OgnlRuntime.getCompiler().getInterfaceClass(source.getClass()), (String)property);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 101 */       return OgnlRuntime.INDEXED_PROPERTY_NONE;
/*     */     } finally {
/*     */       
/* 104 */       context.setCurrentObject(source);
/* 105 */       context.setCurrentType(type);
/* 106 */       context.setPreviousType(prevType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(OgnlContext context, Object source) throws OgnlException {
/* 113 */     return this._children[0].getValue(context, context.getRoot());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 119 */     Object property = getProperty(context, source);
/*     */     
/* 121 */     Object result = OgnlRuntime.getProperty(context, source, property);
/*     */     
/* 123 */     if (result == null)
/*     */     {
/* 125 */       result = OgnlRuntime.getNullHandler(OgnlRuntime.getTargetClass(source)).nullPropertyValue(context, source, property);
/*     */     }
/*     */     
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 134 */     OgnlRuntime.setProperty(context, target, getProperty(context, target), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeSimpleProperty(OgnlContext context) throws OgnlException {
/* 140 */     return (this._children != null && this._children.length == 1 && ((SimpleNode)this._children[0]).isConstant(context));
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/* 145 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/* 150 */     return this._setterClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     String result;
/* 157 */     if (isIndexedAccess()) {
/*     */       
/* 159 */       result = "[" + this._children[0] + "]";
/*     */     } else {
/*     */       
/* 162 */       result = ((ASTConst)this._children[0]).getValue().toString();
/*     */     } 
/* 164 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 169 */     if (context.getCurrentObject() == null) {
/* 170 */       throw new UnsupportedCompilationException("Current target is null.");
/*     */     }
/* 172 */     String result = "";
/* 173 */     Method m = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 179 */       if (isIndexedAccess()) {
/*     */         
/* 181 */         Object value = this._children[0].getValue(context, context.getRoot());
/*     */         
/* 183 */         if (value == null || DynamicSubscript.class.isAssignableFrom(value.getClass())) {
/* 184 */           throw new UnsupportedCompilationException("Value passed as indexed property was null or not supported.");
/*     */         }
/*     */ 
/*     */         
/* 188 */         String srcString = this._children[0].toGetSourceString(context, context.getRoot());
/* 189 */         srcString = ExpressionCompiler.getRootExpression(this._children[0], context.getRoot(), context) + srcString;
/*     */         
/* 191 */         if (ASTChain.class.isInstance(this._children[0])) {
/*     */           
/* 193 */           String cast = (String)context.remove("_preCast");
/* 194 */           if (cast != null) {
/* 195 */             srcString = cast + srcString;
/*     */           }
/*     */         } 
/* 198 */         if (ASTConst.class.isInstance(this._children[0]) && String.class.isInstance(context.getCurrentObject())) {
/* 199 */           srcString = "\"" + srcString + "\"";
/*     */         }
/*     */ 
/*     */         
/* 203 */         if (context.get("_indexedMethod") != null) {
/*     */           
/* 205 */           m = (Method)context.remove("_indexedMethod");
/* 206 */           this._getterClass = m.getReturnType();
/*     */           
/* 208 */           Object indexedValue = OgnlRuntime.callMethod(context, target, m.getName(), new Object[] { value });
/*     */           
/* 210 */           context.setCurrentType(this._getterClass);
/* 211 */           context.setCurrentObject(indexedValue);
/* 212 */           context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */           
/* 214 */           return "." + m.getName() + "(" + srcString + ")";
/*     */         } 
/*     */         
/* 217 */         PropertyAccessor p = OgnlRuntime.getPropertyAccessor(target.getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 222 */         Object currObj = context.getCurrentObject();
/* 223 */         Class currType = context.getCurrentType();
/* 224 */         Class prevType = context.getPreviousType();
/*     */         
/* 226 */         Object indexVal = p.getProperty(context, target, value);
/*     */ 
/*     */ 
/*     */         
/* 230 */         context.setCurrentObject(currObj);
/* 231 */         context.setCurrentType(currType);
/* 232 */         context.setPreviousType(prevType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 241 */         if (ASTConst.class.isInstance(this._children[0]) && Number.class.isInstance(context.getCurrentObject())) {
/* 242 */           context.setCurrentType(OgnlRuntime.getPrimitiveWrapperClass(context.getCurrentObject().getClass()));
/*     */         }
/* 244 */         result = p.getSourceAccessor(context, target, srcString);
/* 245 */         this._getterClass = context.getCurrentType();
/* 246 */         context.setCurrentObject(indexVal);
/*     */         
/* 248 */         return result;
/*     */       } 
/*     */ 
/*     */       
/* 252 */       String name = ((ASTConst)this._children[0]).getValue().toString();
/*     */       
/* 254 */       if (!Iterator.class.isAssignableFrom(context.getCurrentObject().getClass()) || (Iterator.class.isAssignableFrom(context.getCurrentObject().getClass()) && name.indexOf("next") < 0)) {
/*     */ 
/*     */         
/* 257 */         Object currObj = target;
/*     */ 
/*     */         
/*     */         try {
/* 261 */           target = getValue(context, context.getCurrentObject());
/* 262 */         } catch (NoSuchPropertyException e) {
/*     */           
/*     */           try {
/* 265 */             target = getValue(context, context.getRoot());
/* 266 */           } catch (NoSuchPropertyException noSuchPropertyException) {}
/*     */         
/*     */         }
/*     */         finally {
/*     */           
/* 271 */           context.setCurrentObject(currObj);
/*     */         } 
/*     */       } 
/*     */       
/* 275 */       PropertyDescriptor pd = OgnlRuntime.getPropertyDescriptor(context.getCurrentObject().getClass(), name);
/*     */       
/* 277 */       if (pd != null && pd.getReadMethod() != null && !context.getMemberAccess().isAccessible(context, context.getCurrentObject(), pd.getReadMethod(), name))
/*     */       {
/*     */         
/* 280 */         throw new UnsupportedCompilationException("Member access forbidden for property " + name + " on class " + context.getCurrentObject().getClass());
/*     */       }
/*     */       
/* 283 */       if (getIndexedPropertyType(context, context.getCurrentObject()) > 0 && pd != null)
/*     */       {
/*     */ 
/*     */         
/* 287 */         if (pd instanceof IndexedPropertyDescriptor) {
/*     */           
/* 289 */           m = ((IndexedPropertyDescriptor)pd).getIndexedReadMethod();
/*     */         
/*     */         }
/* 292 */         else if (pd instanceof ObjectIndexedPropertyDescriptor) {
/* 293 */           m = ((ObjectIndexedPropertyDescriptor)pd).getIndexedReadMethod();
/*     */         } else {
/* 295 */           throw new OgnlException("property '" + name + "' is not an indexed property");
/*     */         } 
/*     */         
/* 298 */         if (this._parent == null) {
/*     */ 
/*     */           
/* 301 */           m = OgnlRuntime.getReadMethod(context.getCurrentObject().getClass(), name);
/*     */           
/* 303 */           result = m.getName() + "()";
/* 304 */           this._getterClass = m.getReturnType();
/*     */         } else {
/*     */           
/* 307 */           context.put("_indexedMethod", m);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 316 */         PropertyAccessor pa = OgnlRuntime.getPropertyAccessor(context.getCurrentObject().getClass());
/*     */         
/* 318 */         if (context.getCurrentObject().getClass().isArray()) {
/*     */           
/* 320 */           if (pd == null)
/*     */           {
/* 322 */             pd = OgnlRuntime.getProperty(context.getCurrentObject().getClass(), name);
/*     */             
/* 324 */             if (pd != null && pd.getReadMethod() != null) {
/*     */               
/* 326 */               m = pd.getReadMethod();
/* 327 */               result = pd.getName();
/*     */             } else {
/*     */               
/* 330 */               this._getterClass = int.class;
/* 331 */               context.setCurrentAccessor(context.getCurrentObject().getClass());
/* 332 */               context.setCurrentType(int.class);
/* 333 */               result = "." + name;
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 338 */         } else if (pd != null && pd.getReadMethod() != null) {
/*     */           
/* 340 */           m = pd.getReadMethod();
/* 341 */           result = "." + m.getName() + "()";
/* 342 */         } else if (pa != null) {
/*     */           
/* 344 */           Object currObj = context.getCurrentObject();
/* 345 */           Class currType = context.getCurrentType();
/* 346 */           Class prevType = context.getPreviousType();
/*     */           
/* 348 */           String srcString = this._children[0].toGetSourceString(context, context.getRoot());
/*     */           
/* 350 */           if (ASTConst.class.isInstance(this._children[0]) && String.class.isInstance(context.getCurrentObject()))
/*     */           {
/* 352 */             srcString = "\"" + srcString + "\"";
/*     */           }
/* 354 */           context.setCurrentObject(currObj);
/* 355 */           context.setCurrentType(currType);
/* 356 */           context.setPreviousType(prevType);
/*     */           
/* 358 */           result = pa.getSourceAccessor(context, context.getCurrentObject(), srcString);
/*     */           
/* 360 */           this._getterClass = context.getCurrentType();
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 365 */     } catch (Throwable t) {
/*     */       
/* 367 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 372 */     if (m != null) {
/*     */       
/* 374 */       this._getterClass = m.getReturnType();
/*     */       
/* 376 */       context.setCurrentType(m.getReturnType());
/* 377 */       context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */     } 
/*     */     
/* 380 */     context.setCurrentObject(target);
/*     */     
/* 382 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Method getIndexedWriteMethod(PropertyDescriptor pd) {
/* 387 */     if (IndexedPropertyDescriptor.class.isInstance(pd))
/*     */     {
/* 389 */       return ((IndexedPropertyDescriptor)pd).getIndexedWriteMethod(); } 
/* 390 */     if (ObjectIndexedPropertyDescriptor.class.isInstance(pd))
/*     */     {
/* 392 */       return ((ObjectIndexedPropertyDescriptor)pd).getIndexedWriteMethod();
/*     */     }
/*     */     
/* 395 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 400 */     String result = "";
/* 401 */     Method m = null;
/*     */     
/* 403 */     if (context.getCurrentObject() == null) {
/* 404 */       throw new UnsupportedCompilationException("Current target is null.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 411 */       if (isIndexedAccess()) {
/*     */         
/* 413 */         Object value = this._children[0].getValue(context, context.getRoot());
/*     */         
/* 415 */         if (value == null) {
/* 416 */           throw new UnsupportedCompilationException("Value passed as indexed property is null, can't enhance statement to bytecode.");
/*     */         }
/* 418 */         String srcString = this._children[0].toGetSourceString(context, context.getRoot());
/* 419 */         srcString = ExpressionCompiler.getRootExpression(this._children[0], context.getRoot(), context) + srcString;
/*     */         
/* 421 */         if (ASTChain.class.isInstance(this._children[0])) {
/*     */           
/* 423 */           String cast = (String)context.remove("_preCast");
/* 424 */           if (cast != null) {
/* 425 */             srcString = cast + srcString;
/*     */           }
/*     */         } 
/* 428 */         if (ASTConst.class.isInstance(this._children[0]) && String.class.isInstance(context.getCurrentObject()))
/*     */         {
/* 430 */           srcString = "\"" + srcString + "\"";
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 435 */         if (context.get("_indexedMethod") != null) {
/*     */           
/* 437 */           m = (Method)context.remove("_indexedMethod");
/* 438 */           PropertyDescriptor propertyDescriptor = (PropertyDescriptor)context.remove("_indexedDescriptor");
/*     */           
/* 440 */           boolean lastChild = lastChild(context);
/* 441 */           if (lastChild) {
/*     */             
/* 443 */             m = getIndexedWriteMethod(propertyDescriptor);
/*     */             
/* 445 */             if (m == null) {
/* 446 */               throw new UnsupportedCompilationException("Indexed property has no corresponding write method.");
/*     */             }
/*     */           } 
/* 449 */           this._setterClass = m.getParameterTypes()[0];
/*     */           
/* 451 */           Object indexedValue = null;
/* 452 */           if (!lastChild) {
/* 453 */             indexedValue = OgnlRuntime.callMethod(context, target, m.getName(), new Object[] { value });
/*     */           }
/* 455 */           context.setCurrentType(this._setterClass);
/* 456 */           context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */           
/* 458 */           if (!lastChild) {
/*     */             
/* 460 */             context.setCurrentObject(indexedValue);
/* 461 */             return "." + m.getName() + "(" + srcString + ")";
/*     */           } 
/* 463 */           return "." + m.getName() + "(" + srcString + ", $3)";
/*     */         } 
/*     */ 
/*     */         
/* 467 */         PropertyAccessor p = OgnlRuntime.getPropertyAccessor(target.getClass());
/*     */         
/* 469 */         Object currObj = context.getCurrentObject();
/* 470 */         Class currType = context.getCurrentType();
/* 471 */         Class prevType = context.getPreviousType();
/*     */         
/* 473 */         Object indexVal = p.getProperty(context, target, value);
/*     */ 
/*     */ 
/*     */         
/* 477 */         context.setCurrentObject(currObj);
/* 478 */         context.setCurrentType(currType);
/* 479 */         context.setPreviousType(prevType);
/*     */         
/* 481 */         if (ASTConst.class.isInstance(this._children[0]) && Number.class.isInstance(context.getCurrentObject())) {
/* 482 */           context.setCurrentType(OgnlRuntime.getPrimitiveWrapperClass(context.getCurrentObject().getClass()));
/*     */         }
/* 484 */         result = lastChild(context) ? p.getSourceSetter(context, target, srcString) : p.getSourceAccessor(context, target, srcString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 490 */         this._getterClass = context.getCurrentType();
/* 491 */         context.setCurrentObject(indexVal);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 504 */         return result;
/*     */       } 
/*     */ 
/*     */       
/* 508 */       String name = ((ASTConst)this._children[0]).getValue().toString();
/*     */ 
/*     */ 
/*     */       
/* 512 */       if (!Iterator.class.isAssignableFrom(context.getCurrentObject().getClass()) || (Iterator.class.isAssignableFrom(context.getCurrentObject().getClass()) && name.indexOf("next") < 0)) {
/*     */ 
/*     */         
/* 515 */         Object currObj = target;
/*     */         
/*     */         try {
/* 518 */           target = getValue(context, context.getCurrentObject());
/* 519 */         } catch (NoSuchPropertyException e) {
/*     */           
/*     */           try {
/* 522 */             target = getValue(context, context.getRoot());
/*     */           }
/* 524 */           catch (NoSuchPropertyException noSuchPropertyException) {}
/*     */         } finally {
/*     */           
/* 527 */           context.setCurrentObject(currObj);
/*     */         } 
/*     */       } 
/*     */       
/* 531 */       PropertyDescriptor pd = OgnlRuntime.getPropertyDescriptor(OgnlRuntime.getCompiler().getInterfaceClass(context.getCurrentObject().getClass()), name);
/*     */       
/* 533 */       if (pd != null) {
/*     */         
/* 535 */         Method pdMethod = lastChild(context) ? pd.getWriteMethod() : pd.getReadMethod();
/*     */         
/* 537 */         if (pdMethod != null && !context.getMemberAccess().isAccessible(context, context.getCurrentObject(), pdMethod, name))
/*     */         {
/* 539 */           throw new UnsupportedCompilationException("Member access forbidden for property " + name + " on class " + context.getCurrentObject().getClass());
/*     */         }
/*     */       } 
/*     */       
/* 543 */       if (pd != null && getIndexedPropertyType(context, context.getCurrentObject()) > 0) {
/*     */ 
/*     */ 
/*     */         
/* 547 */         if (pd instanceof IndexedPropertyDescriptor) {
/*     */           
/* 549 */           IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)pd;
/* 550 */           m = lastChild(context) ? ipd.getIndexedWriteMethod() : ipd.getIndexedReadMethod();
/*     */         
/*     */         }
/* 553 */         else if (pd instanceof ObjectIndexedPropertyDescriptor) {
/*     */           
/* 555 */           ObjectIndexedPropertyDescriptor opd = (ObjectIndexedPropertyDescriptor)pd;
/*     */           
/* 557 */           m = lastChild(context) ? opd.getIndexedWriteMethod() : opd.getIndexedReadMethod();
/*     */         } else {
/*     */           
/* 560 */           throw new OgnlException("property '" + name + "' is not an indexed property");
/*     */         } 
/*     */ 
/*     */         
/* 564 */         if (this._parent == null) {
/*     */ 
/*     */ 
/*     */           
/* 568 */           m = OgnlRuntime.getWriteMethod(context.getCurrentObject().getClass(), name);
/* 569 */           Class<?> parm = m.getParameterTypes()[0];
/* 570 */           String cast = parm.isArray() ? ExpressionCompiler.getCastString(parm) : parm.getName();
/*     */           
/* 572 */           result = m.getName() + "((" + cast + ")$3)";
/* 573 */           this._setterClass = parm;
/*     */         } else {
/*     */           
/* 576 */           context.put("_indexedMethod", m);
/* 577 */           context.put("_indexedDescriptor", pd);
/*     */         } 
/*     */       } else {
/*     */         
/* 581 */         PropertyAccessor pa = OgnlRuntime.getPropertyAccessor(context.getCurrentObject().getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 586 */         if (target != null) {
/* 587 */           this._setterClass = target.getClass();
/*     */         }
/* 589 */         if (this._parent != null && pd != null && pa == null) {
/*     */           
/* 591 */           m = pd.getReadMethod();
/* 592 */           result = m.getName() + "()";
/*     */         
/*     */         }
/* 595 */         else if (context.getCurrentObject().getClass().isArray()) {
/*     */           
/* 597 */           result = "";
/* 598 */         } else if (pa != null) {
/*     */           
/* 600 */           Object currObj = context.getCurrentObject();
/*     */ 
/*     */ 
/*     */           
/* 604 */           String srcString = this._children[0].toGetSourceString(context, context.getRoot());
/*     */           
/* 606 */           if (ASTConst.class.isInstance(this._children[0]) && String.class.isInstance(context.getCurrentObject()))
/*     */           {
/* 608 */             srcString = "\"" + srcString + "\"";
/*     */           }
/*     */           
/* 611 */           context.setCurrentObject(currObj);
/*     */ 
/*     */ 
/*     */           
/* 615 */           if (!lastChild(context)) {
/*     */             
/* 617 */             result = pa.getSourceAccessor(context, context.getCurrentObject(), srcString);
/*     */           } else {
/*     */             
/* 620 */             result = pa.getSourceSetter(context, context.getCurrentObject(), srcString);
/*     */           } 
/*     */           
/* 623 */           this._getterClass = context.getCurrentType();
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 628 */     } catch (Throwable t) {
/*     */       
/* 630 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 633 */     context.setCurrentObject(target);
/*     */     
/* 635 */     if (m != null) {
/*     */       
/* 637 */       context.setCurrentType(m.getReturnType());
/* 638 */       context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */     } 
/*     */     
/* 641 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTProperty.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */