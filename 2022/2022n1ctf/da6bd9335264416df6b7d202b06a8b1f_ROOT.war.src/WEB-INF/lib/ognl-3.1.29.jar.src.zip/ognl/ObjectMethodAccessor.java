/*    */ package ognl;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectMethodAccessor
/*    */   implements MethodAccessor
/*    */ {
/*    */   public Object callStaticMethod(Map context, Class targetClass, String methodName, Object[] args) throws MethodFailedException {
/* 50 */     List methods = OgnlRuntime.getMethods(targetClass, methodName, true);
/*    */     
/* 52 */     return OgnlRuntime.callAppropriateMethod((OgnlContext)context, targetClass, null, methodName, null, methods, args);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object callMethod(Map context, Object target, String methodName, Object[] args) throws MethodFailedException {
/* 59 */     Class<?> targetClass = (target == null) ? null : target.getClass();
/* 60 */     List methods = OgnlRuntime.getMethods(targetClass, methodName, false);
/*    */     
/* 62 */     if (methods == null || methods.size() == 0)
/*    */     {
/* 64 */       methods = OgnlRuntime.getMethods(targetClass, methodName, true);
/*    */     }
/*    */ 
/*    */     
/* 68 */     return OgnlRuntime.callAppropriateMethod((OgnlContext)context, target, target, methodName, null, methods, args);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectMethodAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */