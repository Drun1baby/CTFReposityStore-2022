package ognl;

import ognl.enhance.ExpressionAccessor;

public interface Node extends JavaSource {
  void jjtOpen();
  
  void jjtClose();
  
  void jjtSetParent(Node paramNode);
  
  Node jjtGetParent();
  
  void jjtAddChild(Node paramNode, int paramInt);
  
  Node jjtGetChild(int paramInt);
  
  int jjtGetNumChildren();
  
  Object getValue(OgnlContext paramOgnlContext, Object paramObject) throws OgnlException;
  
  void setValue(OgnlContext paramOgnlContext, Object paramObject1, Object paramObject2) throws OgnlException;
  
  ExpressionAccessor getAccessor();
  
  void setAccessor(ExpressionAccessor paramExpressionAccessor);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\Node.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */