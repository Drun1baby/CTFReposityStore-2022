/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayPropertyAccessor
/*     */   extends ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*  49 */     Object result = null;
/*     */     
/*  51 */     if (name instanceof String) {
/*     */       
/*  53 */       if (name.equals("length")) {
/*     */         
/*  55 */         result = new Integer(Array.getLength(target));
/*     */       } else {
/*     */         
/*  58 */         result = super.getProperty(context, target, name);
/*     */       } 
/*     */     } else {
/*     */       
/*  62 */       Object index = name;
/*     */       
/*  64 */       if (index instanceof DynamicSubscript) {
/*     */         
/*  66 */         int len = Array.getLength(target);
/*     */         
/*  68 */         switch (((DynamicSubscript)index).getFlag()) {
/*     */           
/*     */           case 3:
/*  71 */             result = Array.newInstance(target.getClass().getComponentType(), len);
/*  72 */             System.arraycopy(target, 0, result, 0, len);
/*     */             break;
/*     */           case 0:
/*  75 */             index = new Integer((len > 0) ? 0 : -1);
/*     */             break;
/*     */           case 1:
/*  78 */             index = new Integer((len > 0) ? (len / 2) : -1);
/*     */             break;
/*     */           case 2:
/*  81 */             index = new Integer((len > 0) ? (len - 1) : -1);
/*     */             break;
/*     */         } 
/*     */       } 
/*  85 */       if (result == null)
/*     */       {
/*  87 */         if (index instanceof Number) {
/*     */           
/*  89 */           int i = ((Number)index).intValue();
/*     */           
/*  91 */           result = (i >= 0) ? Array.get(target, i) : null;
/*     */         } else {
/*     */           
/*  94 */           throw new NoSuchPropertyException(target, index);
/*     */         } 
/*     */       }
/*     */     } 
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/* 104 */     Object index = name;
/* 105 */     boolean isNumber = index instanceof Number;
/*     */     
/* 107 */     if (isNumber || index instanceof DynamicSubscript) {
/*     */       
/* 109 */       TypeConverter converter = ((OgnlContext)context).getTypeConverter();
/*     */ 
/*     */       
/* 112 */       Object convertedValue = converter.convertValue(context, target, null, name.toString(), value, target.getClass().getComponentType());
/*     */ 
/*     */       
/* 115 */       if (isNumber) {
/*     */         
/* 117 */         int i = ((Number)index).intValue();
/*     */         
/* 119 */         if (i >= 0)
/*     */         {
/* 121 */           Array.set(target, i, convertedValue);
/*     */         }
/*     */       } else {
/*     */         
/* 125 */         int len = Array.getLength(target);
/*     */         
/* 127 */         switch (((DynamicSubscript)index).getFlag()) {
/*     */           
/*     */           case 3:
/* 130 */             System.arraycopy(target, 0, convertedValue, 0, len);
/*     */             return;
/*     */           case 0:
/* 133 */             index = new Integer((len > 0) ? 0 : -1);
/*     */             break;
/*     */           case 1:
/* 136 */             index = new Integer((len > 0) ? (len / 2) : -1);
/*     */             break;
/*     */           case 2:
/* 139 */             index = new Integer((len > 0) ? (len - 1) : -1);
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 144 */     } else if (name instanceof String) {
/*     */       
/* 146 */       super.setProperty(context, target, name, value);
/*     */     } else {
/*     */       
/* 149 */       throw new NoSuchPropertyException(target, index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/* 156 */     String indexStr = index.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     if (context.getCurrentType() != null && !context.getCurrentType().isPrimitive() && Number.class.isAssignableFrom(context.getCurrentType())) {
/*     */ 
/*     */       
/* 165 */       indexStr = indexStr + "." + OgnlRuntime.getNumericValueGetter(context.getCurrentType());
/* 166 */     } else if (context.getCurrentObject() != null && Number.class.isAssignableFrom(context.getCurrentObject().getClass()) && !context.getCurrentType().isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 171 */       String toString = (String.class.isInstance(index) && context.getCurrentType() != Object.class) ? "" : ".toString()";
/*     */       
/* 173 */       indexStr = "ognl.OgnlOps#getIntValue(" + indexStr + toString + ")";
/*     */     } 
/*     */     
/* 176 */     context.setCurrentAccessor(target.getClass());
/* 177 */     context.setCurrentType(target.getClass().getComponentType());
/*     */     
/* 179 */     return "[" + indexStr + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/* 184 */     String indexStr = index.toString();
/*     */ 
/*     */ 
/*     */     
/* 188 */     if (context.getCurrentType() != null && !context.getCurrentType().isPrimitive() && Number.class.isAssignableFrom(context.getCurrentType())) {
/*     */ 
/*     */       
/* 191 */       indexStr = indexStr + "." + OgnlRuntime.getNumericValueGetter(context.getCurrentType());
/* 192 */     } else if (context.getCurrentObject() != null && Number.class.isAssignableFrom(context.getCurrentObject().getClass()) && !context.getCurrentType().isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       String toString = (String.class.isInstance(index) && context.getCurrentType() != Object.class) ? "" : ".toString()";
/*     */       
/* 199 */       indexStr = "ognl.OgnlOps#getIntValue(" + indexStr + toString + ")";
/*     */     } 
/*     */     
/* 202 */     Class<?> type = target.getClass().isArray() ? target.getClass().getComponentType() : target.getClass();
/*     */     
/* 204 */     context.setCurrentAccessor(target.getClass());
/* 205 */     context.setCurrentType(target.getClass().getComponentType());
/*     */     
/* 207 */     if (type.isPrimitive()) {
/*     */       
/* 209 */       Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(type);
/*     */       
/* 211 */       return "[" + indexStr + "]=((" + wrapClass.getName() + ")ognl.OgnlOps.convertValue($3," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass);
/*     */     } 
/*     */ 
/*     */     
/* 215 */     return "[" + indexStr + "]=ognl.OgnlOps.convertValue($3," + type.getName() + ".class)";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ArrayPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */