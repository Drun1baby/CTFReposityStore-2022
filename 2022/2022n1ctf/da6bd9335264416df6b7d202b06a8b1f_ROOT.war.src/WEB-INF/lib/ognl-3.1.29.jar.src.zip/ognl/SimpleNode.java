/*     */ package ognl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import ognl.enhance.ExpressionAccessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleNode
/*     */   implements Node, Serializable
/*     */ {
/*     */   protected Node _parent;
/*     */   protected Node[] _children;
/*     */   protected int _id;
/*     */   protected OgnlParser _parser;
/*     */   private boolean _constantValueCalculated;
/*     */   private volatile boolean _hasConstantValue;
/*     */   private Object _constantValue;
/*     */   private ExpressionAccessor _accessor;
/*     */   
/*     */   public SimpleNode(int i) {
/*  57 */     this._id = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleNode(OgnlParser p, int i) {
/*  62 */     this(i);
/*  63 */     this._parser = p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtOpen() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtClose() {}
/*     */ 
/*     */   
/*     */   public void jjtSetParent(Node n) {
/*  76 */     this._parent = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node jjtGetParent() {
/*  81 */     return this._parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void jjtAddChild(Node n, int i) {
/*  86 */     if (this._children == null) {
/*  87 */       this._children = new Node[i + 1];
/*  88 */     } else if (i >= this._children.length) {
/*  89 */       Node[] c = new Node[i + 1];
/*  90 */       System.arraycopy(this._children, 0, c, 0, this._children.length);
/*  91 */       this._children = c;
/*     */     } 
/*  93 */     this._children[i] = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node jjtGetChild(int i) {
/*  98 */     return this._children[i];
/*     */   }
/*     */ 
/*     */   
/*     */   public int jjtGetNumChildren() {
/* 103 */     return (this._children == null) ? 0 : this._children.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return OgnlParserTreeConstants.jjtNodeName[this._id];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(String prefix) {
/* 121 */     return prefix + OgnlParserTreeConstants.jjtNodeName[this._id] + " " + toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 126 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 131 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(PrintWriter writer, String prefix) {
/* 140 */     writer.println(toString(prefix));
/*     */     
/* 142 */     if (this._children != null)
/*     */     {
/* 144 */       for (int i = 0; i < this._children.length; i++) {
/*     */         
/* 146 */         SimpleNode n = (SimpleNode)this._children[i];
/* 147 */         if (n != null)
/*     */         {
/* 149 */           n.dump(writer, prefix + "  ");
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIndexInParent() {
/* 157 */     int result = -1;
/*     */     
/* 159 */     if (this._parent != null) {
/*     */       
/* 161 */       int icount = this._parent.jjtGetNumChildren();
/*     */       
/* 163 */       for (int i = 0; i < icount; i++) {
/*     */         
/* 165 */         if (this._parent.jjtGetChild(i) == this) {
/*     */           
/* 167 */           result = i;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getNextSibling() {
/* 178 */     Node result = null;
/* 179 */     int i = getIndexInParent();
/*     */     
/* 181 */     if (i >= 0) {
/*     */       
/* 183 */       int icount = this._parent.jjtGetNumChildren();
/*     */       
/* 185 */       if (i < icount)
/*     */       {
/* 187 */         result = this._parent.jjtGetChild(i + 1);
/*     */       }
/*     */     } 
/* 190 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object evaluateGetValueBody(OgnlContext context, Object source) throws OgnlException {
/* 196 */     context.setCurrentObject(source);
/* 197 */     context.setCurrentNode(this);
/*     */     
/* 199 */     if (!this._constantValueCalculated) {
/*     */       
/* 201 */       this._constantValueCalculated = true;
/* 202 */       boolean constant = isConstant(context);
/*     */       
/* 204 */       if (constant)
/*     */       {
/* 206 */         this._constantValue = getValueBody(context, source);
/*     */       }
/*     */       
/* 209 */       this._hasConstantValue = constant;
/*     */     } 
/*     */     
/* 212 */     return this._hasConstantValue ? this._constantValue : getValueBody(context, source);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluateSetValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 218 */     context.setCurrentObject(target);
/* 219 */     context.setCurrentNode(this);
/* 220 */     setValueBody(context, target, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getValue(OgnlContext context, Object source) throws OgnlException {
/* 226 */     Object result = null;
/*     */     
/* 228 */     if (context.getTraceEvaluations()) {
/*     */       
/* 230 */       EvaluationPool pool = OgnlRuntime.getEvaluationPool();
/* 231 */       Throwable evalException = null;
/* 232 */       Evaluation evaluation = pool.create(this, source);
/*     */       
/* 234 */       context.pushEvaluation(evaluation);
/*     */       try {
/* 236 */         result = evaluateGetValueBody(context, source);
/*     */       }
/* 238 */       catch (OgnlException ex) {
/* 239 */         evalException = ex;
/* 240 */         throw ex;
/*     */       }
/* 242 */       catch (RuntimeException ex) {
/* 243 */         evalException = ex;
/* 244 */         throw ex;
/*     */       } finally {
/* 246 */         Evaluation eval = context.popEvaluation();
/*     */         
/* 248 */         eval.setResult(result);
/* 249 */         if (evalException != null) {
/* 250 */           eval.setException(evalException);
/*     */         }
/* 252 */         if (evalException == null && context.getRootEvaluation() == null && !context.getKeepLastEvaluation())
/*     */         {
/* 254 */           pool.recycleAll(eval);
/*     */         }
/*     */       } 
/*     */     } else {
/* 258 */       result = evaluateGetValueBody(context, source);
/*     */     } 
/*     */     
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object getValueBody(OgnlContext paramOgnlContext, Object paramObject) throws OgnlException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValue(OgnlContext context, Object target, Object value) throws OgnlException {
/* 278 */     if (context.getTraceEvaluations()) {
/*     */       
/* 280 */       EvaluationPool pool = OgnlRuntime.getEvaluationPool();
/* 281 */       Throwable evalException = null;
/* 282 */       Evaluation evaluation = pool.create(this, target, true);
/*     */       
/* 284 */       context.pushEvaluation(evaluation);
/*     */       try {
/* 286 */         evaluateSetValueBody(context, target, value);
/*     */       }
/* 288 */       catch (OgnlException ex) {
/* 289 */         evalException = ex;
/* 290 */         ex.setEvaluation(evaluation);
/* 291 */         throw ex;
/*     */       }
/* 293 */       catch (RuntimeException ex) {
/* 294 */         evalException = ex;
/* 295 */         throw ex;
/*     */       } finally {
/* 297 */         Evaluation eval = context.popEvaluation();
/*     */         
/* 299 */         if (evalException != null) {
/* 300 */           eval.setException(evalException);
/*     */         }
/* 302 */         if (evalException == null && context.getRootEvaluation() == null && !context.getKeepLastEvaluation())
/*     */         {
/* 304 */           pool.recycleAll(eval);
/*     */         }
/*     */       } 
/*     */     } else {
/* 308 */       evaluateSetValueBody(context, target, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/* 324 */     throw new InappropriateExpressionException(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeConstant(OgnlContext context) throws OgnlException {
/* 337 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstant(OgnlContext context) throws OgnlException {
/* 343 */     return isNodeConstant(context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeSimpleProperty(OgnlContext context) throws OgnlException {
/* 349 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSimpleProperty(OgnlContext context) throws OgnlException {
/* 355 */     return isNodeSimpleProperty(context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSimpleNavigationChain(OgnlContext context) throws OgnlException {
/* 361 */     return isSimpleProperty(context);
/*     */   }
/*     */   
/*     */   public boolean isEvalChain(OgnlContext context) throws OgnlException {
/* 365 */     if (this._children == null) {
/* 366 */       return false;
/*     */     }
/* 368 */     for (Node child : this._children) {
/* 369 */       if (child instanceof SimpleNode && (
/* 370 */         (SimpleNode)child).isEvalChain(context)) {
/* 371 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 375 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSequence(OgnlContext context) throws OgnlException {
/* 379 */     if (this._children == null) {
/* 380 */       return false;
/*     */     }
/* 382 */     for (Node child : this._children) {
/* 383 */       if (child instanceof SimpleNode && (
/* 384 */         (SimpleNode)child).isSequence(context)) {
/* 385 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 389 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isOperation(OgnlContext context) throws OgnlException {
/* 393 */     if (this._children == null) {
/* 394 */       return false;
/*     */     }
/* 396 */     for (Node child : this._children) {
/* 397 */       if (child instanceof SimpleNode && (
/* 398 */         (SimpleNode)child).isOperation(context)) {
/* 399 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 403 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isChain(OgnlContext context) throws OgnlException {
/* 407 */     if (this._children == null) {
/* 408 */       return false;
/*     */     }
/* 410 */     for (Node child : this._children) {
/* 411 */       if (child instanceof SimpleNode && (
/* 412 */         (SimpleNode)child).isChain(context)) {
/* 413 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 417 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSimpleMethod(OgnlContext context) throws OgnlException {
/* 421 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean lastChild(OgnlContext context) {
/* 426 */     return (this._parent == null || context.get("_lastChild") != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flattenTree() {
/* 435 */     boolean shouldFlatten = false;
/* 436 */     int newSize = 0;
/*     */     
/* 438 */     for (int i = 0; i < this._children.length; i++) {
/* 439 */       if (this._children[i].getClass() == getClass()) {
/*     */         
/* 441 */         shouldFlatten = true;
/* 442 */         newSize += this._children[i].jjtGetNumChildren();
/*     */       } else {
/* 444 */         newSize++;
/*     */       } 
/* 446 */     }  if (shouldFlatten) {
/*     */       
/* 448 */       Node[] newChildren = new Node[newSize];
/* 449 */       int j = 0;
/*     */       
/* 451 */       for (int k = 0; k < this._children.length; k++) {
/*     */         
/* 453 */         Node c = this._children[k];
/* 454 */         if (c.getClass() == getClass()) {
/*     */           
/* 456 */           for (int m = 0; m < c.jjtGetNumChildren(); m++) {
/* 457 */             newChildren[j++] = c.jjtGetChild(m);
/*     */           }
/*     */         } else {
/* 460 */           newChildren[j++] = c;
/*     */         } 
/*     */       } 
/* 463 */       if (j != newSize) {
/* 464 */         throw new Error("Assertion error: " + j + " != " + newSize);
/*     */       }
/* 466 */       this._children = newChildren;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ExpressionAccessor getAccessor() {
/* 472 */     return this._accessor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessor(ExpressionAccessor accessor) {
/* 477 */     this._accessor = accessor;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\SimpleNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */