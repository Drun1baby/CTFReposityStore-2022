/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExpressionNode
/*     */   extends SimpleNode
/*     */ {
/*     */   public ExpressionNode(int i) {
/*  42 */     super(i);
/*     */   }
/*     */   
/*     */   public ExpressionNode(OgnlParser p, int i) {
/*  46 */     super(p, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeConstant(OgnlContext context) throws OgnlException {
/*  53 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstant(OgnlContext context) throws OgnlException {
/*  58 */     boolean result = isNodeConstant(context);
/*     */     
/*  60 */     if (this._children != null && this._children.length > 0) {
/*  61 */       result = true;
/*  62 */       for (int i = 0; result && i < this._children.length; i++) {
/*  63 */         if (this._children[i] instanceof SimpleNode) {
/*  64 */           result = ((SimpleNode)this._children[i]).isConstant(context);
/*     */         } else {
/*  66 */           result = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*  70 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionOperator(int index) {
/*  75 */     throw new RuntimeException("unknown operator for " + OgnlParserTreeConstants.jjtNodeName[this._id]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  80 */     String result = (this._parent == null) ? "" : "(";
/*     */     
/*  82 */     if (this._children != null && this._children.length > 0) {
/*  83 */       for (int i = 0; i < this._children.length; i++) {
/*  84 */         if (i > 0) {
/*  85 */           result = result + " " + getExpressionOperator(i) + " ";
/*     */         }
/*  87 */         result = result + this._children[i].toString();
/*     */       } 
/*     */     }
/*  90 */     if (this._parent != null) {
/*  91 */       result = result + ")";
/*     */     }
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  98 */     String result = (this._parent == null || NumericExpression.class.isAssignableFrom(this._parent.getClass())) ? "" : "(";
/*     */     
/* 100 */     if (this._children != null && this._children.length > 0) {
/* 101 */       for (int i = 0; i < this._children.length; i++) {
/* 102 */         if (i > 0) {
/* 103 */           result = result + " " + getExpressionOperator(i) + " ";
/*     */         }
/*     */         
/* 106 */         String value = this._children[i].toGetSourceString(context, target);
/*     */         
/* 108 */         if ((ASTProperty.class.isInstance(this._children[i]) || ASTMethod.class.isInstance(this._children[i]) || ASTSequence.class.isInstance(this._children[i]) || ASTChain.class.isInstance(this._children[i])) && value != null && value.trim().length() > 0) {
/*     */ 
/*     */ 
/*     */           
/* 112 */           String pre = null;
/* 113 */           if (ASTMethod.class.isInstance(this._children[i]))
/*     */           {
/* 115 */             pre = (String)context.get("_currentChain");
/*     */           }
/*     */           
/* 118 */           if (pre == null) {
/* 119 */             pre = "";
/*     */           }
/* 121 */           String cast = (String)context.remove("_preCast");
/* 122 */           if (cast == null) {
/* 123 */             cast = "";
/*     */           }
/* 125 */           value = cast + ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + pre + value;
/*     */         } 
/*     */         
/* 128 */         result = result + value;
/*     */       } 
/*     */     }
/*     */     
/* 132 */     if (this._parent != null && !NumericExpression.class.isAssignableFrom(this._parent.getClass())) {
/* 133 */       result = result + ")";
/*     */     }
/*     */     
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 141 */     String result = (this._parent == null) ? "" : "(";
/*     */     
/* 143 */     if (this._children != null && this._children.length > 0) {
/* 144 */       for (int i = 0; i < this._children.length; i++) {
/* 145 */         if (i > 0) {
/* 146 */           result = result + " " + getExpressionOperator(i) + " ";
/*     */         }
/*     */         
/* 149 */         result = result + this._children[i].toSetSourceString(context, target);
/*     */       } 
/*     */     }
/* 152 */     if (this._parent != null) {
/* 153 */       result = result + ")";
/*     */     }
/*     */     
/* 156 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOperation(OgnlContext context) throws OgnlException {
/* 161 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ExpressionNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */