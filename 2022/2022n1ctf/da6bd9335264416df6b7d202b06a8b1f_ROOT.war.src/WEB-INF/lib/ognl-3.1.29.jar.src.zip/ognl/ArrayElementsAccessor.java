/*    */ package ognl;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(final Object target) {
/* 45 */     return new Enumeration() {
/* 46 */         private int count = Array.getLength(target);
/* 47 */         private int index = 0;
/*    */ 
/*    */         
/*    */         public boolean hasMoreElements() {
/* 51 */           return (this.index < this.count);
/*    */         }
/*    */ 
/*    */         
/*    */         public Object nextElement() {
/* 56 */           return Array.get(target, this.index++);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ArrayElementsAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */