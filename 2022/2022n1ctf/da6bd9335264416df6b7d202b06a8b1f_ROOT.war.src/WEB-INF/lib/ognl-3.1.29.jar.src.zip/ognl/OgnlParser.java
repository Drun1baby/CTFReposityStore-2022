/*      */ package ognl;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ 
/*      */ public class OgnlParser implements OgnlParserTreeConstants, OgnlParserConstants {
/*    9 */   protected JJTOgnlParserState jjtree = new JJTOgnlParserState(); public OgnlParserTokenManager token_source; JavaCharStream jj_input_stream;
/*      */   public Token token;
/*      */   public Token jj_nt;
/*      */   private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   
/*      */   public final Node topLevelExpression() throws ParseException {
/*   18 */     expression();
/*   19 */     jj_consume_token(0);
/*   20 */     return this.jjtree.rootNode();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void expression() throws ParseException {
/*   26 */     assignmentExpression();
/*      */     
/*      */     while (true) {
/*   29 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 1:
/*      */           break;
/*      */         
/*      */         default:
/*   34 */           this.jj_la1[0] = this.jj_gen;
/*      */           break;
/*      */       } 
/*   37 */       jj_consume_token(1);
/*   38 */       ASTSequence jjtn001 = new ASTSequence(1);
/*   39 */       boolean jjtc001 = true;
/*   40 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*   42 */         assignmentExpression();
/*   43 */       } catch (Throwable jjte001) {
/*   44 */         if (jjtc001) {
/*   45 */           this.jjtree.clearNodeScope(jjtn001);
/*   46 */           jjtc001 = false;
/*      */         } else {
/*   48 */           this.jjtree.popNode();
/*      */         } 
/*   50 */         if (jjte001 instanceof RuntimeException) {
/*   51 */           throw (RuntimeException)jjte001;
/*      */         }
/*   53 */         if (jjte001 instanceof ParseException) {
/*   54 */           throw (ParseException)jjte001;
/*      */         }
/*   56 */         throw (Error)jjte001;
/*      */       } finally {
/*   58 */         if (jjtc001)
/*   59 */           this.jjtree.closeNodeScope(jjtn001, 2); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void assignmentExpression() throws ParseException {
/*      */     ASTAssign jjtn001;
/*      */     boolean jjtc001;
/*   67 */     conditionalTestExpression();
/*   68 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 2:
/*   70 */         jj_consume_token(2);
/*   71 */         jjtn001 = new ASTAssign(2);
/*   72 */         jjtc001 = true;
/*   73 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/*   75 */           assignmentExpression();
/*   76 */         } catch (Throwable jjte001) {
/*   77 */           if (jjtc001) {
/*   78 */             this.jjtree.clearNodeScope(jjtn001);
/*   79 */             jjtc001 = false;
/*      */           } else {
/*   81 */             this.jjtree.popNode();
/*      */           } 
/*   83 */           if (jjte001 instanceof RuntimeException) {
/*   84 */             throw (RuntimeException)jjte001;
/*      */           }
/*   86 */           if (jjte001 instanceof ParseException) {
/*   87 */             throw (ParseException)jjte001;
/*      */           }
/*   89 */           throw (Error)jjte001;
/*      */         } finally {
/*   91 */           if (jjtc001) {
/*   92 */             this.jjtree.closeNodeScope(jjtn001, 2);
/*      */           }
/*      */         } 
/*      */         return;
/*      */     } 
/*   97 */     this.jj_la1[1] = this.jj_gen;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void conditionalTestExpression() throws ParseException {
/*      */     ASTTest jjtn001;
/*      */     boolean jjtc001;
/*  104 */     logicalOrExpression();
/*  105 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 3:
/*  107 */         jj_consume_token(3);
/*  108 */         conditionalTestExpression();
/*  109 */         jj_consume_token(4);
/*  110 */         jjtn001 = new ASTTest(3);
/*  111 */         jjtc001 = true;
/*  112 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/*  114 */           conditionalTestExpression();
/*  115 */         } catch (Throwable jjte001) {
/*  116 */           if (jjtc001) {
/*  117 */             this.jjtree.clearNodeScope(jjtn001);
/*  118 */             jjtc001 = false;
/*      */           } else {
/*  120 */             this.jjtree.popNode();
/*      */           } 
/*  122 */           if (jjte001 instanceof RuntimeException) {
/*  123 */             throw (RuntimeException)jjte001;
/*      */           }
/*  125 */           if (jjte001 instanceof ParseException) {
/*  126 */             throw (ParseException)jjte001;
/*      */           }
/*  128 */           throw (Error)jjte001;
/*      */         } finally {
/*  130 */           if (jjtc001) {
/*  131 */             this.jjtree.closeNodeScope(jjtn001, 3);
/*      */           }
/*      */         } 
/*      */         return;
/*      */     } 
/*  136 */     this.jj_la1[2] = this.jj_gen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void logicalOrExpression() throws ParseException {
/*  143 */     logicalAndExpression();
/*      */     
/*      */     while (true) {
/*  146 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 5:
/*      */         case 6:
/*      */           break;
/*      */         
/*      */         default:
/*  152 */           this.jj_la1[3] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  155 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 5:
/*  157 */           jj_consume_token(5);
/*      */           break;
/*      */         case 6:
/*  160 */           jj_consume_token(6);
/*      */           break;
/*      */         default:
/*  163 */           this.jj_la1[4] = this.jj_gen;
/*  164 */           jj_consume_token(-1);
/*  165 */           throw new ParseException();
/*      */       } 
/*  167 */       ASTOr jjtn001 = new ASTOr(4);
/*  168 */       boolean jjtc001 = true;
/*  169 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  171 */         logicalAndExpression();
/*  172 */       } catch (Throwable jjte001) {
/*  173 */         if (jjtc001) {
/*  174 */           this.jjtree.clearNodeScope(jjtn001);
/*  175 */           jjtc001 = false;
/*      */         } else {
/*  177 */           this.jjtree.popNode();
/*      */         } 
/*  179 */         if (jjte001 instanceof RuntimeException) {
/*  180 */           throw (RuntimeException)jjte001;
/*      */         }
/*  182 */         if (jjte001 instanceof ParseException) {
/*  183 */           throw (ParseException)jjte001;
/*      */         }
/*  185 */         throw (Error)jjte001;
/*      */       } finally {
/*  187 */         if (jjtc001) {
/*  188 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void logicalAndExpression() throws ParseException {
/*  196 */     inclusiveOrExpression();
/*      */     
/*      */     while (true) {
/*  199 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 7:
/*      */         case 8:
/*      */           break;
/*      */         
/*      */         default:
/*  205 */           this.jj_la1[5] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  208 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 7:
/*  210 */           jj_consume_token(7);
/*      */           break;
/*      */         case 8:
/*  213 */           jj_consume_token(8);
/*      */           break;
/*      */         default:
/*  216 */           this.jj_la1[6] = this.jj_gen;
/*  217 */           jj_consume_token(-1);
/*  218 */           throw new ParseException();
/*      */       } 
/*  220 */       ASTAnd jjtn001 = new ASTAnd(5);
/*  221 */       boolean jjtc001 = true;
/*  222 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  224 */         inclusiveOrExpression();
/*  225 */       } catch (Throwable jjte001) {
/*  226 */         if (jjtc001) {
/*  227 */           this.jjtree.clearNodeScope(jjtn001);
/*  228 */           jjtc001 = false;
/*      */         } else {
/*  230 */           this.jjtree.popNode();
/*      */         } 
/*  232 */         if (jjte001 instanceof RuntimeException) {
/*  233 */           throw (RuntimeException)jjte001;
/*      */         }
/*  235 */         if (jjte001 instanceof ParseException) {
/*  236 */           throw (ParseException)jjte001;
/*      */         }
/*  238 */         throw (Error)jjte001;
/*      */       } finally {
/*  240 */         if (jjtc001) {
/*  241 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void inclusiveOrExpression() throws ParseException {
/*  249 */     exclusiveOrExpression();
/*      */     
/*      */     while (true) {
/*  252 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 9:
/*      */         case 10:
/*      */           break;
/*      */         
/*      */         default:
/*  258 */           this.jj_la1[7] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  261 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 9:
/*  263 */           jj_consume_token(9);
/*      */           break;
/*      */         case 10:
/*  266 */           jj_consume_token(10);
/*      */           break;
/*      */         default:
/*  269 */           this.jj_la1[8] = this.jj_gen;
/*  270 */           jj_consume_token(-1);
/*  271 */           throw new ParseException();
/*      */       } 
/*  273 */       ASTBitOr jjtn001 = new ASTBitOr(6);
/*  274 */       boolean jjtc001 = true;
/*  275 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  277 */         exclusiveOrExpression();
/*  278 */       } catch (Throwable jjte001) {
/*  279 */         if (jjtc001) {
/*  280 */           this.jjtree.clearNodeScope(jjtn001);
/*  281 */           jjtc001 = false;
/*      */         } else {
/*  283 */           this.jjtree.popNode();
/*      */         } 
/*  285 */         if (jjte001 instanceof RuntimeException) {
/*  286 */           throw (RuntimeException)jjte001;
/*      */         }
/*  288 */         if (jjte001 instanceof ParseException) {
/*  289 */           throw (ParseException)jjte001;
/*      */         }
/*  291 */         throw (Error)jjte001;
/*      */       } finally {
/*  293 */         if (jjtc001) {
/*  294 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void exclusiveOrExpression() throws ParseException {
/*  302 */     andExpression();
/*      */     
/*      */     while (true) {
/*  305 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 11:
/*      */         case 12:
/*      */           break;
/*      */         
/*      */         default:
/*  311 */           this.jj_la1[9] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  314 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 11:
/*  316 */           jj_consume_token(11);
/*      */           break;
/*      */         case 12:
/*  319 */           jj_consume_token(12);
/*      */           break;
/*      */         default:
/*  322 */           this.jj_la1[10] = this.jj_gen;
/*  323 */           jj_consume_token(-1);
/*  324 */           throw new ParseException();
/*      */       } 
/*  326 */       ASTXor jjtn001 = new ASTXor(7);
/*  327 */       boolean jjtc001 = true;
/*  328 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  330 */         andExpression();
/*  331 */       } catch (Throwable jjte001) {
/*  332 */         if (jjtc001) {
/*  333 */           this.jjtree.clearNodeScope(jjtn001);
/*  334 */           jjtc001 = false;
/*      */         } else {
/*  336 */           this.jjtree.popNode();
/*      */         } 
/*  338 */         if (jjte001 instanceof RuntimeException) {
/*  339 */           throw (RuntimeException)jjte001;
/*      */         }
/*  341 */         if (jjte001 instanceof ParseException) {
/*  342 */           throw (ParseException)jjte001;
/*      */         }
/*  344 */         throw (Error)jjte001;
/*      */       } finally {
/*  346 */         if (jjtc001) {
/*  347 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void andExpression() throws ParseException {
/*  355 */     equalityExpression();
/*      */     
/*      */     while (true) {
/*  358 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 13:
/*      */         case 14:
/*      */           break;
/*      */         
/*      */         default:
/*  364 */           this.jj_la1[11] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  367 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 13:
/*  369 */           jj_consume_token(13);
/*      */           break;
/*      */         case 14:
/*  372 */           jj_consume_token(14);
/*      */           break;
/*      */         default:
/*  375 */           this.jj_la1[12] = this.jj_gen;
/*  376 */           jj_consume_token(-1);
/*  377 */           throw new ParseException();
/*      */       } 
/*  379 */       ASTBitAnd jjtn001 = new ASTBitAnd(8);
/*  380 */       boolean jjtc001 = true;
/*  381 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  383 */         equalityExpression();
/*  384 */       } catch (Throwable jjte001) {
/*  385 */         if (jjtc001) {
/*  386 */           this.jjtree.clearNodeScope(jjtn001);
/*  387 */           jjtc001 = false;
/*      */         } else {
/*  389 */           this.jjtree.popNode();
/*      */         } 
/*  391 */         if (jjte001 instanceof RuntimeException) {
/*  392 */           throw (RuntimeException)jjte001;
/*      */         }
/*  394 */         if (jjte001 instanceof ParseException) {
/*  395 */           throw (ParseException)jjte001;
/*      */         }
/*  397 */         throw (Error)jjte001;
/*      */       } finally {
/*  399 */         if (jjtc001) {
/*  400 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void equalityExpression() throws ParseException {
/*  408 */     relationalExpression(); while (true) {
/*      */       ASTEq jjtn001; boolean jjtc001; ASTNotEq jjtn002;
/*      */       boolean jjtc002;
/*  411 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/*      */         case 18:
/*      */           break;
/*      */         
/*      */         default:
/*  419 */           this.jj_la1[13] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  422 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 15:
/*      */         case 16:
/*  425 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 15:
/*  427 */               jj_consume_token(15);
/*      */               break;
/*      */             case 16:
/*  430 */               jj_consume_token(16);
/*      */               break;
/*      */             default:
/*  433 */               this.jj_la1[14] = this.jj_gen;
/*  434 */               jj_consume_token(-1);
/*  435 */               throw new ParseException();
/*      */           } 
/*  437 */           jjtn001 = new ASTEq(9);
/*  438 */           jjtc001 = true;
/*  439 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/*  441 */             relationalExpression(); continue;
/*  442 */           } catch (Throwable jjte001) {
/*  443 */             if (jjtc001) {
/*  444 */               this.jjtree.clearNodeScope(jjtn001);
/*  445 */               jjtc001 = false;
/*      */             } else {
/*  447 */               this.jjtree.popNode();
/*      */             } 
/*  449 */             if (jjte001 instanceof RuntimeException) {
/*  450 */               throw (RuntimeException)jjte001;
/*      */             }
/*  452 */             if (jjte001 instanceof ParseException) {
/*  453 */               throw (ParseException)jjte001;
/*      */             }
/*  455 */             throw (Error)jjte001;
/*      */           } finally {
/*  457 */             if (jjtc001) {
/*  458 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 17:
/*      */         case 18:
/*  464 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 17:
/*  466 */               jj_consume_token(17);
/*      */               break;
/*      */             case 18:
/*  469 */               jj_consume_token(18);
/*      */               break;
/*      */             default:
/*  472 */               this.jj_la1[15] = this.jj_gen;
/*  473 */               jj_consume_token(-1);
/*  474 */               throw new ParseException();
/*      */           } 
/*  476 */           jjtn002 = new ASTNotEq(10);
/*  477 */           jjtc002 = true;
/*  478 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/*  480 */             relationalExpression(); continue;
/*  481 */           } catch (Throwable jjte002) {
/*  482 */             if (jjtc002) {
/*  483 */               this.jjtree.clearNodeScope(jjtn002);
/*  484 */               jjtc002 = false;
/*      */             } else {
/*  486 */               this.jjtree.popNode();
/*      */             } 
/*  488 */             if (jjte002 instanceof RuntimeException) {
/*  489 */               throw (RuntimeException)jjte002;
/*      */             }
/*  491 */             if (jjte002 instanceof ParseException) {
/*  492 */               throw (ParseException)jjte002;
/*      */             }
/*  494 */             throw (Error)jjte002;
/*      */           } finally {
/*  496 */             if (jjtc002) {
/*  497 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */       } 
/*      */       
/*  502 */       this.jj_la1[16] = this.jj_gen;
/*  503 */       jj_consume_token(-1);
/*  504 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void relationalExpression() throws ParseException {
/*  511 */     shiftExpression(); while (true) {
/*      */       ASTLess jjtn001; boolean jjtc001; ASTGreater jjtn002; boolean jjtc002; ASTLessEq jjtn003; boolean jjtc003; ASTGreaterEq jjtn004; boolean jjtc004; ASTIn jjtn005; boolean jjtc005; ASTNotIn jjtn006;
/*      */       boolean jjtc006;
/*  514 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */           break;
/*      */         
/*      */         default:
/*  528 */           this.jj_la1[17] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  531 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 19:
/*      */         case 20:
/*  534 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 19:
/*  536 */               jj_consume_token(19);
/*      */               break;
/*      */             case 20:
/*  539 */               jj_consume_token(20);
/*      */               break;
/*      */             default:
/*  542 */               this.jj_la1[18] = this.jj_gen;
/*  543 */               jj_consume_token(-1);
/*  544 */               throw new ParseException();
/*      */           } 
/*  546 */           jjtn001 = new ASTLess(11);
/*  547 */           jjtc001 = true;
/*  548 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/*  550 */             shiftExpression(); continue;
/*  551 */           } catch (Throwable jjte001) {
/*  552 */             if (jjtc001) {
/*  553 */               this.jjtree.clearNodeScope(jjtn001);
/*  554 */               jjtc001 = false;
/*      */             } else {
/*  556 */               this.jjtree.popNode();
/*      */             } 
/*  558 */             if (jjte001 instanceof RuntimeException) {
/*  559 */               throw (RuntimeException)jjte001;
/*      */             }
/*  561 */             if (jjte001 instanceof ParseException) {
/*  562 */               throw (ParseException)jjte001;
/*      */             }
/*  564 */             throw (Error)jjte001;
/*      */           } finally {
/*  566 */             if (jjtc001) {
/*  567 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 21:
/*      */         case 22:
/*  573 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 21:
/*  575 */               jj_consume_token(21);
/*      */               break;
/*      */             case 22:
/*  578 */               jj_consume_token(22);
/*      */               break;
/*      */             default:
/*  581 */               this.jj_la1[19] = this.jj_gen;
/*  582 */               jj_consume_token(-1);
/*  583 */               throw new ParseException();
/*      */           } 
/*  585 */           jjtn002 = new ASTGreater(12);
/*  586 */           jjtc002 = true;
/*  587 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/*  589 */             shiftExpression(); continue;
/*  590 */           } catch (Throwable jjte002) {
/*  591 */             if (jjtc002) {
/*  592 */               this.jjtree.clearNodeScope(jjtn002);
/*  593 */               jjtc002 = false;
/*      */             } else {
/*  595 */               this.jjtree.popNode();
/*      */             } 
/*  597 */             if (jjte002 instanceof RuntimeException) {
/*  598 */               throw (RuntimeException)jjte002;
/*      */             }
/*  600 */             if (jjte002 instanceof ParseException) {
/*  601 */               throw (ParseException)jjte002;
/*      */             }
/*  603 */             throw (Error)jjte002;
/*      */           } finally {
/*  605 */             if (jjtc002) {
/*  606 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 23:
/*      */         case 24:
/*  612 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 23:
/*  614 */               jj_consume_token(23);
/*      */               break;
/*      */             case 24:
/*  617 */               jj_consume_token(24);
/*      */               break;
/*      */             default:
/*  620 */               this.jj_la1[20] = this.jj_gen;
/*  621 */               jj_consume_token(-1);
/*  622 */               throw new ParseException();
/*      */           } 
/*  624 */           jjtn003 = new ASTLessEq(13);
/*  625 */           jjtc003 = true;
/*  626 */           this.jjtree.openNodeScope(jjtn003);
/*      */           try {
/*  628 */             shiftExpression(); continue;
/*  629 */           } catch (Throwable jjte003) {
/*  630 */             if (jjtc003) {
/*  631 */               this.jjtree.clearNodeScope(jjtn003);
/*  632 */               jjtc003 = false;
/*      */             } else {
/*  634 */               this.jjtree.popNode();
/*      */             } 
/*  636 */             if (jjte003 instanceof RuntimeException) {
/*  637 */               throw (RuntimeException)jjte003;
/*      */             }
/*  639 */             if (jjte003 instanceof ParseException) {
/*  640 */               throw (ParseException)jjte003;
/*      */             }
/*  642 */             throw (Error)jjte003;
/*      */           } finally {
/*  644 */             if (jjtc003) {
/*  645 */               this.jjtree.closeNodeScope(jjtn003, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 25:
/*      */         case 26:
/*  651 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 25:
/*  653 */               jj_consume_token(25);
/*      */               break;
/*      */             case 26:
/*  656 */               jj_consume_token(26);
/*      */               break;
/*      */             default:
/*  659 */               this.jj_la1[21] = this.jj_gen;
/*  660 */               jj_consume_token(-1);
/*  661 */               throw new ParseException();
/*      */           } 
/*  663 */           jjtn004 = new ASTGreaterEq(14);
/*  664 */           jjtc004 = true;
/*  665 */           this.jjtree.openNodeScope(jjtn004);
/*      */           try {
/*  667 */             shiftExpression(); continue;
/*  668 */           } catch (Throwable jjte004) {
/*  669 */             if (jjtc004) {
/*  670 */               this.jjtree.clearNodeScope(jjtn004);
/*  671 */               jjtc004 = false;
/*      */             } else {
/*  673 */               this.jjtree.popNode();
/*      */             } 
/*  675 */             if (jjte004 instanceof RuntimeException) {
/*  676 */               throw (RuntimeException)jjte004;
/*      */             }
/*  678 */             if (jjte004 instanceof ParseException) {
/*  679 */               throw (ParseException)jjte004;
/*      */             }
/*  681 */             throw (Error)jjte004;
/*      */           } finally {
/*  683 */             if (jjtc004) {
/*  684 */               this.jjtree.closeNodeScope(jjtn004, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 27:
/*  689 */           jj_consume_token(27);
/*  690 */           jjtn005 = new ASTIn(15);
/*  691 */           jjtc005 = true;
/*  692 */           this.jjtree.openNodeScope(jjtn005);
/*      */           try {
/*  694 */             shiftExpression(); continue;
/*  695 */           } catch (Throwable jjte005) {
/*  696 */             if (jjtc005) {
/*  697 */               this.jjtree.clearNodeScope(jjtn005);
/*  698 */               jjtc005 = false;
/*      */             } else {
/*  700 */               this.jjtree.popNode();
/*      */             } 
/*  702 */             if (jjte005 instanceof RuntimeException) {
/*  703 */               throw (RuntimeException)jjte005;
/*      */             }
/*  705 */             if (jjte005 instanceof ParseException) {
/*  706 */               throw (ParseException)jjte005;
/*      */             }
/*  708 */             throw (Error)jjte005;
/*      */           } finally {
/*  710 */             if (jjtc005) {
/*  711 */               this.jjtree.closeNodeScope(jjtn005, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 28:
/*  716 */           jj_consume_token(28);
/*  717 */           jj_consume_token(27);
/*  718 */           jjtn006 = new ASTNotIn(16);
/*  719 */           jjtc006 = true;
/*  720 */           this.jjtree.openNodeScope(jjtn006);
/*      */           try {
/*  722 */             shiftExpression(); continue;
/*  723 */           } catch (Throwable jjte006) {
/*  724 */             if (jjtc006) {
/*  725 */               this.jjtree.clearNodeScope(jjtn006);
/*  726 */               jjtc006 = false;
/*      */             } else {
/*  728 */               this.jjtree.popNode();
/*      */             } 
/*  730 */             if (jjte006 instanceof RuntimeException) {
/*  731 */               throw (RuntimeException)jjte006;
/*      */             }
/*  733 */             if (jjte006 instanceof ParseException) {
/*  734 */               throw (ParseException)jjte006;
/*      */             }
/*  736 */             throw (Error)jjte006;
/*      */           } finally {
/*  738 */             if (jjtc006) {
/*  739 */               this.jjtree.closeNodeScope(jjtn006, 2);
/*      */             }
/*      */           } 
/*      */       } 
/*      */       
/*  744 */       this.jj_la1[22] = this.jj_gen;
/*  745 */       jj_consume_token(-1);
/*  746 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void shiftExpression() throws ParseException {
/*  753 */     additiveExpression(); while (true) {
/*      */       ASTShiftLeft jjtn001; boolean jjtc001; ASTShiftRight jjtn002; boolean jjtc002; ASTUnsignedShiftRight jjtn003;
/*      */       boolean jjtc003;
/*  756 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */         case 33:
/*      */         case 34:
/*      */           break;
/*      */         
/*      */         default:
/*  766 */           this.jj_la1[23] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  769 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 29:
/*      */         case 30:
/*  772 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 29:
/*  774 */               jj_consume_token(29);
/*      */               break;
/*      */             case 30:
/*  777 */               jj_consume_token(30);
/*      */               break;
/*      */             default:
/*  780 */               this.jj_la1[24] = this.jj_gen;
/*  781 */               jj_consume_token(-1);
/*  782 */               throw new ParseException();
/*      */           } 
/*  784 */           jjtn001 = new ASTShiftLeft(17);
/*  785 */           jjtc001 = true;
/*  786 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/*  788 */             additiveExpression(); continue;
/*  789 */           } catch (Throwable jjte001) {
/*  790 */             if (jjtc001) {
/*  791 */               this.jjtree.clearNodeScope(jjtn001);
/*  792 */               jjtc001 = false;
/*      */             } else {
/*  794 */               this.jjtree.popNode();
/*      */             } 
/*  796 */             if (jjte001 instanceof RuntimeException) {
/*  797 */               throw (RuntimeException)jjte001;
/*      */             }
/*  799 */             if (jjte001 instanceof ParseException) {
/*  800 */               throw (ParseException)jjte001;
/*      */             }
/*  802 */             throw (Error)jjte001;
/*      */           } finally {
/*  804 */             if (jjtc001) {
/*  805 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 31:
/*      */         case 32:
/*  811 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 31:
/*  813 */               jj_consume_token(31);
/*      */               break;
/*      */             case 32:
/*  816 */               jj_consume_token(32);
/*      */               break;
/*      */             default:
/*  819 */               this.jj_la1[25] = this.jj_gen;
/*  820 */               jj_consume_token(-1);
/*  821 */               throw new ParseException();
/*      */           } 
/*  823 */           jjtn002 = new ASTShiftRight(18);
/*  824 */           jjtc002 = true;
/*  825 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/*  827 */             additiveExpression(); continue;
/*  828 */           } catch (Throwable jjte002) {
/*  829 */             if (jjtc002) {
/*  830 */               this.jjtree.clearNodeScope(jjtn002);
/*  831 */               jjtc002 = false;
/*      */             } else {
/*  833 */               this.jjtree.popNode();
/*      */             } 
/*  835 */             if (jjte002 instanceof RuntimeException) {
/*  836 */               throw (RuntimeException)jjte002;
/*      */             }
/*  838 */             if (jjte002 instanceof ParseException) {
/*  839 */               throw (ParseException)jjte002;
/*      */             }
/*  841 */             throw (Error)jjte002;
/*      */           } finally {
/*  843 */             if (jjtc002) {
/*  844 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 33:
/*      */         case 34:
/*  850 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 33:
/*  852 */               jj_consume_token(33);
/*      */               break;
/*      */             case 34:
/*  855 */               jj_consume_token(34);
/*      */               break;
/*      */             default:
/*  858 */               this.jj_la1[26] = this.jj_gen;
/*  859 */               jj_consume_token(-1);
/*  860 */               throw new ParseException();
/*      */           } 
/*  862 */           jjtn003 = new ASTUnsignedShiftRight(19);
/*  863 */           jjtc003 = true;
/*  864 */           this.jjtree.openNodeScope(jjtn003);
/*      */           try {
/*  866 */             additiveExpression(); continue;
/*  867 */           } catch (Throwable jjte003) {
/*  868 */             if (jjtc003) {
/*  869 */               this.jjtree.clearNodeScope(jjtn003);
/*  870 */               jjtc003 = false;
/*      */             } else {
/*  872 */               this.jjtree.popNode();
/*      */             } 
/*  874 */             if (jjte003 instanceof RuntimeException) {
/*  875 */               throw (RuntimeException)jjte003;
/*      */             }
/*  877 */             if (jjte003 instanceof ParseException) {
/*  878 */               throw (ParseException)jjte003;
/*      */             }
/*  880 */             throw (Error)jjte003;
/*      */           } finally {
/*  882 */             if (jjtc003) {
/*  883 */               this.jjtree.closeNodeScope(jjtn003, 2);
/*      */             }
/*      */           } 
/*      */       } 
/*      */       
/*  888 */       this.jj_la1[27] = this.jj_gen;
/*  889 */       jj_consume_token(-1);
/*  890 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void additiveExpression() throws ParseException {
/*  897 */     multiplicativeExpression(); while (true) {
/*      */       ASTAdd jjtn001; boolean jjtc001; ASTSubtract jjtn002;
/*      */       boolean jjtc002;
/*  900 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 35:
/*      */         case 36:
/*      */           break;
/*      */         
/*      */         default:
/*  906 */           this.jj_la1[28] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  909 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 35:
/*  911 */           jj_consume_token(35);
/*  912 */           jjtn001 = new ASTAdd(20);
/*  913 */           jjtc001 = true;
/*  914 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/*  916 */             multiplicativeExpression(); continue;
/*  917 */           } catch (Throwable jjte001) {
/*  918 */             if (jjtc001) {
/*  919 */               this.jjtree.clearNodeScope(jjtn001);
/*  920 */               jjtc001 = false;
/*      */             } else {
/*  922 */               this.jjtree.popNode();
/*      */             } 
/*  924 */             if (jjte001 instanceof RuntimeException) {
/*  925 */               throw (RuntimeException)jjte001;
/*      */             }
/*  927 */             if (jjte001 instanceof ParseException) {
/*  928 */               throw (ParseException)jjte001;
/*      */             }
/*  930 */             throw (Error)jjte001;
/*      */           } finally {
/*  932 */             if (jjtc001) {
/*  933 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 36:
/*  938 */           jj_consume_token(36);
/*  939 */           jjtn002 = new ASTSubtract(21);
/*  940 */           jjtc002 = true;
/*  941 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/*  943 */             multiplicativeExpression(); continue;
/*  944 */           } catch (Throwable jjte002) {
/*  945 */             if (jjtc002) {
/*  946 */               this.jjtree.clearNodeScope(jjtn002);
/*  947 */               jjtc002 = false;
/*      */             } else {
/*  949 */               this.jjtree.popNode();
/*      */             } 
/*  951 */             if (jjte002 instanceof RuntimeException) {
/*  952 */               throw (RuntimeException)jjte002;
/*      */             }
/*  954 */             if (jjte002 instanceof ParseException) {
/*  955 */               throw (ParseException)jjte002;
/*      */             }
/*  957 */             throw (Error)jjte002;
/*      */           } finally {
/*  959 */             if (jjtc002) {
/*  960 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */       } 
/*      */       
/*  965 */       this.jj_la1[29] = this.jj_gen;
/*  966 */       jj_consume_token(-1);
/*  967 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void multiplicativeExpression() throws ParseException
/*      */   {
/*  974 */     unaryExpression(); while (true) {
/*      */       ASTMultiply jjtn001; boolean jjtc001; ASTDivide jjtn002; boolean jjtc002; ASTRemainder jjtn003;
/*      */       boolean jjtc003;
/*  977 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 37:
/*      */         case 38:
/*      */         case 39:
/*      */           break;
/*      */         
/*      */         default:
/*  984 */           this.jj_la1[30] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  987 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 37:
/*  989 */           jj_consume_token(37);
/*  990 */           jjtn001 = new ASTMultiply(22);
/*  991 */           jjtc001 = true;
/*  992 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/*  994 */             unaryExpression(); continue;
/*  995 */           } catch (Throwable jjte001) {
/*  996 */             if (jjtc001) {
/*  997 */               this.jjtree.clearNodeScope(jjtn001);
/*  998 */               jjtc001 = false;
/*      */             } else {
/* 1000 */               this.jjtree.popNode();
/*      */             } 
/* 1002 */             if (jjte001 instanceof RuntimeException) {
/* 1003 */               throw (RuntimeException)jjte001;
/*      */             }
/* 1005 */             if (jjte001 instanceof ParseException) {
/* 1006 */               throw (ParseException)jjte001;
/*      */             }
/* 1008 */             throw (Error)jjte001;
/*      */           } finally {
/* 1010 */             if (jjtc001) {
/* 1011 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 38:
/* 1016 */           jj_consume_token(38);
/* 1017 */           jjtn002 = new ASTDivide(23);
/* 1018 */           jjtc002 = true;
/* 1019 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/* 1021 */             unaryExpression(); continue;
/* 1022 */           } catch (Throwable jjte002) {
/* 1023 */             if (jjtc002) {
/* 1024 */               this.jjtree.clearNodeScope(jjtn002);
/* 1025 */               jjtc002 = false;
/*      */             } else {
/* 1027 */               this.jjtree.popNode();
/*      */             } 
/* 1029 */             if (jjte002 instanceof RuntimeException) {
/* 1030 */               throw (RuntimeException)jjte002;
/*      */             }
/* 1032 */             if (jjte002 instanceof ParseException) {
/* 1033 */               throw (ParseException)jjte002;
/*      */             }
/* 1035 */             throw (Error)jjte002;
/*      */           } finally {
/* 1037 */             if (jjtc002) {
/* 1038 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 39:
/* 1043 */           jj_consume_token(39);
/* 1044 */           jjtn003 = new ASTRemainder(24);
/* 1045 */           jjtc003 = true;
/* 1046 */           this.jjtree.openNodeScope(jjtn003);
/*      */           try {
/* 1048 */             unaryExpression(); continue;
/* 1049 */           } catch (Throwable jjte003) {
/* 1050 */             if (jjtc003) {
/* 1051 */               this.jjtree.clearNodeScope(jjtn003);
/* 1052 */               jjtc003 = false;
/*      */             } else {
/* 1054 */               this.jjtree.popNode();
/*      */             } 
/* 1056 */             if (jjte003 instanceof RuntimeException) {
/* 1057 */               throw (RuntimeException)jjte003;
/*      */             }
/* 1059 */             if (jjte003 instanceof ParseException) {
/* 1060 */               throw (ParseException)jjte003;
/*      */             }
/* 1062 */             throw (Error)jjte003;
/*      */           } finally {
/* 1064 */             if (jjtc003) {
/* 1065 */               this.jjtree.closeNodeScope(jjtn003, 2);
/*      */             }
/*      */           } 
/*      */       } 
/*      */       
/* 1070 */       this.jj_la1[31] = this.jj_gen;
/* 1071 */       jj_consume_token(-1);
/* 1072 */       throw new ParseException();
/*      */     }  } public final void unaryExpression() throws ParseException { StringBuffer sb; Token t; ASTInstanceof ionode;
/*      */     ASTNegate jjtn001;
/*      */     boolean jjtc001;
/*      */     ASTBitNegate jjtn002;
/*      */     boolean jjtc002;
/*      */     ASTNot jjtn003;
/*      */     boolean jjtc003;
/*      */     ASTInstanceof jjtn004;
/*      */     boolean jjtc004;
/* 1082 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 36:
/* 1084 */         jj_consume_token(36);
/* 1085 */         jjtn001 = new ASTNegate(25);
/* 1086 */         jjtc001 = true;
/* 1087 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/* 1089 */           unaryExpression();
/* 1090 */         } catch (Throwable jjte001) {
/* 1091 */           if (jjtc001) {
/* 1092 */             this.jjtree.clearNodeScope(jjtn001);
/* 1093 */             jjtc001 = false;
/*      */           } else {
/* 1095 */             this.jjtree.popNode();
/*      */           } 
/* 1097 */           if (jjte001 instanceof RuntimeException) {
/* 1098 */             throw (RuntimeException)jjte001;
/*      */           }
/* 1100 */           if (jjte001 instanceof ParseException) {
/* 1101 */             throw (ParseException)jjte001;
/*      */           }
/* 1103 */           throw (Error)jjte001;
/*      */         } finally {
/* 1105 */           if (jjtc001) {
/* 1106 */             this.jjtree.closeNodeScope(jjtn001, 1);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 35:
/* 1111 */         jj_consume_token(35);
/* 1112 */         unaryExpression();
/*      */         return;
/*      */       case 40:
/* 1115 */         jj_consume_token(40);
/* 1116 */         jjtn002 = new ASTBitNegate(26);
/* 1117 */         jjtc002 = true;
/* 1118 */         this.jjtree.openNodeScope(jjtn002);
/*      */         try {
/* 1120 */           unaryExpression();
/* 1121 */         } catch (Throwable jjte002) {
/* 1122 */           if (jjtc002) {
/* 1123 */             this.jjtree.clearNodeScope(jjtn002);
/* 1124 */             jjtc002 = false;
/*      */           } else {
/* 1126 */             this.jjtree.popNode();
/*      */           } 
/* 1128 */           if (jjte002 instanceof RuntimeException) {
/* 1129 */             throw (RuntimeException)jjte002;
/*      */           }
/* 1131 */           if (jjte002 instanceof ParseException) {
/* 1132 */             throw (ParseException)jjte002;
/*      */           }
/* 1134 */           throw (Error)jjte002;
/*      */         } finally {
/* 1136 */           if (jjtc002) {
/* 1137 */             this.jjtree.closeNodeScope(jjtn002, 1);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 28:
/*      */       case 41:
/* 1143 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 41:
/* 1145 */             jj_consume_token(41);
/*      */             break;
/*      */           case 28:
/* 1148 */             jj_consume_token(28);
/*      */             break;
/*      */           default:
/* 1151 */             this.jj_la1[32] = this.jj_gen;
/* 1152 */             jj_consume_token(-1);
/* 1153 */             throw new ParseException();
/*      */         } 
/* 1155 */         jjtn003 = new ASTNot(27);
/* 1156 */         jjtc003 = true;
/* 1157 */         this.jjtree.openNodeScope(jjtn003);
/*      */         try {
/* 1159 */           unaryExpression();
/* 1160 */         } catch (Throwable jjte003) {
/* 1161 */           if (jjtc003) {
/* 1162 */             this.jjtree.clearNodeScope(jjtn003);
/* 1163 */             jjtc003 = false;
/*      */           } else {
/* 1165 */             this.jjtree.popNode();
/*      */           } 
/* 1167 */           if (jjte003 instanceof RuntimeException) {
/* 1168 */             throw (RuntimeException)jjte003;
/*      */           }
/* 1170 */           if (jjte003 instanceof ParseException) {
/* 1171 */             throw (ParseException)jjte003;
/*      */           }
/* 1173 */           throw (Error)jjte003;
/*      */         } finally {
/* 1175 */           if (jjtc003) {
/* 1176 */             this.jjtree.closeNodeScope(jjtn003, 1);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 4:
/*      */       case 44:
/*      */       case 46:
/*      */       case 47:
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 54:
/*      */       case 56:
/*      */       case 57:
/*      */       case 64:
/*      */       case 67:
/*      */       case 73:
/*      */       case 76:
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/* 1199 */         navigationChain();
/* 1200 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 42:
/* 1202 */             jj_consume_token(42);
/* 1203 */             t = jj_consume_token(64);
/* 1204 */             jjtn004 = new ASTInstanceof(28);
/* 1205 */             jjtc004 = true;
/* 1206 */             this.jjtree.openNodeScope(jjtn004);
/*      */             try {
/* 1208 */               this.jjtree.closeNodeScope(jjtn004, 1);
/* 1209 */               jjtc004 = false;
/* 1210 */               sb = new StringBuffer(t.image); ionode = jjtn004;
/*      */             } finally {
/* 1212 */               if (jjtc004) {
/* 1213 */                 this.jjtree.closeNodeScope(jjtn004, 1);
/*      */               }
/*      */             } 
/*      */             
/*      */             while (true) {
/* 1218 */               switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                 case 43:
/*      */                   break;
/*      */                 
/*      */                 default:
/* 1223 */                   this.jj_la1[33] = this.jj_gen;
/*      */                   break;
/*      */               } 
/* 1226 */               jj_consume_token(43);
/* 1227 */               t = jj_consume_token(64);
/* 1228 */               sb.append('.').append(t.image);
/*      */             } 
/* 1230 */             ionode.setTargetType(new String(sb));
/*      */             return;
/*      */         } 
/* 1233 */         this.jj_la1[34] = this.jj_gen;
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 1238 */     this.jj_la1[35] = this.jj_gen;
/* 1239 */     jj_consume_token(-1);
/* 1240 */     throw new ParseException(); }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void navigationChain() throws ParseException
/*      */   {
/* 1246 */     primaryExpression(); while (true) {
/*      */       ASTChain jjtn001; boolean jjtc001; ASTChain jjtn002; boolean jjtc002; ASTEval jjtn003;
/*      */       boolean jjtc003;
/* 1249 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 43:
/*      */         case 44:
/*      */         case 52:
/*      */         case 67:
/*      */           break;
/*      */         
/*      */         default:
/* 1257 */           this.jj_la1[36] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 1260 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 43:
/* 1262 */           jj_consume_token(43);
/* 1263 */           jjtn001 = new ASTChain(29);
/* 1264 */           jjtc001 = true;
/* 1265 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/* 1267 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 64:
/* 1269 */                 if (jj_2_1(2)) {
/* 1270 */                   methodCall(); break;
/*      */                 } 
/* 1272 */                 switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                   case 64:
/* 1274 */                     propertyName();
/*      */                     break;
/*      */                 } 
/* 1277 */                 this.jj_la1[37] = this.jj_gen;
/* 1278 */                 jj_consume_token(-1);
/* 1279 */                 throw new ParseException();
/*      */ 
/*      */ 
/*      */               
/*      */               case 54:
/* 1284 */                 if (jj_2_2(2)) {
/* 1285 */                   projection(); break;
/*      */                 } 
/* 1287 */                 switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                   case 54:
/* 1289 */                     selection();
/*      */                     break;
/*      */                 } 
/* 1292 */                 this.jj_la1[38] = this.jj_gen;
/* 1293 */                 jj_consume_token(-1);
/* 1294 */                 throw new ParseException();
/*      */ 
/*      */ 
/*      */               
/*      */               case 44:
/* 1299 */                 jj_consume_token(44);
/* 1300 */                 expression();
/* 1301 */                 jj_consume_token(45);
/*      */                 break;
/*      */               default:
/* 1304 */                 this.jj_la1[39] = this.jj_gen;
/* 1305 */                 jj_consume_token(-1);
/* 1306 */                 throw new ParseException();
/*      */             }  continue;
/* 1308 */           } catch (Throwable jjte001) {
/* 1309 */             if (jjtc001) {
/* 1310 */               this.jjtree.clearNodeScope(jjtn001);
/* 1311 */               jjtc001 = false;
/*      */             } else {
/* 1313 */               this.jjtree.popNode();
/*      */             } 
/* 1315 */             if (jjte001 instanceof RuntimeException) {
/* 1316 */               throw (RuntimeException)jjte001;
/*      */             }
/* 1318 */             if (jjte001 instanceof ParseException) {
/* 1319 */               throw (ParseException)jjte001;
/*      */             }
/* 1321 */             throw (Error)jjte001;
/*      */           } finally {
/* 1323 */             if (jjtc001) {
/* 1324 */               this.jjtree.closeNodeScope(jjtn001, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 52:
/*      */         case 67:
/* 1330 */           jjtn002 = new ASTChain(29);
/* 1331 */           jjtc002 = true;
/* 1332 */           this.jjtree.openNodeScope(jjtn002);
/*      */           try {
/* 1334 */             index(); continue;
/* 1335 */           } catch (Throwable jjte002) {
/* 1336 */             if (jjtc002) {
/* 1337 */               this.jjtree.clearNodeScope(jjtn002);
/* 1338 */               jjtc002 = false;
/*      */             } else {
/* 1340 */               this.jjtree.popNode();
/*      */             } 
/* 1342 */             if (jjte002 instanceof RuntimeException) {
/* 1343 */               throw (RuntimeException)jjte002;
/*      */             }
/* 1345 */             if (jjte002 instanceof ParseException) {
/* 1346 */               throw (ParseException)jjte002;
/*      */             }
/* 1348 */             throw (Error)jjte002;
/*      */           } finally {
/* 1350 */             if (jjtc002) {
/* 1351 */               this.jjtree.closeNodeScope(jjtn002, 2);
/*      */             }
/*      */           } 
/*      */         
/*      */         case 44:
/* 1356 */           jj_consume_token(44);
/* 1357 */           expression();
/* 1358 */           jjtn003 = new ASTEval(30);
/* 1359 */           jjtc003 = true;
/* 1360 */           this.jjtree.openNodeScope(jjtn003);
/*      */           try {
/* 1362 */             jj_consume_token(45);
/*      */           } finally {
/* 1364 */             if (jjtc003) {
/* 1365 */               this.jjtree.closeNodeScope(jjtn003, 2);
/*      */             }
/*      */           } 
/*      */           continue;
/*      */       } 
/* 1370 */       this.jj_la1[40] = this.jj_gen;
/* 1371 */       jj_consume_token(-1);
/* 1372 */       throw new ParseException();
/*      */     }  } public final void primaryExpression() throws ParseException { ASTConst jjtn001; boolean jjtc001; ASTConst jjtn002;
/*      */     boolean jjtc002;
/*      */     ASTConst jjtn003;
/*      */     boolean jjtc003;
/*      */     ASTConst jjtn004;
/*      */     boolean jjtc004;
/* 1379 */     String className = null;
/* 1380 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 73:
/*      */       case 76:
/*      */       case 79:
/*      */       case 80:
/*      */       case 81:
/* 1386 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 73:
/* 1388 */             jj_consume_token(73);
/*      */             break;
/*      */           case 76:
/* 1391 */             jj_consume_token(76);
/*      */             break;
/*      */           case 79:
/* 1394 */             jj_consume_token(79);
/*      */             break;
/*      */           case 80:
/* 1397 */             jj_consume_token(80);
/*      */             break;
/*      */           case 81:
/* 1400 */             jj_consume_token(81);
/*      */             break;
/*      */           default:
/* 1403 */             this.jj_la1[41] = this.jj_gen;
/* 1404 */             jj_consume_token(-1);
/* 1405 */             throw new ParseException();
/*      */         } 
/* 1407 */         jjtn001 = new ASTConst(31);
/* 1408 */         jjtc001 = true;
/* 1409 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/* 1411 */           this.jjtree.closeNodeScope(jjtn001, 0);
/* 1412 */           jjtc001 = false;
/* 1413 */           jjtn001.setValue(this.token_source.literalValue);
/*      */         } finally {
/* 1415 */           if (jjtc001) {
/* 1416 */             this.jjtree.closeNodeScope(jjtn001, 0);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 46:
/* 1421 */         jj_consume_token(46);
/* 1422 */         jjtn002 = new ASTConst(31);
/* 1423 */         jjtc002 = true;
/* 1424 */         this.jjtree.openNodeScope(jjtn002);
/*      */         try {
/* 1426 */           this.jjtree.closeNodeScope(jjtn002, 0);
/* 1427 */           jjtc002 = false;
/* 1428 */           jjtn002.setValue(Boolean.TRUE);
/*      */         } finally {
/* 1430 */           if (jjtc002) {
/* 1431 */             this.jjtree.closeNodeScope(jjtn002, 0);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 47:
/* 1436 */         jj_consume_token(47);
/* 1437 */         jjtn003 = new ASTConst(31);
/* 1438 */         jjtc003 = true;
/* 1439 */         this.jjtree.openNodeScope(jjtn003);
/*      */         try {
/* 1441 */           this.jjtree.closeNodeScope(jjtn003, 0);
/* 1442 */           jjtc003 = false;
/* 1443 */           jjtn003.setValue(Boolean.FALSE);
/*      */         } finally {
/* 1445 */           if (jjtc003) {
/* 1446 */             this.jjtree.closeNodeScope(jjtn003, 0);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 48:
/* 1451 */         jjtn004 = new ASTConst(31);
/* 1452 */         jjtc004 = true;
/* 1453 */         this.jjtree.openNodeScope(jjtn004);
/*      */         try {
/* 1455 */           jj_consume_token(48);
/*      */         } finally {
/* 1457 */           if (jjtc004) {
/* 1458 */             this.jjtree.closeNodeScope(jjtn004, 0);
/*      */           }
/*      */         } 
/*      */         return;
/*      */     } 
/* 1463 */     this.jj_la1[48] = this.jj_gen;
/* 1464 */     if (jj_2_4(2)) {
/* 1465 */       jj_consume_token(49);
/* 1466 */       ASTThisVarRef jjtn005 = new ASTThisVarRef(32);
/* 1467 */       boolean jjtc005 = true;
/* 1468 */       this.jjtree.openNodeScope(jjtn005);
/*      */       try {
/* 1470 */         this.jjtree.closeNodeScope(jjtn005, 0);
/* 1471 */         jjtc005 = false;
/* 1472 */         jjtn005.setName("this");
/*      */       } finally {
/* 1474 */         if (jjtc005) {
/* 1475 */           this.jjtree.closeNodeScope(jjtn005, 0);
/*      */         }
/*      */       } 
/* 1478 */     } else if (jj_2_5(2)) {
/* 1479 */       jj_consume_token(50);
/* 1480 */       ASTRootVarRef jjtn006 = new ASTRootVarRef(33);
/* 1481 */       boolean jjtc006 = true;
/* 1482 */       this.jjtree.openNodeScope(jjtn006);
/*      */       try {
/* 1484 */         this.jjtree.closeNodeScope(jjtn006, 0);
/* 1485 */         jjtc006 = false;
/* 1486 */         jjtn006.setName("root");
/*      */       } finally {
/* 1488 */         if (jjtc006) {
/* 1489 */           this.jjtree.closeNodeScope(jjtn006, 0);
/*      */         }
/*      */       } 
/* 1492 */     } else if (jj_2_6(2)) {
/* 1493 */       jj_consume_token(51);
/* 1494 */       Token t = jj_consume_token(64);
/* 1495 */       ASTVarRef jjtn007 = new ASTVarRef(34);
/* 1496 */       boolean jjtc007 = true;
/* 1497 */       this.jjtree.openNodeScope(jjtn007);
/*      */       try {
/* 1499 */         this.jjtree.closeNodeScope(jjtn007, 0);
/* 1500 */         jjtc007 = false;
/* 1501 */         jjtn007.setName(t.image);
/*      */       } finally {
/* 1503 */         if (jjtc007) {
/* 1504 */           this.jjtree.closeNodeScope(jjtn007, 0);
/*      */         }
/*      */       } 
/* 1507 */     } else if (jj_2_7(2)) {
/* 1508 */       jj_consume_token(4);
/* 1509 */       jj_consume_token(52);
/* 1510 */       expression();
/* 1511 */       jj_consume_token(53);
/* 1512 */       ASTConst jjtn008 = new ASTConst(31);
/* 1513 */       boolean jjtc008 = true;
/* 1514 */       this.jjtree.openNodeScope(jjtn008);
/*      */       try {
/* 1516 */         this.jjtree.closeNodeScope(jjtn008, 1);
/* 1517 */         jjtc008 = false;
/* 1518 */         jjtn008.setValue(jjtn008.jjtGetChild(0));
/*      */       } finally {
/* 1520 */         if (jjtc008) {
/* 1521 */           this.jjtree.closeNodeScope(jjtn008, 1);
/*      */         }
/*      */       } 
/*      */     } else {
/* 1525 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 56:
/* 1527 */           staticReference();
/*      */           return;
/*      */       } 
/* 1530 */       this.jj_la1[49] = this.jj_gen;
/* 1531 */       if (jj_2_8(2)) {
/* 1532 */         constructorCall();
/*      */       } else {
/* 1534 */         ASTList jjtn009; boolean jjtc009; switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 64:
/* 1536 */             if (jj_2_3(2)) {
/* 1537 */               methodCall();
/*      */             } else {
/* 1539 */               switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                 case 64:
/* 1541 */                   propertyName();
/*      */                   return;
/*      */               } 
/* 1544 */               this.jj_la1[42] = this.jj_gen;
/* 1545 */               jj_consume_token(-1);
/* 1546 */               throw new ParseException();
/*      */             } 
/*      */             return;
/*      */           
/*      */           case 52:
/*      */           case 67:
/* 1552 */             index();
/*      */             return;
/*      */           case 44:
/* 1555 */             jj_consume_token(44);
/* 1556 */             expression();
/* 1557 */             jj_consume_token(45);
/*      */             return;
/*      */           case 54:
/* 1560 */             jj_consume_token(54);
/* 1561 */             jjtn009 = new ASTList(35);
/* 1562 */             jjtc009 = true;
/* 1563 */             this.jjtree.openNodeScope(jjtn009);
/*      */             try {
/* 1565 */               switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                 case 4:
/*      */                 case 28:
/*      */                 case 35:
/*      */                 case 36:
/*      */                 case 40:
/*      */                 case 41:
/*      */                 case 44:
/*      */                 case 46:
/*      */                 case 47:
/*      */                 case 48:
/*      */                 case 49:
/*      */                 case 50:
/*      */                 case 51:
/*      */                 case 52:
/*      */                 case 54:
/*      */                 case 56:
/*      */                 case 57:
/*      */                 case 64:
/*      */                 case 67:
/*      */                 case 73:
/*      */                 case 76:
/*      */                 case 79:
/*      */                 case 80:
/*      */                 case 81:
/* 1590 */                   assignmentExpression();
/*      */                   
/*      */                   while (true) {
/* 1593 */                     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                       case 1:
/*      */                         break;
/*      */                       
/*      */                       default:
/* 1598 */                         this.jj_la1[43] = this.jj_gen;
/*      */                         break;
/*      */                     } 
/* 1601 */                     jj_consume_token(1);
/* 1602 */                     assignmentExpression();
/*      */                   } 
/*      */                   break;
/*      */                 default:
/* 1606 */                   this.jj_la1[44] = this.jj_gen;
/*      */                   break;
/*      */               } 
/* 1609 */             } catch (Throwable jjte009) {
/* 1610 */               if (jjtc009) {
/* 1611 */                 this.jjtree.clearNodeScope(jjtn009);
/* 1612 */                 jjtc009 = false;
/*      */               } else {
/* 1614 */                 this.jjtree.popNode();
/*      */               } 
/* 1616 */               if (jjte009 instanceof RuntimeException) {
/* 1617 */                 throw (RuntimeException)jjte009;
/*      */               }
/* 1619 */               if (jjte009 instanceof ParseException) {
/* 1620 */                 throw (ParseException)jjte009;
/*      */               }
/* 1622 */               throw (Error)jjte009;
/*      */             } finally {
/* 1624 */               if (jjtc009) {
/* 1625 */                 this.jjtree.closeNodeScope(jjtn009, true);
/*      */               }
/*      */             } 
/* 1628 */             jj_consume_token(55);
/*      */             return;
/*      */         } 
/* 1631 */         this.jj_la1[50] = this.jj_gen;
/* 1632 */         if (jj_2_9(2)) {
/* 1633 */           ASTMap jjtn010 = new ASTMap(36);
/* 1634 */           boolean jjtc010 = true;
/* 1635 */           this.jjtree.openNodeScope(jjtn010);
/*      */           try {
/* 1637 */             jj_consume_token(51);
/* 1638 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 56:
/* 1640 */                 className = classReference();
/*      */                 break;
/*      */               default:
/* 1643 */                 this.jj_la1[45] = this.jj_gen;
/*      */                 break;
/*      */             } 
/* 1646 */             jj_consume_token(54);
/* 1647 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 4:
/*      */               case 28:
/*      */               case 35:
/*      */               case 36:
/*      */               case 40:
/*      */               case 41:
/*      */               case 44:
/*      */               case 46:
/*      */               case 47:
/*      */               case 48:
/*      */               case 49:
/*      */               case 50:
/*      */               case 51:
/*      */               case 52:
/*      */               case 54:
/*      */               case 56:
/*      */               case 57:
/*      */               case 64:
/*      */               case 67:
/*      */               case 73:
/*      */               case 76:
/*      */               case 79:
/*      */               case 80:
/*      */               case 81:
/* 1672 */                 keyValueExpression();
/*      */                 
/*      */                 while (true) {
/* 1675 */                   switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                     case 1:
/*      */                       break;
/*      */                     
/*      */                     default:
/* 1680 */                       this.jj_la1[46] = this.jj_gen;
/*      */                       break;
/*      */                   } 
/* 1683 */                   jj_consume_token(1);
/* 1684 */                   keyValueExpression();
/*      */                 } 
/*      */                 break;
/*      */               default:
/* 1688 */                 this.jj_la1[47] = this.jj_gen;
/*      */                 break;
/*      */             } 
/* 1691 */             jjtn010.setClassName(className);
/* 1692 */             jj_consume_token(55);
/* 1693 */           } catch (Throwable jjte010) {
/* 1694 */             if (jjtc010) {
/* 1695 */               this.jjtree.clearNodeScope(jjtn010);
/* 1696 */               jjtc010 = false;
/*      */             } else {
/* 1698 */               this.jjtree.popNode();
/*      */             } 
/* 1700 */             if (jjte010 instanceof RuntimeException) {
/* 1701 */               throw (RuntimeException)jjte010;
/*      */             }
/* 1703 */             if (jjte010 instanceof ParseException) {
/* 1704 */               throw (ParseException)jjte010;
/*      */             }
/* 1706 */             throw (Error)jjte010;
/*      */           } finally {
/* 1708 */             if (jjtc010) {
/* 1709 */               this.jjtree.closeNodeScope(jjtn010, true);
/*      */             }
/*      */           } 
/*      */         } else {
/* 1713 */           jj_consume_token(-1);
/* 1714 */           throw new ParseException();
/*      */         } 
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void keyValueExpression() throws ParseException {
/* 1724 */     ASTKeyValue jjtn001 = new ASTKeyValue(37);
/* 1725 */     boolean jjtc001 = true;
/* 1726 */     this.jjtree.openNodeScope(jjtn001);
/*      */     try {
/* 1728 */       assignmentExpression();
/* 1729 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 4:
/* 1731 */           jj_consume_token(4);
/* 1732 */           assignmentExpression();
/*      */           break;
/*      */         default:
/* 1735 */           this.jj_la1[51] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 1738 */     } catch (Throwable jjte001) {
/* 1739 */       if (jjtc001) {
/* 1740 */         this.jjtree.clearNodeScope(jjtn001);
/* 1741 */         jjtc001 = false;
/*      */       } else {
/* 1743 */         this.jjtree.popNode();
/*      */       } 
/* 1745 */       if (jjte001 instanceof RuntimeException) {
/* 1746 */         throw (RuntimeException)jjte001;
/*      */       }
/* 1748 */       if (jjte001 instanceof ParseException) {
/* 1749 */         throw (ParseException)jjte001;
/*      */       }
/* 1751 */       throw (Error)jjte001;
/*      */     } finally {
/* 1753 */       if (jjtc001) {
/* 1754 */         this.jjtree.closeNodeScope(jjtn001, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void staticReference() throws ParseException {
/* 1760 */     String className = "java.lang.Math";
/*      */     
/* 1762 */     className = classReference();
/* 1763 */     if (jj_2_10(2)) {
/* 1764 */       staticMethodCall(className);
/*      */     } else {
/* 1766 */       Token t; ASTStaticField jjtn001; boolean jjtc001; switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 64:
/* 1768 */           t = jj_consume_token(64);
/* 1769 */           jjtn001 = new ASTStaticField(38);
/* 1770 */           jjtc001 = true;
/* 1771 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/* 1773 */             this.jjtree.closeNodeScope(jjtn001, 0);
/* 1774 */             jjtc001 = false;
/* 1775 */             jjtn001.init(className, t.image);
/*      */           } finally {
/* 1777 */             if (jjtc001) {
/* 1778 */               this.jjtree.closeNodeScope(jjtn001, 0);
/*      */             }
/*      */           } 
/*      */           return;
/*      */       } 
/* 1783 */       this.jj_la1[52] = this.jj_gen;
/* 1784 */       jj_consume_token(-1);
/* 1785 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final String classReference() throws ParseException {
/* 1791 */     String result = "java.lang.Math";
/* 1792 */     jj_consume_token(56);
/* 1793 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk)
/*      */     { case 64:
/* 1795 */         result = className();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1801 */         jj_consume_token(56);
/* 1802 */         return result; }  this.jj_la1[53] = this.jj_gen; jj_consume_token(56); return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String className() throws ParseException {
/* 1809 */     Token t = jj_consume_token(64);
/* 1810 */     StringBuffer result = new StringBuffer(t.image);
/*      */     
/*      */     while (true) {
/* 1813 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 43:
/*      */           break;
/*      */         
/*      */         default:
/* 1818 */           this.jj_la1[54] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 1821 */       jj_consume_token(43);
/* 1822 */       t = jj_consume_token(64);
/* 1823 */       result.append('.').append(t.image);
/*      */     } 
/* 1825 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void constructorCall() throws ParseException {
/* 1831 */     ASTCtor jjtn000 = new ASTCtor(39);
/* 1832 */     boolean jjtc000 = true;
/* 1833 */     this.jjtree.openNodeScope(jjtn000);
/*      */ 
/*      */     
/*      */     try {
/* 1837 */       jj_consume_token(57);
/* 1838 */       String className = className();
/* 1839 */       if (jj_2_11(2)) {
/* 1840 */         jj_consume_token(44);
/* 1841 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 4:
/*      */           case 28:
/*      */           case 35:
/*      */           case 36:
/*      */           case 40:
/*      */           case 41:
/*      */           case 44:
/*      */           case 46:
/*      */           case 47:
/*      */           case 48:
/*      */           case 49:
/*      */           case 50:
/*      */           case 51:
/*      */           case 52:
/*      */           case 54:
/*      */           case 56:
/*      */           case 57:
/*      */           case 64:
/*      */           case 67:
/*      */           case 73:
/*      */           case 76:
/*      */           case 79:
/*      */           case 80:
/*      */           case 81:
/* 1866 */             assignmentExpression();
/*      */             
/*      */             while (true) {
/* 1869 */               switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                 case 1:
/*      */                   break;
/*      */                 
/*      */                 default:
/* 1874 */                   this.jj_la1[55] = this.jj_gen;
/*      */                   break;
/*      */               } 
/* 1877 */               jj_consume_token(1);
/* 1878 */               assignmentExpression();
/*      */             } 
/*      */             break;
/*      */           default:
/* 1882 */             this.jj_la1[56] = this.jj_gen;
/*      */             break;
/*      */         } 
/* 1885 */         jj_consume_token(45);
/* 1886 */         this.jjtree.closeNodeScope(jjtn000, true);
/* 1887 */         jjtc000 = false;
/* 1888 */         jjtn000.setClassName(className);
/* 1889 */       } else if (jj_2_12(2)) {
/* 1890 */         jj_consume_token(52);
/* 1891 */         jj_consume_token(53);
/* 1892 */         jj_consume_token(54);
/* 1893 */         ASTList jjtn001 = new ASTList(35);
/* 1894 */         boolean jjtc001 = true;
/* 1895 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/* 1897 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 4:
/*      */             case 28:
/*      */             case 35:
/*      */             case 36:
/*      */             case 40:
/*      */             case 41:
/*      */             case 44:
/*      */             case 46:
/*      */             case 47:
/*      */             case 48:
/*      */             case 49:
/*      */             case 50:
/*      */             case 51:
/*      */             case 52:
/*      */             case 54:
/*      */             case 56:
/*      */             case 57:
/*      */             case 64:
/*      */             case 67:
/*      */             case 73:
/*      */             case 76:
/*      */             case 79:
/*      */             case 80:
/*      */             case 81:
/* 1922 */               assignmentExpression();
/*      */               
/*      */               while (true) {
/* 1925 */                 switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */                   case 1:
/*      */                     break;
/*      */                   
/*      */                   default:
/* 1930 */                     this.jj_la1[57] = this.jj_gen;
/*      */                     break;
/*      */                 } 
/* 1933 */                 jj_consume_token(1);
/* 1934 */                 assignmentExpression();
/*      */               } 
/*      */               break;
/*      */             default:
/* 1938 */               this.jj_la1[58] = this.jj_gen;
/*      */               break;
/*      */           } 
/* 1941 */         } catch (Throwable jjte001) {
/* 1942 */           if (jjtc001) {
/* 1943 */             this.jjtree.clearNodeScope(jjtn001);
/* 1944 */             jjtc001 = false;
/*      */           } else {
/* 1946 */             this.jjtree.popNode();
/*      */           } 
/* 1948 */           if (jjte001 instanceof RuntimeException) {
/* 1949 */             throw (RuntimeException)jjte001;
/*      */           }
/* 1951 */           if (jjte001 instanceof ParseException) {
/* 1952 */             throw (ParseException)jjte001;
/*      */           }
/* 1954 */           throw (Error)jjte001;
/*      */         } finally {
/* 1956 */           if (jjtc001) {
/* 1957 */             this.jjtree.closeNodeScope(jjtn001, true);
/*      */           }
/*      */         } 
/* 1960 */         jj_consume_token(55);
/* 1961 */         this.jjtree.closeNodeScope(jjtn000, true);
/* 1962 */         jjtc000 = false;
/* 1963 */         jjtn000.setClassName(className);
/* 1964 */         jjtn000.setArray(true);
/* 1965 */       } else if (jj_2_13(2)) {
/* 1966 */         jj_consume_token(52);
/* 1967 */         assignmentExpression();
/* 1968 */         jj_consume_token(53);
/* 1969 */         this.jjtree.closeNodeScope(jjtn000, true);
/* 1970 */         jjtc000 = false;
/* 1971 */         jjtn000.setClassName(className);
/* 1972 */         jjtn000.setArray(true);
/*      */       } else {
/* 1974 */         jj_consume_token(-1);
/* 1975 */         throw new ParseException();
/*      */       } 
/* 1977 */     } catch (Throwable jjte000) {
/* 1978 */       if (jjtc000) {
/* 1979 */         this.jjtree.clearNodeScope(jjtn000);
/* 1980 */         jjtc000 = false;
/*      */       } else {
/* 1982 */         this.jjtree.popNode();
/*      */       } 
/* 1984 */       if (jjte000 instanceof RuntimeException) {
/* 1985 */         throw (RuntimeException)jjte000;
/*      */       }
/* 1987 */       if (jjte000 instanceof ParseException) {
/* 1988 */         throw (ParseException)jjte000;
/*      */       }
/* 1990 */       throw (Error)jjte000;
/*      */     } finally {
/* 1992 */       if (jjtc000) {
/* 1993 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void propertyName() throws ParseException {
/* 2000 */     ASTProperty jjtn000 = new ASTProperty(40);
/* 2001 */     boolean jjtc000 = true;
/* 2002 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2004 */       Token t = jj_consume_token(64);
/* 2005 */       ASTConst jjtn001 = new ASTConst(31);
/* 2006 */       boolean jjtc001 = true;
/* 2007 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/* 2009 */         this.jjtree.closeNodeScope(jjtn001, true);
/* 2010 */         jjtc001 = false;
/* 2011 */         jjtn001.setValue(t.image);
/*      */       } finally {
/* 2013 */         if (jjtc001) {
/* 2014 */           this.jjtree.closeNodeScope(jjtn001, true);
/*      */         }
/*      */       } 
/*      */     } finally {
/* 2018 */       if (jjtc000) {
/* 2019 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void staticMethodCall(String className) throws ParseException {
/* 2026 */     ASTStaticMethod jjtn000 = new ASTStaticMethod(41);
/* 2027 */     boolean jjtc000 = true;
/* 2028 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2030 */       Token t = jj_consume_token(64);
/* 2031 */       jj_consume_token(44);
/* 2032 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 4:
/*      */         case 28:
/*      */         case 35:
/*      */         case 36:
/*      */         case 40:
/*      */         case 41:
/*      */         case 44:
/*      */         case 46:
/*      */         case 47:
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 54:
/*      */         case 56:
/*      */         case 57:
/*      */         case 64:
/*      */         case 67:
/*      */         case 73:
/*      */         case 76:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/* 2057 */           assignmentExpression();
/*      */           
/*      */           while (true) {
/* 2060 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 1:
/*      */                 break;
/*      */               
/*      */               default:
/* 2065 */                 this.jj_la1[59] = this.jj_gen;
/*      */                 break;
/*      */             } 
/* 2068 */             jj_consume_token(1);
/* 2069 */             assignmentExpression();
/*      */           } 
/*      */           break;
/*      */         default:
/* 2073 */           this.jj_la1[60] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 2076 */       jj_consume_token(45);
/* 2077 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 2078 */       jjtc000 = false;
/* 2079 */       jjtn000.init(className, t.image);
/* 2080 */     } catch (Throwable jjte000) {
/* 2081 */       if (jjtc000) {
/* 2082 */         this.jjtree.clearNodeScope(jjtn000);
/* 2083 */         jjtc000 = false;
/*      */       } else {
/* 2085 */         this.jjtree.popNode();
/*      */       } 
/* 2087 */       if (jjte000 instanceof RuntimeException) {
/* 2088 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2090 */       if (jjte000 instanceof ParseException) {
/* 2091 */         throw (ParseException)jjte000;
/*      */       }
/* 2093 */       throw (Error)jjte000;
/*      */     } finally {
/* 2095 */       if (jjtc000) {
/* 2096 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void methodCall() throws ParseException {
/* 2103 */     ASTMethod jjtn000 = new ASTMethod(42);
/* 2104 */     boolean jjtc000 = true;
/* 2105 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2107 */       Token t = jj_consume_token(64);
/* 2108 */       jj_consume_token(44);
/* 2109 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 4:
/*      */         case 28:
/*      */         case 35:
/*      */         case 36:
/*      */         case 40:
/*      */         case 41:
/*      */         case 44:
/*      */         case 46:
/*      */         case 47:
/*      */         case 48:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */         case 54:
/*      */         case 56:
/*      */         case 57:
/*      */         case 64:
/*      */         case 67:
/*      */         case 73:
/*      */         case 76:
/*      */         case 79:
/*      */         case 80:
/*      */         case 81:
/* 2134 */           assignmentExpression();
/*      */           
/*      */           while (true) {
/* 2137 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 1:
/*      */                 break;
/*      */               
/*      */               default:
/* 2142 */                 this.jj_la1[61] = this.jj_gen;
/*      */                 break;
/*      */             } 
/* 2145 */             jj_consume_token(1);
/* 2146 */             assignmentExpression();
/*      */           } 
/*      */           break;
/*      */         default:
/* 2150 */           this.jj_la1[62] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 2153 */       jj_consume_token(45);
/* 2154 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 2155 */       jjtc000 = false;
/* 2156 */       jjtn000.setMethodName(t.image);
/* 2157 */     } catch (Throwable jjte000) {
/* 2158 */       if (jjtc000) {
/* 2159 */         this.jjtree.clearNodeScope(jjtn000);
/* 2160 */         jjtc000 = false;
/*      */       } else {
/* 2162 */         this.jjtree.popNode();
/*      */       } 
/* 2164 */       if (jjte000 instanceof RuntimeException) {
/* 2165 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2167 */       if (jjte000 instanceof ParseException) {
/* 2168 */         throw (ParseException)jjte000;
/*      */       }
/* 2170 */       throw (Error)jjte000;
/*      */     } finally {
/* 2172 */       if (jjtc000) {
/* 2173 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void projection() throws ParseException {
/* 2186 */     ASTProject jjtn000 = new ASTProject(43);
/* 2187 */     boolean jjtc000 = true;
/* 2188 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2190 */       jj_consume_token(54);
/* 2191 */       expression();
/* 2192 */       jj_consume_token(55);
/* 2193 */     } catch (Throwable jjte000) {
/* 2194 */       if (jjtc000) {
/* 2195 */         this.jjtree.clearNodeScope(jjtn000);
/* 2196 */         jjtc000 = false;
/*      */       } else {
/* 2198 */         this.jjtree.popNode();
/*      */       } 
/* 2200 */       if (jjte000 instanceof RuntimeException) {
/* 2201 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2203 */       if (jjte000 instanceof ParseException) {
/* 2204 */         throw (ParseException)jjte000;
/*      */       }
/* 2206 */       throw (Error)jjte000;
/*      */     } finally {
/* 2208 */       if (jjtc000) {
/* 2209 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void selection() throws ParseException {
/* 2215 */     if (jj_2_14(2)) {
/* 2216 */       selectAll();
/* 2217 */     } else if (jj_2_15(2)) {
/* 2218 */       selectFirst();
/* 2219 */     } else if (jj_2_16(2)) {
/* 2220 */       selectLast();
/*      */     } else {
/* 2222 */       jj_consume_token(-1);
/* 2223 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void selectAll() throws ParseException {
/* 2235 */     ASTSelect jjtn000 = new ASTSelect(44);
/* 2236 */     boolean jjtc000 = true;
/* 2237 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2239 */       jj_consume_token(54);
/* 2240 */       jj_consume_token(3);
/* 2241 */       expression();
/* 2242 */       jj_consume_token(55);
/* 2243 */     } catch (Throwable jjte000) {
/* 2244 */       if (jjtc000) {
/* 2245 */         this.jjtree.clearNodeScope(jjtn000);
/* 2246 */         jjtc000 = false;
/*      */       } else {
/* 2248 */         this.jjtree.popNode();
/*      */       } 
/* 2250 */       if (jjte000 instanceof RuntimeException) {
/* 2251 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2253 */       if (jjte000 instanceof ParseException) {
/* 2254 */         throw (ParseException)jjte000;
/*      */       }
/* 2256 */       throw (Error)jjte000;
/*      */     } finally {
/* 2258 */       if (jjtc000) {
/* 2259 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void selectFirst() throws ParseException {
/* 2272 */     ASTSelectFirst jjtn000 = new ASTSelectFirst(45);
/* 2273 */     boolean jjtc000 = true;
/* 2274 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2276 */       jj_consume_token(54);
/* 2277 */       jj_consume_token(11);
/* 2278 */       expression();
/* 2279 */       jj_consume_token(55);
/* 2280 */     } catch (Throwable jjte000) {
/* 2281 */       if (jjtc000) {
/* 2282 */         this.jjtree.clearNodeScope(jjtn000);
/* 2283 */         jjtc000 = false;
/*      */       } else {
/* 2285 */         this.jjtree.popNode();
/*      */       } 
/* 2287 */       if (jjte000 instanceof RuntimeException) {
/* 2288 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2290 */       if (jjte000 instanceof ParseException) {
/* 2291 */         throw (ParseException)jjte000;
/*      */       }
/* 2293 */       throw (Error)jjte000;
/*      */     } finally {
/* 2295 */       if (jjtc000) {
/* 2296 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void selectLast() throws ParseException {
/* 2309 */     ASTSelectLast jjtn000 = new ASTSelectLast(46);
/* 2310 */     boolean jjtc000 = true;
/* 2311 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 2313 */       jj_consume_token(54);
/* 2314 */       jj_consume_token(58);
/* 2315 */       expression();
/* 2316 */       jj_consume_token(55);
/* 2317 */     } catch (Throwable jjte000) {
/* 2318 */       if (jjtc000) {
/* 2319 */         this.jjtree.clearNodeScope(jjtn000);
/* 2320 */         jjtc000 = false;
/*      */       } else {
/* 2322 */         this.jjtree.popNode();
/*      */       } 
/* 2324 */       if (jjte000 instanceof RuntimeException) {
/* 2325 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2327 */       if (jjte000 instanceof ParseException) {
/* 2328 */         throw (ParseException)jjte000;
/*      */       }
/* 2330 */       throw (Error)jjte000;
/*      */     } finally {
/* 2332 */       if (jjtc000) {
/* 2333 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void index() throws ParseException {
/* 2340 */     ASTProperty jjtn000 = new ASTProperty(40);
/* 2341 */     boolean jjtc000 = true;
/* 2342 */     this.jjtree.openNodeScope(jjtn000); try {
/*      */       ASTConst jjtn001; boolean jjtc001;
/* 2344 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 52:
/* 2346 */           jj_consume_token(52);
/* 2347 */           expression();
/* 2348 */           jj_consume_token(53);
/* 2349 */           this.jjtree.closeNodeScope(jjtn000, true);
/* 2350 */           jjtc000 = false;
/* 2351 */           jjtn000.setIndexedAccess(true);
/*      */           break;
/*      */         case 67:
/* 2354 */           jj_consume_token(67);
/* 2355 */           jjtn001 = new ASTConst(31);
/* 2356 */           jjtc001 = true;
/* 2357 */           this.jjtree.openNodeScope(jjtn001);
/*      */           try {
/* 2359 */             this.jjtree.closeNodeScope(jjtn001, true);
/* 2360 */             jjtc001 = false;
/* 2361 */             jjtn001.setValue(this.token_source.literalValue);
/*      */           } finally {
/* 2363 */             if (jjtc001) {
/* 2364 */               this.jjtree.closeNodeScope(jjtn001, true);
/*      */             }
/*      */           } 
/* 2367 */           this.jjtree.closeNodeScope(jjtn000, true);
/* 2368 */           jjtc000 = false;
/* 2369 */           jjtn000.setIndexedAccess(true);
/*      */           break;
/*      */         default:
/* 2372 */           this.jj_la1[63] = this.jj_gen;
/* 2373 */           jj_consume_token(-1);
/* 2374 */           throw new ParseException();
/*      */       } 
/* 2376 */     } catch (Throwable jjte000) {
/* 2377 */       if (jjtc000) {
/* 2378 */         this.jjtree.clearNodeScope(jjtn000);
/* 2379 */         jjtc000 = false;
/*      */       } else {
/* 2381 */         this.jjtree.popNode();
/*      */       } 
/* 2383 */       if (jjte000 instanceof RuntimeException) {
/* 2384 */         throw (RuntimeException)jjte000;
/*      */       }
/* 2386 */       if (jjte000 instanceof ParseException) {
/* 2387 */         throw (ParseException)jjte000;
/*      */       }
/* 2389 */       throw (Error)jjte000;
/*      */     } finally {
/* 2391 */       if (jjtc000) {
/* 2392 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean jj_2_1(int xla) {
/* 2398 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2399 */     try { return !jj_3_1(); }
/* 2400 */     catch (LookaheadSuccess ls) { return true; }
/* 2401 */     finally { jj_save(0, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_2(int xla) {
/* 2405 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2406 */     try { return !jj_3_2(); }
/* 2407 */     catch (LookaheadSuccess ls) { return true; }
/* 2408 */     finally { jj_save(1, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_3(int xla) {
/* 2412 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2413 */     try { return !jj_3_3(); }
/* 2414 */     catch (LookaheadSuccess ls) { return true; }
/* 2415 */     finally { jj_save(2, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_4(int xla) {
/* 2419 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2420 */     try { return !jj_3_4(); }
/* 2421 */     catch (LookaheadSuccess ls) { return true; }
/* 2422 */     finally { jj_save(3, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_5(int xla) {
/* 2426 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2427 */     try { return !jj_3_5(); }
/* 2428 */     catch (LookaheadSuccess ls) { return true; }
/* 2429 */     finally { jj_save(4, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_6(int xla) {
/* 2433 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2434 */     try { return !jj_3_6(); }
/* 2435 */     catch (LookaheadSuccess ls) { return true; }
/* 2436 */     finally { jj_save(5, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_7(int xla) {
/* 2440 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2441 */     try { return !jj_3_7(); }
/* 2442 */     catch (LookaheadSuccess ls) { return true; }
/* 2443 */     finally { jj_save(6, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_8(int xla) {
/* 2447 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2448 */     try { return !jj_3_8(); }
/* 2449 */     catch (LookaheadSuccess ls) { return true; }
/* 2450 */     finally { jj_save(7, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_9(int xla) {
/* 2454 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2455 */     try { return !jj_3_9(); }
/* 2456 */     catch (LookaheadSuccess ls) { return true; }
/* 2457 */     finally { jj_save(8, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_10(int xla) {
/* 2461 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2462 */     try { return !jj_3_10(); }
/* 2463 */     catch (LookaheadSuccess ls) { return true; }
/* 2464 */     finally { jj_save(9, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_11(int xla) {
/* 2468 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2469 */     try { return !jj_3_11(); }
/* 2470 */     catch (LookaheadSuccess ls) { return true; }
/* 2471 */     finally { jj_save(10, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_12(int xla) {
/* 2475 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2476 */     try { return !jj_3_12(); }
/* 2477 */     catch (LookaheadSuccess ls) { return true; }
/* 2478 */     finally { jj_save(11, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_13(int xla) {
/* 2482 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2483 */     try { return !jj_3_13(); }
/* 2484 */     catch (LookaheadSuccess ls) { return true; }
/* 2485 */     finally { jj_save(12, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_14(int xla) {
/* 2489 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2490 */     try { return !jj_3_14(); }
/* 2491 */     catch (LookaheadSuccess ls) { return true; }
/* 2492 */     finally { jj_save(13, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_15(int xla) {
/* 2496 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2497 */     try { return !jj_3_15(); }
/* 2498 */     catch (LookaheadSuccess ls) { return true; }
/* 2499 */     finally { jj_save(14, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_2_16(int xla) {
/* 2503 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 2504 */     try { return !jj_3_16(); }
/* 2505 */     catch (LookaheadSuccess ls) { return true; }
/* 2506 */     finally { jj_save(15, xla); }
/*      */   
/*      */   }
/*      */   private boolean jj_3R_56() {
/* 2510 */     if (jj_scan_token(48)) return true; 
/* 2511 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_55() {
/* 2515 */     if (jj_scan_token(47)) return true; 
/* 2516 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_54() {
/* 2520 */     if (jj_scan_token(46)) return true; 
/* 2521 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_31() {
/* 2525 */     if (jj_3R_27()) return true; 
/* 2526 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_13() {
/* 2530 */     if (jj_scan_token(52)) return true; 
/* 2531 */     if (jj_3R_27()) return true; 
/* 2532 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_53() {
/* 2537 */     Token xsp = this.jj_scanpos;
/* 2538 */     if (jj_scan_token(73)) {
/* 2539 */       this.jj_scanpos = xsp;
/* 2540 */       if (jj_scan_token(76)) {
/* 2541 */         this.jj_scanpos = xsp;
/* 2542 */         if (jj_scan_token(79)) {
/* 2543 */           this.jj_scanpos = xsp;
/* 2544 */           if (jj_scan_token(80)) {
/* 2545 */             this.jj_scanpos = xsp;
/* 2546 */             if (jj_scan_token(81)) return true; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2551 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_26() {
/* 2555 */     if (jj_3R_27()) return true; 
/* 2556 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_52() {
/* 2561 */     Token xsp = this.jj_scanpos;
/* 2562 */     if (jj_3R_53()) {
/* 2563 */       this.jj_scanpos = xsp;
/* 2564 */       if (jj_3R_54()) {
/* 2565 */         this.jj_scanpos = xsp;
/* 2566 */         if (jj_3R_55()) {
/* 2567 */           this.jj_scanpos = xsp;
/* 2568 */           if (jj_3R_56()) {
/* 2569 */             this.jj_scanpos = xsp;
/* 2570 */             if (jj_3_4()) {
/* 2571 */               this.jj_scanpos = xsp;
/* 2572 */               if (jj_3_5()) {
/* 2573 */                 this.jj_scanpos = xsp;
/* 2574 */                 if (jj_3_6()) {
/* 2575 */                   this.jj_scanpos = xsp;
/* 2576 */                   if (jj_3_7()) {
/* 2577 */                     this.jj_scanpos = xsp;
/* 2578 */                     if (jj_3R_57()) {
/* 2579 */                       this.jj_scanpos = xsp;
/* 2580 */                       if (jj_3_8()) {
/* 2581 */                         this.jj_scanpos = xsp;
/* 2582 */                         if (jj_3R_58()) {
/* 2583 */                           this.jj_scanpos = xsp;
/* 2584 */                           if (jj_3R_59()) {
/* 2585 */                             this.jj_scanpos = xsp;
/* 2586 */                             if (jj_3R_60()) {
/* 2587 */                               this.jj_scanpos = xsp;
/* 2588 */                               if (jj_3R_61()) {
/* 2589 */                                 this.jj_scanpos = xsp;
/* 2590 */                                 if (jj_3_9()) return true; 
/*      */                               } 
/*      */                             } 
/*      */                           } 
/*      */                         } 
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2605 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_42() {
/* 2609 */     if (jj_3R_43()) return true; 
/* 2610 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_12() {
/* 2614 */     if (jj_scan_token(52)) return true; 
/* 2615 */     if (jj_scan_token(53)) return true; 
/* 2616 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_11() {
/* 2620 */     if (jj_scan_token(44)) return true;
/*      */     
/* 2622 */     Token xsp = this.jj_scanpos;
/* 2623 */     if (jj_3R_26()) this.jj_scanpos = xsp; 
/* 2624 */     if (jj_scan_token(45)) return true; 
/* 2625 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_67() {
/* 2629 */     if (jj_scan_token(67)) return true; 
/* 2630 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_2() {
/* 2634 */     if (jj_3R_22()) return true; 
/* 2635 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_66() {
/* 2639 */     if (jj_scan_token(52)) return true; 
/* 2640 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_64() {
/* 2645 */     Token xsp = this.jj_scanpos;
/* 2646 */     if (jj_3R_66()) {
/* 2647 */       this.jj_scanpos = xsp;
/* 2648 */       if (jj_3R_67()) return true; 
/*      */     } 
/* 2650 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_1() {
/* 2654 */     if (jj_3R_21()) return true; 
/* 2655 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_23() {
/* 2659 */     if (jj_scan_token(57)) return true; 
/* 2660 */     if (jj_3R_32()) return true; 
/* 2661 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_41() {
/* 2665 */     if (jj_3R_42()) return true; 
/* 2666 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_30() {
/* 2670 */     if (jj_scan_token(54)) return true; 
/* 2671 */     if (jj_scan_token(58)) return true; 
/* 2672 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_32() {
/* 2676 */     if (jj_scan_token(64)) return true; 
/* 2677 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_51() {
/* 2681 */     if (jj_3R_52()) return true; 
/* 2682 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_29() {
/* 2686 */     if (jj_scan_token(54)) return true; 
/* 2687 */     if (jj_scan_token(11)) return true; 
/* 2688 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_40() {
/* 2692 */     if (jj_3R_41()) return true; 
/* 2693 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_33() {
/* 2697 */     if (jj_scan_token(56)) return true; 
/* 2698 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_63() {
/* 2702 */     if (jj_3R_65()) return true; 
/* 2703 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_28() {
/* 2707 */     if (jj_scan_token(54)) return true; 
/* 2708 */     if (jj_scan_token(3)) return true; 
/* 2709 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_50() {
/* 2713 */     if (jj_3R_51()) return true; 
/* 2714 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_39() {
/* 2718 */     if (jj_3R_40()) return true; 
/* 2719 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_10() {
/* 2723 */     if (jj_3R_25()) return true; 
/* 2724 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_24() {
/* 2728 */     if (jj_3R_33()) return true; 
/* 2729 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_49() {
/* 2734 */     Token xsp = this.jj_scanpos;
/* 2735 */     if (jj_scan_token(41)) {
/* 2736 */       this.jj_scanpos = xsp;
/* 2737 */       if (jj_scan_token(28)) return true; 
/*      */     } 
/* 2739 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_48() {
/* 2743 */     if (jj_scan_token(40)) return true; 
/* 2744 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_16() {
/* 2748 */     if (jj_3R_30()) return true; 
/* 2749 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_47() {
/* 2753 */     if (jj_scan_token(35)) return true; 
/* 2754 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_15() {
/* 2758 */     if (jj_3R_29()) return true; 
/* 2759 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_38() {
/* 2763 */     if (jj_3R_39()) return true; 
/* 2764 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_46() {
/* 2768 */     if (jj_scan_token(36)) return true; 
/* 2769 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_14() {
/* 2773 */     if (jj_3R_28()) return true; 
/* 2774 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_62() {
/* 2778 */     if (jj_3R_33()) return true; 
/* 2779 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_45() {
/* 2784 */     Token xsp = this.jj_scanpos;
/* 2785 */     if (jj_3R_46()) {
/* 2786 */       this.jj_scanpos = xsp;
/* 2787 */       if (jj_3R_47()) {
/* 2788 */         this.jj_scanpos = xsp;
/* 2789 */         if (jj_3R_48()) {
/* 2790 */           this.jj_scanpos = xsp;
/* 2791 */           if (jj_3R_49()) {
/* 2792 */             this.jj_scanpos = xsp;
/* 2793 */             if (jj_3R_50()) return true; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2798 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_37() {
/* 2802 */     if (jj_3R_38()) return true; 
/* 2803 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_22() {
/* 2807 */     if (jj_scan_token(54)) return true; 
/* 2808 */     if (jj_3R_31()) return true; 
/* 2809 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_9() {
/* 2813 */     if (jj_scan_token(51)) return true;
/*      */     
/* 2815 */     Token xsp = this.jj_scanpos;
/* 2816 */     if (jj_3R_24()) this.jj_scanpos = xsp; 
/* 2817 */     if (jj_scan_token(54)) return true; 
/* 2818 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_36() {
/* 2822 */     if (jj_3R_37()) return true; 
/* 2823 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_61() {
/* 2827 */     if (jj_scan_token(54)) return true; 
/* 2828 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_60() {
/* 2832 */     if (jj_scan_token(44)) return true; 
/* 2833 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_59() {
/* 2837 */     if (jj_3R_64()) return true; 
/* 2838 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_3() {
/* 2842 */     if (jj_3R_21()) return true; 
/* 2843 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_21() {
/* 2847 */     if (jj_scan_token(64)) return true; 
/* 2848 */     if (jj_scan_token(44)) return true; 
/* 2849 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean jj_3R_58() {
/* 2854 */     Token xsp = this.jj_scanpos;
/* 2855 */     if (jj_3_3()) {
/* 2856 */       this.jj_scanpos = xsp;
/* 2857 */       if (jj_3R_63()) return true; 
/*      */     } 
/* 2859 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_35() {
/* 2863 */     if (jj_3R_36()) return true; 
/* 2864 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_44() {
/* 2868 */     if (jj_3R_45()) return true; 
/* 2869 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_8() {
/* 2873 */     if (jj_3R_23()) return true; 
/* 2874 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_57() {
/* 2878 */     if (jj_3R_62()) return true; 
/* 2879 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_34() {
/* 2883 */     if (jj_3R_35()) return true; 
/* 2884 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_7() {
/* 2888 */     if (jj_scan_token(4)) return true; 
/* 2889 */     if (jj_scan_token(52)) return true; 
/* 2890 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_25() {
/* 2894 */     if (jj_scan_token(64)) return true; 
/* 2895 */     if (jj_scan_token(44)) return true; 
/* 2896 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_6() {
/* 2900 */     if (jj_scan_token(51)) return true; 
/* 2901 */     if (jj_scan_token(64)) return true; 
/* 2902 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_5() {
/* 2906 */     if (jj_scan_token(50)) return true; 
/* 2907 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_27() {
/* 2911 */     if (jj_3R_34()) return true; 
/* 2912 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_4() {
/* 2916 */     if (jj_scan_token(49)) return true; 
/* 2917 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_65() {
/* 2921 */     if (jj_scan_token(64)) return true; 
/* 2922 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_43() {
/* 2926 */     if (jj_3R_44()) return true; 
/* 2927 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_lookingAhead = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean jj_semLA;
/*      */ 
/*      */ 
/*      */   
/*      */   private int jj_gen;
/*      */ 
/*      */   
/* 2944 */   private final int[] jj_la1 = new int[64]; private static int[] jj_la1_0;
/*      */   private static int[] jj_la1_1;
/*      */   private static int[] jj_la1_2;
/*      */   
/*      */   static {
/* 2949 */     jj_la1_init_0();
/* 2950 */     jj_la1_init_1();
/* 2951 */     jj_la1_init_2();
/*      */   }
/*      */   private static void jj_la1_init_0() {
/* 2954 */     jj_la1_0 = new int[] { 2, 4, 8, 96, 96, 384, 384, 1536, 1536, 6144, 6144, 24576, 24576, 491520, 98304, 393216, 491520, 536346624, 1572864, 6291456, 25165824, 100663296, 536346624, -536870912, 1610612736, Integer.MIN_VALUE, 0, -536870912, 0, 0, 0, 0, 268435456, 0, 0, 268435472, 0, 0, 0, 0, 0, 0, 0, 2, 268435472, 0, 2, 268435472, 0, 0, 0, 16, 0, 0, 0, 2, 268435472, 2, 268435472, 2, 268435472, 2, 268435472, 0 };
/*      */   }
/*      */   private static void jj_la1_init_1() {
/* 2957 */     jj_la1_1 = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 1, 6, 7, 24, 24, 224, 224, 512, 2048, 1024, 56611608, 1054720, 0, 4194304, 4198400, 1054720, 0, 0, 0, 56611608, 16777216, 0, 56611608, 114688, 16777216, 5246976, 0, 0, 0, 2048, 0, 56611608, 0, 56611608, 0, 56611608, 0, 56611608, 1048576 };
/*      */   }
/*      */   private static void jj_la1_init_2() {
/* 2960 */     jj_la1_2 = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 233993, 8, 1, 0, 1, 8, 233984, 1, 0, 233993, 0, 0, 233993, 233984, 0, 9, 0, 1, 1, 0, 0, 233993, 0, 233993, 0, 233993, 0, 233993, 8 };
/*      */   }
/* 2962 */   private final JJCalls[] jj_2_rtns = new JJCalls[16];
/*      */   private boolean jj_rescan = false;
/* 2964 */   private int jj_gc = 0; private final LookaheadSuccess jj_ls;
/*      */   private List jj_expentries;
/*      */   private int[] jj_expentry;
/*      */   private int jj_kind;
/*      */   private int[] jj_lasttokens;
/*      */   private int jj_endpos;
/*      */   
/*      */   public OgnlParser(InputStream stream) {
/* 2972 */     this(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(InputStream stream) {
/* 2997 */     ReInit(stream, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(InputStream stream, String encoding) {
/*      */     
/* 3007 */     try { this.jj_input_stream.ReInit(stream, encoding, 1, 1); } catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }
/* 3008 */      this.token_source.ReInit(this.jj_input_stream);
/* 3009 */     this.token = new Token();
/* 3010 */     this.jj_ntk = -1;
/* 3011 */     this.jjtree.reset();
/* 3012 */     this.jj_gen = 0; int i;
/* 3013 */     for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }
/* 3014 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(Reader stream) {
/* 3038 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 3039 */     this.token_source.ReInit(this.jj_input_stream);
/* 3040 */     this.token = new Token();
/* 3041 */     this.jj_ntk = -1;
/* 3042 */     this.jjtree.reset();
/* 3043 */     this.jj_gen = 0; int i;
/* 3044 */     for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }
/* 3045 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ReInit(OgnlParserTokenManager tm) {
/* 3068 */     this.token_source = tm;
/* 3069 */     this.token = new Token();
/* 3070 */     this.jj_ntk = -1;
/* 3071 */     this.jjtree.reset();
/* 3072 */     this.jj_gen = 0; int i;
/* 3073 */     for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }
/* 3074 */      for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }
/*      */   
/*      */   }
/*      */   private Token jj_consume_token(int kind) throws ParseException {
/*      */     Token oldToken;
/* 3079 */     if ((oldToken = this.token).next != null) { this.token = this.token.next; }
/* 3080 */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/* 3081 */      this.jj_ntk = -1;
/* 3082 */     if (this.token.kind == kind) {
/* 3083 */       this.jj_gen++;
/* 3084 */       if (++this.jj_gc > 100) {
/* 3085 */         this.jj_gc = 0;
/* 3086 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 3087 */           JJCalls c = this.jj_2_rtns[i];
/* 3088 */           while (c != null) {
/* 3089 */             if (c.gen < this.jj_gen) c.first = null; 
/* 3090 */             c = c.next;
/*      */           } 
/*      */         } 
/*      */       } 
/* 3094 */       return this.token;
/*      */     } 
/* 3096 */     this.token = oldToken;
/* 3097 */     this.jj_kind = kind;
/* 3098 */     throw generateParseException();
/*      */   }
/*      */   private static final class LookaheadSuccess extends Error {
/*      */     private LookaheadSuccess() {} }
/* 3102 */   public OgnlParser(InputStream stream, String encoding) { this.jj_ls = new LookaheadSuccess();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3160 */     this.jj_expentries = new ArrayList();
/*      */     
/* 3162 */     this.jj_kind = -1;
/* 3163 */     this.jj_lasttokens = new int[100]; try { this.jj_input_stream = new JavaCharStream(stream, encoding, 1, 1); } catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }  this.token_source = new OgnlParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public OgnlParser(Reader stream) { this.jj_ls = new LookaheadSuccess(); this.jj_expentries = new ArrayList(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.jj_input_stream = new JavaCharStream(stream, 1, 1); this.token_source = new OgnlParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public OgnlParser(OgnlParserTokenManager tm) { this.jj_ls = new LookaheadSuccess(); this.jj_expentries = new ArrayList(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; int i; for (i = 0; i < 64; ) { this.jj_la1[i] = -1; i++; }  for (i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  }
/*      */   private boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) { this.jj_la--; if (this.jj_scanpos.next == null) { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken(); } else { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next; }  } else { this.jj_scanpos = this.jj_scanpos.next; }  if (this.jj_rescan) { int i = 0; Token tok = this.token; while (tok != null && tok != this.jj_scanpos) { i++; tok = tok.next; }  if (tok != null)
/*      */         jj_add_error_token(kind, i);  }  if (this.jj_scanpos.kind != kind)
/*      */       return true;  if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos)
/* 3167 */       throw this.jj_ls;  return false; } private void jj_add_error_token(int kind, int pos) { if (pos >= 100)
/* 3168 */       return;  if (pos == this.jj_endpos + 1) {
/* 3169 */       this.jj_lasttokens[this.jj_endpos++] = kind;
/* 3170 */     } else if (this.jj_endpos != 0) {
/* 3171 */       this.jj_expentry = new int[this.jj_endpos];
/* 3172 */       for (int i = 0; i < this.jj_endpos; i++)
/* 3173 */         this.jj_expentry[i] = this.jj_lasttokens[i]; 
/*      */       Iterator<int[]> it;
/* 3175 */       label31: for (it = this.jj_expentries.iterator(); it.hasNext(); ) {
/* 3176 */         int[] oldentry = it.next();
/* 3177 */         if (oldentry.length == this.jj_expentry.length) {
/* 3178 */           for (int j = 0; j < this.jj_expentry.length; j++) {
/* 3179 */             if (oldentry[j] != this.jj_expentry[j]) {
/*      */               continue label31;
/*      */             }
/*      */           } 
/* 3183 */           this.jj_expentries.add(this.jj_expentry);
/*      */           break;
/*      */         } 
/*      */       } 
/* 3187 */       if (pos != 0) this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind; 
/*      */     }  }
/*      */   public final Token getNextToken() { if (this.token.next != null) { this.token = this.token.next; }
/*      */     else { this.token = this.token.next = this.token_source.getNextToken(); }
/*      */      this.jj_ntk = -1; this.jj_gen++; return this.token; }
/*      */   public final Token getToken(int index) { Token t = this.jj_lookingAhead ? this.jj_scanpos : this.token; for (int i = 0; i < index; i++) { if (t.next != null) { t = t.next; }
/*      */       else { t = t.next = this.token_source.getNextToken(); }
/*      */        }
/*      */      return t; }
/*      */   private int jj_ntk() { if ((this.jj_nt = this.token.next) == null)
/* 3197 */       return this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind;  return this.jj_ntk = this.jj_nt.kind; } public ParseException generateParseException() { this.jj_expentries.clear();
/* 3198 */     boolean[] la1tokens = new boolean[86];
/* 3199 */     if (this.jj_kind >= 0) {
/* 3200 */       la1tokens[this.jj_kind] = true;
/* 3201 */       this.jj_kind = -1;
/*      */     }  int i;
/* 3203 */     for (i = 0; i < 64; i++) {
/* 3204 */       if (this.jj_la1[i] == this.jj_gen) {
/* 3205 */         for (int k = 0; k < 32; k++) {
/* 3206 */           if ((jj_la1_0[i] & 1 << k) != 0) {
/* 3207 */             la1tokens[k] = true;
/*      */           }
/* 3209 */           if ((jj_la1_1[i] & 1 << k) != 0) {
/* 3210 */             la1tokens[32 + k] = true;
/*      */           }
/* 3212 */           if ((jj_la1_2[i] & 1 << k) != 0) {
/* 3213 */             la1tokens[64 + k] = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 3218 */     for (i = 0; i < 86; i++) {
/* 3219 */       if (la1tokens[i]) {
/* 3220 */         this.jj_expentry = new int[1];
/* 3221 */         this.jj_expentry[0] = i;
/* 3222 */         this.jj_expentries.add(this.jj_expentry);
/*      */       } 
/*      */     } 
/* 3225 */     this.jj_endpos = 0;
/* 3226 */     jj_rescan_token();
/* 3227 */     jj_add_error_token(0, 0);
/* 3228 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 3229 */     for (int j = 0; j < this.jj_expentries.size(); j++) {
/* 3230 */       exptokseq[j] = this.jj_expentries.get(j);
/*      */     }
/* 3232 */     return new ParseException(this.token, exptokseq, tokenImage); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enable_tracing() {}
/*      */ 
/*      */   
/*      */   public final void disable_tracing() {}
/*      */ 
/*      */   
/*      */   private void jj_rescan_token() {
/* 3244 */     this.jj_rescan = true;
/* 3245 */     for (int i = 0; i < 16; i++) {
/*      */       try {
/* 3247 */         JJCalls p = this.jj_2_rtns[i];
/*      */         do {
/* 3249 */           if (p.gen > this.jj_gen) {
/* 3250 */             this.jj_la = p.arg; this.jj_lastpos = this.jj_scanpos = p.first;
/* 3251 */             switch (i) { case 0:
/* 3252 */                 jj_3_1(); break;
/* 3253 */               case 1: jj_3_2(); break;
/* 3254 */               case 2: jj_3_3(); break;
/* 3255 */               case 3: jj_3_4(); break;
/* 3256 */               case 4: jj_3_5(); break;
/* 3257 */               case 5: jj_3_6(); break;
/* 3258 */               case 6: jj_3_7(); break;
/* 3259 */               case 7: jj_3_8(); break;
/* 3260 */               case 8: jj_3_9(); break;
/* 3261 */               case 9: jj_3_10(); break;
/* 3262 */               case 10: jj_3_11(); break;
/* 3263 */               case 11: jj_3_12(); break;
/* 3264 */               case 12: jj_3_13(); break;
/* 3265 */               case 13: jj_3_14(); break;
/* 3266 */               case 14: jj_3_15(); break;
/* 3267 */               case 15: jj_3_16(); break; }
/*      */           
/*      */           } 
/* 3270 */           p = p.next;
/* 3271 */         } while (p != null);
/* 3272 */       } catch (LookaheadSuccess lookaheadSuccess) {}
/*      */     } 
/* 3274 */     this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private void jj_save(int index, int xla) {
/* 3278 */     JJCalls p = this.jj_2_rtns[index];
/* 3279 */     while (p.gen > this.jj_gen) {
/* 3280 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 3281 */        p = p.next;
/*      */     } 
/* 3283 */     p.gen = this.jj_gen + xla - this.jj_la; p.first = this.token; p.arg = xla;
/*      */   }
/*      */   
/*      */   static final class JJCalls {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */