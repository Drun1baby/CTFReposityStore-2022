/*     */ package ognl;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getPossibleProperty(Map context, Object target, String name) throws OgnlException {
/*     */     Object result;
/*  63 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     
/*     */     try {
/*  66 */       if ((result = OgnlRuntime.getMethodValue(ognlContext, target, name, true)) == OgnlRuntime.NotFound)
/*     */       {
/*  68 */         result = OgnlRuntime.getFieldValue(ognlContext, target, name, true);
/*     */       }
/*  70 */     } catch (IntrospectionException ex) {
/*  71 */       throw new OgnlException(name, ex);
/*  72 */     } catch (OgnlException ex) {
/*  73 */       throw ex;
/*  74 */     } catch (Exception ex) {
/*  75 */       throw new OgnlException(name, ex);
/*     */     } 
/*     */     
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setPossibleProperty(Map context, Object target, String name, Object value) throws OgnlException {
/*  94 */     Object result = null;
/*  95 */     OgnlContext ognlContext = (OgnlContext)context;
/*     */     
/*     */     try {
/*  98 */       if (!OgnlRuntime.setMethodValue(ognlContext, target, name, value, true))
/*     */       {
/* 100 */         result = OgnlRuntime.setFieldValue(ognlContext, target, name, value) ? null : OgnlRuntime.NotFound;
/*     */       }
/*     */       
/* 103 */       if (result == OgnlRuntime.NotFound) {
/*     */         
/* 105 */         Method m = OgnlRuntime.getWriteMethod(target.getClass(), name);
/* 106 */         if (m != null)
/*     */         {
/* 108 */           result = m.invoke(target, new Object[] { value });
/*     */         }
/*     */       } 
/* 111 */     } catch (IntrospectionException ex) {
/* 112 */       throw new OgnlException(name, ex);
/* 113 */     } catch (OgnlException ex) {
/* 114 */       throw ex;
/* 115 */     } catch (Exception ex) {
/* 116 */       throw new OgnlException(name, ex);
/*     */     } 
/*     */     
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasGetProperty(OgnlContext context, Object target, Object oname) throws OgnlException {
/*     */     try {
/* 126 */       return OgnlRuntime.hasGetProperty(context, target, oname);
/* 127 */     } catch (IntrospectionException ex) {
/* 128 */       throw new OgnlException("checking if " + target + " has gettable property " + oname, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasGetProperty(Map context, Object target, Object oname) throws OgnlException {
/* 135 */     return hasGetProperty((OgnlContext)context, target, oname);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSetProperty(OgnlContext context, Object target, Object oname) throws OgnlException {
/*     */     try {
/* 142 */       return OgnlRuntime.hasSetProperty(context, target, oname);
/* 143 */     } catch (IntrospectionException ex) {
/* 144 */       throw new OgnlException("checking if " + target + " has settable property " + oname, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSetProperty(Map context, Object target, Object oname) throws OgnlException {
/* 151 */     return hasSetProperty((OgnlContext)context, target, oname);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(Map context, Object target, Object oname) throws OgnlException {
/* 157 */     Object result = null;
/* 158 */     String name = oname.toString();
/*     */     
/* 160 */     result = getPossibleProperty(context, target, name);
/*     */     
/* 162 */     if (result == OgnlRuntime.NotFound)
/*     */     {
/* 164 */       throw new NoSuchPropertyException(target, name);
/*     */     }
/*     */     
/* 167 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object oname, Object value) throws OgnlException {
/* 173 */     String name = oname.toString();
/*     */     
/* 175 */     Object result = setPossibleProperty(context, target, name, value);
/*     */     
/* 177 */     if (result == OgnlRuntime.NotFound)
/*     */     {
/* 179 */       throw new NoSuchPropertyException(target, name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getPropertyClass(OgnlContext context, Object target, Object index) {
/*     */     try {
/* 186 */       Method m = OgnlRuntime.getReadMethod(target.getClass(), index.toString());
/*     */       
/* 188 */       if (m == null) {
/*     */         
/* 190 */         if (String.class.isAssignableFrom(index.getClass()) && !target.getClass().isArray()) {
/* 191 */           String indexStr = (String)index;
/* 192 */           String key = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/*     */           try {
/* 194 */             Field f = target.getClass().getField(key);
/* 195 */             if (f != null)
/*     */             {
/* 197 */               return f.getType();
/*     */             }
/* 199 */           } catch (NoSuchFieldException e) {
/* 200 */             return null;
/*     */           } 
/*     */         } 
/*     */         
/* 204 */         return null;
/*     */       } 
/*     */       
/* 207 */       return m.getReturnType();
/*     */     }
/* 209 */     catch (Throwable t) {
/*     */       
/* 211 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/*     */     try {
/* 219 */       String indexStr = index.toString();
/* 220 */       String methodName = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/* 221 */       Method m = OgnlRuntime.getReadMethod(target.getClass(), methodName);
/*     */ 
/*     */ 
/*     */       
/* 225 */       if (m == null && context.getCurrentObject() != null) {
/*     */         
/* 227 */         String currentObjectStr = context.getCurrentObject().toString();
/* 228 */         m = OgnlRuntime.getReadMethod(target.getClass(), (currentObjectStr.indexOf('"') >= 0) ? currentObjectStr.replaceAll("\"", "") : currentObjectStr);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (m == null) {
/*     */ 
/*     */         
/*     */         try {
/* 238 */           if (String.class.isAssignableFrom(index.getClass()) && !target.getClass().isArray()) {
/*     */             
/* 240 */             Field f = target.getClass().getField(methodName);
/*     */             
/* 242 */             if (f != null)
/*     */             {
/* 244 */               context.setCurrentType(f.getType());
/* 245 */               context.setCurrentAccessor(f.getDeclaringClass());
/*     */               
/* 247 */               return "." + f.getName();
/*     */             }
/*     */           
/*     */           } 
/* 251 */         } catch (NoSuchFieldException noSuchFieldException) {}
/*     */ 
/*     */ 
/*     */         
/* 255 */         return "";
/*     */       } 
/*     */       
/* 258 */       context.setCurrentType(m.getReturnType());
/* 259 */       context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */       
/* 261 */       return "." + m.getName() + "()";
/*     */     }
/* 263 */     catch (Throwable t) {
/*     */       
/* 265 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/*     */     try {
/* 273 */       String conversion, indexStr = index.toString();
/* 274 */       String methodName = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/* 275 */       Method m = OgnlRuntime.getWriteMethod(target.getClass(), methodName);
/*     */       
/* 277 */       if (m == null && context.getCurrentObject() != null && context.getCurrentObject().toString() != null) {
/*     */ 
/*     */         
/* 280 */         String currentObjectStr = context.getCurrentObject().toString();
/* 281 */         m = OgnlRuntime.getWriteMethod(target.getClass(), (currentObjectStr.indexOf('"') >= 0) ? currentObjectStr.replaceAll("\"", "") : currentObjectStr);
/*     */       } 
/*     */       
/* 284 */       if (m == null || m.getParameterTypes() == null || (m.getParameterTypes()).length <= 0) {
/* 285 */         throw new UnsupportedCompilationException("Unable to determine setting expression on " + context.getCurrentObject() + " with index of " + index);
/*     */       }
/*     */       
/* 288 */       Class<?> parm = m.getParameterTypes()[0];
/*     */ 
/*     */       
/* 291 */       if ((m.getParameterTypes()).length > 1) {
/* 292 */         throw new UnsupportedCompilationException("Object property accessors can only support single parameter setters.");
/*     */       }
/*     */       
/* 295 */       if (parm.isPrimitive()) {
/*     */         
/* 297 */         Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(parm);
/* 298 */         conversion = OgnlRuntime.getCompiler().createLocalReference(context, "((" + wrapClass.getName() + ")ognl.OgnlOps#convertValue($3," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass), parm);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 303 */       else if (parm.isArray()) {
/*     */         
/* 305 */         conversion = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ExpressionCompiler.getCastString(parm) + ")ognl.OgnlOps#toArray($3," + parm.getComponentType().getName() + ".class)", parm);
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 312 */         conversion = OgnlRuntime.getCompiler().createLocalReference(context, "(" + parm.getName() + ")ognl.OgnlOps#convertValue($3," + parm.getName() + ".class)", parm);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 319 */       context.setCurrentType(m.getReturnType());
/* 320 */       context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */       
/* 322 */       return "." + m.getName() + "(" + conversion + ")";
/*     */     }
/* 324 */     catch (Throwable t) {
/*     */       
/* 326 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */