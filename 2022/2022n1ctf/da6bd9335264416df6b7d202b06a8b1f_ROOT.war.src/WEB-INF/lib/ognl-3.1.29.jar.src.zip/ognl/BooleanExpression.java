/*    */ package ognl;
/*    */ 
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BooleanExpression
/*    */   extends ExpressionNode
/*    */   implements NodeType
/*    */ {
/*    */   protected Class _getterClass;
/*    */   
/*    */   public BooleanExpression(int id) {
/* 20 */     super(id);
/*    */   }
/*    */   
/*    */   public BooleanExpression(OgnlParser p, int id) {
/* 24 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getGetterClass() {
/* 29 */     return this._getterClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getSetterClass() {
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/*    */     try {
/* 41 */       Object value = getValueBody(context, target);
/*    */       
/* 43 */       if (value != null && Boolean.class.isAssignableFrom(value.getClass())) {
/* 44 */         this._getterClass = boolean.class;
/* 45 */       } else if (value != null) {
/* 46 */         this._getterClass = value.getClass();
/*    */       } else {
/* 48 */         this._getterClass = boolean.class;
/*    */       } 
/* 50 */       String ret = super.toGetSourceString(context, target);
/*    */       
/* 52 */       if ("(false)".equals(ret))
/* 53 */         return "false"; 
/* 54 */       if ("(true)".equals(ret)) {
/* 55 */         return "true";
/*    */       }
/* 57 */       return ret;
/*    */     }
/* 59 */     catch (NullPointerException e) {
/*    */ 
/*    */       
/* 62 */       e.printStackTrace();
/*    */       
/* 64 */       throw new UnsupportedCompilationException("evaluation resulted in null expression.");
/* 65 */     } catch (Throwable t) {
/*    */       
/* 67 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\BooleanExpression.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */