/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTStaticMethod
/*     */   extends SimpleNode
/*     */   implements NodeType
/*     */ {
/*     */   private String _className;
/*     */   private String _methodName;
/*     */   private Class _getterClass;
/*     */   
/*     */   public ASTStaticMethod(int id) {
/*  52 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTStaticMethod(OgnlParser p, int id) {
/*  57 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void init(String className, String methodName) {
/*  63 */     this._className = className;
/*  64 */     this._methodName = methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  70 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(jjtGetNumChildren());
/*  71 */     Object root = context.getRoot();
/*     */     
/*     */     try {
/*  74 */       for (int i = 0, icount = args.length; i < icount; i++) {
/*  75 */         args[i] = this._children[i].getValue(context, root);
/*     */       }
/*  77 */       return OgnlRuntime.callStaticMethod(context, this._className, this._methodName, args);
/*     */     } finally {
/*  79 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  85 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/*  90 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     String result = "@" + this._className + "@" + this._methodName;
/*     */     
/*  97 */     result = result + "(";
/*  98 */     if (this._children != null && this._children.length > 0) {
/*  99 */       for (int i = 0; i < this._children.length; i++) {
/* 100 */         if (i > 0) {
/* 101 */           result = result + ", ";
/*     */         }
/* 103 */         result = result + this._children[i];
/*     */       } 
/*     */     }
/* 106 */     result = result + ")";
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 112 */     String result = this._className + "#" + this._methodName + "(";
/*     */     
/*     */     try {
/* 115 */       Class clazz = OgnlRuntime.classForName(context, this._className);
/* 116 */       Method m = OgnlRuntime.getMethod(context, clazz, this._methodName, this._children, true);
/*     */       
/* 118 */       if (clazz == null || m == null) {
/* 119 */         throw new UnsupportedCompilationException("Unable to find class/method combo " + this._className + " / " + this._methodName);
/*     */       }
/* 121 */       if (!context.getMemberAccess().isAccessible(context, clazz, m, this._methodName))
/*     */       {
/* 123 */         throw new UnsupportedCompilationException("Method is not accessible, check your jvm runtime security settings. For static class method " + this._className + " / " + this._methodName);
/*     */       }
/*     */ 
/*     */       
/* 127 */       if (this._children != null && this._children.length > 0) {
/*     */         
/* 129 */         Class[] parms = m.getParameterTypes();
/*     */         
/* 131 */         for (int i = 0; i < this._children.length; i++) {
/*     */           
/* 133 */           if (i > 0)
/*     */           {
/* 135 */             result = result + ", ";
/*     */           }
/*     */           
/* 138 */           Class prevType = context.getCurrentType();
/*     */           
/* 140 */           Object value = this._children[i].getValue(context, context.getRoot());
/* 141 */           String parmString = this._children[i].toGetSourceString(context, context.getRoot());
/*     */           
/* 143 */           if (parmString == null || parmString.trim().length() < 1) {
/* 144 */             parmString = "null";
/*     */           }
/*     */           
/* 147 */           if (ASTConst.class.isInstance(this._children[i]))
/*     */           {
/* 149 */             context.setCurrentType(prevType);
/*     */           }
/*     */           
/* 152 */           parmString = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + parmString;
/*     */           
/* 154 */           String cast = "";
/* 155 */           if (ExpressionCompiler.shouldCast(this._children[i]))
/*     */           {
/* 157 */             cast = (String)context.remove("_preCast");
/*     */           }
/*     */           
/* 160 */           if (cast == null) {
/* 161 */             cast = "";
/*     */           }
/* 163 */           if (!ASTConst.class.isInstance(this._children[i])) {
/* 164 */             parmString = cast + parmString;
/*     */           }
/* 166 */           Class<?> valueClass = (value != null) ? value.getClass() : null;
/* 167 */           if (NodeType.class.isAssignableFrom(this._children[i].getClass())) {
/* 168 */             valueClass = ((NodeType)this._children[i]).getGetterClass();
/*     */           }
/* 170 */           if (valueClass != parms[i])
/*     */           {
/* 172 */             if (parms[i].isArray()) {
/*     */               
/* 174 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ExpressionCompiler.getCastString(parms[i]) + ")ognl.OgnlOps.toArray(" + parmString + ", " + parms[i].getComponentType().getName() + ".class, true)", parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 182 */             else if (parms[i].isPrimitive()) {
/*     */               
/* 184 */               Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(parms[i]);
/*     */               
/* 186 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "((" + wrapClass.getName() + ")ognl.OgnlOps.convertValue(" + parmString + "," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass), parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 194 */             else if (parms[i] != Object.class) {
/*     */               
/* 196 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + parms[i].getName() + ")ognl.OgnlOps.convertValue(" + parmString + "," + parms[i].getName() + ".class)", parms[i]);
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 201 */             else if ((NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null && Number.class.isAssignableFrom(((NodeType)this._children[i]).getGetterClass())) || valueClass.isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 206 */               parmString = " ($w) " + parmString;
/* 207 */             } else if (valueClass.isPrimitive()) {
/*     */               
/* 209 */               parmString = "($w) " + parmString;
/*     */             } 
/*     */           }
/*     */           
/* 213 */           result = result + parmString;
/*     */         } 
/*     */       } 
/*     */       
/* 217 */       result = result + ")";
/*     */ 
/*     */       
/*     */       try {
/* 221 */         Object contextObj = getValueBody(context, target);
/* 222 */         context.setCurrentObject(contextObj);
/* 223 */       } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       if (m != null)
/*     */       {
/* 230 */         this._getterClass = m.getReturnType();
/*     */         
/* 232 */         context.setCurrentType(m.getReturnType());
/* 233 */         context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */       }
/*     */     
/* 236 */     } catch (Throwable t) {
/*     */       
/* 238 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 241 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 246 */     return toGetSourceString(context, target);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTStaticMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */