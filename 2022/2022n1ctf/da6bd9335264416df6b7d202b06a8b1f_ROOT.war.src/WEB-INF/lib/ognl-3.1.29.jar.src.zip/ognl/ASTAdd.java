/*     */ package ognl;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTAdd
/*     */   extends NumericExpression
/*     */ {
/*     */   public ASTAdd(int id) {
/*  47 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTAdd(OgnlParser p, int id) {
/*  52 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public void jjtClose() {
/*  57 */     flattenTree();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  62 */     Object result = this._children[0].getValue(context, source);
/*     */     
/*  64 */     for (int i = 1; i < this._children.length; i++) {
/*  65 */       result = OgnlOps.add(result, this._children[i].getValue(context, source));
/*     */     }
/*  67 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionOperator(int index) {
/*  72 */     return "+";
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isWider(NodeType type, NodeType lastType) {
/*  77 */     if (lastType == null) {
/*  78 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  82 */     if (String.class.isAssignableFrom(lastType.getGetterClass())) {
/*  83 */       return false;
/*     */     }
/*  85 */     if (String.class.isAssignableFrom(type.getGetterClass())) {
/*  86 */       return true;
/*     */     }
/*  88 */     if (this._parent != null && String.class.isAssignableFrom(type.getGetterClass())) {
/*  89 */       return true;
/*     */     }
/*  91 */     if (String.class.isAssignableFrom(lastType.getGetterClass()) && Object.class == type.getGetterClass()) {
/*  92 */       return false;
/*     */     }
/*  94 */     if (this._parent != null && String.class.isAssignableFrom(lastType.getGetterClass()))
/*  95 */       return false; 
/*  96 */     if (this._parent == null && String.class.isAssignableFrom(lastType.getGetterClass()))
/*  97 */       return true; 
/*  98 */     if (this._parent == null && String.class.isAssignableFrom(type.getGetterClass())) {
/*  99 */       return false;
/*     */     }
/* 101 */     if (BigDecimal.class.isAssignableFrom(type.getGetterClass()) || BigInteger.class.isAssignableFrom(type.getGetterClass()))
/*     */     {
/* 103 */       return true;
/*     */     }
/* 105 */     if (BigDecimal.class.isAssignableFrom(lastType.getGetterClass()) || BigInteger.class.isAssignableFrom(lastType.getGetterClass()))
/*     */     {
/* 107 */       return false;
/*     */     }
/* 109 */     if (Double.class.isAssignableFrom(type.getGetterClass())) {
/* 110 */       return true;
/*     */     }
/* 112 */     if (Integer.class.isAssignableFrom(type.getGetterClass()) && Double.class.isAssignableFrom(lastType.getGetterClass()))
/*     */     {
/* 114 */       return false;
/*     */     }
/* 116 */     if (Float.class.isAssignableFrom(type.getGetterClass()) && Integer.class.isAssignableFrom(lastType.getGetterClass()))
/*     */     {
/* 118 */       return true;
/*     */     }
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*     */     try {
/* 126 */       String result = "";
/* 127 */       NodeType lastType = null;
/*     */ 
/*     */ 
/*     */       
/* 131 */       if (this._children != null && this._children.length > 0) {
/*     */         
/* 133 */         Class currType = context.getCurrentType();
/* 134 */         Class currAccessor = context.getCurrentAccessor();
/*     */         
/* 136 */         Object cast = context.get("_preCast");
/*     */         
/* 138 */         for (int i = 0; i < this._children.length; i++) {
/*     */           
/* 140 */           this._children[i].toGetSourceString(context, target);
/*     */           
/* 142 */           if (NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null && isWider((NodeType)this._children[i], lastType))
/*     */           {
/*     */ 
/*     */             
/* 146 */             lastType = (NodeType)this._children[i];
/*     */           }
/*     */         } 
/*     */         
/* 150 */         context.put("_preCast", cast);
/*     */         
/* 152 */         context.setCurrentType(currType);
/* 153 */         context.setCurrentAccessor(currAccessor);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 158 */       context.setCurrentObject(target);
/*     */       
/* 160 */       if (this._children != null && this._children.length > 0)
/*     */       {
/*     */         
/* 163 */         for (int i = 0; i < this._children.length; i++) {
/*     */           
/* 165 */           if (i > 0) {
/* 166 */             result = result + " " + getExpressionOperator(i) + " ";
/*     */           }
/* 168 */           String expr = this._children[i].toGetSourceString(context, target);
/*     */           
/* 170 */           if ((expr != null && "null".equals(expr)) || (!ASTConst.class.isInstance(this._children[i]) && (expr == null || expr.trim().length() <= 0)))
/*     */           {
/*     */ 
/*     */             
/* 174 */             expr = "null";
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 179 */           if (ASTProperty.class.isInstance(this._children[i])) {
/*     */             
/* 181 */             expr = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + expr;
/* 182 */             context.setCurrentAccessor(context.getRoot().getClass());
/* 183 */           } else if (ASTMethod.class.isInstance(this._children[i])) {
/*     */             
/* 185 */             String chain = (String)context.get("_currentChain");
/* 186 */             String rootExpr = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 191 */             if (rootExpr.endsWith(".") && chain != null && chain.startsWith(")."))
/*     */             {
/* 193 */               chain = chain.substring(1, chain.length());
/*     */             }
/*     */             
/* 196 */             expr = rootExpr + ((chain != null) ? (chain + ".") : "") + expr;
/* 197 */             context.setCurrentAccessor(context.getRoot().getClass());
/*     */           }
/* 199 */           else if (ExpressionNode.class.isInstance(this._children[i])) {
/*     */             
/* 201 */             expr = "(" + expr + ")";
/* 202 */           } else if ((this._parent == null || !ASTChain.class.isInstance(this._parent)) && ASTChain.class.isInstance(this._children[i])) {
/*     */ 
/*     */             
/* 205 */             String rootExpr = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context);
/*     */             
/* 207 */             if (!ASTProperty.class.isInstance(this._children[i].jjtGetChild(0)) && rootExpr.endsWith(")") && expr.startsWith(")"))
/*     */             {
/* 209 */               expr = expr.substring(1, expr.length());
/*     */             }
/* 211 */             expr = rootExpr + expr;
/* 212 */             context.setCurrentAccessor(context.getRoot().getClass());
/*     */             
/* 214 */             String cast = (String)context.remove("_preCast");
/* 215 */             if (cast == null) {
/* 216 */               cast = "";
/*     */             }
/* 218 */             expr = cast + expr;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 223 */           if (context.getCurrentType() != null && context.getCurrentType() == Character.class && ASTConst.class.isInstance(this._children[i])) {
/*     */ 
/*     */             
/* 226 */             if (expr.indexOf('\'') >= 0)
/* 227 */               expr = expr.replaceAll("'", "\""); 
/* 228 */             context.setCurrentType(String.class);
/*     */           
/*     */           }
/* 231 */           else if (!ASTVarRef.class.isAssignableFrom(this._children[i].getClass()) && !ASTProperty.class.isInstance(this._children[i]) && !ASTMethod.class.isInstance(this._children[i]) && !ASTSequence.class.isInstance(this._children[i]) && !ASTChain.class.isInstance(this._children[i]) && !NumericExpression.class.isAssignableFrom(this._children[i].getClass()) && !ASTStaticField.class.isInstance(this._children[i]) && !ASTStaticMethod.class.isInstance(this._children[i]) && !ASTTest.class.isInstance(this._children[i])) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 241 */             if (lastType != null && String.class.isAssignableFrom(lastType.getGetterClass())) {
/*     */ 
/*     */               
/* 244 */               if (expr.indexOf("&quot;") >= 0)
/* 245 */                 expr = expr.replaceAll("&quot;", "\""); 
/* 246 */               if (expr.indexOf('"') >= 0)
/* 247 */                 expr = expr.replaceAll("\"", "'"); 
/* 248 */               expr = "\"" + expr + "\"";
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 254 */           result = result + expr;
/*     */ 
/*     */ 
/*     */           
/* 258 */           if ((lastType == null || !String.class.isAssignableFrom(lastType.getGetterClass())) && !ASTConst.class.isAssignableFrom(this._children[i].getClass()) && !NumericExpression.class.isAssignableFrom(this._children[i].getClass()))
/*     */           {
/*     */ 
/*     */             
/* 262 */             if (context.getCurrentType() != null && Number.class.isAssignableFrom(context.getCurrentType()) && !ASTMethod.class.isInstance(this._children[i])) {
/*     */ 
/*     */               
/* 265 */               if (ASTVarRef.class.isInstance(this._children[i]) || ASTProperty.class.isInstance(this._children[i]) || ASTChain.class.isInstance(this._children[i]))
/*     */               {
/*     */                 
/* 268 */                 result = result + ".";
/*     */               }
/* 270 */               result = result + OgnlRuntime.getNumericValueGetter(context.getCurrentType());
/* 271 */               context.setCurrentType(OgnlRuntime.getPrimitiveWrapperClass(context.getCurrentType()));
/*     */             } 
/*     */           }
/*     */           
/* 275 */           if (lastType != null) {
/* 276 */             context.setCurrentAccessor(lastType.getGetterClass());
/*     */           }
/*     */         } 
/*     */       }
/* 280 */       if (this._parent == null || ASTSequence.class.isAssignableFrom(this._parent.getClass())) {
/*     */         
/* 282 */         if (this._getterClass != null && String.class.isAssignableFrom(this._getterClass)) {
/* 283 */           this._getterClass = Object.class;
/*     */         }
/*     */       } else {
/* 286 */         context.setCurrentType(this._getterClass);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 291 */         Object contextObj = getValueBody(context, target);
/* 292 */         context.setCurrentObject(contextObj);
/* 293 */       } catch (Throwable t) {
/*     */         
/* 295 */         throw OgnlOps.castToRuntime(t);
/*     */       } 
/*     */       
/* 298 */       return result;
/*     */     }
/* 300 */     catch (Throwable t) {
/*     */       
/* 302 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTAdd.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */