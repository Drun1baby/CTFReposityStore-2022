/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTUnsignedShiftRight
/*    */   extends NumericExpression
/*    */ {
/*    */   public ASTUnsignedShiftRight(int id) {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTUnsignedShiftRight(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 49 */     Object v1 = this._children[0].getValue(context, source);
/* 50 */     Object v2 = this._children[1].getValue(context, source);
/* 51 */     return OgnlOps.unsignedShiftRight(v1, v2);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 56 */     return ">>>";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 61 */     String result = "";
/*    */ 
/*    */     
/*    */     try {
/* 65 */       String child1 = OgnlRuntime.getChildSource(context, target, this._children[0]);
/* 66 */       child1 = coerceToNumeric(child1, context, this._children[0]);
/*    */       
/* 68 */       String child2 = OgnlRuntime.getChildSource(context, target, this._children[1]);
/* 69 */       child2 = coerceToNumeric(child2, context, this._children[1]);
/*    */       
/* 71 */       Object v1 = this._children[0].getValue(context, target);
/* 72 */       int type = OgnlOps.getNumericType(v1);
/*    */       
/* 74 */       if (type <= 4) {
/*    */         
/* 76 */         child1 = "(int)" + child1;
/* 77 */         child2 = "(int)" + child2;
/*    */       } 
/*    */       
/* 80 */       result = child1 + " >>> " + child2;
/*    */       
/* 82 */       context.setCurrentType(int.class);
/* 83 */       context.setCurrentObject(getValueBody(context, target));
/*    */     }
/* 85 */     catch (Throwable t) {
/*    */       
/* 87 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */     
/* 90 */     return result;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTUnsignedShiftRight.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */