/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTXor
/*    */   extends NumericExpression
/*    */ {
/*    */   public ASTXor(int id) {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTXor(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */   
/*    */   public void jjtClose() {
/* 48 */     flattenTree();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 53 */     Object result = this._children[0].getValue(context, source);
/* 54 */     for (int i = 1; i < this._children.length; i++)
/* 55 */       result = OgnlOps.binaryXor(result, this._children[i].getValue(context, source)); 
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 61 */     return "^";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTXor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */