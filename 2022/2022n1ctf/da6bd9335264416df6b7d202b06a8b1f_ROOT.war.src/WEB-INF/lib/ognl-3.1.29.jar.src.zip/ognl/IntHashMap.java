/*     */ package ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntHashMap
/*     */   implements Map
/*     */ {
/*     */   private Entry[] table;
/*     */   private int count;
/*     */   private int threshold;
/*     */   private float loadFactor;
/*     */   
/*     */   private static class IntHashMapIterator
/*     */     implements Iterator
/*     */   {
/*     */     boolean keys;
/*     */     int index;
/*     */     IntHashMap.Entry[] table;
/*     */     IntHashMap.Entry entry;
/*     */     
/*     */     IntHashMapIterator(IntHashMap.Entry[] table, boolean keys) {
/*  65 */       this.table = table;
/*  66 */       this.keys = keys;
/*  67 */       this.index = table.length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  75 */       if (this.entry != null) {
/*  76 */         return true;
/*     */       }
/*  78 */       while (this.index-- > 0) {
/*  79 */         if ((this.entry = this.table[this.index]) != null) {
/*  80 */           return true;
/*     */         }
/*     */       } 
/*  83 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object next() {
/*  88 */       if (this.entry == null) {
/*  89 */         while (this.index-- > 0 && (this.entry = this.table[this.index]) == null);
/*     */       }
/*     */ 
/*     */       
/*  93 */       if (this.entry != null) {
/*  94 */         IntHashMap.Entry e = this.entry;
/*     */         
/*  96 */         this.entry = e.next;
/*  97 */         return this.keys ? new Integer(e.key) : e.value;
/*     */       } 
/*  99 */       throw new NoSuchElementException("IntHashMapIterator");
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 104 */       throw new UnsupportedOperationException("remove");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Entry
/*     */   {
/*     */     int hash;
/*     */ 
/*     */ 
/*     */     
/*     */     int key;
/*     */ 
/*     */ 
/*     */     
/*     */     Object value;
/*     */ 
/*     */     
/*     */     Entry next;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashMap(int initialCapacity, float loadFactor) {
/* 130 */     if (initialCapacity <= 0 || loadFactor <= 0.0D) {
/* 131 */       throw new IllegalArgumentException();
/*     */     }
/* 133 */     this.loadFactor = loadFactor;
/* 134 */     this.table = new Entry[initialCapacity];
/* 135 */     this.threshold = (int)(initialCapacity * loadFactor);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntHashMap(int initialCapacity) {
/* 140 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntHashMap() {
/* 145 */     this(101, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehash() {
/* 153 */     int oldCapacity = this.table.length;
/* 154 */     Entry[] oldTable = this.table;
/* 155 */     int newCapacity = oldCapacity * 2 + 1;
/* 156 */     Entry[] newTable = new Entry[newCapacity];
/*     */     
/* 158 */     this.threshold = (int)(newCapacity * this.loadFactor);
/* 159 */     this.table = newTable;
/* 160 */     for (int i = oldCapacity; i-- > 0;) {
/* 161 */       for (Entry old = oldTable[i]; old != null; ) {
/* 162 */         Entry e = old;
/* 163 */         int index = (e.hash & Integer.MAX_VALUE) % newCapacity;
/*     */         
/* 165 */         old = old.next;
/* 166 */         e.next = newTable[index];
/* 167 */         newTable[index] = e;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsKey(int key) {
/* 177 */     int index = (key & Integer.MAX_VALUE) % this.table.length;
/*     */     
/* 179 */     for (Entry e = this.table[index]; e != null; e = e.next) {
/* 180 */       if (e.hash == key && e.key == key) {
/* 181 */         return true;
/*     */       }
/*     */     } 
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object get(int key) {
/* 189 */     int index = (key & Integer.MAX_VALUE) % this.table.length;
/*     */     
/* 191 */     for (Entry e = this.table[index]; e != null; e = e.next) {
/* 192 */       if (e.hash == key && e.key == key) {
/* 193 */         return e.value;
/*     */       }
/*     */     } 
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object put(int key, Object value) {
/* 201 */     int index = (key & Integer.MAX_VALUE) % this.table.length;
/*     */     
/* 203 */     if (value == null)
/* 204 */       throw new IllegalArgumentException(); 
/*     */     Entry e;
/* 206 */     for (e = this.table[index]; e != null; e = e.next) {
/* 207 */       if (e.hash == key && e.key == key) {
/* 208 */         Object old = e.value;
/*     */         
/* 210 */         e.value = value;
/* 211 */         return old;
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     if (this.count >= this.threshold) {
/*     */       
/* 217 */       rehash();
/* 218 */       return put(key, value);
/*     */     } 
/*     */     
/* 221 */     e = new Entry();
/*     */     
/* 223 */     e.hash = key;
/* 224 */     e.key = key;
/* 225 */     e.value = value;
/* 226 */     e.next = this.table[index];
/* 227 */     this.table[index] = e;
/* 228 */     this.count++;
/* 229 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object remove(int key) {
/* 234 */     int index = (key & Integer.MAX_VALUE) % this.table.length;
/*     */     
/* 236 */     for (Entry e = this.table[index], prev = null; e != null; prev = e, e = e.next) {
/* 237 */       if (e.hash == key && e.key == key) {
/* 238 */         if (prev != null) {
/* 239 */           prev.next = e.next;
/*     */         } else {
/* 241 */           this.table[index] = e.next;
/*     */         } 
/* 243 */         this.count--;
/* 244 */         return e.value;
/*     */       } 
/*     */     } 
/* 247 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 255 */     return this.count;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 260 */     return (this.count == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 265 */     if (!(key instanceof Number)) {
/* 266 */       throw new IllegalArgumentException("key is not an Number subclass");
/*     */     }
/* 268 */     return get(((Number)key).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 273 */     if (!(key instanceof Number)) {
/* 274 */       throw new IllegalArgumentException("key cannot be null");
/*     */     }
/* 276 */     return put(((Number)key).intValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map otherMap) {
/* 281 */     for (Iterator it = otherMap.keySet().iterator(); it.hasNext(); ) {
/* 282 */       Object k = it.next();
/*     */       
/* 284 */       put(k, otherMap.get(k));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 290 */     if (!(key instanceof Number)) {
/* 291 */       throw new IllegalArgumentException("key cannot be null");
/*     */     }
/* 293 */     return remove(((Number)key).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 298 */     Entry[] tab = this.table;
/*     */     
/* 300 */     for (int index = tab.length; --index >= 0;) {
/* 301 */       tab[index] = null;
/*     */     }
/* 303 */     this.count = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 308 */     if (!(key instanceof Number)) {
/* 309 */       throw new InternalError("key is not an Number subclass");
/*     */     }
/* 311 */     return containsKey(((Number)key).intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 316 */     Entry[] tab = this.table;
/*     */     
/* 318 */     if (value == null) {
/* 319 */       throw new IllegalArgumentException();
/*     */     }
/* 321 */     for (int i = tab.length; i-- > 0;) {
/* 322 */       for (Entry e = tab[i]; e != null; e = e.next) {
/* 323 */         if (e.value.equals(value)) {
/* 324 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 328 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set keySet() {
/* 333 */     Set result = new HashSet();
/*     */     
/* 335 */     for (Iterator it = new IntHashMapIterator(this.table, true); it.hasNext();) {
/* 336 */       result.add(it.next());
/*     */     }
/* 338 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 343 */     List result = new ArrayList();
/*     */     
/* 345 */     for (Iterator it = new IntHashMapIterator(this.table, false); it.hasNext();) {
/* 346 */       result.add(it.next());
/*     */     }
/* 348 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/* 353 */     throw new UnsupportedOperationException("entrySet");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\IntHashMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */