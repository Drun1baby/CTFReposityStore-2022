/*     */ package ognl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*     */     Object result;
/*  51 */     Map map = (Map)target;
/*  52 */     Node currentNode = ((OgnlContext)context).getCurrentNode().jjtGetParent();
/*  53 */     boolean indexedAccess = false;
/*     */     
/*  55 */     if (currentNode == null) throw new OgnlException("node is null for '" + name + "'"); 
/*  56 */     if (!(currentNode instanceof ASTProperty)) {
/*  57 */       currentNode = currentNode.jjtGetParent();
/*     */     }
/*  59 */     if (currentNode instanceof ASTProperty) {
/*  60 */       indexedAccess = ((ASTProperty)currentNode).isIndexedAccess();
/*     */     }
/*     */     
/*  63 */     if (name instanceof String && !indexedAccess) {
/*  64 */       if (name.equals("size")) {
/*  65 */         result = new Integer(map.size());
/*     */       }
/*  67 */       else if (name.equals("keys") || name.equals("keySet")) {
/*  68 */         result = map.keySet();
/*     */       }
/*  70 */       else if (name.equals("values")) {
/*  71 */         result = map.values();
/*     */       }
/*  73 */       else if (name.equals("isEmpty")) {
/*  74 */         result = map.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */       } else {
/*  76 */         result = map.get(name);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  82 */       result = map.get(name);
/*     */     } 
/*     */     
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/*  91 */     Map<Object, Object> map = (Map)target;
/*  92 */     map.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/*  97 */     Node currentNode = context.getCurrentNode().jjtGetParent();
/*  98 */     boolean indexedAccess = false;
/*     */     
/* 100 */     if (currentNode == null) {
/* 101 */       throw new RuntimeException("node is null for '" + index + "'");
/*     */     }
/* 103 */     if (!(currentNode instanceof ASTProperty)) {
/* 104 */       currentNode = currentNode.jjtGetParent();
/*     */     }
/* 106 */     if (currentNode instanceof ASTProperty) {
/* 107 */       indexedAccess = ((ASTProperty)currentNode).isIndexedAccess();
/*     */     }
/* 109 */     String indexStr = index.toString();
/*     */     
/* 111 */     context.setCurrentAccessor(Map.class);
/* 112 */     context.setCurrentType(Object.class);
/*     */     
/* 114 */     if (String.class.isInstance(index) && !indexedAccess) {
/*     */       
/* 116 */       String key = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/*     */       
/* 118 */       if (key.equals("size")) {
/* 119 */         context.setCurrentType(int.class);
/* 120 */         return ".size()";
/* 121 */       }  if (key.equals("keys") || key.equals("keySet")) {
/* 122 */         context.setCurrentType(Set.class);
/* 123 */         return ".keySet()";
/* 124 */       }  if (key.equals("values")) {
/* 125 */         context.setCurrentType(Collection.class);
/* 126 */         return ".values()";
/* 127 */       }  if (key.equals("isEmpty")) {
/* 128 */         context.setCurrentType(boolean.class);
/* 129 */         return ".isEmpty()";
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     return ".get(" + indexStr + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/* 138 */     context.setCurrentAccessor(Map.class);
/* 139 */     context.setCurrentType(Object.class);
/*     */     
/* 141 */     String indexStr = index.toString();
/*     */     
/* 143 */     if (String.class.isInstance(index)) {
/*     */       
/* 145 */       String key = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/*     */       
/* 147 */       if (key.equals("size"))
/* 148 */         return ""; 
/* 149 */       if (key.equals("keys") || key.equals("keySet"))
/* 150 */         return ""; 
/* 151 */       if (key.equals("values"))
/* 152 */         return ""; 
/* 153 */       if (key.equals("isEmpty")) {
/* 154 */         return "";
/*     */       }
/*     */     } 
/* 157 */     return ".put(" + indexStr + ", $3)";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\MapPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */