/*    */ package ognl.enhance;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalReferenceImpl
/*    */   implements LocalReference
/*    */ {
/*    */   String _name;
/*    */   Class _type;
/*    */   String _expression;
/*    */   
/*    */   public LocalReferenceImpl(String name, String expression, Class type) {
/* 14 */     this._name = name;
/* 15 */     this._type = type;
/* 16 */     this._expression = expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 21 */     return this._name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpression() {
/* 26 */     return this._expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getType() {
/* 31 */     return this._type;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 36 */     if (this == o) return true; 
/* 37 */     if (o == null || getClass() != o.getClass()) return false;
/*    */     
/* 39 */     LocalReferenceImpl that = (LocalReferenceImpl)o;
/*    */     
/* 41 */     if ((this._expression != null) ? !this._expression.equals(that._expression) : (that._expression != null)) return false; 
/* 42 */     if ((this._name != null) ? !this._name.equals(that._name) : (that._name != null)) return false; 
/* 43 */     if ((this._type != null) ? !this._type.equals(that._type) : (that._type != null)) return false;
/*    */     
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int result = (this._name != null) ? this._name.hashCode() : 0;
/* 52 */     result = 31 * result + ((this._type != null) ? this._type.hashCode() : 0);
/* 53 */     result = 31 * result + ((this._expression != null) ? this._expression.hashCode() : 0);
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "LocalReferenceImpl[_name='" + this._name + '\'' + '\n' + ", _type=" + this._type + '\n' + ", _expression='" + this._expression + '\'' + '\n' + ']';
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\LocalReferenceImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */