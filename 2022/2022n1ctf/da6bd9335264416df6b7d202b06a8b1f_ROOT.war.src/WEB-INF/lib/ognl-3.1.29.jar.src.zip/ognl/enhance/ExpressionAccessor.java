package ognl.enhance;

import ognl.Node;
import ognl.OgnlContext;

public interface ExpressionAccessor {
  Object get(OgnlContext paramOgnlContext, Object paramObject);
  
  void set(OgnlContext paramOgnlContext, Object paramObject1, Object paramObject2);
  
  void setExpression(Node paramNode);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\ExpressionAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */