/*     */ package ognl.enhance;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtField;
/*     */ import javassist.CtMethod;
/*     */ import javassist.CtNewMethod;
/*     */ import javassist.NotFoundException;
/*     */ import ognl.ASTChain;
/*     */ import ognl.ASTConst;
/*     */ import ognl.ASTProperty;
/*     */ import ognl.ASTRootVarRef;
/*     */ import ognl.ASTStaticField;
/*     */ import ognl.ASTStaticMethod;
/*     */ import ognl.ASTVarRef;
/*     */ import ognl.ExpressionNode;
/*     */ import ognl.Node;
/*     */ import ognl.OgnlContext;
/*     */ 
/*     */ public class ExpressionCompiler implements OgnlExpressionCompiler {
/*  26 */   protected Map _loaders = new HashMap<>();
/*     */ 
/*     */   
/*     */   public static final String PRE_CAST = "_preCast";
/*     */   
/*     */   protected ClassPool _pool;
/*     */   
/*  33 */   protected int _classCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addCastString(OgnlContext context, String cast) {
/*  55 */     String value = (String)context.get("_preCast");
/*     */     
/*  57 */     if (value != null) {
/*  58 */       value = cast + value;
/*     */     } else {
/*  60 */       value = cast;
/*     */     } 
/*  62 */     context.put("_preCast", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCastString(Class type) {
/*  79 */     if (type == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     return type.isArray() ? (type.getComponentType().getName() + "[]") : type.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRootExpression(Node expression, Object root, OgnlContext context) {
/* 101 */     String rootExpr = "";
/*     */     
/* 103 */     if (!shouldCast(expression)) {
/* 104 */       return rootExpr;
/*     */     }
/* 106 */     if ((!ASTList.class.isInstance(expression) && !ASTVarRef.class.isInstance(expression) && !ASTStaticMethod.class.isInstance(expression) && !ASTStaticField.class.isInstance(expression) && !ASTConst.class.isInstance(expression) && !ExpressionNode.class.isInstance(expression) && !ASTCtor.class.isInstance(expression) && !ASTStaticMethod.class.isInstance(expression) && root != null) || (root != null && ASTRootVarRef.class.isInstance(expression))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       Class castClass = OgnlRuntime.getCompiler().getRootExpressionClass(expression, context);
/*     */       
/* 118 */       if (castClass.isArray() || ASTRootVarRef.class.isInstance(expression) || ASTThisVarRef.class.isInstance(expression)) {
/*     */ 
/*     */         
/* 121 */         rootExpr = "((" + getCastString(castClass) + ")$2)";
/*     */         
/* 123 */         if (ASTProperty.class.isInstance(expression) && !((ASTProperty)expression).isIndexedAccess())
/* 124 */           rootExpr = rootExpr + "."; 
/* 125 */       } else if ((ASTProperty.class.isInstance(expression) && ((ASTProperty)expression).isIndexedAccess()) || ASTChain.class.isInstance(expression)) {
/*     */ 
/*     */ 
/*     */         
/* 129 */         rootExpr = "((" + getCastString(castClass) + ")$2)";
/*     */       } else {
/*     */         
/* 132 */         rootExpr = "((" + getCastString(castClass) + ")$2).";
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     return rootExpr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean shouldCast(Node expression) {
/* 149 */     if (ASTChain.class.isInstance(expression)) {
/*     */       
/* 151 */       Node child = expression.jjtGetChild(0);
/* 152 */       if (ASTConst.class.isInstance(child) || ASTStaticMethod.class.isInstance(child) || ASTStaticField.class.isInstance(child) || (ASTVarRef.class.isInstance(child) && !ASTRootVarRef.class.isInstance(child)))
/*     */       {
/*     */ 
/*     */         
/* 156 */         return false;
/*     */       }
/*     */     } 
/* 159 */     return !ASTConst.class.isInstance(expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String castExpression(OgnlContext context, Node expression, String body) {
/* 166 */     if (context.getCurrentAccessor() == null || context.getPreviousType() == null || context.getCurrentAccessor().isAssignableFrom(context.getPreviousType()) || (context.getCurrentType() != null && context.getCurrentObject() != null && context.getCurrentType().isAssignableFrom(context.getCurrentObject().getClass()) && context.getCurrentAccessor().isAssignableFrom(context.getPreviousType())) || body == null || body.trim().length() < 1 || (context.getCurrentType() != null && context.getCurrentType().isArray() && (context.getPreviousType() == null || context.getPreviousType() != Object.class)) || ASTOr.class.isInstance(expression) || ASTAnd.class.isInstance(expression) || ASTRootVarRef.class.isInstance(expression) || context.getCurrentAccessor() == Class.class || (context.get("_preCast") != null && ((String)context.get("_preCast")).startsWith("new")) || ASTStaticField.class.isInstance(expression) || ASTStaticMethod.class.isInstance(expression) || (OrderedReturn.class.isInstance(expression) && ((OrderedReturn)expression).getLastExpression() != null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 184 */       return body;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     addCastString(context, "((" + getCastString(context.getCurrentAccessor()) + ")");
/*     */     
/* 194 */     return ")" + body;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName(Class clazz) {
/* 199 */     if (clazz.getName().equals("java.util.AbstractList$Itr")) {
/* 200 */       return Iterator.class.getName();
/*     */     }
/* 202 */     if (Modifier.isPublic(clazz.getModifiers()) && clazz.isInterface()) {
/* 203 */       return clazz.getName();
/*     */     }
/* 205 */     return _getClassName(clazz, clazz.getInterfaces());
/*     */   }
/*     */ 
/*     */   
/*     */   private String _getClassName(Class clazz, Class[] intf) {
/* 210 */     for (int i = 0; i < intf.length; i++) {
/*     */       
/* 212 */       if (intf[i].getName().indexOf("util.List") > 0)
/* 213 */         return intf[i].getName(); 
/* 214 */       if (intf[i].getName().indexOf("Iterator") > 0) {
/* 215 */         return intf[i].getName();
/*     */       }
/*     */     } 
/* 218 */     Class superclazz = clazz.getSuperclass();
/* 219 */     if (superclazz != null) {
/*     */       
/* 221 */       Class[] superclazzIntf = superclazz.getInterfaces();
/* 222 */       if (superclazzIntf.length > 0) {
/* 223 */         return _getClassName(superclazz, superclazzIntf);
/*     */       }
/*     */     } 
/* 226 */     return clazz.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSuperOrInterfaceClass(Method m, Class clazz) {
/* 231 */     Class[] intfs = clazz.getInterfaces();
/* 232 */     if (intfs != null && intfs.length > 0)
/*     */     {
/*     */ 
/*     */       
/* 236 */       for (int i = 0; i < intfs.length; i++) {
/*     */         
/* 238 */         Class intClass = getSuperOrInterfaceClass(m, intfs[i]);
/*     */         
/* 240 */         if (intClass != null) {
/* 241 */           return intClass;
/*     */         }
/* 243 */         if (Modifier.isPublic(intfs[i].getModifiers()) && containsMethod(m, intfs[i])) {
/* 244 */           return intfs[i];
/*     */         }
/*     */       } 
/*     */     }
/* 248 */     if (clazz.getSuperclass() != null) {
/*     */       
/* 250 */       Class superClass = getSuperOrInterfaceClass(m, clazz.getSuperclass());
/*     */       
/* 252 */       if (superClass != null) {
/* 253 */         return superClass;
/*     */       }
/*     */     } 
/* 256 */     if (Modifier.isPublic(clazz.getModifiers()) && containsMethod(m, clazz)) {
/* 257 */       return clazz;
/*     */     }
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsMethod(Method m, Class clazz) {
/* 274 */     Method[] methods = clazz.getMethods();
/*     */     
/* 276 */     if (methods == null) {
/* 277 */       return false;
/*     */     }
/* 279 */     for (int i = 0; i < methods.length; i++) {
/*     */       
/* 281 */       if (methods[i].getName().equals(m.getName()) && methods[i].getReturnType() == m.getReturnType()) {
/*     */ 
/*     */         
/* 284 */         Class[] parms = m.getParameterTypes();
/* 285 */         if (parms != null) {
/*     */ 
/*     */           
/* 288 */           Class[] mparms = methods[i].getParameterTypes();
/* 289 */           if (mparms != null && mparms.length == parms.length) {
/*     */ 
/*     */             
/* 292 */             boolean parmsMatch = true;
/* 293 */             for (int p = 0; p < parms.length; p++) {
/*     */               
/* 295 */               if (parms[p] != mparms[p]) {
/*     */                 
/* 297 */                 parmsMatch = false;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 302 */             if (parmsMatch)
/*     */             
/*     */             { 
/* 305 */               Class[] exceptions = m.getExceptionTypes();
/* 306 */               if (exceptions != null)
/*     */               
/*     */               { 
/* 309 */                 Class[] mexceptions = methods[i].getExceptionTypes();
/* 310 */                 if (mexceptions != null && mexceptions.length == exceptions.length)
/*     */                 
/*     */                 { 
/* 313 */                   boolean exceptionsMatch = true;
/* 314 */                   for (int e = 0; e < exceptions.length; e++) {
/*     */                     
/* 316 */                     if (exceptions[e] != mexceptions[e]) {
/*     */                       
/* 318 */                       exceptionsMatch = false;
/*     */                       
/*     */                       break;
/*     */                     } 
/*     */                   } 
/* 323 */                   if (exceptionsMatch)
/*     */                   {
/*     */                     
/* 326 */                     return true; }  }  }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 330 */     }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getInterfaceClass(Class clazz) {
/* 335 */     if (clazz.getName().equals("java.util.AbstractList$Itr")) {
/* 336 */       return Iterator.class;
/*     */     }
/* 338 */     if ((Modifier.isPublic(clazz.getModifiers()) && clazz.isInterface()) || clazz.isPrimitive())
/*     */     {
/* 340 */       return clazz;
/*     */     }
/* 342 */     return _getInterfaceClass(clazz, clazz.getInterfaces());
/*     */   }
/*     */ 
/*     */   
/*     */   private Class _getInterfaceClass(Class clazz, Class[] intf) {
/* 347 */     for (int i = 0; i < intf.length; i++) {
/*     */       
/* 349 */       if (List.class.isAssignableFrom(intf[i]))
/* 350 */         return List.class; 
/* 351 */       if (Iterator.class.isAssignableFrom(intf[i]))
/* 352 */         return Iterator.class; 
/* 353 */       if (Map.class.isAssignableFrom(intf[i]))
/* 354 */         return Map.class; 
/* 355 */       if (Set.class.isAssignableFrom(intf[i]))
/* 356 */         return Set.class; 
/* 357 */       if (Collection.class.isAssignableFrom(intf[i])) {
/* 358 */         return Collection.class;
/*     */       }
/*     */     } 
/* 361 */     Class superclazz = clazz.getSuperclass();
/* 362 */     if (superclazz != null) {
/*     */       
/* 364 */       Class[] superclazzIntf = superclazz.getInterfaces();
/* 365 */       if (superclazzIntf.length > 0) {
/* 366 */         return _getInterfaceClass(superclazz, superclazzIntf);
/*     */       }
/*     */     } 
/* 369 */     return clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getRootExpressionClass(Node rootNode, OgnlContext context) {
/* 374 */     if (context.getRoot() == null) {
/* 375 */       return null;
/*     */     }
/* 377 */     Class<?> ret = context.getRoot().getClass();
/*     */     
/* 379 */     if (context.getFirstAccessor() != null && context.getFirstAccessor().isInstance(context.getRoot()))
/*     */     {
/* 381 */       ret = context.getFirstAccessor();
/*     */     }
/*     */     
/* 384 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compileExpression(OgnlContext context, Node expression, Object root) throws Exception {
/*     */     String getBody, setBody;
/* 395 */     if (expression.getAccessor() != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 400 */     EnhancedClassLoader loader = getClassLoader(context);
/* 401 */     ClassPool pool = getClassPool(context, loader);
/*     */     
/* 403 */     CtClass newClass = pool.makeClass(expression.getClass().getName() + expression.hashCode() + this._classCounter++ + "Accessor");
/* 404 */     newClass.addInterface(getCtClass(ExpressionAccessor.class));
/*     */     
/* 406 */     CtClass ognlClass = getCtClass(OgnlContext.class);
/* 407 */     CtClass objClass = getCtClass(Object.class);
/*     */     
/* 409 */     CtMethod valueGetter = new CtMethod(objClass, "get", new CtClass[] { ognlClass, objClass }, newClass);
/* 410 */     CtMethod valueSetter = new CtMethod(CtClass.voidType, "set", new CtClass[] { ognlClass, objClass, objClass }, newClass);
/*     */     
/* 412 */     CtField nodeMember = null;
/*     */     
/* 414 */     CtClass nodeClass = getCtClass(Node.class);
/* 415 */     CtMethod setExpression = null;
/*     */ 
/*     */     
/*     */     try {
/* 419 */       getBody = generateGetter(context, newClass, objClass, pool, valueGetter, expression, root);
/*     */     }
/* 421 */     catch (UnsupportedCompilationException uc) {
/*     */ 
/*     */ 
/*     */       
/* 425 */       nodeMember = new CtField(nodeClass, "_node", newClass);
/* 426 */       newClass.addField(nodeMember);
/*     */       
/* 428 */       getBody = generateOgnlGetter(newClass, valueGetter, nodeMember);
/*     */       
/* 430 */       if (setExpression == null) {
/*     */         
/* 432 */         setExpression = CtNewMethod.setter("setExpression", nodeMember);
/* 433 */         newClass.addMethod(setExpression);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 439 */       setBody = generateSetter(context, newClass, objClass, pool, valueSetter, expression, root);
/*     */     }
/* 441 */     catch (UnsupportedCompilationException uc) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 446 */       if (nodeMember == null) {
/*     */         
/* 448 */         nodeMember = new CtField(nodeClass, "_node", newClass);
/* 449 */         newClass.addField(nodeMember);
/*     */       } 
/*     */       
/* 452 */       setBody = generateOgnlSetter(newClass, valueSetter, nodeMember);
/*     */       
/* 454 */       if (setExpression == null) {
/*     */         
/* 456 */         setExpression = CtNewMethod.setter("setExpression", nodeMember);
/* 457 */         newClass.addMethod(setExpression);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 462 */       newClass.addConstructor(CtNewConstructor.defaultConstructor(newClass));
/*     */       
/* 464 */       Class<ExpressionAccessor> clazz = pool.toClass(newClass);
/* 465 */       newClass.detach();
/*     */       
/* 467 */       expression.setAccessor(clazz.newInstance());
/*     */ 
/*     */ 
/*     */       
/* 471 */       if (nodeMember != null)
/*     */       {
/* 473 */         expression.getAccessor().setExpression(expression);
/*     */       }
/*     */     }
/* 476 */     catch (Throwable t) {
/*     */ 
/*     */       
/* 479 */       throw new RuntimeException("Error compiling expression on object " + root + " with expression node " + expression + " getter body: " + getBody + " setter body: " + setBody, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateGetter(OgnlContext context, CtClass newClass, CtClass objClass, ClassPool pool, CtMethod valueGetter, Node expression, Object root) throws Exception {
/* 490 */     String body, pre = "";
/* 491 */     String post = "";
/*     */ 
/*     */     
/* 494 */     context.setRoot(root);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 499 */     context.remove("_preCast");
/*     */ 
/*     */ 
/*     */     
/* 503 */     String getterCode = expression.toGetSourceString(context, root);
/*     */     
/* 505 */     if (getterCode == null || (getterCode.trim().length() <= 0 && !ASTVarRef.class.isAssignableFrom(expression.getClass())))
/*     */     {
/* 507 */       getterCode = "null";
/*     */     }
/* 509 */     String castExpression = (String)context.get("_preCast");
/*     */     
/* 511 */     if (context.getCurrentType() == null || context.getCurrentType().isPrimitive() || Character.class.isAssignableFrom(context.getCurrentType()) || Object.class == context.getCurrentType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 516 */       pre = pre + " ($w) (";
/* 517 */       post = post + ")";
/*     */     } 
/*     */     
/* 520 */     String rootExpr = !getterCode.equals("null") ? getRootExpression(expression, root, context) : "";
/*     */     
/* 522 */     String noRoot = (String)context.remove("_noRoot");
/* 523 */     if (noRoot != null) {
/* 524 */       rootExpr = "";
/*     */     }
/* 526 */     createLocalReferences(context, pool, newClass, objClass, valueGetter.getParameterTypes());
/*     */     
/* 528 */     if (OrderedReturn.class.isInstance(expression) && ((OrderedReturn)expression).getLastExpression() != null) {
/*     */       
/* 530 */       body = "{ " + ((ASTMethod.class.isInstance(expression) || ASTChain.class.isInstance(expression)) ? rootExpr : "") + ((castExpression != null) ? castExpression : "") + ((OrderedReturn)expression).getCoreExpression() + " return " + pre + ((OrderedReturn)expression).getLastExpression() + post + ";}";
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 540 */       body = "{  return " + pre + ((castExpression != null) ? castExpression : "") + rootExpr + getterCode + post + ";}";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     if (body.indexOf("..") >= 0) {
/* 550 */       body = body.replaceAll("\\.\\.", ".");
/*     */     }
/*     */     
/* 553 */     valueGetter.setBody(body);
/* 554 */     newClass.addMethod(valueGetter);
/*     */     
/* 556 */     return body;
/*     */   }
/*     */ 
/*     */   
/*     */   public String createLocalReference(OgnlContext context, String expression, Class type) {
/* 561 */     String referenceName = "ref" + context.incrementLocalReferenceCounter();
/* 562 */     context.addLocalReference(referenceName, new LocalReferenceImpl(referenceName, expression, type));
/*     */     
/* 564 */     String castString = "";
/* 565 */     if (!type.isPrimitive()) {
/* 566 */       castString = "(" + getCastString(type) + ") ";
/*     */     }
/* 568 */     return castString + referenceName + "($$)";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void createLocalReferences(OgnlContext context, ClassPool pool, CtClass clazz, CtClass objClass, CtClass[] params) throws CannotCompileException, NotFoundException {
/* 574 */     Map referenceMap = context.getLocalReferences();
/* 575 */     if (referenceMap == null || referenceMap.size() < 1) {
/*     */       return;
/*     */     }
/* 578 */     Iterator<LocalReference> it = referenceMap.values().iterator();
/*     */     
/* 580 */     while (it.hasNext()) {
/*     */       
/* 582 */       LocalReference ref = it.next();
/*     */       
/* 584 */       String widener = ref.getType().isPrimitive() ? " " : " ($w) ";
/*     */       
/* 586 */       String body = "{";
/* 587 */       body = body + " return  " + widener + ref.getExpression() + ";";
/* 588 */       body = body + "}";
/*     */       
/* 590 */       if (body.indexOf("..") >= 0) {
/* 591 */         body = body.replaceAll("\\.\\.", ".");
/*     */       }
/*     */ 
/*     */       
/* 595 */       CtMethod method = new CtMethod(pool.get(getCastString(ref.getType())), ref.getName(), params, clazz);
/* 596 */       method.setBody(body);
/*     */       
/* 598 */       clazz.addMethod(method);
/*     */       
/* 600 */       it.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateSetter(OgnlContext context, CtClass newClass, CtClass objClass, ClassPool pool, CtMethod valueSetter, Node expression, Object root) throws Exception {
/* 608 */     if (ExpressionNode.class.isInstance(expression) || ASTConst.class.isInstance(expression))
/*     */     {
/* 610 */       throw new UnsupportedCompilationException("Can't compile expression/constant setters.");
/*     */     }
/* 612 */     context.setRoot(root);
/* 613 */     context.remove("_preCast");
/*     */ 
/*     */ 
/*     */     
/* 617 */     String setterCode = expression.toSetSourceString(context, root);
/* 618 */     String castExpression = (String)context.get("_preCast");
/*     */     
/* 620 */     if (setterCode == null || setterCode.trim().length() < 1) {
/* 621 */       throw new UnsupportedCompilationException("Can't compile null setter body.");
/*     */     }
/* 623 */     if (root == null) {
/* 624 */       throw new UnsupportedCompilationException("Can't compile setters with a null root object.");
/*     */     }
/* 626 */     String pre = getRootExpression(expression, root, context);
/*     */     
/* 628 */     String noRoot = (String)context.remove("_noRoot");
/* 629 */     if (noRoot != null) {
/* 630 */       pre = "";
/*     */     }
/* 632 */     createLocalReferences(context, pool, newClass, objClass, valueSetter.getParameterTypes());
/*     */     
/* 634 */     String body = "{" + ((castExpression != null) ? castExpression : "") + pre + setterCode + ";}";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 639 */     if (body.indexOf("..") >= 0) {
/* 640 */       body = body.replaceAll("\\.\\.", ".");
/*     */     }
/*     */ 
/*     */     
/* 644 */     valueSetter.setBody(body);
/* 645 */     newClass.addMethod(valueSetter);
/*     */     
/* 647 */     return body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateOgnlGetter(CtClass clazz, CtMethod valueGetter, CtField node) throws Exception {
/* 668 */     String body = "return " + node.getName() + ".getValue($1, $2);";
/*     */     
/* 670 */     valueGetter.setBody(body);
/* 671 */     clazz.addMethod(valueGetter);
/*     */     
/* 673 */     return body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String generateOgnlSetter(CtClass clazz, CtMethod valueSetter, CtField node) throws Exception {
/* 694 */     String body = node.getName() + ".setValue($1, $2, $3);";
/*     */     
/* 696 */     valueSetter.setBody(body);
/* 697 */     clazz.addMethod(valueSetter);
/*     */     
/* 699 */     return body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EnhancedClassLoader getClassLoader(OgnlContext context) {
/* 713 */     EnhancedClassLoader ret = (EnhancedClassLoader)this._loaders.get(context.getClassResolver());
/*     */     
/* 715 */     if (ret != null) {
/* 716 */       return ret;
/*     */     }
/* 718 */     ClassLoader classLoader = new ContextClassLoader(OgnlContext.class.getClassLoader(), context);
/*     */     
/* 720 */     ret = new EnhancedClassLoader(classLoader);
/* 721 */     this._loaders.put(context.getClassResolver(), ret);
/*     */     
/* 723 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CtClass getCtClass(Class searchClass) throws NotFoundException {
/* 738 */     return this._pool.get(searchClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassPool getClassPool(OgnlContext context, EnhancedClassLoader loader) {
/* 754 */     if (this._pool != null) {
/* 755 */       return this._pool;
/*     */     }
/* 757 */     this._pool = ClassPool.getDefault();
/* 758 */     this._pool.insertClassPath((ClassPath)new LoaderClassPath(loader.getParent()));
/*     */     
/* 760 */     return this._pool;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\ExpressionCompiler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */