package ognl.enhance;

import java.lang.reflect.Method;
import ognl.Node;
import ognl.OgnlContext;

public interface OgnlExpressionCompiler {
  public static final String ROOT_TYPE = "-ognl-root-type";
  
  void compileExpression(OgnlContext paramOgnlContext, Node paramNode, Object paramObject) throws Exception;
  
  String getClassName(Class paramClass);
  
  Class getInterfaceClass(Class paramClass);
  
  Class getSuperOrInterfaceClass(Method paramMethod, Class paramClass);
  
  Class getRootExpressionClass(Node paramNode, OgnlContext paramOgnlContext);
  
  String castExpression(OgnlContext paramOgnlContext, Node paramNode, String paramString);
  
  String createLocalReference(OgnlContext paramOgnlContext, String paramString, Class paramClass);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\OgnlExpressionCompiler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */