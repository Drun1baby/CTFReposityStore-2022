/*    */ package ognl.enhance;
/*    */ 
/*    */ import java.util.Map;
/*    */ import ognl.OgnlContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextClassLoader
/*    */   extends ClassLoader
/*    */ {
/*    */   private OgnlContext context;
/*    */   
/*    */   public ContextClassLoader(ClassLoader parentClassLoader, OgnlContext context) {
/* 44 */     super(parentClassLoader);
/* 45 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class findClass(String name) throws ClassNotFoundException {
/* 53 */     if (this.context != null && this.context.getClassResolver() != null) {
/* 54 */       return this.context.getClassResolver().classForName(name, (Map)this.context);
/*    */     }
/* 56 */     return super.findClass(name);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\ContextClassLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */