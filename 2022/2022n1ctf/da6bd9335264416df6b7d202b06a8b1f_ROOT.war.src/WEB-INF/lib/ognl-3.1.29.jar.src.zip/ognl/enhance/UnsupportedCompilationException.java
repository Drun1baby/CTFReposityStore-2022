/*    */ package ognl.enhance;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedCompilationException
/*    */   extends RuntimeException
/*    */ {
/*    */   public UnsupportedCompilationException(String message) {
/* 22 */     super(message);
/*    */   }
/*    */ 
/*    */   
/*    */   public UnsupportedCompilationException(String message, Throwable cause) {
/* 27 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\enhance\UnsupportedCompilationException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */