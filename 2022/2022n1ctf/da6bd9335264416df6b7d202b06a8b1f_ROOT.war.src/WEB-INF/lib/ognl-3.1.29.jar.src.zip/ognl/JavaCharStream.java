/*     */ package ognl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ public class JavaCharStream
/*     */ {
/*     */   public static final boolean staticFlag = false;
/*     */   
/*     */   static final int hexval(char c) throws IOException {
/*  15 */     switch (c) {
/*     */       
/*     */       case '0':
/*  18 */         return 0;
/*     */       case '1':
/*  20 */         return 1;
/*     */       case '2':
/*  22 */         return 2;
/*     */       case '3':
/*  24 */         return 3;
/*     */       case '4':
/*  26 */         return 4;
/*     */       case '5':
/*  28 */         return 5;
/*     */       case '6':
/*  30 */         return 6;
/*     */       case '7':
/*  32 */         return 7;
/*     */       case '8':
/*  34 */         return 8;
/*     */       case '9':
/*  36 */         return 9;
/*     */       
/*     */       case 'A':
/*     */       case 'a':
/*  40 */         return 10;
/*     */       case 'B':
/*     */       case 'b':
/*  43 */         return 11;
/*     */       case 'C':
/*     */       case 'c':
/*  46 */         return 12;
/*     */       case 'D':
/*     */       case 'd':
/*  49 */         return 13;
/*     */       case 'E':
/*     */       case 'e':
/*  52 */         return 14;
/*     */       case 'F':
/*     */       case 'f':
/*  55 */         return 15;
/*     */     } 
/*     */     
/*  58 */     throw new IOException();
/*     */   }
/*     */ 
/*     */   
/*  62 */   public int bufpos = -1;
/*     */   
/*     */   int bufsize;
/*     */   int available;
/*     */   int tokenBegin;
/*     */   protected int[] bufline;
/*     */   protected int[] bufcolumn;
/*  69 */   protected int column = 0;
/*  70 */   protected int line = 1;
/*     */   
/*     */   protected boolean prevCharIsCR = false;
/*     */   
/*     */   protected boolean prevCharIsLF = false;
/*     */   
/*     */   protected Reader inputStream;
/*     */   protected char[] nextCharBuf;
/*     */   protected char[] buffer;
/*  79 */   protected int maxNextCharInd = 0;
/*  80 */   protected int nextCharInd = -1;
/*  81 */   protected int inBuf = 0;
/*  82 */   protected int tabSize = 8;
/*     */   
/*  84 */   protected void setTabSize(int i) { this.tabSize = i; } protected int getTabSize(int i) {
/*  85 */     return this.tabSize;
/*     */   }
/*     */   
/*     */   protected void ExpandBuff(boolean wrapAround) {
/*  89 */     char[] newbuffer = new char[this.bufsize + 2048];
/*  90 */     int[] newbufline = new int[this.bufsize + 2048];
/*  91 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*     */ 
/*     */     
/*     */     try {
/*  95 */       if (wrapAround)
/*     */       {
/*  97 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  98 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*     */         
/* 100 */         this.buffer = newbuffer;
/*     */         
/* 102 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/* 103 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/* 104 */         this.bufline = newbufline;
/*     */         
/* 106 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/* 107 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/* 108 */         this.bufcolumn = newbufcolumn;
/*     */         
/* 110 */         this.bufpos += this.bufsize - this.tokenBegin;
/*     */       }
/*     */       else
/*     */       {
/* 114 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/* 115 */         this.buffer = newbuffer;
/*     */         
/* 117 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/* 118 */         this.bufline = newbufline;
/*     */         
/* 120 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/* 121 */         this.bufcolumn = newbufcolumn;
/*     */         
/* 123 */         this.bufpos -= this.tokenBegin;
/*     */       }
/*     */     
/* 126 */     } catch (Throwable t) {
/*     */       
/* 128 */       throw new Error(t.getMessage());
/*     */     } 
/*     */     
/* 131 */     this.available = this.bufsize += 2048;
/* 132 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void FillBuff() throws IOException {
/* 138 */     if (this.maxNextCharInd == 4096)
/* 139 */       this.maxNextCharInd = this.nextCharInd = 0; 
/*     */     try {
/*     */       int i;
/* 142 */       if ((i = this.inputStream.read(this.nextCharBuf, this.maxNextCharInd, 4096 - this.maxNextCharInd)) == -1) {
/*     */ 
/*     */         
/* 145 */         this.inputStream.close();
/* 146 */         throw new IOException();
/*     */       } 
/*     */       
/* 149 */       this.maxNextCharInd += i;
/*     */       
/*     */       return;
/* 152 */     } catch (IOException e) {
/* 153 */       if (this.bufpos != 0) {
/*     */         
/* 155 */         this.bufpos--;
/* 156 */         backup(0);
/*     */       }
/*     */       else {
/*     */         
/* 160 */         this.bufline[this.bufpos] = this.line;
/* 161 */         this.bufcolumn[this.bufpos] = this.column;
/*     */       } 
/* 163 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected char ReadByte() throws IOException {
/* 169 */     if (++this.nextCharInd >= this.maxNextCharInd) {
/* 170 */       FillBuff();
/*     */     }
/* 172 */     return this.nextCharBuf[this.nextCharInd];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char BeginToken() throws IOException {
/* 183 */     if (this.inBuf > 0) {
/*     */       
/* 185 */       this.inBuf--;
/*     */       
/* 187 */       if (++this.bufpos == this.bufsize) {
/* 188 */         this.bufpos = 0;
/*     */       }
/* 190 */       this.tokenBegin = this.bufpos;
/* 191 */       return this.buffer[this.bufpos];
/*     */     } 
/*     */     
/* 194 */     this.tokenBegin = 0;
/* 195 */     this.bufpos = -1;
/*     */     
/* 197 */     return readChar();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void AdjustBuffSize() {
/* 202 */     if (this.available == this.bufsize) {
/*     */       
/* 204 */       if (this.tokenBegin > 2048) {
/*     */         
/* 206 */         this.bufpos = 0;
/* 207 */         this.available = this.tokenBegin;
/*     */       } else {
/*     */         
/* 210 */         ExpandBuff(false);
/*     */       } 
/* 212 */     } else if (this.available > this.tokenBegin) {
/* 213 */       this.available = this.bufsize;
/* 214 */     } else if (this.tokenBegin - this.available < 2048) {
/* 215 */       ExpandBuff(true);
/*     */     } else {
/* 217 */       this.available = this.tokenBegin;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void UpdateLineColumn(char c) {
/* 222 */     this.column++;
/*     */     
/* 224 */     if (this.prevCharIsLF) {
/*     */       
/* 226 */       this.prevCharIsLF = false;
/* 227 */       this.line += this.column = 1;
/*     */     }
/* 229 */     else if (this.prevCharIsCR) {
/*     */       
/* 231 */       this.prevCharIsCR = false;
/* 232 */       if (c == '\n') {
/*     */         
/* 234 */         this.prevCharIsLF = true;
/*     */       } else {
/*     */         
/* 237 */         this.line += this.column = 1;
/*     */       } 
/*     */     } 
/* 240 */     switch (c) {
/*     */       
/*     */       case '\r':
/* 243 */         this.prevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 246 */         this.prevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 249 */         this.column--;
/* 250 */         this.column += this.tabSize - this.column % this.tabSize;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.bufline[this.bufpos] = this.line;
/* 257 */     this.bufcolumn[this.bufpos] = this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 268 */     if (this.inBuf > 0) {
/*     */       
/* 270 */       this.inBuf--;
/*     */       
/* 272 */       if (++this.bufpos == this.bufsize) {
/* 273 */         this.bufpos = 0;
/*     */       }
/* 275 */       return this.buffer[this.bufpos];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 280 */     if (++this.bufpos == this.available) {
/* 281 */       AdjustBuffSize();
/*     */     }
/* 283 */     char c = ReadByte(); if ((c = ReadByte()) == '\\') {
/*     */       
/* 285 */       UpdateLineColumn(c);
/*     */       
/* 287 */       int backSlashCnt = 1;
/*     */ 
/*     */       
/*     */       while (true) {
/* 291 */         if (++this.bufpos == this.available) {
/* 292 */           AdjustBuffSize();
/*     */         }
/*     */         
/*     */         try {
/* 296 */           this.buffer[this.bufpos] = c = ReadByte(); if ((c = ReadByte()) != '\\') {
/*     */             
/* 298 */             UpdateLineColumn(c);
/*     */             
/* 300 */             if (c == 'u' && (backSlashCnt & 0x1) == 1) {
/*     */               
/* 302 */               if (--this.bufpos < 0) {
/* 303 */                 this.bufpos = this.bufsize - 1;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } else {
/* 308 */               backup(backSlashCnt);
/* 309 */               return '\\';
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 320 */             UpdateLineColumn(c);
/* 321 */             backSlashCnt++;
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } catch (IOException e) {
/*     */           if (backSlashCnt > 1) {
/*     */             backup(backSlashCnt - 1);
/*     */           }
/*     */ 
/*     */           
/*     */           return '\\';
/*     */         } 
/*     */         
/*     */         try {
/*     */           break;
/* 337 */         } catch (IOException e) {
/*     */           
/* 339 */           throw new Error("Invalid escape character at line " + this.line + " column " + this.column + ".");
/*     */         } 
/*     */       }  while ((c = ReadByte()) == 'u')
/*     */         this.column++;  this.buffer[this.bufpos] = c = (char)(hexval(c) << 12 | hexval(ReadByte()) << 8 | hexval(ReadByte()) << 4 | hexval(ReadByte())); this.column += 4;
/* 343 */       if (backSlashCnt == 1) {
/* 344 */         return c;
/*     */       }
/*     */       
/* 347 */       backup(backSlashCnt - 1);
/* 348 */       return '\\';
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 353 */     UpdateLineColumn(c);
/* 354 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 366 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 377 */     return this.bufline[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndColumn() {
/* 386 */     return this.bufcolumn[this.bufpos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndLine() {
/* 395 */     return this.bufline[this.bufpos];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBeginColumn() {
/* 400 */     return this.bufcolumn[this.tokenBegin];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBeginLine() {
/* 405 */     return this.bufline[this.tokenBegin];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void backup(int amount) {
/* 415 */     this.inBuf += amount;
/* 416 */     if ((this.bufpos -= amount) < 0) {
/* 417 */       this.bufpos += this.bufsize;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 431 */     this.inputStream = dstream;
/* 432 */     this.line = startline;
/* 433 */     this.column = startcolumn - 1;
/*     */     
/* 435 */     this.available = this.bufsize = buffersize;
/* 436 */     this.buffer = new char[buffersize];
/* 437 */     this.bufline = new int[buffersize];
/* 438 */     this.bufcolumn = new int[buffersize];
/* 439 */     this.nextCharBuf = new char[4096];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(Reader dstream, int startline, int startcolumn) {
/* 452 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(Reader dstream) {
/* 462 */     this(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 476 */     this.inputStream = dstream;
/* 477 */     this.line = startline;
/* 478 */     this.column = startcolumn - 1;
/*     */     
/* 480 */     if (this.buffer == null || buffersize != this.buffer.length) {
/*     */       
/* 482 */       this.available = this.bufsize = buffersize;
/* 483 */       this.buffer = new char[buffersize];
/* 484 */       this.bufline = new int[buffersize];
/* 485 */       this.bufcolumn = new int[buffersize];
/* 486 */       this.nextCharBuf = new char[4096];
/*     */     } 
/* 488 */     this.prevCharIsLF = this.prevCharIsCR = false;
/* 489 */     this.tokenBegin = this.inBuf = this.maxNextCharInd = 0;
/* 490 */     this.nextCharInd = this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn) {
/* 503 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream) {
/* 513 */     ReInit(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize) throws UnsupportedEncodingException {
/* 529 */     this((encoding == null) ? new InputStreamReader(dstream) : new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 543 */     this(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream, String encoding, int startline, int startcolumn) throws UnsupportedEncodingException {
/* 558 */     this(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream, int startline, int startcolumn) {
/* 571 */     this(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream, String encoding) throws UnsupportedEncodingException {
/* 583 */     this(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaCharStream(InputStream dstream) {
/* 593 */     this(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn, int buffersize) throws UnsupportedEncodingException {
/* 609 */     ReInit((encoding == null) ? new InputStreamReader(dstream) : new InputStreamReader(dstream, encoding), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 623 */     ReInit(new InputStreamReader(dstream), startline, startcolumn, buffersize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding, int startline, int startcolumn) throws UnsupportedEncodingException {
/* 638 */     ReInit(dstream, encoding, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, int startline, int startcolumn) {
/* 651 */     ReInit(dstream, startline, startcolumn, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream, String encoding) throws UnsupportedEncodingException {
/* 663 */     ReInit(dstream, encoding, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(InputStream dstream) {
/* 673 */     ReInit(dstream, 1, 1, 4096);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String GetImage() {
/* 679 */     if (this.bufpos >= this.tokenBegin) {
/* 680 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/* 682 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] GetSuffix(int len) {
/* 694 */     char[] ret = new char[len];
/*     */     
/* 696 */     if (this.bufpos + 1 >= len) {
/* 697 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     } else {
/*     */       
/* 700 */       System.arraycopy(this.buffer, this.bufsize - len - this.bufpos - 1, ret, 0, len - this.bufpos - 1);
/*     */       
/* 702 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/*     */     } 
/*     */     
/* 705 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void Done() {
/* 711 */     this.nextCharBuf = null;
/* 712 */     this.buffer = null;
/* 713 */     this.bufline = null;
/* 714 */     this.bufcolumn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustBeginLineColumn(int newLine, int newCol) {
/* 725 */     int len, start = this.tokenBegin;
/*     */ 
/*     */     
/* 728 */     if (this.bufpos >= this.tokenBegin) {
/*     */       
/* 730 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     }
/*     */     else {
/*     */       
/* 734 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 737 */     int i = 0, j = 0, k = 0;
/* 738 */     int nextColDiff = 0, columnDiff = 0;
/*     */     
/* 740 */     while (i < len && this.bufline[j = start % this.bufsize] == this.bufline[k = ++start % this.bufsize]) {
/*     */ 
/*     */       
/* 743 */       this.bufline[j] = newLine;
/* 744 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 745 */       this.bufcolumn[j] = newCol + columnDiff;
/* 746 */       columnDiff = nextColDiff;
/* 747 */       i++;
/*     */     } 
/*     */     
/* 750 */     if (i < len) {
/*     */       
/* 752 */       this.bufline[j] = newLine++;
/* 753 */       this.bufcolumn[j] = newCol + columnDiff;
/*     */       
/* 755 */       while (i++ < len) {
/*     */         
/* 757 */         if (this.bufline[j = start % this.bufsize] != this.bufline[++start % this.bufsize]) {
/* 758 */           this.bufline[j] = newLine++; continue;
/*     */         } 
/* 760 */         this.bufline[j] = newLine;
/*     */       } 
/*     */     } 
/*     */     
/* 764 */     this.line = this.bufline[j];
/* 765 */     this.column = this.bufcolumn[j];
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\JavaCharStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */