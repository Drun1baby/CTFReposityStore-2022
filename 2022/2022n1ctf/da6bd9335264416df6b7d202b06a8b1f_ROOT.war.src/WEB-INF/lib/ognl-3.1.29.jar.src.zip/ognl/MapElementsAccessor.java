/*    */ package ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapElementsAccessor
/*    */   implements ElementsAccessor
/*    */ {
/*    */   public Enumeration getElements(Object target) {
/* 44 */     return new IteratorEnumeration(((Map)target).values().iterator());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\MapElementsAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */