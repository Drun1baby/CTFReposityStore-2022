/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTStaticField
/*     */   extends SimpleNode
/*     */   implements NodeType
/*     */ {
/*     */   private String className;
/*     */   private String fieldName;
/*     */   private Class _getterClass;
/*     */   
/*     */   public ASTStaticField(int id) {
/*  50 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTStaticField(OgnlParser p, int id) {
/*  55 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void init(String className, String fieldName) {
/*  61 */     this.className = className;
/*  62 */     this.fieldName = fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  68 */     return OgnlRuntime.getStaticField(context, this.className, this.fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNodeConstant(OgnlContext context) throws OgnlException {
/*  74 */     boolean result = false;
/*  75 */     Exception reason = null;
/*     */     
/*     */     try {
/*  78 */       Class c = OgnlRuntime.classForName(context, this.className);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       if (this.fieldName.equals("class")) {
/*     */         
/*  86 */         result = true;
/*  87 */       } else if (OgnlRuntime.isJdk15() && c.isEnum()) {
/*     */         
/*  89 */         result = true;
/*     */       } else {
/*     */         Field f;
/*     */         
/*     */         try {
/*  94 */           f = c.getField(this.fieldName);
/*  95 */         } catch (NoSuchFieldException nsfe) {
/*  96 */           f = OgnlRuntime.getField(c, this.fieldName);
/*  97 */           if (f == null) {
/*  98 */             throw new NoSuchFieldException(this.fieldName);
/*     */           }
/*     */         } 
/* 101 */         int fModifiers = f.getModifiers();
/*     */         
/* 103 */         if (!Modifier.isStatic(fModifiers)) {
/* 104 */           throw new OgnlException("Field " + this.fieldName + " of class " + this.className + " is not static");
/*     */         }
/* 106 */         result = Modifier.isFinal(fModifiers);
/*     */       } 
/* 108 */     } catch (ClassNotFoundException e) {
/* 109 */       reason = e;
/* 110 */     } catch (NoSuchFieldException e) {
/* 111 */       reason = e;
/* 112 */     } catch (SecurityException e) {
/* 113 */       reason = e;
/*     */     } 
/*     */     
/* 116 */     if (reason != null) {
/* 117 */       throw new OgnlException("Could not get static field " + this.fieldName + " from class " + this.className, reason);
/*     */     }
/*     */     
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Class getFieldClass(OgnlContext context) throws OgnlException {
/* 126 */     Exception reason = null;
/*     */     
/*     */     try {
/* 129 */       Class c = OgnlRuntime.classForName(context, this.className);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       if (this.fieldName.equals("class"))
/*     */       {
/* 137 */         return c; } 
/* 138 */       if (OgnlRuntime.isJdk15() && c.isEnum())
/*     */       {
/* 140 */         return c;
/*     */       }
/*     */       
/* 143 */       Field f = c.getField(this.fieldName);
/*     */       
/* 145 */       return f.getType();
/*     */     }
/* 147 */     catch (ClassNotFoundException e) {
/* 148 */       reason = e;
/* 149 */     } catch (NoSuchFieldException e) {
/* 150 */       reason = e;
/* 151 */     } catch (SecurityException e) {
/* 152 */       reason = e;
/*     */     } 
/*     */     
/* 155 */     if (reason != null) throw new OgnlException("Could not get static field " + this.fieldName + " from class " + this.className, reason);
/*     */ 
/*     */     
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/* 163 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/* 168 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 173 */     return "@" + this.className + "@" + this.fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*     */     try {
/* 180 */       Object obj = OgnlRuntime.getStaticField(context, this.className, this.fieldName);
/*     */       
/* 182 */       context.setCurrentObject(obj);
/*     */       
/* 184 */       this._getterClass = getFieldClass(context);
/*     */       
/* 186 */       context.setCurrentType(this._getterClass);
/*     */     }
/* 188 */     catch (Throwable t) {
/*     */       
/* 190 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 193 */     return this.className + "." + this.fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/*     */     try {
/* 200 */       Object obj = OgnlRuntime.getStaticField(context, this.className, this.fieldName);
/*     */       
/* 202 */       context.setCurrentObject(obj);
/*     */       
/* 204 */       this._getterClass = getFieldClass(context);
/*     */       
/* 206 */       context.setCurrentType(this._getterClass);
/*     */     }
/* 208 */     catch (Throwable t) {
/*     */       
/* 210 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 213 */     return this.className + "." + this.fieldName;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTStaticField.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */