/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTSubtract
/*    */   extends NumericExpression
/*    */ {
/*    */   public ASTSubtract(int id) {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTSubtract(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 49 */     Object v1 = this._children[0].getValue(context, source);
/* 50 */     Object v2 = this._children[1].getValue(context, source);
/* 51 */     return OgnlOps.subtract(v1, v2);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 56 */     return "-";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTSubtract.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */