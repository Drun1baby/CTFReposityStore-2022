/*    */ package ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumerationIterator
/*    */   implements Iterator
/*    */ {
/*    */   private Enumeration e;
/*    */   
/*    */   public EnumerationIterator(Enumeration e) {
/* 47 */     this.e = e;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 52 */     return this.e.hasMoreElements();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object next() {
/* 57 */     return this.e.nextElement();
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove() {
/* 62 */     throw new UnsupportedOperationException("remove() not supported by Enumeration");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\EnumerationIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */