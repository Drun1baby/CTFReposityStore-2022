/*    */ package ognl;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberElementsAccessor
/*    */   implements ElementsAccessor, NumericTypes
/*    */ {
/*    */   public Enumeration getElements(final Object target) {
/* 45 */     return new Enumeration() {
/* 46 */         private int type = OgnlOps.getNumericType(target);
/* 47 */         private long next = 0L;
/* 48 */         private long finish = OgnlOps.longValue(target);
/*    */         
/*    */         public boolean hasMoreElements() {
/* 51 */           return (this.next < this.finish);
/*    */         }
/*    */         
/*    */         public Object nextElement() {
/* 55 */           if (this.next >= this.finish)
/* 56 */             throw new NoSuchElementException(); 
/* 57 */           return OgnlOps.newInteger(this.type, this.next++);
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\NumberElementsAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */