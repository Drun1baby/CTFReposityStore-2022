/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTLessEq
/*    */   extends ComparisonExpression
/*    */ {
/*    */   public ASTLessEq(int id) {
/* 41 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTLessEq(OgnlParser p, int id) {
/* 45 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 50 */     Object v1 = this._children[0].getValue(context, source);
/* 51 */     Object v2 = this._children[1].getValue(context, source);
/* 52 */     return OgnlOps.greater(v1, v2) ? Boolean.FALSE : Boolean.TRUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 57 */     return "<=";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComparisonFunction() {
/* 62 */     return "!ognl.OgnlOps.greater";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTLessEq.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */