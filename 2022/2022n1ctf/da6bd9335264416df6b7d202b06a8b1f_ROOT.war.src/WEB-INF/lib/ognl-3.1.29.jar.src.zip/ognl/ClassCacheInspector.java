package ognl;

public interface ClassCacheInspector {
  boolean shouldCache(Class paramClass);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ClassCacheInspector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */