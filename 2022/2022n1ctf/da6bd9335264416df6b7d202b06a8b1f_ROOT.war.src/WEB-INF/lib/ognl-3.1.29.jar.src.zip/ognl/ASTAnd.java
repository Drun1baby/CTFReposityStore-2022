/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTAnd
/*     */   extends BooleanExpression
/*     */ {
/*     */   public ASTAnd(int id) {
/*  43 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTAnd(OgnlParser p, int id) {
/*  47 */     super(p, id);
/*     */   }
/*     */   
/*     */   public void jjtClose() {
/*  51 */     flattenTree();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  57 */     Object result = null;
/*  58 */     int last = this._children.length - 1;
/*  59 */     for (int i = 0; i <= last; i++) {
/*     */       
/*  61 */       result = this._children[i].getValue(context, source);
/*     */       
/*  63 */       if (i != last && !OgnlOps.booleanValue(result)) {
/*     */         break;
/*     */       }
/*     */     } 
/*  67 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/*  73 */     int last = this._children.length - 1;
/*     */     
/*  75 */     for (int i = 0; i < last; i++) {
/*     */       
/*  77 */       Object v = this._children[i].getValue(context, target);
/*     */       
/*  79 */       if (!OgnlOps.booleanValue(v)) {
/*     */         return;
/*     */       }
/*     */     } 
/*  83 */     this._children[last].setValue(context, target, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionOperator(int index) {
/*  88 */     return "&&";
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  98 */     if (this._children.length != 2) {
/*  99 */       throw new UnsupportedCompilationException("Can only compile boolean expressions with two children.");
/*     */     }
/* 101 */     String result = "";
/*     */ 
/*     */     
/*     */     try {
/* 105 */       String first = OgnlRuntime.getChildSource(context, target, this._children[0]);
/* 106 */       if (!OgnlOps.booleanValue(context.getCurrentObject()))
/*     */       {
/* 108 */         throw new UnsupportedCompilationException("And expression can't be compiled until all conditions are true.");
/*     */       }
/*     */       
/* 111 */       if (!OgnlRuntime.isBoolean(first) && !context.getCurrentType().isPrimitive()) {
/* 112 */         first = OgnlRuntime.getCompiler().createLocalReference(context, first, context.getCurrentType());
/*     */       }
/* 114 */       String second = OgnlRuntime.getChildSource(context, target, this._children[1]);
/* 115 */       if (!OgnlRuntime.isBoolean(second) && !context.getCurrentType().isPrimitive()) {
/* 116 */         second = OgnlRuntime.getCompiler().createLocalReference(context, second, context.getCurrentType());
/*     */       }
/* 118 */       result = result + "(ognl.OgnlOps.booleanValue(" + first + ")";
/*     */       
/* 120 */       result = result + " ? ";
/*     */       
/* 122 */       result = result + " ($w) (" + second + ")";
/* 123 */       result = result + " : ";
/*     */       
/* 125 */       result = result + " ($w) (" + first + ")";
/*     */       
/* 127 */       result = result + ")";
/*     */       
/* 129 */       context.setCurrentObject(target);
/* 130 */       context.setCurrentType(Object.class);
/* 131 */     } catch (NullPointerException e) {
/*     */       
/* 133 */       throw new UnsupportedCompilationException("evaluation resulted in null expression.");
/* 134 */     } catch (Throwable t) {
/*     */       
/* 136 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 144 */     if (this._children.length != 2) {
/* 145 */       throw new UnsupportedCompilationException("Can only compile boolean expressions with two children.");
/*     */     }
/* 147 */     String pre = (String)context.get("_currentChain");
/* 148 */     if (pre == null) {
/* 149 */       pre = "";
/*     */     }
/* 151 */     String result = "";
/*     */ 
/*     */     
/*     */     try {
/* 155 */       if (!OgnlOps.booleanValue(this._children[0].getValue(context, target)))
/*     */       {
/* 157 */         throw new UnsupportedCompilationException("And expression can't be compiled until all conditions are true.");
/*     */       }
/*     */       
/* 160 */       String first = ExpressionCompiler.getRootExpression(this._children[0], context.getRoot(), context) + pre + this._children[0].toGetSourceString(context, target);
/*     */ 
/*     */       
/* 163 */       this._children[1].getValue(context, target);
/*     */       
/* 165 */       String second = ExpressionCompiler.getRootExpression(this._children[1], context.getRoot(), context) + pre + this._children[1].toSetSourceString(context, target);
/*     */ 
/*     */       
/* 168 */       if (!OgnlRuntime.isBoolean(first)) {
/* 169 */         result = result + "if(ognl.OgnlOps.booleanValue(" + first + ")){";
/*     */       } else {
/* 171 */         result = result + "if(" + first + "){";
/*     */       } 
/* 173 */       result = result + second;
/* 174 */       result = result + "; } ";
/*     */       
/* 176 */       context.setCurrentObject(target);
/* 177 */       context.setCurrentType(Object.class);
/*     */     }
/* 179 */     catch (Throwable t) {
/*     */       
/* 181 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 184 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTAnd.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */