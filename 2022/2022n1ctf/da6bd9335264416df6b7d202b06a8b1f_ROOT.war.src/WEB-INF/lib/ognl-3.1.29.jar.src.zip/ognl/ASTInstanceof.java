/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTInstanceof
/*    */   extends SimpleNode
/*    */   implements NodeType
/*    */ {
/*    */   private String targetType;
/*    */   
/*    */   public ASTInstanceof(int id) {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTInstanceof(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */   
/*    */   void setTargetType(String targetType) {
/* 50 */     this.targetType = targetType;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 55 */     Object value = this._children[0].getValue(context, source);
/* 56 */     return OgnlRuntime.isInstance(context, value, this.targetType) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return this._children[0] + " instanceof " + this.targetType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getGetterClass() {
/* 66 */     return boolean.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getSetterClass() {
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/*    */     try {
/* 78 */       String ret = "";
/*    */       
/* 80 */       if (ASTConst.class.isInstance(this._children[0])) {
/* 81 */         ret = ((Boolean)getValueBody(context, target)).toString();
/*    */       } else {
/* 83 */         ret = this._children[0].toGetSourceString(context, target) + " instanceof " + this.targetType;
/*    */       } 
/* 85 */       context.setCurrentType(boolean.class);
/*    */       
/* 87 */       return ret;
/*    */     }
/* 89 */     catch (Throwable t) {
/*    */       
/* 91 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 97 */     return toGetSourceString(context, target);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTInstanceof.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */