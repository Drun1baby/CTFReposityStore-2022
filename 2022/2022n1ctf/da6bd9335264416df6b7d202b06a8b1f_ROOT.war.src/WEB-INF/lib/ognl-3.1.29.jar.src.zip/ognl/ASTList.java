/*     */ package ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTList
/*     */   extends SimpleNode
/*     */   implements NodeType
/*     */ {
/*     */   public ASTList(int id) {
/*  47 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTList(OgnlParser p, int id) {
/*  52 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  58 */     List<Object> answer = new ArrayList(jjtGetNumChildren());
/*  59 */     for (int i = 0; i < jjtGetNumChildren(); i++)
/*  60 */       answer.add(this._children[i].getValue(context, source)); 
/*  61 */     return answer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  76 */     String result = "{ ";
/*     */     
/*  78 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/*  79 */       if (i > 0) {
/*  80 */         result = result + ", ";
/*     */       }
/*  82 */       result = result + this._children[i].toString();
/*     */     } 
/*  84 */     return result + " }";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  89 */     String result = "";
/*  90 */     boolean array = false;
/*     */     
/*  92 */     if (this._parent != null && ASTCtor.class.isInstance(this._parent) && ((ASTCtor)this._parent).isArray())
/*     */     {
/*     */       
/*  95 */       array = true;
/*     */     }
/*     */     
/*  98 */     context.setCurrentType(List.class);
/*  99 */     context.setCurrentAccessor(List.class);
/*     */     
/* 101 */     if (!array) {
/*     */       
/* 103 */       if (jjtGetNumChildren() < 1) {
/* 104 */         return "java.util.Arrays.asList( new Object[0])";
/*     */       }
/* 106 */       result = result + "java.util.Arrays.asList( new Object[] ";
/*     */     } 
/*     */     
/* 109 */     result = result + "{ ";
/*     */ 
/*     */     
/*     */     try {
/* 113 */       for (int i = 0; i < jjtGetNumChildren(); i++) {
/* 114 */         if (i > 0) {
/* 115 */           result = result + ", ";
/*     */         }
/*     */         
/* 118 */         Class prevType = context.getCurrentType();
/*     */         
/* 120 */         Object objValue = this._children[i].getValue(context, context.getRoot());
/* 121 */         String value = this._children[i].toGetSourceString(context, target);
/*     */ 
/*     */         
/* 124 */         if (ASTConst.class.isInstance(this._children[i]))
/*     */         {
/* 126 */           context.setCurrentType(prevType);
/*     */         }
/*     */         
/* 129 */         value = ExpressionCompiler.getRootExpression(this._children[i], target, context) + value;
/*     */         
/* 131 */         String cast = "";
/* 132 */         if (ExpressionCompiler.shouldCast(this._children[i]))
/*     */         {
/* 134 */           cast = (String)context.remove("_preCast");
/*     */         }
/* 136 */         if (cast == null) {
/* 137 */           cast = "";
/*     */         }
/* 139 */         if (!ASTConst.class.isInstance(this._children[i])) {
/* 140 */           value = cast + value;
/*     */         }
/* 142 */         Class<Object> ctorClass = (Class)context.get("_ctorClass");
/* 143 */         if (array && ctorClass != null && !ctorClass.isPrimitive()) {
/*     */           
/* 145 */           Class<?> valueClass = (value != null) ? value.getClass() : null;
/* 146 */           if (NodeType.class.isAssignableFrom(this._children[i].getClass())) {
/* 147 */             valueClass = ((NodeType)this._children[i]).getGetterClass();
/*     */           }
/* 149 */           if (valueClass != null && ctorClass.isArray()) {
/*     */             
/* 151 */             value = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ExpressionCompiler.getCastString(ctorClass) + ")ognl.OgnlOps.toArray(" + value + ", " + ctorClass.getComponentType().getName() + ".class, true)", ctorClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 158 */           else if (ctorClass.isPrimitive()) {
/*     */             
/* 160 */             Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(ctorClass);
/*     */             
/* 162 */             value = OgnlRuntime.getCompiler().createLocalReference(context, "((" + wrapClass.getName() + ")ognl.OgnlOps.convertValue(" + value + "," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass), ctorClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 170 */           else if (ctorClass != Object.class) {
/*     */             
/* 172 */             value = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ctorClass.getName() + ")ognl.OgnlOps.convertValue(" + value + "," + ctorClass.getName() + ".class)", ctorClass);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 177 */           else if ((NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null && Number.class.isAssignableFrom(((NodeType)this._children[i]).getGetterClass())) || valueClass.isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 182 */             value = " ($w) (" + value + ")";
/* 183 */           } else if (valueClass.isPrimitive()) {
/* 184 */             value = "($w) (" + value + ")";
/*     */           }
/*     */         
/* 187 */         } else if (ctorClass == null || !ctorClass.isPrimitive()) {
/*     */           
/* 189 */           value = " ($w) (" + value + ")";
/*     */         } 
/*     */         
/* 192 */         if (objValue == null || value.length() <= 0) {
/* 193 */           value = "null";
/*     */         }
/* 195 */         result = result + value;
/*     */       }
/*     */     
/* 198 */     } catch (Throwable t) {
/*     */       
/* 200 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 203 */     context.setCurrentType(List.class);
/* 204 */     context.setCurrentAccessor(List.class);
/*     */     
/* 206 */     result = result + "}";
/*     */     
/* 208 */     if (!array) {
/* 209 */       result = result + ")";
/*     */     }
/* 211 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 216 */     throw new UnsupportedCompilationException("Can't generate setter for ASTList.");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */