/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTNegate
/*    */   extends NumericExpression
/*    */ {
/*    */   public ASTNegate(int id) {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTNegate(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 49 */     return OgnlOps.negate(this._children[0].getValue(context, source));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 54 */     return "-" + this._children[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 59 */     String source = this._children[0].toGetSourceString(context, target);
/*    */     
/* 61 */     if (!ASTNegate.class.isInstance(this._children[0]))
/*    */     {
/* 63 */       return "-" + source;
/*    */     }
/*    */     
/* 66 */     return "-(" + source + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isOperation(OgnlContext context) throws OgnlException {
/* 72 */     if (this._children.length == 1) {
/* 73 */       SimpleNode child = (SimpleNode)this._children[0];
/* 74 */       return (child.isOperation(context) || !child.isConstant(context));
/*    */     } 
/* 76 */     return super.isOperation(context);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTNegate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */