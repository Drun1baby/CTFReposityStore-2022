/*    */ package ognl.security;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.PrivilegedExceptionAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserMethod
/*    */   implements PrivilegedExceptionAction<Object>
/*    */ {
/*    */   private final Object target;
/*    */   private final Method method;
/*    */   private final Object[] argsArray;
/*    */   
/*    */   public UserMethod(Object target, Method method, Object[] argsArray) {
/* 18 */     this.target = target;
/* 19 */     this.method = method;
/* 20 */     this.argsArray = argsArray;
/*    */   }
/*    */   
/*    */   public Object run() throws Exception {
/* 24 */     return this.method.invoke(this.target, this.argsArray);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\security\UserMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */