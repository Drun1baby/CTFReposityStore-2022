/*     */ package ognl.security;
/*     */ 
/*     */ import java.io.FilePermission;
/*     */ import java.security.Permission;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlSecurityManager
/*     */   extends SecurityManager
/*     */ {
/*     */   private static final String OGNL_SANDBOX_CLASS_NAME = "ognl.security.UserMethod";
/*  28 */   private static final Class<?> CLASS_LOADER_CLASS = ClassLoader.class;
/*  29 */   private static final Class<?> FILE_PERMISSION_CLASS = FilePermission.class;
/*     */   
/*     */   private SecurityManager parentSecurityManager;
/*  32 */   private List<Long> residents = new ArrayList<>();
/*  33 */   private SecureRandom rnd = new SecureRandom();
/*     */   
/*     */   public OgnlSecurityManager(SecurityManager parentSecurityManager) {
/*  36 */     this.parentSecurityManager = parentSecurityManager;
/*     */   }
/*     */   
/*     */   private boolean isAccessDenied(Permission perm) {
/*  40 */     Class[] classContext = getClassContext();
/*  41 */     Boolean isInsideClassLoader = null;
/*  42 */     for (Class<?> c : classContext) {
/*  43 */       if (isInsideClassLoader == null && CLASS_LOADER_CLASS.isAssignableFrom(c)) {
/*  44 */         if (FILE_PERMISSION_CLASS.equals(perm.getClass()) && "read".equals(perm.getActions()))
/*     */         {
/*     */           
/*  47 */           return false;
/*     */         }
/*  49 */         isInsideClassLoader = Boolean.valueOf(false);
/*     */       } 
/*     */       
/*  52 */       if ("ognl.security.UserMethod".equals(c.getName())) {
/*  53 */         return true;
/*     */       }
/*     */     } 
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkPermission(Permission perm) {
/*  61 */     if (this.parentSecurityManager != null) {
/*  62 */       this.parentSecurityManager.checkPermission(perm);
/*     */     }
/*  64 */     if (isAccessDenied(perm)) {
/*  65 */       super.checkPermission(perm);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkPermission(Permission perm, Object context) {
/*  71 */     if (this.parentSecurityManager != null) {
/*  72 */       this.parentSecurityManager.checkPermission(perm, context);
/*     */     }
/*  74 */     if (isAccessDenied(perm)) {
/*  75 */       super.checkPermission(perm, context);
/*     */     }
/*     */   }
/*     */   
/*     */   public Long enter() {
/*  80 */     synchronized (this) {
/*  81 */       long token = this.rnd.nextLong();
/*  82 */       if (this.residents.size() == 0) {
/*  83 */         if (install()) {
/*  84 */           this.residents.add(Long.valueOf(token));
/*  85 */           return Long.valueOf(token);
/*     */         } 
/*  87 */         return null;
/*     */       } 
/*     */       
/*  90 */       this.residents.add(Long.valueOf(token));
/*  91 */       return Long.valueOf(token);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void leave(long token) throws SecurityException {
/*  96 */     synchronized (this) {
/*  97 */       if (!this.residents.contains(Long.valueOf(token))) {
/*  98 */         throw new SecurityException();
/*     */       }
/* 100 */       this.residents.remove(Long.valueOf(token));
/* 101 */       if (this.residents.size() == 0)
/*     */       {
/* 103 */         uninstall();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean install() {
/*     */     try {
/* 110 */       System.setSecurityManager(this);
/* 111 */     } catch (SecurityException ex) {
/*     */       
/* 113 */       return false;
/*     */     } 
/*     */     
/* 116 */     return true;
/*     */   }
/*     */   
/*     */   private void uninstall() {
/* 120 */     System.setSecurityManager(this.parentSecurityManager);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\security\OgnlSecurityManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */