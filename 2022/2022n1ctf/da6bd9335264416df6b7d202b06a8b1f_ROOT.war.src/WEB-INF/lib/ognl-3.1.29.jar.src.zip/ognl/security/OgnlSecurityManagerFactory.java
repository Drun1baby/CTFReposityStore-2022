/*    */ package ognl.security;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.security.AllPermission;
/*    */ import java.security.PermissionCollection;
/*    */ import java.security.ProtectionDomain;
/*    */ import java.security.SecureClassLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OgnlSecurityManagerFactory
/*    */   extends SecureClassLoader
/*    */ {
/*    */   private static Object ognlSecurityManager;
/*    */   private Class<?> ognlSecurityManagerClass;
/*    */   
/*    */   public static Object getOgnlSecurityManager() {
/* 24 */     if (ognlSecurityManager == null) {
/* 25 */       synchronized (SecurityManager.class) {
/* 26 */         if (ognlSecurityManager == null) {
/* 27 */           SecurityManager sm = System.getSecurityManager();
/* 28 */           if (sm == null || !sm.getClass().getName().equals(OgnlSecurityManager.class.getName())) {
/*    */             try {
/* 30 */               ognlSecurityManager = (new OgnlSecurityManagerFactory()).build(sm);
/* 31 */             } catch (Exception exception) {}
/*    */           }
/*    */           else {
/*    */             
/* 35 */             ognlSecurityManager = sm;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     }
/* 40 */     return ognlSecurityManager;
/*    */   }
/*    */   
/*    */   private OgnlSecurityManagerFactory() throws IOException {
/* 44 */     super(OgnlSecurityManagerFactory.class.getClassLoader());
/*    */     
/* 46 */     PermissionCollection pc = (new AllPermission()).newPermissionCollection();
/* 47 */     pc.add(new AllPermission());
/* 48 */     ProtectionDomain pd = new ProtectionDomain(null, pc);
/*    */     
/* 50 */     byte[] byteArray = toByteArray(getParent().getResourceAsStream(OgnlSecurityManager.class.getName().replace('.', '/') + ".class"));
/*    */     
/* 52 */     this.ognlSecurityManagerClass = defineClass((String)null, byteArray, 0, byteArray.length, pd);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private Object build(SecurityManager parentSecurityManager) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
/* 58 */     return this.ognlSecurityManagerClass.getConstructor(new Class[] { SecurityManager.class }).newInstance(new Object[] { parentSecurityManager });
/*    */   }
/*    */   
/*    */   private static byte[] toByteArray(InputStream input) throws IOException {
/* 62 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*    */     
/* 64 */     byte[] buffer = new byte[4096]; int n;
/* 65 */     while (-1 != (n = input.read(buffer))) {
/* 66 */       output.write(buffer, 0, n);
/*    */     }
/*    */     
/* 69 */     return output.toByteArray();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\security\OgnlSecurityManagerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */