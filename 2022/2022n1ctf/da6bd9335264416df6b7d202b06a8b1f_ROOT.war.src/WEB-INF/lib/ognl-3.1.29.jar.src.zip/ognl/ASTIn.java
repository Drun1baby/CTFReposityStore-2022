/*    */ package ognl;
/*    */ 
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTIn
/*    */   extends SimpleNode
/*    */   implements NodeType
/*    */ {
/*    */   public ASTIn(int id) {
/* 42 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTIn(OgnlParser p, int id) {
/* 46 */     super(p, id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 52 */     Object v1 = this._children[0].getValue(context, source);
/* 53 */     Object v2 = this._children[1].getValue(context, source);
/*    */     
/* 55 */     return OgnlOps.in(v1, v2) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return this._children[0] + " in " + this._children[1];
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getGetterClass() {
/* 65 */     return boolean.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getSetterClass() {
/* 70 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/*    */     try {
/* 76 */       String result = "ognl.OgnlOps.in( ($w) ";
/*    */       
/* 78 */       result = result + OgnlRuntime.getChildSource(context, target, this._children[0]) + ", ($w) " + OgnlRuntime.getChildSource(context, target, this._children[1]);
/*    */       
/* 80 */       result = result + ")";
/*    */       
/* 82 */       context.setCurrentType(boolean.class);
/*    */       
/* 84 */       return result;
/* 85 */     } catch (NullPointerException e) {
/*    */ 
/*    */       
/* 88 */       e.printStackTrace();
/*    */       
/* 90 */       throw new UnsupportedCompilationException("evaluation resulted in null expression.");
/* 91 */     } catch (Throwable t) {
/*    */       
/* 93 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 99 */     throw new UnsupportedCompilationException("Map expressions not supported as native java yet.");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTIn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */