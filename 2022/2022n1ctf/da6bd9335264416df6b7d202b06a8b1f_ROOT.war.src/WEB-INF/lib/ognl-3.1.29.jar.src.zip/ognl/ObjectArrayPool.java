/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObjectArrayPool
/*    */ {
/*    */   public Object[] create(int arraySize) {
/* 48 */     return new Object[arraySize];
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] create(Object singleton) {
/* 53 */     Object[] result = create(1);
/*    */     
/* 55 */     result[0] = singleton;
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] create(Object object1, Object object2) {
/* 61 */     Object[] result = create(2);
/*    */     
/* 63 */     result[0] = object1;
/* 64 */     result[1] = object2;
/* 65 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] create(Object object1, Object object2, Object object3) {
/* 70 */     Object[] result = create(3);
/*    */     
/* 72 */     result[0] = object1;
/* 73 */     result[1] = object2;
/* 74 */     result[2] = object3;
/* 75 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] create(Object object1, Object object2, Object object3, Object object4) {
/* 80 */     Object[] result = create(4);
/*    */     
/* 82 */     result[0] = object1;
/* 83 */     result[1] = object2;
/* 84 */     result[2] = object3;
/* 85 */     result[3] = object4;
/* 86 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] create(Object object1, Object object2, Object object3, Object object4, Object object5) {
/* 91 */     Object[] result = create(5);
/*    */     
/* 93 */     result[0] = object1;
/* 94 */     result[1] = object2;
/* 95 */     result[2] = object3;
/* 96 */     result[3] = object4;
/* 97 */     result[4] = object5;
/* 98 */     return result;
/*    */   }
/*    */   
/*    */   public void recycle(Object[] value) {}
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectArrayPool.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */