/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTOr
/*     */   extends BooleanExpression
/*     */ {
/*     */   public ASTOr(int id) {
/*  43 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTOr(OgnlParser p, int id) {
/*  48 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public void jjtClose() {
/*  53 */     flattenTree();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  58 */     Object result = null;
/*  59 */     int last = this._children.length - 1;
/*  60 */     for (int i = 0; i <= last; i++) {
/*  61 */       result = this._children[i].getValue(context, source);
/*  62 */       if (i != last && OgnlOps.booleanValue(result))
/*     */         break; 
/*     */     } 
/*  65 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/*  70 */     int last = this._children.length - 1;
/*  71 */     for (int i = 0; i < last; i++) {
/*  72 */       Object v = this._children[i].getValue(context, target);
/*  73 */       if (OgnlOps.booleanValue(v))
/*     */         return; 
/*     */     } 
/*  76 */     this._children[last].setValue(context, target, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpressionOperator(int index) {
/*  81 */     return "||";
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  91 */     if (this._children.length != 2) {
/*  92 */       throw new UnsupportedCompilationException("Can only compile boolean expressions with two children.");
/*     */     }
/*  94 */     String result = "(";
/*     */ 
/*     */     
/*     */     try {
/*  98 */       String first = OgnlRuntime.getChildSource(context, target, this._children[0]);
/*  99 */       if (!OgnlRuntime.isBoolean(first)) {
/* 100 */         first = OgnlRuntime.getCompiler().createLocalReference(context, first, context.getCurrentType());
/*     */       }
/* 102 */       Class firstType = context.getCurrentType();
/*     */       
/* 104 */       String second = OgnlRuntime.getChildSource(context, target, this._children[1]);
/* 105 */       if (!OgnlRuntime.isBoolean(second)) {
/* 106 */         second = OgnlRuntime.getCompiler().createLocalReference(context, second, context.getCurrentType());
/*     */       }
/* 108 */       Class secondType = context.getCurrentType();
/*     */       
/* 110 */       boolean mismatched = ((firstType.isPrimitive() && !secondType.isPrimitive()) || (!firstType.isPrimitive() && secondType.isPrimitive()));
/*     */ 
/*     */       
/* 113 */       result = result + "ognl.OgnlOps.booleanValue(" + first + ")";
/*     */       
/* 115 */       result = result + " ? ";
/*     */       
/* 117 */       result = result + (mismatched ? " ($w) " : "") + first;
/*     */       
/* 119 */       result = result + " : ";
/*     */       
/* 121 */       result = result + (mismatched ? " ($w) " : "") + second;
/*     */       
/* 123 */       result = result + ")";
/*     */       
/* 125 */       context.setCurrentObject(target);
/* 126 */       context.setCurrentType(boolean.class);
/*     */     }
/* 128 */     catch (Throwable t) {
/*     */       
/* 130 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 133 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 138 */     if (this._children.length != 2) {
/* 139 */       throw new UnsupportedCompilationException("Can only compile boolean expressions with two children.");
/*     */     }
/* 141 */     String pre = (String)context.get("_currentChain");
/* 142 */     if (pre == null) {
/* 143 */       pre = "";
/*     */     }
/* 145 */     String result = "";
/*     */ 
/*     */     
/*     */     try {
/* 149 */       this._children[0].getValue(context, target);
/*     */       
/* 151 */       String first = ExpressionCompiler.getRootExpression(this._children[0], context.getRoot(), context) + pre + this._children[0].toGetSourceString(context, target);
/*     */       
/* 153 */       if (!OgnlRuntime.isBoolean(first)) {
/* 154 */         first = OgnlRuntime.getCompiler().createLocalReference(context, first, Object.class);
/*     */       }
/* 156 */       this._children[1].getValue(context, target);
/*     */       
/* 158 */       String second = ExpressionCompiler.getRootExpression(this._children[1], context.getRoot(), context) + pre + this._children[1].toSetSourceString(context, target);
/*     */       
/* 160 */       if (!OgnlRuntime.isBoolean(second)) {
/* 161 */         second = OgnlRuntime.getCompiler().createLocalReference(context, second, context.getCurrentType());
/*     */       }
/* 163 */       result = result + "ognl.OgnlOps.booleanValue(" + first + ")";
/*     */       
/* 165 */       result = result + " ? ";
/*     */       
/* 167 */       result = result + first;
/* 168 */       result = result + " : ";
/*     */       
/* 170 */       result = result + second;
/*     */       
/* 172 */       context.setCurrentObject(target);
/*     */       
/* 174 */       context.setCurrentType(boolean.class);
/*     */     }
/* 176 */     catch (Throwable t) {
/*     */       
/* 178 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 181 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTOr.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */