/*    */ package ognl;
/*    */ 
/*    */ import java.security.BasicPermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OgnlInvokePermission
/*    */   extends BasicPermission
/*    */ {
/*    */   public OgnlInvokePermission(String name) {
/* 48 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public OgnlInvokePermission(String name, String actions) {
/* 53 */     super(name, actions);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlInvokePermission.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */