package ognl;

import java.lang.reflect.Member;
import java.util.Map;

public interface MemberAccess {
  Object setup(Map paramMap, Object paramObject, Member paramMember, String paramString);
  
  void restore(Map paramMap, Object paramObject1, Member paramMember, String paramString, Object paramObject2);
  
  boolean isAccessible(Map paramMap, Object paramObject, Member paramMember, String paramString);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\MemberAccess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */