/*    */ package ognl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTSelectLast
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTSelectLast(int id) {
/* 46 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTSelectLast(OgnlParser p, int id) {
/* 50 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 55 */     Node expr = this._children[0];
/* 56 */     List<Object> answer = new ArrayList();
/* 57 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(source));
/*    */     
/* 59 */     for (Enumeration e = elementsAccessor.getElements(source); e.hasMoreElements(); ) {
/* 60 */       Object next = e.nextElement();
/*    */       
/* 62 */       if (OgnlOps.booleanValue(expr.getValue(context, next))) {
/* 63 */         answer.clear();
/* 64 */         answer.add(next);
/*    */       } 
/*    */     } 
/* 67 */     return answer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "{$ " + this._children[0] + " }";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 77 */     throw new UnsupportedCompilationException("Eval expressions not supported as native java yet.");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 82 */     throw new UnsupportedCompilationException("Eval expressions not supported as native java yet.");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTSelectLast.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */