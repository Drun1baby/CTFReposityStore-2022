/*     */ package ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JJTOgnlParserState
/*     */ {
/*  13 */   private List nodes = new ArrayList();
/*  14 */   private List marks = new ArrayList();
/*  15 */   private int sp = 0;
/*  16 */   private int mk = 0;
/*     */ 
/*     */   
/*     */   private boolean node_created;
/*     */ 
/*     */   
/*     */   public boolean nodeCreated() {
/*  23 */     return this.node_created;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  29 */     this.nodes.clear();
/*  30 */     this.marks.clear();
/*  31 */     this.sp = 0;
/*  32 */     this.mk = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node rootNode() {
/*  38 */     return this.nodes.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushNode(Node n) {
/*  43 */     this.nodes.add(n);
/*  44 */     this.sp++;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node popNode() {
/*  50 */     if (--this.sp < this.mk) {
/*  51 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*     */     }
/*  53 */     return this.nodes.remove(this.nodes.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node peekNode() {
/*  58 */     return this.nodes.get(this.nodes.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int nodeArity() {
/*  64 */     return this.sp - this.mk;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearNodeScope(Node n) {
/*  69 */     while (this.sp > this.mk) {
/*  70 */       popNode();
/*     */     }
/*  72 */     this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void openNodeScope(Node n) {
/*  77 */     this.marks.add(new Integer(this.mk));
/*  78 */     this.mk = this.sp;
/*  79 */     n.jjtOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeNodeScope(Node n, int num) {
/*  88 */     this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/*  89 */     while (num-- > 0) {
/*  90 */       Node c = popNode();
/*  91 */       c.jjtSetParent(n);
/*  92 */       n.jjtAddChild(c, num);
/*     */     } 
/*  94 */     n.jjtClose();
/*  95 */     pushNode(n);
/*  96 */     this.node_created = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeNodeScope(Node n, boolean condition) {
/* 106 */     if (condition) {
/* 107 */       int a = nodeArity();
/* 108 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/* 109 */       while (a-- > 0) {
/* 110 */         Node c = popNode();
/* 111 */         c.jjtSetParent(n);
/* 112 */         n.jjtAddChild(c, a);
/*     */       } 
/* 114 */       n.jjtClose();
/* 115 */       pushNode(n);
/* 116 */       this.node_created = true;
/*     */     } else {
/* 118 */       this.mk = ((Integer)this.marks.remove(this.marks.size() - 1)).intValue();
/* 119 */       this.node_created = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\JJTOgnlParserState.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */