/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodFailedException
/*    */   extends OgnlException
/*    */ {
/*    */   public MethodFailedException(Object source, String name) {
/* 43 */     super("Method \"" + name + "\" failed for object " + source);
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodFailedException(Object source, String name, Throwable reason) {
/* 48 */     super("Method \"" + name + "\" failed for object " + source, reason);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\MethodFailedException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */