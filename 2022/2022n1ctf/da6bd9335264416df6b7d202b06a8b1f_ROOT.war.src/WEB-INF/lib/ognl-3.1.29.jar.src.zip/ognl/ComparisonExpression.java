/*    */ package ognl;
/*    */ 
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComparisonExpression
/*    */   extends BooleanExpression
/*    */ {
/*    */   public ComparisonExpression(int id) {
/* 16 */     super(id);
/*    */   }
/*    */   
/*    */   public ComparisonExpression(OgnlParser p, int id) {
/* 20 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract String getComparisonFunction();
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 27 */     if (target == null) {
/* 28 */       throw new UnsupportedCompilationException("Current target is null, can't compile.");
/*    */     }
/*    */     
/*    */     try {
/* 32 */       Object value = getValueBody(context, target);
/*    */       
/* 34 */       if (value != null && Boolean.class.isAssignableFrom(value.getClass())) {
/* 35 */         this._getterClass = boolean.class;
/* 36 */       } else if (value != null) {
/* 37 */         this._getterClass = value.getClass();
/*    */       } else {
/* 39 */         this._getterClass = boolean.class;
/*    */       } 
/*    */ 
/*    */       
/* 43 */       OgnlRuntime.getChildSource(context, target, this._children[0]);
/* 44 */       OgnlRuntime.getChildSource(context, target, this._children[1]);
/*    */ 
/*    */ 
/*    */       
/* 48 */       boolean conversion = OgnlRuntime.shouldConvertNumericTypes(context);
/*    */       
/* 50 */       String result = conversion ? ("(" + getComparisonFunction() + "( ($w) (") : "(";
/*    */       
/* 52 */       result = result + OgnlRuntime.getChildSource(context, target, this._children[0], conversion) + " " + (conversion ? "), ($w) " : getExpressionOperator(0)) + " " + OgnlRuntime.getChildSource(context, target, this._children[1], conversion);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 57 */       result = result + (conversion ? ")" : "");
/*    */       
/* 59 */       context.setCurrentType(boolean.class);
/*    */       
/* 61 */       result = result + ")";
/*    */       
/* 63 */       return result;
/* 64 */     } catch (NullPointerException e) {
/*    */ 
/*    */ 
/*    */       
/* 68 */       throw new UnsupportedCompilationException("evaluation resulted in null expression.");
/* 69 */     } catch (Throwable t) {
/*    */       
/* 71 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ComparisonExpression.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */