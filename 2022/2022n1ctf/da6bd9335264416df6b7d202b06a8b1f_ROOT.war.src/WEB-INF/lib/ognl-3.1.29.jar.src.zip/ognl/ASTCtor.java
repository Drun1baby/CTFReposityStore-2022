/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.List;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTCtor
/*     */   extends SimpleNode
/*     */ {
/*     */   private String className;
/*     */   private boolean isArray;
/*     */   
/*     */   public ASTCtor(int id) {
/*  51 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTCtor(OgnlParser p, int id) {
/*  56 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setClassName(String className) {
/*  62 */     this.className = className;
/*     */   }
/*     */   
/*     */   Class getCreatedClass(OgnlContext context) throws ClassNotFoundException {
/*  66 */     return OgnlRuntime.classForName(context, this.className);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setArray(boolean value) {
/*  72 */     this.isArray = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArray() {
/*  77 */     return this.isArray;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  83 */     Object root = context.getRoot();
/*  84 */     int count = jjtGetNumChildren();
/*  85 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(count);
/*     */     try {
/*     */       Object result;
/*  88 */       for (int i = 0; i < count; i++) {
/*  89 */         args[i] = this._children[i].getValue(context, root);
/*     */       }
/*  91 */       if (this.isArray) {
/*  92 */         if (args.length == 1) {
/*     */           try {
/*  94 */             int size; Class<?> componentClass = OgnlRuntime.classForName(context, this.className);
/*  95 */             List sourceList = null;
/*     */ 
/*     */             
/*  98 */             if (args[0] instanceof List) {
/*  99 */               sourceList = (List)args[0];
/* 100 */               size = sourceList.size();
/*     */             } else {
/* 102 */               size = (int)OgnlOps.longValue(args[0]);
/*     */             } 
/* 104 */             result = Array.newInstance(componentClass, size);
/* 105 */             if (sourceList != null) {
/* 106 */               TypeConverter converter = context.getTypeConverter();
/*     */               
/* 108 */               for (int j = 0, icount = sourceList.size(); j < icount; j++) {
/* 109 */                 Object o = sourceList.get(j);
/*     */                 
/* 111 */                 if (o == null || componentClass.isInstance(o)) {
/* 112 */                   Array.set(result, j, o);
/*     */                 } else {
/* 114 */                   Array.set(result, j, converter.convertValue(context, null, null, null, o, componentClass));
/*     */                 }
/*     */               
/*     */               } 
/*     */             } 
/* 119 */           } catch (ClassNotFoundException ex) {
/* 120 */             throw new OgnlException("array component class '" + this.className + "' not found", ex);
/*     */           } 
/*     */         } else {
/* 123 */           throw new OgnlException("only expect array size or fixed initializer list");
/*     */         } 
/*     */       } else {
/* 126 */         result = OgnlRuntime.callConstructor(context, this.className, args);
/*     */       } 
/*     */       
/* 129 */       return result;
/*     */     } finally {
/* 131 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     String result = "new " + this.className;
/*     */     
/* 139 */     if (this.isArray) {
/* 140 */       if (this._children[0] instanceof ASTConst) {
/* 141 */         result = result + "[" + this._children[0] + "]";
/*     */       } else {
/* 143 */         result = result + "[] " + this._children[0];
/*     */       } 
/*     */     } else {
/* 146 */       result = result + "(";
/* 147 */       if (this._children != null && this._children.length > 0) {
/* 148 */         for (int i = 0; i < this._children.length; i++) {
/* 149 */           if (i > 0) {
/* 150 */             result = result + ", ";
/*     */           }
/* 152 */           result = result + this._children[i];
/*     */         } 
/*     */       }
/* 155 */       result = result + ")";
/*     */     } 
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 162 */     String result = "new " + this.className;
/*     */     
/* 164 */     Class clazz = null;
/* 165 */     Object ctorValue = null;
/*     */     
/*     */     try {
/* 168 */       clazz = OgnlRuntime.classForName(context, this.className);
/*     */       
/* 170 */       ctorValue = getValueBody(context, target);
/* 171 */       context.setCurrentObject(ctorValue);
/*     */       
/* 173 */       if (clazz != null && ctorValue != null) {
/*     */         
/* 175 */         context.setCurrentType(ctorValue.getClass());
/* 176 */         context.setCurrentAccessor(ctorValue.getClass());
/*     */       } 
/*     */       
/* 179 */       if (this.isArray) {
/* 180 */         context.put("_ctorClass", clazz);
/*     */       }
/* 182 */     } catch (Throwable t) {
/*     */       
/* 184 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 189 */       if (this.isArray) {
/* 190 */         if (this._children[0] instanceof ASTConst) {
/*     */           
/* 192 */           result = result + "[" + this._children[0].toGetSourceString(context, target) + "]";
/* 193 */         } else if (ASTProperty.class.isInstance(this._children[0])) {
/*     */           
/* 195 */           result = result + "[" + ExpressionCompiler.getRootExpression(this._children[0], target, context) + this._children[0].toGetSourceString(context, target) + "]";
/*     */ 
/*     */         
/*     */         }
/* 199 */         else if (ASTChain.class.isInstance(this._children[0])) {
/*     */           
/* 201 */           result = result + "[" + this._children[0].toGetSourceString(context, target) + "]";
/*     */         } else {
/*     */           
/* 204 */           result = result + "[] " + this._children[0].toGetSourceString(context, target);
/*     */         } 
/*     */       } else {
/*     */         
/* 208 */         result = result + "(";
/*     */         
/* 210 */         if (this._children != null && this._children.length > 0) {
/*     */           
/* 212 */           Object[] values = new Object[this._children.length];
/* 213 */           String[] expressions = new String[this._children.length];
/* 214 */           Class[] types = new Class[this._children.length];
/*     */ 
/*     */ 
/*     */           
/* 218 */           for (int i = 0; i < this._children.length; i++) {
/*     */             
/* 220 */             Object objValue = this._children[i].getValue(context, context.getRoot());
/* 221 */             String value = this._children[i].toGetSourceString(context, target);
/*     */             
/* 223 */             if (!ASTRootVarRef.class.isInstance(this._children[i]))
/*     */             {
/* 225 */               value = ExpressionCompiler.getRootExpression(this._children[i], target, context) + value;
/*     */             }
/*     */             
/* 228 */             String cast = "";
/* 229 */             if (ExpressionCompiler.shouldCast(this._children[i]))
/*     */             {
/* 231 */               cast = (String)context.remove("_preCast");
/*     */             }
/* 233 */             if (cast == null) {
/* 234 */               cast = "";
/*     */             }
/* 236 */             if (!ASTConst.class.isInstance(this._children[i])) {
/* 237 */               value = cast + value;
/*     */             }
/* 239 */             values[i] = objValue;
/* 240 */             expressions[i] = value;
/* 241 */             types[i] = context.getCurrentType();
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 246 */           Constructor[] cons = (Constructor[])clazz.getConstructors();
/* 247 */           Constructor ctor = null;
/* 248 */           Class[] ctorParamTypes = null;
/*     */           int j;
/* 250 */           for (j = 0; j < cons.length; j++) {
/*     */             
/* 252 */             Class[] ctorTypes = cons[j].getParameterTypes();
/*     */             
/* 254 */             if (OgnlRuntime.areArgsCompatible(values, ctorTypes) && (ctor == null || OgnlRuntime.isMoreSpecific(ctorTypes, ctorParamTypes))) {
/*     */               
/* 256 */               ctor = cons[j];
/* 257 */               ctorParamTypes = ctorTypes;
/*     */             } 
/*     */           } 
/*     */           
/* 261 */           if (ctor == null) {
/* 262 */             ctor = OgnlRuntime.getConvertedConstructorAndArgs(context, clazz, OgnlRuntime.getConstructors(clazz), values, new Object[values.length]);
/*     */           }
/* 264 */           if (ctor == null) {
/* 265 */             throw new NoSuchMethodException("Unable to find constructor appropriate for arguments in class: " + clazz);
/*     */           }
/* 267 */           ctorParamTypes = ctor.getParameterTypes();
/*     */ 
/*     */ 
/*     */           
/* 271 */           for (j = 0; j < this._children.length; j++) {
/* 272 */             if (j > 0) {
/* 273 */               result = result + ", ";
/*     */             }
/*     */             
/* 276 */             String value = expressions[j];
/*     */             
/* 278 */             if (types[j].isPrimitive()) {
/*     */               
/* 280 */               String literal = OgnlRuntime.getNumericLiteral(types[j]);
/* 281 */               if (literal != null) {
/* 282 */                 value = value + literal;
/*     */               }
/*     */             } 
/* 285 */             if (ctorParamTypes[j] != types[j])
/*     */             {
/* 287 */               if (values[j] != null && !types[j].isPrimitive() && !values[j].getClass().isArray() && !ASTConst.class.isInstance(this._children[j])) {
/*     */ 
/*     */                 
/* 290 */                 value = "(" + OgnlRuntime.getCompiler().getInterfaceClass(values[j].getClass()).getName() + ")" + value;
/* 291 */               } else if (!ASTConst.class.isInstance(this._children[j]) || (ASTConst.class.isInstance(this._children[j]) && !types[j].isPrimitive())) {
/*     */ 
/*     */                 
/* 294 */                 if (!types[j].isArray() && types[j].isPrimitive() && !ctorParamTypes[j].isPrimitive()) {
/*     */                   
/* 296 */                   value = "new " + ExpressionCompiler.getCastString(OgnlRuntime.getPrimitiveWrapperClass(types[j])) + "(" + value + ")";
/*     */                 } else {
/* 298 */                   value = " ($w) " + value;
/*     */                 } 
/*     */               } 
/*     */             }
/* 302 */             result = result + value;
/*     */           } 
/*     */         } 
/*     */         
/* 306 */         result = result + ")";
/*     */       } 
/*     */       
/* 309 */       context.setCurrentType((ctorValue != null) ? ctorValue.getClass() : clazz);
/* 310 */       context.setCurrentAccessor(clazz);
/* 311 */       context.setCurrentObject(ctorValue);
/*     */     }
/* 313 */     catch (Throwable t) {
/*     */       
/* 315 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 318 */     context.remove("_ctorClass");
/*     */     
/* 320 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 325 */     return "";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTCtor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */