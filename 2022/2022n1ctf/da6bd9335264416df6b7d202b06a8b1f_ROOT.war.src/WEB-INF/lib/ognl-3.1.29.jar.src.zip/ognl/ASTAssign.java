/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.OrderedReturn;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTAssign
/*     */   extends SimpleNode
/*     */ {
/*     */   public ASTAssign(int id) {
/*  43 */     super(id);
/*     */   }
/*     */   
/*     */   public ASTAssign(OgnlParser p, int id) {
/*  47 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  52 */     Object result = this._children[1].getValue(context, source);
/*  53 */     this._children[0].setValue(context, source, result);
/*  54 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  59 */     return this._children[0] + " = " + this._children[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/*  64 */     String result = "";
/*     */     
/*  66 */     String first = this._children[0].toGetSourceString(context, target);
/*  67 */     String second = "";
/*     */     
/*  69 */     if (ASTProperty.class.isInstance(this._children[1])) {
/*  70 */       second = second + "((" + OgnlRuntime.getCompiler().getClassName(target.getClass()) + ")$2).";
/*     */     }
/*     */     
/*  73 */     second = second + this._children[1].toGetSourceString(context, target);
/*     */     
/*  75 */     if (ASTSequence.class.isAssignableFrom(this._children[1].getClass())) {
/*  76 */       ASTSequence seq = (ASTSequence)this._children[1];
/*     */       
/*  78 */       context.setCurrentType(Object.class);
/*     */       
/*  80 */       String core = seq.getCoreExpression();
/*  81 */       if (core.endsWith(";")) {
/*  82 */         core = core.substring(0, core.lastIndexOf(";"));
/*     */       }
/*  84 */       second = OgnlRuntime.getCompiler().createLocalReference(context, "ognl.OgnlOps.returnValue(($w)" + core + ", ($w) " + seq.getLastExpression() + ")", Object.class);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (NodeType.class.isInstance(this._children[1]) && !ASTProperty.class.isInstance(this._children[1]) && ((NodeType)this._children[1]).getGetterClass() != null && !OrderedReturn.class.isInstance(this._children[1]))
/*     */     {
/*     */ 
/*     */       
/*  93 */       second = "new " + ((NodeType)this._children[1]).getGetterClass().getName() + "(" + second + ")";
/*     */     }
/*     */     
/*  96 */     if (OrderedReturn.class.isAssignableFrom(this._children[0].getClass()) && ((OrderedReturn)this._children[0]).getCoreExpression() != null) {
/*     */       
/*  98 */       context.setCurrentType(Object.class);
/*     */       
/* 100 */       result = first + second + ")";
/*     */ 
/*     */ 
/*     */       
/* 104 */       result = OgnlRuntime.getCompiler().createLocalReference(context, "ognl.OgnlOps.returnValue(($w)" + result + ", ($w)" + ((OrderedReturn)this._children[0]).getLastExpression() + ")", Object.class);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 114 */     String result = "";
/*     */     
/* 116 */     result = result + this._children[0].toSetSourceString(context, target);
/*     */     
/* 118 */     if (ASTProperty.class.isInstance(this._children[1])) {
/* 119 */       result = result + "((" + OgnlRuntime.getCompiler().getClassName(target.getClass()) + ")$2).";
/*     */     }
/*     */     
/* 122 */     String value = this._children[1].toSetSourceString(context, target);
/*     */     
/* 124 */     if (value == null) {
/* 125 */       throw new UnsupportedCompilationException("Value for assignment is null, can't enhance statement to bytecode.");
/*     */     }
/* 127 */     if (ASTSequence.class.isAssignableFrom(this._children[1].getClass())) {
/* 128 */       ASTSequence seq = (ASTSequence)this._children[1];
/* 129 */       result = seq.getCoreExpression() + result;
/* 130 */       value = seq.getLastExpression();
/*     */     } 
/*     */     
/* 133 */     if (NodeType.class.isInstance(this._children[1]) && !ASTProperty.class.isInstance(this._children[1]) && ((NodeType)this._children[1]).getGetterClass() != null)
/*     */     {
/*     */ 
/*     */       
/* 137 */       value = "new " + ((NodeType)this._children[1]).getGetterClass().getName() + "(" + value + ")";
/*     */     }
/*     */     
/* 140 */     return result + value + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOperation(OgnlContext context) {
/* 145 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTAssign.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */