/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTMultiply
/*    */   extends NumericExpression
/*    */ {
/*    */   public ASTMultiply(int id) {
/* 41 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTMultiply(OgnlParser p, int id) {
/* 45 */     super(p, id);
/*    */   }
/*    */   
/*    */   public void jjtClose() {
/* 49 */     flattenTree();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 54 */     Object result = this._children[0].getValue(context, source);
/* 55 */     for (int i = 1; i < this._children.length; i++)
/* 56 */       result = OgnlOps.multiply(result, this._children[i].getValue(context, source)); 
/* 57 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 62 */     return "*";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTMultiply.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */