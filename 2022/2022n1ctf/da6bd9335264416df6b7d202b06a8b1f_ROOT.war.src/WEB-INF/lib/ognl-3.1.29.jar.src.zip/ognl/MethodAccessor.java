package ognl;

import java.util.Map;

public interface MethodAccessor {
  Object callStaticMethod(Map paramMap, Class paramClass, String paramString, Object[] paramArrayOfObject) throws MethodFailedException;
  
  Object callMethod(Map paramMap, Object paramObject, String paramString, Object[] paramArrayOfObject) throws MethodFailedException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\MethodAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */