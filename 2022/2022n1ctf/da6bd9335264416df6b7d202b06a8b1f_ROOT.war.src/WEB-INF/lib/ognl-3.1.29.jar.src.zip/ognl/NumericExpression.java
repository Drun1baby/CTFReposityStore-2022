/*    */ package ognl;
/*    */ 
/*    */ import ognl.enhance.ExpressionCompiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NumericExpression
/*    */   extends ExpressionNode
/*    */   implements NodeType
/*    */ {
/*    */   protected Class _getterClass;
/*    */   
/*    */   public NumericExpression(int id) {
/* 17 */     super(id);
/*    */   }
/*    */   
/*    */   public NumericExpression(OgnlParser p, int id) {
/* 21 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getGetterClass() {
/* 26 */     if (this._getterClass != null) {
/* 27 */       return this._getterClass;
/*    */     }
/* 29 */     return double.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class getSetterClass() {
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 39 */     Object value = null;
/* 40 */     String result = "";
/*    */ 
/*    */     
/*    */     try {
/* 44 */       value = getValueBody(context, target);
/*    */       
/* 46 */       if (value != null) {
/* 47 */         this._getterClass = value.getClass();
/*    */       }
/* 49 */       for (int i = 0; i < this._children.length; i++)
/*    */       {
/* 51 */         if (i > 0) {
/* 52 */           result = result + " " + getExpressionOperator(i) + " ";
/*    */         }
/* 54 */         String str = OgnlRuntime.getChildSource(context, target, this._children[i]);
/*    */         
/* 56 */         result = result + coerceToNumeric(str, context, this._children[i]);
/*    */       }
/*    */     
/* 59 */     } catch (Throwable t) {
/*    */       
/* 61 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */     
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String coerceToNumeric(String source, OgnlContext context, Node child) {
/* 69 */     String ret = source;
/* 70 */     Object value = context.getCurrentObject();
/*    */     
/* 72 */     if (ASTConst.class.isInstance(child) && value != null)
/*    */     {
/* 74 */       return value.toString();
/*    */     }
/*    */     
/* 77 */     if (context.getCurrentType() != null && !context.getCurrentType().isPrimitive() && context.getCurrentObject() != null && Number.class.isInstance(context.getCurrentObject())) {
/*    */ 
/*    */       
/* 80 */       ret = "((" + ExpressionCompiler.getCastString(context.getCurrentObject().getClass()) + ")" + ret + ")";
/* 81 */       ret = ret + "." + OgnlRuntime.getNumericValueGetter(context.getCurrentObject().getClass());
/* 82 */     } else if (context.getCurrentType() != null && context.getCurrentType().isPrimitive() && (ASTConst.class.isInstance(child) || NumericExpression.class.isInstance(child))) {
/*    */ 
/*    */       
/* 85 */       ret = ret + OgnlRuntime.getNumericLiteral(context.getCurrentType());
/* 86 */     } else if (context.getCurrentType() != null && String.class.isAssignableFrom(context.getCurrentType())) {
/*    */       
/* 88 */       ret = "Double.parseDouble(" + ret + ")";
/* 89 */       context.setCurrentType(double.class);
/*    */     } 
/*    */     
/* 92 */     if (NumericExpression.class.isInstance(child)) {
/* 93 */       ret = "(" + ret + ")";
/*    */     }
/* 95 */     return ret;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\NumericExpression.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */