/*      */ package ognl;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import ognl.enhance.UnsupportedCompilationException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class OgnlOps
/*      */   implements NumericTypes
/*      */ {
/*      */   public static int compareWithConversion(Object v1, Object v2) {
/*      */     int result;
/*   73 */     if (v1 == v2)
/*   74 */     { result = 0; }
/*      */     else
/*   76 */     { double dv1, dv2; int t1 = getNumericType(v1), t2 = getNumericType(v2), type = getNumericType(t1, t2, true);
/*      */       
/*   78 */       switch (type)
/*      */       { case 6:
/*   80 */           result = bigIntValue(v1).compareTo(bigIntValue(v2));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  116 */           return result;case 9: result = bigDecValue(v1).compareTo(bigDecValue(v2)); return result;case 10: if (t1 == 10 && t2 == 10) { if (v1 instanceof Comparable && v1.getClass().isAssignableFrom(v2.getClass())) { result = ((Comparable<Object>)v1).compareTo(v2); } else if (v1 instanceof Enum && v2 instanceof Enum && (v1.getClass() == v2.getClass() || ((Enum)v1).getDeclaringClass() == ((Enum)v2).getDeclaringClass())) { result = ((Enum)v1).compareTo(v2); } else { throw new IllegalArgumentException("invalid comparison: " + v1.getClass().getName() + " and " + v2.getClass().getName()); }  return result; } case 7: case 8: dv1 = doubleValue(v1); dv2 = doubleValue(v2); return (dv1 == dv2) ? 0 : ((dv1 < dv2) ? -1 : 1); }  long lv1 = longValue(v1); long lv2 = longValue(v2); return (lv1 == lv2) ? 0 : ((lv1 < lv2) ? -1 : 1); }  return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEqual(Object object1, Object object2) {
/*  131 */     boolean result = false;
/*      */     
/*  133 */     if (object1 == object2) {
/*  134 */       result = true;
/*  135 */     } else if (object1 != null && object2 != null) {
/*  136 */       if (object1.getClass().isArray()) {
/*  137 */         if (object2.getClass().isArray() && object2.getClass() == object1.getClass()) {
/*  138 */           result = (Array.getLength(object1) == Array.getLength(object2));
/*  139 */           if (result) {
/*  140 */             for (int i = 0, icount = Array.getLength(object1); result && i < icount; i++) {
/*  141 */               result = isEqual(Array.get(object1, i), Array.get(object2, i));
/*      */             }
/*      */           }
/*      */         } 
/*      */       } else {
/*  146 */         int t1 = getNumericType(object1);
/*  147 */         int t2 = getNumericType(object2);
/*      */ 
/*      */         
/*  150 */         if (t1 == 10 && t2 == 10 && (!(object1 instanceof Comparable) || !(object2 instanceof Comparable))) {
/*  151 */           result = object1.equals(object2);
/*      */         } else {
/*  153 */           result = (compareWithConversion(object1, object2) == 0);
/*      */         } 
/*      */       } 
/*      */     } 
/*  157 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(boolean value) {
/*  162 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(int value) {
/*  167 */     return (value > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(float value) {
/*  172 */     return (value > 0.0F);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(long value) {
/*  177 */     return (value > 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(double value) {
/*  182 */     return (value > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean booleanValue(Object value) {
/*  196 */     if (value == null)
/*  197 */       return false; 
/*  198 */     Class<?> c = value.getClass();
/*      */     
/*  200 */     if (c == Boolean.class) {
/*  201 */       return ((Boolean)value).booleanValue();
/*      */     }
/*  203 */     if (c == String.class) {
/*  204 */       return Boolean.parseBoolean(String.valueOf(value));
/*      */     }
/*  206 */     if (c == Character.class)
/*  207 */       return (((Character)value).charValue() != '\000'); 
/*  208 */     if (value instanceof Number) {
/*  209 */       return (((Number)value).doubleValue() != 0.0D);
/*      */     }
/*  211 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long longValue(Object value) throws NumberFormatException {
/*  226 */     if (value == null) return 0L; 
/*  227 */     Class<?> c = value.getClass();
/*  228 */     if (c.getSuperclass() == Number.class) return ((Number)value).longValue(); 
/*  229 */     if (c == Boolean.class) return ((Boolean)value).booleanValue() ? 1L : 0L; 
/*  230 */     if (c == Character.class) return ((Character)value).charValue(); 
/*  231 */     return Long.parseLong(stringValue(value, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double doubleValue(Object value) throws NumberFormatException {
/*  246 */     if (value == null) return 0.0D; 
/*  247 */     Class<?> c = value.getClass();
/*  248 */     if (c.getSuperclass() == Number.class) return ((Number)value).doubleValue(); 
/*  249 */     if (c == Boolean.class) return ((Boolean)value).booleanValue() ? 1.0D : 0.0D; 
/*  250 */     if (c == Character.class) return ((Character)value).charValue(); 
/*  251 */     String s = stringValue(value, true);
/*      */     
/*  253 */     return (s.length() == 0) ? 0.0D : Double.parseDouble(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger bigIntValue(Object value) throws NumberFormatException {
/*  268 */     if (value == null) return BigInteger.valueOf(0L); 
/*  269 */     Class<?> c = value.getClass();
/*  270 */     if (c == BigInteger.class) return (BigInteger)value; 
/*  271 */     if (c == BigDecimal.class) return ((BigDecimal)value).toBigInteger(); 
/*  272 */     if (c.getSuperclass() == Number.class) return BigInteger.valueOf(((Number)value).longValue()); 
/*  273 */     if (c == Boolean.class) return BigInteger.valueOf(((Boolean)value).booleanValue() ? 1L : 0L); 
/*  274 */     if (c == Character.class) return BigInteger.valueOf(((Character)value).charValue()); 
/*  275 */     return new BigInteger(stringValue(value, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal bigDecValue(Object value) throws NumberFormatException {
/*  290 */     if (value == null) return BigDecimal.valueOf(0L); 
/*  291 */     Class<?> c = value.getClass();
/*  292 */     if (c == BigDecimal.class) return (BigDecimal)value; 
/*  293 */     if (c == BigInteger.class) return new BigDecimal((BigInteger)value); 
/*  294 */     if (c == Boolean.class) return BigDecimal.valueOf(((Boolean)value).booleanValue() ? 1L : 0L); 
/*  295 */     if (c == Character.class) return BigDecimal.valueOf(((Character)value).charValue()); 
/*  296 */     return new BigDecimal(stringValue(value, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stringValue(Object value, boolean trim) {
/*      */     String result;
/*  313 */     if (value == null) {
/*  314 */       result = OgnlRuntime.NULL_STRING;
/*      */     } else {
/*  316 */       result = value.toString();
/*  317 */       if (trim) {
/*  318 */         result = result.trim();
/*      */       }
/*      */     } 
/*  321 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stringValue(Object value) {
/*  334 */     return stringValue(value, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNumericType(Object value) {
/*  347 */     if (value != null) {
/*  348 */       Class<?> c = value.getClass();
/*  349 */       if (c == Integer.class) return 4; 
/*  350 */       if (c == Double.class) return 8; 
/*  351 */       if (c == Boolean.class) return 0; 
/*  352 */       if (c == Byte.class) return 1; 
/*  353 */       if (c == Character.class) return 2; 
/*  354 */       if (c == Short.class) return 3; 
/*  355 */       if (c == Long.class) return 5; 
/*  356 */       if (c == Float.class) return 7; 
/*  357 */       if (c == BigInteger.class) return 6; 
/*  358 */       if (c == BigDecimal.class) return 9; 
/*      */     } 
/*  360 */     return 10;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(char value, Class toType) {
/*  365 */     return toArray(new Character(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(byte value, Class toType) {
/*  370 */     return toArray(new Byte(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(int value, Class toType) {
/*  375 */     return toArray(new Integer(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(long value, Class toType) {
/*  380 */     return toArray(new Long(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(float value, Class toType) {
/*  385 */     return toArray(new Float(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(double value, Class toType) {
/*  390 */     return toArray(new Double(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(boolean value, Class toType) {
/*  395 */     return toArray(new Boolean(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(char value, Class toType) {
/*  400 */     return convertValue(new Character(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(byte value, Class toType) {
/*  405 */     return convertValue(new Byte(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(int value, Class toType) {
/*  410 */     return convertValue(new Integer(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(long value, Class toType) {
/*  415 */     return convertValue(new Long(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(float value, Class toType) {
/*  420 */     return convertValue(new Float(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(double value, Class toType) {
/*  425 */     return convertValue(new Double(value), toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(boolean value, Class toType) {
/*  430 */     return convertValue(new Boolean(value), toType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object convertValue(char value, Class toType, boolean preventNull) {
/*  437 */     return convertValue(new Character(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(byte value, Class toType, boolean preventNull) {
/*  442 */     return convertValue(new Byte(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(int value, Class toType, boolean preventNull) {
/*  447 */     return convertValue(new Integer(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(long value, Class toType, boolean preventNull) {
/*  452 */     return convertValue(new Long(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(float value, Class toType, boolean preventNull) {
/*  457 */     return convertValue(new Float(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(double value, Class toType, boolean preventNull) {
/*  462 */     return convertValue(new Double(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(boolean value, Class toType, boolean preventNull) {
/*  467 */     return convertValue(new Boolean(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(char value, Class toType, boolean preventNull) {
/*  475 */     return toArray(new Character(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(byte value, Class toType, boolean preventNull) {
/*  480 */     return toArray(new Byte(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(int value, Class toType, boolean preventNull) {
/*  485 */     return toArray(new Integer(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(long value, Class toType, boolean preventNull) {
/*  490 */     return toArray(new Long(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(float value, Class toType, boolean preventNull) {
/*  495 */     return toArray(new Float(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(double value, Class toType, boolean preventNull) {
/*  500 */     return toArray(new Double(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(boolean value, Class toType, boolean preventNull) {
/*  505 */     return toArray(new Boolean(value), toType, preventNull);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object convertValue(Object value, Class toType) {
/*  522 */     return convertValue(value, toType, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(Object value, Class toType) {
/*  527 */     return toArray(value, toType, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object toArray(Object value, Class<char> toType, boolean preventNulls) {
/*  532 */     if (value == null) {
/*  533 */       return null;
/*      */     }
/*  535 */     Object result = null;
/*      */     
/*  537 */     if (value.getClass().isArray() && toType.isAssignableFrom(value.getClass().getComponentType())) {
/*  538 */       return value;
/*      */     }
/*  540 */     if (!value.getClass().isArray()) {
/*      */       
/*  542 */       if (toType == char.class) {
/*  543 */         return stringValue(value).toCharArray();
/*      */       }
/*  545 */       if (value instanceof Collection) {
/*  546 */         return ((Collection)value).toArray((Object[])Array.newInstance(toType, 0));
/*      */       }
/*  548 */       Object arr = Array.newInstance(toType, 1);
/*  549 */       Array.set(arr, 0, convertValue(value, toType, preventNulls));
/*      */       
/*  551 */       return arr;
/*      */     } 
/*      */     
/*  554 */     result = Array.newInstance(toType, Array.getLength(value));
/*  555 */     for (int i = 0, icount = Array.getLength(value); i < icount; i++) {
/*  556 */       Array.set(result, i, convertValue(Array.get(value, i), toType));
/*      */     }
/*      */     
/*  559 */     if (result == null && preventNulls) {
/*  560 */       return value;
/*      */     }
/*  562 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object convertValue(Object value, Class<Integer> toType, boolean preventNulls) {
/*  567 */     Object result = null;
/*      */     
/*  569 */     if (value != null && toType.isAssignableFrom(value.getClass())) {
/*  570 */       return value;
/*      */     }
/*  572 */     if (value != null) {
/*      */       
/*  574 */       if (value.getClass().isArray() && toType.isArray()) {
/*  575 */         Class<?> componentType = toType.getComponentType();
/*      */         
/*  577 */         result = Array.newInstance(componentType, Array.getLength(value));
/*  578 */         for (int i = 0, icount = Array.getLength(value); i < icount; i++)
/*  579 */           Array.set(result, i, convertValue(Array.get(value, i), componentType)); 
/*      */       } else {
/*  581 */         if (value.getClass().isArray() && !toType.isArray())
/*      */         {
/*  583 */           return convertValue(Array.get(value, 0), toType); } 
/*  584 */         if (!value.getClass().isArray() && toType.isArray()) {
/*      */           
/*  586 */           if (toType.getComponentType() == char.class) {
/*      */             
/*  588 */             result = stringValue(value).toCharArray();
/*  589 */           } else if (toType.getComponentType() == Object.class) {
/*  590 */             if (value instanceof Collection) {
/*  591 */               Collection vc = (Collection)value;
/*  592 */               return vc.toArray(new Object[0]);
/*      */             } 
/*  594 */             return new Object[] { value };
/*      */           } 
/*      */         } else {
/*  597 */           if (toType == Integer.class || toType == int.class) {
/*  598 */             result = new Integer((int)longValue(value));
/*      */           }
/*  600 */           if (toType == Double.class || toType == double.class) result = new Double(doubleValue(value)); 
/*  601 */           if (toType == Boolean.class || toType == boolean.class)
/*  602 */             result = booleanValue(value) ? Boolean.TRUE : Boolean.FALSE; 
/*  603 */           if (toType == Byte.class || toType == byte.class) result = new Byte((byte)(int)longValue(value)); 
/*  604 */           if (toType == Character.class || toType == char.class)
/*  605 */             result = new Character((char)(int)longValue(value)); 
/*  606 */           if (toType == Short.class || toType == short.class) result = new Short((short)(int)longValue(value)); 
/*  607 */           if (toType == Long.class || toType == long.class) result = new Long(longValue(value)); 
/*  608 */           if (toType == Float.class || toType == float.class) result = new Float(doubleValue(value)); 
/*  609 */           if (toType == BigInteger.class) result = bigIntValue(value); 
/*  610 */           if (toType == BigDecimal.class) result = bigDecValue(value); 
/*  611 */           if (toType == String.class) result = stringValue(value); 
/*      */         } 
/*      */       } 
/*  614 */     } else if (toType.isPrimitive()) {
/*  615 */       result = OgnlRuntime.getPrimitiveDefaultValue(toType);
/*  616 */     } else if (preventNulls && toType == Boolean.class) {
/*  617 */       result = Boolean.FALSE;
/*  618 */     } else if (preventNulls && Number.class.isAssignableFrom(toType)) {
/*  619 */       result = OgnlRuntime.getNumericDefaultValue(toType);
/*      */     } 
/*      */ 
/*      */     
/*  623 */     if (result == null && preventNulls) {
/*  624 */       return value;
/*      */     }
/*  626 */     if (value != null && result == null)
/*      */     {
/*  628 */       throw new IllegalArgumentException("Unable to convert type " + value.getClass().getName() + " of " + value + " to type of " + toType.getName());
/*      */     }
/*      */     
/*  631 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getIntValue(Object value) {
/*      */     try {
/*  651 */       if (value == null) {
/*  652 */         return -1;
/*      */       }
/*  654 */       if (Number.class.isInstance(value))
/*      */       {
/*  656 */         return ((Number)value).intValue();
/*      */       }
/*      */       
/*  659 */       String str = String.class.isInstance(value) ? (String)value : value.toString();
/*      */       
/*  661 */       return Integer.parseInt(str);
/*      */     }
/*  663 */     catch (Throwable t) {
/*      */       
/*  665 */       throw new RuntimeException("Error converting " + value + " to integer:", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNumericType(Object v1, Object v2) {
/*  681 */     return getNumericType(v1, v2, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNumericType(int t1, int t2, boolean canBeNonNumeric) {
/*  698 */     if (t1 == t2) return t1;
/*      */     
/*  700 */     if (canBeNonNumeric && (t1 == 10 || t2 == 10 || t1 == 2 || t2 == 2)) return 10;
/*      */     
/*  702 */     if (t1 == 10) t1 = 8; 
/*  703 */     if (t2 == 10) t2 = 8;
/*      */     
/*  705 */     if (t1 >= 7) {
/*  706 */       if (t2 >= 7) return Math.max(t1, t2); 
/*  707 */       if (t2 < 4) return t1; 
/*  708 */       if (t2 == 6) return 9; 
/*  709 */       return Math.max(8, t1);
/*  710 */     }  if (t2 >= 7) {
/*  711 */       if (t1 < 4) return t2; 
/*  712 */       if (t1 == 6) return 9; 
/*  713 */       return Math.max(8, t2);
/*  714 */     }  return Math.max(t1, t2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNumericType(Object v1, Object v2, boolean canBeNonNumeric) {
/*  731 */     return getNumericType(getNumericType(v1), getNumericType(v2), canBeNonNumeric);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number newInteger(int type, long value) {
/*  747 */     switch (type) {
/*      */       case 0:
/*      */       case 2:
/*      */       case 4:
/*  751 */         return new Integer((int)value);
/*      */       
/*      */       case 7:
/*  754 */         if ((long)(float)value == value) return new Float((float)value);
/*      */       
/*      */       case 8:
/*  757 */         if ((long)value == value) return new Double(value);
/*      */       
/*      */       case 5:
/*  760 */         return new Long(value);
/*      */       
/*      */       case 1:
/*  763 */         return new Byte((byte)(int)value);
/*      */       
/*      */       case 3:
/*  766 */         return new Short((short)(int)value);
/*      */     } 
/*      */     
/*  769 */     return BigInteger.valueOf(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number newReal(int type, double value) {
/*  786 */     if (type == 7) return new Float((float)value); 
/*  787 */     return new Double(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object binaryOr(Object v1, Object v2) {
/*  792 */     int type = getNumericType(v1, v2);
/*  793 */     if (type == 6 || type == 9) return bigIntValue(v1).or(bigIntValue(v2)); 
/*  794 */     return newInteger(type, longValue(v1) | longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object binaryXor(Object v1, Object v2) {
/*  799 */     int type = getNumericType(v1, v2);
/*  800 */     if (type == 6 || type == 9) return bigIntValue(v1).xor(bigIntValue(v2)); 
/*  801 */     return newInteger(type, longValue(v1) ^ longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object binaryAnd(Object v1, Object v2) {
/*  806 */     int type = getNumericType(v1, v2);
/*  807 */     if (type == 6 || type == 9) return bigIntValue(v1).and(bigIntValue(v2)); 
/*  808 */     return newInteger(type, longValue(v1) & longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean equal(Object v1, Object v2) {
/*  813 */     if (v1 == null) return (v2 == null); 
/*  814 */     if (v1 == v2 || isEqual(v1, v2)) return true; 
/*  815 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean less(Object v1, Object v2) {
/*  820 */     return (compareWithConversion(v1, v2) < 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean greater(Object v1, Object v2) {
/*  825 */     return (compareWithConversion(v1, v2) > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean in(Object v1, Object v2) throws OgnlException {
/*  831 */     if (v2 == null) {
/*  832 */       return false;
/*      */     }
/*  834 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(v2));
/*      */     
/*  836 */     for (Enumeration e = elementsAccessor.getElements(v2); e.hasMoreElements(); ) {
/*  837 */       Object o = e.nextElement();
/*      */       
/*  839 */       if (equal(v1, o)) {
/*  840 */         return true;
/*      */       }
/*      */     } 
/*  843 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object shiftLeft(Object v1, Object v2) {
/*  848 */     int type = getNumericType(v1);
/*  849 */     if (type == 6 || type == 9) return bigIntValue(v1).shiftLeft((int)longValue(v2)); 
/*  850 */     return newInteger(type, longValue(v1) << (int)longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object shiftRight(Object v1, Object v2) {
/*  855 */     int type = getNumericType(v1);
/*  856 */     if (type == 6 || type == 9) return bigIntValue(v1).shiftRight((int)longValue(v2)); 
/*  857 */     return newInteger(type, longValue(v1) >> (int)longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object unsignedShiftRight(Object v1, Object v2) {
/*  862 */     int type = getNumericType(v1);
/*  863 */     if (type == 6 || type == 9) return bigIntValue(v1).shiftRight((int)longValue(v2)); 
/*  864 */     if (type <= 4) return newInteger(4, ((int)longValue(v1) >>> (int)longValue(v2))); 
/*  865 */     return newInteger(type, longValue(v1) >>> (int)longValue(v2));
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object add(Object v1, Object v2) {
/*  870 */     int t1, t2, type = getNumericType(v1, v2, true);
/*  871 */     switch (type) {
/*      */       case 6:
/*  873 */         return bigIntValue(v1).add(bigIntValue(v2));
/*      */       case 9:
/*  875 */         return bigDecValue(v1).add(bigDecValue(v2));
/*      */       case 7:
/*      */       case 8:
/*  878 */         return newReal(type, doubleValue(v1) + doubleValue(v2));
/*      */       case 10:
/*  880 */         t1 = getNumericType(v1);
/*  881 */         t2 = getNumericType(v2);
/*      */         
/*  883 */         if ((t1 != 10 && v2 == null) || (t2 != 10 && v1 == null)) {
/*  884 */           throw new NullPointerException("Can't add values " + v1 + " , " + v2);
/*      */         }
/*      */         
/*  887 */         return stringValue(v1) + stringValue(v2);
/*      */     } 
/*  889 */     return newInteger(type, longValue(v1) + longValue(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object subtract(Object v1, Object v2) {
/*  895 */     int type = getNumericType(v1, v2);
/*  896 */     switch (type) {
/*      */       case 6:
/*  898 */         return bigIntValue(v1).subtract(bigIntValue(v2));
/*      */       case 9:
/*  900 */         return bigDecValue(v1).subtract(bigDecValue(v2));
/*      */       case 7:
/*      */       case 8:
/*  903 */         return newReal(type, doubleValue(v1) - doubleValue(v2));
/*      */     } 
/*  905 */     return newInteger(type, longValue(v1) - longValue(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object multiply(Object v1, Object v2) {
/*  911 */     int type = getNumericType(v1, v2);
/*  912 */     switch (type) {
/*      */       case 6:
/*  914 */         return bigIntValue(v1).multiply(bigIntValue(v2));
/*      */       case 9:
/*  916 */         return bigDecValue(v1).multiply(bigDecValue(v2));
/*      */       case 7:
/*      */       case 8:
/*  919 */         return newReal(type, doubleValue(v1) * doubleValue(v2));
/*      */     } 
/*  921 */     return newInteger(type, longValue(v1) * longValue(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object divide(Object v1, Object v2) {
/*  927 */     int type = getNumericType(v1, v2);
/*  928 */     switch (type) {
/*      */       case 6:
/*  930 */         return bigIntValue(v1).divide(bigIntValue(v2));
/*      */       case 9:
/*  932 */         return bigDecValue(v1).divide(bigDecValue(v2), 6);
/*      */       case 7:
/*      */       case 8:
/*  935 */         return newReal(type, doubleValue(v1) / doubleValue(v2));
/*      */     } 
/*  937 */     return newInteger(type, longValue(v1) / longValue(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object remainder(Object v1, Object v2) {
/*  943 */     int type = getNumericType(v1, v2);
/*  944 */     switch (type) {
/*      */       case 6:
/*      */       case 9:
/*  947 */         return bigIntValue(v1).remainder(bigIntValue(v2));
/*      */     } 
/*  949 */     return newInteger(type, longValue(v1) % longValue(v2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object negate(Object value) {
/*  955 */     int type = getNumericType(value);
/*  956 */     switch (type) {
/*      */       case 6:
/*  958 */         return bigIntValue(value).negate();
/*      */       case 9:
/*  960 */         return bigDecValue(value).negate();
/*      */       case 7:
/*      */       case 8:
/*  963 */         return newReal(type, -doubleValue(value));
/*      */     } 
/*  965 */     return newInteger(type, -longValue(value));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object bitNegate(Object value) {
/*  971 */     int type = getNumericType(value);
/*  972 */     switch (type) {
/*      */       case 6:
/*      */       case 9:
/*  975 */         return bigIntValue(value).not();
/*      */     } 
/*  977 */     return newInteger(type, longValue(value) ^ 0xFFFFFFFFFFFFFFFFL);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getEscapeString(String value) {
/*  983 */     StringBuffer result = new StringBuffer();
/*      */     
/*  985 */     for (int i = 0, icount = value.length(); i < icount; i++) {
/*  986 */       result.append(getEscapedChar(value.charAt(i)));
/*      */     }
/*  988 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getEscapedChar(char ch) {
/*      */     String result;
/*  995 */     switch (ch)
/*      */     { case '\b':
/*  997 */         result = "\b";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1045 */         return result;case '\t': result = "\\t"; return result;case '\n': result = "\\n"; return result;case '\f': result = "\\f"; return result;case '\r': result = "\\r"; return result;case '"': result = "\\\""; return result;case '\'': result = "\\'"; return result;case '\\': result = "\\\\"; return result; }  if (Character.isISOControl(ch)) { String hc = Integer.toString(ch, 16); int hcl = hc.length(); result = "\\u"; if (hcl < 4) if (hcl == 3) { result = result + "0"; } else if (hcl == 2) { result = result + "00"; } else { result = result + "000"; }   result = result + hc; } else { result = new String(ch + ""); }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object returnValue(Object ignore, Object returnValue) {
/* 1050 */     return returnValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RuntimeException castToRuntime(Throwable t) {
/* 1063 */     if (RuntimeException.class.isInstance(t)) {
/* 1064 */       return (RuntimeException)t;
/*      */     }
/* 1066 */     if (OgnlException.class.isInstance(t)) {
/* 1067 */       throw new UnsupportedCompilationException("Error evluating expression: " + t.getMessage(), t);
/*      */     }
/* 1069 */     return new RuntimeException(t);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlOps.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */