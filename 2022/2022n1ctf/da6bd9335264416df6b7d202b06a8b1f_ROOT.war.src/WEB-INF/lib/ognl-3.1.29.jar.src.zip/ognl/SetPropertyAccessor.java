/*    */ package ognl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetPropertyAccessor
/*    */   extends ObjectPropertyAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/* 47 */     Set set = (Set)target;
/*    */     
/* 49 */     if (name instanceof String) {
/*    */       Object result;
/*    */       
/* 52 */       if (name.equals("size")) {
/* 53 */         result = new Integer(set.size());
/*    */       }
/* 55 */       else if (name.equals("iterator")) {
/* 56 */         result = set.iterator();
/*    */       }
/* 58 */       else if (name.equals("isEmpty")) {
/* 59 */         result = set.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*    */       } else {
/* 61 */         result = super.getProperty(context, target, name);
/*    */       } 
/*    */ 
/*    */       
/* 65 */       return result;
/*    */     } 
/*    */     
/* 68 */     throw new NoSuchPropertyException(target, name);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\SetPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */