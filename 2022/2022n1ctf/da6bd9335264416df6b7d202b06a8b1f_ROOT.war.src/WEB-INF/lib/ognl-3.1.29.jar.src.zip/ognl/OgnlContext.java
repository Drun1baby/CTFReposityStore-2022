/*     */ package ognl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import ognl.enhance.LocalReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OgnlContext
/*     */   implements Map
/*     */ {
/*     */   public static final String ROOT_CONTEXT_KEY = "root";
/*     */   public static final String THIS_CONTEXT_KEY = "this";
/*     */   public static final String TRACE_EVALUATIONS_CONTEXT_KEY = "_traceEvaluations";
/*     */   public static final String LAST_EVALUATION_CONTEXT_KEY = "_lastEvaluation";
/*     */   public static final String KEEP_LAST_EVALUATION_CONTEXT_KEY = "_keepLastEvaluation";
/*     */   public static final String TYPE_CONVERTER_CONTEXT_KEY = "_typeConverter";
/*     */   private static final String PROPERTY_KEY_PREFIX = "ognl";
/*     */   private static boolean DEFAULT_TRACE_EVALUATIONS = false;
/*     */   private static boolean DEFAULT_KEEP_LAST_EVALUATION = false;
/*  57 */   public static final ClassResolver DEFAULT_CLASS_RESOLVER = new DefaultClassResolver();
/*  58 */   public static final TypeConverter DEFAULT_TYPE_CONVERTER = new DefaultTypeConverter();
/*  59 */   public static final MemberAccess DEFAULT_MEMBER_ACCESS = new DefaultMemberAccess(false);
/*     */   
/*  61 */   private static Map RESERVED_KEYS = new HashMap<>(11);
/*     */   
/*     */   private Object _root;
/*     */   private Object _currentObject;
/*     */   private Node _currentNode;
/*  66 */   private boolean _traceEvaluations = DEFAULT_TRACE_EVALUATIONS;
/*     */   private Evaluation _rootEvaluation;
/*     */   private Evaluation _currentEvaluation;
/*     */   private Evaluation _lastEvaluation;
/*  70 */   private boolean _keepLastEvaluation = DEFAULT_KEEP_LAST_EVALUATION;
/*     */   
/*     */   private final Map _values;
/*     */   
/*  74 */   private ClassResolver _classResolver = DEFAULT_CLASS_RESOLVER;
/*  75 */   private TypeConverter _typeConverter = DEFAULT_TYPE_CONVERTER;
/*  76 */   private MemberAccess _memberAccess = DEFAULT_MEMBER_ACCESS;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  81 */     RESERVED_KEYS.put("root", null);
/*  82 */     RESERVED_KEYS.put("this", null);
/*  83 */     RESERVED_KEYS.put("_traceEvaluations", null);
/*  84 */     RESERVED_KEYS.put("_lastEvaluation", null);
/*  85 */     RESERVED_KEYS.put("_keepLastEvaluation", null);
/*  86 */     RESERVED_KEYS.put("_typeConverter", null);
/*     */     try {
/*     */       String s;
/*  89 */       if ((s = System.getProperty("ognl.traceEvaluations")) != null) {
/*  90 */         DEFAULT_TRACE_EVALUATIONS = Boolean.valueOf(s.trim()).booleanValue();
/*     */       }
/*  92 */       if ((s = System.getProperty("ognl.keepLastEvaluation")) != null) {
/*  93 */         DEFAULT_KEEP_LAST_EVALUATION = Boolean.valueOf(s.trim()).booleanValue();
/*     */       }
/*  95 */     } catch (SecurityException securityException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 100 */   private final List _typeStack = new ArrayList(3);
/* 101 */   private final List _accessorStack = new ArrayList(3);
/*     */   
/* 103 */   private int _localReferenceCounter = 0;
/* 104 */   private Map _localReferenceMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlContext() {
/* 113 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlContext(ClassResolver classResolver, TypeConverter typeConverter, MemberAccess memberAccess) {
/* 127 */     this(classResolver, typeConverter, memberAccess, new HashMap<>(23));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlContext(Map values) {
/* 133 */     this(null, null, null, values);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OgnlContext(ClassResolver classResolver, TypeConverter typeConverter, MemberAccess memberAccess, Map values) {
/* 139 */     this._values = values;
/* 140 */     if (classResolver != null) {
/* 141 */       this._classResolver = classResolver;
/*     */     }
/* 143 */     if (typeConverter != null) {
/* 144 */       this._typeConverter = typeConverter;
/*     */     }
/* 146 */     if (memberAccess != null) {
/* 147 */       this._memberAccess = memberAccess;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValues(Map value) {
/* 153 */     for (Iterator it = value.keySet().iterator(); it.hasNext(); ) {
/* 154 */       Object k = it.next();
/*     */       
/* 156 */       this._values.put(k, value.get(k));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Map getValues() {
/* 162 */     return this._values;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassResolver(ClassResolver value) {
/* 167 */     if (value == null) throw new IllegalArgumentException("cannot set ClassResolver to null"); 
/* 168 */     this._classResolver = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassResolver getClassResolver() {
/* 173 */     return this._classResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeConverter(TypeConverter value) {
/* 178 */     if (value == null) throw new IllegalArgumentException("cannot set TypeConverter to null"); 
/* 179 */     this._typeConverter = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 184 */     return this._typeConverter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMemberAccess(MemberAccess value) {
/* 189 */     if (value == null) throw new IllegalArgumentException("cannot set MemberAccess to null"); 
/* 190 */     this._memberAccess = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public MemberAccess getMemberAccess() {
/* 195 */     return this._memberAccess;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRoot(Object value) {
/* 200 */     this._root = value;
/* 201 */     this._accessorStack.clear();
/* 202 */     this._typeStack.clear();
/* 203 */     this._currentObject = value;
/*     */     
/* 205 */     if (this._currentObject != null)
/*     */     {
/* 207 */       setCurrentType(this._currentObject.getClass());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getRoot() {
/* 213 */     return this._root;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getTraceEvaluations() {
/* 218 */     return this._traceEvaluations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTraceEvaluations(boolean value) {
/* 223 */     this._traceEvaluations = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Evaluation getLastEvaluation() {
/* 228 */     return this._lastEvaluation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLastEvaluation(Evaluation value) {
/* 233 */     this._lastEvaluation = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recycleLastEvaluation() {
/* 244 */     OgnlRuntime.getEvaluationPool().recycleAll(this._lastEvaluation);
/* 245 */     this._lastEvaluation = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getKeepLastEvaluation() {
/* 256 */     return this._keepLastEvaluation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepLastEvaluation(boolean value) {
/* 267 */     this._keepLastEvaluation = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentObject(Object value) {
/* 272 */     this._currentObject = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCurrentObject() {
/* 277 */     return this._currentObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentAccessor(Class<?> type) {
/* 282 */     this._accessorStack.add(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getCurrentAccessor() {
/* 287 */     if (this._accessorStack.isEmpty()) {
/* 288 */       return null;
/*     */     }
/* 290 */     return this._accessorStack.get(this._accessorStack.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getPreviousAccessor() {
/* 295 */     if (this._accessorStack.isEmpty()) {
/* 296 */       return null;
/*     */     }
/* 298 */     if (this._accessorStack.size() > 1) {
/* 299 */       return this._accessorStack.get(this._accessorStack.size() - 2);
/*     */     }
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getFirstAccessor() {
/* 306 */     if (this._accessorStack.isEmpty()) {
/* 307 */       return null;
/*     */     }
/* 309 */     return this._accessorStack.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getCurrentType() {
/* 319 */     if (this._typeStack.isEmpty()) {
/* 320 */       return null;
/*     */     }
/* 322 */     return this._typeStack.get(this._typeStack.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentType(Class<?> type) {
/* 327 */     this._typeStack.add(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getPreviousType() {
/* 338 */     if (this._typeStack.isEmpty()) {
/* 339 */       return null;
/*     */     }
/* 341 */     if (this._typeStack.size() > 1) {
/* 342 */       return this._typeStack.get(this._typeStack.size() - 2);
/*     */     }
/* 344 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPreviousType(Class<?> type) {
/* 349 */     if (this._typeStack.isEmpty() || this._typeStack.size() < 2) {
/*     */       return;
/*     */     }
/* 352 */     this._typeStack.set(this._typeStack.size() - 2, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getFirstType() {
/* 357 */     if (this._typeStack.isEmpty()) {
/* 358 */       return null;
/*     */     }
/* 360 */     return this._typeStack.get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentNode(Node value) {
/* 365 */     this._currentNode = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getCurrentNode() {
/* 370 */     return this._currentNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getCurrentEvaluation() {
/* 381 */     return this._currentEvaluation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentEvaluation(Evaluation value) {
/* 386 */     this._currentEvaluation = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getRootEvaluation() {
/* 397 */     return this._rootEvaluation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRootEvaluation(Evaluation value) {
/* 402 */     this._rootEvaluation = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getEvaluation(int relativeIndex) {
/* 415 */     Evaluation result = null;
/*     */     
/* 417 */     if (relativeIndex <= 0) {
/* 418 */       result = this._currentEvaluation;
/* 419 */       while (++relativeIndex < 0 && result != null) {
/* 420 */         result = result.getParent();
/*     */       }
/*     */     } 
/* 423 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushEvaluation(Evaluation value) {
/* 434 */     if (this._currentEvaluation != null) {
/* 435 */       this._currentEvaluation.addChild(value);
/*     */     } else {
/* 437 */       setRootEvaluation(value);
/*     */     } 
/* 439 */     setCurrentEvaluation(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation popEvaluation() {
/* 452 */     Evaluation result = this._currentEvaluation;
/* 453 */     setCurrentEvaluation(result.getParent());
/* 454 */     if (this._currentEvaluation == null) {
/* 455 */       setLastEvaluation(getKeepLastEvaluation() ? result : null);
/* 456 */       setRootEvaluation(null);
/* 457 */       setCurrentNode(null);
/*     */     } 
/* 459 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int incrementLocalReferenceCounter() {
/* 464 */     return ++this._localReferenceCounter;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addLocalReference(String key, LocalReference reference) {
/* 469 */     if (this._localReferenceMap == null)
/*     */     {
/* 471 */       this._localReferenceMap = new LinkedHashMap<>();
/*     */     }
/*     */     
/* 474 */     this._localReferenceMap.put(key, reference);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map getLocalReferences() {
/* 479 */     return this._localReferenceMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 485 */     return this._values.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 490 */     return this._values.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 495 */     return this._values.containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 500 */     return this._values.containsValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*     */     Object result;
/* 507 */     if (RESERVED_KEYS.containsKey(key)) {
/* 508 */       if (key.equals("this")) {
/* 509 */         result = getCurrentObject();
/*     */       }
/* 511 */       else if (key.equals("root")) {
/* 512 */         result = getRoot();
/*     */       }
/* 514 */       else if (key.equals("_traceEvaluations")) {
/* 515 */         result = getTraceEvaluations() ? Boolean.TRUE : Boolean.FALSE;
/*     */       }
/* 517 */       else if (key.equals("_lastEvaluation")) {
/* 518 */         result = getLastEvaluation();
/*     */       }
/* 520 */       else if (key.equals("_keepLastEvaluation")) {
/* 521 */         result = getKeepLastEvaluation() ? Boolean.TRUE : Boolean.FALSE;
/*     */       }
/* 523 */       else if (key.equals("_typeConverter")) {
/* 524 */         result = getTypeConverter();
/*     */       } else {
/* 526 */         throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 534 */       result = this._values.get(key);
/*     */     } 
/* 536 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/*     */     Object result;
/* 543 */     if (RESERVED_KEYS.containsKey(key)) {
/* 544 */       if (key.equals("this")) {
/* 545 */         result = getCurrentObject();
/* 546 */         setCurrentObject(value);
/*     */       }
/* 548 */       else if (key.equals("root")) {
/* 549 */         result = getRoot();
/* 550 */         setRoot(value);
/*     */       }
/* 552 */       else if (key.equals("_traceEvaluations")) {
/* 553 */         result = getTraceEvaluations() ? Boolean.TRUE : Boolean.FALSE;
/* 554 */         setTraceEvaluations(OgnlOps.booleanValue(value));
/*     */       }
/* 556 */       else if (key.equals("_lastEvaluation")) {
/* 557 */         result = getLastEvaluation();
/* 558 */         this._lastEvaluation = (Evaluation)value;
/*     */       }
/* 560 */       else if (key.equals("_keepLastEvaluation")) {
/* 561 */         result = getKeepLastEvaluation() ? Boolean.TRUE : Boolean.FALSE;
/* 562 */         setKeepLastEvaluation(OgnlOps.booleanValue(value));
/*     */       }
/* 564 */       else if (key.equals("_typeConverter")) {
/* 565 */         result = getTypeConverter();
/* 566 */         setTypeConverter((TypeConverter)value);
/*     */       } else {
/* 568 */         throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 576 */       result = this._values.put(key, value);
/*     */     } 
/*     */     
/* 579 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/*     */     Object result;
/* 586 */     if (RESERVED_KEYS.containsKey(key)) {
/* 587 */       if (key.equals("this")) {
/* 588 */         result = getCurrentObject();
/* 589 */         setCurrentObject(null);
/*     */       }
/* 591 */       else if (key.equals("root")) {
/* 592 */         result = getRoot();
/* 593 */         setRoot(null);
/*     */       } else {
/* 595 */         if (key.equals("_traceEvaluations")) {
/* 596 */           throw new IllegalArgumentException("can't remove _traceEvaluations from context");
/*     */         }
/*     */         
/* 599 */         if (key.equals("_lastEvaluation")) {
/* 600 */           result = this._lastEvaluation;
/* 601 */           setLastEvaluation(null);
/*     */         } else {
/* 603 */           if (key.equals("_keepLastEvaluation")) {
/* 604 */             throw new IllegalArgumentException("can't remove _keepLastEvaluation from context");
/*     */           }
/*     */           
/* 607 */           if (key.equals("_typeConverter")) {
/* 608 */             result = getTypeConverter();
/* 609 */             setTypeConverter(null);
/*     */           } else {
/* 611 */             throw new IllegalArgumentException("unknown reserved key '" + key + "'");
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 619 */       result = this._values.remove(key);
/*     */     } 
/* 621 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map t) {
/* 626 */     for (Iterator it = t.keySet().iterator(); it.hasNext(); ) {
/* 627 */       Object k = it.next();
/*     */       
/* 629 */       put(k, t.get(k));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 635 */     this._values.clear();
/* 636 */     this._typeStack.clear();
/* 637 */     this._accessorStack.clear();
/*     */     
/* 639 */     this._localReferenceCounter = 0;
/* 640 */     if (this._localReferenceMap != null)
/*     */     {
/* 642 */       this._localReferenceMap.clear();
/*     */     }
/*     */     
/* 645 */     setRoot(null);
/* 646 */     setCurrentObject(null);
/* 647 */     setRootEvaluation(null);
/* 648 */     setCurrentEvaluation(null);
/* 649 */     setLastEvaluation(null);
/* 650 */     setCurrentNode(null);
/* 651 */     setClassResolver(DEFAULT_CLASS_RESOLVER);
/* 652 */     setTypeConverter(DEFAULT_TYPE_CONVERTER);
/* 653 */     setMemberAccess(DEFAULT_MEMBER_ACCESS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set keySet() {
/* 659 */     return this._values.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 665 */     return this._values.values();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/* 671 */     return this._values.entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 676 */     return this._values.equals(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 681 */     return this._values.hashCode();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\OgnlContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */