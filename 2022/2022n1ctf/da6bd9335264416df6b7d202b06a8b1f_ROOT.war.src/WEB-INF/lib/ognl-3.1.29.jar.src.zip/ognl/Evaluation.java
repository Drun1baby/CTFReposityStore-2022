/*     */ package ognl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Evaluation
/*     */ {
/*     */   private SimpleNode node;
/*     */   private Object source;
/*     */   private boolean setOperation;
/*     */   private Object result;
/*     */   private Throwable exception;
/*     */   private Evaluation parent;
/*     */   private Evaluation next;
/*     */   private Evaluation previous;
/*     */   private Evaluation firstChild;
/*     */   private Evaluation lastChild;
/*     */   
/*     */   public Evaluation(SimpleNode node, Object source) {
/*  61 */     this.node = node;
/*  62 */     this.source = source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation(SimpleNode node, Object source, boolean setOperation) {
/*  76 */     this(node, source);
/*  77 */     this.setOperation = setOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleNode getNode() {
/*  87 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(SimpleNode value) {
/* 100 */     this.node = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSource() {
/* 110 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSource(Object value) {
/* 123 */     this.source = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetOperation() {
/* 133 */     return this.setOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSetOperation(boolean value) {
/* 144 */     this.setOperation = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getResult() {
/* 154 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResult(Object value) {
/* 165 */     this.result = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/* 176 */     return this.exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setException(Throwable value) {
/* 188 */     this.exception = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getParent() {
/* 199 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getNext() {
/* 210 */     return this.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getPrevious() {
/* 221 */     return this.previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getFirstChild() {
/* 232 */     return this.firstChild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getLastChild() {
/* 243 */     return this.lastChild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getFirstDescendant() {
/* 254 */     if (this.firstChild != null) {
/* 255 */       return this.firstChild.getFirstDescendant();
/*     */     }
/* 257 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Evaluation getLastDescendant() {
/* 268 */     if (this.lastChild != null) {
/* 269 */       return this.lastChild.getLastDescendant();
/*     */     }
/* 271 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(Evaluation child) {
/* 285 */     if (this.firstChild == null) {
/* 286 */       this.firstChild = this.lastChild = child;
/*     */     }
/* 288 */     else if (this.firstChild == this.lastChild) {
/* 289 */       this.firstChild.next = child;
/* 290 */       this.lastChild = child;
/* 291 */       this.lastChild.previous = this.firstChild;
/*     */     } else {
/* 293 */       child.previous = this.lastChild;
/* 294 */       this.lastChild.next = child;
/* 295 */       this.lastChild = child;
/*     */     } 
/*     */     
/* 298 */     child.parent = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(SimpleNode node, Object source, boolean setOperation) {
/* 310 */     this.node = node;
/* 311 */     this.source = source;
/* 312 */     this.setOperation = setOperation;
/* 313 */     this.result = null;
/* 314 */     this.exception = null;
/* 315 */     this.parent = null;
/* 316 */     this.next = null;
/* 317 */     this.previous = null;
/* 318 */     this.firstChild = null;
/* 319 */     this.lastChild = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 327 */     init(null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean compact, boolean showChildren, String depth) {
/*     */     String stringResult;
/* 347 */     if (compact) {
/* 348 */       stringResult = depth + "<" + this.node.getClass().getName() + " " + System.identityHashCode(this) + ">";
/*     */     } else {
/* 350 */       String ss = (this.source != null) ? this.source.getClass().getName() : "null";
/* 351 */       String rs = (this.result != null) ? this.result.getClass().getName() : "null";
/*     */       
/* 353 */       stringResult = depth + "<" + this.node.getClass().getName() + ": [" + (this.setOperation ? "set" : "get") + "] source = " + ss + ", result = " + this.result + " [" + rs + "]>";
/*     */     } 
/* 355 */     if (showChildren) {
/* 356 */       Evaluation child = this.firstChild;
/*     */       
/* 358 */       stringResult = stringResult + "\n";
/* 359 */       while (child != null) {
/* 360 */         stringResult = stringResult + child.toString(compact, depth + "  ");
/* 361 */         child = child.next;
/*     */       } 
/*     */     } 
/* 364 */     return stringResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(boolean compact, String depth) {
/* 380 */     return toString(compact, true, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 390 */     return toString(false, "");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\Evaluation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */