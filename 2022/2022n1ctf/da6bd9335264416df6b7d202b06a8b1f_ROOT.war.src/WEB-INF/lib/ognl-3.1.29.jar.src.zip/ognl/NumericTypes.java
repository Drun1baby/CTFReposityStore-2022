package ognl;

public interface NumericTypes {
  public static final int BOOL = 0;
  
  public static final int BYTE = 1;
  
  public static final int CHAR = 2;
  
  public static final int SHORT = 3;
  
  public static final int INT = 4;
  
  public static final int LONG = 5;
  
  public static final int BIGINT = 6;
  
  public static final int FLOAT = 7;
  
  public static final int DOUBLE = 8;
  
  public static final int BIGDEC = 9;
  
  public static final int NONNUMERIC = 10;
  
  public static final int MIN_REAL_TYPE = 7;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\NumericTypes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */