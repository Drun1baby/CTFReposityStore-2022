/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import ognl.enhance.ExpressionCompiler;
/*     */ import ognl.enhance.OrderedReturn;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTMethod
/*     */   extends SimpleNode
/*     */   implements OrderedReturn, NodeType
/*     */ {
/*     */   private String _methodName;
/*     */   private String _lastExpression;
/*     */   private String _coreExpression;
/*     */   private Class _getterClass;
/*     */   
/*     */   public ASTMethod(int id) {
/*  57 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTMethod(OgnlParser p, int id) {
/*  62 */     super(p, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethodName(String methodName) {
/*  72 */     this._methodName = methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName() {
/*  82 */     return this._methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  88 */     Object[] args = OgnlRuntime.getObjectArrayPool().create(jjtGetNumChildren());
/*     */     
/*     */     try {
/*  91 */       Object root = context.getRoot();
/*     */       
/*  93 */       for (int i = 0, icount = args.length; i < icount; i++) {
/*  94 */         args[i] = this._children[i].getValue(context, root);
/*     */       }
/*     */       
/*  97 */       Object result = OgnlRuntime.callMethod(context, source, this._methodName, args);
/*     */       
/*  99 */       if (result == null) {
/*     */         
/* 101 */         NullHandler nh = OgnlRuntime.getNullHandler(OgnlRuntime.getTargetClass(source));
/* 102 */         result = nh.nullMethodResult(context, source, this._methodName, args);
/*     */       } 
/*     */       
/* 105 */       return result;
/*     */     } finally {
/*     */       
/* 108 */       OgnlRuntime.getObjectArrayPool().recycle(args);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLastExpression() {
/* 114 */     return this._lastExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoreExpression() {
/* 119 */     return this._coreExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/* 124 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/* 129 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     String result = this._methodName;
/*     */     
/* 136 */     result = result + "(";
/* 137 */     if (this._children != null && this._children.length > 0)
/*     */     {
/* 139 */       for (int i = 0; i < this._children.length; i++) {
/* 140 */         if (i > 0) {
/* 141 */           result = result + ", ";
/*     */         }
/*     */         
/* 144 */         result = result + this._children[i];
/*     */       } 
/*     */     }
/*     */     
/* 148 */     result = result + ")";
/* 149 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 156 */     if (target == null) {
/* 157 */       throw new UnsupportedCompilationException("Target object is null.");
/*     */     }
/* 159 */     String post = "";
/* 160 */     String result = null;
/* 161 */     Method m = null;
/*     */     
/*     */     try {
/* 164 */       m = OgnlRuntime.getMethod(context, (context.getCurrentType() != null) ? context.getCurrentType() : target.getClass(), this._methodName, this._children, false);
/* 165 */       Class[] argumentClasses = getChildrenClasses(context, this._children);
/* 166 */       if (m == null) {
/* 167 */         m = OgnlRuntime.getReadMethod(target.getClass(), this._methodName, argumentClasses);
/*     */       }
/* 169 */       if (m == null) {
/* 170 */         m = OgnlRuntime.getWriteMethod(target.getClass(), this._methodName, argumentClasses);
/*     */         
/* 172 */         if (m != null) {
/*     */           
/* 174 */           context.setCurrentType(m.getReturnType());
/* 175 */           context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */           
/* 177 */           this._coreExpression = toSetSourceString(context, target);
/* 178 */           if (this._coreExpression == null || this._coreExpression.length() < 1) {
/* 179 */             throw new UnsupportedCompilationException("can't find suitable getter method");
/*     */           }
/* 181 */           this._coreExpression += ";";
/* 182 */           this._lastExpression = "null";
/*     */           
/* 184 */           return this._coreExpression;
/*     */         } 
/*     */         
/* 187 */         return "";
/*     */       } 
/*     */       
/* 190 */       this._getterClass = m.getReturnType();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       boolean varArgs = (OgnlRuntime.isJdk15() && m.isVarArgs());
/*     */       
/* 197 */       if (varArgs)
/*     */       {
/* 199 */         throw new UnsupportedCompilationException("Javassist does not currently support varargs method calls");
/*     */       }
/*     */       
/* 202 */       result = "." + m.getName() + "(";
/*     */       
/* 204 */       if (this._children != null && this._children.length > 0)
/*     */       {
/* 206 */         Class[] parms = m.getParameterTypes();
/* 207 */         String prevCast = (String)context.remove("_preCast");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 212 */         for (int i = 0; i < this._children.length; i++) {
/*     */           
/* 214 */           if (i > 0)
/*     */           {
/* 216 */             result = result + ", ";
/*     */           }
/*     */           
/* 219 */           Class prevType = context.getCurrentType();
/*     */           
/* 221 */           context.setCurrentObject(context.getRoot());
/* 222 */           context.setCurrentType((context.getRoot() != null) ? context.getRoot().getClass() : null);
/* 223 */           context.setCurrentAccessor(null);
/* 224 */           context.setPreviousType(null);
/*     */           
/* 226 */           Object value = this._children[i].getValue(context, context.getRoot());
/* 227 */           String parmString = this._children[i].toGetSourceString(context, context.getRoot());
/*     */           
/* 229 */           if (parmString == null || parmString.trim().length() < 1) {
/* 230 */             parmString = "null";
/*     */           }
/*     */           
/* 233 */           if (ASTConst.class.isInstance(this._children[i]))
/*     */           {
/* 235 */             context.setCurrentType(prevType);
/*     */           }
/*     */           
/* 238 */           parmString = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + parmString;
/*     */           
/* 240 */           String cast = "";
/* 241 */           if (ExpressionCompiler.shouldCast(this._children[i]))
/*     */           {
/* 243 */             cast = (String)context.remove("_preCast");
/*     */           }
/* 245 */           if (cast == null) {
/* 246 */             cast = "";
/*     */           }
/* 248 */           if (!ASTConst.class.isInstance(this._children[i])) {
/* 249 */             parmString = cast + parmString;
/*     */           }
/* 251 */           Class<?> valueClass = (value != null) ? value.getClass() : null;
/* 252 */           if (NodeType.class.isAssignableFrom(this._children[i].getClass())) {
/* 253 */             valueClass = ((NodeType)this._children[i]).getGetterClass();
/*     */           }
/* 255 */           if ((!varArgs || (varArgs && i + 1 < parms.length)) && valueClass != parms[i])
/*     */           {
/* 257 */             if (parms[i].isArray()) {
/*     */               
/* 259 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ExpressionCompiler.getCastString(parms[i]) + ")ognl.OgnlOps#toArray(" + parmString + ", " + parms[i].getComponentType().getName() + ".class, true)", parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 266 */             else if (parms[i].isPrimitive()) {
/*     */               
/* 268 */               Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(parms[i]);
/*     */               
/* 270 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "((" + wrapClass.getName() + ")ognl.OgnlOps#convertValue(" + parmString + "," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass), parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 278 */             else if (parms[i] != Object.class) {
/* 279 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + parms[i].getName() + ")ognl.OgnlOps#convertValue(" + parmString + "," + parms[i].getName() + ".class)", parms[i]);
/*     */ 
/*     */             
/*     */             }
/* 283 */             else if ((NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null && Number.class.isAssignableFrom(((NodeType)this._children[i]).getGetterClass())) || (valueClass != null && valueClass.isPrimitive())) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 288 */               parmString = " ($w) " + parmString;
/* 289 */             } else if (valueClass != null && valueClass.isPrimitive()) {
/*     */               
/* 291 */               parmString = "($w) " + parmString;
/*     */             } 
/*     */           }
/*     */           
/* 295 */           result = result + parmString;
/*     */         } 
/*     */         
/* 298 */         if (prevCast != null)
/*     */         {
/* 300 */           context.put("_preCast", prevCast);
/*     */         }
/*     */       }
/*     */     
/* 304 */     } catch (Throwable t) {
/*     */       
/* 306 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 311 */       Object contextObj = getValueBody(context, target);
/* 312 */       context.setCurrentObject(contextObj);
/* 313 */     } catch (Throwable t) {
/*     */       
/* 315 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */     
/* 318 */     result = result + ")" + post;
/*     */     
/* 320 */     if (m.getReturnType() == void.class) {
/* 321 */       this._coreExpression = result + ";";
/* 322 */       this._lastExpression = "null";
/*     */     } 
/*     */     
/* 325 */     context.setCurrentType(m.getReturnType());
/* 326 */     context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */     
/* 328 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 335 */     Method m = OgnlRuntime.getWriteMethod((context.getCurrentType() != null) ? context.getCurrentType() : target.getClass(), this._methodName, getChildrenClasses(context, this._children));
/*     */ 
/*     */     
/* 338 */     if (m == null)
/*     */     {
/* 340 */       throw new UnsupportedCompilationException("Unable to determine setter method generation for " + this._methodName);
/*     */     }
/*     */     
/* 343 */     String post = "";
/* 344 */     String result = "." + m.getName() + "(";
/*     */     
/* 346 */     if (m.getReturnType() != void.class && m.getReturnType().isPrimitive() && (this._parent == null || !ASTTest.class.isInstance(this._parent))) {
/*     */ 
/*     */       
/* 349 */       Class wrapper = OgnlRuntime.getPrimitiveWrapperClass(m.getReturnType());
/*     */       
/* 351 */       ExpressionCompiler.addCastString(context, "new " + wrapper.getName() + "(");
/* 352 */       post = ")";
/* 353 */       this._getterClass = wrapper;
/*     */     } 
/*     */     
/* 356 */     boolean varArgs = (OgnlRuntime.isJdk15() && m.isVarArgs());
/*     */     
/* 358 */     if (varArgs)
/*     */     {
/* 360 */       throw new UnsupportedCompilationException("Javassist does not currently support varargs method calls");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 367 */       if (this._children != null && this._children.length > 0)
/*     */       {
/* 369 */         Class[] parms = m.getParameterTypes();
/* 370 */         String prevCast = (String)context.remove("_preCast");
/*     */         
/* 372 */         for (int i = 0; i < this._children.length; i++) {
/*     */           
/* 374 */           if (i > 0)
/*     */           {
/* 376 */             result = result + ", ";
/*     */           }
/*     */           
/* 379 */           Class prevType = context.getCurrentType();
/*     */           
/* 381 */           context.setCurrentObject(context.getRoot());
/* 382 */           context.setCurrentType((context.getRoot() != null) ? context.getRoot().getClass() : null);
/* 383 */           context.setCurrentAccessor(null);
/* 384 */           context.setPreviousType(null);
/*     */           
/* 386 */           Object value = this._children[i].getValue(context, context.getRoot());
/* 387 */           String parmString = this._children[i].toSetSourceString(context, context.getRoot());
/*     */           
/* 389 */           if (context.getCurrentType() == void.class || context.getCurrentType() == void.class) {
/* 390 */             throw new UnsupportedCompilationException("Method argument can't be a void type.");
/*     */           }
/* 392 */           if (parmString == null || parmString.trim().length() < 1) {
/*     */             
/* 394 */             if (ASTProperty.class.isInstance(this._children[i]) || ASTMethod.class.isInstance(this._children[i]) || ASTStaticMethod.class.isInstance(this._children[i]) || ASTChain.class.isInstance(this._children[i]))
/*     */             {
/* 396 */               throw new UnsupportedCompilationException("ASTMethod setter child returned null from a sub property expression.");
/*     */             }
/* 398 */             parmString = "null";
/*     */           } 
/*     */ 
/*     */           
/* 402 */           if (ASTConst.class.isInstance(this._children[i]))
/*     */           {
/* 404 */             context.setCurrentType(prevType);
/*     */           }
/*     */           
/* 407 */           parmString = ExpressionCompiler.getRootExpression(this._children[i], context.getRoot(), context) + parmString;
/*     */           
/* 409 */           String cast = "";
/* 410 */           if (ExpressionCompiler.shouldCast(this._children[i]))
/*     */           {
/* 412 */             cast = (String)context.remove("_preCast");
/*     */           }
/*     */           
/* 415 */           if (cast == null) {
/* 416 */             cast = "";
/*     */           }
/* 418 */           parmString = cast + parmString;
/*     */           
/* 420 */           Class<?> valueClass = (value != null) ? value.getClass() : null;
/* 421 */           if (NodeType.class.isAssignableFrom(this._children[i].getClass())) {
/* 422 */             valueClass = ((NodeType)this._children[i]).getGetterClass();
/*     */           }
/* 424 */           if (valueClass != parms[i])
/*     */           {
/* 426 */             if (parms[i].isArray()) {
/*     */               
/* 428 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + ExpressionCompiler.getCastString(parms[i]) + ")ognl.OgnlOps#toArray(" + parmString + ", " + parms[i].getComponentType().getName() + ".class)", parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 436 */             else if (parms[i].isPrimitive()) {
/*     */               
/* 438 */               Class wrapClass = OgnlRuntime.getPrimitiveWrapperClass(parms[i]);
/*     */               
/* 440 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "((" + wrapClass.getName() + ")ognl.OgnlOps#convertValue(" + parmString + "," + wrapClass.getName() + ".class, true))." + OgnlRuntime.getNumericValueGetter(wrapClass), parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 448 */             else if (parms[i] != Object.class) {
/*     */               
/* 450 */               parmString = OgnlRuntime.getCompiler().createLocalReference(context, "(" + parms[i].getName() + ")ognl.OgnlOps#convertValue(" + parmString + "," + parms[i].getName() + ".class)", parms[i]);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 456 */             else if ((NodeType.class.isInstance(this._children[i]) && ((NodeType)this._children[i]).getGetterClass() != null && Number.class.isAssignableFrom(((NodeType)this._children[i]).getGetterClass())) || (valueClass != null && valueClass.isPrimitive())) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 461 */               parmString = " ($w) " + parmString;
/* 462 */             } else if (valueClass != null && valueClass.isPrimitive()) {
/*     */               
/* 464 */               parmString = "($w) " + parmString;
/*     */             } 
/*     */           }
/*     */           
/* 468 */           result = result + parmString;
/*     */         } 
/*     */         
/* 471 */         if (prevCast != null)
/*     */         {
/* 473 */           context.put("_preCast", prevCast);
/*     */         }
/*     */       }
/*     */     
/* 477 */     } catch (Throwable t) {
/*     */       
/* 479 */       throw OgnlOps.castToRuntime(t);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 484 */       Object contextObj = getValueBody(context, target);
/* 485 */       context.setCurrentObject(contextObj);
/* 486 */     } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     context.setCurrentType(m.getReturnType());
/* 492 */     context.setCurrentAccessor(OgnlRuntime.getCompiler().getSuperOrInterfaceClass(m, m.getDeclaringClass()));
/*     */     
/* 494 */     return result + ")" + post;
/*     */   }
/*     */   
/*     */   private static Class getClassMatchingAllChildren(OgnlContext context, Node[] _children) {
/* 498 */     Class[] cc = getChildrenClasses(context, _children);
/* 499 */     Class<? super Object> clazz = null;
/* 500 */     for (int j = 0; j < cc.length; j++) {
/* 501 */       Class<Object> ic = cc[j];
/* 502 */       if (ic == null) {
/* 503 */         clazz = Object.class;
/*     */         break;
/*     */       } 
/* 506 */       if (clazz == null) {
/* 507 */         clazz = ic;
/*     */       }
/* 509 */       else if (!clazz.isAssignableFrom(ic)) {
/* 510 */         if (ic.isAssignableFrom(clazz)) {
/* 511 */           clazz = ic;
/*     */         } else {
/*     */           Class<? super Object> pc;
/* 514 */           while ((pc = clazz.getSuperclass()) != null) {
/* 515 */             if (pc.isAssignableFrom(ic)) {
/* 516 */               clazz = pc;
/*     */               break;
/*     */             } 
/*     */           } 
/* 520 */           if (!clazz.isAssignableFrom(ic)) {
/*     */             
/* 522 */             clazz = Object.class;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 530 */     if (clazz == null)
/* 531 */       clazz = Object.class; 
/* 532 */     return clazz;
/*     */   }
/*     */   
/*     */   private static Class[] getChildrenClasses(OgnlContext context, Node[] _children) {
/* 536 */     if (_children == null)
/* 537 */       return null; 
/* 538 */     Class[] argumentClasses = new Class[_children.length];
/* 539 */     for (int i = 0; i < _children.length; i++) {
/* 540 */       Node child = _children[i];
/* 541 */       if (child instanceof ASTList) {
/*     */ 
/*     */         
/* 544 */         argumentClasses[i] = List.class;
/* 545 */       } else if (child instanceof NodeType) {
/* 546 */         argumentClasses[i] = ((NodeType)child).getGetterClass();
/* 547 */       } else if (child instanceof ASTCtor) {
/*     */         try {
/* 549 */           argumentClasses[i] = ((ASTCtor)child).getCreatedClass(context);
/* 550 */         } catch (ClassNotFoundException nfe) {
/* 551 */           throw OgnlOps.castToRuntime(nfe);
/*     */         } 
/* 553 */       } else if (child instanceof ASTTest) {
/* 554 */         argumentClasses[i] = getClassMatchingAllChildren(context, ((ASTTest)child)._children);
/*     */       } else {
/* 556 */         throw new UnsupportedOperationException("Don't know how to handle child: " + child);
/*     */       } 
/*     */     } 
/* 559 */     return argumentClasses;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSimpleMethod(OgnlContext context) {
/* 564 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */