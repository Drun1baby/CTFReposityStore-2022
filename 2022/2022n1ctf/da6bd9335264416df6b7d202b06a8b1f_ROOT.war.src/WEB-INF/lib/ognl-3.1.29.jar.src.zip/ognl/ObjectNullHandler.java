/*    */ package ognl;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectNullHandler
/*    */   implements NullHandler
/*    */ {
/*    */   public Object nullMethodResult(Map context, Object target, String methodName, Object[] args) {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object nullPropertyValue(Map context, Object target, Object property) {
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectNullHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */