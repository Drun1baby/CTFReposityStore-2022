/*     */ package ognl;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectIndexedPropertyDescriptor
/*     */   extends PropertyDescriptor
/*     */ {
/*     */   private Method indexedReadMethod;
/*     */   private Method indexedWriteMethod;
/*     */   private Class propertyType;
/*     */   
/*     */   public ObjectIndexedPropertyDescriptor(String propertyName, Class propertyType, Method indexedReadMethod, Method indexedWriteMethod) throws IntrospectionException {
/* 104 */     super(propertyName, null, null);
/* 105 */     this.propertyType = propertyType;
/* 106 */     this.indexedReadMethod = indexedReadMethod;
/* 107 */     this.indexedWriteMethod = indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getIndexedReadMethod() {
/* 112 */     return this.indexedReadMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getIndexedWriteMethod() {
/* 117 */     return this.indexedWriteMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getPropertyType() {
/* 122 */     return this.propertyType;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ObjectIndexedPropertyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */