/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMemberAccess
/*     */   implements MemberAccess
/*     */ {
/*  56 */   private static final AccessibleObjectHandler _accessibleObjectHandler = OgnlRuntime.usingJDK9PlusAccessHandler() ? AccessibleObjectHandlerJDK9Plus.createHandler() : AccessibleObjectHandlerPreJDK9.createHandler();
/*     */ 
/*     */   
/*     */   public boolean allowPrivateAccess = false;
/*     */ 
/*     */   
/*     */   public boolean allowProtectedAccess = false;
/*     */ 
/*     */   
/*     */   public boolean allowPackageProtectedAccess = false;
/*     */ 
/*     */   
/*     */   public DefaultMemberAccess(boolean allowAllAccess) {
/*  69 */     this(allowAllAccess, allowAllAccess, allowAllAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultMemberAccess(boolean allowPrivateAccess, boolean allowProtectedAccess, boolean allowPackageProtectedAccess) {
/*  75 */     this.allowPrivateAccess = allowPrivateAccess;
/*  76 */     this.allowProtectedAccess = allowProtectedAccess;
/*  77 */     this.allowPackageProtectedAccess = allowPackageProtectedAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAllowPrivateAccess() {
/*  85 */     return this.allowPrivateAccess;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowPrivateAccess(boolean value) {
/*  90 */     this.allowPrivateAccess = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowProtectedAccess() {
/*  95 */     return this.allowProtectedAccess;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowProtectedAccess(boolean value) {
/* 100 */     this.allowProtectedAccess = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowPackageProtectedAccess() {
/* 105 */     return this.allowPackageProtectedAccess;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowPackageProtectedAccess(boolean value) {
/* 110 */     this.allowPackageProtectedAccess = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setup(Map context, Object target, Member member, String propertyName) {
/* 118 */     Object result = null;
/*     */     
/* 120 */     if (isAccessible(context, target, member, propertyName)) {
/* 121 */       AccessibleObject accessible = (AccessibleObject)member;
/*     */       
/* 123 */       if (!accessible.isAccessible()) {
/* 124 */         result = Boolean.FALSE;
/* 125 */         _accessibleObjectHandler.setAccessible(accessible, true);
/*     */       } 
/*     */     } 
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void restore(Map context, Object target, Member member, String propertyName, Object state) {
/* 133 */     if (state != null) {
/* 134 */       AccessibleObject accessible = (AccessibleObject)member;
/* 135 */       boolean stateboolean = ((Boolean)state).booleanValue();
/* 136 */       if (!stateboolean) {
/* 137 */         _accessibleObjectHandler.setAccessible(accessible, stateboolean);
/*     */       } else {
/* 139 */         throw new IllegalArgumentException("Improper restore state [" + stateboolean + "] for target [" + target + "], member [" + member + "], propertyName [" + propertyName + "]");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessible(Map context, Object target, Member member, String propertyName) {
/* 157 */     int modifiers = member.getModifiers();
/* 158 */     boolean result = Modifier.isPublic(modifiers);
/*     */     
/* 160 */     if (!result) {
/* 161 */       if (Modifier.isPrivate(modifiers)) {
/* 162 */         result = getAllowPrivateAccess();
/*     */       }
/* 164 */       else if (Modifier.isProtected(modifiers)) {
/* 165 */         result = getAllowProtectedAccess();
/*     */       } else {
/* 167 */         result = getAllowPackageProtectedAccess();
/*     */       } 
/*     */     }
/*     */     
/* 171 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\DefaultMemberAccess.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */