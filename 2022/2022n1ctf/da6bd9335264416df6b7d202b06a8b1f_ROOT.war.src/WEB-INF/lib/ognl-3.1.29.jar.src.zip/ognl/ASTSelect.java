/*    */ package ognl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.List;
/*    */ import ognl.enhance.UnsupportedCompilationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTSelect
/*    */   extends SimpleNode
/*    */ {
/*    */   public ASTSelect(int id) {
/* 48 */     super(id);
/*    */   }
/*    */ 
/*    */   
/*    */   public ASTSelect(OgnlParser p, int id) {
/* 53 */     super(p, id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 59 */     Node expr = this._children[0];
/* 60 */     List<Object> answer = new ArrayList();
/*    */     
/* 62 */     ElementsAccessor elementsAccessor = OgnlRuntime.getElementsAccessor(OgnlRuntime.getTargetClass(source));
/*    */     
/* 64 */     for (Enumeration e = elementsAccessor.getElements(source); e.hasMoreElements(); ) {
/* 65 */       Object next = e.nextElement();
/*    */       
/* 67 */       if (OgnlOps.booleanValue(expr.getValue(context, next))) {
/* 68 */         answer.add(next);
/*    */       }
/*    */     } 
/* 71 */     return answer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "{? " + this._children[0] + " }";
/*    */   }
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/* 81 */     throw new UnsupportedCompilationException("Eval expressions not supported as native java yet.");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toSetSourceString(OgnlContext context, Object target) {
/* 86 */     throw new UnsupportedCompilationException("Eval expressions not supported as native java yet.");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTSelect.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */