/*     */ package ognl;
/*     */ 
/*     */ import ognl.enhance.OrderedReturn;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTVarRef
/*     */   extends SimpleNode
/*     */   implements NodeType, OrderedReturn
/*     */ {
/*     */   private String _name;
/*     */   protected Class _getterClass;
/*     */   protected String _core;
/*     */   protected String _last;
/*     */   
/*     */   public ASTVarRef(int id) {
/*  52 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTVarRef(OgnlParser p, int id) {
/*  57 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   void setName(String name) {
/*  62 */     this._name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*  68 */     return context.get(this._name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValueBody(OgnlContext context, Object target, Object value) throws OgnlException {
/*  74 */     context.put(this._name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getGetterClass() {
/*  79 */     return this._getterClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getSetterClass() {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoreExpression() {
/*  89 */     return this._core;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLastExpression() {
/*  94 */     return this._last;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     return "#" + this._name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 104 */     Object value = context.get(this._name);
/*     */     
/* 106 */     if (value != null)
/*     */     {
/* 108 */       this._getterClass = value.getClass();
/*     */     }
/*     */     
/* 111 */     context.setCurrentType(this._getterClass);
/* 112 */     context.setCurrentAccessor(context.getClass());
/*     */     
/* 114 */     context.setCurrentObject(value);
/*     */ 
/*     */     
/* 117 */     if (context.getCurrentObject() == null) {
/* 118 */       throw new UnsupportedCompilationException("Current context object is null, can't compile var reference.");
/*     */     }
/* 120 */     String pre = "";
/* 121 */     String post = "";
/* 122 */     if (context.getCurrentType() != null) {
/* 123 */       pre = "((" + OgnlRuntime.getCompiler().getInterfaceClass(context.getCurrentType()).getName() + ")";
/* 124 */       post = ")";
/*     */     } 
/*     */     
/* 127 */     if (this._parent != null && ASTAssign.class.isInstance(this._parent)) {
/* 128 */       this._core = "$1.put(\"" + this._name + "\",";
/* 129 */       this._last = pre + "$1.get(\"" + this._name + "\")" + post;
/*     */       
/* 131 */       return this._core;
/*     */     } 
/*     */     
/* 134 */     return pre + "$1.get(\"" + this._name + "\")" + post;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 139 */     return toGetSourceString(context, target);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTVarRef.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */