/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AccessibleObjectHandlerJDK9Plus
/*     */   implements AccessibleObjectHandler
/*     */ {
/*  47 */   private static final Class _clazzUnsafe = instantiateClazzUnsafe();
/*  48 */   private static final Object _unsafeInstance = instantiateUnsafeInstance(_clazzUnsafe);
/*  49 */   private static final Method _unsafeObjectFieldOffsetMethod = instantiateUnsafeObjectFieldOffsetMethod(_clazzUnsafe);
/*  50 */   private static final Method _unsafePutBooleanMethod = instantiateUnsafePutBooleanMethod(_clazzUnsafe);
/*  51 */   private static final Field _accessibleObjectOverrideField = instantiateAccessibleObjectOverrideField();
/*  52 */   private static final long _accessibleObjectOverrideFieldOffset = determineAccessibleObjectOverrideFieldOffset();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean unsafeOrDescendant(Class<?> clazz) {
/*  67 */     return (_clazzUnsafe != null) ? _clazzUnsafe.isAssignableFrom(clazz) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class instantiateClazzUnsafe() {
/*     */     Class clazz;
/*     */     try {
/*  79 */       clazz = Class.forName("sun.misc.Unsafe");
/*  80 */     } catch (Throwable t) {
/*  81 */       clazz = null;
/*     */     } 
/*     */     
/*  84 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object instantiateUnsafeInstance(Class clazz) {
/*     */     Object unsafe;
/*  96 */     if (clazz != null) {
/*  97 */       Field field = null;
/*     */       try {
/*  99 */         field = clazz.getDeclaredField("theUnsafe");
/* 100 */         field.setAccessible(true);
/* 101 */         unsafe = field.get(null);
/* 102 */       } catch (Throwable t) {
/* 103 */         unsafe = null;
/*     */       } finally {
/* 105 */         if (field != null) {
/*     */           try {
/* 107 */             field.setAccessible(false);
/* 108 */           } catch (Throwable throwable) {}
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 114 */       unsafe = null;
/*     */     } 
/*     */     
/* 117 */     return unsafe;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method instantiateUnsafeObjectFieldOffsetMethod(Class clazz) {
/*     */     Method method;
/* 129 */     if (clazz != null) {
/*     */       try {
/* 131 */         method = clazz.getMethod("objectFieldOffset", new Class[] { Field.class });
/* 132 */       } catch (Throwable t) {
/* 133 */         method = null;
/*     */       } 
/*     */     } else {
/* 136 */       method = null;
/*     */     } 
/*     */     
/* 139 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method instantiateUnsafePutBooleanMethod(Class clazz) {
/*     */     Method method;
/* 151 */     if (clazz != null) {
/*     */       try {
/* 153 */         method = clazz.getMethod("putBoolean", new Class[] { Object.class, long.class, boolean.class });
/* 154 */       } catch (Throwable t) {
/* 155 */         method = null;
/*     */       } 
/*     */     } else {
/* 158 */       method = null;
/*     */     } 
/*     */     
/* 161 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Field instantiateAccessibleObjectOverrideField() {
/*     */     Field field;
/*     */     try {
/* 173 */       field = AccessibleObject.class.getDeclaredField("override");
/* 174 */     } catch (Throwable t) {
/* 175 */       field = null;
/*     */     } 
/*     */     
/* 178 */     return field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long determineAccessibleObjectOverrideFieldOffset() {
/* 187 */     long offset = -1L;
/*     */     
/* 189 */     if (_accessibleObjectOverrideField != null && _unsafeObjectFieldOffsetMethod != null && _unsafeInstance != null) {
/*     */       try {
/* 191 */         offset = ((Long)_unsafeObjectFieldOffsetMethod.invoke(_unsafeInstance, new Object[] { _accessibleObjectOverrideField })).longValue();
/* 192 */       } catch (Throwable throwable) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 197 */     return offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AccessibleObjectHandler createHandler() {
/* 214 */     if (OgnlRuntime.usingJDK9PlusAccessHandler()) {
/* 215 */       return new AccessibleObjectHandlerJDK9Plus();
/*     */     }
/* 217 */     return AccessibleObjectHandlerPreJDK9.createHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessible(AccessibleObject accessibleObject, boolean flag) {
/* 229 */     boolean operationComplete = false;
/*     */     
/* 231 */     if (_unsafeInstance != null && _unsafePutBooleanMethod != null && _accessibleObjectOverrideFieldOffset != -1L) {
/*     */       try {
/* 233 */         _unsafePutBooleanMethod.invoke(_unsafeInstance, new Object[] { accessibleObject, Long.valueOf(_accessibleObjectOverrideFieldOffset), Boolean.valueOf(flag) });
/* 234 */         operationComplete = true;
/* 235 */       } catch (Throwable throwable) {}
/*     */     }
/*     */ 
/*     */     
/* 239 */     if (!operationComplete)
/*     */     {
/* 241 */       accessibleObject.setAccessible(flag);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\AccessibleObjectHandlerJDK9Plus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */