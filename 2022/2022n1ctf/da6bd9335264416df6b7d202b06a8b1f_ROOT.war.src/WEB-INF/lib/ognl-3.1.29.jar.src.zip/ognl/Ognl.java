/*     */ package ognl;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import java.util.Map;
/*     */ import ognl.enhance.ExpressionAccessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Ognl
/*     */ {
/*  94 */   private static volatile Integer expressionMaxLength = null;
/*  95 */   private static volatile Boolean expressionMaxLengthFrozen = Boolean.FALSE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void applyExpressionMaxLength(Integer expressionMaxLength) {
/* 111 */     if (System.getSecurityManager() instanceof ognl.security.OgnlSecurityManager) {
/* 112 */       throw new SecurityException("the OGNL expressions maximum allowed length is not accessible inside expression itself!");
/*     */     }
/* 114 */     if (expressionMaxLengthFrozen.booleanValue()) {
/* 115 */       throw new IllegalStateException("The OGNL expression maximum allowed length has been frozen and cannot be changed.");
/*     */     }
/* 117 */     if (expressionMaxLength != null && expressionMaxLength.intValue() < 0) {
/* 118 */       throw new IllegalArgumentException("The provided OGNL expression maximum allowed length, " + expressionMaxLength + ", is illegal.");
/*     */     }
/*     */     
/* 121 */     Ognl.expressionMaxLength = expressionMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void freezeExpressionMaxLength() {
/* 134 */     if (System.getSecurityManager() instanceof ognl.security.OgnlSecurityManager) {
/* 135 */       throw new SecurityException("Freezing the OGNL expressions maximum allowed length is not accessible inside expression itself!");
/*     */     }
/* 137 */     expressionMaxLengthFrozen = Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized void thawExpressionMaxLength() {
/* 149 */     if (System.getSecurityManager() instanceof ognl.security.OgnlSecurityManager) {
/* 150 */       throw new SecurityException("Thawing the OGNL expressions maximum allowed length is not accessible inside expression itself!");
/*     */     }
/* 152 */     expressionMaxLengthFrozen = Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parseExpression(String expression) throws OgnlException {
/* 170 */     Integer currentExpressionMaxLength = expressionMaxLength;
/* 171 */     if (currentExpressionMaxLength != null && expression != null && expression.length() > currentExpressionMaxLength.intValue()) {
/* 172 */       throw new OgnlException("Parsing blocked due to security reasons!", new SecurityException("This expression exceeded maximum allowed length: " + expression));
/*     */     }
/*     */     
/*     */     try {
/* 176 */       OgnlParser parser = new OgnlParser(new StringReader(expression));
/* 177 */       return parser.topLevelExpression();
/* 178 */     } catch (ParseException e) {
/* 179 */       throw new ExpressionSyntaxException(expression, e);
/* 180 */     } catch (TokenMgrError e) {
/* 181 */       throw new ExpressionSyntaxException(expression, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Node compileExpression(OgnlContext context, Object root, String expression) throws Exception {
/* 206 */     Node expr = (Node)parseExpression(expression);
/*     */     
/* 208 */     OgnlRuntime.compileExpression(context, expr, root);
/*     */     
/* 210 */     return expr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map createDefaultContext(Object root) {
/* 223 */     return addDefaultContext(root, null, null, null, new OgnlContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver) {
/* 239 */     return addDefaultContext(root, classResolver, null, null, new OgnlContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter) {
/* 257 */     return addDefaultContext(root, classResolver, converter, null, new OgnlContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map createDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, MemberAccess memberAccess) {
/* 278 */     return addDefaultContext(root, classResolver, converter, memberAccess, new OgnlContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map addDefaultContext(Object root, Map context) {
/* 294 */     return addDefaultContext(root, null, null, null, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, Map context) {
/* 313 */     return addDefaultContext(root, classResolver, null, null, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, Map context) {
/* 335 */     return addDefaultContext(root, classResolver, converter, null, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map addDefaultContext(Object root, ClassResolver classResolver, TypeConverter converter, MemberAccess memberAccess, Map context) {
/*     */     OgnlContext result;
/* 361 */     if (!(context instanceof OgnlContext)) {
/* 362 */       result = new OgnlContext();
/* 363 */       result.setValues(context);
/*     */     } else {
/* 365 */       result = (OgnlContext)context;
/*     */     } 
/* 367 */     if (classResolver != null) {
/* 368 */       result.setClassResolver(classResolver);
/*     */     }
/* 370 */     if (converter != null) {
/* 371 */       result.setTypeConverter(converter);
/*     */     }
/* 373 */     if (memberAccess != null) {
/* 374 */       result.setMemberAccess(memberAccess);
/*     */     }
/*     */     
/* 377 */     result.setRoot(root);
/* 378 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setClassResolver(Map context, ClassResolver classResolver) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassResolver getClassResolver(Map context) {
/* 408 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTypeConverter(Map<String, TypeConverter> context, TypeConverter converter) {
/* 422 */     context.put("_typeConverter", converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeConverter getTypeConverter(Map context) {
/* 435 */     return (TypeConverter)context.get("_typeConverter");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setRoot(Map<String, Object> context, Object root) {
/* 449 */     context.put("root", root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getRoot(Map context) {
/* 462 */     return context.get("root");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Evaluation getLastEvaluation(Map context) {
/* 475 */     return (Evaluation)context.get("_lastEvaluation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(Object tree, Map context, Object root) throws OgnlException {
/* 501 */     return getValue(tree, context, root, (Class)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(Object tree, Map context, Object root, Class resultType) throws OgnlException {
/*     */     Object result;
/* 530 */     OgnlContext ognlContext = (OgnlContext)addDefaultContext(root, context);
/*     */     
/* 532 */     Node node = (Node)tree;
/*     */     
/* 534 */     if (node.getAccessor() != null) {
/* 535 */       result = node.getAccessor().get(ognlContext, root);
/*     */     } else {
/* 537 */       result = node.getValue(ognlContext, root);
/*     */     } 
/* 539 */     if (resultType != null) {
/* 540 */       result = getTypeConverter(context).convertValue(context, root, null, null, result, resultType);
/*     */     }
/* 542 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(ExpressionAccessor expression, OgnlContext context, Object root) {
/* 560 */     return expression.get(context, root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(ExpressionAccessor expression, OgnlContext context, Object root, Class resultType) {
/* 581 */     return getTypeConverter(context).convertValue(context, root, null, null, expression.get(context, root), resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(String expression, Map context, Object root) throws OgnlException {
/* 609 */     return getValue(expression, context, root, (Class)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(String expression, Map context, Object root, Class resultType) throws OgnlException {
/* 639 */     return getValue(parseExpression(expression), context, root, resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(Object tree, Object root) throws OgnlException {
/* 662 */     return getValue(tree, root, (Class)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(Object tree, Object root, Class resultType) throws OgnlException {
/* 687 */     return getValue(tree, createDefaultContext(root), root, resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(String expression, Object root) throws OgnlException {
/* 715 */     return getValue(expression, root, (Class)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(String expression, Object root, Class resultType) throws OgnlException {
/* 745 */     return getValue(parseExpression(expression), root, resultType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(Object tree, Map context, Object root, Object value) throws OgnlException {
/* 772 */     OgnlContext ognlContext = (OgnlContext)addDefaultContext(root, context);
/* 773 */     Node n = (Node)tree;
/*     */     
/* 775 */     if (n.getAccessor() != null) {
/* 776 */       n.getAccessor().set(ognlContext, root, value);
/*     */       
/*     */       return;
/*     */     } 
/* 780 */     n.setValue(ognlContext, root, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(ExpressionAccessor expression, OgnlContext context, Object root, Object value) {
/* 799 */     expression.set(context, root, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(String expression, Map context, Object root, Object value) throws OgnlException {
/* 826 */     setValue(parseExpression(expression), context, root, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(Object tree, Object root, Object value) throws OgnlException {
/* 851 */     setValue(tree, createDefaultContext(root), root, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setValue(String expression, Object root, Object value) throws OgnlException {
/* 880 */     setValue(parseExpression(expression), root, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstant(Object tree, Map context) throws OgnlException {
/* 898 */     return ((SimpleNode)tree).isConstant((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstant(String expression, Map context) throws OgnlException {
/* 915 */     return isConstant(parseExpression(expression), context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstant(Object tree) throws OgnlException {
/* 931 */     return isConstant(tree, createDefaultContext(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConstant(String expression) throws OgnlException {
/* 947 */     return isConstant(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleProperty(Object tree, Map context) throws OgnlException {
/* 953 */     return ((SimpleNode)tree).isSimpleProperty((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleProperty(String expression, Map context) throws OgnlException {
/* 959 */     return isSimpleProperty(parseExpression(expression), context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleProperty(Object tree) throws OgnlException {
/* 965 */     return isSimpleProperty(tree, createDefaultContext(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleProperty(String expression) throws OgnlException {
/* 971 */     return isSimpleProperty(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleNavigationChain(Object tree, Map context) throws OgnlException {
/* 977 */     return ((SimpleNode)tree).isSimpleNavigationChain((OgnlContext)addDefaultContext(null, context));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleNavigationChain(String expression, Map context) throws OgnlException {
/* 983 */     return isSimpleNavigationChain(parseExpression(expression), context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleNavigationChain(Object tree) throws OgnlException {
/* 989 */     return isSimpleNavigationChain(tree, createDefaultContext(null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSimpleNavigationChain(String expression) throws OgnlException {
/* 995 */     return isSimpleNavigationChain(parseExpression(expression), createDefaultContext(null));
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\Ognl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */