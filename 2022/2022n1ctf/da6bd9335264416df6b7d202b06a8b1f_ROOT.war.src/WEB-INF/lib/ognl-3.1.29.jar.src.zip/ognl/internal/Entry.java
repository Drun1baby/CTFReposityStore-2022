/*    */ package ognl.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Entry
/*    */ {
/*    */   Entry next;
/*    */   Class key;
/*    */   Object value;
/*    */   
/*    */   public Entry(Class key, Object value) {
/* 14 */     this.key = key;
/* 15 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 20 */     return "Entry[next=" + this.next + '\n' + ", key=" + this.key + '\n' + ", value=" + this.value + '\n' + ']';
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\internal\Entry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */