/*     */ package ognl.internal;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import ognl.ClassCacheInspector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassCacheImpl
/*     */   implements ClassCache
/*     */ {
/*     */   private static final int TABLE_SIZE = 512;
/*     */   private static final int TABLE_SIZE_MASK = 511;
/*     */   private Entry[] _table;
/*     */   private ClassCacheInspector _classInspector;
/*  19 */   private int _size = 0;
/*     */ 
/*     */   
/*     */   public ClassCacheImpl() {
/*  23 */     this._table = new Entry[512];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClassInspector(ClassCacheInspector inspector) {
/*  28 */     this._classInspector = inspector;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  33 */     for (int i = 0; i < this._table.length; i++)
/*     */     {
/*  35 */       this._table[i] = null;
/*     */     }
/*     */     
/*  38 */     this._size = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  43 */     return this._size;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object get(Class key) {
/*  48 */     Object result = null;
/*  49 */     int i = key.hashCode() & 0x1FF;
/*     */     
/*  51 */     for (Entry entry = this._table[i]; entry != null; entry = entry.next) {
/*     */       
/*  53 */       if (entry.key == key) {
/*     */         
/*  55 */         result = entry.value;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  60 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object put(Class key, Object value) {
/*  65 */     if (this._classInspector != null && !this._classInspector.shouldCache(key)) {
/*  66 */       return value;
/*     */     }
/*  68 */     Object result = null;
/*  69 */     int i = key.hashCode() & 0x1FF;
/*  70 */     Entry entry = this._table[i];
/*     */     
/*  72 */     if (entry == null) {
/*     */       
/*  74 */       this._table[i] = new Entry(key, value);
/*  75 */       this._size++;
/*     */     
/*     */     }
/*  78 */     else if (entry.key == key) {
/*     */       
/*  80 */       result = entry.value;
/*  81 */       entry.value = value;
/*     */     } else {
/*     */       
/*     */       while (true) {
/*     */         
/*  86 */         if (entry.key == key) {
/*     */ 
/*     */           
/*  89 */           result = entry.value;
/*  90 */           entry.value = value;
/*     */           
/*     */           break;
/*     */         } 
/*  94 */         if (entry.next == null) {
/*     */ 
/*     */           
/*  97 */           entry.next = new Entry(key, value);
/*     */           
/*     */           break;
/*     */         } 
/* 101 */         entry = entry.next;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return "ClassCacheImpl[_table=" + ((this._table == null) ? null : (String)Arrays.<Entry>asList(this._table)) + '\n' + ", _classInspector=" + this._classInspector + '\n' + ", _size=" + this._size + '\n' + ']';
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\internal\ClassCacheImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */