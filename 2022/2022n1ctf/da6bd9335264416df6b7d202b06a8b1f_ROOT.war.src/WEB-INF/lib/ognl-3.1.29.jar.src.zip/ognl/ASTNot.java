/*    */ package ognl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ASTNot
/*    */   extends BooleanExpression
/*    */ {
/*    */   public ASTNot(int id) {
/* 40 */     super(id);
/*    */   }
/*    */   
/*    */   public ASTNot(OgnlParser p, int id) {
/* 44 */     super(p, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/* 49 */     return OgnlOps.booleanValue(this._children[0].getValue(context, source)) ? Boolean.FALSE : Boolean.TRUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExpressionOperator(int index) {
/* 54 */     return "!";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toGetSourceString(OgnlContext context, Object target) {
/*    */     try {
/* 61 */       String srcString = super.toGetSourceString(context, target);
/*    */       
/* 63 */       if (srcString == null || srcString.trim().length() < 1) {
/* 64 */         srcString = "null";
/*    */       }
/* 66 */       context.setCurrentType(boolean.class);
/*    */       
/* 68 */       return "(! ognl.OgnlOps.booleanValue(" + srcString + ") )";
/*    */     }
/* 70 */     catch (Throwable t) {
/*    */       
/* 72 */       throw OgnlOps.castToRuntime(t);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTNot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */