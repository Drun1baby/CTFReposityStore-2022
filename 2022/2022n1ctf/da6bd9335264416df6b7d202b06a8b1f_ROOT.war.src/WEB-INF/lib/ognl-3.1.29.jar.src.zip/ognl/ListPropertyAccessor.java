/*     */ package ognl;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListPropertyAccessor
/*     */   extends ObjectPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*     */   public Object getProperty(Map context, Object target, Object name) throws OgnlException {
/*  49 */     List<?> list = (List)target;
/*     */     
/*  51 */     if (name instanceof String) {
/*  52 */       Object result = null;
/*     */       
/*  54 */       if (name.equals("size")) {
/*  55 */         result = new Integer(list.size());
/*     */       }
/*  57 */       else if (name.equals("iterator")) {
/*  58 */         result = list.iterator();
/*     */       }
/*  60 */       else if (name.equals("isEmpty") || name.equals("empty")) {
/*  61 */         result = list.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */       } else {
/*  63 */         result = super.getProperty(context, target, name);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  68 */       return result;
/*     */     } 
/*     */     
/*  71 */     if (name instanceof Number) {
/*  72 */       return list.get(((Number)name).intValue());
/*     */     }
/*  74 */     if (name instanceof DynamicSubscript) {
/*  75 */       int len = list.size();
/*  76 */       switch (((DynamicSubscript)name).getFlag()) {
/*     */         case 0:
/*  78 */           return (len > 0) ? list.get(0) : null;
/*     */         case 1:
/*  80 */           return (len > 0) ? list.get(len / 2) : null;
/*     */         case 2:
/*  82 */           return (len > 0) ? list.get(len - 1) : null;
/*     */         case 3:
/*  84 */           return new ArrayList(list);
/*     */       } 
/*     */     
/*     */     } 
/*  88 */     throw new NoSuchPropertyException(target, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(Map context, Object target, Object name, Object value) throws OgnlException {
/*  94 */     if (name instanceof String && ((String)name).indexOf("$") < 0) {
/*  95 */       super.setProperty(context, target, name, value);
/*     */       
/*     */       return;
/*     */     } 
/*  99 */     List<Object> list = (List)target;
/*     */     
/* 101 */     if (name instanceof Number) {
/* 102 */       list.set(((Number)name).intValue(), value);
/*     */       
/*     */       return;
/*     */     } 
/* 106 */     if (name instanceof DynamicSubscript) {
/* 107 */       int len = list.size();
/* 108 */       switch (((DynamicSubscript)name).getFlag()) {
/*     */         case 0:
/* 110 */           if (len > 0) list.set(0, value); 
/*     */           return;
/*     */         case 1:
/* 113 */           if (len > 0) list.set(len / 2, value); 
/*     */           return;
/*     */         case 2:
/* 116 */           if (len > 0) list.set(len - 1, value);
/*     */           
/*     */           return;
/*     */         case 3:
/* 120 */           if (!(value instanceof Collection)) throw new OgnlException("Value must be a collection"); 
/* 121 */           list.clear();
/* 122 */           list.addAll((Collection)value);
/*     */           return;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 128 */     throw new NoSuchPropertyException(target, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getPropertyClass(OgnlContext context, Object target, Object index) {
/* 133 */     if (index instanceof String) {
/* 134 */       String indexStr = (String)index;
/* 135 */       String key = (indexStr.indexOf('"') >= 0) ? indexStr.replaceAll("\"", "") : indexStr;
/* 136 */       if (key.equals("size")) {
/* 137 */         return int.class;
/*     */       }
/* 139 */       if (key.equals("iterator")) {
/* 140 */         return Iterator.class;
/*     */       }
/* 142 */       if (key.equals("isEmpty") || key.equals("empty")) {
/* 143 */         return boolean.class;
/*     */       }
/* 145 */       return super.getPropertyClass(context, target, index);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (index instanceof Number) {
/* 152 */       return Object.class;
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index) {
/* 159 */     String indexStr = index.toString();
/* 160 */     if (indexStr.indexOf('"') >= 0) {
/* 161 */       indexStr = indexStr.replaceAll("\"", "");
/*     */     }
/* 163 */     if (String.class.isInstance(index)) {
/*     */       
/* 165 */       if (indexStr.equals("size")) {
/*     */         
/* 167 */         context.setCurrentAccessor(List.class);
/* 168 */         context.setCurrentType(int.class);
/* 169 */         return ".size()";
/*     */       } 
/*     */       
/* 172 */       if (indexStr.equals("iterator")) {
/*     */         
/* 174 */         context.setCurrentAccessor(List.class);
/* 175 */         context.setCurrentType(Iterator.class);
/* 176 */         return ".iterator()";
/*     */       } 
/*     */       
/* 179 */       if (indexStr.equals("isEmpty") || indexStr.equals("empty")) {
/*     */         
/* 181 */         context.setCurrentAccessor(List.class);
/* 182 */         context.setCurrentType(boolean.class);
/* 183 */         return ".isEmpty()";
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     if (context.getCurrentObject() != null && !Number.class.isInstance(context.getCurrentObject())) {
/*     */       
/*     */       try {
/* 195 */         Method m = OgnlRuntime.getReadMethod(target.getClass(), indexStr);
/*     */         
/* 197 */         if (m != null) {
/* 198 */           return super.getSourceAccessor(context, target, index);
/*     */         }
/* 200 */       } catch (Throwable t) {
/*     */         
/* 202 */         throw OgnlOps.castToRuntime(t);
/*     */       } 
/*     */     }
/*     */     
/* 206 */     context.setCurrentAccessor(List.class);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (!context.getCurrentType().isPrimitive() && Number.class.isAssignableFrom(context.getCurrentType())) {
/*     */       
/* 213 */       indexStr = indexStr + "." + OgnlRuntime.getNumericValueGetter(context.getCurrentType());
/* 214 */     } else if (context.getCurrentObject() != null && Number.class.isAssignableFrom(context.getCurrentObject().getClass()) && !context.getCurrentType().isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       String toString = (String.class.isInstance(index) && context.getCurrentType() != Object.class) ? "" : ".toString()";
/*     */       
/* 221 */       indexStr = "ognl.OgnlOps#getIntValue(" + indexStr + toString + ")";
/*     */     } 
/*     */     
/* 224 */     context.setCurrentType(Object.class);
/*     */     
/* 226 */     return ".get(" + indexStr + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index) {
/* 231 */     String indexStr = index.toString();
/* 232 */     if (indexStr.indexOf('"') >= 0) {
/* 233 */       indexStr = indexStr.replaceAll("\"", "");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     if (context.getCurrentObject() != null && !Number.class.isInstance(context.getCurrentObject())) {
/*     */       
/*     */       try {
/* 243 */         Method m = OgnlRuntime.getWriteMethod(target.getClass(), indexStr);
/*     */         
/* 245 */         if (m != null || !context.getCurrentType().isPrimitive())
/*     */         {
/*     */           
/* 248 */           return super.getSourceSetter(context, target, index);
/*     */         }
/*     */       }
/* 251 */       catch (Throwable t) {
/*     */         
/* 253 */         throw OgnlOps.castToRuntime(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     context.setCurrentAccessor(List.class);
/*     */ 
/*     */ 
/*     */     
/* 267 */     if (!context.getCurrentType().isPrimitive() && Number.class.isAssignableFrom(context.getCurrentType())) {
/*     */       
/* 269 */       indexStr = indexStr + "." + OgnlRuntime.getNumericValueGetter(context.getCurrentType());
/* 270 */     } else if (context.getCurrentObject() != null && Number.class.isAssignableFrom(context.getCurrentObject().getClass()) && !context.getCurrentType().isPrimitive()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 275 */       String toString = (String.class.isInstance(index) && context.getCurrentType() != Object.class) ? "" : ".toString()";
/*     */       
/* 277 */       indexStr = "ognl.OgnlOps#getIntValue(" + indexStr + toString + ")";
/*     */     } 
/*     */     
/* 280 */     context.setCurrentType(Object.class);
/*     */     
/* 282 */     return ".set(" + indexStr + ", $3)";
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ListPropertyAccessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */