/*     */ package ognl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTMap
/*     */   extends SimpleNode
/*     */ {
/*     */   private static Class DEFAULT_MAP_CLASS;
/*     */   private String className;
/*     */   
/*     */   static {
/*     */     try {
/*  51 */       DEFAULT_MAP_CLASS = Class.forName("java.util.LinkedHashMap");
/*  52 */     } catch (ClassNotFoundException ex) {
/*  53 */       DEFAULT_MAP_CLASS = HashMap.class;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTMap(int id) {
/*  59 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public ASTMap(OgnlParser p, int id) {
/*  64 */     super(p, id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setClassName(String value) {
/*  69 */     this.className = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getValueBody(OgnlContext context, Object source) throws OgnlException {
/*     */     Map<Object, Object> answer;
/*  77 */     if (this.className == null) {
/*     */       try {
/*  79 */         answer = DEFAULT_MAP_CLASS.newInstance();
/*  80 */       } catch (Exception ex) {
/*     */         
/*  82 */         throw new OgnlException("Default Map class '" + DEFAULT_MAP_CLASS.getName() + "' instantiation error", ex);
/*     */       } 
/*     */     } else {
/*     */       
/*     */       try {
/*  87 */         answer = OgnlRuntime.classForName(context, this.className).newInstance();
/*  88 */       } catch (Exception ex) {
/*  89 */         throw new OgnlException("Map implementor '" + this.className + "' not found", ex);
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/*  94 */       ASTKeyValue kv = (ASTKeyValue)this._children[i];
/*  95 */       Node k = kv.getKey(), v = kv.getValue();
/*     */       
/*  97 */       answer.put(k.getValue(context, source), (v == null) ? null : v.getValue(context, source));
/*     */     } 
/*     */     
/* 100 */     return answer;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     String result = "#";
/*     */     
/* 107 */     if (this.className != null) {
/* 108 */       result = result + "@" + this.className + "@";
/*     */     }
/*     */     
/* 111 */     result = result + "{ ";
/* 112 */     for (int i = 0; i < jjtGetNumChildren(); i++) {
/* 113 */       ASTKeyValue kv = (ASTKeyValue)this._children[i];
/*     */       
/* 115 */       if (i > 0) {
/* 116 */         result = result + ", ";
/*     */       }
/* 118 */       result = result + kv.getKey() + " : " + kv.getValue();
/*     */     } 
/* 120 */     return result + " }";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toGetSourceString(OgnlContext context, Object target) {
/* 125 */     throw new UnsupportedCompilationException("Map expressions not supported as native java yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toSetSourceString(OgnlContext context, Object target) {
/* 130 */     throw new UnsupportedCompilationException("Map expressions not supported as native java yet.");
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\ognl-3.1.29.jar!\ognl\ASTMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */