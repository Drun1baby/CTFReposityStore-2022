package freemarker.ext.ant;

import java.io.File;
import java.util.Map;
import org.apache.tools.ant.BuildException;

interface UnlinkedJythonOperations {
  void execute(String paramString, Map paramMap) throws BuildException;
  
  void execute(File paramFile, Map paramMap) throws BuildException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\ant\UnlinkedJythonOperations.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */