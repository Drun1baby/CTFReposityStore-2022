package freemarker.ext.beans;

import java.beans.MethodDescriptor;
import java.util.List;

interface MethodSorter {
  void sortMethodDescriptors(List<MethodDescriptor> paramList);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\MethodSorter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */