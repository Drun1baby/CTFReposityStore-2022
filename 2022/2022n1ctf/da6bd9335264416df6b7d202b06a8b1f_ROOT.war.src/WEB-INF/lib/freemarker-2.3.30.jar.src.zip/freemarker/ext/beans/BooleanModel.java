/*    */ package freemarker.ext.beans;
/*    */ 
/*    */ import freemarker.template.TemplateBooleanModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanModel
/*    */   extends BeanModel
/*    */   implements TemplateBooleanModel
/*    */ {
/*    */   private final boolean value;
/*    */   
/*    */   public BooleanModel(Boolean bool, BeansWrapper wrapper) {
/* 32 */     super(bool, wrapper, false);
/* 33 */     this.value = bool.booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getAsBoolean() {
/* 38 */     return this.value;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\BooleanModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */