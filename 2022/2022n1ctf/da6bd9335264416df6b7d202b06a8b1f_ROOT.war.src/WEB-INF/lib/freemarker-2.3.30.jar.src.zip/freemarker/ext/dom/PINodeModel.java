/*    */ package freemarker.ext.dom;
/*    */ 
/*    */ import freemarker.template.TemplateScalarModel;
/*    */ import org.w3c.dom.ProcessingInstruction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PINodeModel
/*    */   extends NodeModel
/*    */   implements TemplateScalarModel
/*    */ {
/*    */   public PINodeModel(ProcessingInstruction pi) {
/* 29 */     super(pi);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAsString() {
/* 34 */     return ((ProcessingInstruction)this.node).getData();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNodeName() {
/* 39 */     return "@pi$" + ((ProcessingInstruction)this.node).getTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 44 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\dom\PINodeModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */