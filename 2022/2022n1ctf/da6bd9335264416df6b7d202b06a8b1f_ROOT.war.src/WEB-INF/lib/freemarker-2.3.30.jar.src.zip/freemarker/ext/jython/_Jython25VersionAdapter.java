/*    */ package freemarker.ext.jython;
/*    */ 
/*    */ import org.python.core.PyInstance;
/*    */ import org.python.core.PyObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _Jython25VersionAdapter
/*    */   extends JythonVersionAdapter
/*    */ {
/*    */   public boolean isPyInstance(Object obj) {
/* 35 */     return obj instanceof PyInstance;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object pyInstanceToJava(Object pyInstance) {
/* 40 */     return ((PyInstance)pyInstance).__tojava__(Object.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPythonClassName(PyObject pyObject) {
/* 45 */     return pyObject.getType().getName();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\jython\_Jython25VersionAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */