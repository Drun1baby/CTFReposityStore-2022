/*     */ package freemarker.ext.beans;
/*     */ 
/*     */ import freemarker.core.BugException;
/*     */ import freemarker.core._DelayedConversionToString;
/*     */ import freemarker.core._DelayedJQuote;
/*     */ import freemarker.core._TemplateModelException;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import freemarker.template.utility.ClassUtil;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class _MethodUtil
/*     */ {
/*     */   public static int isMoreOrSameSpecificParameterType(Class<?> specific, Class<?> generic, boolean bugfixed, int ifHigherThan) {
/*  72 */     if (ifHigherThan >= 4) return 0; 
/*  73 */     if (generic.isAssignableFrom(specific))
/*     */     {
/*  75 */       return (generic == specific) ? 1 : 4;
/*     */     }
/*  77 */     boolean specificIsPrim = specific.isPrimitive();
/*  78 */     boolean genericIsPrim = generic.isPrimitive();
/*  79 */     if (specificIsPrim) {
/*  80 */       if (genericIsPrim) {
/*  81 */         if (ifHigherThan >= 3) return 0; 
/*  82 */         return isWideningPrimitiveNumberConversion(specific, generic) ? 3 : 0;
/*     */       } 
/*  84 */       if (bugfixed) {
/*  85 */         Class<?> specificAsBoxed = ClassUtil.primitiveClassToBoxingClass(specific);
/*  86 */         if (specificAsBoxed == generic)
/*     */         {
/*  88 */           return 2; } 
/*  89 */         if (generic.isAssignableFrom(specificAsBoxed))
/*     */         {
/*  91 */           return 4; } 
/*  92 */         if (ifHigherThan >= 3)
/*  93 */           return 0; 
/*  94 */         if (Number.class.isAssignableFrom(specificAsBoxed) && Number.class
/*  95 */           .isAssignableFrom(generic)) {
/*  96 */           return isWideningBoxedNumberConversion(specificAsBoxed, generic) ? 3 : 0;
/*     */         }
/*  98 */         return 0;
/*     */       } 
/*     */       
/* 101 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     if (ifHigherThan >= 3) return 0; 
/* 106 */     if (bugfixed && !genericIsPrim && Number.class
/* 107 */       .isAssignableFrom(specific) && Number.class.isAssignableFrom(generic)) {
/* 108 */       return isWideningBoxedNumberConversion(specific, generic) ? 3 : 0;
/*     */     }
/* 110 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isWideningPrimitiveNumberConversion(Class<byte> source, Class<short> target) {
/* 117 */     if (target == short.class && source == byte.class)
/* 118 */       return true; 
/* 119 */     if (target == int.class && (source == short.class || source == byte.class))
/*     */     {
/* 121 */       return true; } 
/* 122 */     if (target == long.class && (source == int.class || source == short.class || source == byte.class))
/*     */     {
/*     */       
/* 125 */       return true; } 
/* 126 */     if (target == float.class && (source == long.class || source == int.class || source == short.class || source == byte.class))
/*     */     {
/*     */       
/* 129 */       return true; } 
/* 130 */     if (target == double.class && (source == float.class || source == long.class || source == int.class || source == short.class || source == byte.class))
/*     */     {
/*     */ 
/*     */       
/* 134 */       return true;
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isWideningBoxedNumberConversion(Class<Byte> source, Class<Short> target) {
/* 141 */     if (target == Short.class && source == Byte.class)
/* 142 */       return true; 
/* 143 */     if (target == Integer.class && (source == Short.class || source == Byte.class))
/*     */     {
/* 145 */       return true; } 
/* 146 */     if (target == Long.class && (source == Integer.class || source == Short.class || source == Byte.class))
/*     */     {
/*     */       
/* 149 */       return true; } 
/* 150 */     if (target == Float.class && (source == Long.class || source == Integer.class || source == Short.class || source == Byte.class))
/*     */     {
/*     */       
/* 153 */       return true; } 
/* 154 */     if (target == Double.class && (source == Float.class || source == Long.class || source == Integer.class || source == Short.class || source == Byte.class))
/*     */     {
/*     */ 
/*     */       
/* 158 */       return true;
/*     */     }
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set getAssignables(Class c1, Class c2) {
/* 168 */     Set s = new HashSet();
/* 169 */     collectAssignables(c1, c2, s);
/* 170 */     return s;
/*     */   }
/*     */   
/*     */   private static void collectAssignables(Class<?> c1, Class<?> c2, Set<Class<?>> s) {
/* 174 */     if (c1.isAssignableFrom(c2)) {
/* 175 */       s.add(c1);
/*     */     }
/* 177 */     Class<?> sc = c1.getSuperclass();
/* 178 */     if (sc != null) {
/* 179 */       collectAssignables(sc, c2, s);
/*     */     }
/* 181 */     Class[] itf = c1.getInterfaces();
/* 182 */     for (int i = 0; i < itf.length; i++) {
/* 183 */       collectAssignables(itf[i], c2, s);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Class[] getParameterTypes(Member member) {
/* 188 */     if (member instanceof Method) {
/* 189 */       return ((Method)member).getParameterTypes();
/*     */     }
/* 191 */     if (member instanceof Constructor) {
/* 192 */       return ((Constructor)member).getParameterTypes();
/*     */     }
/* 194 */     throw new IllegalArgumentException("\"member\" must be Method or Constructor");
/*     */   }
/*     */   
/*     */   public static boolean isVarargs(Member member) {
/* 198 */     if (member instanceof Method) {
/* 199 */       return ((Method)member).isVarArgs();
/*     */     }
/* 201 */     if (member instanceof Constructor) {
/* 202 */       return ((Constructor)member).isVarArgs();
/*     */     }
/* 204 */     throw new BugException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Member member) {
/* 211 */     if (!(member instanceof Method) && !(member instanceof Constructor)) {
/* 212 */       throw new IllegalArgumentException("\"member\" must be a Method or Constructor");
/*     */     }
/*     */     
/* 215 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 217 */     if ((member.getModifiers() & 0x8) != 0) {
/* 218 */       sb.append("static ");
/*     */     }
/*     */     
/* 221 */     String className = ClassUtil.getShortClassName(member.getDeclaringClass());
/* 222 */     if (className != null) {
/* 223 */       sb.append(className);
/* 224 */       sb.append('.');
/*     */     } 
/* 226 */     sb.append(member.getName());
/*     */     
/* 228 */     sb.append('(');
/* 229 */     Class[] paramTypes = getParameterTypes(member);
/* 230 */     for (int i = 0; i < paramTypes.length; i++) {
/* 231 */       if (i != 0) sb.append(", "); 
/* 232 */       String paramTypeDecl = ClassUtil.getShortClassName(paramTypes[i]);
/* 233 */       if (i == paramTypes.length - 1 && paramTypeDecl.endsWith("[]") && isVarargs(member)) {
/* 234 */         sb.append(paramTypeDecl.substring(0, paramTypeDecl.length() - 2));
/* 235 */         sb.append("...");
/*     */       } else {
/* 237 */         sb.append(paramTypeDecl);
/*     */       } 
/*     */     } 
/* 240 */     sb.append(')');
/*     */     
/* 242 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static Object[] invocationErrorMessageStart(Member member) {
/* 246 */     return invocationErrorMessageStart(member, member instanceof Constructor);
/*     */   }
/*     */   
/*     */   private static Object[] invocationErrorMessageStart(Object member, boolean isConstructor) {
/* 250 */     return new Object[] { "Java ", isConstructor ? "constructor " : "method ", new _DelayedJQuote(member) };
/*     */   }
/*     */   
/*     */   public static TemplateModelException newInvocationTemplateModelException(Object object, Member member, Throwable e) {
/* 254 */     return newInvocationTemplateModelException(object, member, 
/*     */ 
/*     */         
/* 257 */         ((member.getModifiers() & 0x8) != 0), member instanceof Constructor, e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static TemplateModelException newInvocationTemplateModelException(Object object, CallableMemberDescriptor callableMemberDescriptor, Throwable e) {
/* 263 */     return newInvocationTemplateModelException(object, new _DelayedConversionToString(callableMemberDescriptor)
/*     */         {
/*     */           
/*     */           protected String doConversion(Object callableMemberDescriptor)
/*     */           {
/* 268 */             return ((CallableMemberDescriptor)callableMemberDescriptor).getDeclaration();
/*     */           }
/*     */         }, 
/* 271 */         callableMemberDescriptor.isStatic(), callableMemberDescriptor
/* 272 */         .isConstructor(), e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static TemplateModelException newInvocationTemplateModelException(Object parentObject, Object member, boolean isStatic, boolean isConstructor, Throwable e) {
/* 278 */     while (e instanceof InvocationTargetException) {
/* 279 */       Throwable cause = ((InvocationTargetException)e).getTargetException();
/* 280 */       if (cause != null) {
/* 281 */         e = cause;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 287 */     (new Object[4])[0] = 
/* 288 */       invocationErrorMessageStart(member, isConstructor); (new Object[4])[1] = " threw an exception"; (new Object[4])[0] = " when invoked on "; (new Object[4])[1] = parentObject
/*     */ 
/*     */       
/* 291 */       .getClass(); (new Object[4])[2] = " object "; (new Object[4])[3] = new _DelayedJQuote(parentObject); return (TemplateModelException)new _TemplateModelException(e, new Object[] { null, null, (isStatic || isConstructor) ? "" : new Object[4], "; see cause exception in the Java stack trace." });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBeanPropertyNameFromReaderMethodName(String name, Class<?> returnType) {
/*     */     int start;
/* 302 */     if (name.startsWith("get")) {
/* 303 */       start = 3;
/* 304 */     } else if (returnType == boolean.class && name.startsWith("is")) {
/* 305 */       start = 2;
/*     */     } else {
/* 307 */       return null;
/*     */     } 
/* 309 */     int ln = name.length();
/*     */     
/* 311 */     if (start == ln) {
/* 312 */       return null;
/*     */     }
/* 314 */     char c1 = name.charAt(start);
/*     */     
/* 316 */     return (start + 1 < ln && Character.isUpperCase(name.charAt(start + 1)) && Character.isUpperCase(c1)) ? name
/* 317 */       .substring(start) : (new StringBuilder(ln - start))
/* 318 */       .append(Character.toLowerCase(c1)).append(name, start + 1, ln)
/* 319 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends java.lang.annotation.Annotation> T getInheritableAnnotation(Class<?> contextClass, Method method, Class<T> annotationClass) {
/* 327 */     T result = method.getAnnotation(annotationClass);
/* 328 */     if (result != null) {
/* 329 */       return result;
/*     */     }
/* 331 */     return getInheritableMethodAnnotation(contextClass, method
/* 332 */         .getName(), method.getParameterTypes(), true, annotationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends java.lang.annotation.Annotation> T getInheritableMethodAnnotation(Class<?> contextClass, String methodName, Class<?>[] methodParamTypes, boolean skipCheckingDirectMethod, Class<T> annotationClass) {
/* 339 */     if (!skipCheckingDirectMethod) {
/*     */       Method similarMethod;
/*     */       try {
/* 342 */         similarMethod = contextClass.getMethod(methodName, methodParamTypes);
/* 343 */       } catch (NoSuchMethodException e) {
/* 344 */         similarMethod = null;
/*     */       } 
/* 346 */       if (similarMethod != null) {
/* 347 */         T result = similarMethod.getAnnotation(annotationClass);
/* 348 */         if (result != null) {
/* 349 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/* 353 */     for (Class<?> anInterface : contextClass.getInterfaces()) {
/* 354 */       if (!anInterface.getName().startsWith("java.")) {
/*     */         Method similarInterfaceMethod;
/*     */         try {
/* 357 */           similarInterfaceMethod = anInterface.getMethod(methodName, methodParamTypes);
/* 358 */         } catch (NoSuchMethodException e) {
/* 359 */           similarInterfaceMethod = null;
/*     */         } 
/* 361 */         if (similarInterfaceMethod != null) {
/* 362 */           T result = similarInterfaceMethod.getAnnotation(annotationClass);
/* 363 */           if (result != null) {
/* 364 */             return result;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 369 */     Class<?> superClass = contextClass.getSuperclass();
/* 370 */     if (superClass == Object.class || superClass == null) {
/* 371 */       return null;
/*     */     }
/* 373 */     return getInheritableMethodAnnotation(superClass, methodName, methodParamTypes, false, annotationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends java.lang.annotation.Annotation> T getInheritableAnnotation(Class<?> contextClass, Constructor<?> constructor, Class<T> annotationClass) {
/* 382 */     T result = constructor.getAnnotation(annotationClass);
/* 383 */     if (result != null) {
/* 384 */       return result;
/*     */     }
/*     */     
/* 387 */     Class<?>[] paramTypes = constructor.getParameterTypes();
/*     */     while (true) {
/* 389 */       contextClass = contextClass.getSuperclass();
/* 390 */       if (contextClass == Object.class || contextClass == null) {
/* 391 */         return null;
/*     */       }
/*     */       try {
/* 394 */         constructor = contextClass.getConstructor(paramTypes);
/* 395 */       } catch (NoSuchMethodException e) {
/* 396 */         constructor = null;
/*     */       } 
/* 398 */       if (constructor != null) {
/* 399 */         result = constructor.getAnnotation(annotationClass);
/* 400 */         if (result != null) {
/* 401 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends java.lang.annotation.Annotation> T getInheritableAnnotation(Class<?> contextClass, Field field, Class<T> annotationClass) {
/* 412 */     T result = field.getAnnotation(annotationClass);
/* 413 */     if (result != null) {
/* 414 */       return result;
/*     */     }
/* 416 */     return getInheritableFieldAnnotation(contextClass, field
/* 417 */         .getName(), true, annotationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T extends java.lang.annotation.Annotation> T getInheritableFieldAnnotation(Class<?> contextClass, String fieldName, boolean skipCheckingDirectField, Class<T> annotationClass) {
/* 424 */     if (!skipCheckingDirectField) {
/*     */       Field similarField;
/*     */       try {
/* 427 */         similarField = contextClass.getField(fieldName);
/* 428 */       } catch (NoSuchFieldException e) {
/* 429 */         similarField = null;
/*     */       } 
/* 431 */       if (similarField != null) {
/* 432 */         T result = similarField.getAnnotation(annotationClass);
/* 433 */         if (result != null) {
/* 434 */           return result;
/*     */         }
/*     */       } 
/*     */     } 
/* 438 */     for (Class<?> anInterface : contextClass.getInterfaces()) {
/* 439 */       if (!anInterface.getName().startsWith("java.")) {
/*     */         Field similarInterfaceField;
/*     */         try {
/* 442 */           similarInterfaceField = anInterface.getField(fieldName);
/* 443 */         } catch (NoSuchFieldException e) {
/* 444 */           similarInterfaceField = null;
/*     */         } 
/* 446 */         if (similarInterfaceField != null) {
/* 447 */           T result = similarInterfaceField.getAnnotation(annotationClass);
/* 448 */           if (result != null) {
/* 449 */             return result;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 454 */     Class<?> superClass = contextClass.getSuperclass();
/* 455 */     if (superClass == Object.class || superClass == null) {
/* 456 */       return null;
/*     */     }
/* 458 */     return getInheritableFieldAnnotation(superClass, fieldName, false, annotationClass);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\_MethodUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */