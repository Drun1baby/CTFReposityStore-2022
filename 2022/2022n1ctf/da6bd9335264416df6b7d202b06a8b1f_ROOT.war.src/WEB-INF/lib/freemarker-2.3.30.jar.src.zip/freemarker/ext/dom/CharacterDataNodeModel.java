/*    */ package freemarker.ext.dom;
/*    */ 
/*    */ import freemarker.template.TemplateScalarModel;
/*    */ import org.w3c.dom.CharacterData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CharacterDataNodeModel
/*    */   extends NodeModel
/*    */   implements TemplateScalarModel
/*    */ {
/*    */   public CharacterDataNodeModel(CharacterData text) {
/* 30 */     super(text);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAsString() {
/* 35 */     return ((CharacterData)this.node).getData();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNodeName() {
/* 40 */     return (this.node instanceof org.w3c.dom.Comment) ? "@comment" : "@text";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\dom\CharacterDataNodeModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */