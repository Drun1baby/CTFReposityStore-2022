package freemarker.ext.beans;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public interface ClassMemberAccessPolicy {
  boolean isMethodExposed(Method paramMethod);
  
  boolean isConstructorExposed(Constructor<?> paramConstructor);
  
  boolean isFieldExposed(Field paramField);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\ClassMemberAccessPolicy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */