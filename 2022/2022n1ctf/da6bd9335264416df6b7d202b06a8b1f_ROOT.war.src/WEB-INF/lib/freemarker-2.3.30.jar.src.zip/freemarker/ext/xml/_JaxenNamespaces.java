package freemarker.ext.xml;

import freemarker.template.TemplateModelException;
import java.util.List;
import org.jaxen.NamespaceContext;

public class _JaxenNamespaces extends Namespaces implements NamespaceContext {}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\xml\_JaxenNamespaces.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */