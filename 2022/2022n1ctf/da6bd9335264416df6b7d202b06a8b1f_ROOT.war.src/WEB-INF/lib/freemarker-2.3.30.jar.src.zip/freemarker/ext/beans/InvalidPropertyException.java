/*    */ package freemarker.ext.beans;
/*    */ 
/*    */ import freemarker.template.TemplateModelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidPropertyException
/*    */   extends TemplateModelException
/*    */ {
/*    */   public InvalidPropertyException(String description) {
/* 32 */     super(description);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\InvalidPropertyException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */