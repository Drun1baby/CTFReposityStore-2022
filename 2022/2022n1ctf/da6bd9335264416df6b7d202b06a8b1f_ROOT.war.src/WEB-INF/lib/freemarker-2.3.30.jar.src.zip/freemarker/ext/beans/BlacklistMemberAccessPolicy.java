/*    */ package freemarker.ext.beans;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlacklistMemberAccessPolicy
/*    */   extends MemberSelectorListMemberAccessPolicy
/*    */ {
/*    */   private final boolean toStringAlwaysExposed;
/*    */   
/*    */   public BlacklistMemberAccessPolicy(Collection<? extends MemberSelectorListMemberAccessPolicy.MemberSelector> memberSelectors) {
/* 50 */     super(memberSelectors, MemberSelectorListMemberAccessPolicy.ListType.BLACKLIST, null);
/*    */     
/* 52 */     boolean toStringBlacklistedAnywhere = false;
/* 53 */     for (MemberSelectorListMemberAccessPolicy.MemberSelector memberSelector : memberSelectors) {
/* 54 */       Method method = memberSelector.getMethod();
/* 55 */       if (method != null && method.getName().equals("toString") && (method.getParameterTypes()).length == 0) {
/* 56 */         toStringBlacklistedAnywhere = true;
/*    */         break;
/*    */       } 
/*    */     } 
/* 60 */     this.toStringAlwaysExposed = !toStringBlacklistedAnywhere;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isToStringAlwaysExposed() {
/* 65 */     return this.toStringAlwaysExposed;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\BlacklistMemberAccessPolicy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */