/*    */ package freemarker.ext.beans;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NonPrimitiveArrayBackedReadOnlyList
/*    */   extends AbstractList
/*    */ {
/*    */   private final Object[] array;
/*    */   
/*    */   NonPrimitiveArrayBackedReadOnlyList(Object[] array) {
/* 29 */     this.array = array;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object get(int index) {
/* 34 */     return this.array[index];
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 39 */     return this.array.length;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\NonPrimitiveArrayBackedReadOnlyList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */