/*    */ package freemarker.ext.beans;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FastPropertyDescriptor
/*    */ {
/*    */   private final Method readMethod;
/*    */   private final Method indexedReadMethod;
/*    */   
/*    */   public FastPropertyDescriptor(Method readMethod, Method indexedReadMethod) {
/* 34 */     this.readMethod = readMethod;
/* 35 */     this.indexedReadMethod = indexedReadMethod;
/*    */   }
/*    */   
/*    */   public Method getReadMethod() {
/* 39 */     return this.readMethod;
/*    */   }
/*    */   
/*    */   public Method getIndexedReadMethod() {
/* 43 */     return this.indexedReadMethod;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\beans\FastPropertyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */