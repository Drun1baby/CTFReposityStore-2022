/*    */ package freemarker.ext.dom;
/*    */ 
/*    */ import freemarker.core.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class _ExtDomApi
/*    */ {
/*    */   public static boolean isXMLNameLike(String name) {
/* 36 */     return DomStringUtil.isXMLNameLike(name);
/*    */   }
/*    */   
/*    */   public static boolean matchesName(String qname, String nodeName, String nsURI, Environment env) {
/* 40 */     return DomStringUtil.matchesName(qname, nodeName, nsURI, env);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\ext\dom\_ExtDomApi.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */