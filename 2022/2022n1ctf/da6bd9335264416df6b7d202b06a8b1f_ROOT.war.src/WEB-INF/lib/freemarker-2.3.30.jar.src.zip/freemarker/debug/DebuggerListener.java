package freemarker.debug;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.EventListener;

public interface DebuggerListener extends Remote, EventListener {
  void environmentSuspended(EnvironmentSuspendedEvent paramEnvironmentSuspendedEvent) throws RemoteException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\debug\DebuggerListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */