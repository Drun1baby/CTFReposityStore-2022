package freemarker.debug;

import java.rmi.RemoteException;

public interface DebuggedEnvironment extends DebugModel {
  void resume() throws RemoteException;
  
  void stop() throws RemoteException;
  
  long getId() throws RemoteException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\debug\DebuggedEnvironment.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */