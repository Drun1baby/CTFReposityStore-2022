package freemarker.cache;

import java.io.IOException;
import java.io.Reader;

public interface TemplateLoader {
  Object findTemplateSource(String paramString) throws IOException;
  
  long getLastModified(Object paramObject);
  
  Reader getReader(Object paramObject, String paramString) throws IOException;
  
  void closeTemplateSource(Object paramObject) throws IOException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\TemplateLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */