/*    */ package freemarker.cache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotMatcher
/*    */   extends TemplateSourceMatcher
/*    */ {
/*    */   private final TemplateSourceMatcher matcher;
/*    */   
/*    */   public NotMatcher(TemplateSourceMatcher matcher) {
/* 33 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(String sourceName, Object templateSource) throws IOException {
/* 38 */     return !this.matcher.matches(sourceName, templateSource);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\NotMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */