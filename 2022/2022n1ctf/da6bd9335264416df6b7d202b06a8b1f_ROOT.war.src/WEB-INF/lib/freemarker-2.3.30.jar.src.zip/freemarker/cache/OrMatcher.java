/*    */ package freemarker.cache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrMatcher
/*    */   extends TemplateSourceMatcher
/*    */ {
/*    */   private final TemplateSourceMatcher[] matchers;
/*    */   
/*    */   public OrMatcher(TemplateSourceMatcher... matchers) {
/* 33 */     if (matchers.length == 0) throw new IllegalArgumentException("Need at least 1 matcher, had 0."); 
/* 34 */     this.matchers = matchers;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(String sourceName, Object templateSource) throws IOException {
/* 39 */     for (TemplateSourceMatcher matcher : this.matchers) {
/* 40 */       if (matcher.matches(sourceName, templateSource)) return true; 
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\OrMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */