/*    */ package freemarker.cache;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrongCacheStorage
/*    */   implements ConcurrentCacheStorage, CacheStorageWithGetSize
/*    */ {
/* 34 */   private final Map map = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isConcurrent() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object get(Object key) {
/* 46 */     return this.map.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public void put(Object key, Object value) {
/* 51 */     this.map.put(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(Object key) {
/* 56 */     this.map.remove(key);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSize() {
/* 66 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 71 */     this.map.clear();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\StrongCacheStorage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */