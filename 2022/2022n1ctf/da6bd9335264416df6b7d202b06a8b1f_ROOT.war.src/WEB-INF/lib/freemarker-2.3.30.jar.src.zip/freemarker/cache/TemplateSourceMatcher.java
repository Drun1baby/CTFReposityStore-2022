package freemarker.cache;

import java.io.IOException;

public abstract class TemplateSourceMatcher {
  abstract boolean matches(String paramString, Object paramObject) throws IOException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\TemplateSourceMatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */