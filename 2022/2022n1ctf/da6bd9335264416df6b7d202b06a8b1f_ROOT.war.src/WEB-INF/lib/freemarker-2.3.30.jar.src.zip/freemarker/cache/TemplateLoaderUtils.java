/*    */ package freemarker.cache;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TemplateLoaderUtils
/*    */ {
/*    */   public static String getClassNameForToString(TemplateLoader templateLoader) {
/* 31 */     Class<?> tlClass = templateLoader.getClass();
/* 32 */     Package tlPackage = tlClass.getPackage();
/* 33 */     return (tlPackage == Configuration.class.getPackage() || tlPackage == TemplateLoader.class.getPackage()) ? tlClass
/* 34 */       .getSimpleName() : tlClass.getName();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\cache\TemplateLoaderUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */