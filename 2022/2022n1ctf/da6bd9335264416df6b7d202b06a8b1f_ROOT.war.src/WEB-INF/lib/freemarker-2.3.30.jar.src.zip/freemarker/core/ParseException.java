/*     */ package freemarker.core;
/*     */ 
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.utility.SecurityUtilities;
/*     */ import freemarker.template.utility.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseException
/*     */   extends IOException
/*     */   implements FMParserConstants
/*     */ {
/*     */   public Token currentToken;
/*     */   private static volatile Boolean jbossToolsMode;
/*     */   private boolean messageAndDescriptionRendered;
/*     */   private String message;
/*     */   private String description;
/*     */   public int columnNumber;
/*     */   public int lineNumber;
/*     */   public int endColumnNumber;
/*     */   public int endLineNumber;
/*     */   public int[][] expectedTokenSequences;
/*     */   public String[] tokenImage;
/*  80 */   protected String eol = SecurityUtilities.getSystemProperty("line.separator", "\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected boolean specialConstructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String templateName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(Token currentTokenVal, int[][] expectedTokenSequencesVal, String[] tokenImageVal) {
/* 102 */     super("");
/* 103 */     this.currentToken = currentTokenVal;
/* 104 */     this.specialConstructor = true;
/* 105 */     this.expectedTokenSequences = expectedTokenSequencesVal;
/* 106 */     this.tokenImage = tokenImageVal;
/* 107 */     this.lineNumber = this.currentToken.next.beginLine;
/* 108 */     this.columnNumber = this.currentToken.next.beginColumn;
/* 109 */     this.endLineNumber = this.currentToken.next.endLine;
/* 110 */     this.endColumnNumber = this.currentToken.next.endColumn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ParseException() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ParseException(String description, int lineNumber, int columnNumber) {
/* 134 */     this(description, null, lineNumber, columnNumber, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, Template template, int lineNumber, int columnNumber, int endLineNumber, int endColumnNumber) {
/* 142 */     this(description, template, lineNumber, columnNumber, endLineNumber, endColumnNumber, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, Template template, int lineNumber, int columnNumber, int endLineNumber, int endColumnNumber, Throwable cause) {
/* 151 */     this(description, (template == null) ? null : template
/* 152 */         .getSourceName(), lineNumber, columnNumber, endLineNumber, endColumnNumber, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ParseException(String description, Template template, int lineNumber, int columnNumber) {
/* 165 */     this(description, template, lineNumber, columnNumber, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ParseException(String description, Template template, int lineNumber, int columnNumber, Throwable cause) {
/* 175 */     this(description, (template == null) ? null : template
/* 176 */         .getSourceName(), lineNumber, columnNumber, 0, 0, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, Template template, Token tk) {
/* 186 */     this(description, template, tk, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, Template template, Token tk, Throwable cause) {
/* 193 */     this(description, (template == null) ? null : template
/* 194 */         .getSourceName(), tk.beginLine, tk.beginColumn, tk.endLine, tk.endColumn, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, TemplateObject tobj) {
/* 204 */     this(description, tobj, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseException(String description, TemplateObject tobj, Throwable cause) {
/* 211 */     this(description, 
/* 212 */         (tobj.getTemplate() == null) ? null : tobj.getTemplate().getSourceName(), tobj.beginLine, tobj.beginColumn, tobj.endLine, tobj.endColumn, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ParseException(String description, String templateName, int lineNumber, int columnNumber, int endLineNumber, int endColumnNumber, Throwable cause) {
/* 222 */     super(description);
/*     */     try {
/* 224 */       initCause(cause);
/* 225 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 228 */     this.description = description;
/* 229 */     this.templateName = templateName;
/* 230 */     this.lineNumber = lineNumber;
/* 231 */     this.columnNumber = columnNumber;
/* 232 */     this.endLineNumber = endLineNumber;
/* 233 */     this.endColumnNumber = endColumnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateName(String templateName) {
/* 242 */     this.templateName = templateName;
/* 243 */     synchronized (this) {
/* 244 */       this.messageAndDescriptionRendered = false;
/* 245 */       this.message = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 259 */     synchronized (this) {
/* 260 */       if (this.messageAndDescriptionRendered) return this.message; 
/*     */     } 
/* 262 */     renderMessageAndDescription();
/* 263 */     synchronized (this) {
/* 264 */       return this.message;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getDescription() {
/* 269 */     synchronized (this) {
/* 270 */       if (this.messageAndDescriptionRendered) return this.description; 
/*     */     } 
/* 272 */     renderMessageAndDescription();
/* 273 */     synchronized (this) {
/* 274 */       return this.description;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEditorMessage() {
/* 284 */     return getDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTemplateName() {
/* 294 */     return this.templateName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 301 */     return this.lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNumber() {
/* 308 */     return this.columnNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndLineNumber() {
/* 317 */     return this.endLineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndColumnNumber() {
/* 327 */     return this.endColumnNumber;
/*     */   }
/*     */   
/*     */   private void renderMessageAndDescription() {
/* 331 */     String prefix, desc = getOrRenderDescription();
/*     */ 
/*     */     
/* 334 */     if (!isInJBossToolsMode()) {
/*     */       
/* 336 */       prefix = "Syntax error " + _MessageUtil.formatLocationForSimpleParsingError(this.templateName, this.lineNumber, this.columnNumber) + ":\n";
/*     */     } else {
/*     */       
/* 339 */       prefix = "[col. " + this.columnNumber + "] ";
/*     */     } 
/*     */     
/* 342 */     String msg = prefix + desc;
/* 343 */     desc = msg.substring(prefix.length());
/*     */     
/* 345 */     synchronized (this) {
/* 346 */       this.message = msg;
/* 347 */       this.description = desc;
/* 348 */       this.messageAndDescriptionRendered = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isInJBossToolsMode() {
/* 353 */     if (jbossToolsMode == null) {
/*     */       try {
/* 355 */         jbossToolsMode = Boolean.valueOf(
/* 356 */             (ParseException.class.getClassLoader().toString().indexOf("[org.jboss.ide.eclipse.freemarker:") != -1));
/*     */       }
/* 358 */       catch (Throwable e) {
/* 359 */         jbossToolsMode = Boolean.FALSE;
/*     */       } 
/*     */     }
/* 362 */     return jbossToolsMode.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getOrRenderDescription() {
/*     */     String tokenErrDesc;
/* 370 */     synchronized (this) {
/* 371 */       if (this.description != null) return this.description;
/*     */     
/*     */     } 
/*     */     
/* 375 */     if (this.currentToken != null) {
/* 376 */       tokenErrDesc = getCustomTokenErrorDescription();
/* 377 */       if (tokenErrDesc == null) {
/*     */         
/* 379 */         StringBuilder expected = new StringBuilder();
/* 380 */         int maxSize = 0;
/* 381 */         for (int i = 0; i < this.expectedTokenSequences.length; i++) {
/* 382 */           if (i != 0) {
/* 383 */             expected.append(this.eol);
/*     */           }
/* 385 */           expected.append("    ");
/* 386 */           if (maxSize < (this.expectedTokenSequences[i]).length) {
/* 387 */             maxSize = (this.expectedTokenSequences[i]).length;
/*     */           }
/* 389 */           for (int k = 0; k < (this.expectedTokenSequences[i]).length; k++) {
/* 390 */             if (k != 0) expected.append(' '); 
/* 391 */             expected.append(this.tokenImage[this.expectedTokenSequences[i][k]]);
/*     */           } 
/*     */         } 
/* 394 */         tokenErrDesc = "Encountered \"";
/* 395 */         Token tok = this.currentToken.next;
/* 396 */         for (int j = 0; j < maxSize; j++) {
/* 397 */           if (j != 0) tokenErrDesc = tokenErrDesc + " "; 
/* 398 */           if (tok.kind == 0) {
/* 399 */             tokenErrDesc = tokenErrDesc + this.tokenImage[0];
/*     */             break;
/*     */           } 
/* 402 */           tokenErrDesc = tokenErrDesc + add_escapes(tok.image);
/* 403 */           tok = tok.next;
/*     */         } 
/* 405 */         tokenErrDesc = tokenErrDesc + "\", but ";
/*     */         
/* 407 */         if (this.expectedTokenSequences.length == 1) {
/* 408 */           tokenErrDesc = tokenErrDesc + "was expecting:" + this.eol;
/*     */         } else {
/* 410 */           tokenErrDesc = tokenErrDesc + "was expecting one of:" + this.eol;
/*     */         } 
/* 412 */         tokenErrDesc = tokenErrDesc + expected;
/*     */       } 
/*     */     } else {
/* 415 */       tokenErrDesc = null;
/*     */     } 
/* 417 */     return tokenErrDesc;
/*     */   }
/*     */   
/*     */   private String getCustomTokenErrorDescription() {
/* 421 */     Token nextToken = this.currentToken.next;
/* 422 */     int kind = nextToken.kind;
/* 423 */     if (kind == 0) {
/* 424 */       Set<String> endNames = new HashSet();
/* 425 */       for (int i = 0; i < this.expectedTokenSequences.length; i++) {
/* 426 */         int[] sequence = this.expectedTokenSequences[i];
/* 427 */         for (int j = 0; j < sequence.length; j++) {
/* 428 */           switch (sequence[j]) {
/*     */             case 42:
/* 430 */               endNames.add("#foreach");
/*     */               break;
/*     */             case 37:
/* 433 */               endNames.add("#list");
/*     */               break;
/*     */             case 53:
/* 436 */               endNames.add("#switch");
/*     */               break;
/*     */             case 36:
/* 439 */               endNames.add("#if");
/*     */               break;
/*     */             case 51:
/* 442 */               endNames.add("#compress");
/*     */               break;
/*     */             case 47:
/* 445 */               endNames.add("#macro");
/*     */             case 46:
/* 447 */               endNames.add("#function");
/*     */               break;
/*     */             case 52:
/* 450 */               endNames.add("#transform");
/*     */               break;
/*     */             case 71:
/* 453 */               endNames.add("#escape");
/*     */               break;
/*     */             case 73:
/* 456 */               endNames.add("#noescape");
/*     */               break;
/*     */             case 45:
/* 459 */               endNames.add("#assign");
/*     */               break;
/*     */             case 43:
/* 462 */               endNames.add("#local");
/*     */               break;
/*     */             case 44:
/* 465 */               endNames.add("#global");
/*     */               break;
/*     */             case 41:
/* 468 */               endNames.add("#attempt");
/*     */               break;
/*     */             case 138:
/* 471 */               endNames.add("\"{\"");
/*     */               break;
/*     */             case 134:
/* 474 */               endNames.add("\"[\"");
/*     */               break;
/*     */             case 136:
/* 477 */               endNames.add("\"(\"");
/*     */               break;
/*     */             case 75:
/* 480 */               endNames.add("@...");
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 485 */       return "Unexpected end of file reached." + (
/* 486 */         (endNames.size() == 0) ? "" : (" You have an unclosed " + concatWithOrs(endNames) + "."));
/* 487 */     }  if (kind == 54) {
/* 488 */       return "Unexpected directive, \"#else\". Check if you have a valid #if-#elseif-#else or #list-#else structure.";
/*     */     }
/* 490 */     if (kind == 36 || kind == 9) {
/* 491 */       return "Unexpected directive, " + 
/* 492 */         StringUtil.jQuote(nextToken) + ". Check if you have a valid #if-#elseif-#else structure.";
/*     */     }
/*     */     
/* 495 */     return null;
/*     */   }
/*     */   
/*     */   private String concatWithOrs(Set endNames) {
/* 499 */     StringBuilder sb = new StringBuilder();
/* 500 */     for (Iterator<String> it = endNames.iterator(); it.hasNext(); ) {
/* 501 */       String endName = it.next();
/* 502 */       if (sb.length() != 0) {
/* 503 */         sb.append(" or ");
/*     */       }
/* 505 */       sb.append(endName);
/*     */     } 
/* 507 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String add_escapes(String str) {
/* 516 */     StringBuilder retval = new StringBuilder();
/*     */     
/* 518 */     for (int i = 0; i < str.length(); i++) {
/* 519 */       char ch; switch (str.charAt(i)) {
/*     */         case '\000':
/*     */           break;
/*     */         
/*     */         case '\b':
/* 524 */           retval.append("\\b");
/*     */           break;
/*     */         case '\t':
/* 527 */           retval.append("\\t");
/*     */           break;
/*     */         case '\n':
/* 530 */           retval.append("\\n");
/*     */           break;
/*     */         case '\f':
/* 533 */           retval.append("\\f");
/*     */           break;
/*     */         case '\r':
/* 536 */           retval.append("\\r");
/*     */           break;
/*     */         case '"':
/* 539 */           retval.append("\\\"");
/*     */           break;
/*     */         case '\'':
/* 542 */           retval.append("\\'");
/*     */           break;
/*     */         case '\\':
/* 545 */           retval.append("\\\\");
/*     */           break;
/*     */         default:
/* 548 */           if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/* 549 */             String s = "0000" + Integer.toString(ch, 16);
/* 550 */             retval.append("\\u" + s.substring(s.length() - 4, s.length())); break;
/*     */           } 
/* 552 */           retval.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 557 */     return retval.toString();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\ParseException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */