/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CommonTemplateMarkupOutputModel<MO extends CommonTemplateMarkupOutputModel<MO>>
/*    */   implements TemplateMarkupOutputModel<MO>
/*    */ {
/*    */   private final String plainTextContent;
/*    */   private String markupContent;
/*    */   
/*    */   protected CommonTemplateMarkupOutputModel(String plainTextContent, String markupContent) {
/* 42 */     this.plainTextContent = plainTextContent;
/* 43 */     this.markupContent = markupContent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getPlainTextContent() {
/* 51 */     return this.plainTextContent;
/*    */   }
/*    */ 
/*    */   
/*    */   final String getMarkupContent() {
/* 56 */     return this.markupContent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final void setMarkupContent(String markupContent) {
/* 64 */     this.markupContent = markupContent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "markupOutput(format=" + getOutputFormat().getName() + ", " + ((this.plainTextContent != null) ? ("plainText=" + this.plainTextContent) : ("markup=" + this.markupContent)) + ")";
/*    */   }
/*    */   
/*    */   public abstract CommonMarkupOutputFormat<MO> getOutputFormat();
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\CommonTemplateMarkupOutputModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */