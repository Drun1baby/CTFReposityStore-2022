/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class RightUnboundedRangeModel
/*    */   extends RangeModel
/*    */ {
/*    */   RightUnboundedRangeModel(int begin) {
/* 25 */     super(begin);
/*    */   }
/*    */ 
/*    */   
/*    */   final int getStep() {
/* 30 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   final boolean isRightUnbounded() {
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   final boolean isRightAdaptive() {
/* 40 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   final boolean isAffectedByStringSlicingBug() {
/* 45 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\RightUnboundedRangeModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */