/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UncheckedParseException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final ParseException parseException;
/*    */   
/*    */   public UncheckedParseException(ParseException parseException) {
/* 31 */     this.parseException = parseException;
/*    */   }
/*    */   
/*    */   public ParseException getParseException() {
/* 35 */     return this.parseException;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\UncheckedParseException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */