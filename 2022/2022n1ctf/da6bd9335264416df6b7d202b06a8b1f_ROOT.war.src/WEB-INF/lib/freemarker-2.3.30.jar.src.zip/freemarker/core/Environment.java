/*      */ package freemarker.core;
/*      */ 
/*      */ import freemarker.cache.TemplateNameFormat;
/*      */ import freemarker.cache._CacheAPI;
/*      */ import freemarker.ext.beans.BeansWrapper;
/*      */ import freemarker.log.Logger;
/*      */ import freemarker.template.Configuration;
/*      */ import freemarker.template.MalformedTemplateNameException;
/*      */ import freemarker.template.ObjectWrapper;
/*      */ import freemarker.template.SimpleHash;
/*      */ import freemarker.template.SimpleSequence;
/*      */ import freemarker.template.Template;
/*      */ import freemarker.template.TemplateCollectionModel;
/*      */ import freemarker.template.TemplateDateModel;
/*      */ import freemarker.template.TemplateDirectiveBody;
/*      */ import freemarker.template.TemplateDirectiveModel;
/*      */ import freemarker.template.TemplateException;
/*      */ import freemarker.template.TemplateExceptionHandler;
/*      */ import freemarker.template.TemplateHashModel;
/*      */ import freemarker.template.TemplateHashModelEx;
/*      */ import freemarker.template.TemplateHashModelEx2;
/*      */ import freemarker.template.TemplateModel;
/*      */ import freemarker.template.TemplateModelException;
/*      */ import freemarker.template.TemplateModelIterator;
/*      */ import freemarker.template.TemplateNodeModel;
/*      */ import freemarker.template.TemplateNumberModel;
/*      */ import freemarker.template.TemplateScalarModel;
/*      */ import freemarker.template.TemplateSequenceModel;
/*      */ import freemarker.template.TemplateTransformModel;
/*      */ import freemarker.template.TransformControl;
/*      */ import freemarker.template._TemplateAPI;
/*      */ import freemarker.template.utility.DateUtil;
/*      */ import freemarker.template.utility.NullWriter;
/*      */ import freemarker.template.utility.StringUtil;
/*      */ import freemarker.template.utility.TemplateModelUtils;
/*      */ import freemarker.template.utility.UndeclaredThrowableException;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.Collator;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.DecimalFormatSymbols;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Environment
/*      */   extends Configurable
/*      */ {
/*  100 */   private static final ThreadLocal threadEnv = new ThreadLocal();
/*      */   
/*  102 */   private static final Logger LOG = Logger.getLogger("freemarker.runtime");
/*  103 */   private static final Logger ATTEMPT_LOGGER = Logger.getLogger("freemarker.runtime.attempt");
/*      */ 
/*      */ 
/*      */   
/*  107 */   private static final DecimalFormat C_NUMBER_FORMAT = new DecimalFormat("0.################", new DecimalFormatSymbols(Locale.US)); private final Configuration configuration;
/*      */   private final boolean incompatibleImprovementsGE2328;
/*      */   private final TemplateHashModel rootDataModel;
/*      */   
/*      */   static {
/*  112 */     C_NUMBER_FORMAT.setGroupingUsed(false);
/*  113 */     C_NUMBER_FORMAT.setDecimalSeparatorAlwaysShown(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private TemplateElement[] instructionStack = new TemplateElement[16];
/*  120 */   private int instructionStackSize = 0;
/*  121 */   private final ArrayList recoveredErrorStack = new ArrayList();
/*      */ 
/*      */   
/*      */   private TemplateNumberFormat cachedTemplateNumberFormat;
/*      */ 
/*      */   
/*      */   private Map<String, TemplateNumberFormat> cachedTemplateNumberFormats;
/*      */ 
/*      */   
/*      */   private TemplateDateFormat[] cachedTempDateFormatArray;
/*      */ 
/*      */   
/*      */   private HashMap<String, TemplateDateFormat>[] cachedTempDateFormatsByFmtStrArray;
/*      */ 
/*      */   
/*      */   private static final int CACHED_TDFS_ZONELESS_INPUT_OFFS = 4;
/*      */ 
/*      */   
/*      */   private static final int CACHED_TDFS_SQL_D_T_TZ_OFFS = 8;
/*      */ 
/*      */   
/*      */   private static final int CACHED_TDFS_LENGTH = 16;
/*      */ 
/*      */   
/*      */   private Boolean cachedSQLDateAndTimeTimeZoneSameAsNormal;
/*      */ 
/*      */   
/*      */   private NumberFormat cNumberFormat;
/*      */ 
/*      */   
/*      */   private DateUtil.DateToISO8601CalendarFactory isoBuiltInCalendarFactory;
/*      */   
/*      */   private Collator cachedCollator;
/*      */   
/*      */   private Writer out;
/*      */   
/*      */   private Macro.Context currentMacroContext;
/*      */   
/*      */   private LocalContextStack localContextStack;
/*      */   
/*      */   private final Namespace mainNamespace;
/*      */   
/*      */   private Namespace currentNamespace;
/*      */   
/*      */   private Namespace globalNamespace;
/*      */   
/*      */   private HashMap<String, Namespace> loadedLibs;
/*      */   
/*      */   private Configurable legacyParent;
/*      */   
/*      */   private boolean inAttemptBlock;
/*      */   
/*      */   private Throwable lastThrowable;
/*      */   
/*      */   private TemplateModel lastReturnValue;
/*      */   
/*  177 */   private Map<Object, Namespace> macroToNamespaceLookup = new IdentityHashMap<>();
/*      */   
/*      */   private TemplateNodeModel currentVisitorNode;
/*      */   
/*      */   private TemplateSequenceModel nodeNamespaces;
/*      */   
/*      */   private int nodeNamespaceIndex;
/*      */   
/*      */   private String currentNodeName;
/*      */   
/*      */   private String currentNodeNS;
/*      */   
/*      */   private String cachedURLEscapingCharset;
/*      */   
/*      */   private boolean cachedURLEscapingCharsetSet;
/*      */   
/*      */   private boolean fastInvalidReferenceExceptions;
/*      */ 
/*      */   
/*      */   public static Environment getCurrentEnvironment() {
/*  197 */     return threadEnv.get();
/*      */   }
/*      */   
/*      */   static void setCurrentEnvironment(Environment env) {
/*  201 */     threadEnv.set(env);
/*      */   }
/*      */   
/*      */   public Environment(Template template, TemplateHashModel rootDataModel, Writer out) {
/*  205 */     super((Configurable)template);
/*  206 */     this.configuration = template.getConfiguration();
/*  207 */     this.incompatibleImprovementsGE2328 = (this.configuration.getIncompatibleImprovements().intValue() >= _TemplateAPI.VERSION_INT_2_3_28);
/*  208 */     this.globalNamespace = new Namespace(null);
/*  209 */     this.currentNamespace = this.mainNamespace = new Namespace(template);
/*  210 */     this.out = out;
/*  211 */     this.rootDataModel = rootDataModel;
/*  212 */     importMacros(template);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Template getTemplate() {
/*  227 */     return (Template)getParent();
/*      */   }
/*      */ 
/*      */   
/*      */   Template getTemplate230() {
/*  232 */     Template legacyParent = (Template)this.legacyParent;
/*  233 */     return (legacyParent != null) ? legacyParent : getTemplate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Template getMainTemplate() {
/*  246 */     return this.mainNamespace.getTemplate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Template getCurrentTemplate() {
/*  263 */     int ln = this.instructionStackSize;
/*  264 */     return (ln == 0) ? getMainTemplate() : this.instructionStack[ln - 1].getTemplate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DirectiveCallPlace getCurrentDirectiveCallPlace() {
/*  277 */     int ln = this.instructionStackSize;
/*  278 */     if (ln == 0) return null; 
/*  279 */     TemplateElement te = this.instructionStack[ln - 1];
/*  280 */     if (te instanceof UnifiedCall) return (UnifiedCall)te; 
/*  281 */     if (te instanceof Macro && ln > 1 && this.instructionStack[ln - 2] instanceof UnifiedCall) {
/*  282 */       return (UnifiedCall)this.instructionStack[ln - 2];
/*      */     }
/*  284 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearCachedValues() {
/*  291 */     this.cachedTemplateNumberFormats = null;
/*  292 */     this.cachedTemplateNumberFormat = null;
/*      */     
/*  294 */     this.cachedTempDateFormatArray = null;
/*  295 */     this.cachedTempDateFormatsByFmtStrArray = null;
/*      */     
/*  297 */     this.cachedCollator = null;
/*  298 */     this.cachedURLEscapingCharset = null;
/*  299 */     this.cachedURLEscapingCharsetSet = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void process() throws TemplateException, IOException {
/*  306 */     Object savedEnv = threadEnv.get();
/*  307 */     threadEnv.set(this);
/*      */     
/*      */     try {
/*  310 */       clearCachedValues();
/*      */       try {
/*  312 */         doAutoImportsAndIncludes(this);
/*  313 */         visit(getTemplate().getRootTreeNode());
/*      */         
/*  315 */         if (getAutoFlush()) {
/*  316 */           this.out.flush();
/*      */         }
/*      */       } finally {
/*      */         
/*  320 */         clearCachedValues();
/*      */       } 
/*      */     } finally {
/*  323 */       threadEnv.set(savedEnv);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void visit(TemplateElement element) throws IOException, TemplateException {
/*  332 */     pushElement(element);
/*      */     try {
/*  334 */       TemplateElement[] templateElementsToVisit = element.accept(this);
/*  335 */       if (templateElementsToVisit != null) {
/*  336 */         for (TemplateElement el : templateElementsToVisit) {
/*  337 */           if (el == null) {
/*      */             break;
/*      */           }
/*  340 */           visit(el);
/*      */         } 
/*      */       }
/*  343 */     } catch (TemplateException te) {
/*  344 */       handleTemplateException(te);
/*      */     } finally {
/*  346 */       popElement();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void visit(TemplateElement[] elementBuffer) throws IOException, TemplateException {
/*  358 */     if (elementBuffer == null) {
/*      */       return;
/*      */     }
/*  361 */     for (TemplateElement element : elementBuffer) {
/*  362 */       if (element == null) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  368 */       pushElement(element);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void visit(TemplateElement[] elementBuffer, Writer out) throws IOException, TemplateException {
/*  394 */     Writer prevOut = this.out;
/*  395 */     this.out = out;
/*      */     try {
/*  397 */       visit(elementBuffer);
/*      */     } finally {
/*  399 */       this.out = prevOut;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private TemplateElement replaceTopElement(TemplateElement element) {
/*  405 */     this.instructionStack[this.instructionStackSize - 1] = element; return element;
/*      */   }
/*      */   
/*  408 */   private static final TemplateModel[] NO_OUT_ARGS = new TemplateModel[0];
/*      */   
/*      */   private static final int TERSE_MODE_INSTRUCTION_STACK_TRACE_LIMIT = 10;
/*      */   
/*      */   private IdentityHashMap<Object, Object> customStateVariables;
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void visit(TemplateElement element, TemplateDirectiveModel directiveModel, Map args, List bodyParameterNames) throws TemplateException, IOException {
/*  417 */     visit(new TemplateElement[] { element }, directiveModel, args, bodyParameterNames);
/*      */   }
/*      */ 
/*      */   
/*      */   void visit(TemplateElement[] childBuffer, TemplateDirectiveModel directiveModel, Map args, final List bodyParameterNames) throws TemplateException, IOException {
/*      */     TemplateDirectiveBody nested;
/*      */     final TemplateModel[] outArgs;
/*  424 */     if (childBuffer == null) {
/*  425 */       nested = null;
/*      */     } else {
/*  427 */       nested = new NestedElementTemplateDirectiveBody(childBuffer);
/*      */     } 
/*      */     
/*  430 */     if (bodyParameterNames == null || bodyParameterNames.isEmpty()) {
/*  431 */       outArgs = NO_OUT_ARGS;
/*      */     } else {
/*  433 */       outArgs = new TemplateModel[bodyParameterNames.size()];
/*      */     } 
/*  435 */     if (outArgs.length > 0) {
/*  436 */       pushLocalContext(new LocalContext()
/*      */           {
/*      */             public TemplateModel getLocalVariable(String name)
/*      */             {
/*  440 */               int index = bodyParameterNames.indexOf(name);
/*  441 */               return (index != -1) ? outArgs[index] : null;
/*      */             }
/*      */ 
/*      */             
/*      */             public Collection getLocalVariableNames() {
/*  446 */               return bodyParameterNames;
/*      */             }
/*      */           });
/*      */     }
/*      */     try {
/*  451 */       directiveModel.execute(this, args, outArgs, nested);
/*  452 */     } catch (FlowControlException e) {
/*  453 */       throw e;
/*  454 */     } catch (TemplateException e) {
/*  455 */       throw e;
/*  456 */     } catch (IOException e) {
/*      */       
/*  458 */       throw e;
/*  459 */     } catch (Exception e) {
/*  460 */       if (EvalUtil.shouldWrapUncheckedException(e, this)) {
/*  461 */         throw new _MiscTemplateException(e, this, "Directive has thrown an unchecked exception; see the cause exception.");
/*      */       }
/*  463 */       if (e instanceof RuntimeException) {
/*  464 */         throw (RuntimeException)e;
/*      */       }
/*  466 */       throw new UndeclaredThrowableException(e);
/*      */     } finally {
/*      */       
/*  469 */       if (outArgs.length > 0) {
/*  470 */         this.localContextStack.pop();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void visitAndTransform(TemplateElement[] elementBuffer, TemplateTransformModel transform, Map args) throws TemplateException, IOException {
/*      */     try {
/*  490 */       Writer tw = transform.getWriter(this.out, args);
/*  491 */       if (tw == null) tw = EMPTY_BODY_WRITER; 
/*  492 */       TransformControl tc = (tw instanceof TransformControl) ? (TransformControl)tw : null;
/*      */ 
/*      */ 
/*      */       
/*  496 */       Writer prevOut = this.out;
/*  497 */       this.out = tw;
/*      */       try {
/*  499 */         if (tc == null || tc.onStart() != 0) {
/*      */           do {
/*  501 */             visit(elementBuffer);
/*  502 */           } while (tc != null && tc.afterBody() == 0);
/*      */         }
/*  504 */       } catch (Throwable t) {
/*      */         try {
/*  506 */           if (tc != null && (!(t instanceof FlowControlException) || 
/*      */             
/*  508 */             getConfiguration().getIncompatibleImprovements().intValue() < _TemplateAPI.VERSION_INT_2_3_27)) {
/*      */             
/*  510 */             tc.onError(t);
/*      */           } else {
/*  512 */             throw t;
/*      */           } 
/*  514 */         } catch (TemplateException|IOException|Error e) {
/*  515 */           throw e;
/*  516 */         } catch (Throwable e) {
/*  517 */           if (EvalUtil.shouldWrapUncheckedException(e, this)) {
/*  518 */             throw new _MiscTemplateException(e, this, "Transform has thrown an unchecked exception; see the cause exception.");
/*      */           }
/*  520 */           if (e instanceof RuntimeException) {
/*  521 */             throw (RuntimeException)e;
/*      */           }
/*  523 */           throw new UndeclaredThrowableException(e);
/*      */         } 
/*      */       } finally {
/*      */         
/*  527 */         this.out = prevOut;
/*  528 */         if (prevOut != tw) {
/*  529 */           tw.close();
/*      */         }
/*      */       } 
/*  532 */     } catch (TemplateException te) {
/*  533 */       handleTemplateException(te);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void visitAttemptRecover(AttemptBlock attemptBlock, TemplateElement attemptedSection, RecoveryBlock recoverySection) throws TemplateException, IOException {
/*  543 */     Writer prevOut = this.out;
/*  544 */     StringWriter sw = new StringWriter();
/*  545 */     this.out = sw;
/*  546 */     TemplateException thrownException = null;
/*  547 */     boolean lastFIRE = setFastInvalidReferenceExceptions(false);
/*  548 */     boolean lastInAttemptBlock = this.inAttemptBlock;
/*      */     try {
/*  550 */       this.inAttemptBlock = true;
/*  551 */       visit(attemptedSection);
/*  552 */     } catch (TemplateException te) {
/*  553 */       thrownException = te;
/*      */     } finally {
/*  555 */       this.inAttemptBlock = lastInAttemptBlock;
/*  556 */       setFastInvalidReferenceExceptions(lastFIRE);
/*  557 */       this.out = prevOut;
/*      */     } 
/*  559 */     if (thrownException != null) {
/*  560 */       if (ATTEMPT_LOGGER.isDebugEnabled()) {
/*  561 */         ATTEMPT_LOGGER.debug("Error in attempt block " + attemptBlock
/*  562 */             .getStartLocationQuoted(), (Throwable)thrownException);
/*      */       }
/*      */       try {
/*  565 */         this.recoveredErrorStack.add(thrownException);
/*  566 */         visit(recoverySection);
/*      */       } finally {
/*  568 */         this.recoveredErrorStack.remove(this.recoveredErrorStack.size() - 1);
/*      */       } 
/*      */     } else {
/*  571 */       this.out.write(sw.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   String getCurrentRecoveredErrorMessage() throws TemplateException {
/*  576 */     if (this.recoveredErrorStack.isEmpty()) {
/*  577 */       throw new _MiscTemplateException(this, ".error is not available outside of a #recover block");
/*      */     }
/*  579 */     return ((Throwable)this.recoveredErrorStack.get(this.recoveredErrorStack.size() - 1)).getMessage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInAttemptBlock() {
/*  590 */     return this.inAttemptBlock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invokeNestedContent(BodyInstruction.Context bodyCtx) throws TemplateException, IOException {
/*  597 */     Macro.Context invokingMacroContext = getCurrentMacroContext();
/*  598 */     LocalContextStack prevLocalContextStack = this.localContextStack;
/*  599 */     TemplateObject callPlace = invokingMacroContext.callPlace;
/*      */     
/*  601 */     TemplateElement[] nestedContentBuffer = (callPlace instanceof TemplateElement) ? ((TemplateElement)callPlace).getChildBuffer() : null;
/*  602 */     if (nestedContentBuffer != null) {
/*  603 */       this.currentMacroContext = invokingMacroContext.prevMacroContext;
/*  604 */       this.currentNamespace = invokingMacroContext.nestedContentNamespace;
/*      */ 
/*      */       
/*  607 */       boolean parentReplacementOn = isBeforeIcI2322();
/*  608 */       Configurable prevParent = getParent();
/*  609 */       if (parentReplacementOn) {
/*  610 */         setParent((Configurable)this.currentNamespace.getTemplate());
/*      */       } else {
/*  612 */         this.legacyParent = (Configurable)this.currentNamespace.getTemplate();
/*      */       } 
/*      */       
/*  615 */       this.localContextStack = invokingMacroContext.prevLocalContextStack;
/*  616 */       if (invokingMacroContext.nestedContentParameterNames != null) {
/*  617 */         pushLocalContext(bodyCtx);
/*      */       }
/*      */       try {
/*  620 */         visit(nestedContentBuffer);
/*      */       } finally {
/*  622 */         if (invokingMacroContext.nestedContentParameterNames != null) {
/*  623 */           this.localContextStack.pop();
/*      */         }
/*  625 */         this.currentMacroContext = invokingMacroContext;
/*  626 */         this.currentNamespace = getMacroNamespace(invokingMacroContext.getMacro());
/*  627 */         if (parentReplacementOn) {
/*  628 */           setParent(prevParent);
/*      */         } else {
/*  630 */           this.legacyParent = prevParent;
/*      */         } 
/*  632 */         this.localContextStack = prevLocalContextStack;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean visitIteratorBlock(IteratorBlock.IterationContext ictxt) throws TemplateException, IOException {
/*  642 */     pushLocalContext(ictxt);
/*      */     try {
/*  644 */       return ictxt.accept(this);
/*  645 */     } catch (TemplateException te) {
/*  646 */       handleTemplateException(te);
/*  647 */       return true;
/*      */     } finally {
/*  649 */       this.localContextStack.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IteratorBlock.IterationContext findEnclosingIterationContextWithVisibleVariable(String loopVarName) {
/*  660 */     return findEnclosingIterationContext(loopVarName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IteratorBlock.IterationContext findClosestEnclosingIterationContext() {
/*  667 */     return findEnclosingIterationContext((String)null);
/*      */   }
/*      */   
/*      */   private IteratorBlock.IterationContext findEnclosingIterationContext(String visibleLoopVarName) {
/*  671 */     LocalContextStack ctxStack = getLocalContextStack();
/*  672 */     if (ctxStack != null) {
/*  673 */       for (int i = ctxStack.size() - 1; i >= 0; i--) {
/*  674 */         Object ctx = ctxStack.get(i);
/*  675 */         if (ctx instanceof IteratorBlock.IterationContext && (visibleLoopVarName == null || ((IteratorBlock.IterationContext)ctx)
/*      */ 
/*      */           
/*  678 */           .hasVisibleLoopVar(visibleLoopVarName))) {
/*  679 */           return (IteratorBlock.IterationContext)ctx;
/*      */         }
/*      */       } 
/*      */     }
/*  683 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateModel evaluateWithNewLocal(Expression exp, String lambdaArgName, TemplateModel lamdaArgValue) throws TemplateException {
/*  691 */     pushLocalContext(new LocalContextWithNewLocal(lambdaArgName, lamdaArgValue));
/*      */     try {
/*  693 */       return exp.eval(this);
/*      */     } finally {
/*  695 */       this.localContextStack.pop();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static class LocalContextWithNewLocal
/*      */     implements LocalContext
/*      */   {
/*      */     private final String lambdaArgName;
/*      */     private final TemplateModel lambdaArgValue;
/*      */     
/*      */     public LocalContextWithNewLocal(String lambdaArgName, TemplateModel lambdaArgValue) {
/*  707 */       this.lambdaArgName = lambdaArgName;
/*  708 */       this.lambdaArgValue = lambdaArgValue;
/*      */     }
/*      */ 
/*      */     
/*      */     public TemplateModel getLocalVariable(String name) throws TemplateModelException {
/*  713 */       return name.equals(this.lambdaArgName) ? this.lambdaArgValue : null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection getLocalVariableNames() throws TemplateModelException {
/*  718 */       return Collections.singleton(this.lambdaArgName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invokeNodeHandlerFor(TemplateNodeModel node, TemplateSequenceModel namespaces) throws TemplateException, IOException {
/*  727 */     if (this.nodeNamespaces == null) {
/*  728 */       SimpleSequence ss = new SimpleSequence(1, (ObjectWrapper)_TemplateAPI.SAFE_OBJECT_WRAPPER);
/*  729 */       ss.add(this.currentNamespace);
/*  730 */       this.nodeNamespaces = (TemplateSequenceModel)ss;
/*      */     } 
/*  732 */     int prevNodeNamespaceIndex = this.nodeNamespaceIndex;
/*  733 */     String prevNodeName = this.currentNodeName;
/*  734 */     String prevNodeNS = this.currentNodeNS;
/*  735 */     TemplateSequenceModel prevNodeNamespaces = this.nodeNamespaces;
/*  736 */     TemplateNodeModel prevVisitorNode = this.currentVisitorNode;
/*  737 */     this.currentVisitorNode = node;
/*  738 */     if (namespaces != null) {
/*  739 */       this.nodeNamespaces = namespaces;
/*      */     }
/*      */     try {
/*  742 */       TemplateModel macroOrTransform = getNodeProcessor(node);
/*  743 */       if (macroOrTransform instanceof Macro) {
/*  744 */         invokeMacro((Macro)macroOrTransform, (Map<String, ? extends Expression>)null, (List<? extends Expression>)null, (List<String>)null, (TemplateObject)null);
/*  745 */       } else if (macroOrTransform instanceof TemplateTransformModel) {
/*  746 */         visitAndTransform((TemplateElement[])null, (TemplateTransformModel)macroOrTransform, (Map)null);
/*      */       } else {
/*  748 */         String nodeType = node.getNodeType();
/*  749 */         if (nodeType != null) {
/*      */           
/*  751 */           if (nodeType.equals("text") && node instanceof TemplateScalarModel) {
/*  752 */             this.out.write(((TemplateScalarModel)node).getAsString());
/*  753 */           } else if (nodeType.equals("document")) {
/*  754 */             recurse(node, namespaces);
/*      */ 
/*      */           
/*      */           }
/*  758 */           else if (!nodeType.equals("pi") && 
/*  759 */             !nodeType.equals("comment") && 
/*  760 */             !nodeType.equals("document_type")) {
/*  761 */             throw new _MiscTemplateException(this, 
/*  762 */                 noNodeHandlerDefinedDescription(node, node.getNodeNamespace(), nodeType));
/*      */           } 
/*      */         } else {
/*  765 */           throw new _MiscTemplateException(this, 
/*  766 */               noNodeHandlerDefinedDescription(node, node.getNodeNamespace(), "default"));
/*      */         } 
/*      */       } 
/*      */     } finally {
/*  770 */       this.currentVisitorNode = prevVisitorNode;
/*  771 */       this.nodeNamespaceIndex = prevNodeNamespaceIndex;
/*  772 */       this.currentNodeName = prevNodeName;
/*  773 */       this.currentNodeNS = prevNodeNS;
/*  774 */       this.nodeNamespaces = prevNodeNamespaces;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] noNodeHandlerDefinedDescription(TemplateNodeModel node, String ns, String nodeType) throws TemplateModelException {
/*      */     String nsPrefix;
/*  782 */     if (ns != null) {
/*  783 */       if (ns.length() > 0) {
/*  784 */         nsPrefix = " and namespace ";
/*      */       } else {
/*  786 */         nsPrefix = " and no namespace";
/*      */       } 
/*      */     } else {
/*  789 */       nsPrefix = "";
/*  790 */       ns = "";
/*      */     } 
/*  792 */     return new Object[] { "No macro or directive is defined for node named ", new _DelayedJQuote(node
/*  793 */           .getNodeName()), nsPrefix, ns, ", and there is no fallback handler called @", nodeType, " either." };
/*      */   }
/*      */ 
/*      */   
/*      */   void fallback() throws TemplateException, IOException {
/*  798 */     TemplateModel macroOrTransform = getNodeProcessor(this.currentNodeName, this.currentNodeNS, this.nodeNamespaceIndex);
/*  799 */     if (macroOrTransform instanceof Macro) {
/*  800 */       invokeMacro((Macro)macroOrTransform, (Map<String, ? extends Expression>)null, (List<? extends Expression>)null, (List<String>)null, (TemplateObject)null);
/*  801 */     } else if (macroOrTransform instanceof TemplateTransformModel) {
/*  802 */       visitAndTransform((TemplateElement[])null, (TemplateTransformModel)macroOrTransform, (Map)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invokeMacro(Macro macro, Map<String, ? extends Expression> namedArgs, List<? extends Expression> positionalArgs, List<String> bodyParameterNames, TemplateObject callPlace) throws TemplateException, IOException {
/*  812 */     invokeMacroOrFunctionCommonPart(macro, namedArgs, positionalArgs, bodyParameterNames, callPlace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateModel invokeFunction(Environment env, Macro func, List<? extends Expression> argumentExps, TemplateObject callPlace) throws TemplateException {
/*  821 */     env.setLastReturnValue((TemplateModel)null);
/*  822 */     if (!func.isFunction()) {
/*  823 */       throw new _MiscTemplateException(env, "A macro cannot be called in an expression. (Functions can be.)");
/*      */     }
/*  825 */     Writer prevOut = env.getOut();
/*      */     try {
/*  827 */       env.setOut((Writer)NullWriter.INSTANCE);
/*  828 */       env.invokeMacro(func, (Map<String, ? extends Expression>)null, argumentExps, (List<String>)null, callPlace);
/*  829 */     } catch (IOException e) {
/*      */       
/*  831 */       throw new TemplateException("Unexpected exception during function execution", e, env);
/*      */     } finally {
/*  833 */       env.setOut(prevOut);
/*      */     } 
/*  835 */     return env.getLastReturnValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeMacroOrFunctionCommonPart(Macro macroOrFunction, Map<String, ? extends Expression> namedArgs, List<? extends Expression> positionalArgs, List<String> bodyParameterNames, TemplateObject callPlace) throws TemplateException, IOException {
/*      */     boolean elementPushed;
/*  842 */     if (macroOrFunction == Macro.DO_NOTHING_MACRO) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  847 */     if (!this.incompatibleImprovementsGE2328) {
/*      */ 
/*      */       
/*  850 */       pushElement(macroOrFunction);
/*  851 */       elementPushed = true;
/*      */     } else {
/*  853 */       elementPushed = false;
/*      */     } 
/*      */     try {
/*  856 */       macroOrFunction.getClass(); Macro.Context macroCtx = new Macro.Context(macroOrFunction, this, callPlace, bodyParameterNames);
/*      */       
/*  858 */       setMacroContextLocalsFromArguments(macroCtx, macroOrFunction, namedArgs, positionalArgs);
/*      */       
/*  860 */       if (!elementPushed) {
/*  861 */         pushElement(macroOrFunction);
/*  862 */         elementPushed = true;
/*      */       } 
/*      */       
/*  865 */       Macro.Context prevMacroCtx = this.currentMacroContext;
/*  866 */       this.currentMacroContext = macroCtx;
/*      */       
/*  868 */       LocalContextStack prevLocalContextStack = this.localContextStack;
/*  869 */       this.localContextStack = null;
/*      */       
/*  871 */       Namespace prevNamespace = this.currentNamespace;
/*  872 */       this.currentNamespace = getMacroNamespace(macroOrFunction);
/*      */       
/*      */       try {
/*  875 */         macroCtx.checkParamsSetAndApplyDefaults(this);
/*  876 */         visit(macroOrFunction.getChildBuffer());
/*  877 */       } catch (Return return_) {
/*      */       
/*  879 */       } catch (TemplateException te) {
/*  880 */         handleTemplateException(te);
/*      */       } finally {
/*  882 */         this.currentMacroContext = prevMacroCtx;
/*  883 */         this.localContextStack = prevLocalContextStack;
/*  884 */         this.currentNamespace = prevNamespace;
/*      */       } 
/*      */     } finally {
/*  887 */       if (elementPushed) {
/*  888 */         popElement();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setMacroContextLocalsFromArguments(Macro.Context macroCtx, Macro macro, Map<String, ? extends Expression> namedArgs, List<? extends Expression> positionalArgs) throws TemplateException {
/*  901 */     String catchAllParamName = macro.getCatchAll();
/*  902 */     SimpleHash namedCatchAllParamValue = null;
/*  903 */     SimpleSequence positionalCatchAllParamValue = null;
/*  904 */     int nextPositionalArgToAssignIdx = 0;
/*      */ 
/*      */     
/*  907 */     WithArgsState withArgsState = getWithArgState(macro);
/*  908 */     if (withArgsState != null) {
/*  909 */       TemplateHashModelEx byNameWithArgs = withArgsState.byName;
/*  910 */       TemplateSequenceModel byPositionWithArgs = withArgsState.byPosition;
/*      */       
/*  912 */       if (byNameWithArgs != null) {
/*      */         
/*  914 */         TemplateHashModelEx2.KeyValuePairIterator withArgsKVPIter = TemplateModelUtils.getKeyValuePairIterator(byNameWithArgs);
/*  915 */         while (withArgsKVPIter.hasNext()) {
/*  916 */           TemplateHashModelEx2.KeyValuePair withArgKVP = withArgsKVPIter.next();
/*      */ 
/*      */ 
/*      */           
/*  920 */           TemplateModel argNameTM = withArgKVP.getKey();
/*  921 */           if (!(argNameTM instanceof TemplateScalarModel)) {
/*  922 */             throw new _TemplateModelException(new Object[] { "Expected string keys in the \"with args\" hash, but one of the keys was ", new _DelayedAOrAn(new _DelayedFTLTypeDescription(argNameTM)), "." });
/*      */           }
/*      */ 
/*      */           
/*  926 */           String argName = EvalUtil.modelToString((TemplateScalarModel)argNameTM, null, null);
/*      */ 
/*      */           
/*  929 */           TemplateModel argValue = withArgKVP.getValue();
/*      */ 
/*      */ 
/*      */           
/*  933 */           boolean isArgNameDeclared = macro.hasArgNamed(argName);
/*  934 */           if (isArgNameDeclared) {
/*  935 */             macroCtx.setLocalVar(argName, argValue); continue;
/*  936 */           }  if (catchAllParamName != null) {
/*  937 */             if (namedCatchAllParamValue == null) {
/*  938 */               namedCatchAllParamValue = initNamedCatchAllParameter(macroCtx, catchAllParamName);
/*      */             }
/*  940 */             if (!withArgsState.orderLast) {
/*  941 */               namedCatchAllParamValue.put(argName, argValue); continue;
/*      */             } 
/*  943 */             List<NameValuePair> orderLastByNameCatchAll = withArgsState.orderLastByNameCatchAll;
/*  944 */             if (orderLastByNameCatchAll == null) {
/*  945 */               orderLastByNameCatchAll = new ArrayList<>();
/*  946 */               withArgsState.orderLastByNameCatchAll = orderLastByNameCatchAll;
/*      */             } 
/*  948 */             orderLastByNameCatchAll.add(new NameValuePair(argName, argValue));
/*      */             continue;
/*      */           } 
/*  951 */           throw newUndeclaredParamNameException(macro, argName);
/*      */         }
/*      */       
/*  954 */       } else if (byPositionWithArgs != null) {
/*  955 */         if (!withArgsState.orderLast) {
/*  956 */           String[] argNames = macro.getArgumentNamesNoCopy();
/*  957 */           int argsCnt = byPositionWithArgs.size();
/*  958 */           if (argNames.length < argsCnt && catchAllParamName == null) {
/*  959 */             throw newTooManyArgumentsException(macro, argNames, argsCnt);
/*      */           }
/*  961 */           for (int argIdx = 0; argIdx < argsCnt; argIdx++) {
/*  962 */             TemplateModel argValue = byPositionWithArgs.get(argIdx);
/*      */             try {
/*  964 */               if (nextPositionalArgToAssignIdx < argNames.length) {
/*  965 */                 String argName = argNames[nextPositionalArgToAssignIdx++];
/*  966 */                 macroCtx.setLocalVar(argName, argValue);
/*      */               } else {
/*  968 */                 if (positionalCatchAllParamValue == null) {
/*  969 */                   positionalCatchAllParamValue = initPositionalCatchAllParameter(macroCtx, catchAllParamName);
/*      */                 }
/*  971 */                 positionalCatchAllParamValue.add(argValue);
/*      */               } 
/*  973 */             } catch (RuntimeException re) {
/*  974 */               throw new _MiscTemplateException(re, this);
/*      */             } 
/*      */           } 
/*      */         } else {
/*  978 */           if (namedArgs != null && !namedArgs.isEmpty() && byPositionWithArgs.size() != 0)
/*      */           {
/*      */             
/*  981 */             throw new _MiscTemplateException("Call can't pass parameters by name, as there's \"with args last\" in effect that specifies parameters by position.");
/*      */           }
/*      */           
/*  984 */           if (catchAllParamName == null) {
/*      */ 
/*      */             
/*  987 */             int totalPositionalArgCnt = ((positionalArgs != null) ? positionalArgs.size() : 0) + byPositionWithArgs.size();
/*  988 */             if (totalPositionalArgCnt > (macro.getArgumentNamesNoCopy()).length) {
/*  989 */               throw newTooManyArgumentsException(macro, macro.getArgumentNamesNoCopy(), totalPositionalArgCnt);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  996 */     if (namedArgs != null) {
/*  997 */       if (catchAllParamName != null && namedCatchAllParamValue == null && positionalCatchAllParamValue == null)
/*      */       {
/*      */         
/* 1000 */         if (namedArgs.isEmpty() && withArgsState != null && withArgsState.byPosition != null) {
/* 1001 */           positionalCatchAllParamValue = initPositionalCatchAllParameter(macroCtx, catchAllParamName);
/*      */         } else {
/* 1003 */           namedCatchAllParamValue = initNamedCatchAllParameter(macroCtx, catchAllParamName);
/*      */         } 
/*      */       }
/*      */       
/* 1007 */       for (Map.Entry<String, ? extends Expression> argNameAndValExp : namedArgs.entrySet()) {
/* 1008 */         String argName = argNameAndValExp.getKey();
/* 1009 */         boolean isArgNameDeclared = macro.hasArgNamed(argName);
/* 1010 */         if (isArgNameDeclared || namedCatchAllParamValue != null) {
/* 1011 */           Expression argValueExp = argNameAndValExp.getValue();
/* 1012 */           TemplateModel argValue = argValueExp.eval(this);
/* 1013 */           if (isArgNameDeclared) {
/* 1014 */             macroCtx.setLocalVar(argName, argValue); continue;
/*      */           } 
/* 1016 */           namedCatchAllParamValue.put(argName, argValue);
/*      */           continue;
/*      */         } 
/* 1019 */         if (positionalCatchAllParamValue != null) {
/* 1020 */           throw newBothNamedAndPositionalCatchAllParamsException(macro);
/*      */         }
/* 1022 */         throw newUndeclaredParamNameException(macro, argName);
/*      */       }
/*      */     
/*      */     }
/* 1026 */     else if (positionalArgs != null) {
/* 1027 */       if (catchAllParamName != null && positionalCatchAllParamValue == null && namedCatchAllParamValue == null) {
/* 1028 */         if (positionalArgs.isEmpty() && withArgsState != null && withArgsState.byName != null) {
/* 1029 */           namedCatchAllParamValue = initNamedCatchAllParameter(macroCtx, catchAllParamName);
/*      */         } else {
/* 1031 */           positionalCatchAllParamValue = initPositionalCatchAllParameter(macroCtx, catchAllParamName);
/*      */         } 
/*      */       }
/*      */       
/* 1035 */       String[] argNames = macro.getArgumentNamesNoCopy();
/* 1036 */       int argsCnt = positionalArgs.size();
/* 1037 */       int argsWithWithArgsCnt = argsCnt + nextPositionalArgToAssignIdx;
/* 1038 */       if (argNames.length < argsWithWithArgsCnt && positionalCatchAllParamValue == null) {
/* 1039 */         if (namedCatchAllParamValue != null) {
/* 1040 */           throw newBothNamedAndPositionalCatchAllParamsException(macro);
/*      */         }
/* 1042 */         throw newTooManyArgumentsException(macro, argNames, argsWithWithArgsCnt);
/*      */       } 
/*      */       
/* 1045 */       for (int srcPosArgIdx = 0; srcPosArgIdx < argsCnt; srcPosArgIdx++) {
/* 1046 */         TemplateModel argValue; Expression argValueExp = positionalArgs.get(srcPosArgIdx);
/*      */         
/*      */         try {
/* 1049 */           argValue = argValueExp.eval(this);
/* 1050 */         } catch (RuntimeException e) {
/* 1051 */           throw new _MiscTemplateException(e, this);
/*      */         } 
/* 1053 */         if (nextPositionalArgToAssignIdx < argNames.length) {
/* 1054 */           String argName = argNames[nextPositionalArgToAssignIdx++];
/* 1055 */           macroCtx.setLocalVar(argName, argValue);
/*      */         } else {
/* 1057 */           positionalCatchAllParamValue.add(argValue);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1062 */     if (withArgsState != null && withArgsState.orderLast) {
/* 1063 */       if (withArgsState.orderLastByNameCatchAll != null) {
/* 1064 */         for (NameValuePair nameValuePair : withArgsState.orderLastByNameCatchAll) {
/* 1065 */           if (!namedCatchAllParamValue.containsKey(nameValuePair.name)) {
/* 1066 */             namedCatchAllParamValue.put(nameValuePair.name, nameValuePair.value);
/*      */           }
/*      */         } 
/* 1069 */       } else if (withArgsState.byPosition != null) {
/* 1070 */         TemplateSequenceModel byPosition = withArgsState.byPosition;
/* 1071 */         int withArgCnt = byPosition.size();
/* 1072 */         String[] argNames = macro.getArgumentNamesNoCopy();
/* 1073 */         for (int withArgIdx = 0; withArgIdx < withArgCnt; withArgIdx++) {
/* 1074 */           TemplateModel withArgValue = byPosition.get(withArgIdx);
/* 1075 */           if (nextPositionalArgToAssignIdx < argNames.length) {
/* 1076 */             String argName = argNames[nextPositionalArgToAssignIdx++];
/* 1077 */             macroCtx.setLocalVar(argName, withArgValue);
/*      */           } else {
/*      */             
/* 1080 */             positionalCatchAllParamValue.add(withArgValue);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static WithArgsState getWithArgState(Macro macro) {
/* 1088 */     Macro.WithArgs withArgs = macro.getWithArgs();
/* 1089 */     return (withArgs == null) ? null : new WithArgsState(withArgs.getByName(), withArgs.getByPosition(), withArgs
/* 1090 */         .isOrderLast());
/*      */   }
/*      */   
/*      */   private static final class WithArgsState {
/*      */     private final TemplateHashModelEx byName;
/*      */     private final TemplateSequenceModel byPosition;
/*      */     private final boolean orderLast;
/*      */     private List<Environment.NameValuePair> orderLastByNameCatchAll;
/*      */     
/*      */     public WithArgsState(TemplateHashModelEx byName, TemplateSequenceModel byPosition, boolean orderLast) {
/* 1100 */       this.byName = byName;
/* 1101 */       this.byPosition = byPosition;
/* 1102 */       this.orderLast = orderLast;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class NameValuePair {
/*      */     private final String name;
/*      */     private final TemplateModel value;
/*      */     
/*      */     public NameValuePair(String name, TemplateModel value) {
/* 1111 */       this.name = name;
/* 1112 */       this.value = value;
/*      */     }
/*      */   }
/*      */   
/*      */   private _MiscTemplateException newTooManyArgumentsException(Macro macro, String[] argNames, int argsCnt) {
/* 1117 */     return new _MiscTemplateException(this, new Object[] {
/* 1118 */           macro.isFunction() ? "Function " : "Macro ", new _DelayedJQuote(macro.getName()), " only accepts ", new _DelayedToString(argNames.length), " parameters, but got ", new _DelayedToString(argsCnt), "."
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static SimpleSequence initPositionalCatchAllParameter(Macro.Context macroCtx, String catchAllParamName) {
/* 1125 */     SimpleSequence positionalCatchAllParamValue = new SimpleSequence((ObjectWrapper)_TemplateAPI.SAFE_OBJECT_WRAPPER);
/* 1126 */     macroCtx.setLocalVar(catchAllParamName, (TemplateModel)positionalCatchAllParamValue);
/* 1127 */     return positionalCatchAllParamValue;
/*      */   }
/*      */ 
/*      */   
/*      */   private static SimpleHash initNamedCatchAllParameter(Macro.Context macroCtx, String catchAllParamName) {
/* 1132 */     SimpleHash namedCatchAllParamValue = new SimpleHash(new LinkedHashMap<>(), (ObjectWrapper)_TemplateAPI.SAFE_OBJECT_WRAPPER, 0);
/*      */     
/* 1134 */     macroCtx.setLocalVar(catchAllParamName, (TemplateModel)namedCatchAllParamValue);
/* 1135 */     return namedCatchAllParamValue;
/*      */   }
/*      */   
/*      */   private _MiscTemplateException newUndeclaredParamNameException(Macro macro, String argName) {
/* 1139 */     return new _MiscTemplateException(this, new Object[] {
/* 1140 */           macro.isFunction() ? "Function " : "Macro ", new _DelayedJQuote(macro.getName()), " has no parameter with name ", new _DelayedJQuote(argName), ". Valid parameter names are: ", new _DelayedJoinWithComma(macro
/*      */             
/* 1142 */             .getArgumentNamesNoCopy()) });
/*      */   }
/*      */   
/*      */   private _MiscTemplateException newBothNamedAndPositionalCatchAllParamsException(Macro macro) {
/* 1146 */     return new _MiscTemplateException(this, new Object[] {
/* 1147 */           macro.isFunction() ? "Function " : "Macro ", new _DelayedJQuote(macro.getName()), " call can't have both named and positional arguments that has to go into catch-all parameter."
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void visitMacroDef(Macro macro) {
/* 1155 */     this.macroToNamespaceLookup.put(macro.getNamespaceLookupKey(), this.currentNamespace);
/* 1156 */     this.currentNamespace.put(macro.getName(), macro);
/*      */   }
/*      */   
/*      */   Namespace getMacroNamespace(Macro macro) {
/* 1160 */     return this.macroToNamespaceLookup.get(macro.getNamespaceLookupKey());
/*      */   }
/*      */ 
/*      */   
/*      */   void recurse(TemplateNodeModel node, TemplateSequenceModel namespaces) throws TemplateException, IOException {
/* 1165 */     if (node == null) {
/* 1166 */       node = getCurrentVisitorNode();
/* 1167 */       if (node == null) {
/* 1168 */         throw new _TemplateModelException("The target node of recursion is missing or null.");
/*      */       }
/*      */     } 
/*      */     
/* 1172 */     TemplateSequenceModel children = node.getChildNodes();
/* 1173 */     if (children == null) {
/*      */       return;
/*      */     }
/* 1176 */     int size = children.size();
/* 1177 */     for (int i = 0; i < size; i++) {
/* 1178 */       TemplateNodeModel child = (TemplateNodeModel)children.get(i);
/* 1179 */       if (child != null) {
/* 1180 */         invokeNodeHandlerFor(child, namespaces);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   Macro.Context getCurrentMacroContext() {
/* 1186 */     return this.currentMacroContext;
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleTemplateException(TemplateException templateException) throws TemplateException {
/* 1191 */     if (templateException instanceof TemplateModelException && ((TemplateModelException)templateException)
/* 1192 */       .getReplaceWithCause() && templateException
/* 1193 */       .getCause() instanceof TemplateException) {
/* 1194 */       templateException = (TemplateException)templateException.getCause();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1199 */     if (this.lastThrowable == templateException) {
/* 1200 */       throw templateException;
/*      */     }
/* 1202 */     this.lastThrowable = (Throwable)templateException;
/*      */     
/* 1204 */     if (getLogTemplateExceptions() && LOG.isErrorEnabled() && 
/* 1205 */       !isInAttemptBlock()) {
/* 1206 */       LOG.error("Error executing FreeMarker template", (Throwable)templateException);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1212 */       if (templateException instanceof StopException) {
/* 1213 */         throw templateException;
/*      */       }
/*      */ 
/*      */       
/* 1217 */       getTemplateExceptionHandler().handleTemplateException(templateException, this, this.out);
/* 1218 */     } catch (TemplateException e) {
/*      */       
/* 1220 */       if (isInAttemptBlock()) {
/* 1221 */         getAttemptExceptionReporter().report(templateException, this);
/*      */       }
/* 1223 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTemplateExceptionHandler(TemplateExceptionHandler templateExceptionHandler) {
/* 1229 */     super.setTemplateExceptionHandler(templateExceptionHandler);
/* 1230 */     this.lastThrowable = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLocale(Locale locale) {
/* 1235 */     Locale prevLocale = getLocale();
/* 1236 */     super.setLocale(locale);
/* 1237 */     if (!locale.equals(prevLocale)) {
/* 1238 */       this.cachedTemplateNumberFormats = null;
/* 1239 */       if (this.cachedTemplateNumberFormat != null && this.cachedTemplateNumberFormat.isLocaleBound()) {
/* 1240 */         this.cachedTemplateNumberFormat = null;
/*      */       }
/*      */       
/* 1243 */       if (this.cachedTempDateFormatArray != null) {
/* 1244 */         for (int i = 0; i < 16; i++) {
/* 1245 */           TemplateDateFormat f = this.cachedTempDateFormatArray[i];
/* 1246 */           if (f != null && f.isLocaleBound()) {
/* 1247 */             this.cachedTempDateFormatArray[i] = null;
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 1252 */       this.cachedTempDateFormatsByFmtStrArray = null;
/*      */       
/* 1254 */       this.cachedCollator = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimeZone(TimeZone timeZone) {
/* 1260 */     TimeZone prevTimeZone = getTimeZone();
/* 1261 */     super.setTimeZone(timeZone);
/*      */     
/* 1263 */     if (!timeZone.equals(prevTimeZone)) {
/* 1264 */       if (this.cachedTempDateFormatArray != null) {
/* 1265 */         for (int i = 0; i < 8; i++) {
/* 1266 */           TemplateDateFormat f = this.cachedTempDateFormatArray[i];
/* 1267 */           if (f != null && f.isTimeZoneBound()) {
/* 1268 */             this.cachedTempDateFormatArray[i] = null;
/*      */           }
/*      */         } 
/*      */       }
/* 1272 */       if (this.cachedTempDateFormatsByFmtStrArray != null) {
/* 1273 */         for (int i = 0; i < 8; i++) {
/* 1274 */           this.cachedTempDateFormatsByFmtStrArray[i] = null;
/*      */         }
/*      */       }
/*      */       
/* 1278 */       this.cachedSQLDateAndTimeTimeZoneSameAsNormal = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSQLDateAndTimeTimeZone(TimeZone timeZone) {
/* 1284 */     TimeZone prevTimeZone = getSQLDateAndTimeTimeZone();
/* 1285 */     super.setSQLDateAndTimeTimeZone(timeZone);
/*      */     
/* 1287 */     if (!nullSafeEquals(timeZone, prevTimeZone)) {
/* 1288 */       if (this.cachedTempDateFormatArray != null) {
/* 1289 */         for (int i = 8; i < 16; i++) {
/* 1290 */           TemplateDateFormat format = this.cachedTempDateFormatArray[i];
/* 1291 */           if (format != null && format.isTimeZoneBound()) {
/* 1292 */             this.cachedTempDateFormatArray[i] = null;
/*      */           }
/*      */         } 
/*      */       }
/* 1296 */       if (this.cachedTempDateFormatsByFmtStrArray != null) {
/* 1297 */         for (int i = 8; i < 16; i++) {
/* 1298 */           this.cachedTempDateFormatsByFmtStrArray[i] = null;
/*      */         }
/*      */       }
/*      */       
/* 1302 */       this.cachedSQLDateAndTimeTimeZoneSameAsNormal = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean nullSafeEquals(Object o1, Object o2) {
/* 1308 */     if (o1 == o2) return true; 
/* 1309 */     if (o1 == null || o2 == null) return false; 
/* 1310 */     return o1.equals(o2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSQLDateAndTimeTimeZoneSameAsNormal() {
/* 1318 */     if (this.cachedSQLDateAndTimeTimeZoneSameAsNormal == null) {
/* 1319 */       this.cachedSQLDateAndTimeTimeZoneSameAsNormal = Boolean.valueOf((
/* 1320 */           getSQLDateAndTimeTimeZone() == null || 
/* 1321 */           getSQLDateAndTimeTimeZone().equals(getTimeZone())));
/*      */     }
/* 1323 */     return this.cachedSQLDateAndTimeTimeZoneSameAsNormal.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setURLEscapingCharset(String urlEscapingCharset) {
/* 1328 */     this.cachedURLEscapingCharsetSet = false;
/* 1329 */     super.setURLEscapingCharset(urlEscapingCharset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOutputEncoding(String outputEncoding) {
/* 1339 */     this.cachedURLEscapingCharsetSet = false;
/* 1340 */     super.setOutputEncoding(outputEncoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getEffectiveURLEscapingCharset() {
/* 1348 */     if (!this.cachedURLEscapingCharsetSet) {
/* 1349 */       this.cachedURLEscapingCharset = getURLEscapingCharset();
/* 1350 */       if (this.cachedURLEscapingCharset == null) {
/* 1351 */         this.cachedURLEscapingCharset = getOutputEncoding();
/*      */       }
/* 1353 */       this.cachedURLEscapingCharsetSet = true;
/*      */     } 
/* 1355 */     return this.cachedURLEscapingCharset;
/*      */   }
/*      */   
/*      */   Collator getCollator() {
/* 1359 */     if (this.cachedCollator == null) {
/* 1360 */       this.cachedCollator = Collator.getInstance(getLocale());
/*      */     }
/* 1362 */     return this.cachedCollator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyEqualsOperator(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1372 */     return EvalUtil.compare(leftValue, 1, rightValue, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyEqualsOperatorLenient(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1384 */     return EvalUtil.compareLenient(leftValue, 1, rightValue, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyLessThanOperator(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1394 */     return EvalUtil.compare(leftValue, 3, rightValue, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyLessThanOrEqualsOperator(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1404 */     return EvalUtil.compare(leftValue, 5, rightValue, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyGreaterThanOperator(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1414 */     return EvalUtil.compare(leftValue, 4, rightValue, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean applyWithGreaterThanOrEqualsOperator(TemplateModel leftValue, TemplateModel rightValue) throws TemplateException {
/* 1424 */     return EvalUtil.compare(leftValue, 6, rightValue, this);
/*      */   }
/*      */   
/*      */   public void setOut(Writer out) {
/* 1428 */     this.out = out;
/*      */   }
/*      */   
/*      */   public Writer getOut() {
/* 1432 */     return this.out;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNumberFormat(String formatName) {
/* 1437 */     super.setNumberFormat(formatName);
/* 1438 */     this.cachedTemplateNumberFormat = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatNumberToPlainText(TemplateNumberModel number, Expression exp, boolean useTempModelExc) throws TemplateException {
/* 1449 */     return formatNumberToPlainText(number, getTemplateNumberFormat(exp, useTempModelExc), exp, useTempModelExc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatNumberToPlainText(TemplateNumberModel number, TemplateNumberFormat format, Expression exp, boolean useTempModelExc) throws TemplateException {
/*      */     try {
/* 1463 */       return EvalUtil.assertFormatResultNotNull(format.formatToPlainText(number));
/* 1464 */     } catch (TemplateValueFormatException e) {
/* 1465 */       throw _MessageUtil.newCantFormatNumberException(format, exp, e, useTempModelExc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatNumberToPlainText(Number number, BackwardCompatibleTemplateNumberFormat format, Expression exp) throws TemplateModelException, _MiscTemplateException {
/*      */     try {
/* 1478 */       return format.format(number);
/* 1479 */     } catch (UnformattableValueException e) {
/* 1480 */       throw new _MiscTemplateException(exp, e, this, new Object[] { "Failed to format number with ", new _DelayedJQuote(format
/* 1481 */               .getDescription()), ": ", e
/* 1482 */             .getMessage() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateNumberFormat getTemplateNumberFormat() throws TemplateValueFormatException {
/* 1498 */     TemplateNumberFormat format = this.cachedTemplateNumberFormat;
/* 1499 */     if (format == null) {
/* 1500 */       format = getTemplateNumberFormat(getNumberFormat(), false);
/* 1501 */       this.cachedTemplateNumberFormat = format;
/*      */     } 
/* 1503 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateNumberFormat getTemplateNumberFormat(String formatString) throws TemplateValueFormatException {
/* 1519 */     return getTemplateNumberFormat(formatString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateNumberFormat getTemplateNumberFormat(String formatString, Locale locale) throws TemplateValueFormatException {
/* 1542 */     if (locale.equals(getLocale())) {
/* 1543 */       getTemplateNumberFormat(formatString);
/*      */     }
/*      */     
/* 1546 */     return getTemplateNumberFormatWithoutCache(formatString, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateNumberFormat getTemplateNumberFormat(Expression exp, boolean useTempModelExc) throws TemplateException {
/*      */     TemplateNumberFormat format;
/*      */     try {
/* 1555 */       format = getTemplateNumberFormat();
/* 1556 */     } catch (TemplateValueFormatException e) {
/*      */ 
/*      */ 
/*      */       
/* 1560 */       _ErrorDescriptionBuilder desc = (new _ErrorDescriptionBuilder(new Object[] { "Failed to get number format object for the current number format string, ", new _DelayedJQuote(getNumberFormat()), ": ", e.getMessage() })).blame(exp);
/* 1561 */       throw useTempModelExc ? new _TemplateModelException(e, this, desc) : new _MiscTemplateException(e, this, desc);
/*      */     } 
/*      */     
/* 1564 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateNumberFormat getTemplateNumberFormat(String formatString, Expression exp, boolean useTempModelExc) throws TemplateException {
/*      */     TemplateNumberFormat format;
/*      */     try {
/* 1577 */       format = getTemplateNumberFormat(formatString);
/* 1578 */     } catch (TemplateValueFormatException e) {
/*      */ 
/*      */ 
/*      */       
/* 1582 */       _ErrorDescriptionBuilder desc = (new _ErrorDescriptionBuilder(new Object[] { "Failed to get number format object for the ", new _DelayedJQuote(formatString), " number format string: ", e.getMessage() })).blame(exp);
/* 1583 */       throw useTempModelExc ? new _TemplateModelException(e, this, desc) : new _MiscTemplateException(e, this, desc);
/*      */     } 
/*      */     
/* 1586 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TemplateNumberFormat getTemplateNumberFormat(String formatString, boolean cacheResult) throws TemplateValueFormatException {
/* 1600 */     if (this.cachedTemplateNumberFormats == null) {
/* 1601 */       if (cacheResult) {
/* 1602 */         this.cachedTemplateNumberFormats = new HashMap<>();
/*      */       }
/*      */     } else {
/* 1605 */       TemplateNumberFormat templateNumberFormat = this.cachedTemplateNumberFormats.get(formatString);
/* 1606 */       if (templateNumberFormat != null) {
/* 1607 */         return templateNumberFormat;
/*      */       }
/*      */     } 
/*      */     
/* 1611 */     TemplateNumberFormat format = getTemplateNumberFormatWithoutCache(formatString, getLocale());
/*      */     
/* 1613 */     if (cacheResult) {
/* 1614 */       this.cachedTemplateNumberFormats.put(formatString, format);
/*      */     }
/* 1616 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TemplateNumberFormat getTemplateNumberFormatWithoutCache(String formatString, Locale locale) throws TemplateValueFormatException {
/* 1630 */     int formatStringLen = formatString.length();
/* 1631 */     if (formatStringLen > 1 && formatString
/* 1632 */       .charAt(0) == '@' && (
/* 1633 */       isIcI2324OrLater() || hasCustomFormats()) && 
/* 1634 */       Character.isLetter(formatString.charAt(1))) {
/*      */       int endIdx;
/*      */ 
/*      */ 
/*      */       
/* 1639 */       for (endIdx = 1; endIdx < formatStringLen; endIdx++) {
/* 1640 */         char c = formatString.charAt(endIdx);
/* 1641 */         if (c == ' ' || c == '_') {
/*      */           break;
/*      */         }
/*      */       } 
/* 1645 */       String name = formatString.substring(1, endIdx);
/* 1646 */       String params = (endIdx < formatStringLen) ? formatString.substring(endIdx + 1) : "";
/*      */ 
/*      */       
/* 1649 */       TemplateNumberFormatFactory formatFactory = getCustomNumberFormat(name);
/* 1650 */       if (formatFactory == null) {
/* 1651 */         throw new UndefinedCustomFormatException("No custom number format was defined with name " + 
/* 1652 */             StringUtil.jQuote(name));
/*      */       }
/*      */       
/* 1655 */       return formatFactory.get(params, locale, this);
/*      */     } 
/* 1657 */     return JavaTemplateNumberFormatFactory.INSTANCE.get(formatString, locale, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NumberFormat getCNumberFormat() {
/* 1668 */     if (this.cNumberFormat == null) {
/* 1669 */       this.cNumberFormat = (DecimalFormat)C_NUMBER_FORMAT.clone();
/*      */     }
/* 1671 */     return this.cNumberFormat;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimeFormat(String timeFormat) {
/* 1676 */     String prevTimeFormat = getTimeFormat();
/* 1677 */     super.setTimeFormat(timeFormat);
/* 1678 */     if (!timeFormat.equals(prevTimeFormat) && 
/* 1679 */       this.cachedTempDateFormatArray != null) {
/* 1680 */       for (int i = 0; i < 16; i += 4) {
/* 1681 */         this.cachedTempDateFormatArray[i + 1] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateFormat(String dateFormat) {
/* 1689 */     String prevDateFormat = getDateFormat();
/* 1690 */     super.setDateFormat(dateFormat);
/* 1691 */     if (!dateFormat.equals(prevDateFormat) && 
/* 1692 */       this.cachedTempDateFormatArray != null) {
/* 1693 */       for (int i = 0; i < 16; i += 4) {
/* 1694 */         this.cachedTempDateFormatArray[i + 2] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateTimeFormat(String dateTimeFormat) {
/* 1702 */     String prevDateTimeFormat = getDateTimeFormat();
/* 1703 */     super.setDateTimeFormat(dateTimeFormat);
/* 1704 */     if (!dateTimeFormat.equals(prevDateTimeFormat) && 
/* 1705 */       this.cachedTempDateFormatArray != null) {
/* 1706 */       for (int i = 0; i < 16; i += 4) {
/* 1707 */         this.cachedTempDateFormatArray[i + 3] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public Configuration getConfiguration() {
/* 1714 */     return this.configuration;
/*      */   }
/*      */   
/*      */   TemplateModel getLastReturnValue() {
/* 1718 */     return this.lastReturnValue;
/*      */   }
/*      */   
/*      */   void setLastReturnValue(TemplateModel lastReturnValue) {
/* 1722 */     this.lastReturnValue = lastReturnValue;
/*      */   }
/*      */   
/*      */   void clearLastReturnValue() {
/* 1726 */     this.lastReturnValue = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatDateToPlainText(TemplateDateModel tdm, Expression tdmSourceExpr, boolean useTempModelExc) throws TemplateException {
/* 1735 */     TemplateDateFormat format = getTemplateDateFormat(tdm, tdmSourceExpr, useTempModelExc);
/*      */     
/*      */     try {
/* 1738 */       return EvalUtil.assertFormatResultNotNull(format.formatToPlainText(tdm));
/* 1739 */     } catch (TemplateValueFormatException e) {
/* 1740 */       throw _MessageUtil.newCantFormatDateException(format, tdmSourceExpr, e, useTempModelExc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatDateToPlainText(TemplateDateModel tdm, String formatString, Expression blamedDateSourceExp, Expression blamedFormatterExp, boolean useTempModelExc) throws TemplateException {
/* 1753 */     Date date = EvalUtil.modelToDate(tdm, blamedDateSourceExp);
/*      */     
/* 1755 */     TemplateDateFormat format = getTemplateDateFormat(formatString, tdm
/* 1756 */         .getDateType(), (Class)date.getClass(), blamedDateSourceExp, blamedFormatterExp, useTempModelExc);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1761 */       return EvalUtil.assertFormatResultNotNull(format.formatToPlainText(tdm));
/* 1762 */     } catch (TemplateValueFormatException e) {
/* 1763 */       throw _MessageUtil.newCantFormatDateException(format, blamedDateSourceExp, e, useTempModelExc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateDateFormat getTemplateDateFormat(int dateType, Class<? extends Date> dateClass) throws TemplateValueFormatException {
/* 1781 */     boolean isSQLDateOrTime = isSQLDateOrTimeClass(dateClass);
/* 1782 */     return getTemplateDateFormat(dateType, shouldUseSQLDTTimeZone(isSQLDateOrTime), isSQLDateOrTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, Class<? extends Date> dateClass) throws TemplateValueFormatException {
/* 1804 */     boolean isSQLDateOrTime = isSQLDateOrTimeClass(dateClass);
/* 1805 */     return getTemplateDateFormat(formatString, dateType, 
/*      */         
/* 1807 */         shouldUseSQLDTTimeZone(isSQLDateOrTime), isSQLDateOrTime, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, Class<? extends Date> dateClass, Locale locale) throws TemplateValueFormatException {
/* 1832 */     boolean isSQLDateOrTime = isSQLDateOrTimeClass(dateClass);
/* 1833 */     boolean useSQLDTTZ = shouldUseSQLDTTimeZone(isSQLDateOrTime);
/* 1834 */     return getTemplateDateFormat(formatString, dateType, locale, useSQLDTTZ ? 
/*      */         
/* 1836 */         getSQLDateAndTimeTimeZone() : getTimeZone(), isSQLDateOrTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, Class<? extends Date> dateClass, Locale locale, TimeZone timeZone, TimeZone sqlDateAndTimeTimeZone) throws TemplateValueFormatException {
/* 1864 */     boolean isSQLDateOrTime = isSQLDateOrTimeClass(dateClass);
/* 1865 */     boolean useSQLDTTZ = shouldUseSQLDTTimeZone(isSQLDateOrTime);
/* 1866 */     return getTemplateDateFormat(formatString, dateType, locale, useSQLDTTZ ? sqlDateAndTimeTimeZone : timeZone, isSQLDateOrTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, Locale locale, TimeZone timeZone, boolean zonelessInput) throws TemplateValueFormatException {
/* 1909 */     Locale currentLocale = getLocale();
/* 1910 */     if (locale.equals(currentLocale)) {
/*      */       int equalCurrentTZ;
/* 1912 */       TimeZone currentTimeZone = getTimeZone();
/* 1913 */       if (timeZone.equals(currentTimeZone)) {
/* 1914 */         equalCurrentTZ = 1;
/*      */       } else {
/* 1916 */         TimeZone currentSQLDTTimeZone = getSQLDateAndTimeTimeZone();
/* 1917 */         if (timeZone.equals(currentSQLDTTimeZone)) {
/* 1918 */           equalCurrentTZ = 2;
/*      */         } else {
/* 1920 */           equalCurrentTZ = 0;
/*      */         } 
/*      */       } 
/* 1923 */       if (equalCurrentTZ != 0) {
/* 1924 */         return getTemplateDateFormat(formatString, dateType, (equalCurrentTZ == 2), zonelessInput, true);
/*      */       }
/*      */     } 
/*      */     
/* 1928 */     return getTemplateDateFormatWithoutCache(formatString, dateType, locale, timeZone, zonelessInput);
/*      */   }
/*      */ 
/*      */   
/*      */   TemplateDateFormat getTemplateDateFormat(TemplateDateModel tdm, Expression tdmSourceExpr, boolean useTempModelExc) throws TemplateModelException, TemplateException {
/* 1933 */     Date date = EvalUtil.modelToDate(tdm, tdmSourceExpr);
/*      */     
/* 1935 */     TemplateDateFormat format = getTemplateDateFormat(tdm
/* 1936 */         .getDateType(), (Class)date.getClass(), tdmSourceExpr, useTempModelExc);
/*      */     
/* 1938 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateDateFormat getTemplateDateFormat(int dateType, Class<? extends Date> dateClass, Expression blamedDateSourceExp, boolean useTempModelExc) throws TemplateException {
/*      */     try {
/* 1948 */       return getTemplateDateFormat(dateType, dateClass);
/* 1949 */     } catch (UnknownDateTypeFormattingUnsupportedException e) {
/* 1950 */       throw _MessageUtil.newCantFormatUnknownTypeDateException(blamedDateSourceExp, e);
/* 1951 */     } catch (TemplateValueFormatException e) {
/*      */       String settingName, settingValue;
/*      */       
/* 1954 */       switch (dateType) {
/*      */         case 1:
/* 1956 */           settingName = "time_format";
/* 1957 */           settingValue = getTimeFormat();
/*      */           break;
/*      */         case 2:
/* 1960 */           settingName = "date_format";
/* 1961 */           settingValue = getDateFormat();
/*      */           break;
/*      */         case 3:
/* 1964 */           settingName = "datetime_format";
/* 1965 */           settingValue = getDateTimeFormat();
/*      */           break;
/*      */         default:
/* 1968 */           settingName = "???";
/* 1969 */           settingValue = "???";
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1976 */       _ErrorDescriptionBuilder desc = new _ErrorDescriptionBuilder(new Object[] { "The value of the \"", settingName, "\" FreeMarker configuration setting is a malformed date/time/datetime format string: ", new _DelayedJQuote(settingValue), ". Reason given: ", e.getMessage() });
/* 1977 */       throw useTempModelExc ? new _TemplateModelException(e, new Object[] { desc }) : new _MiscTemplateException(e, new Object[] { desc });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, Class<? extends Date> dateClass, Expression blamedDateSourceExp, Expression blamedFormatterExp, boolean useTempModelExc) throws TemplateException {
/*      */     try {
/* 1991 */       return getTemplateDateFormat(formatString, dateType, dateClass);
/* 1992 */     } catch (UnknownDateTypeFormattingUnsupportedException e) {
/* 1993 */       throw _MessageUtil.newCantFormatUnknownTypeDateException(blamedDateSourceExp, e);
/* 1994 */     } catch (TemplateValueFormatException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1999 */       _ErrorDescriptionBuilder desc = (new _ErrorDescriptionBuilder(new Object[] { "Can't create date/time/datetime format based on format string ", new _DelayedJQuote(formatString), ". Reason given: ", e.getMessage() })).blame(blamedFormatterExp);
/* 2000 */       throw useTempModelExc ? new _TemplateModelException(e, new Object[] { desc }) : new _MiscTemplateException(e, new Object[] { desc });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TemplateDateFormat getTemplateDateFormat(int dateType, boolean useSQLDTTZ, boolean zonelessInput) throws TemplateValueFormatException {
/* 2011 */     if (dateType == 0) {
/* 2012 */       throw new UnknownDateTypeFormattingUnsupportedException();
/*      */     }
/* 2014 */     int cacheIdx = getTemplateDateFormatCacheArrayIndex(dateType, zonelessInput, useSQLDTTZ);
/* 2015 */     TemplateDateFormat[] cachedTemplateDateFormats = this.cachedTempDateFormatArray;
/* 2016 */     if (cachedTemplateDateFormats == null) {
/* 2017 */       cachedTemplateDateFormats = new TemplateDateFormat[16];
/* 2018 */       this.cachedTempDateFormatArray = cachedTemplateDateFormats;
/*      */     } 
/* 2020 */     TemplateDateFormat format = cachedTemplateDateFormats[cacheIdx];
/* 2021 */     if (format == null) {
/*      */       String formatString;
/* 2023 */       switch (dateType) {
/*      */         case 1:
/* 2025 */           formatString = getTimeFormat();
/*      */           break;
/*      */         case 2:
/* 2028 */           formatString = getDateFormat();
/*      */           break;
/*      */         case 3:
/* 2031 */           formatString = getDateTimeFormat();
/*      */           break;
/*      */         default:
/* 2034 */           throw new IllegalArgumentException("Invalid date type enum: " + Integer.valueOf(dateType));
/*      */       } 
/*      */       
/* 2037 */       format = getTemplateDateFormat(formatString, dateType, useSQLDTTZ, zonelessInput, false);
/*      */       
/* 2039 */       cachedTemplateDateFormats[cacheIdx] = format;
/*      */     } 
/* 2041 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TemplateDateFormat getTemplateDateFormat(String formatString, int dateType, boolean useSQLDTTimeZone, boolean zonelessInput, boolean cacheResult) throws TemplateValueFormatException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield cachedTempDateFormatsByFmtStrArray : [Ljava/util/HashMap;
/*      */     //   4: astore #7
/*      */     //   6: aload #7
/*      */     //   8: ifnonnull -> 38
/*      */     //   11: iload #5
/*      */     //   13: ifeq -> 32
/*      */     //   16: bipush #16
/*      */     //   18: anewarray java/util/HashMap
/*      */     //   21: astore #7
/*      */     //   23: aload_0
/*      */     //   24: aload #7
/*      */     //   26: putfield cachedTempDateFormatsByFmtStrArray : [Ljava/util/HashMap;
/*      */     //   29: goto -> 38
/*      */     //   32: aconst_null
/*      */     //   33: astore #6
/*      */     //   35: goto -> 107
/*      */     //   38: aload_0
/*      */     //   39: iload_2
/*      */     //   40: iload #4
/*      */     //   42: iload_3
/*      */     //   43: invokespecial getTemplateDateFormatCacheArrayIndex : (IZZ)I
/*      */     //   46: istore #9
/*      */     //   48: aload #7
/*      */     //   50: iload #9
/*      */     //   52: aaload
/*      */     //   53: astore #6
/*      */     //   55: aload #6
/*      */     //   57: ifnonnull -> 88
/*      */     //   60: iload #5
/*      */     //   62: ifeq -> 107
/*      */     //   65: new java/util/HashMap
/*      */     //   68: dup
/*      */     //   69: iconst_4
/*      */     //   70: invokespecial <init> : (I)V
/*      */     //   73: astore #6
/*      */     //   75: aload #7
/*      */     //   77: iload #9
/*      */     //   79: aload #6
/*      */     //   81: aastore
/*      */     //   82: aconst_null
/*      */     //   83: astore #8
/*      */     //   85: goto -> 99
/*      */     //   88: aload #6
/*      */     //   90: aload_1
/*      */     //   91: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   94: checkcast freemarker/core/TemplateDateFormat
/*      */     //   97: astore #8
/*      */     //   99: aload #8
/*      */     //   101: ifnull -> 107
/*      */     //   104: aload #8
/*      */     //   106: areturn
/*      */     //   107: aload_0
/*      */     //   108: aload_1
/*      */     //   109: iload_2
/*      */     //   110: aload_0
/*      */     //   111: invokevirtual getLocale : ()Ljava/util/Locale;
/*      */     //   114: iload_3
/*      */     //   115: ifeq -> 125
/*      */     //   118: aload_0
/*      */     //   119: invokevirtual getSQLDateAndTimeTimeZone : ()Ljava/util/TimeZone;
/*      */     //   122: goto -> 129
/*      */     //   125: aload_0
/*      */     //   126: invokevirtual getTimeZone : ()Ljava/util/TimeZone;
/*      */     //   129: iload #4
/*      */     //   131: invokespecial getTemplateDateFormatWithoutCache : (Ljava/lang/String;ILjava/util/Locale;Ljava/util/TimeZone;Z)Lfreemarker/core/TemplateDateFormat;
/*      */     //   134: astore #7
/*      */     //   136: iload #5
/*      */     //   138: ifeq -> 150
/*      */     //   141: aload #6
/*      */     //   143: aload_1
/*      */     //   144: aload #7
/*      */     //   146: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   149: pop
/*      */     //   150: aload #7
/*      */     //   152: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2059	-> 0
/*      */     //   #2060	-> 6
/*      */     //   #2061	-> 11
/*      */     //   #2062	-> 16
/*      */     //   #2063	-> 23
/*      */     //   #2065	-> 32
/*      */     //   #2066	-> 35
/*      */     //   #2072	-> 38
/*      */     //   #2073	-> 48
/*      */     //   #2074	-> 55
/*      */     //   #2075	-> 60
/*      */     //   #2076	-> 65
/*      */     //   #2077	-> 75
/*      */     //   #2078	-> 82
/*      */     //   #2083	-> 88
/*      */     //   #2087	-> 99
/*      */     //   #2088	-> 104
/*      */     //   #2093	-> 107
/*      */     //   #2095	-> 111
/*      */     //   #2093	-> 131
/*      */     //   #2097	-> 136
/*      */     //   #2099	-> 141
/*      */     //   #2101	-> 150
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   35	3	6	cachedFormatsByFormatString	Ljava/util/HashMap;
/*      */     //   85	3	8	format	Lfreemarker/core/TemplateDateFormat;
/*      */     //   48	51	9	cacheArrIdx	I
/*      */     //   6	101	7	cachedTempDateFormatsByFmtStrArray	[Ljava/util/HashMap;
/*      */     //   99	8	8	format	Lfreemarker/core/TemplateDateFormat;
/*      */     //   0	153	0	this	Lfreemarker/core/Environment;
/*      */     //   0	153	1	formatString	Ljava/lang/String;
/*      */     //   0	153	2	dateType	I
/*      */     //   0	153	3	useSQLDTTimeZone	Z
/*      */     //   0	153	4	zonelessInput	Z
/*      */     //   0	153	5	cacheResult	Z
/*      */     //   55	98	6	cachedFormatsByFormatString	Ljava/util/HashMap;
/*      */     //   136	17	7	format	Lfreemarker/core/TemplateDateFormat;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   35	3	6	cachedFormatsByFormatString	Ljava/util/HashMap<Ljava/lang/String;Lfreemarker/core/TemplateDateFormat;>;
/*      */     //   6	101	7	cachedTempDateFormatsByFmtStrArray	[Ljava/util/HashMap<Ljava/lang/String;Lfreemarker/core/TemplateDateFormat;>;
/*      */     //   55	98	6	cachedFormatsByFormatString	Ljava/util/HashMap<Ljava/lang/String;Lfreemarker/core/TemplateDateFormat;>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TemplateDateFormat getTemplateDateFormatWithoutCache(String formatString, int dateType, Locale locale, TimeZone timeZone, boolean zonelessInput) throws TemplateValueFormatException {
/*      */     String formatParams;
/*      */     TemplateDateFormatFactory formatFactory;
/* 2119 */     int formatStringLen = formatString.length();
/*      */ 
/*      */ 
/*      */     
/* 2123 */     char firstChar = (formatStringLen != 0) ? formatString.charAt(0) : Character.MIN_VALUE;
/*      */ 
/*      */     
/* 2126 */     if (firstChar == 'x' && formatStringLen > 1 && formatString
/*      */       
/* 2128 */       .charAt(1) == 's') {
/* 2129 */       formatFactory = XSTemplateDateFormatFactory.INSTANCE;
/* 2130 */       formatParams = formatString;
/* 2131 */     } else if (firstChar == 'i' && formatStringLen > 2 && formatString
/*      */       
/* 2133 */       .charAt(1) == 's' && formatString
/* 2134 */       .charAt(2) == 'o') {
/* 2135 */       formatFactory = ISOTemplateDateFormatFactory.INSTANCE;
/* 2136 */       formatParams = formatString;
/* 2137 */     } else if (firstChar == '@' && formatStringLen > 1 && (
/*      */       
/* 2139 */       isIcI2324OrLater() || hasCustomFormats()) && 
/* 2140 */       Character.isLetter(formatString.charAt(1))) {
/*      */       int endIdx;
/*      */ 
/*      */       
/* 2144 */       for (endIdx = 1; endIdx < formatStringLen; endIdx++) {
/* 2145 */         char c = formatString.charAt(endIdx);
/* 2146 */         if (c == ' ' || c == '_') {
/*      */           break;
/*      */         }
/*      */       } 
/* 2150 */       String name = formatString.substring(1, endIdx);
/* 2151 */       formatParams = (endIdx < formatStringLen) ? formatString.substring(endIdx + 1) : "";
/*      */ 
/*      */       
/* 2154 */       formatFactory = getCustomDateFormat(name);
/* 2155 */       if (formatFactory == null) {
/* 2156 */         throw new UndefinedCustomFormatException("No custom date format was defined with name " + 
/* 2157 */             StringUtil.jQuote(name));
/*      */       }
/*      */     } else {
/* 2160 */       formatParams = formatString;
/* 2161 */       formatFactory = JavaTemplateDateFormatFactory.INSTANCE;
/*      */     } 
/*      */     
/* 2164 */     return formatFactory.get(formatParams, dateType, locale, timeZone, zonelessInput, this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean shouldUseSQLDTTZ(Class<Date> dateClass) {
/* 2170 */     return (dateClass != Date.class && 
/* 2171 */       !isSQLDateAndTimeTimeZoneSameAsNormal() && 
/* 2172 */       isSQLDateOrTimeClass(dateClass));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean shouldUseSQLDTTimeZone(boolean sqlDateOrTime) {
/* 2177 */     return (sqlDateOrTime && !isSQLDateAndTimeTimeZoneSameAsNormal());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isSQLDateOrTimeClass(Class<Date> dateClass) {
/* 2185 */     return (dateClass != Date.class && (dateClass == Date.class || dateClass == Time.class || (dateClass != Timestamp.class && (Date.class
/*      */ 
/*      */       
/* 2188 */       .isAssignableFrom(dateClass) || Time.class
/* 2189 */       .isAssignableFrom(dateClass)))));
/*      */   }
/*      */   
/*      */   private int getTemplateDateFormatCacheArrayIndex(int dateType, boolean zonelessInput, boolean sqlDTTZ) {
/* 2193 */     return dateType + (zonelessInput ? 4 : 0) + (sqlDTTZ ? 8 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DateUtil.DateToISO8601CalendarFactory getISOBuiltInCalendarFactory() {
/* 2206 */     if (this.isoBuiltInCalendarFactory == null) {
/* 2207 */       this.isoBuiltInCalendarFactory = (DateUtil.DateToISO8601CalendarFactory)new DateUtil.TrivialDateToISO8601CalendarFactory();
/*      */     }
/* 2209 */     return this.isoBuiltInCalendarFactory;
/*      */   }
/*      */   
/*      */   TemplateTransformModel getTransform(Expression exp) throws TemplateException {
/* 2213 */     TemplateTransformModel ttm = null;
/* 2214 */     TemplateModel tm = exp.eval(this);
/* 2215 */     if (tm instanceof TemplateTransformModel) {
/* 2216 */       ttm = (TemplateTransformModel)tm;
/* 2217 */     } else if (exp instanceof Identifier) {
/* 2218 */       tm = this.configuration.getSharedVariable(exp.toString());
/* 2219 */       if (tm instanceof TemplateTransformModel) {
/* 2220 */         ttm = (TemplateTransformModel)tm;
/*      */       }
/*      */     } 
/* 2223 */     return ttm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateModel getLocalVariable(String name) throws TemplateModelException {
/* 2232 */     TemplateModel val = getNullableLocalVariable(name);
/* 2233 */     return (val != TemplateNullModel.INSTANCE) ? val : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final TemplateModel getNullableLocalVariable(String name) throws TemplateModelException {
/* 2243 */     if (this.localContextStack != null) {
/* 2244 */       for (int i = this.localContextStack.size() - 1; i >= 0; i--) {
/* 2245 */         LocalContext lc = this.localContextStack.get(i);
/* 2246 */         TemplateModel tm = lc.getLocalVariable(name);
/* 2247 */         if (tm != null) {
/* 2248 */           return tm;
/*      */         }
/*      */       } 
/*      */     }
/* 2252 */     return (this.currentMacroContext == null) ? null : this.currentMacroContext.getLocalVariable(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateModel getVariable(String name) throws TemplateModelException {
/* 2273 */     TemplateModel result = getNullableLocalVariable(name);
/* 2274 */     if (result != null) {
/* 2275 */       return (result != TemplateNullModel.INSTANCE) ? result : null;
/*      */     }
/*      */     
/* 2278 */     result = this.currentNamespace.get(name);
/* 2279 */     if (result != null) {
/* 2280 */       return result;
/*      */     }
/*      */     
/* 2283 */     return getGlobalVariable(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateModel getGlobalVariable(String name) throws TemplateModelException {
/* 2293 */     TemplateModel result = this.globalNamespace.get(name);
/* 2294 */     if (result != null) {
/* 2295 */       return result;
/*      */     }
/*      */     
/* 2298 */     return getDataModelOrSharedVariable(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateModel getDataModelOrSharedVariable(String name) throws TemplateModelException {
/* 2308 */     TemplateModel dataModelVal = this.rootDataModel.get(name);
/* 2309 */     if (dataModelVal != null) {
/* 2310 */       return dataModelVal;
/*      */     }
/*      */     
/* 2313 */     return this.configuration.getSharedVariable(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGlobalVariable(String name, TemplateModel value) {
/* 2330 */     this.globalNamespace.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVariable(String name, TemplateModel value) {
/* 2344 */     this.currentNamespace.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocalVariable(String name, TemplateModel value) {
/* 2363 */     if (this.currentMacroContext == null) {
/* 2364 */       throw new IllegalStateException("Not executing macro body");
/*      */     }
/* 2366 */     this.currentMacroContext.setLocalVar(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set getKnownVariableNames() throws TemplateModelException {
/* 2380 */     Set<String> set = this.configuration.getSharedVariableNames();
/*      */ 
/*      */     
/* 2383 */     if (this.rootDataModel instanceof TemplateHashModelEx) {
/* 2384 */       TemplateModelIterator rootNames = ((TemplateHashModelEx)this.rootDataModel).keys().iterator();
/* 2385 */       while (rootNames.hasNext()) {
/* 2386 */         set.add(((TemplateScalarModel)rootNames.next()).getAsString());
/*      */       }
/*      */     } 
/*      */     
/*      */     TemplateModelIterator tmi;
/* 2391 */     for (tmi = this.globalNamespace.keys().iterator(); tmi.hasNext();) {
/* 2392 */       set.add(((TemplateScalarModel)tmi.next()).getAsString());
/*      */     }
/*      */ 
/*      */     
/* 2396 */     for (tmi = this.currentNamespace.keys().iterator(); tmi.hasNext();) {
/* 2397 */       set.add(((TemplateScalarModel)tmi.next()).getAsString());
/*      */     }
/*      */ 
/*      */     
/* 2401 */     if (this.currentMacroContext != null) {
/* 2402 */       set.addAll(this.currentMacroContext.getLocalVariableNames());
/*      */     }
/* 2404 */     if (this.localContextStack != null) {
/* 2405 */       for (int i = this.localContextStack.size() - 1; i >= 0; i--) {
/* 2406 */         LocalContext lc = this.localContextStack.get(i);
/* 2407 */         set.addAll(lc.getLocalVariableNames());
/*      */       } 
/*      */     }
/* 2410 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void outputInstructionStack(PrintWriter pw) {
/* 2418 */     outputInstructionStack(getInstructionStackSnapshot(), false, pw);
/* 2419 */     pw.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void outputInstructionStack(TemplateElement[] instructionStackSnapshot, boolean terseMode, Writer w) {
/* 2434 */     PrintWriter pw = (w instanceof PrintWriter) ? (PrintWriter)w : null;
/*      */     try {
/* 2436 */       if (instructionStackSnapshot != null) {
/* 2437 */         int totalFrames = instructionStackSnapshot.length;
/* 2438 */         int framesToPrint = terseMode ? ((totalFrames <= 10) ? totalFrames : 9) : totalFrames;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2443 */         boolean hideNestringRelatedFrames = (terseMode && framesToPrint < totalFrames);
/* 2444 */         int nestingRelatedFramesHidden = 0;
/* 2445 */         int trailingFramesHidden = 0;
/* 2446 */         int framesPrinted = 0;
/* 2447 */         for (int frameIdx = 0; frameIdx < totalFrames; frameIdx++) {
/* 2448 */           TemplateElement stackEl = instructionStackSnapshot[frameIdx];
/* 2449 */           boolean nestingRelatedElement = ((frameIdx > 0 && stackEl instanceof BodyInstruction) || (frameIdx > 1 && instructionStackSnapshot[frameIdx - 1] instanceof BodyInstruction));
/*      */           
/* 2451 */           if (framesPrinted < framesToPrint) {
/* 2452 */             if (!nestingRelatedElement || !hideNestringRelatedFrames) {
/* 2453 */               w.write((frameIdx == 0) ? "\t- Failed at: " : (nestingRelatedElement ? "\t~ Reached through: " : "\t- Reached through: "));
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2458 */               w.write(instructionStackItemToString(stackEl));
/* 2459 */               if (pw != null) { pw.println(); }
/*      */               else
/* 2461 */               { w.write(10); }
/* 2462 */                framesPrinted++;
/*      */             } else {
/* 2464 */               nestingRelatedFramesHidden++;
/*      */             } 
/*      */           } else {
/* 2467 */             trailingFramesHidden++;
/*      */           } 
/*      */         } 
/*      */         
/* 2471 */         boolean hadClosingNotes = false;
/* 2472 */         if (trailingFramesHidden > 0) {
/* 2473 */           w.write("\t... (Had ");
/* 2474 */           w.write(String.valueOf(trailingFramesHidden + nestingRelatedFramesHidden));
/* 2475 */           w.write(" more, hidden for tersenes)");
/* 2476 */           hadClosingNotes = true;
/*      */         } 
/* 2478 */         if (nestingRelatedFramesHidden > 0) {
/* 2479 */           if (hadClosingNotes) {
/* 2480 */             w.write(32);
/*      */           } else {
/* 2482 */             w.write(9);
/*      */           } 
/* 2484 */           w.write("(Hidden " + nestingRelatedFramesHidden + " \"~\" lines for terseness)");
/* 2485 */           if (pw != null) { pw.println(); }
/*      */           else
/* 2487 */           { w.write(10); }
/* 2488 */            hadClosingNotes = true;
/*      */         } 
/* 2490 */         if (hadClosingNotes)
/* 2491 */           if (pw != null) { pw.println(); }
/*      */           else
/* 2493 */           { w.write(10); }
/*      */            
/*      */       } else {
/* 2496 */         w.write("(The stack was empty)");
/* 2497 */         if (pw != null) { pw.println(); }
/*      */         else
/* 2499 */         { w.write(10); } 
/*      */       } 
/* 2501 */     } catch (IOException e) {
/* 2502 */       LOG.error("Failed to print FTL stack trace", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TemplateElement[] getInstructionStackSnapshot() {
/* 2512 */     int requiredLength = 0;
/* 2513 */     int ln = this.instructionStackSize;
/*      */     
/* 2515 */     for (int i = 0; i < ln; i++) {
/* 2516 */       TemplateElement stackEl = this.instructionStack[i];
/* 2517 */       if (i == ln - 1 || stackEl.isShownInStackTrace()) {
/* 2518 */         requiredLength++;
/*      */       }
/*      */     } 
/*      */     
/* 2522 */     if (requiredLength == 0) return null;
/*      */     
/* 2524 */     TemplateElement[] result = new TemplateElement[requiredLength];
/* 2525 */     int dstIdx = requiredLength - 1;
/* 2526 */     for (int j = 0; j < ln; j++) {
/* 2527 */       TemplateElement stackEl = this.instructionStack[j];
/* 2528 */       if (j == ln - 1 || stackEl.isShownInStackTrace()) {
/* 2529 */         result[dstIdx--] = stackEl;
/*      */       }
/*      */     } 
/*      */     
/* 2533 */     return result;
/*      */   }
/*      */   
/*      */   static String instructionStackItemToString(TemplateElement stackEl) {
/* 2537 */     StringBuilder sb = new StringBuilder();
/* 2538 */     appendInstructionStackItem(stackEl, sb);
/* 2539 */     return sb.toString();
/*      */   }
/*      */   
/*      */   static void appendInstructionStackItem(TemplateElement stackEl, StringBuilder sb) {
/* 2543 */     sb.append(_MessageUtil.shorten(stackEl.getDescription(), 40));
/*      */     
/* 2545 */     sb.append("  [");
/* 2546 */     Macro enclosingMacro = getEnclosingMacro(stackEl);
/* 2547 */     if (enclosingMacro != null) {
/* 2548 */       sb.append(_MessageUtil.formatLocationForEvaluationError(enclosingMacro, stackEl.beginLine, stackEl.beginColumn));
/*      */     } else {
/*      */       
/* 2551 */       sb.append(_MessageUtil.formatLocationForEvaluationError(stackEl
/* 2552 */             .getTemplate(), stackEl.beginLine, stackEl.beginColumn));
/*      */     } 
/* 2554 */     sb.append("]");
/*      */   }
/*      */   
/*      */   private static Macro getEnclosingMacro(TemplateElement stackEl) {
/* 2558 */     while (stackEl != null) {
/* 2559 */       if (stackEl instanceof Macro) return (Macro)stackEl; 
/* 2560 */       stackEl = stackEl.getParentElement();
/*      */     } 
/* 2562 */     return null;
/*      */   }
/*      */   
/*      */   private void pushLocalContext(LocalContext localContext) {
/* 2566 */     if (this.localContextStack == null) {
/* 2567 */       this.localContextStack = new LocalContextStack();
/*      */     }
/* 2569 */     this.localContextStack.push(localContext);
/*      */   }
/*      */   
/*      */   LocalContextStack getLocalContextStack() {
/* 2573 */     return this.localContextStack;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace getNamespace(String name) {
/* 2585 */     if (name.startsWith("/")) name = name.substring(1); 
/* 2586 */     if (this.loadedLibs != null) {
/* 2587 */       return this.loadedLibs.get(name);
/*      */     }
/* 2589 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace getMainNamespace() {
/* 2597 */     return this.mainNamespace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace getCurrentNamespace() {
/* 2608 */     return this.currentNamespace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace getGlobalNamespace() {
/* 2616 */     return this.globalNamespace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateHashModel getDataModel() {
/* 2624 */     return (this.rootDataModel instanceof TemplateHashModelEx) ? (TemplateHashModel)new TemplateHashModelEx()
/*      */       {
/*      */         public boolean isEmpty() throws TemplateModelException
/*      */         {
/* 2628 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public TemplateModel get(String key) throws TemplateModelException {
/* 2633 */           return Environment.this.getDataModelOrSharedVariable(key);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TemplateCollectionModel values() throws TemplateModelException {
/* 2641 */           return ((TemplateHashModelEx)Environment.this.rootDataModel).values();
/*      */         }
/*      */ 
/*      */         
/*      */         public TemplateCollectionModel keys() throws TemplateModelException {
/* 2646 */           return ((TemplateHashModelEx)Environment.this.rootDataModel).keys();
/*      */         }
/*      */ 
/*      */         
/*      */         public int size() throws TemplateModelException {
/* 2651 */           return ((TemplateHashModelEx)Environment.this.rootDataModel).size();
/*      */         }
/*      */       } : new TemplateHashModel()
/*      */       {
/*      */         public boolean isEmpty()
/*      */         {
/* 2657 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public TemplateModel get(String key) throws TemplateModelException {
/* 2662 */           TemplateModel value = Environment.this.rootDataModel.get(key);
/* 2663 */           return (value != null) ? value : Environment.this.configuration.getSharedVariable(key);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TemplateHashModel getGlobalVariables() {
/* 2674 */     return new TemplateHashModel()
/*      */       {
/*      */         public boolean isEmpty()
/*      */         {
/* 2678 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public TemplateModel get(String key) throws TemplateModelException {
/* 2683 */           TemplateModel result = Environment.this.globalNamespace.get(key);
/* 2684 */           if (result == null) {
/* 2685 */             result = Environment.this.rootDataModel.get(key);
/*      */           }
/* 2687 */           if (result == null) {
/* 2688 */             result = Environment.this.configuration.getSharedVariable(key);
/*      */           }
/* 2690 */           return result;
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   private void pushElement(TemplateElement element) {
/* 2696 */     int newSize = ++this.instructionStackSize;
/* 2697 */     TemplateElement[] instructionStack = this.instructionStack;
/* 2698 */     if (newSize > instructionStack.length) {
/* 2699 */       TemplateElement[] newInstructionStack = new TemplateElement[newSize * 2];
/* 2700 */       for (int i = 0; i < instructionStack.length; i++) {
/* 2701 */         newInstructionStack[i] = instructionStack[i];
/*      */       }
/* 2703 */       instructionStack = newInstructionStack;
/* 2704 */       this.instructionStack = instructionStack;
/*      */     } 
/* 2706 */     instructionStack[newSize - 1] = element;
/*      */   }
/*      */   
/*      */   private void popElement() {
/* 2710 */     this.instructionStackSize--;
/*      */   }
/*      */   
/*      */   void replaceElementStackTop(TemplateElement instr) {
/* 2714 */     this.instructionStack[this.instructionStackSize - 1] = instr;
/*      */   }
/*      */   
/*      */   public TemplateNodeModel getCurrentVisitorNode() {
/* 2718 */     return this.currentVisitorNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurrentVisitorNode(TemplateNodeModel node) {
/* 2725 */     this.currentVisitorNode = node;
/*      */   }
/*      */   
/*      */   TemplateModel getNodeProcessor(TemplateNodeModel node) throws TemplateException {
/* 2729 */     String nodeName = node.getNodeName();
/* 2730 */     if (nodeName == null) {
/* 2731 */       throw new _MiscTemplateException(this, "Node name is null.");
/*      */     }
/* 2733 */     TemplateModel result = getNodeProcessor(nodeName, node.getNodeNamespace(), 0);
/*      */     
/* 2735 */     if (result == null) {
/* 2736 */       String type = node.getNodeType();
/*      */ 
/*      */       
/* 2739 */       if (type == null) {
/* 2740 */         type = "default";
/*      */       }
/* 2742 */       result = getNodeProcessor("@" + type, (String)null, 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2750 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private TemplateModel getNodeProcessor(String nodeName, String nsURI, int startIndex) throws TemplateException {
/* 2755 */     TemplateModel result = null;
/*      */     
/* 2757 */     int size = this.nodeNamespaces.size(); int i;
/* 2758 */     for (i = startIndex; i < size; i++) {
/* 2759 */       Namespace ns = null;
/*      */       try {
/* 2761 */         ns = (Namespace)this.nodeNamespaces.get(i);
/* 2762 */       } catch (ClassCastException cce) {
/* 2763 */         throw new _MiscTemplateException(this, "A \"using\" clause should contain a sequence of namespaces or strings that indicate the location of importable macro libraries.");
/*      */       } 
/*      */ 
/*      */       
/* 2767 */       result = getNodeProcessor(ns, nodeName, nsURI);
/* 2768 */       if (result != null)
/*      */         break; 
/*      */     } 
/* 2771 */     if (result != null) {
/* 2772 */       this.nodeNamespaceIndex = i + 1;
/* 2773 */       this.currentNodeName = nodeName;
/* 2774 */       this.currentNodeNS = nsURI;
/*      */     } 
/* 2776 */     return result;
/*      */   }
/*      */   
/*      */   private TemplateModel getNodeProcessor(Namespace ns, String localName, String nsURI) throws TemplateException {
/* 2780 */     TemplateModel result = null;
/* 2781 */     if (nsURI == null) {
/* 2782 */       result = ns.get(localName);
/* 2783 */       if (!(result instanceof Macro) && !(result instanceof TemplateTransformModel)) {
/* 2784 */         result = null;
/*      */       }
/*      */     } else {
/* 2787 */       Template template = ns.getTemplate();
/* 2788 */       String prefix = template.getPrefixForNamespace(nsURI);
/* 2789 */       if (prefix == null)
/*      */       {
/*      */         
/* 2792 */         return null;
/*      */       }
/* 2794 */       if (prefix.length() > 0) {
/* 2795 */         result = ns.get(prefix + ":" + localName);
/* 2796 */         if (!(result instanceof Macro) && !(result instanceof TemplateTransformModel)) {
/* 2797 */           result = null;
/*      */         }
/*      */       } else {
/* 2800 */         if (nsURI.length() == 0) {
/* 2801 */           result = ns.get("N:" + localName);
/* 2802 */           if (!(result instanceof Macro) && !(result instanceof TemplateTransformModel)) {
/* 2803 */             result = null;
/*      */           }
/*      */         } 
/* 2806 */         if (nsURI.equals(template.getDefaultNS())) {
/* 2807 */           result = ns.get("D:" + localName);
/* 2808 */           if (!(result instanceof Macro) && !(result instanceof TemplateTransformModel)) {
/* 2809 */             result = null;
/*      */           }
/*      */         } 
/* 2812 */         if (result == null) {
/* 2813 */           result = ns.get(localName);
/* 2814 */           if (!(result instanceof Macro) && !(result instanceof TemplateTransformModel)) {
/* 2815 */             result = null;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2820 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void include(String name, String encoding, boolean parse) throws IOException, TemplateException {
/* 2836 */     include(getTemplateForInclusion(name, encoding, parse));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Template getTemplateForInclusion(String name, String encoding, boolean parse) throws IOException {
/* 2845 */     return getTemplateForInclusion(name, encoding, parse, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Template getTemplateForInclusion(String name, String encoding, boolean parseAsFTL, boolean ignoreMissing) throws IOException {
/* 2883 */     return this.configuration.getTemplate(name, 
/* 2884 */         getLocale(), getIncludedTemplateCustomLookupCondition(), (encoding != null) ? encoding : 
/* 2885 */         getIncludedTemplateEncoding(), parseAsFTL, ignoreMissing);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getIncludedTemplateCustomLookupCondition() {
/* 2891 */     return getTemplate().getCustomLookupCondition();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String getIncludedTemplateEncoding() {
/* 2897 */     String encoding = getTemplate().getEncoding();
/* 2898 */     if (encoding == null) {
/* 2899 */       encoding = this.configuration.getEncoding(getLocale());
/*      */     }
/* 2901 */     return encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void include(Template includedTemplate) throws TemplateException, IOException {
/* 2915 */     boolean parentReplacementOn = isBeforeIcI2322();
/* 2916 */     Template prevTemplate = getTemplate();
/* 2917 */     if (parentReplacementOn) {
/* 2918 */       setParent((Configurable)includedTemplate);
/*      */     } else {
/* 2920 */       this.legacyParent = (Configurable)includedTemplate;
/*      */     } 
/*      */     
/* 2923 */     importMacros(includedTemplate);
/*      */     try {
/* 2925 */       visit(includedTemplate.getRootTreeNode());
/*      */     } finally {
/* 2927 */       if (parentReplacementOn) {
/* 2928 */         setParent((Configurable)prevTemplate);
/*      */       } else {
/* 2930 */         this.legacyParent = (Configurable)prevTemplate;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace importLib(String templateName, String targetNsVarName) throws IOException, TemplateException {
/* 2956 */     return importLib(templateName, targetNsVarName, getLazyImports());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace importLib(Template loadedTemplate, String targetNsVarName) throws IOException, TemplateException {
/* 2976 */     return importLib((String)null, loadedTemplate, targetNsVarName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Namespace importLib(String templateName, String targetNsVarName, boolean lazy) throws IOException, TemplateException {
/* 2990 */     return lazy ? 
/* 2991 */       importLib(templateName, (Template)null, targetNsVarName) : 
/* 2992 */       importLib((String)null, getTemplateForImporting(templateName), targetNsVarName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Template getTemplateForImporting(String name) throws IOException {
/* 3007 */     return getTemplateForInclusion(name, (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Namespace importLib(String templateName, Template loadedTemplate, String targetNsVarName) throws IOException, TemplateException {
/*      */     boolean lazyImport;
/* 3021 */     if (loadedTemplate != null) {
/* 3022 */       lazyImport = false;
/*      */ 
/*      */ 
/*      */       
/* 3026 */       templateName = loadedTemplate.getName();
/*      */     } else {
/* 3028 */       lazyImport = true;
/*      */ 
/*      */ 
/*      */       
/* 3032 */       TemplateNameFormat tnf = getConfiguration().getTemplateNameFormat();
/* 3033 */       templateName = _CacheAPI.normalizeRootBasedName(tnf, templateName);
/*      */     } 
/*      */     
/* 3036 */     if (this.loadedLibs == null) {
/* 3037 */       this.loadedLibs = new HashMap<>();
/*      */     }
/* 3039 */     Namespace existingNamespace = this.loadedLibs.get(templateName);
/* 3040 */     if (existingNamespace != null) {
/* 3041 */       if (targetNsVarName != null) {
/* 3042 */         setVariable(targetNsVarName, (TemplateModel)existingNamespace);
/* 3043 */         if (isIcI2324OrLater() && this.currentNamespace == this.mainNamespace) {
/* 3044 */           this.globalNamespace.put(targetNsVarName, existingNamespace);
/*      */         }
/*      */       } 
/* 3047 */       if (!lazyImport && existingNamespace instanceof LazilyInitializedNamespace) {
/* 3048 */         ((LazilyInitializedNamespace)existingNamespace).ensureInitializedTME();
/*      */       }
/*      */     } else {
/* 3051 */       Namespace newNamespace = lazyImport ? new LazilyInitializedNamespace(templateName) : new Namespace(loadedTemplate);
/*      */       
/* 3053 */       this.loadedLibs.put(templateName, newNamespace);
/*      */       
/* 3055 */       if (targetNsVarName != null) {
/* 3056 */         setVariable(targetNsVarName, (TemplateModel)newNamespace);
/* 3057 */         if (this.currentNamespace == this.mainNamespace) {
/* 3058 */           this.globalNamespace.put(targetNsVarName, newNamespace);
/*      */         }
/*      */       } 
/*      */       
/* 3062 */       if (!lazyImport) {
/* 3063 */         initializeImportLibNamespace(newNamespace, loadedTemplate);
/*      */       }
/*      */     } 
/* 3066 */     return this.loadedLibs.get(templateName);
/*      */   }
/*      */ 
/*      */   
/*      */   private void initializeImportLibNamespace(Namespace newNamespace, Template loadedTemplate) throws TemplateException, IOException {
/* 3071 */     Namespace prevNamespace = this.currentNamespace;
/* 3072 */     this.currentNamespace = newNamespace;
/* 3073 */     Writer prevOut = this.out;
/* 3074 */     this.out = (Writer)NullWriter.INSTANCE;
/*      */     try {
/* 3076 */       include(loadedTemplate);
/*      */     } finally {
/* 3078 */       this.out = prevOut;
/* 3079 */       this.currentNamespace = prevNamespace;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toFullTemplateName(String baseName, String targetName) throws MalformedTemplateNameException {
/* 3114 */     if (isClassicCompatible() || baseName == null) {
/* 3115 */       return targetName;
/*      */     }
/*      */     
/* 3118 */     return _CacheAPI.toRootBasedName(this.configuration.getTemplateNameFormat(), baseName, targetName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rootBasedToAbsoluteTemplateName(String rootBasedName) throws MalformedTemplateNameException {
/* 3137 */     return _CacheAPI.rootBasedNameToAbsoluteName(this.configuration.getTemplateNameFormat(), rootBasedName);
/*      */   }
/*      */   
/*      */   String renderElementToString(TemplateElement te) throws IOException, TemplateException {
/* 3141 */     Writer prevOut = this.out;
/*      */     try {
/* 3143 */       StringWriter sw = new StringWriter();
/* 3144 */       this.out = sw;
/* 3145 */       visit(te);
/* 3146 */       return sw.toString();
/*      */     } finally {
/* 3148 */       this.out = prevOut;
/*      */     } 
/*      */   }
/*      */   
/*      */   void importMacros(Template template) {
/* 3153 */     for (Iterator<Macro> it = template.getMacros().values().iterator(); it.hasNext();) {
/* 3154 */       visitMacroDef(it.next());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNamespaceForPrefix(String prefix) {
/* 3163 */     return this.currentNamespace.getTemplate().getNamespaceForPrefix(prefix);
/*      */   }
/*      */   
/*      */   public String getPrefixForNamespace(String nsURI) {
/* 3167 */     return this.currentNamespace.getTemplate().getPrefixForNamespace(nsURI);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultNS() {
/* 3174 */     return this.currentNamespace.getTemplate().getDefaultNS();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object __getitem__(String key) throws TemplateModelException {
/* 3181 */     return BeansWrapper.getDefaultInstance().unwrap(getVariable(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void __setitem__(String key, Object o) throws TemplateException {
/* 3188 */     setGlobalVariable(key, getObjectWrapper().wrap(o));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomState(Object identityKey) {
/* 3200 */     if (this.customStateVariables == null) {
/* 3201 */       return null;
/*      */     }
/* 3203 */     return this.customStateVariables.get(identityKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object setCustomState(Object identityKey, Object value) {
/* 3223 */     IdentityHashMap<Object, Object> customStateVariables = this.customStateVariables;
/* 3224 */     if (customStateVariables == null) {
/* 3225 */       customStateVariables = new IdentityHashMap<>();
/* 3226 */       this.customStateVariables = customStateVariables;
/*      */     } 
/* 3228 */     return customStateVariables.put(identityKey, value);
/*      */   }
/*      */   
/*      */   final class NestedElementTemplateDirectiveBody
/*      */     implements TemplateDirectiveBody {
/*      */     private final TemplateElement[] childBuffer;
/*      */     
/*      */     private NestedElementTemplateDirectiveBody(TemplateElement[] childBuffer) {
/* 3236 */       this.childBuffer = childBuffer;
/*      */     }
/*      */ 
/*      */     
/*      */     public void render(Writer newOut) throws TemplateException, IOException {
/* 3241 */       Writer prevOut = Environment.this.out;
/* 3242 */       Environment.this.out = newOut;
/*      */       try {
/* 3244 */         Environment.this.visit(this.childBuffer);
/*      */       } finally {
/* 3246 */         Environment.this.out = prevOut;
/*      */       } 
/*      */     }
/*      */     
/*      */     TemplateElement[] getChildrenBuffer() {
/* 3251 */       return this.childBuffer;
/*      */     }
/*      */   }
/*      */   
/*      */   public class Namespace
/*      */     extends SimpleHash
/*      */   {
/*      */     private Template template;
/*      */     
/*      */     Namespace() {
/* 3261 */       super((ObjectWrapper)_TemplateAPI.SAFE_OBJECT_WRAPPER);
/* 3262 */       this.template = Environment.this.getTemplate();
/*      */     }
/*      */     
/*      */     Namespace(Template template) {
/* 3266 */       super((ObjectWrapper)_TemplateAPI.SAFE_OBJECT_WRAPPER);
/* 3267 */       this.template = template;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Template getTemplate() {
/* 3274 */       return (this.template == null) ? Environment.this.getTemplate() : this.template;
/*      */     }
/*      */     
/*      */     void setTemplate(Template template) {
/* 3278 */       this.template = template;
/*      */     }
/*      */   }
/*      */   
/*      */   private enum InitializationStatus
/*      */   {
/* 3284 */     UNINITIALIZED, INITIALIZING, INITIALIZED, FAILED;
/*      */   }
/*      */   
/*      */   class LazilyInitializedNamespace
/*      */     extends Namespace
/*      */   {
/*      */     private final String templateName;
/*      */     private final Locale locale;
/*      */     private final String encoding;
/*      */     private final Object customLookupCondition;
/* 3294 */     private Environment.InitializationStatus status = Environment.InitializationStatus.UNINITIALIZED;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private LazilyInitializedNamespace(String templateName) {
/* 3301 */       super((Template)null);
/*      */       
/* 3303 */       this.templateName = templateName;
/*      */       
/* 3305 */       this.locale = Environment.this.getLocale();
/* 3306 */       this.encoding = Environment.this.getIncludedTemplateEncoding();
/* 3307 */       this.customLookupCondition = Environment.this.getIncludedTemplateCustomLookupCondition();
/*      */     }
/*      */     
/*      */     private void ensureInitializedTME() throws TemplateModelException {
/* 3311 */       if (this.status != Environment.InitializationStatus.INITIALIZED && this.status != Environment.InitializationStatus.INITIALIZING) {
/* 3312 */         if (this.status == Environment.InitializationStatus.FAILED) {
/* 3313 */           throw new TemplateModelException("Lazy initialization of the imported namespace for " + 
/*      */               
/* 3315 */               StringUtil.jQuote(this.templateName) + " has already failed earlier; won't retry it.");
/*      */         }
/*      */         
/*      */         try {
/* 3319 */           this.status = Environment.InitializationStatus.INITIALIZING;
/* 3320 */           initialize();
/* 3321 */           this.status = Environment.InitializationStatus.INITIALIZED;
/* 3322 */         } catch (Exception e) {
/*      */           
/* 3324 */           throw new TemplateModelException("Lazy initialization of the imported namespace for " + 
/*      */               
/* 3326 */               StringUtil.jQuote(this.templateName) + " has failed; see cause exception", e);
/*      */         } finally {
/*      */           
/* 3329 */           if (this.status != Environment.InitializationStatus.INITIALIZED) {
/* 3330 */             this.status = Environment.InitializationStatus.FAILED;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void ensureInitializedRTE() {
/*      */       try {
/* 3338 */         ensureInitializedTME();
/* 3339 */       } catch (TemplateModelException e) {
/* 3340 */         throw new RuntimeException(e.getMessage(), e.getCause());
/*      */       } 
/*      */     }
/*      */     
/*      */     private void initialize() throws IOException, TemplateException {
/* 3345 */       setTemplate(Environment.this.configuration.getTemplate(this.templateName, this.locale, this.customLookupCondition, this.encoding, true, false));
/*      */ 
/*      */       
/* 3348 */       Locale lastLocale = Environment.this.getLocale();
/*      */       try {
/* 3350 */         Environment.this.setLocale(this.locale);
/* 3351 */         Environment.this.initializeImportLibNamespace(this, getTemplate());
/*      */       } finally {
/* 3353 */         Environment.this.setLocale(lastLocale);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected Map copyMap(Map map) {
/* 3359 */       ensureInitializedRTE();
/* 3360 */       return super.copyMap(map);
/*      */     }
/*      */ 
/*      */     
/*      */     public Template getTemplate() {
/* 3365 */       ensureInitializedRTE();
/* 3366 */       return super.getTemplate();
/*      */     }
/*      */ 
/*      */     
/*      */     public void put(String key, Object value) {
/* 3371 */       ensureInitializedRTE();
/* 3372 */       super.put(key, value);
/*      */     }
/*      */ 
/*      */     
/*      */     public void put(String key, boolean b) {
/* 3377 */       ensureInitializedRTE();
/* 3378 */       super.put(key, b);
/*      */     }
/*      */ 
/*      */     
/*      */     public TemplateModel get(String key) throws TemplateModelException {
/* 3383 */       ensureInitializedTME();
/* 3384 */       return super.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(String key) {
/* 3389 */       ensureInitializedRTE();
/* 3390 */       return super.containsKey(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(String key) {
/* 3395 */       ensureInitializedRTE();
/* 3396 */       super.remove(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void putAll(Map m) {
/* 3401 */       ensureInitializedRTE();
/* 3402 */       super.putAll(m);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map toMap() throws TemplateModelException {
/* 3407 */       ensureInitializedTME();
/* 3408 */       return super.toMap();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 3413 */       ensureInitializedRTE();
/* 3414 */       return super.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 3419 */       ensureInitializedRTE();
/* 3420 */       return super.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 3425 */       ensureInitializedRTE();
/* 3426 */       return super.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public TemplateCollectionModel keys() {
/* 3431 */       ensureInitializedRTE();
/* 3432 */       return super.keys();
/*      */     }
/*      */ 
/*      */     
/*      */     public TemplateCollectionModel values() {
/* 3437 */       ensureInitializedRTE();
/* 3438 */       return super.values();
/*      */     }
/*      */ 
/*      */     
/*      */     public TemplateHashModelEx2.KeyValuePairIterator keyValuePairIterator() {
/* 3443 */       ensureInitializedRTE();
/* 3444 */       return super.keyValuePairIterator();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 3450 */   private static final Writer EMPTY_BODY_WRITER = new Writer()
/*      */     {
/*      */       public void write(char[] cbuf, int off, int len) throws IOException
/*      */       {
/* 3454 */         if (len > 0) {
/* 3455 */           throw new IOException("This transform does not allow nested content.");
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public void flush() {}
/*      */ 
/*      */ 
/*      */       
/*      */       public void close() {}
/*      */     };
/*      */ 
/*      */   
/*      */   private boolean isBeforeIcI2322() {
/* 3470 */     return (this.configuration.getIncompatibleImprovements().intValue() < _TemplateAPI.VERSION_INT_2_3_22);
/*      */   }
/*      */   
/*      */   boolean isIcI2324OrLater() {
/* 3474 */     return (this.configuration.getIncompatibleImprovements().intValue() >= _TemplateAPI.VERSION_INT_2_3_24);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getFastInvalidReferenceExceptions() {
/* 3481 */     return this.fastInvalidReferenceExceptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean setFastInvalidReferenceExceptions(boolean b) {
/* 3490 */     boolean res = this.fastInvalidReferenceExceptions;
/* 3491 */     this.fastInvalidReferenceExceptions = b;
/* 3492 */     return res;
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\Environment.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */