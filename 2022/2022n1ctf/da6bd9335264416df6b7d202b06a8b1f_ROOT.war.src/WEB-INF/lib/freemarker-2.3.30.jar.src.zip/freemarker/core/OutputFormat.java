/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.utility.ClassUtil;
/*    */ import freemarker.template.utility.StringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OutputFormat
/*    */ {
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract String getMimeType();
/*    */   
/*    */   public abstract boolean isOutputFormatMixingAllowed();
/*    */   
/*    */   public final String toString() {
/* 68 */     String extras = toStringExtraProperties();
/* 69 */     return getName() + "(mimeType=" + 
/* 70 */       StringUtil.jQuote(getMimeType()) + ", class=" + 
/* 71 */       ClassUtil.getShortClassNameOfObject(this, true) + (
/* 72 */       (extras.length() != 0) ? ", " : "") + extras + ")";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String toStringExtraProperties() {
/* 81 */     return "";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\OutputFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */