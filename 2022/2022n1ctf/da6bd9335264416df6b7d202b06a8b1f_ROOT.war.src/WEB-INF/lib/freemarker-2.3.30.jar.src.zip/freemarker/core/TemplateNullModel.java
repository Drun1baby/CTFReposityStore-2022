/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TemplateNullModel
/*    */   implements TemplateModel
/*    */ {
/* 37 */   static final TemplateNullModel INSTANCE = new TemplateNullModel();
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateNullModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */