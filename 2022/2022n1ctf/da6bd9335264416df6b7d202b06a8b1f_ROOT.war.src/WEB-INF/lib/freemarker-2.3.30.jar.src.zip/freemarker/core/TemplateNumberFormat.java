/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateModelException;
/*    */ import freemarker.template.TemplateNumberModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TemplateNumberFormat
/*    */   extends TemplateValueFormat
/*    */ {
/*    */   public abstract String formatToPlainText(TemplateNumberModel paramTemplateNumberModel) throws TemplateValueFormatException, TemplateModelException;
/*    */   
/*    */   public Object format(TemplateNumberModel numberModel) throws TemplateValueFormatException, TemplateModelException {
/* 71 */     return formatToPlainText(numberModel);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean isLocaleBound();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Object parse(String s) throws TemplateValueFormatException {
/* 86 */     throw new ParsingNotSupportedException("Number formats currenly don't support parsing");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateNumberFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */