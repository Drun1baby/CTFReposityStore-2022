/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InvalidFormatParametersException
/*    */   extends InvalidFormatStringException
/*    */ {
/*    */   public InvalidFormatParametersException(String message, Throwable cause) {
/* 30 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public InvalidFormatParametersException(String message) {
/* 34 */     this(message, null);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\InvalidFormatParametersException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */