/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.SimpleScalar;
/*    */ import freemarker.template.TemplateModel;
/*    */ import freemarker.template.TemplateModelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BuiltInsForMarkupOutputs
/*    */ {
/*    */   static class markup_stringBI
/*    */     extends BuiltInForMarkupOutput
/*    */   {
/*    */     protected TemplateModel calculateResult(TemplateMarkupOutputModel<TemplateMarkupOutputModel> model) throws TemplateModelException {
/* 35 */       return (TemplateModel)new SimpleScalar(model.getOutputFormat().getMarkupString(model));
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\BuiltInsForMarkupOutputs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */