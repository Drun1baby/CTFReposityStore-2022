/*     */ package freemarker.core;
/*     */ 
/*     */ import freemarker.log.Logger;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaTemplateNumberFormatFactory
/*     */   extends TemplateNumberFormatFactory
/*     */ {
/*  33 */   static final JavaTemplateNumberFormatFactory INSTANCE = new JavaTemplateNumberFormatFactory();
/*     */   
/*  35 */   private static final Logger LOG = Logger.getLogger("freemarker.runtime");
/*     */   
/*  37 */   private static final ConcurrentHashMap<CacheKey, NumberFormat> GLOBAL_FORMAT_CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int LEAK_ALERT_NUMBER_FORMAT_CACHE_SIZE = 1024;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateNumberFormat get(String params, Locale locale, Environment env) throws InvalidFormatParametersException {
/*  48 */     CacheKey cacheKey = new CacheKey(params, locale);
/*  49 */     NumberFormat jFormat = GLOBAL_FORMAT_CACHE.get(cacheKey);
/*  50 */     if (jFormat == null) {
/*  51 */       if ("number".equals(params)) {
/*  52 */         jFormat = NumberFormat.getNumberInstance(locale);
/*  53 */       } else if ("currency".equals(params)) {
/*  54 */         jFormat = NumberFormat.getCurrencyInstance(locale);
/*  55 */       } else if ("percent".equals(params)) {
/*  56 */         jFormat = NumberFormat.getPercentInstance(locale);
/*  57 */       } else if ("computer".equals(params)) {
/*  58 */         jFormat = env.getCNumberFormat();
/*     */       } else {
/*     */         try {
/*  61 */           jFormat = ExtendedDecimalFormatParser.parse(params, locale);
/*  62 */         } catch (ParseException e) {
/*  63 */           String msg = e.getMessage();
/*  64 */           throw new InvalidFormatParametersException((msg != null) ? msg : "Invalid DecimalFormat pattern", e);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  69 */       if (GLOBAL_FORMAT_CACHE.size() >= 1024) {
/*  70 */         boolean triggered = false;
/*  71 */         synchronized (JavaTemplateNumberFormatFactory.class) {
/*  72 */           if (GLOBAL_FORMAT_CACHE.size() >= 1024) {
/*  73 */             triggered = true;
/*  74 */             GLOBAL_FORMAT_CACHE.clear();
/*     */           } 
/*     */         } 
/*  77 */         if (triggered) {
/*  78 */           LOG.warn("Global Java NumberFormat cache has exceeded 1024 entries => cache flushed. Typical cause: Some template generates high variety of format pattern strings.");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  84 */       NumberFormat prevJFormat = GLOBAL_FORMAT_CACHE.putIfAbsent(cacheKey, jFormat);
/*  85 */       if (prevJFormat != null) {
/*  86 */         jFormat = prevJFormat;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  91 */     jFormat = (NumberFormat)jFormat.clone();
/*     */     
/*  93 */     return new JavaTemplateNumberFormat(jFormat, params);
/*     */   }
/*     */   
/*     */   private static final class CacheKey {
/*     */     private final String pattern;
/*     */     private final Locale locale;
/*     */     
/*     */     CacheKey(String pattern, Locale locale) {
/* 101 */       this.pattern = pattern;
/* 102 */       this.locale = locale;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 107 */       if (o instanceof CacheKey) {
/* 108 */         CacheKey fk = (CacheKey)o;
/* 109 */         return (fk.pattern.equals(this.pattern) && fk.locale.equals(this.locale));
/*     */       } 
/* 111 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 116 */       return this.pattern.hashCode() ^ this.locale.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\JavaTemplateNumberFormatFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */