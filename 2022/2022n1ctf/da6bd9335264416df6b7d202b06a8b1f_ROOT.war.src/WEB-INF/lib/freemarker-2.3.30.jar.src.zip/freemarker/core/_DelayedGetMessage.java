/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _DelayedGetMessage
/*    */   extends _DelayedConversionToString
/*    */ {
/*    */   public _DelayedGetMessage(Throwable exception) {
/* 26 */     super(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String doConversion(Object obj) {
/* 31 */     String message = ((Throwable)obj).getMessage();
/* 32 */     return (message == null || message.length() == 0) ? "[No exception message]" : message;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_DelayedGetMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */