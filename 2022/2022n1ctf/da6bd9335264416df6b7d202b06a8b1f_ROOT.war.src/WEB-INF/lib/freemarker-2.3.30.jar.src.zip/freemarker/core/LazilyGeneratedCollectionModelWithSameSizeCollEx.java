/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateCollectionModelEx;
/*    */ import freemarker.template.TemplateModelException;
/*    */ import freemarker.template.TemplateModelIterator;
/*    */ import freemarker.template.utility.NullArgumentException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LazilyGeneratedCollectionModelWithSameSizeCollEx
/*    */   extends LazilyGeneratedCollectionModelEx
/*    */ {
/*    */   private final TemplateCollectionModelEx sizeSourceCollEx;
/*    */   
/*    */   public LazilyGeneratedCollectionModelWithSameSizeCollEx(TemplateModelIterator iterator, TemplateCollectionModelEx sizeSourceCollEx, boolean sequenceSourced) {
/* 36 */     super(iterator, sequenceSourced);
/* 37 */     NullArgumentException.check(sizeSourceCollEx);
/* 38 */     this.sizeSourceCollEx = sizeSourceCollEx;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() throws TemplateModelException {
/* 43 */     return this.sizeSourceCollEx.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() throws TemplateModelException {
/* 48 */     return this.sizeSourceCollEx.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   protected LazilyGeneratedCollectionModelWithSameSizeCollEx withIsSequenceFromFalseToTrue() {
/* 53 */     return new LazilyGeneratedCollectionModelWithSameSizeCollEx(getIterator(), this.sizeSourceCollEx, true);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\LazilyGeneratedCollectionModelWithSameSizeCollEx.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */