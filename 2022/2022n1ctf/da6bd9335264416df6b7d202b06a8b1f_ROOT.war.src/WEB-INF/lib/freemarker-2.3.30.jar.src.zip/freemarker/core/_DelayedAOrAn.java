/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _DelayedAOrAn
/*    */   extends _DelayedConversionToString
/*    */ {
/*    */   public _DelayedAOrAn(Object object) {
/* 26 */     super(object);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String doConversion(Object obj) {
/* 31 */     String s = obj.toString();
/* 32 */     return _MessageUtil.getAOrAn(s) + " " + s;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_DelayedAOrAn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */