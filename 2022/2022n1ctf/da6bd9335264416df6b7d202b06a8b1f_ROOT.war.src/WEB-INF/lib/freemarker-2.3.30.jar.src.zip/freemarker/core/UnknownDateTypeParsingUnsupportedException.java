/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnknownDateTypeParsingUnsupportedException
/*    */   extends UnformattableValueException
/*    */ {
/*    */   public UnknownDateTypeParsingUnsupportedException() {
/* 33 */     super("Can't parse the string to date-like value because it isn't known if it's desired result should be a date (no time part), a time, or a date-time value.");
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\UnknownDateTypeParsingUnsupportedException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */