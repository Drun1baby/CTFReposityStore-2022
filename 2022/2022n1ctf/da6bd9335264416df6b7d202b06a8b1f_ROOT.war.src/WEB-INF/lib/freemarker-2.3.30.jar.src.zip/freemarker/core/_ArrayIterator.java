/*    */ package freemarker.core;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _ArrayIterator
/*    */   implements Iterator
/*    */ {
/*    */   private final Object[] array;
/*    */   private int nextIndex;
/*    */   
/*    */   public _ArrayIterator(Object[] array) {
/* 32 */     this.array = array;
/* 33 */     this.nextIndex = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 38 */     return (this.nextIndex < this.array.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object next() {
/* 43 */     if (this.nextIndex >= this.array.length) {
/* 44 */       throw new NoSuchElementException();
/*    */     }
/* 46 */     return this.array[this.nextIndex++];
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove() {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_ArrayIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */