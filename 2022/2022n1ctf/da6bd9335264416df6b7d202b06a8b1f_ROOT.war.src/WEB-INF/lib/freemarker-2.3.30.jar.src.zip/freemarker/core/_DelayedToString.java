/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _DelayedToString
/*    */   extends _DelayedConversionToString
/*    */ {
/*    */   public _DelayedToString(Object object) {
/* 25 */     super(object);
/*    */   }
/*    */   
/*    */   public _DelayedToString(int object) {
/* 29 */     super(Integer.valueOf(object));
/*    */   }
/*    */ 
/*    */   
/*    */   protected String doConversion(Object obj) {
/* 34 */     return String.valueOf(obj);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_DelayedToString.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */