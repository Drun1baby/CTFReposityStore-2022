/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlainTextOutputFormat
/*    */   extends OutputFormat
/*    */ {
/* 35 */   public static final PlainTextOutputFormat INSTANCE = new PlainTextOutputFormat();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isOutputFormatMixingAllowed() {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 48 */     return "plainText";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMimeType() {
/* 53 */     return "text/plain";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\PlainTextOutputFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */