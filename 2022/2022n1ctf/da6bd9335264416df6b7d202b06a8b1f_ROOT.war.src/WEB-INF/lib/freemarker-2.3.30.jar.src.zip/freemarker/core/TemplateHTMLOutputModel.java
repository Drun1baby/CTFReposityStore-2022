/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateHTMLOutputModel
/*    */   extends CommonTemplateMarkupOutputModel<TemplateHTMLOutputModel>
/*    */ {
/*    */   protected TemplateHTMLOutputModel(String plainTextContent, String markupContent) {
/* 35 */     super(plainTextContent, markupContent);
/*    */   }
/*    */ 
/*    */   
/*    */   public HTMLOutputFormat getOutputFormat() {
/* 40 */     return HTMLOutputFormat.INSTANCE;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateHTMLOutputModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */