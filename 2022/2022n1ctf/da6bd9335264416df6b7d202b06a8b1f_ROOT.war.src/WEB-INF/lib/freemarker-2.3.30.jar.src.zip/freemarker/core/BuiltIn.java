/*     */ package freemarker.core;
/*     */ 
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import freemarker.template.TemplateNumberModel;
/*     */ import freemarker.template.TemplateScalarModel;
/*     */ import freemarker.template.utility.StringUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BuiltIn
/*     */   extends Expression
/*     */   implements Cloneable
/*     */ {
/*     */   protected Expression target;
/*     */   protected String key;
/*  85 */   static final Set<String> CAMEL_CASE_NAMES = new TreeSet<>();
/*  86 */   static final Set<String> SNAKE_CASE_NAMES = new TreeSet<>();
/*     */   static final int NUMBER_OF_BIS = 289;
/*  88 */   static final HashMap<String, BuiltIn> BUILT_INS_BY_NAME = new HashMap<>(434, 1.0F);
/*     */   
/*     */   static final String BI_NAME_SNAKE_CASE_WITH_ARGS = "with_args";
/*     */   
/*     */   static final String BI_NAME_CAMEL_CASE_WITH_ARGS = "withArgs";
/*     */   
/*     */   static final String BI_NAME_SNAKE_CASE_WITH_ARGS_LAST = "with_args_last";
/*     */   static final String BI_NAME_CAMEL_CASE_WITH_ARGS_LAST = "withArgsLast";
/*     */   
/*     */   static {
/*  98 */     putBI("abs", new BuiltInsForNumbers.absBI());
/*  99 */     putBI("absolute_template_name", "absoluteTemplateName", new BuiltInsForStringsMisc.absolute_template_nameBI());
/* 100 */     putBI("ancestors", new BuiltInsForNodes.ancestorsBI());
/* 101 */     putBI("api", new BuiltInsForMultipleTypes.apiBI());
/* 102 */     putBI("boolean", new BuiltInsForStringsMisc.booleanBI());
/* 103 */     putBI("byte", new BuiltInsForNumbers.byteBI());
/* 104 */     putBI("c", new BuiltInsForMultipleTypes.cBI());
/* 105 */     putBI("cap_first", "capFirst", new BuiltInsForStringsBasic.cap_firstBI());
/* 106 */     putBI("capitalize", new BuiltInsForStringsBasic.capitalizeBI());
/* 107 */     putBI("ceiling", new BuiltInsForNumbers.ceilingBI());
/* 108 */     putBI("children", new BuiltInsForNodes.childrenBI());
/* 109 */     putBI("chop_linebreak", "chopLinebreak", new BuiltInsForStringsBasic.chop_linebreakBI());
/* 110 */     putBI("contains", new BuiltInsForStringsBasic.containsBI());
/* 111 */     putBI("date", new BuiltInsForMultipleTypes.dateBI(2));
/* 112 */     putBI("date_if_unknown", "dateIfUnknown", new BuiltInsForDates.dateType_if_unknownBI(2));
/* 113 */     putBI("datetime", new BuiltInsForMultipleTypes.dateBI(3));
/* 114 */     putBI("datetime_if_unknown", "datetimeIfUnknown", new BuiltInsForDates.dateType_if_unknownBI(3));
/* 115 */     putBI("default", new BuiltInsForExistenceHandling.defaultBI());
/* 116 */     putBI("double", new BuiltInsForNumbers.doubleBI());
/* 117 */     putBI("drop_while", "dropWhile", new BuiltInsForSequences.drop_whileBI());
/* 118 */     putBI("ends_with", "endsWith", new BuiltInsForStringsBasic.ends_withBI());
/* 119 */     putBI("ensure_ends_with", "ensureEndsWith", new BuiltInsForStringsBasic.ensure_ends_withBI());
/* 120 */     putBI("ensure_starts_with", "ensureStartsWith", new BuiltInsForStringsBasic.ensure_starts_withBI());
/* 121 */     putBI("esc", new BuiltInsForOutputFormatRelated.escBI());
/* 122 */     putBI("eval", new BuiltInsForStringsMisc.evalBI());
/* 123 */     putBI("exists", new BuiltInsForExistenceHandling.existsBI());
/* 124 */     putBI("filter", new BuiltInsForSequences.filterBI());
/* 125 */     putBI("first", new BuiltInsForSequences.firstBI());
/* 126 */     putBI("float", new BuiltInsForNumbers.floatBI());
/* 127 */     putBI("floor", new BuiltInsForNumbers.floorBI());
/* 128 */     putBI("chunk", new BuiltInsForSequences.chunkBI());
/* 129 */     putBI("counter", new BuiltInsForLoopVariables.counterBI());
/* 130 */     putBI("item_cycle", "itemCycle", new BuiltInsForLoopVariables.item_cycleBI());
/* 131 */     putBI("has_api", "hasApi", new BuiltInsForMultipleTypes.has_apiBI());
/* 132 */     putBI("has_content", "hasContent", new BuiltInsForExistenceHandling.has_contentBI());
/* 133 */     putBI("has_next", "hasNext", new BuiltInsForLoopVariables.has_nextBI());
/* 134 */     putBI("html", new BuiltInsForStringsEncoding.htmlBI());
/* 135 */     putBI("if_exists", "ifExists", new BuiltInsForExistenceHandling.if_existsBI());
/* 136 */     putBI("index", new BuiltInsForLoopVariables.indexBI());
/* 137 */     putBI("index_of", "indexOf", new BuiltInsForStringsBasic.index_ofBI(false));
/* 138 */     putBI("int", new BuiltInsForNumbers.intBI());
/* 139 */     putBI("interpret", new Interpret());
/* 140 */     putBI("is_boolean", "isBoolean", new BuiltInsForMultipleTypes.is_booleanBI());
/* 141 */     putBI("is_collection", "isCollection", new BuiltInsForMultipleTypes.is_collectionBI());
/* 142 */     putBI("is_collection_ex", "isCollectionEx", new BuiltInsForMultipleTypes.is_collection_exBI());
/* 143 */     BuiltInsForMultipleTypes.is_dateLikeBI bi = new BuiltInsForMultipleTypes.is_dateLikeBI();
/* 144 */     putBI("is_date", "isDate", bi);
/* 145 */     putBI("is_date_like", "isDateLike", bi);
/* 146 */     putBI("is_date_only", "isDateOnly", new BuiltInsForMultipleTypes.is_dateOfTypeBI(2));
/* 147 */     putBI("is_even_item", "isEvenItem", new BuiltInsForLoopVariables.is_even_itemBI());
/* 148 */     putBI("is_first", "isFirst", new BuiltInsForLoopVariables.is_firstBI());
/* 149 */     putBI("is_last", "isLast", new BuiltInsForLoopVariables.is_lastBI());
/* 150 */     putBI("is_unknown_date_like", "isUnknownDateLike", new BuiltInsForMultipleTypes.is_dateOfTypeBI(0));
/* 151 */     putBI("is_datetime", "isDatetime", new BuiltInsForMultipleTypes.is_dateOfTypeBI(3));
/* 152 */     putBI("is_directive", "isDirective", new BuiltInsForMultipleTypes.is_directiveBI());
/* 153 */     putBI("is_enumerable", "isEnumerable", new BuiltInsForMultipleTypes.is_enumerableBI());
/* 154 */     putBI("is_hash_ex", "isHashEx", new BuiltInsForMultipleTypes.is_hash_exBI());
/* 155 */     putBI("is_hash", "isHash", new BuiltInsForMultipleTypes.is_hashBI());
/* 156 */     putBI("is_infinite", "isInfinite", new BuiltInsForNumbers.is_infiniteBI());
/* 157 */     putBI("is_indexable", "isIndexable", new BuiltInsForMultipleTypes.is_indexableBI());
/* 158 */     putBI("is_macro", "isMacro", new BuiltInsForMultipleTypes.is_macroBI());
/* 159 */     putBI("is_markup_output", "isMarkupOutput", new BuiltInsForMultipleTypes.is_markup_outputBI());
/* 160 */     putBI("is_method", "isMethod", new BuiltInsForMultipleTypes.is_methodBI());
/* 161 */     putBI("is_nan", "isNan", new BuiltInsForNumbers.is_nanBI());
/* 162 */     putBI("is_node", "isNode", new BuiltInsForMultipleTypes.is_nodeBI());
/* 163 */     putBI("is_number", "isNumber", new BuiltInsForMultipleTypes.is_numberBI());
/* 164 */     putBI("is_odd_item", "isOddItem", new BuiltInsForLoopVariables.is_odd_itemBI());
/* 165 */     putBI("is_sequence", "isSequence", new BuiltInsForMultipleTypes.is_sequenceBI());
/* 166 */     putBI("is_string", "isString", new BuiltInsForMultipleTypes.is_stringBI());
/* 167 */     putBI("is_time", "isTime", new BuiltInsForMultipleTypes.is_dateOfTypeBI(1));
/* 168 */     putBI("is_transform", "isTransform", new BuiltInsForMultipleTypes.is_transformBI());
/*     */     
/* 170 */     putBI("iso_utc", "isoUtc", new BuiltInsForDates.iso_utc_or_local_BI(null, 6, true));
/*     */     
/* 172 */     putBI("iso_utc_fz", "isoUtcFZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.TRUE, 6, true));
/*     */     
/* 174 */     putBI("iso_utc_nz", "isoUtcNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 6, true));
/*     */ 
/*     */     
/* 177 */     putBI("iso_utc_ms", "isoUtcMs", new BuiltInsForDates.iso_utc_or_local_BI(null, 7, true));
/*     */     
/* 179 */     putBI("iso_utc_ms_nz", "isoUtcMsNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 7, true));
/*     */ 
/*     */     
/* 182 */     putBI("iso_utc_m", "isoUtcM", new BuiltInsForDates.iso_utc_or_local_BI(null, 5, true));
/*     */     
/* 184 */     putBI("iso_utc_m_nz", "isoUtcMNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 5, true));
/*     */ 
/*     */     
/* 187 */     putBI("iso_utc_h", "isoUtcH", new BuiltInsForDates.iso_utc_or_local_BI(null, 4, true));
/*     */     
/* 189 */     putBI("iso_utc_h_nz", "isoUtcHNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 4, true));
/*     */ 
/*     */     
/* 192 */     putBI("iso_local", "isoLocal", new BuiltInsForDates.iso_utc_or_local_BI(null, 6, false));
/*     */     
/* 194 */     putBI("iso_local_nz", "isoLocalNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 6, false));
/*     */ 
/*     */     
/* 197 */     putBI("iso_local_ms", "isoLocalMs", new BuiltInsForDates.iso_utc_or_local_BI(null, 7, false));
/*     */     
/* 199 */     putBI("iso_local_ms_nz", "isoLocalMsNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 7, false));
/*     */ 
/*     */     
/* 202 */     putBI("iso_local_m", "isoLocalM", new BuiltInsForDates.iso_utc_or_local_BI(null, 5, false));
/*     */     
/* 204 */     putBI("iso_local_m_nz", "isoLocalMNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 5, false));
/*     */ 
/*     */     
/* 207 */     putBI("iso_local_h", "isoLocalH", new BuiltInsForDates.iso_utc_or_local_BI(null, 4, false));
/*     */     
/* 209 */     putBI("iso_local_h_nz", "isoLocalHNZ", new BuiltInsForDates.iso_utc_or_local_BI(Boolean.FALSE, 4, false));
/*     */ 
/*     */     
/* 212 */     putBI("iso", new BuiltInsForDates.iso_BI(null, 6));
/*     */     
/* 214 */     putBI("iso_nz", "isoNZ", new BuiltInsForDates.iso_BI(Boolean.FALSE, 6));
/*     */ 
/*     */     
/* 217 */     putBI("iso_ms", "isoMs", new BuiltInsForDates.iso_BI(null, 7));
/*     */     
/* 219 */     putBI("iso_ms_nz", "isoMsNZ", new BuiltInsForDates.iso_BI(Boolean.FALSE, 7));
/*     */ 
/*     */     
/* 222 */     putBI("iso_m", "isoM", new BuiltInsForDates.iso_BI(null, 5));
/*     */     
/* 224 */     putBI("iso_m_nz", "isoMNZ", new BuiltInsForDates.iso_BI(Boolean.FALSE, 5));
/*     */ 
/*     */     
/* 227 */     putBI("iso_h", "isoH", new BuiltInsForDates.iso_BI(null, 4));
/*     */     
/* 229 */     putBI("iso_h_nz", "isoHNZ", new BuiltInsForDates.iso_BI(Boolean.FALSE, 4));
/*     */ 
/*     */     
/* 232 */     putBI("j_string", "jString", new BuiltInsForStringsEncoding.j_stringBI());
/* 233 */     putBI("join", new BuiltInsForSequences.joinBI());
/* 234 */     putBI("js_string", "jsString", new BuiltInsForStringsEncoding.js_stringBI());
/* 235 */     putBI("json_string", "jsonString", new BuiltInsForStringsEncoding.json_stringBI());
/* 236 */     putBI("keep_after", "keepAfter", new BuiltInsForStringsBasic.keep_afterBI());
/* 237 */     putBI("keep_before", "keepBefore", new BuiltInsForStringsBasic.keep_beforeBI());
/* 238 */     putBI("keep_after_last", "keepAfterLast", new BuiltInsForStringsBasic.keep_after_lastBI());
/* 239 */     putBI("keep_before_last", "keepBeforeLast", new BuiltInsForStringsBasic.keep_before_lastBI());
/* 240 */     putBI("keys", new BuiltInsForHashes.keysBI());
/* 241 */     putBI("last_index_of", "lastIndexOf", new BuiltInsForStringsBasic.index_ofBI(true));
/* 242 */     putBI("last", new BuiltInsForSequences.lastBI());
/* 243 */     putBI("left_pad", "leftPad", new BuiltInsForStringsBasic.padBI(true));
/* 244 */     putBI("length", new BuiltInsForStringsBasic.lengthBI());
/* 245 */     putBI("long", new BuiltInsForNumbers.longBI());
/* 246 */     putBI("lower_abc", "lowerAbc", new BuiltInsForNumbers.lower_abcBI());
/* 247 */     putBI("lower_case", "lowerCase", new BuiltInsForStringsBasic.lower_caseBI());
/* 248 */     putBI("map", new BuiltInsForSequences.mapBI());
/* 249 */     putBI("namespace", new BuiltInsForMultipleTypes.namespaceBI());
/* 250 */     putBI("new", new NewBI());
/* 251 */     putBI("markup_string", "markupString", new BuiltInsForMarkupOutputs.markup_stringBI());
/* 252 */     putBI("node_name", "nodeName", new BuiltInsForNodes.node_nameBI());
/* 253 */     putBI("node_namespace", "nodeNamespace", new BuiltInsForNodes.node_namespaceBI());
/* 254 */     putBI("node_type", "nodeType", new BuiltInsForNodes.node_typeBI());
/* 255 */     putBI("no_esc", "noEsc", new BuiltInsForOutputFormatRelated.no_escBI());
/* 256 */     putBI("max", new BuiltInsForSequences.maxBI());
/* 257 */     putBI("min", new BuiltInsForSequences.minBI());
/* 258 */     putBI("number", new BuiltInsForStringsMisc.numberBI());
/* 259 */     putBI("number_to_date", "numberToDate", new BuiltInsForNumbers.number_to_dateBI(2));
/* 260 */     putBI("number_to_time", "numberToTime", new BuiltInsForNumbers.number_to_dateBI(1));
/* 261 */     putBI("number_to_datetime", "numberToDatetime", new BuiltInsForNumbers.number_to_dateBI(3));
/* 262 */     putBI("parent", new BuiltInsForNodes.parentBI());
/* 263 */     putBI("previous_sibling", "previousSibling", new BuiltInsForNodes.previousSiblingBI());
/* 264 */     putBI("next_sibling", "nextSibling", new BuiltInsForNodes.nextSiblingBI());
/* 265 */     putBI("item_parity", "itemParity", new BuiltInsForLoopVariables.item_parityBI());
/* 266 */     putBI("item_parity_cap", "itemParityCap", new BuiltInsForLoopVariables.item_parity_capBI());
/* 267 */     putBI("reverse", new BuiltInsForSequences.reverseBI());
/* 268 */     putBI("right_pad", "rightPad", new BuiltInsForStringsBasic.padBI(false));
/* 269 */     putBI("root", new BuiltInsForNodes.rootBI());
/* 270 */     putBI("round", new BuiltInsForNumbers.roundBI());
/* 271 */     putBI("remove_ending", "removeEnding", new BuiltInsForStringsBasic.remove_endingBI());
/* 272 */     putBI("remove_beginning", "removeBeginning", new BuiltInsForStringsBasic.remove_beginningBI());
/* 273 */     putBI("rtf", new BuiltInsForStringsEncoding.rtfBI());
/* 274 */     putBI("seq_contains", "seqContains", new BuiltInsForSequences.seq_containsBI());
/* 275 */     putBI("seq_index_of", "seqIndexOf", new BuiltInsForSequences.seq_index_ofBI(true));
/* 276 */     putBI("seq_last_index_of", "seqLastIndexOf", new BuiltInsForSequences.seq_index_ofBI(false));
/* 277 */     putBI("sequence", new BuiltInsForSequences.sequenceBI());
/* 278 */     putBI("short", new BuiltInsForNumbers.shortBI());
/* 279 */     putBI("size", new BuiltInsForMultipleTypes.sizeBI());
/* 280 */     putBI("sort_by", "sortBy", new BuiltInsForSequences.sort_byBI());
/* 281 */     putBI("sort", new BuiltInsForSequences.sortBI());
/* 282 */     putBI("split", new BuiltInsForStringsBasic.split_BI());
/* 283 */     putBI("switch", new BuiltInsWithLazyConditionals.switch_BI());
/* 284 */     putBI("starts_with", "startsWith", new BuiltInsForStringsBasic.starts_withBI());
/* 285 */     putBI("string", new BuiltInsForMultipleTypes.stringBI());
/* 286 */     putBI("substring", new BuiltInsForStringsBasic.substringBI());
/* 287 */     putBI("take_while", "takeWhile", new BuiltInsForSequences.take_whileBI());
/* 288 */     putBI("then", new BuiltInsWithLazyConditionals.then_BI());
/* 289 */     putBI("time", new BuiltInsForMultipleTypes.dateBI(1));
/* 290 */     putBI("time_if_unknown", "timeIfUnknown", new BuiltInsForDates.dateType_if_unknownBI(1));
/* 291 */     putBI("trim", new BuiltInsForStringsBasic.trimBI());
/* 292 */     putBI("truncate", new BuiltInsForStringsBasic.truncateBI());
/* 293 */     putBI("truncate_w", "truncateW", new BuiltInsForStringsBasic.truncate_wBI());
/* 294 */     putBI("truncate_c", "truncateC", new BuiltInsForStringsBasic.truncate_cBI());
/* 295 */     putBI("truncate_m", "truncateM", new BuiltInsForStringsBasic.truncate_mBI());
/* 296 */     putBI("truncate_w_m", "truncateWM", new BuiltInsForStringsBasic.truncate_w_mBI());
/* 297 */     putBI("truncate_c_m", "truncateCM", new BuiltInsForStringsBasic.truncate_c_mBI());
/* 298 */     putBI("uncap_first", "uncapFirst", new BuiltInsForStringsBasic.uncap_firstBI());
/* 299 */     putBI("upper_abc", "upperAbc", new BuiltInsForNumbers.upper_abcBI());
/* 300 */     putBI("upper_case", "upperCase", new BuiltInsForStringsBasic.upper_caseBI());
/* 301 */     putBI("url", new BuiltInsForStringsEncoding.urlBI());
/* 302 */     putBI("url_path", "urlPath", new BuiltInsForStringsEncoding.urlPathBI());
/* 303 */     putBI("values", new BuiltInsForHashes.valuesBI());
/* 304 */     putBI("web_safe", "webSafe", BUILT_INS_BY_NAME.get("html"));
/* 305 */     putBI("with_args", "withArgs", new BuiltInsForCallables.with_argsBI());
/*     */     
/* 307 */     putBI("with_args_last", "withArgsLast", new BuiltInsForCallables.with_args_lastBI());
/*     */     
/* 309 */     putBI("word_list", "wordList", new BuiltInsForStringsBasic.word_listBI());
/* 310 */     putBI("xhtml", new BuiltInsForStringsEncoding.xhtmlBI());
/* 311 */     putBI("xml", new BuiltInsForStringsEncoding.xmlBI());
/* 312 */     putBI("matches", new BuiltInsForStringsRegexp.matchesBI());
/* 313 */     putBI("groups", new BuiltInsForStringsRegexp.groupsBI());
/* 314 */     putBI("replace", new BuiltInsForStringsRegexp.replace_reBI());
/*     */ 
/*     */     
/* 317 */     if (289 < BUILT_INS_BY_NAME.size()) {
/* 318 */       throw new AssertionError("Update NUMBER_OF_BIS! Should be: " + BUILT_INS_BY_NAME.size());
/*     */     }
/*     */   }
/*     */   
/*     */   private static void putBI(String name, BuiltIn bi) {
/* 323 */     BUILT_INS_BY_NAME.put(name, bi);
/* 324 */     SNAKE_CASE_NAMES.add(name);
/* 325 */     CAMEL_CASE_NAMES.add(name);
/*     */   }
/*     */   
/*     */   private static void putBI(String nameSnakeCase, String nameCamelCase, BuiltIn bi) {
/* 329 */     BUILT_INS_BY_NAME.put(nameSnakeCase, bi);
/* 330 */     BUILT_INS_BY_NAME.put(nameCamelCase, bi);
/* 331 */     SNAKE_CASE_NAMES.add(nameSnakeCase);
/* 332 */     CAMEL_CASE_NAMES.add(nameCamelCase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BuiltIn newBuiltIn(int incompatibleImprovements, Expression target, Token keyTk, FMParserTokenManager tokenManager) throws ParseException {
/* 343 */     String key = keyTk.image;
/* 344 */     BuiltIn bi = BUILT_INS_BY_NAME.get(key);
/* 345 */     if (bi == null) {
/* 346 */       StringBuilder buf = (new StringBuilder("Unknown built-in: ")).append(StringUtil.jQuote(key)).append(". ");
/*     */       
/* 348 */       buf.append("Help (latest version): https://freemarker.apache.org/docs/ref_builtins.html; you're using FreeMarker ")
/*     */         
/* 350 */         .append(Configuration.getVersion()).append(".\nThe alphabetical list of built-ins:");
/*     */       
/* 352 */       List<Comparable> names = new ArrayList(BUILT_INS_BY_NAME.keySet().size());
/* 353 */       names.addAll(BUILT_INS_BY_NAME.keySet());
/* 354 */       Collections.sort(names);
/* 355 */       char lastLetter = Character.MIN_VALUE;
/*     */ 
/*     */ 
/*     */       
/* 359 */       int namingConvention = tokenManager.namingConvention;
/* 360 */       int shownNamingConvention = (namingConvention != 10) ? namingConvention : 11;
/*     */ 
/*     */ 
/*     */       
/* 364 */       boolean first = true;
/* 365 */       for (Iterator<Comparable> it = names.iterator(); it.hasNext(); ) {
/* 366 */         String correctName = (String)it.next();
/* 367 */         int correctNameNamingConvetion = _CoreStringUtils.getIdentifierNamingConvention(correctName);
/* 368 */         if ((shownNamingConvention == 12) ? (correctNameNamingConvetion != 11) : (correctNameNamingConvetion != 12)) {
/*     */ 
/*     */           
/* 371 */           if (first) {
/* 372 */             first = false;
/*     */           } else {
/* 374 */             buf.append(", ");
/*     */           } 
/*     */           
/* 377 */           char firstChar = correctName.charAt(0);
/* 378 */           if (firstChar != lastLetter) {
/* 379 */             lastLetter = firstChar;
/* 380 */             buf.append('\n');
/*     */           } 
/* 382 */           buf.append(correctName);
/*     */         } 
/*     */       } 
/*     */       
/* 386 */       throw new ParseException(buf.toString(), null, keyTk);
/*     */     } 
/*     */     
/* 389 */     while (bi instanceof ICIChainMember && incompatibleImprovements < ((ICIChainMember)bi)
/* 390 */       .getMinimumICIVersion()) {
/* 391 */       bi = (BuiltIn)((ICIChainMember)bi).getPreviousICIChainMember();
/*     */     }
/*     */     
/*     */     try {
/* 395 */       bi = (BuiltIn)bi.clone();
/* 396 */     } catch (CloneNotSupportedException e) {
/* 397 */       throw new InternalError();
/*     */     } 
/* 399 */     bi.key = key;
/* 400 */     bi.setTarget(target);
/* 401 */     return bi;
/*     */   }
/*     */   
/*     */   protected void setTarget(Expression target) {
/* 405 */     this.target = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCanonicalForm() {
/* 410 */     return this.target.getCanonicalForm() + "?" + this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   String getNodeTypeSymbol() {
/* 415 */     return "?" + this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isLiteral() {
/* 420 */     return false;
/*     */   }
/*     */   
/*     */   protected final void checkMethodArgCount(List args, int expectedCnt) throws TemplateModelException {
/* 424 */     checkMethodArgCount(args.size(), expectedCnt);
/*     */   }
/*     */   
/*     */   protected final void checkMethodArgCount(int argCnt, int expectedCnt) throws TemplateModelException {
/* 428 */     if (argCnt != expectedCnt) {
/* 429 */       throw _MessageUtil.newArgCntError("?" + this.key, argCnt, expectedCnt);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void checkMethodArgCount(List args, int minCnt, int maxCnt) throws TemplateModelException {
/* 434 */     checkMethodArgCount(args.size(), minCnt, maxCnt);
/*     */   }
/*     */   
/*     */   protected final void checkMethodArgCount(int argCnt, int minCnt, int maxCnt) throws TemplateModelException {
/* 438 */     if (argCnt < minCnt || argCnt > maxCnt) {
/* 439 */       throw _MessageUtil.newArgCntError("?" + this.key, argCnt, minCnt, maxCnt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getOptStringMethodArg(List args, int argIdx) throws TemplateModelException {
/* 449 */     return (args.size() > argIdx) ? getStringMethodArg(args, argIdx) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getStringMethodArg(List<TemplateModel> args, int argIdx) throws TemplateModelException {
/* 457 */     TemplateModel arg = args.get(argIdx);
/* 458 */     if (!(arg instanceof TemplateScalarModel)) {
/* 459 */       throw _MessageUtil.newMethodArgMustBeStringException("?" + this.key, argIdx, arg);
/*     */     }
/* 461 */     return EvalUtil.modelToString((TemplateScalarModel)arg, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Number getOptNumberMethodArg(List args, int argIdx) throws TemplateModelException {
/* 470 */     return (args.size() > argIdx) ? getNumberMethodArg(args, argIdx) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Number getNumberMethodArg(List<TemplateModel> args, int argIdx) throws TemplateModelException {
/* 478 */     TemplateModel arg = args.get(argIdx);
/* 479 */     if (!(arg instanceof TemplateNumberModel)) {
/* 480 */       throw _MessageUtil.newMethodArgMustBeNumberException("?" + this.key, argIdx, arg);
/*     */     }
/* 482 */     return EvalUtil.modelToNumber((TemplateNumberModel)arg, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final TemplateModelException newMethodArgInvalidValueException(int argIdx, Object[] details) {
/* 487 */     return _MessageUtil.newMethodArgInvalidValueException("?" + this.key, argIdx, details);
/*     */   }
/*     */   
/*     */   protected final TemplateModelException newMethodArgsInvalidValueException(Object[] details) {
/* 491 */     return _MessageUtil.newMethodArgsInvalidValueException("?" + this.key, details);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Expression deepCloneWithIdentifierReplaced_inner(String replacedIdentifier, Expression replacement, Expression.ReplacemenetState replacementState) {
/*     */     try {
/* 498 */       BuiltIn clone = (BuiltIn)clone();
/* 499 */       clone.target = this.target.deepCloneWithIdentifierReplaced(replacedIdentifier, replacement, replacementState);
/* 500 */       return clone;
/* 501 */     } catch (CloneNotSupportedException e) {
/* 502 */       throw new RuntimeException("Internal error: " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   int getParameterCount() {
/* 508 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   Object getParameterValue(int idx) {
/* 513 */     switch (idx) { case 0:
/* 514 */         return this.target;
/* 515 */       case 1: return this.key; }
/* 516 */      throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ParameterRole getParameterRole(int idx) {
/* 522 */     switch (idx) { case 0:
/* 523 */         return ParameterRole.LEFT_HAND_OPERAND;
/* 524 */       case 1: return ParameterRole.RIGHT_HAND_OPERAND; }
/* 525 */      throw new IndexOutOfBoundsException();
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\BuiltIn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */