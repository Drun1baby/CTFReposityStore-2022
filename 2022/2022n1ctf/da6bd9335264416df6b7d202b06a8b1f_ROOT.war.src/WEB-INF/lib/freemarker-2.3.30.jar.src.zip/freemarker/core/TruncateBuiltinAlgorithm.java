package freemarker.core;

import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateScalarModel;

public abstract class TruncateBuiltinAlgorithm {
  public abstract TemplateModel truncateM(String paramString, int paramInt, TemplateModel paramTemplateModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
  
  public abstract TemplateScalarModel truncate(String paramString, int paramInt, TemplateScalarModel paramTemplateScalarModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
  
  public abstract TemplateScalarModel truncateW(String paramString, int paramInt, TemplateScalarModel paramTemplateScalarModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
  
  public abstract TemplateModel truncateWM(String paramString, int paramInt, TemplateModel paramTemplateModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
  
  public abstract TemplateScalarModel truncateC(String paramString, int paramInt, TemplateScalarModel paramTemplateScalarModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
  
  public abstract TemplateModel truncateCM(String paramString, int paramInt, TemplateModel paramTemplateModel, Integer paramInteger, Environment paramEnvironment) throws TemplateException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TruncateBuiltinAlgorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */