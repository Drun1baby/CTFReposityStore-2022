/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateModelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _MarkupBuilder<MO extends TemplateMarkupOutputModel>
/*    */ {
/*    */   private final String markupSource;
/*    */   private final MarkupOutputFormat<MO> markupOutputFormat;
/*    */   
/*    */   public _MarkupBuilder(MarkupOutputFormat<MO> markupOutputFormat, String markupSource) {
/* 36 */     this.markupOutputFormat = markupOutputFormat;
/* 37 */     this.markupSource = markupSource;
/*    */   }
/*    */   
/*    */   public MO build() throws TemplateModelException {
/* 41 */     return this.markupOutputFormat.fromMarkup(this.markupSource);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_MarkupBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */