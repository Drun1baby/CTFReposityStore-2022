/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateException;
/*    */ import freemarker.template.TemplateModel;
/*    */ import freemarker.template.TemplateModelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class BuiltInForNumber
/*    */   extends BuiltIn
/*    */ {
/*    */   TemplateModel _eval(Environment env) throws TemplateException {
/* 30 */     TemplateModel model = this.target.eval(env);
/* 31 */     return calculateResult(this.target.modelToNumber(model, env), model);
/*    */   }
/*    */   
/*    */   abstract TemplateModel calculateResult(Number paramNumber, TemplateModel paramTemplateModel) throws TemplateModelException;
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\BuiltInForNumber.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */