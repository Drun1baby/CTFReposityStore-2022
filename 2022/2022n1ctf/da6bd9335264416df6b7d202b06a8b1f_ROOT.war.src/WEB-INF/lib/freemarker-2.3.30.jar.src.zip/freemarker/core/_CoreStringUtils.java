/*     */ package freemarker.core;
/*     */ 
/*     */ import freemarker.template.utility.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class _CoreStringUtils
/*     */ {
/*     */   public static String toFTLIdentifierReferenceAfterDot(String name) {
/*  37 */     return backslashEscapeIdentifier(name);
/*     */   }
/*     */   
/*     */   public static String toFTLTopLevelIdentifierReference(String name) {
/*  41 */     return backslashEscapeIdentifier(name);
/*     */   }
/*     */   
/*     */   public static String toFTLTopLevelTragetIdentifier(String name) {
/*  45 */     char quotationType = Character.MIN_VALUE;
/*  46 */     for (int i = 0; i < name.length(); i++) {
/*  47 */       char c = name.charAt(i);
/*  48 */       if (((i == 0) ? StringUtil.isFTLIdentifierStart(c) : StringUtil.isFTLIdentifierPart(c)) && c != '@') {
/*  49 */         if ((quotationType == '\000' || quotationType == '\\') && (c == '-' || c == '.' || c == ':')) {
/*  50 */           quotationType = '\\';
/*     */         } else {
/*  52 */           quotationType = '"';
/*     */           break;
/*     */         } 
/*     */       }
/*     */     } 
/*  57 */     switch (quotationType) {
/*     */       case '\000':
/*  59 */         return name;
/*     */       case '"':
/*  61 */         return StringUtil.ftlQuote(name);
/*     */       case '\\':
/*  63 */         return backslashEscapeIdentifier(name);
/*     */     } 
/*  65 */     throw new BugException();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String backslashEscapeIdentifier(String name) {
/*  70 */     return StringUtil.replace(StringUtil.replace(StringUtil.replace(name, "-", "\\-"), ".", "\\."), ":", "\\:");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getIdentifierNamingConvention(String name) {
/*  78 */     int ln = name.length();
/*  79 */     for (int i = 0; i < ln; i++) {
/*  80 */       char c = name.charAt(i);
/*  81 */       if (c == '_') {
/*  82 */         return 11;
/*     */       }
/*  84 */       if (isUpperUSASCII(c)) {
/*  85 */         return 12;
/*     */       }
/*     */     } 
/*  88 */     return 10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String camelCaseToUnderscored(String camelCaseName) {
/*  97 */     int i = 0;
/*  98 */     while (i < camelCaseName.length() && Character.isLowerCase(camelCaseName.charAt(i))) {
/*  99 */       i++;
/*     */     }
/* 101 */     if (i == camelCaseName.length())
/*     */     {
/* 103 */       return camelCaseName;
/*     */     }
/*     */     
/* 106 */     StringBuilder sb = new StringBuilder();
/* 107 */     sb.append(camelCaseName.substring(0, i));
/* 108 */     while (i < camelCaseName.length()) {
/* 109 */       char c = camelCaseName.charAt(i);
/* 110 */       if (isUpperUSASCII(c)) {
/* 111 */         sb.append('_');
/* 112 */         sb.append(Character.toLowerCase(c));
/*     */       } else {
/* 114 */         sb.append(c);
/*     */       } 
/* 116 */       i++;
/*     */     } 
/* 118 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static boolean isUpperUSASCII(char c) {
/* 122 */     return (c >= 'A' && c <= 'Z');
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_CoreStringUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */