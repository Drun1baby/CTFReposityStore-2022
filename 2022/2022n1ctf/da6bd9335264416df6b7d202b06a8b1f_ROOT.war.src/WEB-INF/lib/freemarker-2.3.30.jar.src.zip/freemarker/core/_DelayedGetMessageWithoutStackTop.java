/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _DelayedGetMessageWithoutStackTop
/*    */   extends _DelayedConversionToString
/*    */ {
/*    */   public _DelayedGetMessageWithoutStackTop(TemplateException exception) {
/* 28 */     super(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String doConversion(Object obj) {
/* 33 */     return ((TemplateException)obj).getMessageWithoutStackTop();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_DelayedGetMessageWithoutStackTop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */