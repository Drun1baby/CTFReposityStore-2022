package freemarker.core;

import java.util.Locale;

public abstract class TemplateNumberFormatFactory extends TemplateValueFormatFactory {
  public abstract TemplateNumberFormat get(String paramString, Locale paramLocale, Environment paramEnvironment) throws TemplateValueFormatException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateNumberFormatFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */