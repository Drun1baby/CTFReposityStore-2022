package freemarker.core;

import java.util.Locale;
import java.util.TimeZone;

public abstract class TemplateDateFormatFactory extends TemplateValueFormatFactory {
  public abstract TemplateDateFormat get(String paramString, int paramInt, Locale paramLocale, TimeZone paramTimeZone, boolean paramBoolean, Environment paramEnvironment) throws TemplateValueFormatException;
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateDateFormatFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */