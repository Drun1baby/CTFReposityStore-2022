/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.utility.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class _DelayedShortClassName
/*    */   extends _DelayedConversionToString
/*    */ {
/*    */   public _DelayedShortClassName(Class pClass) {
/* 27 */     super(pClass);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String doConversion(Object obj) {
/* 32 */     return ClassUtil.getShortClassName((Class)obj, true);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\_DelayedShortClassName.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */