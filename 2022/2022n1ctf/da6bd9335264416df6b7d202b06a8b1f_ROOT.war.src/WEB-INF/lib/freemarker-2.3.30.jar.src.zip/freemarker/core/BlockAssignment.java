/*     */ package freemarker.core;
/*     */ 
/*     */ import freemarker.template.SimpleScalar;
/*     */ import freemarker.template.TemplateException;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BlockAssignment
/*     */   extends TemplateElement
/*     */ {
/*     */   private final String varName;
/*     */   private final Expression namespaceExp;
/*     */   private final int scope;
/*     */   private final MarkupOutputFormat<?> markupOutputFormat;
/*     */   
/*     */   BlockAssignment(TemplateElements children, String varName, int scope, Expression namespaceExp, MarkupOutputFormat<?> markupOutputFormat) {
/*  41 */     setChildren(children);
/*  42 */     this.varName = varName;
/*  43 */     this.namespaceExp = namespaceExp;
/*  44 */     this.scope = scope;
/*  45 */     this.markupOutputFormat = markupOutputFormat;
/*     */   }
/*     */   
/*     */   TemplateElement[] accept(Environment env) throws TemplateException, IOException {
/*     */     TemplateModel value;
/*  50 */     TemplateElement[] children = getChildBuffer();
/*     */ 
/*     */     
/*  53 */     if (children != null) {
/*  54 */       StringWriter out = new StringWriter();
/*  55 */       env.visit(children, out);
/*  56 */       value = capturedStringToModel(out.toString());
/*     */     } else {
/*  58 */       value = capturedStringToModel("");
/*     */     } 
/*     */     
/*  61 */     if (this.namespaceExp != null) {
/*  62 */       ((Environment.Namespace)this.namespaceExp.eval(env)).put(this.varName, value);
/*  63 */     } else if (this.scope == 1) {
/*  64 */       env.setVariable(this.varName, value);
/*  65 */     } else if (this.scope == 3) {
/*  66 */       env.setGlobalVariable(this.varName, value);
/*  67 */     } else if (this.scope == 2) {
/*  68 */       env.setLocalVariable(this.varName, value);
/*     */     } else {
/*  70 */       throw new BugException("Unhandled scope");
/*     */     } 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   private TemplateModel capturedStringToModel(String s) throws TemplateModelException {
/*  77 */     return (this.markupOutputFormat == null) ? (TemplateModel)new SimpleScalar(s) : (TemplateModel)this.markupOutputFormat.fromMarkup(s);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String dump(boolean canonical) {
/*  82 */     StringBuilder sb = new StringBuilder();
/*  83 */     if (canonical) sb.append("<"); 
/*  84 */     sb.append(getNodeTypeSymbol());
/*  85 */     sb.append(' ');
/*  86 */     sb.append(this.varName);
/*  87 */     if (this.namespaceExp != null) {
/*  88 */       sb.append(" in ");
/*  89 */       sb.append(this.namespaceExp.getCanonicalForm());
/*     */     } 
/*  91 */     if (canonical) {
/*  92 */       sb.append('>');
/*  93 */       sb.append(getChildrenCanonicalForm());
/*  94 */       sb.append("</");
/*  95 */       sb.append(getNodeTypeSymbol());
/*  96 */       sb.append('>');
/*     */     } else {
/*  98 */       sb.append(" = .nested_output");
/*     */     } 
/* 100 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   String getNodeTypeSymbol() {
/* 105 */     return Assignment.getDirectiveName(this.scope);
/*     */   }
/*     */ 
/*     */   
/*     */   int getParameterCount() {
/* 110 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   Object getParameterValue(int idx) {
/* 115 */     switch (idx) { case 0:
/* 116 */         return this.varName;
/* 117 */       case 1: return Integer.valueOf(this.scope);
/* 118 */       case 2: return this.namespaceExp; }
/* 119 */      throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ParameterRole getParameterRole(int idx) {
/* 125 */     switch (idx) { case 0:
/* 126 */         return ParameterRole.ASSIGNMENT_TARGET;
/* 127 */       case 1: return ParameterRole.VARIABLE_SCOPE;
/* 128 */       case 2: return ParameterRole.NAMESPACE; }
/* 129 */      throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isNestedBlockRepeater() {
/* 135 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\BlockAssignment.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */