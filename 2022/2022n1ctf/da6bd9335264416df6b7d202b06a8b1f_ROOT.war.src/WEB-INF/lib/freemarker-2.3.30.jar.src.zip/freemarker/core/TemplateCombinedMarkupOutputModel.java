/*    */ package freemarker.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TemplateCombinedMarkupOutputModel
/*    */   extends CommonTemplateMarkupOutputModel<TemplateCombinedMarkupOutputModel>
/*    */ {
/*    */   private final CombinedMarkupOutputFormat outputFormat;
/*    */   
/*    */   TemplateCombinedMarkupOutputModel(String plainTextContent, String markupContent, CombinedMarkupOutputFormat outputFormat) {
/* 41 */     super(plainTextContent, markupContent);
/* 42 */     this.outputFormat = outputFormat;
/*    */   }
/*    */ 
/*    */   
/*    */   public CombinedMarkupOutputFormat getOutputFormat() {
/* 47 */     return this.outputFormat;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateCombinedMarkupOutputModel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */