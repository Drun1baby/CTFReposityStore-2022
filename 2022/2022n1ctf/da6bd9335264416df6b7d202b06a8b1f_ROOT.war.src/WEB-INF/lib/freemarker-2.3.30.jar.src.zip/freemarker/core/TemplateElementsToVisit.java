/*    */ package freemarker.core;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TemplateElementsToVisit
/*    */ {
/*    */   private final Collection<TemplateElement> templateElements;
/*    */   
/*    */   TemplateElementsToVisit(Collection<TemplateElement> templateElements) {
/* 37 */     this.templateElements = (null != templateElements) ? templateElements : Collections.<TemplateElement>emptyList();
/*    */   }
/*    */   
/*    */   TemplateElementsToVisit(TemplateElement nestedBlock) {
/* 41 */     this(Collections.singleton(nestedBlock));
/*    */   }
/*    */   
/*    */   Collection<TemplateElement> getTemplateElements() {
/* 45 */     return this.templateElements;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\TemplateElementsToVisit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */