package freemarker.core;

import freemarker.template.TemplateModelException;
import java.io.IOException;
import java.io.Writer;

public abstract class MarkupOutputFormat<MO extends TemplateMarkupOutputModel> extends OutputFormat {
  public abstract MO fromPlainTextByEscaping(String paramString) throws TemplateModelException;
  
  public abstract MO fromMarkup(String paramString) throws TemplateModelException;
  
  public abstract void output(MO paramMO, Writer paramWriter) throws IOException, TemplateModelException;
  
  public abstract void output(String paramString, Writer paramWriter) throws IOException, TemplateModelException;
  
  public abstract String getSourcePlainText(MO paramMO) throws TemplateModelException;
  
  public abstract String getMarkupString(MO paramMO) throws TemplateModelException;
  
  public abstract MO concat(MO paramMO1, MO paramMO2) throws TemplateModelException;
  
  public abstract String escapePlainText(String paramString) throws TemplateModelException;
  
  public abstract boolean isEmpty(MO paramMO) throws TemplateModelException;
  
  public abstract boolean isLegacyBuiltInBypassed(String paramString) throws TemplateModelException;
  
  public abstract boolean isAutoEscapedByDefault();
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\MarkupOutputFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */