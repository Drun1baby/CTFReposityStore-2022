/*    */ package freemarker.core;
/*    */ 
/*    */ import freemarker.template.TemplateModelException;
/*    */ import freemarker.template.TemplateModelIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LazilyGeneratedCollectionModelWithAlreadyKnownSize
/*    */   extends LazilyGeneratedCollectionModelEx
/*    */ {
/*    */   private final int size;
/*    */   
/*    */   LazilyGeneratedCollectionModelWithAlreadyKnownSize(TemplateModelIterator iterator, int size, boolean sequence) {
/* 29 */     super(iterator, sequence);
/* 30 */     this.size = size;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() throws TemplateModelException {
/* 35 */     return this.size;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 40 */     return (this.size == 0);
/*    */   }
/*    */ 
/*    */   
/*    */   protected LazilyGeneratedCollectionModel withIsSequenceFromFalseToTrue() {
/* 45 */     return new LazilyGeneratedCollectionModelWithAlreadyKnownSize(getIterator(), this.size, true);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\core\LazilyGeneratedCollectionModelWithAlreadyKnownSize.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */