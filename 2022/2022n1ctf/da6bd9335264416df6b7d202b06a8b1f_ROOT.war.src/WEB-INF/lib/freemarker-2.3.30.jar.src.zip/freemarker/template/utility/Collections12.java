/*    */ package freemarker.template.utility;
/*    */ 
/*    */ import freemarker.template.EmptyMap;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Collections12
/*    */ {
/* 35 */   public static final Map EMPTY_MAP = (Map)new EmptyMap();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Map singletonMap(Object key, Object value) {
/* 41 */     return Collections.singletonMap(key, value);
/*    */   }
/*    */   
/*    */   public static List singletonList(Object o) {
/* 45 */     return Collections.singletonList(o);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\templat\\utility\Collections12.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */