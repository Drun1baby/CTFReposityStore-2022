/*    */ package freemarker.template.utility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionUtils
/*    */ {
/* 27 */   public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*    */   
/* 29 */   public static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\freemarker-2.3.30.jar!\freemarker\templat\\utility\CollectionUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */