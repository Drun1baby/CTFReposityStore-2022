/*    */ package javassist.bytecode.stackmap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TypeTag
/*    */ {
/*    */   public static final String TOP_TYPE = "*top*";
/* 23 */   public static final TypeData TOP = new TypeData.BasicType("*top*", 0);
/* 24 */   public static final TypeData INTEGER = new TypeData.BasicType("int", 1);
/* 25 */   public static final TypeData FLOAT = new TypeData.BasicType("float", 2);
/* 26 */   public static final TypeData DOUBLE = new TypeData.BasicType("double", 3);
/* 27 */   public static final TypeData LONG = new TypeData.BasicType("long", 4);
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\stackmap\TypeTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */