/*    */ package javassist.bytecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExceptionTableEntry
/*    */ {
/*    */   int startPc;
/*    */   int endPc;
/*    */   int handlerPc;
/*    */   int catchType;
/*    */   
/*    */   ExceptionTableEntry(int start, int end, int handle, int type) {
/* 32 */     this.startPc = start;
/* 33 */     this.endPc = end;
/* 34 */     this.handlerPc = handle;
/* 35 */     this.catchType = type;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\ExceptionTableEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */