/*     */ package javassist.bytecode.analysis;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtMethod;
/*     */ import javassist.bytecode.BadBytecode;
/*     */ import javassist.bytecode.MethodInfo;
/*     */ import javassist.bytecode.stackmap.BasicBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlow
/*     */ {
/*     */   private CtClass clazz;
/*     */   private MethodInfo methodInfo;
/*     */   private Block[] basicBlocks;
/*     */   private Frame[] frames;
/*     */   
/*     */   public ControlFlow(CtMethod method) throws BadBytecode {
/*  56 */     this(method.getDeclaringClass(), method.getMethodInfo2());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ControlFlow(CtClass ctclazz, MethodInfo minfo) throws BadBytecode {
/*  63 */     this.clazz = ctclazz;
/*  64 */     this.methodInfo = minfo;
/*  65 */     this.frames = null;
/*  66 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       .basicBlocks = (Block[])(new BasicBlock.Maker() { protected BasicBlock makeBlock(int pos) { return new ControlFlow.Block(pos, ControlFlow.this.methodInfo); } protected BasicBlock[] makeArray(int size) { return (BasicBlock[])new ControlFlow.Block[size]; } }).make(minfo);
/*  74 */     int size = this.basicBlocks.length;
/*  75 */     int[] counters = new int[size]; int i;
/*  76 */     for (i = 0; i < size; i++) {
/*  77 */       Block b = this.basicBlocks[i];
/*  78 */       b.index = i;
/*  79 */       b.entrances = new Block[b.incomings()];
/*  80 */       counters[i] = 0;
/*     */     } 
/*     */     
/*  83 */     for (i = 0; i < size; i++) {
/*  84 */       Block b = this.basicBlocks[i];
/*  85 */       for (int k = 0; k < b.exits(); k++) {
/*  86 */         Block e = b.exit(k);
/*  87 */         counters[e.index] = counters[e.index] + 1; e.entrances[counters[e.index]] = b;
/*     */       } 
/*     */       
/*  90 */       Catcher[] catchers = b.catchers();
/*  91 */       for (int j = 0; j < catchers.length; j++) {
/*  92 */         Block catchBlock = (catchers[j]).node;
/*  93 */         counters[catchBlock.index] = counters[catchBlock.index] + 1; catchBlock.entrances[counters[catchBlock.index]] = b;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block[] basicBlocks() {
/* 102 */     return this.basicBlocks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Frame frameAt(int pos) throws BadBytecode {
/* 114 */     if (this.frames == null) {
/* 115 */       this.frames = (new Analyzer()).analyze(this.clazz, this.methodInfo);
/*     */     }
/* 117 */     return this.frames[pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node[] dominatorTree() {
/* 141 */     int size = this.basicBlocks.length;
/* 142 */     if (size == 0) {
/* 143 */       return null;
/*     */     }
/* 145 */     Node[] nodes = new Node[size];
/* 146 */     boolean[] visited = new boolean[size];
/* 147 */     int[] distance = new int[size];
/* 148 */     for (int i = 0; i < size; i++) {
/* 149 */       nodes[i] = new Node(this.basicBlocks[i]);
/* 150 */       visited[i] = false;
/*     */     } 
/*     */     
/* 153 */     Access access = new Access(nodes) {
/* 154 */         BasicBlock[] exits(ControlFlow.Node n) { return n.block.getExit(); }
/* 155 */         BasicBlock[] entrances(ControlFlow.Node n) { return (BasicBlock[])n.block.entrances; }
/*     */       };
/* 157 */     nodes[0].makeDepth1stTree(null, visited, 0, distance, access);
/*     */     while (true) {
/* 159 */       for (int j = 0; j < size; j++)
/* 160 */         visited[j] = false; 
/* 161 */       if (!nodes[0].makeDominatorTree(visited, distance, access)) {
/* 162 */         Node.setChildren(nodes);
/* 163 */         return nodes;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node[] postDominatorTree() {
/*     */     boolean changed;
/* 187 */     int size = this.basicBlocks.length;
/* 188 */     if (size == 0) {
/* 189 */       return null;
/*     */     }
/* 191 */     Node[] nodes = new Node[size];
/* 192 */     boolean[] visited = new boolean[size];
/* 193 */     int[] distance = new int[size];
/* 194 */     for (int i = 0; i < size; i++) {
/* 195 */       nodes[i] = new Node(this.basicBlocks[i]);
/* 196 */       visited[i] = false;
/*     */     } 
/*     */     
/* 199 */     Access access = new Access(nodes) {
/* 200 */         BasicBlock[] exits(ControlFlow.Node n) { return (BasicBlock[])n.block.entrances; } BasicBlock[] entrances(ControlFlow.Node n) {
/* 201 */           return n.block.getExit();
/*     */         }
/*     */       };
/* 204 */     int counter = 0;
/* 205 */     for (int j = 0; j < size; j++) {
/* 206 */       if ((nodes[j]).block.exits() == 0)
/* 207 */         counter = nodes[j].makeDepth1stTree(null, visited, counter, distance, access); 
/*     */     } 
/*     */     do {
/*     */       int k;
/* 211 */       for (k = 0; k < size; k++) {
/* 212 */         visited[k] = false;
/*     */       }
/* 214 */       changed = false;
/* 215 */       for (k = 0; k < size; k++)
/* 216 */       { if ((nodes[k]).block.exits() == 0 && 
/* 217 */           nodes[k].makeDominatorTree(visited, distance, access))
/* 218 */           changed = true;  } 
/* 219 */     } while (changed);
/*     */     
/* 221 */     Node.setChildren(nodes);
/* 222 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Block
/*     */     extends BasicBlock
/*     */   {
/* 239 */     public Object clientData = null;
/*     */     
/*     */     int index;
/*     */     MethodInfo method;
/*     */     Block[] entrances;
/*     */     
/*     */     Block(int pos, MethodInfo minfo) {
/* 246 */       super(pos);
/* 247 */       this.method = minfo;
/*     */     }
/*     */     
/*     */     protected void toString2(StringBuffer sbuf) {
/* 251 */       super.toString2(sbuf);
/* 252 */       sbuf.append(", incoming{");
/* 253 */       for (int i = 0; i < this.entrances.length; i++) {
/* 254 */         sbuf.append((this.entrances[i]).position).append(", ");
/*     */       }
/* 256 */       sbuf.append("}");
/*     */     }
/*     */     BasicBlock[] getExit() {
/* 259 */       return this.exit;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int index() {
/* 268 */       return this.index;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int position() {
/* 274 */       return this.position;
/*     */     }
/*     */ 
/*     */     
/*     */     public int length() {
/* 279 */       return this.length;
/*     */     }
/*     */ 
/*     */     
/*     */     public int incomings() {
/* 284 */       return this.incoming;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Block incoming(int n) {
/* 290 */       return this.entrances[n];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int exits() {
/* 297 */       return (this.exit == null) ? 0 : this.exit.length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Block exit(int n) {
/* 305 */       return (Block)this.exit[n];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ControlFlow.Catcher[] catchers() {
/* 312 */       ArrayList<ControlFlow.Catcher> catchers = new ArrayList();
/* 313 */       BasicBlock.Catch c = this.toCatch;
/* 314 */       while (c != null) {
/* 315 */         catchers.add(new ControlFlow.Catcher(c));
/* 316 */         c = c.next;
/*     */       } 
/*     */       
/* 319 */       return catchers.<ControlFlow.Catcher>toArray(new ControlFlow.Catcher[catchers.size()]);
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class Access { ControlFlow.Node[] all;
/*     */     
/* 325 */     Access(ControlFlow.Node[] nodes) { this.all = nodes; } ControlFlow.Node node(BasicBlock b) {
/* 326 */       return this.all[((ControlFlow.Block)b).index];
/*     */     }
/*     */     
/*     */     abstract BasicBlock[] exits(ControlFlow.Node param1Node);
/*     */     
/*     */     abstract BasicBlock[] entrances(ControlFlow.Node param1Node); }
/*     */ 
/*     */   
/*     */   public static class Node {
/*     */     private ControlFlow.Block block;
/*     */     private Node parent;
/*     */     private Node[] children;
/*     */     
/*     */     Node(ControlFlow.Block b) {
/* 340 */       this.block = b;
/* 341 */       this.parent = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 348 */       StringBuffer sbuf = new StringBuffer();
/* 349 */       sbuf.append("Node[pos=").append(block().position());
/* 350 */       sbuf.append(", parent=");
/* 351 */       sbuf.append((this.parent == null) ? "*" : Integer.toString(this.parent.block().position()));
/* 352 */       sbuf.append(", children{");
/* 353 */       for (int i = 0; i < this.children.length; i++) {
/* 354 */         sbuf.append(this.children[i].block().position()).append(", ");
/*     */       }
/* 356 */       sbuf.append("}]");
/* 357 */       return sbuf.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ControlFlow.Block block() {
/* 363 */       return this.block;
/*     */     }
/*     */ 
/*     */     
/*     */     public Node parent() {
/* 368 */       return this.parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public int children() {
/* 373 */       return this.children.length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Node child(int n) {
/* 380 */       return this.children[n];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int makeDepth1stTree(Node caller, boolean[] visited, int counter, int[] distance, ControlFlow.Access access) {
/* 388 */       int index = this.block.index;
/* 389 */       if (visited[index]) {
/* 390 */         return counter;
/*     */       }
/* 392 */       visited[index] = true;
/* 393 */       this.parent = caller;
/* 394 */       BasicBlock[] exits = access.exits(this);
/* 395 */       if (exits != null) {
/* 396 */         for (int i = 0; i < exits.length; i++) {
/* 397 */           Node n = access.node(exits[i]);
/* 398 */           counter = n.makeDepth1stTree(this, visited, counter, distance, access);
/*     */         } 
/*     */       }
/* 401 */       distance[index] = counter++;
/* 402 */       return counter;
/*     */     }
/*     */     
/*     */     boolean makeDominatorTree(boolean[] visited, int[] distance, ControlFlow.Access access) {
/* 406 */       int index = this.block.index;
/* 407 */       if (visited[index]) {
/* 408 */         return false;
/*     */       }
/* 410 */       visited[index] = true;
/* 411 */       boolean changed = false;
/* 412 */       BasicBlock[] exits = access.exits(this);
/* 413 */       if (exits != null)
/* 414 */         for (int i = 0; i < exits.length; i++) {
/* 415 */           Node n = access.node(exits[i]);
/* 416 */           if (n.makeDominatorTree(visited, distance, access)) {
/* 417 */             changed = true;
/*     */           }
/*     */         }  
/* 420 */       BasicBlock[] entrances = access.entrances(this);
/* 421 */       if (entrances != null) {
/* 422 */         for (int i = 0; i < entrances.length; i++) {
/* 423 */           if (this.parent != null) {
/* 424 */             Node n = getAncestor(this.parent, access.node(entrances[i]), distance);
/* 425 */             if (n != this.parent) {
/* 426 */               this.parent = n;
/* 427 */               changed = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/* 432 */       return changed;
/*     */     }
/*     */     
/*     */     private static Node getAncestor(Node n1, Node n2, int[] distance) {
/* 436 */       while (n1 != n2) {
/* 437 */         if (distance[n1.block.index] < distance[n2.block.index]) {
/* 438 */           n1 = n1.parent;
/*     */         } else {
/* 440 */           n2 = n2.parent;
/*     */         } 
/* 442 */         if (n1 == null || n2 == null) {
/* 443 */           return null;
/*     */         }
/*     */       } 
/* 446 */       return n1;
/*     */     }
/*     */     
/*     */     private static void setChildren(Node[] all) {
/* 450 */       int size = all.length;
/* 451 */       int[] nchildren = new int[size]; int i;
/* 452 */       for (i = 0; i < size; i++) {
/* 453 */         nchildren[i] = 0;
/*     */       }
/* 455 */       for (i = 0; i < size; i++) {
/* 456 */         Node p = (all[i]).parent;
/* 457 */         if (p != null) {
/* 458 */           nchildren[p.block.index] = nchildren[p.block.index] + 1;
/*     */         }
/*     */       } 
/* 461 */       for (i = 0; i < size; i++) {
/* 462 */         (all[i]).children = new Node[nchildren[i]];
/*     */       }
/* 464 */       for (i = 0; i < size; i++) {
/* 465 */         nchildren[i] = 0;
/*     */       }
/* 467 */       for (i = 0; i < size; i++) {
/* 468 */         Node n = all[i];
/* 469 */         Node p = n.parent;
/* 470 */         if (p != null) {
/* 471 */           nchildren[p.block.index] = nchildren[p.block.index] + 1; p.children[nchildren[p.block.index]] = n;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Catcher
/*     */   {
/*     */     private ControlFlow.Block node;
/*     */     private int typeIndex;
/*     */     
/*     */     Catcher(BasicBlock.Catch c) {
/* 484 */       this.node = (ControlFlow.Block)c.body;
/* 485 */       this.typeIndex = c.typeIndex;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ControlFlow.Block block() {
/* 491 */       return this.node;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String type() {
/* 498 */       if (this.typeIndex == 0) {
/* 499 */         return "java.lang.Throwable";
/*     */       }
/* 501 */       return this.node.method.getConstPool().getClassInfo(this.typeIndex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\analysis\ControlFlow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */