/*     */ package javassist.bytecode;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javassist.bytecode.annotation.Annotation;
/*     */ import javassist.bytecode.annotation.AnnotationMemberValue;
/*     */ import javassist.bytecode.annotation.AnnotationsWriter;
/*     */ import javassist.bytecode.annotation.ArrayMemberValue;
/*     */ import javassist.bytecode.annotation.BooleanMemberValue;
/*     */ import javassist.bytecode.annotation.ByteMemberValue;
/*     */ import javassist.bytecode.annotation.CharMemberValue;
/*     */ import javassist.bytecode.annotation.ClassMemberValue;
/*     */ import javassist.bytecode.annotation.DoubleMemberValue;
/*     */ import javassist.bytecode.annotation.EnumMemberValue;
/*     */ import javassist.bytecode.annotation.FloatMemberValue;
/*     */ import javassist.bytecode.annotation.IntegerMemberValue;
/*     */ import javassist.bytecode.annotation.LongMemberValue;
/*     */ import javassist.bytecode.annotation.MemberValue;
/*     */ import javassist.bytecode.annotation.ShortMemberValue;
/*     */ import javassist.bytecode.annotation.StringMemberValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationsAttribute
/*     */   extends AttributeInfo
/*     */ {
/*     */   public static final String visibleTag = "RuntimeVisibleAnnotations";
/*     */   public static final String invisibleTag = "RuntimeInvisibleAnnotations";
/*     */   
/*     */   public AnnotationsAttribute(ConstPool cp, String attrname, byte[] info) {
/* 126 */     super(cp, attrname, info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationsAttribute(ConstPool cp, String attrname) {
/* 141 */     this(cp, attrname, new byte[] { 0, 0 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationsAttribute(ConstPool cp, int n, DataInputStream in) throws IOException {
/* 150 */     super(cp, n, in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numAnnotations() {
/* 157 */     return ByteArray.readU16bit(this.info, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeInfo copy(ConstPool newCp, Map classnames) {
/* 164 */     Copier copier = new Copier(this.info, this.constPool, newCp, classnames);
/*     */     try {
/* 166 */       copier.annotationArray();
/* 167 */       return new AnnotationsAttribute(newCp, getName(), copier.close());
/*     */     }
/* 169 */     catch (Exception e) {
/* 170 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation getAnnotation(String type) {
/* 184 */     Annotation[] annotations = getAnnotations();
/* 185 */     for (int i = 0; i < annotations.length; i++) {
/* 186 */       if (annotations[i].getTypeName().equals(type)) {
/* 187 */         return annotations[i];
/*     */       }
/*     */     } 
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnnotation(Annotation annotation) {
/* 200 */     String type = annotation.getTypeName();
/* 201 */     Annotation[] annotations = getAnnotations();
/* 202 */     for (int i = 0; i < annotations.length; i++) {
/* 203 */       if (annotations[i].getTypeName().equals(type)) {
/* 204 */         annotations[i] = annotation;
/* 205 */         setAnnotations(annotations);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 210 */     Annotation[] newlist = new Annotation[annotations.length + 1];
/* 211 */     System.arraycopy(annotations, 0, newlist, 0, annotations.length);
/* 212 */     newlist[annotations.length] = annotation;
/* 213 */     setAnnotations(newlist);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/*     */     try {
/* 227 */       return (new Parser(this.info, this.constPool)).parseAnnotations();
/*     */     }
/* 229 */     catch (Exception e) {
/* 230 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotations(Annotation[] annotations) {
/* 242 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 243 */     AnnotationsWriter writer = new AnnotationsWriter(output, this.constPool);
/*     */     try {
/* 245 */       int n = annotations.length;
/* 246 */       writer.numAnnotations(n);
/* 247 */       for (int i = 0; i < n; i++) {
/* 248 */         annotations[i].write(writer);
/*     */       }
/* 250 */       writer.close();
/*     */     }
/* 252 */     catch (IOException e) {
/* 253 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 256 */     set(output.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotation(Annotation annotation) {
/* 267 */     setAnnotations(new Annotation[] { annotation });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void renameClass(String oldname, String newname) {
/* 275 */     HashMap<Object, Object> map = new HashMap<Object, Object>();
/* 276 */     map.put(oldname, newname);
/* 277 */     renameClass(map);
/*     */   }
/*     */   
/*     */   void renameClass(Map classnames) {
/* 281 */     Renamer renamer = new Renamer(this.info, getConstPool(), classnames);
/*     */     try {
/* 283 */       renamer.annotationArray();
/* 284 */     } catch (Exception e) {
/* 285 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   void getRefClasses(Map classnames) {
/* 289 */     renameClass(classnames);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 295 */     Annotation[] a = getAnnotations();
/* 296 */     StringBuilder sbuf = new StringBuilder();
/* 297 */     int i = 0;
/* 298 */     while (i < a.length) {
/* 299 */       sbuf.append(a[i++].toString());
/* 300 */       if (i != a.length) {
/* 301 */         sbuf.append(", ");
/*     */       }
/*     */     } 
/* 304 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */   static class Walker {
/*     */     byte[] info;
/*     */     
/*     */     Walker(byte[] attrInfo) {
/* 311 */       this.info = attrInfo;
/*     */     }
/*     */     
/*     */     final void parameters() throws Exception {
/* 315 */       int numParam = this.info[0] & 0xFF;
/* 316 */       parameters(numParam, 1);
/*     */     }
/*     */     
/*     */     void parameters(int numParam, int pos) throws Exception {
/* 320 */       for (int i = 0; i < numParam; i++)
/* 321 */         pos = annotationArray(pos); 
/*     */     }
/*     */     
/*     */     final void annotationArray() throws Exception {
/* 325 */       annotationArray(0);
/*     */     }
/*     */     
/*     */     final int annotationArray(int pos) throws Exception {
/* 329 */       int num = ByteArray.readU16bit(this.info, pos);
/* 330 */       return annotationArray(pos + 2, num);
/*     */     }
/*     */     
/*     */     int annotationArray(int pos, int num) throws Exception {
/* 334 */       for (int i = 0; i < num; i++) {
/* 335 */         pos = annotation(pos);
/*     */       }
/* 337 */       return pos;
/*     */     }
/*     */     
/*     */     final int annotation(int pos) throws Exception {
/* 341 */       int type = ByteArray.readU16bit(this.info, pos);
/* 342 */       int numPairs = ByteArray.readU16bit(this.info, pos + 2);
/* 343 */       return annotation(pos + 4, type, numPairs);
/*     */     }
/*     */     
/*     */     int annotation(int pos, int type, int numPairs) throws Exception {
/* 347 */       for (int j = 0; j < numPairs; j++) {
/* 348 */         pos = memberValuePair(pos);
/*     */       }
/* 350 */       return pos;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final int memberValuePair(int pos) throws Exception {
/* 357 */       int nameIndex = ByteArray.readU16bit(this.info, pos);
/* 358 */       return memberValuePair(pos + 2, nameIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int memberValuePair(int pos, int nameIndex) throws Exception {
/* 365 */       return memberValue(pos);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final int memberValue(int pos) throws Exception {
/* 372 */       int tag = this.info[pos] & 0xFF;
/* 373 */       if (tag == 101) {
/* 374 */         int typeNameIndex = ByteArray.readU16bit(this.info, pos + 1);
/* 375 */         int constNameIndex = ByteArray.readU16bit(this.info, pos + 3);
/* 376 */         enumMemberValue(pos, typeNameIndex, constNameIndex);
/* 377 */         return pos + 5;
/*     */       } 
/* 379 */       if (tag == 99) {
/* 380 */         int i = ByteArray.readU16bit(this.info, pos + 1);
/* 381 */         classMemberValue(pos, i);
/* 382 */         return pos + 3;
/*     */       } 
/* 384 */       if (tag == 64)
/* 385 */         return annotationMemberValue(pos + 1); 
/* 386 */       if (tag == 91) {
/* 387 */         int num = ByteArray.readU16bit(this.info, pos + 1);
/* 388 */         return arrayMemberValue(pos + 3, num);
/*     */       } 
/*     */       
/* 391 */       int index = ByteArray.readU16bit(this.info, pos + 1);
/* 392 */       constValueMember(tag, index);
/* 393 */       return pos + 3;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void constValueMember(int tag, int index) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void enumMemberValue(int pos, int typeNameIndex, int constNameIndex) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void classMemberValue(int pos, int index) throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int annotationMemberValue(int pos) throws Exception {
/* 418 */       return annotation(pos);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int arrayMemberValue(int pos, int num) throws Exception {
/* 425 */       for (int i = 0; i < num; i++) {
/* 426 */         pos = memberValue(pos);
/*     */       }
/*     */       
/* 429 */       return pos;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Renamer
/*     */     extends Walker
/*     */   {
/*     */     ConstPool cpool;
/*     */ 
/*     */     
/*     */     Map classnames;
/*     */ 
/*     */ 
/*     */     
/*     */     Renamer(byte[] info, ConstPool cp, Map map) {
/* 447 */       super(info);
/* 448 */       this.cpool = cp;
/* 449 */       this.classnames = map;
/*     */     }
/*     */     
/*     */     int annotation(int pos, int type, int numPairs) throws Exception {
/* 453 */       renameType(pos - 4, type);
/* 454 */       return super.annotation(pos, type, numPairs);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void enumMemberValue(int pos, int typeNameIndex, int constNameIndex) throws Exception {
/* 460 */       renameType(pos + 1, typeNameIndex);
/* 461 */       super.enumMemberValue(pos, typeNameIndex, constNameIndex);
/*     */     }
/*     */     
/*     */     void classMemberValue(int pos, int index) throws Exception {
/* 465 */       renameType(pos + 1, index);
/* 466 */       super.classMemberValue(pos, index);
/*     */     }
/*     */     
/*     */     private void renameType(int pos, int index) {
/* 470 */       String name = this.cpool.getUtf8Info(index);
/* 471 */       String newName = Descriptor.rename(name, this.classnames);
/* 472 */       if (!name.equals(newName)) {
/* 473 */         int index2 = this.cpool.addUtf8Info(newName);
/* 474 */         ByteArray.write16bit(index2, this.info, pos);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Copier
/*     */     extends Walker
/*     */   {
/*     */     ByteArrayOutputStream output;
/*     */ 
/*     */     
/*     */     AnnotationsWriter writer;
/*     */     
/*     */     ConstPool srcPool;
/*     */     
/*     */     ConstPool destPool;
/*     */     
/*     */     Map classnames;
/*     */ 
/*     */     
/*     */     Copier(byte[] info, ConstPool src, ConstPool dest, Map map) {
/* 497 */       this(info, src, dest, map, true);
/*     */     }
/*     */     
/*     */     Copier(byte[] info, ConstPool src, ConstPool dest, Map map, boolean makeWriter) {
/* 501 */       super(info);
/* 502 */       this.output = new ByteArrayOutputStream();
/* 503 */       if (makeWriter) {
/* 504 */         this.writer = new AnnotationsWriter(this.output, dest);
/*     */       }
/* 506 */       this.srcPool = src;
/* 507 */       this.destPool = dest;
/* 508 */       this.classnames = map;
/*     */     }
/*     */     
/*     */     byte[] close() throws IOException {
/* 512 */       this.writer.close();
/* 513 */       return this.output.toByteArray();
/*     */     }
/*     */     
/*     */     void parameters(int numParam, int pos) throws Exception {
/* 517 */       this.writer.numParameters(numParam);
/* 518 */       super.parameters(numParam, pos);
/*     */     }
/*     */     
/*     */     int annotationArray(int pos, int num) throws Exception {
/* 522 */       this.writer.numAnnotations(num);
/* 523 */       return super.annotationArray(pos, num);
/*     */     }
/*     */     
/*     */     int annotation(int pos, int type, int numPairs) throws Exception {
/* 527 */       this.writer.annotation(copyType(type), numPairs);
/* 528 */       return super.annotation(pos, type, numPairs);
/*     */     }
/*     */     
/*     */     int memberValuePair(int pos, int nameIndex) throws Exception {
/* 532 */       this.writer.memberValuePair(copy(nameIndex));
/* 533 */       return super.memberValuePair(pos, nameIndex);
/*     */     }
/*     */     
/*     */     void constValueMember(int tag, int index) throws Exception {
/* 537 */       this.writer.constValueIndex(tag, copy(index));
/* 538 */       super.constValueMember(tag, index);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void enumMemberValue(int pos, int typeNameIndex, int constNameIndex) throws Exception {
/* 544 */       this.writer.enumConstValue(copyType(typeNameIndex), copy(constNameIndex));
/* 545 */       super.enumMemberValue(pos, typeNameIndex, constNameIndex);
/*     */     }
/*     */     
/*     */     void classMemberValue(int pos, int index) throws Exception {
/* 549 */       this.writer.classInfoIndex(copyType(index));
/* 550 */       super.classMemberValue(pos, index);
/*     */     }
/*     */     
/*     */     int annotationMemberValue(int pos) throws Exception {
/* 554 */       this.writer.annotationValue();
/* 555 */       return super.annotationMemberValue(pos);
/*     */     }
/*     */     
/*     */     int arrayMemberValue(int pos, int num) throws Exception {
/* 559 */       this.writer.arrayValue(num);
/* 560 */       return super.arrayMemberValue(pos, num);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int copy(int srcIndex) {
/* 573 */       return this.srcPool.copy(srcIndex, this.destPool, this.classnames);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int copyType(int srcIndex) {
/* 587 */       String name = this.srcPool.getUtf8Info(srcIndex);
/* 588 */       String newName = Descriptor.rename(name, this.classnames);
/* 589 */       return this.destPool.addUtf8Info(newName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class Parser
/*     */     extends Walker
/*     */   {
/*     */     ConstPool pool;
/*     */     
/*     */     Annotation[][] allParams;
/*     */     
/*     */     Annotation[] allAnno;
/*     */     
/*     */     Annotation currentAnno;
/*     */     
/*     */     MemberValue currentMember;
/*     */     
/*     */     Parser(byte[] info, ConstPool cp) {
/* 608 */       super(info);
/* 609 */       this.pool = cp;
/*     */     }
/*     */     
/*     */     Annotation[][] parseParameters() throws Exception {
/* 613 */       parameters();
/* 614 */       return this.allParams;
/*     */     }
/*     */     
/*     */     Annotation[] parseAnnotations() throws Exception {
/* 618 */       annotationArray();
/* 619 */       return this.allAnno;
/*     */     }
/*     */     
/*     */     MemberValue parseMemberValue() throws Exception {
/* 623 */       memberValue(0);
/* 624 */       return this.currentMember;
/*     */     }
/*     */     
/*     */     void parameters(int numParam, int pos) throws Exception {
/* 628 */       Annotation[][] params = new Annotation[numParam][];
/* 629 */       for (int i = 0; i < numParam; i++) {
/* 630 */         pos = annotationArray(pos);
/* 631 */         params[i] = this.allAnno;
/*     */       } 
/*     */       
/* 634 */       this.allParams = params;
/*     */     }
/*     */     
/*     */     int annotationArray(int pos, int num) throws Exception {
/* 638 */       Annotation[] array = new Annotation[num];
/* 639 */       for (int i = 0; i < num; i++) {
/* 640 */         pos = annotation(pos);
/* 641 */         array[i] = this.currentAnno;
/*     */       } 
/*     */       
/* 644 */       this.allAnno = array;
/* 645 */       return pos;
/*     */     }
/*     */     
/*     */     int annotation(int pos, int type, int numPairs) throws Exception {
/* 649 */       this.currentAnno = new Annotation(type, this.pool);
/* 650 */       return super.annotation(pos, type, numPairs);
/*     */     }
/*     */     
/*     */     int memberValuePair(int pos, int nameIndex) throws Exception {
/* 654 */       pos = super.memberValuePair(pos, nameIndex);
/* 655 */       this.currentAnno.addMemberValue(nameIndex, this.currentMember);
/* 656 */       return pos; } void constValueMember(int tag, int index) throws Exception { ByteMemberValue byteMemberValue; CharMemberValue charMemberValue; DoubleMemberValue doubleMemberValue; FloatMemberValue floatMemberValue; IntegerMemberValue integerMemberValue;
/*     */       LongMemberValue longMemberValue;
/*     */       ShortMemberValue shortMemberValue;
/*     */       BooleanMemberValue booleanMemberValue;
/*     */       StringMemberValue stringMemberValue;
/* 661 */       ConstPool cp = this.pool;
/* 662 */       switch (tag) {
/*     */         case 66:
/* 664 */           byteMemberValue = new ByteMemberValue(index, cp);
/*     */           break;
/*     */         case 67:
/* 667 */           charMemberValue = new CharMemberValue(index, cp);
/*     */           break;
/*     */         case 68:
/* 670 */           doubleMemberValue = new DoubleMemberValue(index, cp);
/*     */           break;
/*     */         case 70:
/* 673 */           floatMemberValue = new FloatMemberValue(index, cp);
/*     */           break;
/*     */         case 73:
/* 676 */           integerMemberValue = new IntegerMemberValue(index, cp);
/*     */           break;
/*     */         case 74:
/* 679 */           longMemberValue = new LongMemberValue(index, cp);
/*     */           break;
/*     */         case 83:
/* 682 */           shortMemberValue = new ShortMemberValue(index, cp);
/*     */           break;
/*     */         case 90:
/* 685 */           booleanMemberValue = new BooleanMemberValue(index, cp);
/*     */           break;
/*     */         case 115:
/* 688 */           stringMemberValue = new StringMemberValue(index, cp);
/*     */           break;
/*     */         default:
/* 691 */           throw new RuntimeException("unknown tag:" + tag);
/*     */       } 
/*     */       
/* 694 */       this.currentMember = (MemberValue)stringMemberValue;
/* 695 */       super.constValueMember(tag, index); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void enumMemberValue(int pos, int typeNameIndex, int constNameIndex) throws Exception {
/* 701 */       this.currentMember = (MemberValue)new EnumMemberValue(typeNameIndex, constNameIndex, this.pool);
/*     */       
/* 703 */       super.enumMemberValue(pos, typeNameIndex, constNameIndex);
/*     */     }
/*     */     
/*     */     void classMemberValue(int pos, int index) throws Exception {
/* 707 */       this.currentMember = (MemberValue)new ClassMemberValue(index, this.pool);
/* 708 */       super.classMemberValue(pos, index);
/*     */     }
/*     */     
/*     */     int annotationMemberValue(int pos) throws Exception {
/* 712 */       Annotation anno = this.currentAnno;
/* 713 */       pos = super.annotationMemberValue(pos);
/* 714 */       this.currentMember = (MemberValue)new AnnotationMemberValue(this.currentAnno, this.pool);
/* 715 */       this.currentAnno = anno;
/* 716 */       return pos;
/*     */     }
/*     */     
/*     */     int arrayMemberValue(int pos, int num) throws Exception {
/* 720 */       ArrayMemberValue amv = new ArrayMemberValue(this.pool);
/* 721 */       MemberValue[] elements = new MemberValue[num];
/* 722 */       for (int i = 0; i < num; i++) {
/* 723 */         pos = memberValue(pos);
/* 724 */         elements[i] = this.currentMember;
/*     */       } 
/*     */       
/* 727 */       amv.setValue(elements);
/* 728 */       this.currentMember = (MemberValue)amv;
/* 729 */       return pos;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\AnnotationsAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */