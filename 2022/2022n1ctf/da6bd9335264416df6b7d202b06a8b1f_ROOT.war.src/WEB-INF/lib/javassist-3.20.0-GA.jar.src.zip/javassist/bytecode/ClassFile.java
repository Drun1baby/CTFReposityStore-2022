/*     */ package javassist.bytecode;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import javassist.CannotCompileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassFile
/*     */ {
/*     */   int major;
/*     */   int minor;
/*     */   ConstPool constPool;
/*     */   int thisClass;
/*     */   int accessFlags;
/*     */   int superClass;
/*     */   int[] interfaces;
/*     */   ArrayList fields;
/*     */   ArrayList methods;
/*     */   ArrayList attributes;
/*     */   String thisclassname;
/*     */   String[] cachedInterfaces;
/*     */   String cachedSuperclass;
/*     */   public static final int JAVA_1 = 45;
/*     */   public static final int JAVA_2 = 46;
/*     */   public static final int JAVA_3 = 47;
/*     */   public static final int JAVA_4 = 48;
/*     */   public static final int JAVA_5 = 49;
/*     */   public static final int JAVA_6 = 50;
/*     */   public static final int JAVA_7 = 51;
/*     */   public static final int JAVA_8 = 52;
/* 130 */   public static int MAJOR_VERSION = 47;
/*     */   
/*     */   static {
/*     */     try {
/* 134 */       Class.forName("java.lang.StringBuilder");
/* 135 */       MAJOR_VERSION = 49;
/* 136 */       Class.forName("java.util.zip.DeflaterInputStream");
/* 137 */       MAJOR_VERSION = 50;
/* 138 */       Class.forName("java.lang.invoke.CallSite");
/* 139 */       MAJOR_VERSION = 51;
/*     */     }
/* 141 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFile(DataInputStream in) throws IOException {
/* 148 */     read(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassFile(boolean isInterface, String classname, String superclass) {
/* 162 */     this.major = MAJOR_VERSION;
/* 163 */     this.minor = 0;
/* 164 */     this.constPool = new ConstPool(classname);
/* 165 */     this.thisClass = this.constPool.getThisClassInfo();
/* 166 */     if (isInterface) {
/* 167 */       this.accessFlags = 1536;
/*     */     } else {
/* 169 */       this.accessFlags = 32;
/*     */     } 
/* 171 */     initSuperclass(superclass);
/* 172 */     this.interfaces = null;
/* 173 */     this.fields = new ArrayList();
/* 174 */     this.methods = new ArrayList();
/* 175 */     this.thisclassname = classname;
/*     */     
/* 177 */     this.attributes = new ArrayList();
/* 178 */     this.attributes.add(new SourceFileAttribute(this.constPool, 
/* 179 */           getSourcefileName(this.thisclassname)));
/*     */   }
/*     */   
/*     */   private void initSuperclass(String superclass) {
/* 183 */     if (superclass != null) {
/* 184 */       this.superClass = this.constPool.addClassInfo(superclass);
/* 185 */       this.cachedSuperclass = superclass;
/*     */     } else {
/*     */       
/* 188 */       this.superClass = this.constPool.addClassInfo("java.lang.Object");
/* 189 */       this.cachedSuperclass = "java.lang.Object";
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getSourcefileName(String qname) {
/* 194 */     int index = qname.lastIndexOf('.');
/* 195 */     if (index >= 0) {
/* 196 */       qname = qname.substring(index + 1);
/*     */     }
/* 198 */     return qname + ".java";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void compact() {
/* 207 */     ConstPool cp = compact0();
/* 208 */     ArrayList<MethodInfo> list = this.methods;
/* 209 */     int n = list.size(); int i;
/* 210 */     for (i = 0; i < n; i++) {
/* 211 */       MethodInfo minfo = list.get(i);
/* 212 */       minfo.compact(cp);
/*     */     } 
/*     */     
/* 215 */     list = this.fields;
/* 216 */     n = list.size();
/* 217 */     for (i = 0; i < n; i++) {
/* 218 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 219 */       finfo.compact(cp);
/*     */     } 
/*     */     
/* 222 */     this.attributes = AttributeInfo.copyAll(this.attributes, cp);
/* 223 */     this.constPool = cp;
/*     */   }
/*     */   
/*     */   private ConstPool compact0() {
/* 227 */     ConstPool cp = new ConstPool(this.thisclassname);
/* 228 */     this.thisClass = cp.getThisClassInfo();
/* 229 */     String sc = getSuperclass();
/* 230 */     if (sc != null) {
/* 231 */       this.superClass = cp.addClassInfo(getSuperclass());
/*     */     }
/* 233 */     if (this.interfaces != null) {
/* 234 */       int n = this.interfaces.length;
/* 235 */       for (int i = 0; i < n; i++) {
/* 236 */         this.interfaces[i] = cp
/* 237 */           .addClassInfo(this.constPool.getClassInfo(this.interfaces[i]));
/*     */       }
/*     */     } 
/* 240 */     return cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prune() {
/* 250 */     ConstPool cp = compact0();
/* 251 */     ArrayList<AttributeInfo> newAttributes = new ArrayList();
/*     */     
/* 253 */     AttributeInfo invisibleAnnotations = getAttribute("RuntimeInvisibleAnnotations");
/* 254 */     if (invisibleAnnotations != null) {
/* 255 */       invisibleAnnotations = invisibleAnnotations.copy(cp, null);
/* 256 */       newAttributes.add(invisibleAnnotations);
/*     */     } 
/*     */ 
/*     */     
/* 260 */     AttributeInfo visibleAnnotations = getAttribute("RuntimeVisibleAnnotations");
/* 261 */     if (visibleAnnotations != null) {
/* 262 */       visibleAnnotations = visibleAnnotations.copy(cp, null);
/* 263 */       newAttributes.add(visibleAnnotations);
/*     */     } 
/*     */ 
/*     */     
/* 267 */     AttributeInfo signature = getAttribute("Signature");
/* 268 */     if (signature != null) {
/* 269 */       signature = signature.copy(cp, null);
/* 270 */       newAttributes.add(signature);
/*     */     } 
/*     */     
/* 273 */     ArrayList<MethodInfo> list = this.methods;
/* 274 */     int n = list.size(); int i;
/* 275 */     for (i = 0; i < n; i++) {
/* 276 */       MethodInfo minfo = list.get(i);
/* 277 */       minfo.prune(cp);
/*     */     } 
/*     */     
/* 280 */     list = this.fields;
/* 281 */     n = list.size();
/* 282 */     for (i = 0; i < n; i++) {
/* 283 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 284 */       finfo.prune(cp);
/*     */     } 
/*     */     
/* 287 */     this.attributes = newAttributes;
/* 288 */     this.constPool = cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstPool getConstPool() {
/* 295 */     return this.constPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/* 302 */     return ((this.accessFlags & 0x200) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/* 309 */     return ((this.accessFlags & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/* 316 */     return ((this.accessFlags & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAccessFlags() {
/* 325 */     return this.accessFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessFlags(int acc) {
/* 334 */     if ((acc & 0x200) == 0) {
/* 335 */       acc |= 0x20;
/*     */     }
/* 337 */     this.accessFlags = acc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInnerAccessFlags() {
/* 350 */     InnerClassesAttribute ica = (InnerClassesAttribute)getAttribute("InnerClasses");
/* 351 */     if (ica == null) {
/* 352 */       return -1;
/*     */     }
/* 354 */     String name = getName();
/* 355 */     int n = ica.tableLength();
/* 356 */     for (int i = 0; i < n; i++) {
/* 357 */       if (name.equals(ica.innerClass(i)))
/* 358 */         return ica.accessFlags(i); 
/*     */     } 
/* 360 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 367 */     return this.thisclassname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 375 */     renameClass(this.thisclassname, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSuperclass() {
/* 382 */     if (this.cachedSuperclass == null) {
/* 383 */       this.cachedSuperclass = this.constPool.getClassInfo(this.superClass);
/*     */     }
/* 385 */     return this.cachedSuperclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSuperclassId() {
/* 393 */     return this.superClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuperclass(String superclass) throws CannotCompileException {
/* 405 */     if (superclass == null) {
/* 406 */       superclass = "java.lang.Object";
/*     */     }
/*     */     try {
/* 409 */       this.superClass = this.constPool.addClassInfo(superclass);
/* 410 */       ArrayList<MethodInfo> list = this.methods;
/* 411 */       int n = list.size();
/* 412 */       for (int i = 0; i < n; i++) {
/* 413 */         MethodInfo minfo = list.get(i);
/* 414 */         minfo.setSuperclass(superclass);
/*     */       }
/*     */     
/* 417 */     } catch (BadBytecode e) {
/* 418 */       throw new CannotCompileException(e);
/*     */     } 
/* 420 */     this.cachedSuperclass = superclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void renameClass(String oldname, String newname) {
/* 441 */     if (oldname.equals(newname)) {
/*     */       return;
/*     */     }
/* 444 */     if (oldname.equals(this.thisclassname)) {
/* 445 */       this.thisclassname = newname;
/*     */     }
/* 447 */     oldname = Descriptor.toJvmName(oldname);
/* 448 */     newname = Descriptor.toJvmName(newname);
/* 449 */     this.constPool.renameClass(oldname, newname);
/*     */     
/* 451 */     AttributeInfo.renameClass(this.attributes, oldname, newname);
/* 452 */     ArrayList<MethodInfo> list = this.methods;
/* 453 */     int n = list.size(); int i;
/* 454 */     for (i = 0; i < n; i++) {
/* 455 */       MethodInfo minfo = list.get(i);
/* 456 */       String desc = minfo.getDescriptor();
/* 457 */       minfo.setDescriptor(Descriptor.rename(desc, oldname, newname));
/* 458 */       AttributeInfo.renameClass(minfo.getAttributes(), oldname, newname);
/*     */     } 
/*     */     
/* 461 */     list = this.fields;
/* 462 */     n = list.size();
/* 463 */     for (i = 0; i < n; i++) {
/* 464 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 465 */       String desc = finfo.getDescriptor();
/* 466 */       finfo.setDescriptor(Descriptor.rename(desc, oldname, newname));
/* 467 */       AttributeInfo.renameClass(finfo.getAttributes(), oldname, newname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void renameClass(Map classnames) {
/* 481 */     String jvmNewThisName = (String)classnames.get(
/* 482 */         Descriptor.toJvmName(this.thisclassname));
/* 483 */     if (jvmNewThisName != null) {
/* 484 */       this.thisclassname = Descriptor.toJavaName(jvmNewThisName);
/*     */     }
/* 486 */     this.constPool.renameClass(classnames);
/*     */     
/* 488 */     AttributeInfo.renameClass(this.attributes, classnames);
/* 489 */     ArrayList<MethodInfo> list = this.methods;
/* 490 */     int n = list.size(); int i;
/* 491 */     for (i = 0; i < n; i++) {
/* 492 */       MethodInfo minfo = list.get(i);
/* 493 */       String desc = minfo.getDescriptor();
/* 494 */       minfo.setDescriptor(Descriptor.rename(desc, classnames));
/* 495 */       AttributeInfo.renameClass(minfo.getAttributes(), classnames);
/*     */     } 
/*     */     
/* 498 */     list = this.fields;
/* 499 */     n = list.size();
/* 500 */     for (i = 0; i < n; i++) {
/* 501 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 502 */       String desc = finfo.getDescriptor();
/* 503 */       finfo.setDescriptor(Descriptor.rename(desc, classnames));
/* 504 */       AttributeInfo.renameClass(finfo.getAttributes(), classnames);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void getRefClasses(Map classnames) {
/* 513 */     this.constPool.renameClass(classnames);
/*     */     
/* 515 */     AttributeInfo.getRefClasses(this.attributes, classnames);
/* 516 */     ArrayList<MethodInfo> list = this.methods;
/* 517 */     int n = list.size(); int i;
/* 518 */     for (i = 0; i < n; i++) {
/* 519 */       MethodInfo minfo = list.get(i);
/* 520 */       String desc = minfo.getDescriptor();
/* 521 */       Descriptor.rename(desc, classnames);
/* 522 */       AttributeInfo.getRefClasses(minfo.getAttributes(), classnames);
/*     */     } 
/*     */     
/* 525 */     list = this.fields;
/* 526 */     n = list.size();
/* 527 */     for (i = 0; i < n; i++) {
/* 528 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 529 */       String desc = finfo.getDescriptor();
/* 530 */       Descriptor.rename(desc, classnames);
/* 531 */       AttributeInfo.getRefClasses(finfo.getAttributes(), classnames);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getInterfaces() {
/* 540 */     if (this.cachedInterfaces != null) {
/* 541 */       return this.cachedInterfaces;
/*     */     }
/* 543 */     String[] rtn = null;
/* 544 */     if (this.interfaces == null) {
/* 545 */       rtn = new String[0];
/*     */     } else {
/* 547 */       int n = this.interfaces.length;
/* 548 */       String[] list = new String[n];
/* 549 */       for (int i = 0; i < n; i++) {
/* 550 */         list[i] = this.constPool.getClassInfo(this.interfaces[i]);
/*     */       }
/* 552 */       rtn = list;
/*     */     } 
/*     */     
/* 555 */     this.cachedInterfaces = rtn;
/* 556 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterfaces(String[] nameList) {
/* 566 */     this.cachedInterfaces = null;
/* 567 */     if (nameList != null) {
/* 568 */       int n = nameList.length;
/* 569 */       this.interfaces = new int[n];
/* 570 */       for (int i = 0; i < n; i++) {
/* 571 */         this.interfaces[i] = this.constPool.addClassInfo(nameList[i]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInterface(String name) {
/* 579 */     this.cachedInterfaces = null;
/* 580 */     int info = this.constPool.addClassInfo(name);
/* 581 */     if (this.interfaces == null) {
/* 582 */       this.interfaces = new int[1];
/* 583 */       this.interfaces[0] = info;
/*     */     } else {
/*     */       
/* 586 */       int n = this.interfaces.length;
/* 587 */       int[] newarray = new int[n + 1];
/* 588 */       System.arraycopy(this.interfaces, 0, newarray, 0, n);
/* 589 */       newarray[n] = info;
/* 590 */       this.interfaces = newarray;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getFields() {
/* 601 */     return this.fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addField(FieldInfo finfo) throws DuplicateMemberException {
/* 610 */     testExistingField(finfo.getName(), finfo.getDescriptor());
/* 611 */     this.fields.add(finfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addField2(FieldInfo finfo) {
/* 623 */     this.fields.add(finfo);
/*     */   }
/*     */ 
/*     */   
/*     */   private void testExistingField(String name, String descriptor) throws DuplicateMemberException {
/* 628 */     ListIterator<FieldInfo> it = this.fields.listIterator(0);
/* 629 */     while (it.hasNext()) {
/* 630 */       FieldInfo minfo = it.next();
/* 631 */       if (minfo.getName().equals(name)) {
/* 632 */         throw new DuplicateMemberException("duplicate field: " + name);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getMethods() {
/* 643 */     return this.methods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethod(String name) {
/* 653 */     ArrayList<MethodInfo> list = this.methods;
/* 654 */     int n = list.size();
/* 655 */     for (int i = 0; i < n; i++) {
/* 656 */       MethodInfo minfo = list.get(i);
/* 657 */       if (minfo.getName().equals(name)) {
/* 658 */         return minfo;
/*     */       }
/*     */     } 
/* 661 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getStaticInitializer() {
/* 669 */     return getMethod("<clinit>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMethod(MethodInfo minfo) throws DuplicateMemberException {
/* 680 */     testExistingMethod(minfo);
/* 681 */     this.methods.add(minfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addMethod2(MethodInfo minfo) {
/* 693 */     this.methods.add(minfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void testExistingMethod(MethodInfo newMinfo) throws DuplicateMemberException {
/* 699 */     String name = newMinfo.getName();
/* 700 */     String descriptor = newMinfo.getDescriptor();
/* 701 */     ListIterator<MethodInfo> it = this.methods.listIterator(0);
/* 702 */     while (it.hasNext()) {
/* 703 */       if (isDuplicated(newMinfo, name, descriptor, it.next(), it)) {
/* 704 */         throw new DuplicateMemberException("duplicate method: " + name + " in " + 
/* 705 */             getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isDuplicated(MethodInfo newMethod, String newName, String newDesc, MethodInfo minfo, ListIterator it) {
/* 712 */     if (!minfo.getName().equals(newName)) {
/* 713 */       return false;
/*     */     }
/* 715 */     String desc = minfo.getDescriptor();
/* 716 */     if (!Descriptor.eqParamTypes(desc, newDesc)) {
/* 717 */       return false;
/*     */     }
/* 719 */     if (desc.equals(newDesc)) {
/* 720 */       if (notBridgeMethod(minfo)) {
/* 721 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 725 */       it.remove();
/* 726 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 730 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean notBridgeMethod(MethodInfo minfo) {
/* 737 */     return ((minfo.getAccessFlags() & 0x40) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getAttributes() {
/* 751 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeInfo getAttribute(String name) {
/* 763 */     ArrayList<AttributeInfo> list = this.attributes;
/* 764 */     int n = list.size();
/* 765 */     for (int i = 0; i < n; i++) {
/* 766 */       AttributeInfo ai = list.get(i);
/* 767 */       if (ai.getName().equals(name)) {
/* 768 */         return ai;
/*     */       }
/*     */     } 
/* 771 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(AttributeInfo info) {
/* 781 */     AttributeInfo.remove(this.attributes, info.getName());
/* 782 */     this.attributes.add(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceFile() {
/* 792 */     SourceFileAttribute sf = (SourceFileAttribute)getAttribute("SourceFile");
/* 793 */     if (sf == null) {
/* 794 */       return null;
/*     */     }
/* 796 */     return sf.getFileName();
/*     */   }
/*     */ 
/*     */   
/*     */   private void read(DataInputStream in) throws IOException {
/* 801 */     int magic = in.readInt();
/* 802 */     if (magic != -889275714) {
/* 803 */       throw new IOException("bad magic number: " + Integer.toHexString(magic));
/*     */     }
/* 805 */     this.minor = in.readUnsignedShort();
/* 806 */     this.major = in.readUnsignedShort();
/* 807 */     this.constPool = new ConstPool(in);
/* 808 */     this.accessFlags = in.readUnsignedShort();
/* 809 */     this.thisClass = in.readUnsignedShort();
/* 810 */     this.constPool.setThisClassInfo(this.thisClass);
/* 811 */     this.superClass = in.readUnsignedShort();
/* 812 */     int n = in.readUnsignedShort();
/* 813 */     if (n == 0) {
/* 814 */       this.interfaces = null;
/*     */     } else {
/* 816 */       this.interfaces = new int[n];
/* 817 */       for (int j = 0; j < n; j++) {
/* 818 */         this.interfaces[j] = in.readUnsignedShort();
/*     */       }
/*     */     } 
/* 821 */     ConstPool cp = this.constPool;
/* 822 */     n = in.readUnsignedShort();
/* 823 */     this.fields = new ArrayList(); int i;
/* 824 */     for (i = 0; i < n; i++) {
/* 825 */       addField2(new FieldInfo(cp, in));
/*     */     }
/* 827 */     n = in.readUnsignedShort();
/* 828 */     this.methods = new ArrayList();
/* 829 */     for (i = 0; i < n; i++) {
/* 830 */       addMethod2(new MethodInfo(cp, in));
/*     */     }
/* 832 */     this.attributes = new ArrayList();
/* 833 */     n = in.readUnsignedShort();
/* 834 */     for (i = 0; i < n; i++) {
/* 835 */       addAttribute(AttributeInfo.read(cp, in));
/*     */     }
/* 837 */     this.thisclassname = this.constPool.getClassInfo(this.thisClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(DataOutputStream out) throws IOException {
/* 846 */     out.writeInt(-889275714);
/* 847 */     out.writeShort(this.minor);
/* 848 */     out.writeShort(this.major);
/* 849 */     this.constPool.write(out);
/* 850 */     out.writeShort(this.accessFlags);
/* 851 */     out.writeShort(this.thisClass);
/* 852 */     out.writeShort(this.superClass);
/*     */     
/* 854 */     if (this.interfaces == null) {
/* 855 */       n = 0;
/*     */     } else {
/* 857 */       n = this.interfaces.length;
/*     */     } 
/* 859 */     out.writeShort(n); int i;
/* 860 */     for (i = 0; i < n; i++) {
/* 861 */       out.writeShort(this.interfaces[i]);
/*     */     }
/* 863 */     ArrayList<FieldInfo> list = this.fields;
/* 864 */     int n = list.size();
/* 865 */     out.writeShort(n);
/* 866 */     for (i = 0; i < n; i++) {
/* 867 */       FieldInfo finfo = list.get(i);
/* 868 */       finfo.write(out);
/*     */     } 
/*     */     
/* 871 */     list = this.methods;
/* 872 */     n = list.size();
/* 873 */     out.writeShort(n);
/* 874 */     for (i = 0; i < n; i++) {
/* 875 */       MethodInfo minfo = (MethodInfo)list.get(i);
/* 876 */       minfo.write(out);
/*     */     } 
/*     */     
/* 879 */     out.writeShort(this.attributes.size());
/* 880 */     AttributeInfo.writeAll(this.attributes, out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 889 */     return this.major;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMajorVersion(int major) {
/* 899 */     this.major = major;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 908 */     return this.minor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinorVersion(int minor) {
/* 918 */     this.minor = minor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersionToJava5() {
/* 929 */     this.major = 49;
/* 930 */     this.minor = 0;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\ClassFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */