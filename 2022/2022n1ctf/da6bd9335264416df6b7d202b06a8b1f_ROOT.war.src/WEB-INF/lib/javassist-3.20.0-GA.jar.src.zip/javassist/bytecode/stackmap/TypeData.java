/*     */ package javassist.bytecode.stackmap;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.NotFoundException;
/*     */ import javassist.bytecode.BadBytecode;
/*     */ import javassist.bytecode.ConstPool;
/*     */ import javassist.bytecode.Descriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeData
/*     */ {
/*     */   public static TypeData[] make(int size) {
/*  36 */     TypeData[] array = new TypeData[size];
/*  37 */     for (int i = 0; i < size; i++) {
/*  38 */       array[i] = TypeTag.TOP;
/*     */     }
/*  40 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setType(TypeData td, String className, ClassPool cp) throws BadBytecode {
/*  53 */     td.setType(className, cp);
/*     */   }
/*     */   public abstract int getTypeTag();
/*     */   public abstract int getTypeData(ConstPool paramConstPool);
/*     */   
/*     */   public TypeData join() {
/*  59 */     return new TypeVar(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BasicType isBasicType();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean is2WordType();
/*     */ 
/*     */   
/*     */   public boolean isNullType() {
/*  72 */     return false;
/*     */   } public boolean isUninit() {
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean eq(TypeData paramTypeData);
/*     */   
/*     */   public abstract String getName();
/*     */   
/*     */   public abstract void setType(String paramString, ClassPool paramClassPool) throws BadBytecode;
/*     */   
/*     */   public int dfs(ArrayList order, int index, ClassPool cp) throws NotFoundException {
/*  85 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeVar toTypeVar() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void constructorCalled(int offset) {}
/*     */   
/*     */   protected static class BasicType
/*     */     extends TypeData
/*     */   {
/*     */     private String name;
/*     */     private int typeTag;
/*     */     
/*     */     public BasicType(String type, int tag) {
/* 106 */       this.name = type;
/* 107 */       this.typeTag = tag;
/*     */     }
/*     */     
/* 110 */     public int getTypeTag() { return this.typeTag; } public int getTypeData(ConstPool cp) {
/* 111 */       return 0;
/*     */     }
/*     */     public TypeData join() {
/* 114 */       if (this == TypeTag.TOP) {
/* 115 */         return this;
/*     */       }
/* 117 */       return super.join();
/*     */     }
/*     */     public BasicType isBasicType() {
/* 120 */       return this;
/*     */     }
/*     */     public boolean is2WordType() {
/* 123 */       return (this.typeTag == 4 || this.typeTag == 3);
/*     */     }
/*     */     
/*     */     public boolean eq(TypeData d) {
/* 127 */       return (this == d);
/*     */     }
/*     */     public String getName() {
/* 130 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setType(String s, ClassPool cp) throws BadBytecode {
/* 134 */       throw new BadBytecode("conflict: " + this.name + " and " + s);
/*     */     }
/*     */     public String toString() {
/* 137 */       return this.name;
/*     */     } }
/*     */   
/*     */   public static abstract class AbsTypeVar extends TypeData {
/*     */     public abstract void merge(TypeData param1TypeData);
/*     */     
/*     */     public int getTypeTag() {
/* 144 */       return 7;
/*     */     }
/*     */     public int getTypeData(ConstPool cp) {
/* 147 */       return cp.addClassInfo(getName());
/*     */     }
/*     */     public boolean eq(TypeData d) {
/* 150 */       return getName().equals(d.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeVar
/*     */     extends AbsTypeVar
/*     */   {
/*     */     protected ArrayList lowers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ArrayList usedBy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ArrayList uppers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String fixedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean is2WordType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int visited;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int smallest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean inList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeVar(TypeData t) {
/* 240 */       this.visited = 0;
/* 241 */       this.smallest = 0;
/* 242 */       this.inList = false; this.uppers = null; this.lowers = new ArrayList(2); this.usedBy = new ArrayList(2); merge(t); this.fixedType = null; this.is2WordType = t.is2WordType();
/*     */     }
/*     */     public String getName() { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).getName();  return this.fixedType; }
/*     */     public TypeData.BasicType isBasicType() { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).isBasicType();  return null; }
/* 246 */     public boolean is2WordType() { if (this.fixedType == null) return this.is2WordType;  return false; } public boolean isNullType() { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).isNullType();  return false; } public boolean isUninit() { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).isUninit();  return false; } public int dfs(ArrayList<TypeVar> preOrder, int index, ClassPool cp) throws NotFoundException { if (this.visited > 0) {
/* 247 */         return index;
/*     */       }
/* 249 */       this.visited = this.smallest = ++index;
/* 250 */       preOrder.add(this);
/* 251 */       this.inList = true;
/* 252 */       int n = this.lowers.size();
/* 253 */       for (int i = 0; i < n; i++) {
/* 254 */         TypeVar child = ((TypeData)this.lowers.get(i)).toTypeVar();
/* 255 */         if (child != null)
/* 256 */           if (child.visited == 0) {
/* 257 */             index = child.dfs(preOrder, index, cp);
/* 258 */             if (child.smallest < this.smallest) {
/* 259 */               this.smallest = child.smallest;
/*     */             }
/* 261 */           } else if (child.inList && 
/* 262 */             child.visited < this.smallest) {
/* 263 */             this.smallest = child.visited;
/*     */           }  
/*     */       } 
/* 266 */       if (this.visited == this.smallest) {
/* 267 */         ArrayList<TypeVar> scc = new ArrayList();
/*     */         
/*     */         while (true) {
/* 270 */           TypeVar cv = preOrder.remove(preOrder.size() - 1);
/* 271 */           cv.inList = false;
/* 272 */           scc.add(cv);
/* 273 */           if (cv == this) {
/* 274 */             fixTypes(scc, cp); break;
/*     */           } 
/*     */         } 
/* 277 */       }  return index; }
/*     */     public void merge(TypeData t) { this.lowers.add(t); if (t instanceof TypeVar) ((TypeVar)t).usedBy.add(this);  }
/*     */     public int getTypeTag() { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).getTypeTag();  return super.getTypeTag(); }
/*     */     public int getTypeData(ConstPool cp) { if (this.fixedType == null) return ((TypeData)this.lowers.get(0)).getTypeData(cp);  return super.getTypeData(cp); }
/* 281 */     public void setType(String typeName, ClassPool cp) throws BadBytecode { if (this.uppers == null) this.uppers = new ArrayList();  this.uppers.add(typeName); } protected TypeVar toTypeVar() { return this; } private void fixTypes(ArrayList<TypeVar> scc, ClassPool cp) throws NotFoundException { HashSet<String> lowersSet = new HashSet();
/* 282 */       boolean isBasicType = false;
/* 283 */       TypeData kind = null;
/* 284 */       int size = scc.size(); int i;
/* 285 */       for (i = 0; i < size; i++) {
/* 286 */         ArrayList<TypeData> tds = ((TypeVar)scc.get(i)).lowers;
/* 287 */         int size2 = tds.size();
/* 288 */         for (int j = 0; j < size2; j++) {
/* 289 */           TypeData d = tds.get(j);
/* 290 */           TypeData.BasicType bt = d.isBasicType();
/* 291 */           if (kind == null) {
/* 292 */             if (bt == null) {
/* 293 */               isBasicType = false;
/* 294 */               kind = d;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 299 */               if (d.isUninit()) {
/*     */                 break;
/*     */               }
/*     */             } else {
/* 303 */               isBasicType = true;
/* 304 */               kind = bt;
/*     */             }
/*     */           
/*     */           }
/* 308 */           else if ((bt == null && isBasicType) || (bt != null && kind != bt)) {
/*     */             
/* 310 */             isBasicType = true;
/* 311 */             kind = TypeTag.TOP;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 316 */           if (bt == null && !d.isNullType()) {
/* 317 */             lowersSet.add(d.getName());
/*     */           }
/*     */         } 
/*     */       } 
/* 321 */       if (isBasicType) {
/* 322 */         for (i = 0; i < size; i++) {
/* 323 */           TypeVar cv = scc.get(i);
/* 324 */           cv.lowers.clear();
/* 325 */           cv.lowers.add(kind);
/* 326 */           this.is2WordType = kind.is2WordType();
/*     */         } 
/*     */       } else {
/*     */         
/* 330 */         String typeName = fixTypes2(scc, lowersSet, cp);
/* 331 */         for (int j = 0; j < size; j++) {
/* 332 */           TypeVar cv = scc.get(j);
/* 333 */           cv.fixedType = typeName;
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/*     */     private String fixTypes2(ArrayList scc, HashSet lowersSet, ClassPool cp) throws NotFoundException {
/* 339 */       Iterator<String> it = lowersSet.iterator();
/* 340 */       if (lowersSet.size() == 0)
/* 341 */         return null; 
/* 342 */       if (lowersSet.size() == 1) {
/* 343 */         return it.next();
/*     */       }
/* 345 */       CtClass cc = cp.get(it.next());
/* 346 */       while (it.hasNext()) {
/* 347 */         cc = commonSuperClassEx(cc, cp.get(it.next()));
/*     */       }
/* 349 */       if (cc.getSuperclass() == null || isObjectArray(cc)) {
/* 350 */         cc = fixByUppers(scc, cp, new HashSet(), cc);
/*     */       }
/* 352 */       if (cc.isArray()) {
/* 353 */         return Descriptor.toJvmName(cc);
/*     */       }
/* 355 */       return cc.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     private static boolean isObjectArray(CtClass cc) throws NotFoundException {
/* 360 */       return (cc.isArray() && cc.getComponentType().getSuperclass() == null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CtClass fixByUppers(ArrayList<TypeVar> users, ClassPool cp, HashSet<TypeVar> visited, CtClass type) throws NotFoundException {
/* 366 */       if (users == null) {
/* 367 */         return type;
/*     */       }
/* 369 */       int size = users.size();
/* 370 */       for (int i = 0; i < size; i++) {
/* 371 */         TypeVar t = users.get(i);
/* 372 */         if (!visited.add(t)) {
/* 373 */           return type;
/*     */         }
/* 375 */         if (t.uppers != null) {
/* 376 */           int s = t.uppers.size();
/* 377 */           for (int k = 0; k < s; k++) {
/* 378 */             CtClass cc = cp.get(t.uppers.get(k));
/* 379 */             if (cc.subtypeOf(type)) {
/* 380 */               type = cc;
/*     */             }
/*     */           } 
/*     */         } 
/* 384 */         type = fixByUppers(t.usedBy, cp, visited, type);
/*     */       } 
/*     */       
/* 387 */       return type;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CtClass commonSuperClassEx(CtClass one, CtClass two) throws NotFoundException {
/* 396 */     if (one == two)
/* 397 */       return one; 
/* 398 */     if (one.isArray() && two.isArray()) {
/* 399 */       CtClass ele1 = one.getComponentType();
/* 400 */       CtClass ele2 = two.getComponentType();
/* 401 */       CtClass element = commonSuperClassEx(ele1, ele2);
/* 402 */       if (element == ele1)
/* 403 */         return one; 
/* 404 */       if (element == ele2) {
/* 405 */         return two;
/*     */       }
/* 407 */       return one.getClassPool().get((element == null) ? "java.lang.Object" : (element
/* 408 */           .getName() + "[]"));
/*     */     } 
/* 410 */     if (one.isPrimitive() || two.isPrimitive())
/* 411 */       return null; 
/* 412 */     if (one.isArray() || two.isArray()) {
/* 413 */       return one.getClassPool().get("java.lang.Object");
/*     */     }
/* 415 */     return commonSuperClass(one, two);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CtClass commonSuperClass(CtClass one, CtClass two) throws NotFoundException {
/* 423 */     CtClass deep = one;
/* 424 */     CtClass shallow = two;
/* 425 */     CtClass backupShallow = shallow;
/* 426 */     CtClass backupDeep = deep;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 431 */       if (eq(deep, shallow) && deep.getSuperclass() != null) {
/* 432 */         return deep;
/*     */       }
/* 434 */       CtClass deepSuper = deep.getSuperclass();
/* 435 */       CtClass shallowSuper = shallow.getSuperclass();
/*     */       
/* 437 */       if (shallowSuper == null) {
/*     */         
/* 439 */         shallow = backupShallow;
/*     */         
/*     */         break;
/*     */       } 
/* 443 */       if (deepSuper == null) {
/*     */         
/* 445 */         deep = backupDeep;
/* 446 */         backupDeep = backupShallow;
/* 447 */         backupShallow = deep;
/*     */         
/* 449 */         deep = shallow;
/* 450 */         shallow = backupShallow;
/*     */         
/*     */         break;
/*     */       } 
/* 454 */       deep = deepSuper;
/* 455 */       shallow = shallowSuper;
/*     */     } 
/*     */ 
/*     */     
/*     */     while (true) {
/* 460 */       deep = deep.getSuperclass();
/* 461 */       if (deep == null) {
/*     */         break;
/*     */       }
/* 464 */       backupDeep = backupDeep.getSuperclass();
/*     */     } 
/*     */     
/* 467 */     deep = backupDeep;
/*     */ 
/*     */ 
/*     */     
/* 471 */     while (!eq(deep, shallow)) {
/* 472 */       deep = deep.getSuperclass();
/* 473 */       shallow = shallow.getSuperclass();
/*     */     } 
/*     */     
/* 476 */     return deep;
/*     */   }
/*     */   
/*     */   static boolean eq(CtClass one, CtClass two) {
/* 480 */     return (one == two || (one != null && two != null && one.getName().equals(two.getName())));
/*     */   }
/*     */   
/*     */   public static void aastore(TypeData array, TypeData value, ClassPool cp) throws BadBytecode {
/* 484 */     if (array instanceof AbsTypeVar && 
/* 485 */       !value.isNullType()) {
/* 486 */       ((AbsTypeVar)array).merge(ArrayType.make(value));
/*     */     }
/* 488 */     if (value instanceof AbsTypeVar)
/* 489 */       if (array instanceof AbsTypeVar) {
/* 490 */         ArrayElement.make(array);
/* 491 */       } else if (array instanceof ClassName) {
/* 492 */         if (!array.isNullType()) {
/* 493 */           String type = ArrayElement.typeName(array.getName());
/* 494 */           value.setType(type, cp);
/*     */         } 
/*     */       } else {
/*     */         
/* 498 */         throw new BadBytecode("bad AASTORE: " + array);
/*     */       }  
/*     */   }
/*     */   
/*     */   public static class ArrayType
/*     */     extends AbsTypeVar
/*     */   {
/*     */     private TypeData.AbsTypeVar element;
/*     */     
/*     */     private ArrayType(TypeData.AbsTypeVar elementType) {
/* 508 */       this.element = elementType;
/*     */     }
/*     */     
/*     */     static TypeData make(TypeData element) throws BadBytecode {
/* 512 */       if (element instanceof TypeData.ArrayElement)
/* 513 */         return ((TypeData.ArrayElement)element).arrayType(); 
/* 514 */       if (element instanceof TypeData.AbsTypeVar)
/* 515 */         return new ArrayType((TypeData.AbsTypeVar)element); 
/* 516 */       if (element instanceof TypeData.ClassName && 
/* 517 */         !element.isNullType()) {
/* 518 */         return new TypeData.ClassName(typeName(element.getName()));
/*     */       }
/* 520 */       throw new BadBytecode("bad AASTORE: " + element);
/*     */     }
/*     */     
/*     */     public void merge(TypeData t) {
/*     */       try {
/* 525 */         if (!t.isNullType()) {
/* 526 */           this.element.merge(TypeData.ArrayElement.make(t));
/*     */         }
/* 528 */       } catch (BadBytecode e) {
/*     */         
/* 530 */         throw new RuntimeException("fatal: " + e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getName() {
/* 535 */       return typeName(this.element.getName());
/*     */     }
/*     */     public TypeData.AbsTypeVar elementType() {
/* 538 */       return this.element;
/*     */     }
/* 540 */     public TypeData.BasicType isBasicType() { return null; } public boolean is2WordType() {
/* 541 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static String typeName(String elementType) {
/* 547 */       if (elementType.charAt(0) == '[') {
/* 548 */         return "[" + elementType;
/*     */       }
/* 550 */       return "[L" + elementType.replace('.', '/') + ";";
/*     */     }
/*     */     
/*     */     public void setType(String s, ClassPool cp) throws BadBytecode {
/* 554 */       this.element.setType(TypeData.ArrayElement.typeName(s), cp);
/*     */     }
/*     */     protected TypeData.TypeVar toTypeVar() {
/* 557 */       return this.element.toTypeVar();
/*     */     }
/*     */     public int dfs(ArrayList order, int index, ClassPool cp) throws NotFoundException {
/* 560 */       return this.element.dfs(order, index, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ArrayElement
/*     */     extends AbsTypeVar
/*     */   {
/*     */     private TypeData.AbsTypeVar array;
/*     */     
/*     */     private ArrayElement(TypeData.AbsTypeVar a) {
/* 571 */       this.array = a;
/*     */     }
/*     */     
/*     */     public static TypeData make(TypeData array) throws BadBytecode {
/* 575 */       if (array instanceof TypeData.ArrayType)
/* 576 */         return ((TypeData.ArrayType)array).elementType(); 
/* 577 */       if (array instanceof TypeData.AbsTypeVar)
/* 578 */         return new ArrayElement((TypeData.AbsTypeVar)array); 
/* 579 */       if (array instanceof TypeData.ClassName && 
/* 580 */         !array.isNullType()) {
/* 581 */         return new TypeData.ClassName(typeName(array.getName()));
/*     */       }
/* 583 */       throw new BadBytecode("bad AASTORE: " + array);
/*     */     }
/*     */     
/*     */     public void merge(TypeData t) {
/*     */       try {
/* 588 */         if (!t.isNullType()) {
/* 589 */           this.array.merge(TypeData.ArrayType.make(t));
/*     */         }
/* 591 */       } catch (BadBytecode e) {
/*     */         
/* 593 */         throw new RuntimeException("fatal: " + e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getName() {
/* 598 */       return typeName(this.array.getName());
/*     */     }
/*     */     public TypeData.AbsTypeVar arrayType() {
/* 601 */       return this.array;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeData.BasicType isBasicType() {
/* 607 */       return null;
/*     */     } public boolean is2WordType() {
/* 609 */       return false;
/*     */     }
/*     */     private static String typeName(String arrayType) {
/* 612 */       if (arrayType.length() > 1 && arrayType.charAt(0) == '[') {
/* 613 */         char c = arrayType.charAt(1);
/* 614 */         if (c == 'L')
/* 615 */           return arrayType.substring(2, arrayType.length() - 1).replace('/', '.'); 
/* 616 */         if (c == '[') {
/* 617 */           return arrayType.substring(1);
/*     */         }
/*     */       } 
/* 620 */       return "java.lang.Object";
/*     */     }
/*     */     
/*     */     public void setType(String s, ClassPool cp) throws BadBytecode {
/* 624 */       this.array.setType(TypeData.ArrayType.typeName(s), cp);
/*     */     }
/*     */     protected TypeData.TypeVar toTypeVar() {
/* 627 */       return this.array.toTypeVar();
/*     */     }
/*     */     public int dfs(ArrayList order, int index, ClassPool cp) throws NotFoundException {
/* 630 */       return this.array.dfs(order, index, cp);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UninitTypeVar extends AbsTypeVar {
/*     */     protected TypeData type;
/*     */     
/* 637 */     public UninitTypeVar(TypeData.UninitData t) { this.type = t; }
/* 638 */     public int getTypeTag() { return this.type.getTypeTag(); }
/* 639 */     public int getTypeData(ConstPool cp) { return this.type.getTypeData(cp); }
/* 640 */     public TypeData.BasicType isBasicType() { return this.type.isBasicType(); }
/* 641 */     public boolean is2WordType() { return this.type.is2WordType(); }
/* 642 */     public boolean isUninit() { return this.type.isUninit(); }
/* 643 */     public boolean eq(TypeData d) { return this.type.eq(d); } public String getName() {
/* 644 */       return this.type.getName();
/*     */     }
/* 646 */     protected TypeData.TypeVar toTypeVar() { return null; } public TypeData join() {
/* 647 */       return this.type.join();
/*     */     }
/*     */     public void setType(String s, ClassPool cp) throws BadBytecode {
/* 650 */       this.type.setType(s, cp);
/*     */     }
/*     */     
/*     */     public void merge(TypeData t) {
/* 654 */       if (!t.eq(this.type))
/* 655 */         this.type = TypeTag.TOP; 
/*     */     }
/*     */     
/*     */     public void constructorCalled(int offset) {
/* 659 */       this.type.constructorCalled(offset);
/*     */     }
/*     */     
/*     */     public int offset() {
/* 663 */       if (this.type instanceof TypeData.UninitData) {
/* 664 */         return ((TypeData.UninitData)this.type).offset;
/*     */       }
/* 666 */       throw new RuntimeException("not available");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ClassName
/*     */     extends TypeData
/*     */   {
/*     */     private String name;
/*     */     
/*     */     public ClassName(String n) {
/* 677 */       this.name = n;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 681 */       return this.name;
/*     */     }
/*     */     public TypeData.BasicType isBasicType() {
/* 684 */       return null;
/*     */     } public boolean is2WordType() {
/* 686 */       return false;
/*     */     } public int getTypeTag() {
/* 688 */       return 7;
/*     */     }
/*     */     public int getTypeData(ConstPool cp) {
/* 691 */       return cp.addClassInfo(getName());
/*     */     }
/*     */     public boolean eq(TypeData d) {
/* 694 */       return this.name.equals(d.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     public void setType(String typeName, ClassPool cp) throws BadBytecode {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static class NullType
/*     */     extends ClassName
/*     */   {
/*     */     public NullType() {
/* 706 */       super("null-type");
/*     */     }
/*     */     
/*     */     public int getTypeTag() {
/* 710 */       return 5;
/*     */     }
/*     */     
/* 713 */     public boolean isNullType() { return true; } public int getTypeData(ConstPool cp) {
/* 714 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UninitData
/*     */     extends ClassName
/*     */   {
/*     */     int offset;
/*     */     boolean initialized;
/*     */     
/*     */     UninitData(int offset, String className) {
/* 725 */       super(className);
/* 726 */       this.offset = offset;
/* 727 */       this.initialized = false;
/*     */     }
/*     */     public UninitData copy() {
/* 730 */       return new UninitData(this.offset, getName());
/*     */     }
/*     */     public int getTypeTag() {
/* 733 */       return 8;
/*     */     }
/*     */     
/*     */     public int getTypeData(ConstPool cp) {
/* 737 */       return this.offset;
/*     */     }
/*     */     
/*     */     public TypeData join() {
/* 741 */       if (this.initialized) {
/* 742 */         return new TypeData.TypeVar(new TypeData.ClassName(getName()));
/*     */       }
/* 744 */       return new TypeData.UninitTypeVar(copy());
/*     */     }
/*     */     public boolean isUninit() {
/* 747 */       return true;
/*     */     }
/*     */     public boolean eq(TypeData d) {
/* 750 */       if (d instanceof UninitData) {
/* 751 */         UninitData ud = (UninitData)d;
/* 752 */         return (this.offset == ud.offset && getName().equals(ud.getName()));
/*     */       } 
/*     */       
/* 755 */       return false;
/*     */     }
/*     */     public String toString() {
/* 758 */       return "uninit:" + getName() + "@" + this.offset;
/*     */     } public int offset() {
/* 760 */       return this.offset;
/*     */     }
/*     */     public void constructorCalled(int offset) {
/* 763 */       if (offset == this.offset)
/* 764 */         this.initialized = true; 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UninitThis extends UninitData {
/*     */     UninitThis(String className) {
/* 770 */       super(-1, className);
/*     */     }
/*     */     public TypeData.UninitData copy() {
/* 773 */       return new UninitThis(getName());
/*     */     }
/*     */     public int getTypeTag() {
/* 776 */       return 6;
/*     */     }
/*     */     
/*     */     public int getTypeData(ConstPool cp) {
/* 780 */       return 0;
/*     */     }
/*     */     public String toString() {
/* 783 */       return "uninit:this";
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\stackmap\TypeData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */