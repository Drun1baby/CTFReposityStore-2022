/*      */ package javassist.bytecode;
/*      */ 
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javassist.CtClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ConstPool
/*      */ {
/*      */   LongVector items;
/*      */   int numOfItems;
/*      */   int thisClassInfo;
/*      */   HashMap itemsCache;
/*      */   public static final int CONST_Class = 7;
/*      */   public static final int CONST_Fieldref = 9;
/*      */   public static final int CONST_Methodref = 10;
/*      */   public static final int CONST_InterfaceMethodref = 11;
/*      */   public static final int CONST_String = 8;
/*      */   public static final int CONST_Integer = 3;
/*      */   public static final int CONST_Float = 4;
/*      */   public static final int CONST_Long = 5;
/*      */   public static final int CONST_Double = 6;
/*      */   public static final int CONST_NameAndType = 12;
/*      */   public static final int CONST_Utf8 = 1;
/*      */   public static final int CONST_MethodHandle = 15;
/*      */   public static final int CONST_MethodType = 16;
/*      */   public static final int CONST_InvokeDynamic = 18;
/*  114 */   public static final CtClass THIS = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_getField = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_getStatic = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_putField = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_putStatic = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_invokeVirtual = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_invokeStatic = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_invokeSpecial = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_newInvokeSpecial = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int REF_invokeInterface = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstPool(String thisclass) {
/*  168 */     this.items = new LongVector();
/*  169 */     this.itemsCache = null;
/*  170 */     this.numOfItems = 0;
/*  171 */     addItem0(null);
/*  172 */     this.thisClassInfo = addClassInfo(thisclass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstPool(DataInputStream in) throws IOException {
/*  181 */     this.itemsCache = null;
/*  182 */     this.thisClassInfo = 0;
/*      */ 
/*      */     
/*  185 */     read(in);
/*      */   }
/*      */   
/*      */   void prune() {
/*  189 */     this.itemsCache = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSize() {
/*  196 */     return this.numOfItems;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/*  203 */     return getClassInfo(this.thisClassInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getThisClassInfo() {
/*  211 */     return this.thisClassInfo;
/*      */   }
/*      */   
/*      */   void setThisClassInfo(int i) {
/*  215 */     this.thisClassInfo = i;
/*      */   }
/*      */   
/*      */   ConstInfo getItem(int n) {
/*  219 */     return this.items.elementAt(n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTag(int index) {
/*  227 */     return getItem(index).getTag();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassInfo(int index) {
/*  242 */     ClassInfo c = (ClassInfo)getItem(index);
/*  243 */     if (c == null) {
/*  244 */       return null;
/*      */     }
/*  246 */     return Descriptor.toJavaName(getUtf8Info(c.name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassInfoByDescriptor(int index) {
/*  259 */     ClassInfo c = (ClassInfo)getItem(index);
/*  260 */     if (c == null) {
/*  261 */       return null;
/*      */     }
/*  263 */     String className = getUtf8Info(c.name);
/*  264 */     if (className.charAt(0) == '[') {
/*  265 */       return className;
/*      */     }
/*  267 */     return Descriptor.of(className);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNameAndTypeName(int index) {
/*  277 */     NameAndTypeInfo ntinfo = (NameAndTypeInfo)getItem(index);
/*  278 */     return ntinfo.memberName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNameAndTypeDescriptor(int index) {
/*  287 */     NameAndTypeInfo ntinfo = (NameAndTypeInfo)getItem(index);
/*  288 */     return ntinfo.typeDescriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMemberClass(int index) {
/*  301 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  302 */     return minfo.classIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMemberNameAndType(int index) {
/*  315 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  316 */     return minfo.nameAndTypeIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFieldrefClass(int index) {
/*  325 */     FieldrefInfo finfo = (FieldrefInfo)getItem(index);
/*  326 */     return finfo.classIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFieldrefClassName(int index) {
/*  337 */     FieldrefInfo f = (FieldrefInfo)getItem(index);
/*  338 */     if (f == null) {
/*  339 */       return null;
/*      */     }
/*  341 */     return getClassInfo(f.classIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFieldrefNameAndType(int index) {
/*  350 */     FieldrefInfo finfo = (FieldrefInfo)getItem(index);
/*  351 */     return finfo.nameAndTypeIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFieldrefName(int index) {
/*  363 */     FieldrefInfo f = (FieldrefInfo)getItem(index);
/*  364 */     if (f == null) {
/*  365 */       return null;
/*      */     }
/*  367 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(f.nameAndTypeIndex);
/*  368 */     if (n == null) {
/*  369 */       return null;
/*      */     }
/*  371 */     return getUtf8Info(n.memberName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFieldrefType(int index) {
/*  384 */     FieldrefInfo f = (FieldrefInfo)getItem(index);
/*  385 */     if (f == null) {
/*  386 */       return null;
/*      */     }
/*  388 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(f.nameAndTypeIndex);
/*  389 */     if (n == null) {
/*  390 */       return null;
/*      */     }
/*  392 */     return getUtf8Info(n.typeDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMethodrefClass(int index) {
/*  402 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  403 */     return minfo.classIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMethodrefClassName(int index) {
/*  414 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  415 */     if (minfo == null) {
/*  416 */       return null;
/*      */     }
/*  418 */     return getClassInfo(minfo.classIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMethodrefNameAndType(int index) {
/*  427 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  428 */     return minfo.nameAndTypeIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMethodrefName(int index) {
/*  440 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  441 */     if (minfo == null) {
/*  442 */       return null;
/*      */     }
/*      */     
/*  445 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  446 */     if (n == null) {
/*  447 */       return null;
/*      */     }
/*  449 */     return getUtf8Info(n.memberName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMethodrefType(int index) {
/*  462 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  463 */     if (minfo == null) {
/*  464 */       return null;
/*      */     }
/*      */     
/*  467 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  468 */     if (n == null) {
/*  469 */       return null;
/*      */     }
/*  471 */     return getUtf8Info(n.typeDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInterfaceMethodrefClass(int index) {
/*  481 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  482 */     return minfo.classIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterfaceMethodrefClassName(int index) {
/*  493 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  494 */     return getClassInfo(minfo.classIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInterfaceMethodrefNameAndType(int index) {
/*  503 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  504 */     return minfo.nameAndTypeIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterfaceMethodrefName(int index) {
/*  517 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  518 */     if (minfo == null) {
/*  519 */       return null;
/*      */     }
/*      */     
/*  522 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  523 */     if (n == null) {
/*  524 */       return null;
/*      */     }
/*  526 */     return getUtf8Info(n.memberName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInterfaceMethodrefType(int index) {
/*  540 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  541 */     if (minfo == null) {
/*  542 */       return null;
/*      */     }
/*      */     
/*  545 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  546 */     if (n == null) {
/*  547 */       return null;
/*      */     }
/*  549 */     return getUtf8Info(n.typeDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getLdcValue(int index) {
/*  562 */     ConstInfo constInfo = getItem(index);
/*  563 */     Object value = null;
/*  564 */     if (constInfo instanceof StringInfo) {
/*  565 */       value = getStringInfo(index);
/*  566 */     } else if (constInfo instanceof FloatInfo) {
/*  567 */       value = new Float(getFloatInfo(index));
/*  568 */     } else if (constInfo instanceof IntegerInfo) {
/*  569 */       value = new Integer(getIntegerInfo(index));
/*  570 */     } else if (constInfo instanceof LongInfo) {
/*  571 */       value = new Long(getLongInfo(index));
/*  572 */     } else if (constInfo instanceof DoubleInfo) {
/*  573 */       value = new Double(getDoubleInfo(index));
/*      */     } else {
/*  575 */       value = null;
/*      */     } 
/*  577 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntegerInfo(int index) {
/*  587 */     IntegerInfo i = (IntegerInfo)getItem(index);
/*  588 */     return i.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatInfo(int index) {
/*  598 */     FloatInfo i = (FloatInfo)getItem(index);
/*  599 */     return i.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongInfo(int index) {
/*  609 */     LongInfo i = (LongInfo)getItem(index);
/*  610 */     return i.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleInfo(int index) {
/*  620 */     DoubleInfo i = (DoubleInfo)getItem(index);
/*  621 */     return i.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringInfo(int index) {
/*  631 */     StringInfo si = (StringInfo)getItem(index);
/*  632 */     return getUtf8Info(si.string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUtf8Info(int index) {
/*  642 */     Utf8Info utf = (Utf8Info)getItem(index);
/*  643 */     return utf.string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMethodHandleKind(int index) {
/*  663 */     MethodHandleInfo mhinfo = (MethodHandleInfo)getItem(index);
/*  664 */     return mhinfo.refKind;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMethodHandleIndex(int index) {
/*  675 */     MethodHandleInfo mhinfo = (MethodHandleInfo)getItem(index);
/*  676 */     return mhinfo.refIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMethodTypeInfo(int index) {
/*  687 */     MethodTypeInfo mtinfo = (MethodTypeInfo)getItem(index);
/*  688 */     return mtinfo.descriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInvokeDynamicBootstrap(int index) {
/*  699 */     InvokeDynamicInfo iv = (InvokeDynamicInfo)getItem(index);
/*  700 */     return iv.bootstrap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInvokeDynamicNameAndType(int index) {
/*  711 */     InvokeDynamicInfo iv = (InvokeDynamicInfo)getItem(index);
/*  712 */     return iv.nameAndType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getInvokeDynamicType(int index) {
/*  725 */     InvokeDynamicInfo iv = (InvokeDynamicInfo)getItem(index);
/*  726 */     if (iv == null) {
/*  727 */       return null;
/*      */     }
/*  729 */     NameAndTypeInfo n = (NameAndTypeInfo)getItem(iv.nameAndType);
/*  730 */     if (n == null) {
/*  731 */       return null;
/*      */     }
/*  733 */     return getUtf8Info(n.typeDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int isConstructor(String classname, int index) {
/*  748 */     return isMember(classname, "<init>", index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int isMember(String classname, String membername, int index) {
/*  768 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*  769 */     if (getClassInfo(minfo.classIndex).equals(classname)) {
/*      */       
/*  771 */       NameAndTypeInfo ntinfo = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  772 */       if (getUtf8Info(ntinfo.memberName).equals(membername)) {
/*  773 */         return ntinfo.typeDescriptor;
/*      */       }
/*      */     } 
/*  776 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String eqMember(String membername, String desc, int index) {
/*  797 */     MemberrefInfo minfo = (MemberrefInfo)getItem(index);
/*      */     
/*  799 */     NameAndTypeInfo ntinfo = (NameAndTypeInfo)getItem(minfo.nameAndTypeIndex);
/*  800 */     if (getUtf8Info(ntinfo.memberName).equals(membername) && 
/*  801 */       getUtf8Info(ntinfo.typeDescriptor).equals(desc)) {
/*  802 */       return getClassInfo(minfo.classIndex);
/*      */     }
/*  804 */     return null;
/*      */   }
/*      */   
/*      */   private int addItem0(ConstInfo info) {
/*  808 */     this.items.addElement(info);
/*  809 */     return this.numOfItems++;
/*      */   }
/*      */   
/*      */   private int addItem(ConstInfo info) {
/*  813 */     if (this.itemsCache == null) {
/*  814 */       this.itemsCache = makeItemsCache(this.items);
/*      */     }
/*  816 */     ConstInfo found = (ConstInfo)this.itemsCache.get(info);
/*  817 */     if (found != null) {
/*  818 */       return found.index;
/*      */     }
/*  820 */     this.items.addElement(info);
/*  821 */     this.itemsCache.put(info, info);
/*  822 */     return this.numOfItems++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int copy(int n, ConstPool dest, Map classnames) {
/*  838 */     if (n == 0) {
/*  839 */       return 0;
/*      */     }
/*  841 */     ConstInfo info = getItem(n);
/*  842 */     return info.copy(this, dest, classnames);
/*      */   }
/*      */   
/*      */   int addConstInfoPadding() {
/*  846 */     return addItem0(new ConstInfoPadding(this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addClassInfo(CtClass c) {
/*  858 */     if (c == THIS)
/*  859 */       return this.thisClassInfo; 
/*  860 */     if (!c.isArray()) {
/*  861 */       return addClassInfo(c.getName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  868 */     return addClassInfo(Descriptor.toJvmName(c));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addClassInfo(String qname) {
/*  883 */     int utf8 = addUtf8Info(Descriptor.toJvmName(qname));
/*  884 */     return addItem(new ClassInfo(utf8, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addNameAndTypeInfo(String name, String type) {
/*  897 */     return addNameAndTypeInfo(addUtf8Info(name), addUtf8Info(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addNameAndTypeInfo(int name, int type) {
/*  908 */     return addItem(new NameAndTypeInfo(name, type, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addFieldrefInfo(int classInfo, String name, String type) {
/*  925 */     int nt = addNameAndTypeInfo(name, type);
/*  926 */     return addFieldrefInfo(classInfo, nt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addFieldrefInfo(int classInfo, int nameAndTypeInfo) {
/*  937 */     return addItem(new FieldrefInfo(classInfo, nameAndTypeInfo, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addMethodrefInfo(int classInfo, String name, String type) {
/*  954 */     int nt = addNameAndTypeInfo(name, type);
/*  955 */     return addMethodrefInfo(classInfo, nt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addMethodrefInfo(int classInfo, int nameAndTypeInfo) {
/*  966 */     return addItem(new MethodrefInfo(classInfo, nameAndTypeInfo, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addInterfaceMethodrefInfo(int classInfo, String name, String type) {
/*  985 */     int nt = addNameAndTypeInfo(name, type);
/*  986 */     return addInterfaceMethodrefInfo(classInfo, nt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addInterfaceMethodrefInfo(int classInfo, int nameAndTypeInfo) {
/*  999 */     return addItem(new InterfaceMethodrefInfo(classInfo, nameAndTypeInfo, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addStringInfo(String str) {
/* 1013 */     int utf = addUtf8Info(str);
/* 1014 */     return addItem(new StringInfo(utf, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addIntegerInfo(int i) {
/* 1024 */     return addItem(new IntegerInfo(i, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addFloatInfo(float f) {
/* 1034 */     return addItem(new FloatInfo(f, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addLongInfo(long l) {
/* 1044 */     int i = addItem(new LongInfo(l, this.numOfItems));
/* 1045 */     if (i == this.numOfItems - 1) {
/* 1046 */       addConstInfoPadding();
/*      */     }
/* 1048 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addDoubleInfo(double d) {
/* 1058 */     int i = addItem(new DoubleInfo(d, this.numOfItems));
/* 1059 */     if (i == this.numOfItems - 1) {
/* 1060 */       addConstInfoPadding();
/*      */     }
/* 1062 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addUtf8Info(String utf8) {
/* 1072 */     return addItem(new Utf8Info(utf8, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addMethodHandleInfo(int kind, int index) {
/* 1087 */     return addItem(new MethodHandleInfo(kind, index, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addMethodTypeInfo(int desc) {
/* 1100 */     return addItem(new MethodTypeInfo(desc, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addInvokeDynamicInfo(int bootstrap, int nameAndType) {
/* 1114 */     return addItem(new InvokeDynamicInfo(bootstrap, nameAndType, this.numOfItems));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set getClassNames() {
/* 1123 */     HashSet<String> result = new HashSet();
/* 1124 */     LongVector v = this.items;
/* 1125 */     int size = this.numOfItems;
/* 1126 */     for (int i = 1; i < size; i++) {
/* 1127 */       String className = v.elementAt(i).getClassName(this);
/* 1128 */       if (className != null)
/* 1129 */         result.add(className); 
/*      */     } 
/* 1131 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renameClass(String oldName, String newName) {
/* 1141 */     LongVector v = this.items;
/* 1142 */     int size = this.numOfItems;
/* 1143 */     for (int i = 1; i < size; i++) {
/* 1144 */       ConstInfo ci = v.elementAt(i);
/* 1145 */       ci.renameClass(this, oldName, newName, this.itemsCache);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renameClass(Map classnames) {
/* 1156 */     LongVector v = this.items;
/* 1157 */     int size = this.numOfItems;
/* 1158 */     for (int i = 1; i < size; i++) {
/* 1159 */       ConstInfo ci = v.elementAt(i);
/* 1160 */       ci.renameClass(this, classnames, this.itemsCache);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void read(DataInputStream in) throws IOException {
/* 1165 */     int n = in.readUnsignedShort();
/*      */     
/* 1167 */     this.items = new LongVector(n);
/* 1168 */     this.numOfItems = 0;
/* 1169 */     addItem0(null);
/*      */     
/* 1171 */     while (--n > 0) {
/* 1172 */       int tag = readOne(in);
/* 1173 */       if (tag == 5 || tag == 6) {
/* 1174 */         addConstInfoPadding();
/* 1175 */         n--;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static HashMap makeItemsCache(LongVector items) {
/* 1181 */     HashMap<Object, Object> cache = new HashMap<Object, Object>();
/* 1182 */     int i = 1;
/*      */     while (true) {
/* 1184 */       ConstInfo info = items.elementAt(i++);
/* 1185 */       if (info == null) {
/*      */         break;
/*      */       }
/* 1188 */       cache.put(info, info);
/*      */     } 
/*      */     
/* 1191 */     return cache;
/*      */   }
/*      */   
/*      */   private int readOne(DataInputStream in) throws IOException {
/*      */     ConstInfo info;
/* 1196 */     int tag = in.readUnsignedByte();
/* 1197 */     switch (tag) {
/*      */       case 1:
/* 1199 */         info = new Utf8Info(in, this.numOfItems);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1244 */         addItem0(info);
/* 1245 */         return tag;case 3: info = new IntegerInfo(in, this.numOfItems); addItem0(info); return tag;case 4: info = new FloatInfo(in, this.numOfItems); addItem0(info); return tag;case 5: info = new LongInfo(in, this.numOfItems); addItem0(info); return tag;case 6: info = new DoubleInfo(in, this.numOfItems); addItem0(info); return tag;case 7: info = new ClassInfo(in, this.numOfItems); addItem0(info); return tag;case 8: info = new StringInfo(in, this.numOfItems); addItem0(info); return tag;case 9: info = new FieldrefInfo(in, this.numOfItems); addItem0(info); return tag;case 10: info = new MethodrefInfo(in, this.numOfItems); addItem0(info); return tag;case 11: info = new InterfaceMethodrefInfo(in, this.numOfItems); addItem0(info); return tag;case 12: info = new NameAndTypeInfo(in, this.numOfItems); addItem0(info); return tag;case 15: info = new MethodHandleInfo(in, this.numOfItems); addItem0(info); return tag;case 16: info = new MethodTypeInfo(in, this.numOfItems); addItem0(info); return tag;case 18: info = new InvokeDynamicInfo(in, this.numOfItems); addItem0(info); return tag;
/*      */     } 
/*      */     throw new IOException("invalid constant type: " + tag + " at " + this.numOfItems);
/*      */   }
/*      */ 
/*      */   
/*      */   public void write(DataOutputStream out) throws IOException {
/* 1252 */     out.writeShort(this.numOfItems);
/* 1253 */     LongVector v = this.items;
/* 1254 */     int size = this.numOfItems;
/* 1255 */     for (int i = 1; i < size; i++) {
/* 1256 */       v.elementAt(i).write(out);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void print() {
/* 1263 */     print(new PrintWriter(System.out, true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(PrintWriter out) {
/* 1270 */     int size = this.numOfItems;
/* 1271 */     for (int i = 1; i < size; i++) {
/* 1272 */       out.print(i);
/* 1273 */       out.print(" ");
/* 1274 */       this.items.elementAt(i).print(out);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\ConstPool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */