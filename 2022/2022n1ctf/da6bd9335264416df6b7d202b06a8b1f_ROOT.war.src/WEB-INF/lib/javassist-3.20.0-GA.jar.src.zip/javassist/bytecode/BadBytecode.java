/*    */ package javassist.bytecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadBytecode
/*    */   extends Exception
/*    */ {
/*    */   public BadBytecode(int opcode) {
/* 24 */     super("bytecode " + opcode);
/*    */   }
/*    */   
/*    */   public BadBytecode(String msg) {
/* 28 */     super(msg);
/*    */   }
/*    */   
/*    */   public BadBytecode(String msg, Throwable cause) {
/* 32 */     super(msg, cause);
/*    */   }
/*    */   
/*    */   public BadBytecode(MethodInfo minfo, Throwable cause) {
/* 36 */     super(minfo.toString() + " in " + minfo
/* 37 */         .getConstPool().getClassName() + ": " + cause
/* 38 */         .getMessage(), cause);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\BadBytecode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */