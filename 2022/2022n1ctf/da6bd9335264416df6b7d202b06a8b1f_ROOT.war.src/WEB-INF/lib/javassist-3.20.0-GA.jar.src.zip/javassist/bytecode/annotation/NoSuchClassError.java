/*    */ package javassist.bytecode.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoSuchClassError
/*    */   extends Error
/*    */ {
/*    */   private String className;
/*    */   
/*    */   public NoSuchClassError(String className, Error cause) {
/* 30 */     super(cause.toString(), cause);
/* 31 */     this.className = className;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClassName() {
/* 38 */     return this.className;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\annotation\NoSuchClassError.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */