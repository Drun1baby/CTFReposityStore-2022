/*     */ package javassist.bytecode;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeInfo
/*     */ {
/*     */   protected ConstPool constPool;
/*     */   int name;
/*     */   byte[] info;
/*     */   
/*     */   protected AttributeInfo(ConstPool cp, int attrname, byte[] attrinfo) {
/*  40 */     this.constPool = cp;
/*  41 */     this.name = attrname;
/*  42 */     this.info = attrinfo;
/*     */   }
/*     */   
/*     */   protected AttributeInfo(ConstPool cp, String attrname) {
/*  46 */     this(cp, attrname, (byte[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeInfo(ConstPool cp, String attrname, byte[] attrinfo) {
/*  58 */     this(cp, cp.addUtf8Info(attrname), attrinfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AttributeInfo(ConstPool cp, int n, DataInputStream in) throws IOException {
/*  64 */     this.constPool = cp;
/*  65 */     this.name = n;
/*  66 */     int len = in.readInt();
/*  67 */     this.info = new byte[len];
/*  68 */     if (len > 0) {
/*  69 */       in.readFully(this.info);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static AttributeInfo read(ConstPool cp, DataInputStream in) throws IOException {
/*  75 */     int name = in.readUnsignedShort();
/*  76 */     String nameStr = cp.getUtf8Info(name);
/*  77 */     char first = nameStr.charAt(0);
/*  78 */     if (first < 'M') {
/*  79 */       if (first < 'E') {
/*  80 */         if (nameStr.equals("AnnotationDefault"))
/*  81 */           return new AnnotationDefaultAttribute(cp, name, in); 
/*  82 */         if (nameStr.equals("BootstrapMethods"))
/*  83 */           return new BootstrapMethodsAttribute(cp, name, in); 
/*  84 */         if (nameStr.equals("Code"))
/*  85 */           return new CodeAttribute(cp, name, in); 
/*  86 */         if (nameStr.equals("ConstantValue"))
/*  87 */           return new ConstantAttribute(cp, name, in); 
/*  88 */         if (nameStr.equals("Deprecated")) {
/*  89 */           return new DeprecatedAttribute(cp, name, in);
/*     */         }
/*     */       } else {
/*  92 */         if (nameStr.equals("EnclosingMethod"))
/*  93 */           return new EnclosingMethodAttribute(cp, name, in); 
/*  94 */         if (nameStr.equals("Exceptions"))
/*  95 */           return new ExceptionsAttribute(cp, name, in); 
/*  96 */         if (nameStr.equals("InnerClasses"))
/*  97 */           return new InnerClassesAttribute(cp, name, in); 
/*  98 */         if (nameStr.equals("LineNumberTable"))
/*  99 */           return new LineNumberAttribute(cp, name, in); 
/* 100 */         if (nameStr.equals("LocalVariableTable"))
/* 101 */           return new LocalVariableAttribute(cp, name, in); 
/* 102 */         if (nameStr.equals("LocalVariableTypeTable")) {
/* 103 */           return new LocalVariableTypeAttribute(cp, name, in);
/*     */         }
/*     */       }
/*     */     
/* 107 */     } else if (first < 'S') {
/*     */ 
/*     */       
/* 110 */       if (nameStr.equals("MethodParameters"))
/* 111 */         return new MethodParametersAttribute(cp, name, in); 
/* 112 */       if (nameStr.equals("RuntimeVisibleAnnotations") || nameStr
/* 113 */         .equals("RuntimeInvisibleAnnotations"))
/*     */       {
/* 115 */         return new AnnotationsAttribute(cp, name, in);
/*     */       }
/* 117 */       if (nameStr.equals("RuntimeVisibleParameterAnnotations") || nameStr
/* 118 */         .equals("RuntimeInvisibleParameterAnnotations"))
/* 119 */         return new ParameterAnnotationsAttribute(cp, name, in); 
/* 120 */       if (nameStr.equals("RuntimeVisibleTypeAnnotations") || nameStr
/* 121 */         .equals("RuntimeInvisibleTypeAnnotations")) {
/* 122 */         return new TypeAnnotationsAttribute(cp, name, in);
/*     */       }
/*     */     } else {
/* 125 */       if (nameStr.equals("Signature"))
/* 126 */         return new SignatureAttribute(cp, name, in); 
/* 127 */       if (nameStr.equals("SourceFile"))
/* 128 */         return new SourceFileAttribute(cp, name, in); 
/* 129 */       if (nameStr.equals("Synthetic"))
/* 130 */         return new SyntheticAttribute(cp, name, in); 
/* 131 */       if (nameStr.equals("StackMap"))
/* 132 */         return new StackMap(cp, name, in); 
/* 133 */       if (nameStr.equals("StackMapTable")) {
/* 134 */         return new StackMapTable(cp, name, in);
/*     */       }
/*     */     } 
/*     */     
/* 138 */     return new AttributeInfo(cp, name, in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 145 */     return this.constPool.getUtf8Info(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstPool getConstPool() {
/* 151 */     return this.constPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 159 */     return this.info.length + 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] get() {
/* 169 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(byte[] newinfo) {
/* 178 */     this.info = newinfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeInfo copy(ConstPool newCp, Map classnames) {
/* 189 */     int s = this.info.length;
/* 190 */     byte[] srcInfo = this.info;
/* 191 */     byte[] newInfo = new byte[s];
/* 192 */     for (int i = 0; i < s; i++) {
/* 193 */       newInfo[i] = srcInfo[i];
/*     */     }
/* 195 */     return new AttributeInfo(newCp, getName(), newInfo);
/*     */   }
/*     */   
/*     */   void write(DataOutputStream out) throws IOException {
/* 199 */     out.writeShort(this.name);
/* 200 */     out.writeInt(this.info.length);
/* 201 */     if (this.info.length > 0)
/* 202 */       out.write(this.info); 
/*     */   }
/*     */   
/*     */   static int getLength(ArrayList<AttributeInfo> list) {
/* 206 */     int size = 0;
/* 207 */     int n = list.size();
/* 208 */     for (int i = 0; i < n; i++) {
/* 209 */       AttributeInfo attr = list.get(i);
/* 210 */       size += attr.length();
/*     */     } 
/*     */     
/* 213 */     return size;
/*     */   }
/*     */   
/*     */   static AttributeInfo lookup(ArrayList list, String name) {
/* 217 */     if (list == null) {
/* 218 */       return null;
/*     */     }
/* 220 */     ListIterator<AttributeInfo> iterator = list.listIterator();
/* 221 */     while (iterator.hasNext()) {
/* 222 */       AttributeInfo ai = iterator.next();
/* 223 */       if (ai.getName().equals(name)) {
/* 224 */         return ai;
/*     */       }
/*     */     } 
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   static synchronized void remove(ArrayList list, String name) {
/* 231 */     if (list == null) {
/*     */       return;
/*     */     }
/* 234 */     ListIterator<AttributeInfo> iterator = list.listIterator();
/* 235 */     while (iterator.hasNext()) {
/* 236 */       AttributeInfo ai = iterator.next();
/* 237 */       if (ai.getName().equals(name)) {
/* 238 */         iterator.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeAll(ArrayList<AttributeInfo> list, DataOutputStream out) throws IOException {
/* 245 */     if (list == null) {
/*     */       return;
/*     */     }
/* 248 */     int n = list.size();
/* 249 */     for (int i = 0; i < n; i++) {
/* 250 */       AttributeInfo attr = list.get(i);
/* 251 */       attr.write(out);
/*     */     } 
/*     */   }
/*     */   
/*     */   static ArrayList copyAll(ArrayList<AttributeInfo> list, ConstPool cp) {
/* 256 */     if (list == null) {
/* 257 */       return null;
/*     */     }
/* 259 */     ArrayList<AttributeInfo> newList = new ArrayList();
/* 260 */     int n = list.size();
/* 261 */     for (int i = 0; i < n; i++) {
/* 262 */       AttributeInfo attr = list.get(i);
/* 263 */       newList.add(attr.copy(cp, null));
/*     */     } 
/*     */     
/* 266 */     return newList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void renameClass(String oldname, String newname) {}
/*     */ 
/*     */ 
/*     */   
/*     */   void renameClass(Map classnames) {}
/*     */ 
/*     */   
/*     */   static void renameClass(List attributes, String oldname, String newname) {
/* 279 */     Iterator<AttributeInfo> iterator = attributes.iterator();
/* 280 */     while (iterator.hasNext()) {
/* 281 */       AttributeInfo ai = iterator.next();
/* 282 */       ai.renameClass(oldname, newname);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void renameClass(List attributes, Map classnames) {
/* 287 */     Iterator<AttributeInfo> iterator = attributes.iterator();
/* 288 */     while (iterator.hasNext()) {
/* 289 */       AttributeInfo ai = iterator.next();
/* 290 */       ai.renameClass(classnames);
/*     */     } 
/*     */   }
/*     */   
/*     */   void getRefClasses(Map classnames) {}
/*     */   
/*     */   static void getRefClasses(List attributes, Map classnames) {
/* 297 */     Iterator<AttributeInfo> iterator = attributes.iterator();
/* 298 */     while (iterator.hasNext()) {
/* 299 */       AttributeInfo ai = iterator.next();
/* 300 */       ai.getRefClasses(classnames);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\AttributeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */