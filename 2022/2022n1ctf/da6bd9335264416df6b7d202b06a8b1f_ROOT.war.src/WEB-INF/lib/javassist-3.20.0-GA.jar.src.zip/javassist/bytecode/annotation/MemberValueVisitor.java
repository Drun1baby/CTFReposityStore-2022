package javassist.bytecode.annotation;

public interface MemberValueVisitor {
  void visitAnnotationMemberValue(AnnotationMemberValue paramAnnotationMemberValue);
  
  void visitArrayMemberValue(ArrayMemberValue paramArrayMemberValue);
  
  void visitBooleanMemberValue(BooleanMemberValue paramBooleanMemberValue);
  
  void visitByteMemberValue(ByteMemberValue paramByteMemberValue);
  
  void visitCharMemberValue(CharMemberValue paramCharMemberValue);
  
  void visitDoubleMemberValue(DoubleMemberValue paramDoubleMemberValue);
  
  void visitEnumMemberValue(EnumMemberValue paramEnumMemberValue);
  
  void visitFloatMemberValue(FloatMemberValue paramFloatMemberValue);
  
  void visitIntegerMemberValue(IntegerMemberValue paramIntegerMemberValue);
  
  void visitLongMemberValue(LongMemberValue paramLongMemberValue);
  
  void visitShortMemberValue(ShortMemberValue paramShortMemberValue);
  
  void visitStringMemberValue(StringMemberValue paramStringMemberValue);
  
  void visitClassMemberValue(ClassMemberValue paramClassMemberValue);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\annotation\MemberValueVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */