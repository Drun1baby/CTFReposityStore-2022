/*     */ package javassist.bytecode;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldInfo
/*     */ {
/*     */   ConstPool constPool;
/*     */   int accessFlags;
/*     */   int name;
/*     */   String cachedName;
/*     */   String cachedType;
/*     */   int descriptor;
/*     */   ArrayList attribute;
/*     */   
/*     */   private FieldInfo(ConstPool cp) {
/*  49 */     this.constPool = cp;
/*  50 */     this.accessFlags = 0;
/*  51 */     this.attribute = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInfo(ConstPool cp, String fieldName, String desc) {
/*  64 */     this(cp);
/*  65 */     this.name = cp.addUtf8Info(fieldName);
/*  66 */     this.cachedName = fieldName;
/*  67 */     this.descriptor = cp.addUtf8Info(desc);
/*     */   }
/*     */   
/*     */   FieldInfo(ConstPool cp, DataInputStream in) throws IOException {
/*  71 */     this(cp);
/*  72 */     read(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  79 */     return getName() + " " + getDescriptor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void compact(ConstPool cp) {
/*  91 */     this.name = cp.addUtf8Info(getName());
/*  92 */     this.descriptor = cp.addUtf8Info(getDescriptor());
/*  93 */     this.attribute = AttributeInfo.copyAll(this.attribute, cp);
/*  94 */     this.constPool = cp;
/*     */   }
/*     */   
/*     */   void prune(ConstPool cp) {
/*  98 */     ArrayList<AttributeInfo> newAttributes = new ArrayList();
/*     */     
/* 100 */     AttributeInfo invisibleAnnotations = getAttribute("RuntimeInvisibleAnnotations");
/* 101 */     if (invisibleAnnotations != null) {
/* 102 */       invisibleAnnotations = invisibleAnnotations.copy(cp, null);
/* 103 */       newAttributes.add(invisibleAnnotations);
/*     */     } 
/*     */ 
/*     */     
/* 107 */     AttributeInfo visibleAnnotations = getAttribute("RuntimeVisibleAnnotations");
/* 108 */     if (visibleAnnotations != null) {
/* 109 */       visibleAnnotations = visibleAnnotations.copy(cp, null);
/* 110 */       newAttributes.add(visibleAnnotations);
/*     */     } 
/*     */ 
/*     */     
/* 114 */     AttributeInfo signature = getAttribute("Signature");
/* 115 */     if (signature != null) {
/* 116 */       signature = signature.copy(cp, null);
/* 117 */       newAttributes.add(signature);
/*     */     } 
/*     */     
/* 120 */     int index = getConstantValue();
/* 121 */     if (index != 0) {
/* 122 */       index = this.constPool.copy(index, cp, null);
/* 123 */       newAttributes.add(new ConstantAttribute(cp, index));
/*     */     } 
/*     */     
/* 126 */     this.attribute = newAttributes;
/* 127 */     this.name = cp.addUtf8Info(getName());
/* 128 */     this.descriptor = cp.addUtf8Info(getDescriptor());
/* 129 */     this.constPool = cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConstPool getConstPool() {
/* 137 */     return this.constPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 144 */     if (this.cachedName == null) {
/* 145 */       this.cachedName = this.constPool.getUtf8Info(this.name);
/*     */     }
/* 147 */     return this.cachedName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String newName) {
/* 154 */     this.name = this.constPool.addUtf8Info(newName);
/* 155 */     this.cachedName = newName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAccessFlags() {
/* 164 */     return this.accessFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccessFlags(int acc) {
/* 173 */     this.accessFlags = acc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescriptor() {
/* 182 */     return this.constPool.getUtf8Info(this.descriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescriptor(String desc) {
/* 191 */     if (!desc.equals(getDescriptor())) {
/* 192 */       this.descriptor = this.constPool.addUtf8Info(desc);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConstantValue() {
/* 202 */     if ((this.accessFlags & 0x8) == 0) {
/* 203 */       return 0;
/*     */     }
/*     */     
/* 206 */     ConstantAttribute attr = (ConstantAttribute)getAttribute("ConstantValue");
/* 207 */     if (attr == null) {
/* 208 */       return 0;
/*     */     }
/* 210 */     return attr.getConstantValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getAttributes() {
/* 224 */     if (this.attribute == null) {
/* 225 */       this.attribute = new ArrayList();
/*     */     }
/* 227 */     return this.attribute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeInfo getAttribute(String name) {
/* 238 */     return AttributeInfo.lookup(this.attribute, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttribute(AttributeInfo info) {
/* 248 */     if (this.attribute == null) {
/* 249 */       this.attribute = new ArrayList();
/*     */     }
/* 251 */     AttributeInfo.remove(this.attribute, info.getName());
/* 252 */     this.attribute.add(info);
/*     */   }
/*     */   
/*     */   private void read(DataInputStream in) throws IOException {
/* 256 */     this.accessFlags = in.readUnsignedShort();
/* 257 */     this.name = in.readUnsignedShort();
/* 258 */     this.descriptor = in.readUnsignedShort();
/* 259 */     int n = in.readUnsignedShort();
/* 260 */     this.attribute = new ArrayList();
/* 261 */     for (int i = 0; i < n; i++)
/* 262 */       this.attribute.add(AttributeInfo.read(this.constPool, in)); 
/*     */   }
/*     */   
/*     */   void write(DataOutputStream out) throws IOException {
/* 266 */     out.writeShort(this.accessFlags);
/* 267 */     out.writeShort(this.name);
/* 268 */     out.writeShort(this.descriptor);
/* 269 */     if (this.attribute == null) {
/* 270 */       out.writeShort(0);
/*     */     } else {
/* 272 */       out.writeShort(this.attribute.size());
/* 273 */       AttributeInfo.writeAll(this.attribute, out);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\bytecode\FieldInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */