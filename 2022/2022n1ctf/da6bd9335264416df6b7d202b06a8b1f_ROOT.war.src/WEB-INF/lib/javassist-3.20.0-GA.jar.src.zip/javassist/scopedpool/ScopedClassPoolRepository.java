package javassist.scopedpool;

import java.util.Map;
import javassist.ClassPool;

public interface ScopedClassPoolRepository {
  void setClassPoolFactory(ScopedClassPoolFactory paramScopedClassPoolFactory);
  
  ScopedClassPoolFactory getClassPoolFactory();
  
  boolean isPrune();
  
  void setPrune(boolean paramBoolean);
  
  ScopedClassPool createScopedClassPool(ClassLoader paramClassLoader, ClassPool paramClassPool);
  
  ClassPool findClassPool(ClassLoader paramClassLoader);
  
  ClassPool registerClassLoader(ClassLoader paramClassLoader);
  
  Map getRegisteredCLs();
  
  void clearUnregisteredClassLoaders();
  
  void unregisterClassLoader(ClassLoader paramClassLoader);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\scopedpool\ScopedClassPoolRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */