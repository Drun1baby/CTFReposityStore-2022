/*      */ package javassist.util.proxy;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import javassist.CannotCompileException;
/*      */ import javassist.bytecode.Bytecode;
/*      */ import javassist.bytecode.ClassFile;
/*      */ import javassist.bytecode.CodeAttribute;
/*      */ import javassist.bytecode.ConstPool;
/*      */ import javassist.bytecode.Descriptor;
/*      */ import javassist.bytecode.DuplicateMemberException;
/*      */ import javassist.bytecode.ExceptionsAttribute;
/*      */ import javassist.bytecode.FieldInfo;
/*      */ import javassist.bytecode.MethodInfo;
/*      */ import javassist.bytecode.StackMapTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ProxyFactory
/*      */ {
/*      */   private Class superClass;
/*      */   private Class[] interfaces;
/*      */   private MethodFilter methodFilter;
/*      */   private MethodHandler handler;
/*      */   private List signatureMethods;
/*      */   private boolean hasGetHandler;
/*      */   private byte[] signature;
/*      */   private String classname;
/*      */   private String basename;
/*      */   private String superName;
/*      */   private Class thisClass;
/*      */   private boolean factoryUseCache;
/*      */   private boolean factoryWriteReplace;
/*      */   public String writeDirectory;
/*  189 */   private static final Class OBJECT_TYPE = Object.class;
/*      */   
/*      */   private static final String HOLDER = "_methods_";
/*      */   private static final String HOLDER_TYPE = "[Ljava/lang/reflect/Method;";
/*      */   private static final String FILTER_SIGNATURE_FIELD = "_filter_signature";
/*      */   private static final String FILTER_SIGNATURE_TYPE = "[B";
/*      */   private static final String HANDLER = "handler";
/*      */   private static final String NULL_INTERCEPTOR_HOLDER = "javassist.util.proxy.RuntimeSupport";
/*      */   private static final String DEFAULT_INTERCEPTOR = "default_interceptor";
/*  198 */   private static final String HANDLER_TYPE = 'L' + MethodHandler.class
/*  199 */     .getName().replace('.', '/') + ';';
/*      */   private static final String HANDLER_SETTER = "setHandler";
/*  201 */   private static final String HANDLER_SETTER_TYPE = "(" + HANDLER_TYPE + ")V";
/*      */   
/*      */   private static final String HANDLER_GETTER = "getHandler";
/*  204 */   private static final String HANDLER_GETTER_TYPE = "()" + HANDLER_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String SERIAL_VERSION_UID_FIELD = "serialVersionUID";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String SERIAL_VERSION_UID_TYPE = "J";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long SERIAL_VERSION_UID_VALUE = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static volatile boolean useCache = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static volatile boolean useWriteReplace = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUseCache() {
/*  254 */     return this.factoryUseCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseCache(boolean useCache) {
/*  266 */     if (this.handler != null && useCache) {
/*  267 */       throw new RuntimeException("caching cannot be enabled if the factory default interceptor has been set");
/*      */     }
/*  269 */     this.factoryUseCache = useCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUseWriteReplace() {
/*  278 */     return this.factoryWriteReplace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseWriteReplace(boolean useWriteReplace) {
/*  288 */     this.factoryWriteReplace = useWriteReplace;
/*      */   }
/*      */   
/*  291 */   private static WeakHashMap proxyCache = new WeakHashMap<Object, Object>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isProxyClass(Class<?> cl) {
/*  301 */     return Proxy.class.isAssignableFrom(cl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ProxyDetails
/*      */   {
/*      */     byte[] signature;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     WeakReference proxyClass;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isUseWriteReplace;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyDetails(byte[] signature, Class<?> proxyClass, boolean isUseWriteReplace) {
/*  329 */       this.signature = signature;
/*  330 */       this.proxyClass = new WeakReference<Class<?>>(proxyClass);
/*  331 */       this.isUseWriteReplace = isUseWriteReplace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProxyFactory() {
/*  339 */     this.superClass = null;
/*  340 */     this.interfaces = null;
/*  341 */     this.methodFilter = null;
/*  342 */     this.handler = null;
/*  343 */     this.signature = null;
/*  344 */     this.signatureMethods = null;
/*  345 */     this.hasGetHandler = false;
/*  346 */     this.thisClass = null;
/*  347 */     this.writeDirectory = null;
/*  348 */     this.factoryUseCache = useCache;
/*  349 */     this.factoryWriteReplace = useWriteReplace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSuperclass(Class clazz) {
/*  356 */     this.superClass = clazz;
/*      */     
/*  358 */     this.signature = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getSuperclass() {
/*  366 */     return this.superClass;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInterfaces(Class[] ifs) {
/*  372 */     this.interfaces = ifs;
/*      */     
/*  374 */     this.signature = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class[] getInterfaces() {
/*  382 */     return this.interfaces;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilter(MethodFilter mf) {
/*  388 */     this.methodFilter = mf;
/*      */     
/*  390 */     this.signature = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class createClass() {
/*  397 */     if (this.signature == null) {
/*  398 */       computeSignature(this.methodFilter);
/*      */     }
/*  400 */     return createClass1();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class createClass(MethodFilter filter) {
/*  407 */     computeSignature(filter);
/*  408 */     return createClass1();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Class createClass(byte[] signature) {
/*  419 */     installSignature(signature);
/*  420 */     return createClass1();
/*      */   }
/*      */   
/*      */   private Class createClass1() {
/*  424 */     if (this.thisClass == null) {
/*  425 */       ClassLoader cl = getClassLoader();
/*  426 */       synchronized (proxyCache) {
/*  427 */         if (this.factoryUseCache) {
/*  428 */           createClass2(cl);
/*      */         } else {
/*  430 */           createClass3(cl);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  435 */     Class result = this.thisClass;
/*  436 */     this.thisClass = null;
/*      */     
/*  438 */     return result;
/*      */   }
/*      */   
/*  441 */   private static char[] hexDigits = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKey(Class superClass, Class[] interfaces, byte[] signature, boolean useWriteReplace) {
/*  447 */     StringBuffer sbuf = new StringBuffer();
/*  448 */     if (superClass != null) {
/*  449 */       sbuf.append(superClass.getName());
/*      */     }
/*  451 */     sbuf.append(":"); int i;
/*  452 */     for (i = 0; i < interfaces.length; i++) {
/*  453 */       sbuf.append(interfaces[i].getName());
/*  454 */       sbuf.append(":");
/*      */     } 
/*  456 */     for (i = 0; i < signature.length; i++) {
/*  457 */       byte b = signature[i];
/*  458 */       int lo = b & 0xF;
/*  459 */       int hi = b >> 4 & 0xF;
/*  460 */       sbuf.append(hexDigits[lo]);
/*  461 */       sbuf.append(hexDigits[hi]);
/*      */     } 
/*  463 */     if (useWriteReplace) {
/*  464 */       sbuf.append(":w");
/*      */     }
/*      */     
/*  467 */     return sbuf.toString();
/*      */   }
/*      */   
/*      */   private void createClass2(ClassLoader cl) {
/*  471 */     String key = getKey(this.superClass, this.interfaces, this.signature, this.factoryWriteReplace);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  478 */     HashMap<Object, Object> cacheForTheLoader = (HashMap)proxyCache.get(cl);
/*      */     
/*  480 */     if (cacheForTheLoader == null) {
/*  481 */       cacheForTheLoader = new HashMap<Object, Object>();
/*  482 */       proxyCache.put(cl, cacheForTheLoader);
/*      */     } 
/*  484 */     ProxyDetails details = (ProxyDetails)cacheForTheLoader.get(key);
/*  485 */     if (details != null) {
/*  486 */       WeakReference<Class<?>> reference = details.proxyClass;
/*  487 */       this.thisClass = reference.get();
/*  488 */       if (this.thisClass != null) {
/*      */         return;
/*      */       }
/*      */     } 
/*  492 */     createClass3(cl);
/*  493 */     details = new ProxyDetails(this.signature, this.thisClass, this.factoryWriteReplace);
/*  494 */     cacheForTheLoader.put(key, details);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void createClass3(ClassLoader cl) {
/*  500 */     allocateClassName();
/*      */     
/*      */     try {
/*  503 */       ClassFile cf = make();
/*  504 */       if (this.writeDirectory != null) {
/*  505 */         FactoryHelper.writeFile(cf, this.writeDirectory);
/*      */       }
/*  507 */       this.thisClass = FactoryHelper.toClass(cf, cl, getDomain());
/*  508 */       setField("_filter_signature", this.signature);
/*      */       
/*  510 */       if (!this.factoryUseCache) {
/*  511 */         setField("default_interceptor", this.handler);
/*      */       }
/*      */     }
/*  514 */     catch (CannotCompileException e) {
/*  515 */       throw new RuntimeException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void setField(String fieldName, Object value) {
/*  521 */     if (this.thisClass != null && value != null)
/*      */       try {
/*  523 */         Field f = this.thisClass.getField(fieldName);
/*  524 */         SecurityActions.setAccessible(f, true);
/*  525 */         f.set(null, value);
/*  526 */         SecurityActions.setAccessible(f, false);
/*      */       }
/*  528 */       catch (Exception e) {
/*  529 */         throw new RuntimeException(e);
/*      */       }  
/*      */   }
/*      */   
/*      */   static byte[] getFilterSignature(Class clazz) {
/*  534 */     return (byte[])getField(clazz, "_filter_signature");
/*      */   }
/*      */   
/*      */   private static Object getField(Class clazz, String fieldName) {
/*      */     try {
/*  539 */       Field f = clazz.getField(fieldName);
/*  540 */       f.setAccessible(true);
/*  541 */       Object value = f.get(null);
/*  542 */       f.setAccessible(false);
/*  543 */       return value;
/*      */     }
/*  545 */     catch (Exception e) {
/*  546 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MethodHandler getHandler(Proxy p) {
/*      */     try {
/*  559 */       Field f = p.getClass().getDeclaredField("handler");
/*  560 */       f.setAccessible(true);
/*  561 */       Object value = f.get(p);
/*  562 */       f.setAccessible(false);
/*  563 */       return (MethodHandler)value;
/*      */     }
/*  565 */     catch (Exception e) {
/*  566 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  605 */   public static ClassLoaderProvider classLoaderProvider = new ClassLoaderProvider()
/*      */     {
/*      */       public ClassLoader get(ProxyFactory pf) {
/*  608 */         return pf.getClassLoader0();
/*      */       }
/*      */     };
/*      */   
/*      */   protected ClassLoader getClassLoader() {
/*  613 */     return classLoaderProvider.get(this);
/*      */   }
/*      */   
/*      */   protected ClassLoader getClassLoader0() {
/*  617 */     ClassLoader loader = null;
/*  618 */     if (this.superClass != null && !this.superClass.getName().equals("java.lang.Object")) {
/*  619 */       loader = this.superClass.getClassLoader();
/*  620 */     } else if (this.interfaces != null && this.interfaces.length > 0) {
/*  621 */       loader = this.interfaces[0].getClassLoader();
/*      */     } 
/*  623 */     if (loader == null) {
/*  624 */       loader = getClass().getClassLoader();
/*      */       
/*  626 */       if (loader == null) {
/*  627 */         loader = Thread.currentThread().getContextClassLoader();
/*  628 */         if (loader == null) {
/*  629 */           loader = ClassLoader.getSystemClassLoader();
/*      */         }
/*      */       } 
/*      */     } 
/*  633 */     return loader;
/*      */   }
/*      */   
/*      */   protected ProtectionDomain getDomain() {
/*      */     Class<?> clazz;
/*  638 */     if (this.superClass != null && !this.superClass.getName().equals("java.lang.Object")) {
/*  639 */       clazz = this.superClass;
/*  640 */     } else if (this.interfaces != null && this.interfaces.length > 0) {
/*  641 */       clazz = this.interfaces[0];
/*      */     } else {
/*  643 */       clazz = getClass();
/*      */     } 
/*  645 */     return clazz.getProtectionDomain();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object create(Class[] paramTypes, Object[] args, MethodHandler mh) throws NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
/*  660 */     Object obj = create(paramTypes, args);
/*  661 */     ((Proxy)obj).setHandler(mh);
/*  662 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object create(Class[] paramTypes, Object[] args) throws NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
/*  675 */     Class c = createClass();
/*  676 */     Constructor cons = c.getConstructor(paramTypes);
/*  677 */     return cons.newInstance(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHandler(MethodHandler mi) {
/*  692 */     if (this.factoryUseCache && mi != null) {
/*  693 */       this.factoryUseCache = false;
/*      */       
/*  695 */       this.thisClass = null;
/*      */     } 
/*  697 */     this.handler = mi;
/*      */ 
/*      */     
/*  700 */     setField("default_interceptor", this.handler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  722 */   public static UniqueName nameGenerator = new UniqueName() {
/*  723 */       private final String sep = "_$$_jvst" + Integer.toHexString(hashCode() & 0xFFF) + "_";
/*  724 */       private int counter = 0;
/*      */       
/*      */       public String get(String classname) {
/*  727 */         return classname + this.sep + Integer.toHexString(this.counter++);
/*      */       }
/*      */     };
/*      */   
/*      */   private static String makeProxyName(String classname) {
/*  732 */     synchronized (nameGenerator) {
/*  733 */       return nameGenerator.get(classname);
/*      */     } 
/*      */   }
/*      */   
/*      */   private ClassFile make() throws CannotCompileException {
/*  738 */     ClassFile cf = new ClassFile(false, this.classname, this.superName);
/*  739 */     cf.setAccessFlags(1);
/*  740 */     setInterfaces(cf, this.interfaces, this.hasGetHandler ? Proxy.class : ProxyObject.class);
/*  741 */     ConstPool pool = cf.getConstPool();
/*      */ 
/*      */     
/*  744 */     if (!this.factoryUseCache) {
/*  745 */       FieldInfo finfo = new FieldInfo(pool, "default_interceptor", HANDLER_TYPE);
/*  746 */       finfo.setAccessFlags(9);
/*  747 */       cf.addField(finfo);
/*      */     } 
/*      */ 
/*      */     
/*  751 */     FieldInfo finfo2 = new FieldInfo(pool, "handler", HANDLER_TYPE);
/*  752 */     finfo2.setAccessFlags(2);
/*  753 */     cf.addField(finfo2);
/*      */ 
/*      */     
/*  756 */     FieldInfo finfo3 = new FieldInfo(pool, "_filter_signature", "[B");
/*  757 */     finfo3.setAccessFlags(9);
/*  758 */     cf.addField(finfo3);
/*      */ 
/*      */     
/*  761 */     FieldInfo finfo4 = new FieldInfo(pool, "serialVersionUID", "J");
/*  762 */     finfo4.setAccessFlags(25);
/*  763 */     cf.addField(finfo4);
/*      */ 
/*      */ 
/*      */     
/*  767 */     makeConstructors(this.classname, cf, pool, this.classname);
/*      */     
/*  769 */     ArrayList forwarders = new ArrayList();
/*  770 */     int s = overrideMethods(cf, pool, this.classname, forwarders);
/*  771 */     addClassInitializer(cf, pool, this.classname, s, forwarders);
/*  772 */     addSetter(this.classname, cf, pool);
/*  773 */     if (!this.hasGetHandler) {
/*  774 */       addGetter(this.classname, cf, pool);
/*      */     }
/*  776 */     if (this.factoryWriteReplace) {
/*      */       try {
/*  778 */         cf.addMethod(makeWriteReplace(pool));
/*      */       }
/*  780 */       catch (DuplicateMemberException duplicateMemberException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  785 */     this.thisClass = null;
/*  786 */     return cf;
/*      */   }
/*      */   
/*      */   private void checkClassAndSuperName() {
/*  790 */     if (this.interfaces == null) {
/*  791 */       this.interfaces = new Class[0];
/*      */     }
/*  793 */     if (this.superClass == null) {
/*  794 */       this.superClass = OBJECT_TYPE;
/*  795 */       this.superName = this.superClass.getName();
/*  796 */       this
/*  797 */         .basename = (this.interfaces.length == 0) ? this.superName : this.interfaces[0].getName();
/*      */     } else {
/*  799 */       this.superName = this.superClass.getName();
/*  800 */       this.basename = this.superName;
/*      */     } 
/*      */     
/*  803 */     if (Modifier.isFinal(this.superClass.getModifiers())) {
/*  804 */       throw new RuntimeException(this.superName + " is final");
/*      */     }
/*  806 */     if (this.basename.startsWith("java."))
/*  807 */       this.basename = "org.javassist.tmp." + this.basename; 
/*      */   }
/*      */   
/*      */   private void allocateClassName() {
/*  811 */     this.classname = makeProxyName(this.basename);
/*      */   }
/*      */   
/*  814 */   private static Comparator sorter = new Comparator()
/*      */     {
/*      */       public int compare(Object o1, Object o2) {
/*  817 */         Map.Entry e1 = (Map.Entry)o1;
/*  818 */         Map.Entry e2 = (Map.Entry)o2;
/*  819 */         String key1 = (String)e1.getKey();
/*  820 */         String key2 = (String)e2.getKey();
/*  821 */         return key1.compareTo(key2);
/*      */       }
/*      */     };
/*      */   
/*      */   private void makeSortedMethodList() {
/*  826 */     checkClassAndSuperName();
/*      */     
/*  828 */     this.hasGetHandler = false;
/*  829 */     HashMap allMethods = getMethods(this.superClass, this.interfaces);
/*  830 */     this.signatureMethods = new ArrayList(allMethods.entrySet());
/*  831 */     Collections.sort(this.signatureMethods, sorter);
/*      */   }
/*      */   private static final String HANDLER_GETTER_KEY = "getHandler:()";
/*      */   
/*      */   private void computeSignature(MethodFilter filter) {
/*  836 */     makeSortedMethodList();
/*      */     
/*  838 */     int l = this.signatureMethods.size();
/*  839 */     int maxBytes = l + 7 >> 3;
/*  840 */     this.signature = new byte[maxBytes];
/*  841 */     for (int idx = 0; idx < l; idx++) {
/*      */       
/*  843 */       Map.Entry e = this.signatureMethods.get(idx);
/*  844 */       Method m = (Method)e.getValue();
/*  845 */       int mod = m.getModifiers();
/*  846 */       if (!Modifier.isFinal(mod) && !Modifier.isStatic(mod) && 
/*  847 */         isVisible(mod, this.basename, m) && (filter == null || filter.isHandled(m))) {
/*  848 */         setBit(this.signature, idx);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void installSignature(byte[] signature) {
/*  855 */     makeSortedMethodList();
/*      */     
/*  857 */     int l = this.signatureMethods.size();
/*  858 */     int maxBytes = l + 7 >> 3;
/*  859 */     if (signature.length != maxBytes) {
/*  860 */       throw new RuntimeException("invalid filter signature length for deserialized proxy class");
/*      */     }
/*      */     
/*  863 */     this.signature = signature;
/*      */   }
/*      */   
/*      */   private boolean testBit(byte[] signature, int idx) {
/*  867 */     int byteIdx = idx >> 3;
/*  868 */     if (byteIdx > signature.length) {
/*  869 */       return false;
/*      */     }
/*  871 */     int bitIdx = idx & 0x7;
/*  872 */     int mask = 1 << bitIdx;
/*  873 */     int sigByte = signature[byteIdx];
/*  874 */     return ((sigByte & mask) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setBit(byte[] signature, int idx) {
/*  879 */     int byteIdx = idx >> 3;
/*  880 */     if (byteIdx < signature.length) {
/*  881 */       int bitIdx = idx & 0x7;
/*  882 */       int mask = 1 << bitIdx;
/*  883 */       int sigByte = signature[byteIdx];
/*  884 */       signature[byteIdx] = (byte)(sigByte | mask);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void setInterfaces(ClassFile cf, Class[] interfaces, Class proxyClass) {
/*  889 */     String list[], setterIntf = proxyClass.getName();
/*      */     
/*  891 */     if (interfaces == null || interfaces.length == 0) {
/*  892 */       list = new String[] { setterIntf };
/*      */     } else {
/*  894 */       list = new String[interfaces.length + 1];
/*  895 */       for (int i = 0; i < interfaces.length; i++) {
/*  896 */         list[i] = interfaces[i].getName();
/*      */       }
/*  898 */       list[interfaces.length] = setterIntf;
/*      */     } 
/*      */     
/*  901 */     cf.setInterfaces(list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addClassInitializer(ClassFile cf, ConstPool cp, String classname, int size, ArrayList forwarders) throws CannotCompileException {
/*  908 */     FieldInfo finfo = new FieldInfo(cp, "_methods_", "[Ljava/lang/reflect/Method;");
/*  909 */     finfo.setAccessFlags(10);
/*  910 */     cf.addField(finfo);
/*  911 */     MethodInfo minfo = new MethodInfo(cp, "<clinit>", "()V");
/*  912 */     minfo.setAccessFlags(8);
/*  913 */     setThrows(minfo, cp, new Class[] { ClassNotFoundException.class });
/*      */     
/*  915 */     Bytecode code = new Bytecode(cp, 0, 2);
/*  916 */     code.addIconst(size * 2);
/*  917 */     code.addAnewarray("java.lang.reflect.Method");
/*  918 */     int varArray = 0;
/*  919 */     code.addAstore(0);
/*      */ 
/*      */ 
/*      */     
/*  923 */     code.addLdc(classname);
/*  924 */     code.addInvokestatic("java.lang.Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;");
/*      */     
/*  926 */     int varClass = 1;
/*  927 */     code.addAstore(1);
/*      */     
/*  929 */     Iterator<Find2MethodsArgs> it = forwarders.iterator();
/*  930 */     while (it.hasNext()) {
/*  931 */       Find2MethodsArgs args = it.next();
/*  932 */       callFind2Methods(code, args.methodName, args.delegatorName, args.origIndex, args.descriptor, 1, 0);
/*      */     } 
/*      */ 
/*      */     
/*  936 */     code.addAload(0);
/*  937 */     code.addPutstatic(classname, "_methods_", "[Ljava/lang/reflect/Method;");
/*      */     
/*  939 */     code.addLconst(-1L);
/*  940 */     code.addPutstatic(classname, "serialVersionUID", "J");
/*  941 */     code.addOpcode(177);
/*  942 */     minfo.setCodeAttribute(code.toCodeAttribute());
/*  943 */     cf.addMethod(minfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void callFind2Methods(Bytecode code, String superMethod, String thisMethod, int index, String desc, int classVar, int arrayVar) {
/*  951 */     String findClass = RuntimeSupport.class.getName();
/*  952 */     String findDesc = "(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;[Ljava/lang/reflect/Method;)V";
/*      */ 
/*      */     
/*  955 */     code.addAload(classVar);
/*  956 */     code.addLdc(superMethod);
/*  957 */     if (thisMethod == null) {
/*  958 */       code.addOpcode(1);
/*      */     } else {
/*  960 */       code.addLdc(thisMethod);
/*      */     } 
/*  962 */     code.addIconst(index);
/*  963 */     code.addLdc(desc);
/*  964 */     code.addAload(arrayVar);
/*  965 */     code.addInvokestatic(findClass, "find2Methods", findDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addSetter(String classname, ClassFile cf, ConstPool cp) throws CannotCompileException {
/*  971 */     MethodInfo minfo = new MethodInfo(cp, "setHandler", HANDLER_SETTER_TYPE);
/*      */     
/*  973 */     minfo.setAccessFlags(1);
/*  974 */     Bytecode code = new Bytecode(cp, 2, 2);
/*  975 */     code.addAload(0);
/*  976 */     code.addAload(1);
/*  977 */     code.addPutfield(classname, "handler", HANDLER_TYPE);
/*  978 */     code.addOpcode(177);
/*  979 */     minfo.setCodeAttribute(code.toCodeAttribute());
/*  980 */     cf.addMethod(minfo);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addGetter(String classname, ClassFile cf, ConstPool cp) throws CannotCompileException {
/*  986 */     MethodInfo minfo = new MethodInfo(cp, "getHandler", HANDLER_GETTER_TYPE);
/*      */     
/*  988 */     minfo.setAccessFlags(1);
/*  989 */     Bytecode code = new Bytecode(cp, 1, 1);
/*  990 */     code.addAload(0);
/*  991 */     code.addGetfield(classname, "handler", HANDLER_TYPE);
/*  992 */     code.addOpcode(176);
/*  993 */     minfo.setCodeAttribute(code.toCodeAttribute());
/*  994 */     cf.addMethod(minfo);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int overrideMethods(ClassFile cf, ConstPool cp, String className, ArrayList forwarders) throws CannotCompileException {
/* 1000 */     String prefix = makeUniqueName("_d", this.signatureMethods);
/* 1001 */     Iterator<Map.Entry> it = this.signatureMethods.iterator();
/* 1002 */     int index = 0;
/* 1003 */     while (it.hasNext()) {
/* 1004 */       Map.Entry e = it.next();
/* 1005 */       String key = (String)e.getKey();
/* 1006 */       Method meth = (Method)e.getValue();
/* 1007 */       if ((ClassFile.MAJOR_VERSION < 49 || !isBridge(meth)) && 
/* 1008 */         testBit(this.signature, index)) {
/* 1009 */         override(className, meth, prefix, index, 
/* 1010 */             keyToDesc(key, meth), cf, cp, forwarders);
/*      */       }
/*      */       
/* 1013 */       index++;
/*      */     } 
/*      */     
/* 1016 */     return index;
/*      */   }
/*      */   
/*      */   private static boolean isBridge(Method m) {
/* 1020 */     return m.isBridge();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void override(String thisClassname, Method meth, String prefix, int index, String desc, ClassFile cf, ConstPool cp, ArrayList forwarders) throws CannotCompileException {
/* 1027 */     Class<?> declClass = meth.getDeclaringClass();
/* 1028 */     String delegatorName = prefix + index + meth.getName();
/* 1029 */     if (Modifier.isAbstract(meth.getModifiers())) {
/* 1030 */       delegatorName = null;
/*      */     } else {
/*      */       
/* 1033 */       MethodInfo delegator = makeDelegator(meth, desc, cp, declClass, delegatorName);
/*      */       
/* 1035 */       delegator.setAccessFlags(delegator.getAccessFlags() & 0xFFFFFFBF);
/* 1036 */       cf.addMethod(delegator);
/*      */     } 
/*      */ 
/*      */     
/* 1040 */     MethodInfo forwarder = makeForwarder(thisClassname, meth, desc, cp, declClass, delegatorName, index, forwarders);
/*      */     
/* 1042 */     cf.addMethod(forwarder);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void makeConstructors(String thisClassName, ClassFile cf, ConstPool cp, String classname) throws CannotCompileException {
/* 1048 */     Constructor[] cons = SecurityActions.getDeclaredConstructors(this.superClass);
/*      */     
/* 1050 */     boolean doHandlerInit = !this.factoryUseCache;
/* 1051 */     for (int i = 0; i < cons.length; i++) {
/* 1052 */       Constructor c = cons[i];
/* 1053 */       int mod = c.getModifiers();
/* 1054 */       if (!Modifier.isFinal(mod) && !Modifier.isPrivate(mod) && 
/* 1055 */         isVisible(mod, this.basename, c)) {
/* 1056 */         MethodInfo m = makeConstructor(thisClassName, c, cp, this.superClass, doHandlerInit);
/* 1057 */         cf.addMethod(m);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String makeUniqueName(String name, List sortedMethods) {
/* 1063 */     if (makeUniqueName0(name, sortedMethods.iterator())) {
/* 1064 */       return name;
/*      */     }
/* 1066 */     for (int i = 100; i < 999; i++) {
/* 1067 */       String s = name + i;
/* 1068 */       if (makeUniqueName0(s, sortedMethods.iterator())) {
/* 1069 */         return s;
/*      */       }
/*      */     } 
/* 1072 */     throw new RuntimeException("cannot make a unique method name");
/*      */   }
/*      */   
/*      */   private static boolean makeUniqueName0(String name, Iterator<Map.Entry> it) {
/* 1076 */     while (it.hasNext()) {
/* 1077 */       Map.Entry e = it.next();
/* 1078 */       String key = (String)e.getKey();
/* 1079 */       if (key.startsWith(name)) {
/* 1080 */         return false;
/*      */       }
/*      */     } 
/* 1083 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isVisible(int mod, String from, Member meth) {
/* 1092 */     if ((mod & 0x2) != 0)
/* 1093 */       return false; 
/* 1094 */     if ((mod & 0x5) != 0) {
/* 1095 */       return true;
/*      */     }
/* 1097 */     String p = getPackageName(from);
/* 1098 */     String q = getPackageName(meth.getDeclaringClass().getName());
/* 1099 */     if (p == null) {
/* 1100 */       return (q == null);
/*      */     }
/* 1102 */     return p.equals(q);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getPackageName(String name) {
/* 1107 */     int i = name.lastIndexOf('.');
/* 1108 */     if (i < 0) {
/* 1109 */       return null;
/*      */     }
/* 1111 */     return name.substring(0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap getMethods(Class superClass, Class[] interfaceTypes) {
/* 1117 */     HashMap<Object, Object> hash = new HashMap<Object, Object>();
/* 1118 */     HashSet set = new HashSet();
/* 1119 */     for (int i = 0; i < interfaceTypes.length; i++) {
/* 1120 */       getMethods(hash, interfaceTypes[i], set);
/*      */     }
/* 1122 */     getMethods(hash, superClass, set);
/* 1123 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void getMethods(HashMap<String, Method> hash, Class<?> clazz, Set<Class<?>> visitedClasses) {
/* 1129 */     if (!visitedClasses.add(clazz)) {
/*      */       return;
/*      */     }
/* 1132 */     Class[] ifs = clazz.getInterfaces();
/* 1133 */     for (int i = 0; i < ifs.length; i++) {
/* 1134 */       getMethods(hash, ifs[i], visitedClasses);
/*      */     }
/* 1136 */     Class<?> parent = clazz.getSuperclass();
/* 1137 */     if (parent != null) {
/* 1138 */       getMethods(hash, parent, visitedClasses);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1145 */     Method[] methods = SecurityActions.getDeclaredMethods(clazz);
/* 1146 */     for (int j = 0; j < methods.length; j++) {
/* 1147 */       if (!Modifier.isPrivate(methods[j].getModifiers())) {
/* 1148 */         Method m = methods[j];
/* 1149 */         String key = m.getName() + ':' + RuntimeSupport.makeDescriptor(m);
/* 1150 */         if (key.startsWith("getHandler:()")) {
/* 1151 */           this.hasGetHandler = true;
/*      */         }
/*      */ 
/*      */         
/* 1155 */         Method oldMethod = hash.put(key, methods[j]);
/*      */ 
/*      */         
/* 1158 */         if (null != oldMethod && Modifier.isPublic(oldMethod.getModifiers()) && 
/* 1159 */           !Modifier.isPublic(methods[j].getModifiers()))
/*      */         {
/*      */           
/* 1162 */           hash.put(key, oldMethod);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String keyToDesc(String key, Method m) {
/* 1171 */     return key.substring(key.indexOf(':') + 1);
/*      */   }
/*      */ 
/*      */   
/*      */   private static MethodInfo makeConstructor(String thisClassName, Constructor cons, ConstPool cp, Class superClass, boolean doHandlerInit) {
/* 1176 */     String desc = RuntimeSupport.makeDescriptor(cons.getParameterTypes(), void.class);
/*      */     
/* 1178 */     MethodInfo minfo = new MethodInfo(cp, "<init>", desc);
/* 1179 */     minfo.setAccessFlags(1);
/* 1180 */     setThrows(minfo, cp, cons.getExceptionTypes());
/* 1181 */     Bytecode code = new Bytecode(cp, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1186 */     if (doHandlerInit) {
/* 1187 */       code.addAload(0);
/* 1188 */       code.addGetstatic(thisClassName, "default_interceptor", HANDLER_TYPE);
/* 1189 */       code.addPutfield(thisClassName, "handler", HANDLER_TYPE);
/* 1190 */       code.addGetstatic(thisClassName, "default_interceptor", HANDLER_TYPE);
/* 1191 */       code.addOpcode(199);
/* 1192 */       code.addIndex(10);
/*      */     } 
/*      */ 
/*      */     
/* 1196 */     code.addAload(0);
/* 1197 */     code.addGetstatic("javassist.util.proxy.RuntimeSupport", "default_interceptor", HANDLER_TYPE);
/* 1198 */     code.addPutfield(thisClassName, "handler", HANDLER_TYPE);
/* 1199 */     int pc = code.currentPc();
/*      */     
/* 1201 */     code.addAload(0);
/* 1202 */     int s = addLoadParameters(code, cons.getParameterTypes(), 1);
/* 1203 */     code.addInvokespecial(superClass.getName(), "<init>", desc);
/* 1204 */     code.addOpcode(177);
/* 1205 */     code.setMaxLocals(s + 1);
/* 1206 */     CodeAttribute ca = code.toCodeAttribute();
/* 1207 */     minfo.setCodeAttribute(ca);
/*      */     
/* 1209 */     StackMapTable.Writer writer = new StackMapTable.Writer(32);
/* 1210 */     writer.sameFrame(pc);
/* 1211 */     ca.setAttribute(writer.toStackMapTable(cp));
/* 1212 */     return minfo;
/*      */   }
/*      */ 
/*      */   
/*      */   private static MethodInfo makeDelegator(Method meth, String desc, ConstPool cp, Class declClass, String delegatorName) {
/* 1217 */     MethodInfo delegator = new MethodInfo(cp, delegatorName, desc);
/* 1218 */     delegator.setAccessFlags(0x11 | meth
/* 1219 */         .getModifiers() & 0xFFFFFAD9);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1224 */     setThrows(delegator, cp, meth);
/* 1225 */     Bytecode code = new Bytecode(cp, 0, 0);
/* 1226 */     code.addAload(0);
/* 1227 */     int s = addLoadParameters(code, meth.getParameterTypes(), 1);
/* 1228 */     code.addInvokespecial(declClass.getName(), meth.getName(), desc);
/* 1229 */     addReturn(code, meth.getReturnType());
/* 1230 */     code.setMaxLocals(++s);
/* 1231 */     delegator.setCodeAttribute(code.toCodeAttribute());
/* 1232 */     return delegator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MethodInfo makeForwarder(String thisClassName, Method meth, String desc, ConstPool cp, Class declClass, String delegatorName, int index, ArrayList<Find2MethodsArgs> forwarders) {
/* 1242 */     MethodInfo forwarder = new MethodInfo(cp, meth.getName(), desc);
/* 1243 */     forwarder.setAccessFlags(0x10 | meth
/* 1244 */         .getModifiers() & 0xFFFFFADF);
/*      */ 
/*      */     
/* 1247 */     setThrows(forwarder, cp, meth);
/* 1248 */     int args = Descriptor.paramSize(desc);
/* 1249 */     Bytecode code = new Bytecode(cp, 0, args + 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1262 */     int origIndex = index * 2;
/* 1263 */     int delIndex = index * 2 + 1;
/* 1264 */     int arrayVar = args + 1;
/* 1265 */     code.addGetstatic(thisClassName, "_methods_", "[Ljava/lang/reflect/Method;");
/* 1266 */     code.addAstore(arrayVar);
/*      */     
/* 1268 */     forwarders.add(new Find2MethodsArgs(meth.getName(), delegatorName, desc, origIndex));
/*      */     
/* 1270 */     code.addAload(0);
/* 1271 */     code.addGetfield(thisClassName, "handler", HANDLER_TYPE);
/* 1272 */     code.addAload(0);
/*      */     
/* 1274 */     code.addAload(arrayVar);
/* 1275 */     code.addIconst(origIndex);
/* 1276 */     code.addOpcode(50);
/*      */     
/* 1278 */     code.addAload(arrayVar);
/* 1279 */     code.addIconst(delIndex);
/* 1280 */     code.addOpcode(50);
/*      */     
/* 1282 */     makeParameterList(code, meth.getParameterTypes());
/* 1283 */     code.addInvokeinterface(MethodHandler.class.getName(), "invoke", "(Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;", 5);
/*      */ 
/*      */     
/* 1286 */     Class<?> retType = meth.getReturnType();
/* 1287 */     addUnwrapper(code, retType);
/* 1288 */     addReturn(code, retType);
/*      */     
/* 1290 */     CodeAttribute ca = code.toCodeAttribute();
/* 1291 */     forwarder.setCodeAttribute(ca);
/* 1292 */     return forwarder;
/*      */   }
/*      */   
/*      */   static class Find2MethodsArgs {
/*      */     String methodName;
/*      */     String delegatorName;
/*      */     
/*      */     Find2MethodsArgs(String mname, String dname, String desc, int index) {
/* 1300 */       this.methodName = mname;
/* 1301 */       this.delegatorName = dname;
/* 1302 */       this.descriptor = desc;
/* 1303 */       this.origIndex = index;
/*      */     }
/*      */     String descriptor; int origIndex; }
/*      */   
/*      */   private static void setThrows(MethodInfo minfo, ConstPool cp, Method orig) {
/* 1308 */     Class[] exceptions = orig.getExceptionTypes();
/* 1309 */     setThrows(minfo, cp, exceptions);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void setThrows(MethodInfo minfo, ConstPool cp, Class[] exceptions) {
/* 1314 */     if (exceptions.length == 0) {
/*      */       return;
/*      */     }
/* 1317 */     String[] list = new String[exceptions.length];
/* 1318 */     for (int i = 0; i < exceptions.length; i++) {
/* 1319 */       list[i] = exceptions[i].getName();
/*      */     }
/* 1321 */     ExceptionsAttribute ea = new ExceptionsAttribute(cp);
/* 1322 */     ea.setExceptions(list);
/* 1323 */     minfo.setExceptionsAttribute(ea);
/*      */   }
/*      */ 
/*      */   
/*      */   private static int addLoadParameters(Bytecode code, Class[] params, int offset) {
/* 1328 */     int stacksize = 0;
/* 1329 */     int n = params.length;
/* 1330 */     for (int i = 0; i < n; i++) {
/* 1331 */       stacksize += addLoad(code, stacksize + offset, params[i]);
/*      */     }
/* 1333 */     return stacksize;
/*      */   }
/*      */   
/*      */   private static int addLoad(Bytecode code, int n, Class<long> type) {
/* 1337 */     if (type.isPrimitive()) {
/* 1338 */       if (type == long.class) {
/* 1339 */         code.addLload(n);
/* 1340 */         return 2;
/*      */       } 
/* 1342 */       if (type == float.class)
/* 1343 */       { code.addFload(n); }
/* 1344 */       else { if (type == double.class) {
/* 1345 */           code.addDload(n);
/* 1346 */           return 2;
/*      */         } 
/*      */         
/* 1349 */         code.addIload(n); }
/*      */     
/*      */     } else {
/* 1352 */       code.addAload(n);
/*      */     } 
/* 1354 */     return 1;
/*      */   }
/*      */   
/*      */   private static int addReturn(Bytecode code, Class<long> type) {
/* 1358 */     if (type.isPrimitive()) {
/* 1359 */       if (type == long.class) {
/* 1360 */         code.addOpcode(173);
/* 1361 */         return 2;
/*      */       } 
/* 1363 */       if (type == float.class)
/* 1364 */       { code.addOpcode(174); }
/* 1365 */       else { if (type == double.class) {
/* 1366 */           code.addOpcode(175);
/* 1367 */           return 2;
/*      */         } 
/* 1369 */         if (type == void.class) {
/* 1370 */           code.addOpcode(177);
/* 1371 */           return 0;
/*      */         } 
/*      */         
/* 1374 */         code.addOpcode(172); }
/*      */     
/*      */     } else {
/* 1377 */       code.addOpcode(176);
/*      */     } 
/* 1379 */     return 1;
/*      */   }
/*      */   
/*      */   private static void makeParameterList(Bytecode code, Class[] params) {
/* 1383 */     int regno = 1;
/* 1384 */     int n = params.length;
/* 1385 */     code.addIconst(n);
/* 1386 */     code.addAnewarray("java/lang/Object");
/* 1387 */     for (int i = 0; i < n; i++) {
/* 1388 */       code.addOpcode(89);
/* 1389 */       code.addIconst(i);
/* 1390 */       Class type = params[i];
/* 1391 */       if (type.isPrimitive()) {
/* 1392 */         regno = makeWrapper(code, type, regno);
/*      */       } else {
/* 1394 */         code.addAload(regno);
/* 1395 */         regno++;
/*      */       } 
/*      */       
/* 1398 */       code.addOpcode(83);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int makeWrapper(Bytecode code, Class type, int regno) {
/* 1403 */     int index = FactoryHelper.typeIndex(type);
/* 1404 */     String wrapper = FactoryHelper.wrapperTypes[index];
/* 1405 */     code.addNew(wrapper);
/* 1406 */     code.addOpcode(89);
/* 1407 */     addLoad(code, regno, type);
/* 1408 */     code.addInvokespecial(wrapper, "<init>", FactoryHelper.wrapperDesc[index]);
/*      */     
/* 1410 */     return regno + FactoryHelper.dataSize[index];
/*      */   }
/*      */   
/*      */   private static void addUnwrapper(Bytecode code, Class<void> type) {
/* 1414 */     if (type.isPrimitive()) {
/* 1415 */       if (type == void.class) {
/* 1416 */         code.addOpcode(87);
/*      */       } else {
/* 1418 */         int index = FactoryHelper.typeIndex(type);
/* 1419 */         String wrapper = FactoryHelper.wrapperTypes[index];
/* 1420 */         code.addCheckcast(wrapper);
/* 1421 */         code.addInvokevirtual(wrapper, FactoryHelper.unwarpMethods[index], FactoryHelper.unwrapDesc[index]);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1427 */       code.addCheckcast(type.getName());
/*      */     } 
/*      */   }
/*      */   private static MethodInfo makeWriteReplace(ConstPool cp) {
/* 1431 */     MethodInfo minfo = new MethodInfo(cp, "writeReplace", "()Ljava/lang/Object;");
/* 1432 */     String[] list = new String[1];
/* 1433 */     list[0] = "java.io.ObjectStreamException";
/* 1434 */     ExceptionsAttribute ea = new ExceptionsAttribute(cp);
/* 1435 */     ea.setExceptions(list);
/* 1436 */     minfo.setExceptionsAttribute(ea);
/* 1437 */     Bytecode code = new Bytecode(cp, 0, 1);
/* 1438 */     code.addAload(0);
/* 1439 */     code.addInvokestatic("javassist.util.proxy.RuntimeSupport", "makeSerializedProxy", "(Ljava/lang/Object;)Ljavassist/util/proxy/SerializedProxy;");
/*      */ 
/*      */     
/* 1442 */     code.addOpcode(176);
/* 1443 */     minfo.setCodeAttribute(code.toCodeAttribute());
/* 1444 */     return minfo;
/*      */   }
/*      */   
/*      */   public static interface UniqueName {
/*      */     String get(String param1String);
/*      */   }
/*      */   
/*      */   public static interface ClassLoaderProvider {
/*      */     ClassLoader get(ProxyFactory param1ProxyFactory);
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassis\\util\proxy\ProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */