package javassist.util.proxy;

public interface Proxy {
  void setHandler(MethodHandler paramMethodHandler);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassis\\util\proxy\Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */