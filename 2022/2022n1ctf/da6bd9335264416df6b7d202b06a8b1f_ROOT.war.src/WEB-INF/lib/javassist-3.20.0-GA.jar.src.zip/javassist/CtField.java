/*      */ package javassist;
/*      */ 
/*      */ import java.util.ListIterator;
/*      */ import javassist.bytecode.AccessFlag;
/*      */ import javassist.bytecode.AnnotationsAttribute;
/*      */ import javassist.bytecode.AttributeInfo;
/*      */ import javassist.bytecode.Bytecode;
/*      */ import javassist.bytecode.ClassFile;
/*      */ import javassist.bytecode.ConstPool;
/*      */ import javassist.bytecode.Descriptor;
/*      */ import javassist.bytecode.FieldInfo;
/*      */ import javassist.bytecode.SignatureAttribute;
/*      */ import javassist.compiler.CompileError;
/*      */ import javassist.compiler.Javac;
/*      */ import javassist.compiler.SymbolTable;
/*      */ import javassist.compiler.ast.ASTree;
/*      */ import javassist.compiler.ast.DoubleConst;
/*      */ import javassist.compiler.ast.IntConst;
/*      */ import javassist.compiler.ast.StringL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CtField
/*      */   extends CtMember
/*      */ {
/*      */   static final String javaLangString = "java.lang.String";
/*      */   protected FieldInfo fieldInfo;
/*      */   
/*      */   public CtField(CtClass type, String name, CtClass declaring) throws CannotCompileException {
/*   61 */     this(Descriptor.of(type), name, declaring);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CtField(CtField src, CtClass declaring) throws CannotCompileException {
/*   84 */     this(src.fieldInfo.getDescriptor(), src.fieldInfo.getName(), declaring);
/*      */ 
/*      */     
/*   87 */     ListIterator<AttributeInfo> iterator = src.fieldInfo.getAttributes().listIterator();
/*   88 */     FieldInfo fi = this.fieldInfo;
/*   89 */     fi.setAccessFlags(src.fieldInfo.getAccessFlags());
/*   90 */     ConstPool cp = fi.getConstPool();
/*   91 */     while (iterator.hasNext()) {
/*   92 */       AttributeInfo ainfo = iterator.next();
/*   93 */       fi.addAttribute(ainfo.copy(cp, null));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CtField(String typeDesc, String name, CtClass clazz) throws CannotCompileException {
/*  100 */     super(clazz);
/*  101 */     ClassFile cf = clazz.getClassFile2();
/*  102 */     if (cf == null) {
/*  103 */       throw new CannotCompileException("bad declaring class: " + clazz
/*  104 */           .getName());
/*      */     }
/*  106 */     this.fieldInfo = new FieldInfo(cf.getConstPool(), name, typeDesc);
/*      */   }
/*      */   
/*      */   CtField(FieldInfo fi, CtClass clazz) {
/*  110 */     super(clazz);
/*  111 */     this.fieldInfo = fi;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  118 */     return getDeclaringClass().getName() + "." + getName() + ":" + this.fieldInfo
/*  119 */       .getDescriptor();
/*      */   }
/*      */   
/*      */   protected void extendToString(StringBuffer buffer) {
/*  123 */     buffer.append(' ');
/*  124 */     buffer.append(getName());
/*  125 */     buffer.append(' ');
/*  126 */     buffer.append(this.fieldInfo.getDescriptor());
/*      */   }
/*      */ 
/*      */   
/*      */   protected ASTree getInitAST() {
/*  131 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   Initializer getInit() {
/*  136 */     ASTree tree = getInitAST();
/*  137 */     if (tree == null) {
/*  138 */       return null;
/*      */     }
/*  140 */     return Initializer.byExpr(tree);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CtField make(String src, CtClass declaring) throws CannotCompileException {
/*  160 */     Javac compiler = new Javac(declaring);
/*      */     try {
/*  162 */       CtMember obj = compiler.compile(src);
/*  163 */       if (obj instanceof CtField) {
/*  164 */         return (CtField)obj;
/*      */       }
/*  166 */     } catch (CompileError e) {
/*  167 */       throw new CannotCompileException(e);
/*      */     } 
/*      */     
/*  170 */     throw new CannotCompileException("not a field");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldInfo getFieldInfo() {
/*  177 */     this.declaringClass.checkModify();
/*  178 */     return this.fieldInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldInfo getFieldInfo2() {
/*  200 */     return this.fieldInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CtClass getDeclaringClass() {
/*  207 */     return super.getDeclaringClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  214 */     return this.fieldInfo.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String newName) {
/*  221 */     this.declaringClass.checkModify();
/*  222 */     this.fieldInfo.setName(newName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getModifiers() {
/*  231 */     return AccessFlag.toModifier(this.fieldInfo.getAccessFlags());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setModifiers(int mod) {
/*  240 */     this.declaringClass.checkModify();
/*  241 */     this.fieldInfo.setAccessFlags(AccessFlag.of(mod));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAnnotation(Class clz) {
/*  252 */     FieldInfo fi = getFieldInfo2();
/*      */     
/*  254 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)fi.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  256 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)fi.getAttribute("RuntimeVisibleAnnotations");
/*  257 */     return CtClassType.hasAnnotationType(clz, getDeclaringClass().getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnnotation(Class clz) throws ClassNotFoundException {
/*  273 */     FieldInfo fi = getFieldInfo2();
/*      */     
/*  275 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)fi.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  277 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)fi.getAttribute("RuntimeVisibleAnnotations");
/*  278 */     return CtClassType.getAnnotationType(clz, getDeclaringClass().getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getAnnotations() throws ClassNotFoundException {
/*  290 */     return getAnnotations(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getAvailableAnnotations() {
/*      */     try {
/*  304 */       return getAnnotations(true);
/*      */     }
/*  306 */     catch (ClassNotFoundException e) {
/*  307 */       throw new RuntimeException("Unexpected exception", e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Object[] getAnnotations(boolean ignoreNotFound) throws ClassNotFoundException {
/*  312 */     FieldInfo fi = getFieldInfo2();
/*      */     
/*  314 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)fi.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  316 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)fi.getAttribute("RuntimeVisibleAnnotations");
/*  317 */     return CtClassType.toAnnotationType(ignoreNotFound, getDeclaringClass().getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSignature() {
/*  336 */     return this.fieldInfo.getDescriptor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGenericSignature() {
/*  348 */     SignatureAttribute sa = (SignatureAttribute)this.fieldInfo.getAttribute("Signature");
/*  349 */     return (sa == null) ? null : sa.getSignature();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setGenericSignature(String sig) {
/*  363 */     this.declaringClass.checkModify();
/*  364 */     this.fieldInfo.addAttribute((AttributeInfo)new SignatureAttribute(this.fieldInfo.getConstPool(), sig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CtClass getType() throws NotFoundException {
/*  371 */     return Descriptor.toCtClass(this.fieldInfo.getDescriptor(), this.declaringClass
/*  372 */         .getClassPool());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setType(CtClass clazz) {
/*  379 */     this.declaringClass.checkModify();
/*  380 */     this.fieldInfo.setDescriptor(Descriptor.of(clazz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getConstantValue() {
/*  401 */     int value, index = this.fieldInfo.getConstantValue();
/*  402 */     if (index == 0) {
/*  403 */       return null;
/*      */     }
/*  405 */     ConstPool cp = this.fieldInfo.getConstPool();
/*  406 */     switch (cp.getTag(index)) {
/*      */       case 5:
/*  408 */         return new Long(cp.getLongInfo(index));
/*      */       case 4:
/*  410 */         return new Float(cp.getFloatInfo(index));
/*      */       case 6:
/*  412 */         return new Double(cp.getDoubleInfo(index));
/*      */       case 3:
/*  414 */         value = cp.getIntegerInfo(index);
/*      */         
/*  416 */         if ("Z".equals(this.fieldInfo.getDescriptor())) {
/*  417 */           return new Boolean((value != 0));
/*      */         }
/*  419 */         return new Integer(value);
/*      */       case 8:
/*  421 */         return cp.getStringInfo(index);
/*      */     } 
/*  423 */     throw new RuntimeException("bad tag: " + cp.getTag(index) + " at " + index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getAttribute(String name) {
/*  440 */     AttributeInfo ai = this.fieldInfo.getAttribute(name);
/*  441 */     if (ai == null) {
/*  442 */       return null;
/*      */     }
/*  444 */     return ai.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, byte[] data) {
/*  458 */     this.declaringClass.checkModify();
/*  459 */     this.fieldInfo.addAttribute(new AttributeInfo(this.fieldInfo.getConstPool(), name, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class Initializer
/*      */   {
/*      */     public static Initializer constant(int i) {
/*  484 */       return new CtField.IntInitializer(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer constant(boolean b) {
/*  492 */       return new CtField.IntInitializer(b ? 1 : 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer constant(long l) {
/*  500 */       return new CtField.LongInitializer(l);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer constant(float l) {
/*  508 */       return new CtField.FloatInitializer(l);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer constant(double d) {
/*  516 */       return new CtField.DoubleInitializer(d);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer constant(String s) {
/*  524 */       return new CtField.StringInitializer(s);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byParameter(int nth) {
/*  542 */       CtField.ParamInitializer i = new CtField.ParamInitializer();
/*  543 */       i.nthParam = nth;
/*  544 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNew(CtClass objectType) {
/*  562 */       CtField.NewInitializer i = new CtField.NewInitializer();
/*  563 */       i.objectType = objectType;
/*  564 */       i.stringParams = null;
/*  565 */       i.withConstructorParams = false;
/*  566 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNew(CtClass objectType, String[] stringParams) {
/*  589 */       CtField.NewInitializer i = new CtField.NewInitializer();
/*  590 */       i.objectType = objectType;
/*  591 */       i.stringParams = stringParams;
/*  592 */       i.withConstructorParams = false;
/*  593 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNewWithParams(CtClass objectType) {
/*  617 */       CtField.NewInitializer i = new CtField.NewInitializer();
/*  618 */       i.objectType = objectType;
/*  619 */       i.stringParams = null;
/*  620 */       i.withConstructorParams = true;
/*  621 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNewWithParams(CtClass objectType, String[] stringParams) {
/*  647 */       CtField.NewInitializer i = new CtField.NewInitializer();
/*  648 */       i.objectType = objectType;
/*  649 */       i.stringParams = stringParams;
/*  650 */       i.withConstructorParams = true;
/*  651 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byCall(CtClass methodClass, String methodName) {
/*  675 */       CtField.MethodInitializer i = new CtField.MethodInitializer();
/*  676 */       i.objectType = methodClass;
/*  677 */       i.methodName = methodName;
/*  678 */       i.stringParams = null;
/*  679 */       i.withConstructorParams = false;
/*  680 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byCall(CtClass methodClass, String methodName, String[] stringParams) {
/*  709 */       CtField.MethodInitializer i = new CtField.MethodInitializer();
/*  710 */       i.objectType = methodClass;
/*  711 */       i.methodName = methodName;
/*  712 */       i.stringParams = stringParams;
/*  713 */       i.withConstructorParams = false;
/*  714 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byCallWithParams(CtClass methodClass, String methodName) {
/*  741 */       CtField.MethodInitializer i = new CtField.MethodInitializer();
/*  742 */       i.objectType = methodClass;
/*  743 */       i.methodName = methodName;
/*  744 */       i.stringParams = null;
/*  745 */       i.withConstructorParams = true;
/*  746 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byCallWithParams(CtClass methodClass, String methodName, String[] stringParams) {
/*  777 */       CtField.MethodInitializer i = new CtField.MethodInitializer();
/*  778 */       i.objectType = methodClass;
/*  779 */       i.methodName = methodName;
/*  780 */       i.stringParams = stringParams;
/*  781 */       i.withConstructorParams = true;
/*  782 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNewArray(CtClass type, int size) throws NotFoundException {
/*  796 */       return new CtField.ArrayInitializer(type.getComponentType(), size);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byNewArray(CtClass type, int[] sizes) {
/*  809 */       return new CtField.MultiArrayInitializer(type, sizes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Initializer byExpr(String source) {
/*  818 */       return new CtField.CodeInitializer(source);
/*      */     }
/*      */     
/*      */     static Initializer byExpr(ASTree source) {
/*  822 */       return new CtField.PtreeInitializer(source);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void check(String desc) throws CannotCompileException {}
/*      */ 
/*      */ 
/*      */     
/*      */     abstract int compile(CtClass param1CtClass, String param1String, Bytecode param1Bytecode, CtClass[] param1ArrayOfCtClass, Javac param1Javac) throws CannotCompileException;
/*      */ 
/*      */ 
/*      */     
/*      */     abstract int compileIfStatic(CtClass param1CtClass, String param1String, Bytecode param1Bytecode, Javac param1Javac) throws CannotCompileException;
/*      */ 
/*      */ 
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/*  840 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class CodeInitializer0
/*      */     extends Initializer
/*      */   {
/*      */     abstract void compileExpr(Javac param1Javac) throws CompileError;
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/*      */       try {
/*  851 */         code.addAload(0);
/*  852 */         compileExpr(drv);
/*  853 */         code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/*  854 */         return code.getMaxStack();
/*      */       }
/*  856 */       catch (CompileError e) {
/*  857 */         throw new CannotCompileException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/*      */       try {
/*  865 */         compileExpr(drv);
/*  866 */         code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/*  867 */         return code.getMaxStack();
/*      */       }
/*  869 */       catch (CompileError e) {
/*  870 */         throw new CannotCompileException(e);
/*      */       } 
/*      */     }
/*      */     
/*      */     int getConstantValue2(ConstPool cp, CtClass type, ASTree tree) {
/*  875 */       if (type.isPrimitive()) {
/*  876 */         if (tree instanceof IntConst) {
/*  877 */           long value = ((IntConst)tree).get();
/*  878 */           if (type == CtClass.doubleType)
/*  879 */             return cp.addDoubleInfo(value); 
/*  880 */           if (type == CtClass.floatType)
/*  881 */             return cp.addFloatInfo((float)value); 
/*  882 */           if (type == CtClass.longType)
/*  883 */             return cp.addLongInfo(value); 
/*  884 */           if (type != CtClass.voidType) {
/*  885 */             return cp.addIntegerInfo((int)value);
/*      */           }
/*  887 */         } else if (tree instanceof DoubleConst) {
/*  888 */           double value = ((DoubleConst)tree).get();
/*  889 */           if (type == CtClass.floatType)
/*  890 */             return cp.addFloatInfo((float)value); 
/*  891 */           if (type == CtClass.doubleType) {
/*  892 */             return cp.addDoubleInfo(value);
/*      */           }
/*      */         } 
/*  895 */       } else if (tree instanceof StringL && type
/*  896 */         .getName().equals("java.lang.String")) {
/*  897 */         return cp.addStringInfo(((StringL)tree).get());
/*      */       } 
/*  899 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   static class CodeInitializer
/*      */     extends CodeInitializer0 {
/*      */     CodeInitializer(String expr) {
/*  906 */       this.expression = expr;
/*      */     } private String expression;
/*      */     void compileExpr(Javac drv) throws CompileError {
/*  909 */       drv.compileExpr(this.expression);
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/*      */       try {
/*  914 */         ASTree t = Javac.parseExpr(this.expression, new SymbolTable());
/*  915 */         return getConstantValue2(cp, type, t);
/*      */       }
/*  917 */       catch (CompileError e) {
/*  918 */         return 0;
/*      */       } 
/*      */     } }
/*      */   
/*      */   static class PtreeInitializer extends CodeInitializer0 {
/*      */     private ASTree expression;
/*      */     
/*      */     PtreeInitializer(ASTree expr) {
/*  926 */       this.expression = expr;
/*      */     }
/*      */     void compileExpr(Javac drv) throws CompileError {
/*  929 */       drv.compileExpr(this.expression);
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/*  933 */       return getConstantValue2(cp, type, this.expression);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ParamInitializer
/*      */     extends Initializer
/*      */   {
/*      */     int nthParam;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/*  950 */       if (parameters != null && this.nthParam < parameters.length) {
/*  951 */         code.addAload(0);
/*  952 */         int nth = nthParamToLocal(this.nthParam, parameters, false);
/*  953 */         int s = code.addLoad(nth, type) + 1;
/*  954 */         code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/*  955 */         return s;
/*      */       } 
/*      */       
/*  958 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static int nthParamToLocal(int nth, CtClass[] params, boolean isStatic) {
/*      */       int k;
/*  971 */       CtClass longType = CtClass.longType;
/*  972 */       CtClass doubleType = CtClass.doubleType;
/*      */       
/*  974 */       if (isStatic) {
/*  975 */         k = 0;
/*      */       } else {
/*  977 */         k = 1;
/*      */       } 
/*  979 */       for (int i = 0; i < nth; i++) {
/*  980 */         CtClass type = params[i];
/*  981 */         if (type == longType || type == doubleType) {
/*  982 */           k += 2;
/*      */         } else {
/*  984 */           k++;
/*      */         } 
/*      */       } 
/*  987 */       return k;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/*  993 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class NewInitializer
/*      */     extends Initializer
/*      */   {
/*      */     CtClass objectType;
/*      */ 
/*      */ 
/*      */     
/*      */     String[] stringParams;
/*      */ 
/*      */ 
/*      */     
/*      */     boolean withConstructorParams;
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/*      */       int stacksize;
/* 1017 */       code.addAload(0);
/* 1018 */       code.addNew(this.objectType);
/* 1019 */       code.add(89);
/* 1020 */       code.addAload(0);
/*      */       
/* 1022 */       if (this.stringParams == null) {
/* 1023 */         stacksize = 4;
/*      */       } else {
/* 1025 */         stacksize = compileStringParameter(code) + 4;
/*      */       } 
/* 1027 */       if (this.withConstructorParams) {
/* 1028 */         stacksize += CtNewWrappedMethod.compileParameterList(code, parameters, 1);
/*      */       }
/*      */       
/* 1031 */       code.addInvokespecial(this.objectType, "<init>", getDescriptor());
/* 1032 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1033 */       return stacksize;
/*      */     }
/*      */     
/*      */     private String getDescriptor() {
/* 1037 */       String desc3 = "(Ljava/lang/Object;[Ljava/lang/String;[Ljava/lang/Object;)V";
/*      */ 
/*      */       
/* 1040 */       if (this.stringParams == null) {
/* 1041 */         if (this.withConstructorParams) {
/* 1042 */           return "(Ljava/lang/Object;[Ljava/lang/Object;)V";
/*      */         }
/* 1044 */         return "(Ljava/lang/Object;)V";
/*      */       } 
/* 1046 */       if (this.withConstructorParams) {
/* 1047 */         return "(Ljava/lang/Object;[Ljava/lang/String;[Ljava/lang/Object;)V";
/*      */       }
/* 1049 */       return "(Ljava/lang/Object;[Ljava/lang/String;)V";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/*      */       String desc;
/* 1060 */       code.addNew(this.objectType);
/* 1061 */       code.add(89);
/*      */       
/* 1063 */       int stacksize = 2;
/* 1064 */       if (this.stringParams == null) {
/* 1065 */         desc = "()V";
/*      */       } else {
/* 1067 */         desc = "([Ljava/lang/String;)V";
/* 1068 */         stacksize += compileStringParameter(code);
/*      */       } 
/*      */       
/* 1071 */       code.addInvokespecial(this.objectType, "<init>", desc);
/* 1072 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1073 */       return stacksize;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected final int compileStringParameter(Bytecode code) throws CannotCompileException {
/* 1079 */       int nparam = this.stringParams.length;
/* 1080 */       code.addIconst(nparam);
/* 1081 */       code.addAnewarray("java.lang.String");
/* 1082 */       for (int j = 0; j < nparam; j++) {
/* 1083 */         code.add(89);
/* 1084 */         code.addIconst(j);
/* 1085 */         code.addLdc(this.stringParams[j]);
/* 1086 */         code.add(83);
/*      */       } 
/*      */       
/* 1089 */       return 4;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class MethodInitializer
/*      */     extends NewInitializer
/*      */   {
/*      */     String methodName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/*      */       int stacksize;
/* 1113 */       code.addAload(0);
/* 1114 */       code.addAload(0);
/*      */       
/* 1116 */       if (this.stringParams == null) {
/* 1117 */         stacksize = 2;
/*      */       } else {
/* 1119 */         stacksize = compileStringParameter(code) + 2;
/*      */       } 
/* 1121 */       if (this.withConstructorParams) {
/* 1122 */         stacksize += CtNewWrappedMethod.compileParameterList(code, parameters, 1);
/*      */       }
/*      */       
/* 1125 */       String typeDesc = Descriptor.of(type);
/* 1126 */       String mDesc = getDescriptor() + typeDesc;
/* 1127 */       code.addInvokestatic(this.objectType, this.methodName, mDesc);
/* 1128 */       code.addPutfield(Bytecode.THIS, name, typeDesc);
/* 1129 */       return stacksize;
/*      */     }
/*      */     
/*      */     private String getDescriptor() {
/* 1133 */       String desc3 = "(Ljava/lang/Object;[Ljava/lang/String;[Ljava/lang/Object;)";
/*      */ 
/*      */       
/* 1136 */       if (this.stringParams == null) {
/* 1137 */         if (this.withConstructorParams) {
/* 1138 */           return "(Ljava/lang/Object;[Ljava/lang/Object;)";
/*      */         }
/* 1140 */         return "(Ljava/lang/Object;)";
/*      */       } 
/* 1142 */       if (this.withConstructorParams) {
/* 1143 */         return "(Ljava/lang/Object;[Ljava/lang/String;[Ljava/lang/Object;)";
/*      */       }
/* 1145 */       return "(Ljava/lang/Object;[Ljava/lang/String;)";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/*      */       String desc;
/* 1156 */       int stacksize = 1;
/* 1157 */       if (this.stringParams == null) {
/* 1158 */         desc = "()";
/*      */       } else {
/* 1160 */         desc = "([Ljava/lang/String;)";
/* 1161 */         stacksize += compileStringParameter(code);
/*      */       } 
/*      */       
/* 1164 */       String typeDesc = Descriptor.of(type);
/* 1165 */       code.addInvokestatic(this.objectType, this.methodName, desc + typeDesc);
/* 1166 */       code.addPutstatic(Bytecode.THIS, name, typeDesc);
/* 1167 */       return stacksize;
/*      */     } }
/*      */   
/*      */   static class IntInitializer extends Initializer {
/*      */     int value;
/*      */     
/*      */     IntInitializer(int v) {
/* 1174 */       this.value = v;
/*      */     }
/*      */     void check(String desc) throws CannotCompileException {
/* 1177 */       char c = desc.charAt(0);
/* 1178 */       if (c != 'I' && c != 'S' && c != 'B' && c != 'C' && c != 'Z') {
/* 1179 */         throw new CannotCompileException("type mismatch");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1186 */       code.addAload(0);
/* 1187 */       code.addIconst(this.value);
/* 1188 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1189 */       return 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1195 */       code.addIconst(this.value);
/* 1196 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1197 */       return 1;
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/* 1201 */       return cp.addIntegerInfo(this.value);
/*      */     }
/*      */   }
/*      */   
/*      */   static class LongInitializer extends Initializer { long value;
/*      */     
/*      */     LongInitializer(long v) {
/* 1208 */       this.value = v;
/*      */     }
/*      */     void check(String desc) throws CannotCompileException {
/* 1211 */       if (!desc.equals("J")) {
/* 1212 */         throw new CannotCompileException("type mismatch");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1219 */       code.addAload(0);
/* 1220 */       code.addLdc2w(this.value);
/* 1221 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1222 */       return 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1228 */       code.addLdc2w(this.value);
/* 1229 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1230 */       return 2;
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/* 1234 */       if (type == CtClass.longType) {
/* 1235 */         return cp.addLongInfo(this.value);
/*      */       }
/* 1237 */       return 0;
/*      */     } }
/*      */   
/*      */   static class FloatInitializer extends Initializer {
/*      */     float value;
/*      */     
/*      */     FloatInitializer(float v) {
/* 1244 */       this.value = v;
/*      */     }
/*      */     void check(String desc) throws CannotCompileException {
/* 1247 */       if (!desc.equals("F")) {
/* 1248 */         throw new CannotCompileException("type mismatch");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1255 */       code.addAload(0);
/* 1256 */       code.addFconst(this.value);
/* 1257 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1258 */       return 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1264 */       code.addFconst(this.value);
/* 1265 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1266 */       return 2;
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/* 1270 */       if (type == CtClass.floatType) {
/* 1271 */         return cp.addFloatInfo(this.value);
/*      */       }
/* 1273 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   static class DoubleInitializer extends Initializer { double value;
/*      */     
/*      */     DoubleInitializer(double v) {
/* 1280 */       this.value = v;
/*      */     }
/*      */     void check(String desc) throws CannotCompileException {
/* 1283 */       if (!desc.equals("D")) {
/* 1284 */         throw new CannotCompileException("type mismatch");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1291 */       code.addAload(0);
/* 1292 */       code.addLdc2w(this.value);
/* 1293 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1294 */       return 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1300 */       code.addLdc2w(this.value);
/* 1301 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1302 */       return 2;
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/* 1306 */       if (type == CtClass.doubleType) {
/* 1307 */         return cp.addDoubleInfo(this.value);
/*      */       }
/* 1309 */       return 0;
/*      */     } }
/*      */   
/*      */   static class StringInitializer extends Initializer {
/*      */     String value;
/*      */     
/*      */     StringInitializer(String v) {
/* 1316 */       this.value = v;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1322 */       code.addAload(0);
/* 1323 */       code.addLdc(this.value);
/* 1324 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1325 */       return 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1331 */       code.addLdc(this.value);
/* 1332 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1333 */       return 1;
/*      */     }
/*      */     
/*      */     int getConstantValue(ConstPool cp, CtClass type) {
/* 1337 */       if (type.getName().equals("java.lang.String")) {
/* 1338 */         return cp.addStringInfo(this.value);
/*      */       }
/* 1340 */       return 0;
/*      */     }
/*      */   }
/*      */   
/*      */   static class ArrayInitializer extends Initializer { CtClass type;
/*      */     int size;
/*      */     
/*      */     ArrayInitializer(CtClass t, int s) {
/* 1348 */       this.type = t; this.size = s;
/*      */     }
/*      */     private void addNewarray(Bytecode code) {
/* 1351 */       if (this.type.isPrimitive()) {
/* 1352 */         code.addNewarray(((CtPrimitiveType)this.type).getArrayType(), this.size);
/*      */       } else {
/*      */         
/* 1355 */         code.addAnewarray(this.type, this.size);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1362 */       code.addAload(0);
/* 1363 */       addNewarray(code);
/* 1364 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1365 */       return 2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1371 */       addNewarray(code);
/* 1372 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1373 */       return 1;
/*      */     } }
/*      */   
/*      */   static class MultiArrayInitializer extends Initializer {
/*      */     CtClass type;
/*      */     int[] dim;
/*      */     
/*      */     MultiArrayInitializer(CtClass t, int[] d) {
/* 1381 */       this.type = t; this.dim = d;
/*      */     }
/*      */     void check(String desc) throws CannotCompileException {
/* 1384 */       if (desc.charAt(0) != '[') {
/* 1385 */         throw new CannotCompileException("type mismatch");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compile(CtClass type, String name, Bytecode code, CtClass[] parameters, Javac drv) throws CannotCompileException {
/* 1392 */       code.addAload(0);
/* 1393 */       int s = code.addMultiNewarray(type, this.dim);
/* 1394 */       code.addPutfield(Bytecode.THIS, name, Descriptor.of(type));
/* 1395 */       return s + 1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     int compileIfStatic(CtClass type, String name, Bytecode code, Javac drv) throws CannotCompileException {
/* 1401 */       int s = code.addMultiNewarray(type, this.dim);
/* 1402 */       code.addPutstatic(Bytecode.THIS, name, Descriptor.of(type));
/* 1403 */       return s;
/*      */     }
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\CtField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */