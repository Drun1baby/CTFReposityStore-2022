/*      */ package javassist;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javassist.bytecode.AccessFlag;
/*      */ import javassist.bytecode.AnnotationsAttribute;
/*      */ import javassist.bytecode.AttributeInfo;
/*      */ import javassist.bytecode.BadBytecode;
/*      */ import javassist.bytecode.Bytecode;
/*      */ import javassist.bytecode.ClassFile;
/*      */ import javassist.bytecode.CodeAttribute;
/*      */ import javassist.bytecode.CodeIterator;
/*      */ import javassist.bytecode.ConstPool;
/*      */ import javassist.bytecode.ConstantAttribute;
/*      */ import javassist.bytecode.Descriptor;
/*      */ import javassist.bytecode.EnclosingMethodAttribute;
/*      */ import javassist.bytecode.FieldInfo;
/*      */ import javassist.bytecode.InnerClassesAttribute;
/*      */ import javassist.bytecode.MethodInfo;
/*      */ import javassist.bytecode.ParameterAnnotationsAttribute;
/*      */ import javassist.bytecode.SignatureAttribute;
/*      */ import javassist.bytecode.annotation.Annotation;
/*      */ import javassist.bytecode.annotation.AnnotationImpl;
/*      */ import javassist.compiler.AccessorMaker;
/*      */ import javassist.compiler.CompileError;
/*      */ import javassist.compiler.Javac;
/*      */ import javassist.expr.ExprEditor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class CtClassType
/*      */   extends CtClass
/*      */ {
/*      */   ClassPool classPool;
/*      */   boolean wasChanged;
/*      */   private boolean wasFrozen;
/*      */   boolean wasPruned;
/*      */   boolean gcConstPool;
/*      */   ClassFile classfile;
/*      */   byte[] rawClassfile;
/*      */   private WeakReference memberCache;
/*      */   private AccessorMaker accessors;
/*      */   private FieldInitLink fieldInitializers;
/*      */   private Hashtable hiddenMethods;
/*      */   private int uniqueNumberSeed;
/*   76 */   private boolean doPruning = ClassPool.doPruning;
/*      */   private int getCount;
/*      */   private static final int GET_THRESHOLD = 2;
/*      */   
/*      */   CtClassType(String name, ClassPool cp) {
/*   81 */     super(name);
/*   82 */     this.classPool = cp;
/*   83 */     this.wasChanged = this.wasFrozen = this.wasPruned = this.gcConstPool = false;
/*   84 */     this.classfile = null;
/*   85 */     this.rawClassfile = null;
/*   86 */     this.memberCache = null;
/*   87 */     this.accessors = null;
/*   88 */     this.fieldInitializers = null;
/*   89 */     this.hiddenMethods = null;
/*   90 */     this.uniqueNumberSeed = 0;
/*   91 */     this.getCount = 0;
/*      */   }
/*      */   
/*      */   CtClassType(InputStream ins, ClassPool cp) throws IOException {
/*   95 */     this((String)null, cp);
/*   96 */     this.classfile = new ClassFile(new DataInputStream(ins));
/*   97 */     this.qualifiedName = this.classfile.getName();
/*      */   }
/*      */   
/*      */   CtClassType(ClassFile cf, ClassPool cp) {
/*  101 */     this((String)null, cp);
/*  102 */     this.classfile = cf;
/*  103 */     this.qualifiedName = this.classfile.getName();
/*      */   }
/*      */   
/*      */   protected void extendToString(StringBuffer buffer) {
/*  107 */     if (this.wasChanged) {
/*  108 */       buffer.append("changed ");
/*      */     }
/*  110 */     if (this.wasFrozen) {
/*  111 */       buffer.append("frozen ");
/*      */     }
/*  113 */     if (this.wasPruned) {
/*  114 */       buffer.append("pruned ");
/*      */     }
/*  116 */     buffer.append(Modifier.toString(getModifiers()));
/*  117 */     buffer.append(" class ");
/*  118 */     buffer.append(getName());
/*      */     
/*      */     try {
/*  121 */       CtClass ext = getSuperclass();
/*  122 */       if (ext != null) {
/*  123 */         String name = ext.getName();
/*  124 */         if (!name.equals("java.lang.Object")) {
/*  125 */           buffer.append(" extends " + ext.getName());
/*      */         }
/*      */       } 
/*  128 */     } catch (NotFoundException e) {
/*  129 */       buffer.append(" extends ??");
/*      */     } 
/*      */     
/*      */     try {
/*  133 */       CtClass[] intf = getInterfaces();
/*  134 */       if (intf.length > 0) {
/*  135 */         buffer.append(" implements ");
/*      */       }
/*  137 */       for (int i = 0; i < intf.length; i++) {
/*  138 */         buffer.append(intf[i].getName());
/*  139 */         buffer.append(", ");
/*      */       }
/*      */     
/*  142 */     } catch (NotFoundException e) {
/*  143 */       buffer.append(" extends ??");
/*      */     } 
/*      */     
/*  146 */     CtMember.Cache memCache = getMembers();
/*  147 */     exToString(buffer, " fields=", memCache
/*  148 */         .fieldHead(), memCache.lastField());
/*  149 */     exToString(buffer, " constructors=", memCache
/*  150 */         .consHead(), memCache.lastCons());
/*  151 */     exToString(buffer, " methods=", memCache
/*  152 */         .methodHead(), memCache.lastMethod());
/*      */   }
/*      */ 
/*      */   
/*      */   private void exToString(StringBuffer buffer, String msg, CtMember head, CtMember tail) {
/*  157 */     buffer.append(msg);
/*  158 */     while (head != tail) {
/*  159 */       head = head.next();
/*  160 */       buffer.append(head);
/*  161 */       buffer.append(", ");
/*      */     } 
/*      */   }
/*      */   
/*      */   public AccessorMaker getAccessorMaker() {
/*  166 */     if (this.accessors == null) {
/*  167 */       this.accessors = new AccessorMaker(this);
/*      */     }
/*  169 */     return this.accessors;
/*      */   }
/*      */   
/*      */   public ClassFile getClassFile2() {
/*  173 */     ClassFile cfile = this.classfile;
/*  174 */     if (cfile != null) {
/*  175 */       return cfile;
/*      */     }
/*  177 */     this.classPool.compress();
/*  178 */     if (this.rawClassfile != null) {
/*      */       try {
/*  180 */         this.classfile = new ClassFile(new DataInputStream(new ByteArrayInputStream(this.rawClassfile)));
/*      */         
/*  182 */         this.rawClassfile = null;
/*  183 */         this.getCount = 2;
/*  184 */         return this.classfile;
/*      */       }
/*  186 */       catch (IOException e) {
/*  187 */         throw new RuntimeException(e.toString(), e);
/*      */       } 
/*      */     }
/*      */     
/*  191 */     InputStream fin = null;
/*      */     try {
/*  193 */       fin = this.classPool.openClassfile(getName());
/*  194 */       if (fin == null) {
/*  195 */         throw new NotFoundException(getName());
/*      */       }
/*  197 */       fin = new BufferedInputStream(fin);
/*  198 */       ClassFile cf = new ClassFile(new DataInputStream(fin));
/*  199 */       if (!cf.getName().equals(this.qualifiedName)) {
/*  200 */         throw new RuntimeException("cannot find " + this.qualifiedName + ": " + cf
/*  201 */             .getName() + " found in " + this.qualifiedName
/*  202 */             .replace('.', '/') + ".class");
/*      */       }
/*  204 */       this.classfile = cf;
/*  205 */       return cf;
/*      */     }
/*  207 */     catch (NotFoundException e) {
/*  208 */       throw new RuntimeException(e.toString(), e);
/*      */     }
/*  210 */     catch (IOException e) {
/*  211 */       throw new RuntimeException(e.toString(), e);
/*      */     } finally {
/*      */       
/*  214 */       if (fin != null) {
/*      */         try {
/*  216 */           fin.close();
/*      */         }
/*  218 */         catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void incGetCounter() {
/*  227 */     this.getCount++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void compress() {
/*  235 */     if (this.getCount < 2)
/*  236 */       if (!isModified() && ClassPool.releaseUnmodifiedClassFile) {
/*  237 */         removeClassFile();
/*  238 */       } else if (isFrozen() && !this.wasPruned) {
/*  239 */         saveClassFile();
/*      */       }  
/*  241 */     this.getCount = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void saveClassFile() {
/*  251 */     if (this.classfile == null || hasMemberCache() != null) {
/*      */       return;
/*      */     }
/*  254 */     ByteArrayOutputStream barray = new ByteArrayOutputStream();
/*  255 */     DataOutputStream out = new DataOutputStream(barray);
/*      */     try {
/*  257 */       this.classfile.write(out);
/*  258 */       barray.close();
/*  259 */       this.rawClassfile = barray.toByteArray();
/*  260 */       this.classfile = null;
/*      */     }
/*  262 */     catch (IOException iOException) {}
/*      */   }
/*      */   
/*      */   private synchronized void removeClassFile() {
/*  266 */     if (this.classfile != null && !isModified() && hasMemberCache() == null)
/*  267 */       this.classfile = null; 
/*      */   }
/*      */   public ClassPool getClassPool() {
/*  270 */     return this.classPool;
/*      */   } void setClassPool(ClassPool cp) {
/*  272 */     this.classPool = cp;
/*      */   }
/*      */   public URL getURL() throws NotFoundException {
/*  275 */     URL url = this.classPool.find(getName());
/*  276 */     if (url == null) {
/*  277 */       throw new NotFoundException(getName());
/*      */     }
/*  279 */     return url;
/*      */   }
/*      */   public boolean isModified() {
/*  282 */     return this.wasChanged;
/*      */   } public boolean isFrozen() {
/*  284 */     return this.wasFrozen;
/*      */   } public void freeze() {
/*  286 */     this.wasFrozen = true;
/*      */   }
/*      */   void checkModify() throws RuntimeException {
/*  289 */     if (isFrozen()) {
/*  290 */       String msg = getName() + " class is frozen";
/*  291 */       if (this.wasPruned) {
/*  292 */         msg = msg + " and pruned";
/*      */       }
/*  294 */       throw new RuntimeException(msg);
/*      */     } 
/*      */     
/*  297 */     this.wasChanged = true;
/*      */   }
/*      */   
/*      */   public void defrost() {
/*  301 */     checkPruned("defrost");
/*  302 */     this.wasFrozen = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean subtypeOf(CtClass clazz) throws NotFoundException {
/*  307 */     String cname = clazz.getName();
/*  308 */     if (this == clazz || getName().equals(cname)) {
/*  309 */       return true;
/*      */     }
/*  311 */     ClassFile file = getClassFile2();
/*  312 */     String supername = file.getSuperclass();
/*  313 */     if (supername != null && supername.equals(cname)) {
/*  314 */       return true;
/*      */     }
/*  316 */     String[] ifs = file.getInterfaces();
/*  317 */     int num = ifs.length; int i;
/*  318 */     for (i = 0; i < num; i++) {
/*  319 */       if (ifs[i].equals(cname))
/*  320 */         return true; 
/*      */     } 
/*  322 */     if (supername != null && this.classPool.get(supername).subtypeOf(clazz)) {
/*  323 */       return true;
/*      */     }
/*  325 */     for (i = 0; i < num; i++) {
/*  326 */       if (this.classPool.get(ifs[i]).subtypeOf(clazz))
/*  327 */         return true; 
/*      */     } 
/*  329 */     return false;
/*      */   }
/*      */   
/*      */   public void setName(String name) throws RuntimeException {
/*  333 */     String oldname = getName();
/*  334 */     if (name.equals(oldname)) {
/*      */       return;
/*      */     }
/*      */     
/*  338 */     this.classPool.checkNotFrozen(name);
/*  339 */     ClassFile cf = getClassFile2();
/*  340 */     super.setName(name);
/*  341 */     cf.setName(name);
/*  342 */     nameReplaced();
/*  343 */     this.classPool.classNameChanged(oldname, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getGenericSignature() {
/*  348 */     SignatureAttribute sa = (SignatureAttribute)getClassFile2().getAttribute("Signature");
/*  349 */     return (sa == null) ? null : sa.getSignature();
/*      */   }
/*      */   
/*      */   public void setGenericSignature(String sig) {
/*  353 */     ClassFile cf = getClassFile();
/*  354 */     SignatureAttribute sa = new SignatureAttribute(cf.getConstPool(), sig);
/*  355 */     cf.addAttribute((AttributeInfo)sa);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceClassName(ClassMap classnames) throws RuntimeException {
/*  361 */     String oldClassName = getName();
/*      */     
/*  363 */     String newClassName = (String)classnames.get(Descriptor.toJvmName(oldClassName));
/*  364 */     if (newClassName != null) {
/*  365 */       newClassName = Descriptor.toJavaName(newClassName);
/*      */       
/*  367 */       this.classPool.checkNotFrozen(newClassName);
/*      */     } 
/*      */     
/*  370 */     super.replaceClassName(classnames);
/*  371 */     ClassFile cf = getClassFile2();
/*  372 */     cf.renameClass(classnames);
/*  373 */     nameReplaced();
/*      */     
/*  375 */     if (newClassName != null) {
/*  376 */       super.setName(newClassName);
/*  377 */       this.classPool.classNameChanged(oldClassName, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceClassName(String oldname, String newname) throws RuntimeException {
/*  384 */     String thisname = getName();
/*  385 */     if (thisname.equals(oldname)) {
/*  386 */       setName(newname);
/*      */     } else {
/*  388 */       super.replaceClassName(oldname, newname);
/*  389 */       getClassFile2().renameClass(oldname, newname);
/*  390 */       nameReplaced();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isInterface() {
/*  395 */     return Modifier.isInterface(getModifiers());
/*      */   }
/*      */   
/*      */   public boolean isAnnotation() {
/*  399 */     return Modifier.isAnnotation(getModifiers());
/*      */   }
/*      */   
/*      */   public boolean isEnum() {
/*  403 */     return Modifier.isEnum(getModifiers());
/*      */   }
/*      */   
/*      */   public int getModifiers() {
/*  407 */     ClassFile cf = getClassFile2();
/*  408 */     int acc = cf.getAccessFlags();
/*  409 */     acc = AccessFlag.clear(acc, 32);
/*  410 */     int inner = cf.getInnerAccessFlags();
/*  411 */     if (inner != -1 && (inner & 0x8) != 0) {
/*  412 */       acc |= 0x8;
/*      */     }
/*  414 */     return AccessFlag.toModifier(acc);
/*      */   }
/*      */   
/*      */   public CtClass[] getNestedClasses() throws NotFoundException {
/*  418 */     ClassFile cf = getClassFile2();
/*      */     
/*  420 */     InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
/*  421 */     if (ica == null) {
/*  422 */       return new CtClass[0];
/*      */     }
/*  424 */     String thisName = cf.getName() + "$";
/*  425 */     int n = ica.tableLength();
/*  426 */     ArrayList<CtClass> list = new ArrayList(n);
/*  427 */     for (int i = 0; i < n; i++) {
/*  428 */       String name = ica.innerClass(i);
/*  429 */       if (name != null && 
/*  430 */         name.startsWith(thisName))
/*      */       {
/*  432 */         if (name.lastIndexOf('$') < thisName.length()) {
/*  433 */           list.add(this.classPool.get(name));
/*      */         }
/*      */       }
/*      */     } 
/*  437 */     return list.<CtClass>toArray(new CtClass[list.size()]);
/*      */   }
/*      */   
/*      */   public void setModifiers(int mod) {
/*  441 */     ClassFile cf = getClassFile2();
/*  442 */     if (Modifier.isStatic(mod)) {
/*  443 */       int flags = cf.getInnerAccessFlags();
/*  444 */       if (flags != -1 && (flags & 0x8) != 0) {
/*  445 */         mod &= 0xFFFFFFF7;
/*      */       } else {
/*  447 */         throw new RuntimeException("cannot change " + getName() + " into a static class");
/*      */       } 
/*      */     } 
/*  450 */     checkModify();
/*  451 */     cf.setAccessFlags(AccessFlag.of(mod));
/*      */   }
/*      */   
/*      */   public boolean hasAnnotation(Class clz) {
/*  455 */     ClassFile cf = getClassFile2();
/*      */     
/*  457 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)cf.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  459 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)cf.getAttribute("RuntimeVisibleAnnotations");
/*  460 */     return hasAnnotationType(clz, getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean hasAnnotationType(Class clz, ClassPool cp, AnnotationsAttribute a1, AnnotationsAttribute a2) {
/*      */     Annotation[] anno1, anno2;
/*  468 */     if (a1 == null) {
/*  469 */       anno1 = null;
/*      */     } else {
/*  471 */       anno1 = a1.getAnnotations();
/*      */     } 
/*  473 */     if (a2 == null) {
/*  474 */       anno2 = null;
/*      */     } else {
/*  476 */       anno2 = a2.getAnnotations();
/*      */     } 
/*  478 */     String typeName = clz.getName();
/*  479 */     if (anno1 != null)
/*  480 */       for (int i = 0; i < anno1.length; i++) {
/*  481 */         if (anno1[i].getTypeName().equals(typeName))
/*  482 */           return true; 
/*      */       }  
/*  484 */     if (anno2 != null)
/*  485 */       for (int i = 0; i < anno2.length; i++) {
/*  486 */         if (anno2[i].getTypeName().equals(typeName))
/*  487 */           return true; 
/*      */       }  
/*  489 */     return false;
/*      */   }
/*      */   
/*      */   public Object getAnnotation(Class clz) throws ClassNotFoundException {
/*  493 */     ClassFile cf = getClassFile2();
/*      */     
/*  495 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)cf.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  497 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)cf.getAttribute("RuntimeVisibleAnnotations");
/*  498 */     return getAnnotationType(clz, getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object getAnnotationType(Class clz, ClassPool cp, AnnotationsAttribute a1, AnnotationsAttribute a2) throws ClassNotFoundException {
/*      */     Annotation[] anno1, anno2;
/*  507 */     if (a1 == null) {
/*  508 */       anno1 = null;
/*      */     } else {
/*  510 */       anno1 = a1.getAnnotations();
/*      */     } 
/*  512 */     if (a2 == null) {
/*  513 */       anno2 = null;
/*      */     } else {
/*  515 */       anno2 = a2.getAnnotations();
/*      */     } 
/*  517 */     String typeName = clz.getName();
/*  518 */     if (anno1 != null)
/*  519 */       for (int i = 0; i < anno1.length; i++) {
/*  520 */         if (anno1[i].getTypeName().equals(typeName))
/*  521 */           return toAnnoType(anno1[i], cp); 
/*      */       }  
/*  523 */     if (anno2 != null)
/*  524 */       for (int i = 0; i < anno2.length; i++) {
/*  525 */         if (anno2[i].getTypeName().equals(typeName))
/*  526 */           return toAnnoType(anno2[i], cp); 
/*      */       }  
/*  528 */     return null;
/*      */   }
/*      */   
/*      */   public Object[] getAnnotations() throws ClassNotFoundException {
/*  532 */     return getAnnotations(false);
/*      */   }
/*      */   
/*      */   public Object[] getAvailableAnnotations() {
/*      */     try {
/*  537 */       return getAnnotations(true);
/*      */     }
/*  539 */     catch (ClassNotFoundException e) {
/*  540 */       throw new RuntimeException("Unexpected exception ", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] getAnnotations(boolean ignoreNotFound) throws ClassNotFoundException {
/*  547 */     ClassFile cf = getClassFile2();
/*      */     
/*  549 */     AnnotationsAttribute ainfo = (AnnotationsAttribute)cf.getAttribute("RuntimeInvisibleAnnotations");
/*      */     
/*  551 */     AnnotationsAttribute ainfo2 = (AnnotationsAttribute)cf.getAttribute("RuntimeVisibleAnnotations");
/*  552 */     return toAnnotationType(ignoreNotFound, getClassPool(), ainfo, ainfo2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object[] toAnnotationType(boolean ignoreNotFound, ClassPool cp, AnnotationsAttribute a1, AnnotationsAttribute a2) throws ClassNotFoundException {
/*      */     Annotation[] anno1, anno2;
/*      */     int size1, size2;
/*  562 */     if (a1 == null) {
/*  563 */       anno1 = null;
/*  564 */       size1 = 0;
/*      */     } else {
/*      */       
/*  567 */       anno1 = a1.getAnnotations();
/*  568 */       size1 = anno1.length;
/*      */     } 
/*      */     
/*  571 */     if (a2 == null) {
/*  572 */       anno2 = null;
/*  573 */       size2 = 0;
/*      */     } else {
/*      */       
/*  576 */       anno2 = a2.getAnnotations();
/*  577 */       size2 = anno2.length;
/*      */     } 
/*      */     
/*  580 */     if (!ignoreNotFound) {
/*  581 */       Object[] result = new Object[size1 + size2];
/*  582 */       for (int m = 0; m < size1; m++) {
/*  583 */         result[m] = toAnnoType(anno1[m], cp);
/*      */       }
/*  585 */       for (int k = 0; k < size2; k++) {
/*  586 */         result[k + size1] = toAnnoType(anno2[k], cp);
/*      */       }
/*  588 */       return result;
/*      */     } 
/*      */     
/*  591 */     ArrayList<Object> annotations = new ArrayList();
/*  592 */     for (int i = 0; i < size1; i++) {
/*      */       try {
/*  594 */         annotations.add(toAnnoType(anno1[i], cp));
/*      */       }
/*  596 */       catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*  598 */     for (int j = 0; j < size2; j++) {
/*      */       try {
/*  600 */         annotations.add(toAnnoType(anno2[j], cp));
/*      */       }
/*  602 */       catch (ClassNotFoundException classNotFoundException) {}
/*      */     } 
/*      */     
/*  605 */     return annotations.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object[][] toAnnotationType(boolean ignoreNotFound, ClassPool cp, ParameterAnnotationsAttribute a1, ParameterAnnotationsAttribute a2, MethodInfo minfo) throws ClassNotFoundException {
/*  615 */     int numParameters = 0;
/*  616 */     if (a1 != null) {
/*  617 */       numParameters = a1.numParameters();
/*  618 */     } else if (a2 != null) {
/*  619 */       numParameters = a2.numParameters();
/*      */     } else {
/*  621 */       numParameters = Descriptor.numOfParameters(minfo.getDescriptor());
/*      */     } 
/*  623 */     Object[][] result = new Object[numParameters][];
/*  624 */     for (int i = 0; i < numParameters; i++) {
/*      */       Annotation[] anno1; Annotation[] anno2;
/*      */       int size1;
/*      */       int size2;
/*  628 */       if (a1 == null) {
/*  629 */         anno1 = null;
/*  630 */         size1 = 0;
/*      */       } else {
/*      */         
/*  633 */         anno1 = a1.getAnnotations()[i];
/*  634 */         size1 = anno1.length;
/*      */       } 
/*      */       
/*  637 */       if (a2 == null) {
/*  638 */         anno2 = null;
/*  639 */         size2 = 0;
/*      */       } else {
/*      */         
/*  642 */         anno2 = a2.getAnnotations()[i];
/*  643 */         size2 = anno2.length;
/*      */       } 
/*      */       
/*  646 */       if (!ignoreNotFound) {
/*  647 */         result[i] = new Object[size1 + size2]; int j;
/*  648 */         for (j = 0; j < size1; j++) {
/*  649 */           result[i][j] = toAnnoType(anno1[j], cp);
/*      */         }
/*  651 */         for (j = 0; j < size2; j++) {
/*  652 */           result[i][j + size1] = toAnnoType(anno2[j], cp);
/*      */         }
/*      */       } else {
/*  655 */         ArrayList<Object> annotations = new ArrayList(); int j;
/*  656 */         for (j = 0; j < size1; j++) {
/*      */           try {
/*  658 */             annotations.add(toAnnoType(anno1[j], cp));
/*      */           }
/*  660 */           catch (ClassNotFoundException classNotFoundException) {}
/*      */         } 
/*  662 */         for (j = 0; j < size2; j++) {
/*      */           try {
/*  664 */             annotations.add(toAnnoType(anno2[j], cp));
/*      */           }
/*  666 */           catch (ClassNotFoundException classNotFoundException) {}
/*      */         } 
/*      */         
/*  669 */         result[i] = annotations.toArray();
/*      */       } 
/*      */     } 
/*      */     
/*  673 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object toAnnoType(Annotation anno, ClassPool cp) throws ClassNotFoundException {
/*      */     try {
/*  680 */       ClassLoader cl = cp.getClassLoader();
/*  681 */       return anno.toAnnotationType(cl, cp);
/*      */     }
/*  683 */     catch (ClassNotFoundException e) {
/*  684 */       ClassLoader cl2 = cp.getClass().getClassLoader();
/*      */       try {
/*  686 */         return anno.toAnnotationType(cl2, cp);
/*      */       }
/*  688 */       catch (ClassNotFoundException e2) {
/*      */         try {
/*  690 */           Class<?> clazz = cp.get(anno.getTypeName()).toClass();
/*  691 */           return AnnotationImpl.make(clazz
/*  692 */               .getClassLoader(), clazz, cp, anno);
/*      */         
/*      */         }
/*  695 */         catch (Throwable e3) {
/*  696 */           throw new ClassNotFoundException(anno.getTypeName());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean subclassOf(CtClass superclass) {
/*  703 */     if (superclass == null) {
/*  704 */       return false;
/*      */     }
/*  706 */     String superName = superclass.getName();
/*  707 */     CtClass curr = this;
/*      */     try {
/*  709 */       while (curr != null) {
/*  710 */         if (curr.getName().equals(superName)) {
/*  711 */           return true;
/*      */         }
/*  713 */         curr = curr.getSuperclass();
/*      */       }
/*      */     
/*  716 */     } catch (Exception exception) {}
/*  717 */     return false;
/*      */   }
/*      */   
/*      */   public CtClass getSuperclass() throws NotFoundException {
/*  721 */     String supername = getClassFile2().getSuperclass();
/*  722 */     if (supername == null) {
/*  723 */       return null;
/*      */     }
/*  725 */     return this.classPool.get(supername);
/*      */   }
/*      */   
/*      */   public void setSuperclass(CtClass clazz) throws CannotCompileException {
/*  729 */     checkModify();
/*  730 */     if (isInterface()) {
/*  731 */       addInterface(clazz);
/*      */     } else {
/*  733 */       getClassFile2().setSuperclass(clazz.getName());
/*      */     } 
/*      */   }
/*      */   public CtClass[] getInterfaces() throws NotFoundException {
/*  737 */     String[] ifs = getClassFile2().getInterfaces();
/*  738 */     int num = ifs.length;
/*  739 */     CtClass[] ifc = new CtClass[num];
/*  740 */     for (int i = 0; i < num; i++) {
/*  741 */       ifc[i] = this.classPool.get(ifs[i]);
/*      */     }
/*  743 */     return ifc;
/*      */   }
/*      */   public void setInterfaces(CtClass[] list) {
/*      */     String[] ifs;
/*  747 */     checkModify();
/*      */     
/*  749 */     if (list == null) {
/*  750 */       ifs = new String[0];
/*      */     } else {
/*  752 */       int num = list.length;
/*  753 */       ifs = new String[num];
/*  754 */       for (int i = 0; i < num; i++) {
/*  755 */         ifs[i] = list[i].getName();
/*      */       }
/*      */     } 
/*  758 */     getClassFile2().setInterfaces(ifs);
/*      */   }
/*      */   
/*      */   public void addInterface(CtClass anInterface) {
/*  762 */     checkModify();
/*  763 */     if (anInterface != null)
/*  764 */       getClassFile2().addInterface(anInterface.getName()); 
/*      */   }
/*      */   
/*      */   public CtClass getDeclaringClass() throws NotFoundException {
/*  768 */     ClassFile cf = getClassFile2();
/*  769 */     InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
/*      */     
/*  771 */     if (ica == null) {
/*  772 */       return null;
/*      */     }
/*  774 */     String name = getName();
/*  775 */     int n = ica.tableLength();
/*  776 */     for (int i = 0; i < n; i++) {
/*  777 */       if (name.equals(ica.innerClass(i))) {
/*  778 */         String outName = ica.outerClass(i);
/*  779 */         if (outName != null) {
/*  780 */           return this.classPool.get(outName);
/*      */         }
/*      */ 
/*      */         
/*  784 */         EnclosingMethodAttribute ema = (EnclosingMethodAttribute)cf.getAttribute("EnclosingMethod");
/*      */         
/*  786 */         if (ema != null) {
/*  787 */           return this.classPool.get(ema.className());
/*      */         }
/*      */       } 
/*      */     } 
/*  791 */     return null;
/*      */   }
/*      */   
/*      */   public CtBehavior getEnclosingBehavior() throws NotFoundException {
/*  795 */     ClassFile cf = getClassFile2();
/*      */     
/*  797 */     EnclosingMethodAttribute ema = (EnclosingMethodAttribute)cf.getAttribute("EnclosingMethod");
/*      */     
/*  799 */     if (ema == null) {
/*  800 */       return null;
/*      */     }
/*  802 */     CtClass enc = this.classPool.get(ema.className());
/*  803 */     String name = ema.methodName();
/*  804 */     if ("<init>".equals(name))
/*  805 */       return enc.getConstructor(ema.methodDescriptor()); 
/*  806 */     if ("<clinit>".equals(name)) {
/*  807 */       return enc.getClassInitializer();
/*      */     }
/*  809 */     return enc.getMethod(name, ema.methodDescriptor());
/*      */   }
/*      */ 
/*      */   
/*      */   public CtClass makeNestedClass(String name, boolean isStatic) {
/*  814 */     if (!isStatic) {
/*  815 */       throw new RuntimeException("sorry, only nested static class is supported");
/*      */     }
/*      */     
/*  818 */     checkModify();
/*  819 */     CtClass c = this.classPool.makeNestedClass(getName() + "$" + name);
/*  820 */     ClassFile cf = getClassFile2();
/*  821 */     ClassFile cf2 = c.getClassFile2();
/*  822 */     InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
/*      */     
/*  824 */     if (ica == null) {
/*  825 */       ica = new InnerClassesAttribute(cf.getConstPool());
/*  826 */       cf.addAttribute((AttributeInfo)ica);
/*      */     } 
/*      */     
/*  829 */     ica.append(c.getName(), getName(), name, cf2
/*  830 */         .getAccessFlags() & 0xFFFFFFDF | 0x8);
/*  831 */     cf2.addAttribute(ica.copy(cf2.getConstPool(), null));
/*  832 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void nameReplaced() {
/*  838 */     CtMember.Cache cache = hasMemberCache();
/*  839 */     if (cache != null) {
/*  840 */       CtMember mth = cache.methodHead();
/*  841 */       CtMember tail = cache.lastMethod();
/*  842 */       while (mth != tail) {
/*  843 */         mth = mth.next();
/*  844 */         mth.nameReplaced();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CtMember.Cache hasMemberCache() {
/*  853 */     if (this.memberCache != null) {
/*  854 */       return this.memberCache.get();
/*      */     }
/*  856 */     return null;
/*      */   }
/*      */   
/*      */   protected synchronized CtMember.Cache getMembers() {
/*  860 */     CtMember.Cache cache = null;
/*  861 */     if (this.memberCache == null || (
/*  862 */       cache = this.memberCache.get()) == null) {
/*  863 */       cache = new CtMember.Cache(this);
/*  864 */       makeFieldCache(cache);
/*  865 */       makeBehaviorCache(cache);
/*  866 */       this.memberCache = new WeakReference<CtMember.Cache>(cache);
/*      */     } 
/*      */     
/*  869 */     return cache;
/*      */   }
/*      */   
/*      */   private void makeFieldCache(CtMember.Cache cache) {
/*  873 */     List<FieldInfo> list = getClassFile2().getFields();
/*  874 */     int n = list.size();
/*  875 */     for (int i = 0; i < n; i++) {
/*  876 */       FieldInfo finfo = list.get(i);
/*  877 */       CtField newField = new CtField(finfo, this);
/*  878 */       cache.addField(newField);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void makeBehaviorCache(CtMember.Cache cache) {
/*  883 */     List<MethodInfo> list = getClassFile2().getMethods();
/*  884 */     int n = list.size();
/*  885 */     for (int i = 0; i < n; i++) {
/*  886 */       MethodInfo minfo = list.get(i);
/*  887 */       if (minfo.isMethod()) {
/*  888 */         CtMethod newMethod = new CtMethod(minfo, this);
/*  889 */         cache.addMethod(newMethod);
/*      */       } else {
/*      */         
/*  892 */         CtConstructor newCons = new CtConstructor(minfo, this);
/*  893 */         cache.addConstructor(newCons);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public CtField[] getFields() {
/*  899 */     ArrayList alist = new ArrayList();
/*  900 */     getFields(alist, this);
/*  901 */     return (CtField[])alist.toArray((Object[])new CtField[alist.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void getFields(ArrayList<CtMember> alist, CtClass cc) {
/*  906 */     if (cc == null) {
/*      */       return;
/*      */     }
/*      */     try {
/*  910 */       getFields(alist, cc.getSuperclass());
/*      */     }
/*  912 */     catch (NotFoundException notFoundException) {}
/*      */     
/*      */     try {
/*  915 */       CtClass[] ifs = cc.getInterfaces();
/*  916 */       int num = ifs.length;
/*  917 */       for (int i = 0; i < num; i++) {
/*  918 */         getFields(alist, ifs[i]);
/*      */       }
/*  920 */     } catch (NotFoundException notFoundException) {}
/*      */     
/*  922 */     CtMember.Cache memCache = ((CtClassType)cc).getMembers();
/*  923 */     CtMember field = memCache.fieldHead();
/*  924 */     CtMember tail = memCache.lastField();
/*  925 */     while (field != tail) {
/*  926 */       field = field.next();
/*  927 */       if (!Modifier.isPrivate(field.getModifiers()))
/*  928 */         alist.add(field); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public CtField getField(String name, String desc) throws NotFoundException {
/*  933 */     CtField f = getField2(name, desc);
/*  934 */     return checkGetField(f, name, desc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CtField checkGetField(CtField f, String name, String desc) throws NotFoundException {
/*  940 */     if (f == null) {
/*  941 */       String msg = "field: " + name;
/*  942 */       if (desc != null) {
/*  943 */         msg = msg + " type " + desc;
/*      */       }
/*  945 */       throw new NotFoundException(msg + " in " + getName());
/*      */     } 
/*      */     
/*  948 */     return f;
/*      */   }
/*      */   
/*      */   CtField getField2(String name, String desc) {
/*  952 */     CtField df = getDeclaredField2(name, desc);
/*  953 */     if (df != null) {
/*  954 */       return df;
/*      */     }
/*      */     try {
/*  957 */       CtClass[] ifs = getInterfaces();
/*  958 */       int num = ifs.length;
/*  959 */       for (int i = 0; i < num; i++) {
/*  960 */         CtField f = ifs[i].getField2(name, desc);
/*  961 */         if (f != null) {
/*  962 */           return f;
/*      */         }
/*      */       } 
/*  965 */       CtClass s = getSuperclass();
/*  966 */       if (s != null) {
/*  967 */         return s.getField2(name, desc);
/*      */       }
/*  969 */     } catch (NotFoundException notFoundException) {}
/*  970 */     return null;
/*      */   }
/*      */   
/*      */   public CtField[] getDeclaredFields() {
/*  974 */     CtMember.Cache memCache = getMembers();
/*  975 */     CtMember field = memCache.fieldHead();
/*  976 */     CtMember tail = memCache.lastField();
/*  977 */     int num = CtMember.Cache.count(field, tail);
/*  978 */     CtField[] cfs = new CtField[num];
/*  979 */     int i = 0;
/*  980 */     while (field != tail) {
/*  981 */       field = field.next();
/*  982 */       cfs[i++] = (CtField)field;
/*      */     } 
/*      */     
/*  985 */     return cfs;
/*      */   }
/*      */   
/*      */   public CtField getDeclaredField(String name) throws NotFoundException {
/*  989 */     return getDeclaredField(name, (String)null);
/*      */   }
/*      */   
/*      */   public CtField getDeclaredField(String name, String desc) throws NotFoundException {
/*  993 */     CtField f = getDeclaredField2(name, desc);
/*  994 */     return checkGetField(f, name, desc);
/*      */   }
/*      */   
/*      */   private CtField getDeclaredField2(String name, String desc) {
/*  998 */     CtMember.Cache memCache = getMembers();
/*  999 */     CtMember field = memCache.fieldHead();
/* 1000 */     CtMember tail = memCache.lastField();
/* 1001 */     while (field != tail) {
/* 1002 */       field = field.next();
/* 1003 */       if (field.getName().equals(name) && (desc == null || desc
/* 1004 */         .equals(field.getSignature()))) {
/* 1005 */         return (CtField)field;
/*      */       }
/*      */     } 
/* 1008 */     return null;
/*      */   }
/*      */   
/*      */   public CtBehavior[] getDeclaredBehaviors() {
/* 1012 */     CtMember.Cache memCache = getMembers();
/* 1013 */     CtMember cons = memCache.consHead();
/* 1014 */     CtMember consTail = memCache.lastCons();
/* 1015 */     int cnum = CtMember.Cache.count(cons, consTail);
/* 1016 */     CtMember mth = memCache.methodHead();
/* 1017 */     CtMember mthTail = memCache.lastMethod();
/* 1018 */     int mnum = CtMember.Cache.count(mth, mthTail);
/*      */     
/* 1020 */     CtBehavior[] cb = new CtBehavior[cnum + mnum];
/* 1021 */     int i = 0;
/* 1022 */     while (cons != consTail) {
/* 1023 */       cons = cons.next();
/* 1024 */       cb[i++] = (CtBehavior)cons;
/*      */     } 
/*      */     
/* 1027 */     while (mth != mthTail) {
/* 1028 */       mth = mth.next();
/* 1029 */       cb[i++] = (CtBehavior)mth;
/*      */     } 
/*      */     
/* 1032 */     return cb;
/*      */   }
/*      */   
/*      */   public CtConstructor[] getConstructors() {
/* 1036 */     CtMember.Cache memCache = getMembers();
/* 1037 */     CtMember cons = memCache.consHead();
/* 1038 */     CtMember consTail = memCache.lastCons();
/*      */     
/* 1040 */     int n = 0;
/* 1041 */     CtMember mem = cons;
/* 1042 */     while (mem != consTail) {
/* 1043 */       mem = mem.next();
/* 1044 */       if (isPubCons((CtConstructor)mem)) {
/* 1045 */         n++;
/*      */       }
/*      */     } 
/* 1048 */     CtConstructor[] result = new CtConstructor[n];
/* 1049 */     int i = 0;
/* 1050 */     mem = cons;
/* 1051 */     while (mem != consTail) {
/* 1052 */       mem = mem.next();
/* 1053 */       CtConstructor cc = (CtConstructor)mem;
/* 1054 */       if (isPubCons(cc)) {
/* 1055 */         result[i++] = cc;
/*      */       }
/*      */     } 
/* 1058 */     return result;
/*      */   }
/*      */   
/*      */   private static boolean isPubCons(CtConstructor cons) {
/* 1062 */     return (!Modifier.isPrivate(cons.getModifiers()) && cons
/* 1063 */       .isConstructor());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CtConstructor getConstructor(String desc) throws NotFoundException {
/* 1069 */     CtMember.Cache memCache = getMembers();
/* 1070 */     CtMember cons = memCache.consHead();
/* 1071 */     CtMember consTail = memCache.lastCons();
/*      */     
/* 1073 */     while (cons != consTail) {
/* 1074 */       cons = cons.next();
/* 1075 */       CtConstructor cc = (CtConstructor)cons;
/* 1076 */       if (cc.getMethodInfo2().getDescriptor().equals(desc) && cc
/* 1077 */         .isConstructor()) {
/* 1078 */         return cc;
/*      */       }
/*      */     } 
/* 1081 */     return super.getConstructor(desc);
/*      */   }
/*      */   
/*      */   public CtConstructor[] getDeclaredConstructors() {
/* 1085 */     CtMember.Cache memCache = getMembers();
/* 1086 */     CtMember cons = memCache.consHead();
/* 1087 */     CtMember consTail = memCache.lastCons();
/*      */     
/* 1089 */     int n = 0;
/* 1090 */     CtMember mem = cons;
/* 1091 */     while (mem != consTail) {
/* 1092 */       mem = mem.next();
/* 1093 */       CtConstructor cc = (CtConstructor)mem;
/* 1094 */       if (cc.isConstructor()) {
/* 1095 */         n++;
/*      */       }
/*      */     } 
/* 1098 */     CtConstructor[] result = new CtConstructor[n];
/* 1099 */     int i = 0;
/* 1100 */     mem = cons;
/* 1101 */     while (mem != consTail) {
/* 1102 */       mem = mem.next();
/* 1103 */       CtConstructor cc = (CtConstructor)mem;
/* 1104 */       if (cc.isConstructor()) {
/* 1105 */         result[i++] = cc;
/*      */       }
/*      */     } 
/* 1108 */     return result;
/*      */   }
/*      */   
/*      */   public CtConstructor getClassInitializer() {
/* 1112 */     CtMember.Cache memCache = getMembers();
/* 1113 */     CtMember cons = memCache.consHead();
/* 1114 */     CtMember consTail = memCache.lastCons();
/*      */     
/* 1116 */     while (cons != consTail) {
/* 1117 */       cons = cons.next();
/* 1118 */       CtConstructor cc = (CtConstructor)cons;
/* 1119 */       if (cc.isClassInitializer()) {
/* 1120 */         return cc;
/*      */       }
/*      */     } 
/* 1123 */     return null;
/*      */   }
/*      */   
/*      */   public CtMethod[] getMethods() {
/* 1127 */     HashMap<Object, Object> h = new HashMap<Object, Object>();
/* 1128 */     getMethods0(h, this);
/* 1129 */     return (CtMethod[])h.values().toArray((Object[])new CtMethod[h.size()]);
/*      */   }
/*      */   
/*      */   private static void getMethods0(HashMap<String, CtMember> h, CtClass cc) {
/*      */     try {
/* 1134 */       CtClass[] ifs = cc.getInterfaces();
/* 1135 */       int size = ifs.length;
/* 1136 */       for (int i = 0; i < size; i++) {
/* 1137 */         getMethods0(h, ifs[i]);
/*      */       }
/* 1139 */     } catch (NotFoundException notFoundException) {}
/*      */     
/*      */     try {
/* 1142 */       CtClass s = cc.getSuperclass();
/* 1143 */       if (s != null) {
/* 1144 */         getMethods0(h, s);
/*      */       }
/* 1146 */     } catch (NotFoundException notFoundException) {}
/*      */     
/* 1148 */     if (cc instanceof CtClassType) {
/* 1149 */       CtMember.Cache memCache = ((CtClassType)cc).getMembers();
/* 1150 */       CtMember mth = memCache.methodHead();
/* 1151 */       CtMember mthTail = memCache.lastMethod();
/*      */       
/* 1153 */       while (mth != mthTail) {
/* 1154 */         mth = mth.next();
/* 1155 */         if (!Modifier.isPrivate(mth.getModifiers())) {
/* 1156 */           h.put(((CtMethod)mth).getStringRep(), mth);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public CtMethod getMethod(String name, String desc) throws NotFoundException {
/* 1164 */     CtMethod m = getMethod0(this, name, desc);
/* 1165 */     if (m != null) {
/* 1166 */       return m;
/*      */     }
/* 1168 */     throw new NotFoundException(name + "(..) is not found in " + 
/* 1169 */         getName());
/*      */   }
/*      */ 
/*      */   
/*      */   private static CtMethod getMethod0(CtClass cc, String name, String desc) {
/* 1174 */     if (cc instanceof CtClassType) {
/* 1175 */       CtMember.Cache memCache = ((CtClassType)cc).getMembers();
/* 1176 */       CtMember mth = memCache.methodHead();
/* 1177 */       CtMember mthTail = memCache.lastMethod();
/*      */       
/* 1179 */       while (mth != mthTail) {
/* 1180 */         mth = mth.next();
/* 1181 */         if (mth.getName().equals(name) && ((CtMethod)mth)
/* 1182 */           .getMethodInfo2().getDescriptor().equals(desc)) {
/* 1183 */           return (CtMethod)mth;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     try {
/* 1188 */       CtClass s = cc.getSuperclass();
/* 1189 */       if (s != null) {
/* 1190 */         CtMethod m = getMethod0(s, name, desc);
/* 1191 */         if (m != null) {
/* 1192 */           return m;
/*      */         }
/*      */       } 
/* 1195 */     } catch (NotFoundException notFoundException) {}
/*      */     
/*      */     try {
/* 1198 */       CtClass[] ifs = cc.getInterfaces();
/* 1199 */       int size = ifs.length;
/* 1200 */       for (int i = 0; i < size; i++) {
/* 1201 */         CtMethod m = getMethod0(ifs[i], name, desc);
/* 1202 */         if (m != null) {
/* 1203 */           return m;
/*      */         }
/*      */       } 
/* 1206 */     } catch (NotFoundException notFoundException) {}
/* 1207 */     return null;
/*      */   }
/*      */   
/*      */   public CtMethod[] getDeclaredMethods() {
/* 1211 */     CtMember.Cache memCache = getMembers();
/* 1212 */     CtMember mth = memCache.methodHead();
/* 1213 */     CtMember mthTail = memCache.lastMethod();
/* 1214 */     int num = CtMember.Cache.count(mth, mthTail);
/* 1215 */     CtMethod[] cms = new CtMethod[num];
/* 1216 */     int i = 0;
/* 1217 */     while (mth != mthTail) {
/* 1218 */       mth = mth.next();
/* 1219 */       cms[i++] = (CtMethod)mth;
/*      */     } 
/*      */     
/* 1222 */     return cms;
/*      */   }
/*      */   
/*      */   public CtMethod[] getDeclaredMethods(String name) throws NotFoundException {
/* 1226 */     CtMember.Cache memCache = getMembers();
/* 1227 */     CtMember mth = memCache.methodHead();
/* 1228 */     CtMember mthTail = memCache.lastMethod();
/* 1229 */     ArrayList<CtMethod> methods = new ArrayList<CtMethod>();
/* 1230 */     while (mth != mthTail) {
/* 1231 */       mth = mth.next();
/* 1232 */       if (mth.getName().equals(name)) {
/* 1233 */         methods.add((CtMethod)mth);
/*      */       }
/*      */     } 
/* 1236 */     return methods.<CtMethod>toArray(new CtMethod[methods.size()]);
/*      */   }
/*      */   
/*      */   public CtMethod getDeclaredMethod(String name) throws NotFoundException {
/* 1240 */     CtMember.Cache memCache = getMembers();
/* 1241 */     CtMember mth = memCache.methodHead();
/* 1242 */     CtMember mthTail = memCache.lastMethod();
/* 1243 */     while (mth != mthTail) {
/* 1244 */       mth = mth.next();
/* 1245 */       if (mth.getName().equals(name)) {
/* 1246 */         return (CtMethod)mth;
/*      */       }
/*      */     } 
/* 1249 */     throw new NotFoundException(name + "(..) is not found in " + 
/* 1250 */         getName());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CtMethod getDeclaredMethod(String name, CtClass[] params) throws NotFoundException {
/* 1256 */     String desc = Descriptor.ofParameters(params);
/* 1257 */     CtMember.Cache memCache = getMembers();
/* 1258 */     CtMember mth = memCache.methodHead();
/* 1259 */     CtMember mthTail = memCache.lastMethod();
/*      */     
/* 1261 */     while (mth != mthTail) {
/* 1262 */       mth = mth.next();
/* 1263 */       if (mth.getName().equals(name) && ((CtMethod)mth)
/* 1264 */         .getMethodInfo2().getDescriptor().startsWith(desc)) {
/* 1265 */         return (CtMethod)mth;
/*      */       }
/*      */     } 
/* 1268 */     throw new NotFoundException(name + "(..) is not found in " + 
/* 1269 */         getName());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addField(CtField f, String init) throws CannotCompileException {
/* 1275 */     addField(f, CtField.Initializer.byExpr(init));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addField(CtField f, CtField.Initializer init) throws CannotCompileException {
/* 1281 */     checkModify();
/* 1282 */     if (f.getDeclaringClass() != this) {
/* 1283 */       throw new CannotCompileException("cannot add");
/*      */     }
/* 1285 */     if (init == null) {
/* 1286 */       init = f.getInit();
/*      */     }
/* 1288 */     if (init != null) {
/* 1289 */       init.check(f.getSignature());
/* 1290 */       int mod = f.getModifiers();
/* 1291 */       if (Modifier.isStatic(mod) && Modifier.isFinal(mod)) {
/*      */         try {
/* 1293 */           ConstPool cp = getClassFile2().getConstPool();
/* 1294 */           int index = init.getConstantValue(cp, f.getType());
/* 1295 */           if (index != 0) {
/* 1296 */             f.getFieldInfo2().addAttribute((AttributeInfo)new ConstantAttribute(cp, index));
/* 1297 */             init = null;
/*      */           }
/*      */         
/* 1300 */         } catch (NotFoundException notFoundException) {}
/*      */       }
/*      */     } 
/* 1303 */     getMembers().addField(f);
/* 1304 */     getClassFile2().addField(f.getFieldInfo2());
/*      */     
/* 1306 */     if (init != null) {
/* 1307 */       FieldInitLink fil = new FieldInitLink(f, init);
/* 1308 */       FieldInitLink link = this.fieldInitializers;
/* 1309 */       if (link == null) {
/* 1310 */         this.fieldInitializers = fil;
/*      */       } else {
/* 1312 */         while (link.next != null) {
/* 1313 */           link = link.next;
/*      */         }
/* 1315 */         link.next = fil;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void removeField(CtField f) throws NotFoundException {
/* 1321 */     checkModify();
/* 1322 */     FieldInfo fi = f.getFieldInfo2();
/* 1323 */     ClassFile cf = getClassFile2();
/* 1324 */     if (cf.getFields().remove(fi)) {
/* 1325 */       getMembers().remove(f);
/* 1326 */       this.gcConstPool = true;
/*      */     } else {
/*      */       
/* 1329 */       throw new NotFoundException(f.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public CtConstructor makeClassInitializer() throws CannotCompileException {
/* 1335 */     CtConstructor clinit = getClassInitializer();
/* 1336 */     if (clinit != null) {
/* 1337 */       return clinit;
/*      */     }
/* 1339 */     checkModify();
/* 1340 */     ClassFile cf = getClassFile2();
/* 1341 */     Bytecode code = new Bytecode(cf.getConstPool(), 0, 0);
/* 1342 */     modifyClassConstructor(cf, code, 0, 0);
/* 1343 */     return getClassInitializer();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addConstructor(CtConstructor c) throws CannotCompileException {
/* 1349 */     checkModify();
/* 1350 */     if (c.getDeclaringClass() != this) {
/* 1351 */       throw new CannotCompileException("cannot add");
/*      */     }
/* 1353 */     getMembers().addConstructor(c);
/* 1354 */     getClassFile2().addMethod(c.getMethodInfo2());
/*      */   }
/*      */   
/*      */   public void removeConstructor(CtConstructor m) throws NotFoundException {
/* 1358 */     checkModify();
/* 1359 */     MethodInfo mi = m.getMethodInfo2();
/* 1360 */     ClassFile cf = getClassFile2();
/* 1361 */     if (cf.getMethods().remove(mi)) {
/* 1362 */       getMembers().remove(m);
/* 1363 */       this.gcConstPool = true;
/*      */     } else {
/*      */       
/* 1366 */       throw new NotFoundException(m.toString());
/*      */     } 
/*      */   }
/*      */   public void addMethod(CtMethod m) throws CannotCompileException {
/* 1370 */     checkModify();
/* 1371 */     if (m.getDeclaringClass() != this) {
/* 1372 */       throw new CannotCompileException("bad declaring class");
/*      */     }
/* 1374 */     int mod = m.getModifiers();
/* 1375 */     if ((getModifiers() & 0x200) != 0) {
/* 1376 */       m.setModifiers(mod | 0x1);
/* 1377 */       if ((mod & 0x400) == 0) {
/* 1378 */         throw new CannotCompileException("an interface method must be abstract: " + m
/* 1379 */             .toString());
/*      */       }
/*      */     } 
/* 1382 */     getMembers().addMethod(m);
/* 1383 */     getClassFile2().addMethod(m.getMethodInfo2());
/* 1384 */     if ((mod & 0x400) != 0)
/* 1385 */       setModifiers(getModifiers() | 0x400); 
/*      */   }
/*      */   
/*      */   public void removeMethod(CtMethod m) throws NotFoundException {
/* 1389 */     checkModify();
/* 1390 */     MethodInfo mi = m.getMethodInfo2();
/* 1391 */     ClassFile cf = getClassFile2();
/* 1392 */     if (cf.getMethods().remove(mi)) {
/* 1393 */       getMembers().remove(m);
/* 1394 */       this.gcConstPool = true;
/*      */     } else {
/*      */       
/* 1397 */       throw new NotFoundException(m.toString());
/*      */     } 
/*      */   }
/*      */   public byte[] getAttribute(String name) {
/* 1401 */     AttributeInfo ai = getClassFile2().getAttribute(name);
/* 1402 */     if (ai == null) {
/* 1403 */       return null;
/*      */     }
/* 1405 */     return ai.get();
/*      */   }
/*      */   
/*      */   public void setAttribute(String name, byte[] data) {
/* 1409 */     checkModify();
/* 1410 */     ClassFile cf = getClassFile2();
/* 1411 */     cf.addAttribute(new AttributeInfo(cf.getConstPool(), name, data));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void instrument(CodeConverter converter) throws CannotCompileException {
/* 1417 */     checkModify();
/* 1418 */     ClassFile cf = getClassFile2();
/* 1419 */     ConstPool cp = cf.getConstPool();
/* 1420 */     List<MethodInfo> list = cf.getMethods();
/* 1421 */     int n = list.size();
/* 1422 */     for (int i = 0; i < n; i++) {
/* 1423 */       MethodInfo minfo = list.get(i);
/* 1424 */       converter.doit(this, minfo, cp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void instrument(ExprEditor editor) throws CannotCompileException {
/* 1431 */     checkModify();
/* 1432 */     ClassFile cf = getClassFile2();
/* 1433 */     List<MethodInfo> list = cf.getMethods();
/* 1434 */     int n = list.size();
/* 1435 */     for (int i = 0; i < n; i++) {
/* 1436 */       MethodInfo minfo = list.get(i);
/* 1437 */       editor.doit(this, minfo);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void prune() {
/* 1446 */     if (this.wasPruned) {
/*      */       return;
/*      */     }
/* 1449 */     this.wasPruned = this.wasFrozen = true;
/* 1450 */     getClassFile2().prune();
/*      */   }
/*      */   public void rebuildClassFile() {
/* 1453 */     this.gcConstPool = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void toBytecode(DataOutputStream out) throws CannotCompileException, IOException {
/*      */     try {
/* 1459 */       if (isModified()) {
/* 1460 */         checkPruned("toBytecode");
/* 1461 */         ClassFile cf = getClassFile2();
/* 1462 */         if (this.gcConstPool) {
/* 1463 */           cf.compact();
/* 1464 */           this.gcConstPool = false;
/*      */         } 
/*      */         
/* 1467 */         modifyClassConstructor(cf);
/* 1468 */         modifyConstructors(cf);
/* 1469 */         if (debugDump != null) {
/* 1470 */           dumpClassFile(cf);
/*      */         }
/* 1472 */         cf.write(out);
/* 1473 */         out.flush();
/* 1474 */         this.fieldInitializers = null;
/* 1475 */         if (this.doPruning) {
/*      */           
/* 1477 */           cf.prune();
/* 1478 */           this.wasPruned = true;
/*      */         } 
/*      */       } else {
/*      */         
/* 1482 */         this.classPool.writeClassfile(getName(), out);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1487 */       this.getCount = 0;
/* 1488 */       this.wasFrozen = true;
/*      */     }
/* 1490 */     catch (NotFoundException e) {
/* 1491 */       throw new CannotCompileException(e);
/*      */     }
/* 1493 */     catch (IOException e) {
/* 1494 */       throw new CannotCompileException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void dumpClassFile(ClassFile cf) throws IOException {
/* 1499 */     DataOutputStream dump = makeFileOutput(debugDump);
/*      */     try {
/* 1501 */       cf.write(dump);
/*      */     } finally {
/*      */       
/* 1504 */       dump.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkPruned(String method) {
/* 1511 */     if (this.wasPruned) {
/* 1512 */       throw new RuntimeException(method + "(): " + getName() + " was pruned.");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean stopPruning(boolean stop) {
/* 1517 */     boolean prev = !this.doPruning;
/* 1518 */     this.doPruning = !stop;
/* 1519 */     return prev;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void modifyClassConstructor(ClassFile cf) throws CannotCompileException, NotFoundException {
/* 1525 */     if (this.fieldInitializers == null) {
/*      */       return;
/*      */     }
/* 1528 */     Bytecode code = new Bytecode(cf.getConstPool(), 0, 0);
/* 1529 */     Javac jv = new Javac(code, this);
/* 1530 */     int stacksize = 0;
/* 1531 */     boolean doInit = false;
/* 1532 */     for (FieldInitLink fi = this.fieldInitializers; fi != null; fi = fi.next) {
/* 1533 */       CtField f = fi.field;
/* 1534 */       if (Modifier.isStatic(f.getModifiers())) {
/* 1535 */         doInit = true;
/* 1536 */         int s = fi.init.compileIfStatic(f.getType(), f.getName(), code, jv);
/*      */         
/* 1538 */         if (stacksize < s) {
/* 1539 */           stacksize = s;
/*      */         }
/*      */       } 
/*      */     } 
/* 1543 */     if (doInit) {
/* 1544 */       modifyClassConstructor(cf, code, stacksize, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void modifyClassConstructor(ClassFile cf, Bytecode code, int stacksize, int localsize) throws CannotCompileException {
/* 1551 */     MethodInfo m = cf.getStaticInitializer();
/* 1552 */     if (m == null) {
/* 1553 */       code.add(177);
/* 1554 */       code.setMaxStack(stacksize);
/* 1555 */       code.setMaxLocals(localsize);
/* 1556 */       m = new MethodInfo(cf.getConstPool(), "<clinit>", "()V");
/* 1557 */       m.setAccessFlags(8);
/* 1558 */       m.setCodeAttribute(code.toCodeAttribute());
/* 1559 */       cf.addMethod(m);
/* 1560 */       CtMember.Cache cache = hasMemberCache();
/* 1561 */       if (cache != null) {
/* 1562 */         cache.addConstructor(new CtConstructor(m, this));
/*      */       }
/*      */     } else {
/* 1565 */       CodeAttribute codeAttr = m.getCodeAttribute();
/* 1566 */       if (codeAttr == null) {
/* 1567 */         throw new CannotCompileException("empty <clinit>");
/*      */       }
/*      */       try {
/* 1570 */         CodeIterator it = codeAttr.iterator();
/* 1571 */         int pos = it.insertEx(code.get());
/* 1572 */         it.insert(code.getExceptionTable(), pos);
/* 1573 */         int maxstack = codeAttr.getMaxStack();
/* 1574 */         if (maxstack < stacksize) {
/* 1575 */           codeAttr.setMaxStack(stacksize);
/*      */         }
/* 1577 */         int maxlocals = codeAttr.getMaxLocals();
/* 1578 */         if (maxlocals < localsize) {
/* 1579 */           codeAttr.setMaxLocals(localsize);
/*      */         }
/* 1581 */       } catch (BadBytecode e) {
/* 1582 */         throw new CannotCompileException(e);
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/* 1587 */       m.rebuildStackMapIf6(this.classPool, cf);
/*      */     }
/* 1589 */     catch (BadBytecode e) {
/* 1590 */       throw new CannotCompileException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void modifyConstructors(ClassFile cf) throws CannotCompileException, NotFoundException {
/* 1597 */     if (this.fieldInitializers == null) {
/*      */       return;
/*      */     }
/* 1600 */     ConstPool cp = cf.getConstPool();
/* 1601 */     List<MethodInfo> list = cf.getMethods();
/* 1602 */     int n = list.size();
/* 1603 */     for (int i = 0; i < n; i++) {
/* 1604 */       MethodInfo minfo = list.get(i);
/* 1605 */       if (minfo.isConstructor()) {
/* 1606 */         CodeAttribute codeAttr = minfo.getCodeAttribute();
/* 1607 */         if (codeAttr != null) {
/*      */           
/*      */           try {
/* 1610 */             Bytecode init = new Bytecode(cp, 0, codeAttr.getMaxLocals());
/*      */             
/* 1612 */             CtClass[] params = Descriptor.getParameterTypes(minfo
/* 1613 */                 .getDescriptor(), this.classPool);
/*      */             
/* 1615 */             int stacksize = makeFieldInitializer(init, params);
/* 1616 */             insertAuxInitializer(codeAttr, init, stacksize);
/* 1617 */             minfo.rebuildStackMapIf6(this.classPool, cf);
/*      */           }
/* 1619 */           catch (BadBytecode e) {
/* 1620 */             throw new CannotCompileException(e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void insertAuxInitializer(CodeAttribute codeAttr, Bytecode initializer, int stacksize) throws BadBytecode {
/* 1631 */     CodeIterator it = codeAttr.iterator();
/* 1632 */     int index = it.skipSuperConstructor();
/* 1633 */     if (index < 0) {
/* 1634 */       index = it.skipThisConstructor();
/* 1635 */       if (index >= 0) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1641 */     int pos = it.insertEx(initializer.get());
/* 1642 */     it.insert(initializer.getExceptionTable(), pos);
/* 1643 */     int maxstack = codeAttr.getMaxStack();
/* 1644 */     if (maxstack < stacksize) {
/* 1645 */       codeAttr.setMaxStack(stacksize);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int makeFieldInitializer(Bytecode code, CtClass[] parameters) throws CannotCompileException, NotFoundException {
/* 1651 */     int stacksize = 0;
/* 1652 */     Javac jv = new Javac(code, this);
/*      */     try {
/* 1654 */       jv.recordParams(parameters, false);
/*      */     }
/* 1656 */     catch (CompileError e) {
/* 1657 */       throw new CannotCompileException(e);
/*      */     } 
/*      */     
/* 1660 */     for (FieldInitLink fi = this.fieldInitializers; fi != null; fi = fi.next) {
/* 1661 */       CtField f = fi.field;
/* 1662 */       if (!Modifier.isStatic(f.getModifiers())) {
/* 1663 */         int s = fi.init.compile(f.getType(), f.getName(), code, parameters, jv);
/*      */         
/* 1665 */         if (stacksize < s) {
/* 1666 */           stacksize = s;
/*      */         }
/*      */       } 
/*      */     } 
/* 1670 */     return stacksize;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable getHiddenMethods() {
/* 1676 */     if (this.hiddenMethods == null) {
/* 1677 */       this.hiddenMethods = new Hashtable<Object, Object>();
/*      */     }
/* 1679 */     return this.hiddenMethods;
/*      */   }
/*      */   int getUniqueNumber() {
/* 1682 */     return this.uniqueNumberSeed++;
/*      */   }
/*      */   public String makeUniqueName(String prefix) {
/* 1685 */     HashMap<Object, Object> table = new HashMap<Object, Object>();
/* 1686 */     makeMemberList(table);
/* 1687 */     Set keys = table.keySet();
/* 1688 */     String[] methods = new String[keys.size()];
/* 1689 */     keys.toArray((Object[])methods);
/*      */     
/* 1691 */     if (notFindInArray(prefix, methods)) {
/* 1692 */       return prefix;
/*      */     }
/* 1694 */     int i = 100;
/*      */     
/*      */     while (true) {
/* 1697 */       if (i > 999) {
/* 1698 */         throw new RuntimeException("too many unique name");
/*      */       }
/* 1700 */       String name = prefix + i++;
/* 1701 */       if (notFindInArray(name, methods))
/* 1702 */         return name; 
/*      */     } 
/*      */   }
/*      */   private static boolean notFindInArray(String prefix, String[] values) {
/* 1706 */     int len = values.length;
/* 1707 */     for (int i = 0; i < len; i++) {
/* 1708 */       if (values[i].startsWith(prefix))
/* 1709 */         return false; 
/*      */     } 
/* 1711 */     return true;
/*      */   }
/*      */   
/*      */   private void makeMemberList(HashMap<String, CtClassType> table) {
/* 1715 */     int mod = getModifiers();
/* 1716 */     if (Modifier.isAbstract(mod) || Modifier.isInterface(mod)) {
/*      */       try {
/* 1718 */         CtClass[] ifs = getInterfaces();
/* 1719 */         int size = ifs.length;
/* 1720 */         for (int j = 0; j < size; j++) {
/* 1721 */           CtClass ic = ifs[j];
/* 1722 */           if (ic != null && ic instanceof CtClassType) {
/* 1723 */             ((CtClassType)ic).makeMemberList(table);
/*      */           }
/*      */         } 
/* 1726 */       } catch (NotFoundException notFoundException) {}
/*      */     }
/*      */     try {
/* 1729 */       CtClass s = getSuperclass();
/* 1730 */       if (s != null && s instanceof CtClassType) {
/* 1731 */         ((CtClassType)s).makeMemberList(table);
/*      */       }
/* 1733 */     } catch (NotFoundException notFoundException) {}
/*      */     
/* 1735 */     List<MethodInfo> list = getClassFile2().getMethods();
/* 1736 */     int n = list.size(); int i;
/* 1737 */     for (i = 0; i < n; i++) {
/* 1738 */       MethodInfo minfo = list.get(i);
/* 1739 */       table.put(minfo.getName(), this);
/*      */     } 
/*      */     
/* 1742 */     list = getClassFile2().getFields();
/* 1743 */     n = list.size();
/* 1744 */     for (i = 0; i < n; i++) {
/* 1745 */       FieldInfo finfo = (FieldInfo)list.get(i);
/* 1746 */       table.put(finfo.getName(), this);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\CtClassType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */