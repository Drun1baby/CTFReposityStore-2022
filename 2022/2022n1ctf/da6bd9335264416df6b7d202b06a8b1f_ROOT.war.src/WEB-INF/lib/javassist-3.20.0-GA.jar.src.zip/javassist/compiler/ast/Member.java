/*    */ package javassist.compiler.ast;
/*    */ 
/*    */ import javassist.CtField;
/*    */ import javassist.compiler.CompileError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Member
/*    */   extends Symbol
/*    */ {
/*    */   private CtField field;
/*    */   
/*    */   public Member(String name) {
/* 31 */     super(name);
/* 32 */     this.field = null;
/*    */   }
/*    */   public void setField(CtField f) {
/* 35 */     this.field = f;
/*    */   } public CtField getField() {
/* 37 */     return this.field;
/*    */   } public void accept(Visitor v) throws CompileError {
/* 39 */     v.atMember(this);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\compiler\ast\Member.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */