/*    */ package javassist.compiler.ast;
/*    */ 
/*    */ import javassist.compiler.CompileError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayInit
/*    */   extends ASTList
/*    */ {
/*    */   public ArrayInit(ASTree firstElement) {
/* 26 */     super(firstElement);
/*    */   }
/*    */   public void accept(Visitor v) throws CompileError {
/* 29 */     v.atArrayInit(this);
/*    */   } public String getTag() {
/* 31 */     return "array";
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\compiler\ast\ArrayInit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */