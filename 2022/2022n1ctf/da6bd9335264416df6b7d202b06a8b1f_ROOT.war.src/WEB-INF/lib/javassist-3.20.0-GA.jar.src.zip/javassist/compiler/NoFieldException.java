/*    */ package javassist.compiler;
/*    */ 
/*    */ import javassist.compiler.ast.ASTree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoFieldException
/*    */   extends CompileError
/*    */ {
/*    */   private String fieldName;
/*    */   private ASTree expr;
/*    */   
/*    */   public NoFieldException(String name, ASTree e) {
/* 28 */     super("no such field: " + name);
/* 29 */     this.fieldName = name;
/* 30 */     this.expr = e;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getField() {
/* 35 */     return this.fieldName;
/*    */   }
/*    */   
/*    */   public ASTree getExpr() {
/* 39 */     return this.expr;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\compiler\NoFieldException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */