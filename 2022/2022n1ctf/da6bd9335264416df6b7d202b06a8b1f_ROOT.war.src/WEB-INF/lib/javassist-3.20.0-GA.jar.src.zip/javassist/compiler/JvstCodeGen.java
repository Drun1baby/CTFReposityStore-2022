/*     */ package javassist.compiler;
/*     */ 
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtPrimitiveType;
/*     */ import javassist.NotFoundException;
/*     */ import javassist.bytecode.Bytecode;
/*     */ import javassist.bytecode.Descriptor;
/*     */ import javassist.compiler.ast.ASTList;
/*     */ import javassist.compiler.ast.ASTree;
/*     */ import javassist.compiler.ast.CallExpr;
/*     */ import javassist.compiler.ast.CastExpr;
/*     */ import javassist.compiler.ast.Declarator;
/*     */ import javassist.compiler.ast.Expr;
/*     */ import javassist.compiler.ast.Member;
/*     */ import javassist.compiler.ast.Stmnt;
/*     */ import javassist.compiler.ast.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JvstCodeGen
/*     */   extends MemberCodeGen
/*     */ {
/*  27 */   String paramArrayName = null;
/*  28 */   String paramListName = null;
/*  29 */   CtClass[] paramTypeList = null;
/*  30 */   private int paramVarBase = 0;
/*     */   private boolean useParam0 = false;
/*  32 */   private String param0Type = null;
/*     */   public static final String sigName = "$sig";
/*     */   public static final String dollarTypeName = "$type";
/*     */   public static final String clazzName = "$class";
/*  36 */   private CtClass dollarType = null;
/*  37 */   CtClass returnType = null;
/*  38 */   String returnCastName = null;
/*  39 */   private String returnVarName = null;
/*     */   public static final String wrapperCastName = "$w";
/*  41 */   String proceedName = null;
/*     */   public static final String cflowName = "$cflow";
/*  43 */   ProceedHandler procHandler = null;
/*     */   
/*     */   public JvstCodeGen(Bytecode b, CtClass cc, ClassPool cp) {
/*  46 */     super(b, cc, cp);
/*  47 */     setTypeChecker(new JvstTypeChecker(cc, cp, this));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOfParam1() {
/*  53 */     return this.paramVarBase + (this.useParam0 ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProceedHandler(ProceedHandler h, String name) {
/*  62 */     this.proceedName = name;
/*  63 */     this.procHandler = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNullIfVoid() {
/*  70 */     if (this.exprType == 344) {
/*  71 */       this.bytecode.addOpcode(1);
/*  72 */       this.exprType = 307;
/*  73 */       this.arrayDim = 0;
/*  74 */       this.className = "java/lang/Object";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void atMember(Member mem) throws CompileError {
/*  82 */     String name = mem.get();
/*  83 */     if (name.equals(this.paramArrayName)) {
/*  84 */       compileParameterList(this.bytecode, this.paramTypeList, indexOfParam1());
/*  85 */       this.exprType = 307;
/*  86 */       this.arrayDim = 1;
/*  87 */       this.className = "java/lang/Object";
/*     */     }
/*  89 */     else if (name.equals("$sig")) {
/*  90 */       this.bytecode.addLdc(Descriptor.ofMethod(this.returnType, this.paramTypeList));
/*  91 */       this.bytecode.addInvokestatic("javassist/runtime/Desc", "getParams", "(Ljava/lang/String;)[Ljava/lang/Class;");
/*     */       
/*  93 */       this.exprType = 307;
/*  94 */       this.arrayDim = 1;
/*  95 */       this.className = "java/lang/Class";
/*     */     }
/*  97 */     else if (name.equals("$type")) {
/*  98 */       if (this.dollarType == null) {
/*  99 */         throw new CompileError("$type is not available");
/*     */       }
/* 101 */       this.bytecode.addLdc(Descriptor.of(this.dollarType));
/* 102 */       callGetType("getType");
/*     */     }
/* 104 */     else if (name.equals("$class")) {
/* 105 */       if (this.param0Type == null) {
/* 106 */         throw new CompileError("$class is not available");
/*     */       }
/* 108 */       this.bytecode.addLdc(this.param0Type);
/* 109 */       callGetType("getClazz");
/*     */     } else {
/*     */       
/* 112 */       super.atMember(mem);
/*     */     } 
/*     */   }
/*     */   private void callGetType(String method) {
/* 116 */     this.bytecode.addInvokestatic("javassist/runtime/Desc", method, "(Ljava/lang/String;)Ljava/lang/Class;");
/*     */     
/* 118 */     this.exprType = 307;
/* 119 */     this.arrayDim = 0;
/* 120 */     this.className = "java/lang/Class";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void atFieldAssign(Expr expr, int op, ASTree left, ASTree right, boolean doDup) throws CompileError {
/* 126 */     if (left instanceof Member && ((Member)left)
/* 127 */       .get().equals(this.paramArrayName)) {
/* 128 */       if (op != 61) {
/* 129 */         throw new CompileError("bad operator for " + this.paramArrayName);
/*     */       }
/* 131 */       right.accept(this);
/* 132 */       if (this.arrayDim != 1 || this.exprType != 307) {
/* 133 */         throw new CompileError("invalid type for " + this.paramArrayName);
/*     */       }
/* 135 */       atAssignParamList(this.paramTypeList, this.bytecode);
/* 136 */       if (!doDup) {
/* 137 */         this.bytecode.addOpcode(87);
/*     */       }
/*     */     } else {
/* 140 */       super.atFieldAssign(expr, op, left, right, doDup);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void atAssignParamList(CtClass[] params, Bytecode code) throws CompileError {
/* 146 */     if (params == null) {
/*     */       return;
/*     */     }
/* 149 */     int varNo = indexOfParam1();
/* 150 */     int n = params.length;
/* 151 */     for (int i = 0; i < n; i++) {
/* 152 */       code.addOpcode(89);
/* 153 */       code.addIconst(i);
/* 154 */       code.addOpcode(50);
/* 155 */       compileUnwrapValue(params[i], code);
/* 156 */       code.addStore(varNo, params[i]);
/* 157 */       varNo += is2word(this.exprType, this.arrayDim) ? 2 : 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void atCastExpr(CastExpr expr) throws CompileError {
/* 162 */     ASTList classname = expr.getClassName();
/* 163 */     if (classname != null && expr.getArrayDim() == 0) {
/* 164 */       ASTree p = classname.head();
/* 165 */       if (p instanceof Symbol && classname.tail() == null) {
/* 166 */         String typename = ((Symbol)p).get();
/* 167 */         if (typename.equals(this.returnCastName)) {
/* 168 */           atCastToRtype(expr);
/*     */           return;
/*     */         } 
/* 171 */         if (typename.equals("$w")) {
/* 172 */           atCastToWrapper(expr);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 178 */     super.atCastExpr(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void atCastToRtype(CastExpr expr) throws CompileError {
/* 186 */     expr.getOprand().accept(this);
/* 187 */     if (this.exprType == 344 || isRefType(this.exprType) || this.arrayDim > 0) {
/* 188 */       compileUnwrapValue(this.returnType, this.bytecode);
/* 189 */     } else if (this.returnType instanceof CtPrimitiveType) {
/* 190 */       CtPrimitiveType pt = (CtPrimitiveType)this.returnType;
/* 191 */       int destType = MemberResolver.descToType(pt.getDescriptor());
/* 192 */       atNumCastExpr(this.exprType, destType);
/* 193 */       this.exprType = destType;
/* 194 */       this.arrayDim = 0;
/* 195 */       this.className = null;
/*     */     } else {
/*     */       
/* 198 */       throw new CompileError("invalid cast");
/*     */     } 
/*     */   }
/*     */   protected void atCastToWrapper(CastExpr expr) throws CompileError {
/* 202 */     expr.getOprand().accept(this);
/* 203 */     if (isRefType(this.exprType) || this.arrayDim > 0) {
/*     */       return;
/*     */     }
/* 206 */     CtClass clazz = this.resolver.lookupClass(this.exprType, this.arrayDim, this.className);
/* 207 */     if (clazz instanceof CtPrimitiveType) {
/* 208 */       CtPrimitiveType pt = (CtPrimitiveType)clazz;
/* 209 */       String wrapper = pt.getWrapperName();
/* 210 */       this.bytecode.addNew(wrapper);
/* 211 */       this.bytecode.addOpcode(89);
/* 212 */       if (pt.getDataSize() > 1) {
/* 213 */         this.bytecode.addOpcode(94);
/*     */       } else {
/* 215 */         this.bytecode.addOpcode(93);
/*     */       } 
/* 217 */       this.bytecode.addOpcode(88);
/* 218 */       this.bytecode.addInvokespecial(wrapper, "<init>", "(" + pt
/* 219 */           .getDescriptor() + ")V");
/*     */       
/* 221 */       this.exprType = 307;
/* 222 */       this.arrayDim = 0;
/* 223 */       this.className = "java/lang/Object";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void atCallExpr(CallExpr expr) throws CompileError {
/* 231 */     ASTree method = expr.oprand1();
/* 232 */     if (method instanceof Member) {
/* 233 */       String name = ((Member)method).get();
/* 234 */       if (this.procHandler != null && name.equals(this.proceedName)) {
/* 235 */         this.procHandler.doit(this, this.bytecode, (ASTList)expr.oprand2());
/*     */         return;
/*     */       } 
/* 238 */       if (name.equals("$cflow")) {
/* 239 */         atCflow((ASTList)expr.oprand2());
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 244 */     super.atCallExpr(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void atCflow(ASTList cname) throws CompileError {
/* 250 */     StringBuffer sbuf = new StringBuffer();
/* 251 */     if (cname == null || cname.tail() != null) {
/* 252 */       throw new CompileError("bad $cflow");
/*     */     }
/* 254 */     makeCflowName(sbuf, cname.head());
/* 255 */     String name = sbuf.toString();
/* 256 */     Object[] names = this.resolver.getClassPool().lookupCflow(name);
/* 257 */     if (names == null) {
/* 258 */       throw new CompileError("no such $cflow: " + name);
/*     */     }
/* 260 */     this.bytecode.addGetstatic((String)names[0], (String)names[1], "Ljavassist/runtime/Cflow;");
/*     */     
/* 262 */     this.bytecode.addInvokevirtual("javassist.runtime.Cflow", "value", "()I");
/*     */     
/* 264 */     this.exprType = 324;
/* 265 */     this.arrayDim = 0;
/* 266 */     this.className = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void makeCflowName(StringBuffer sbuf, ASTree name) throws CompileError {
/* 277 */     if (name instanceof Symbol) {
/* 278 */       sbuf.append(((Symbol)name).get());
/*     */       return;
/*     */     } 
/* 281 */     if (name instanceof Expr) {
/* 282 */       Expr expr = (Expr)name;
/* 283 */       if (expr.getOperator() == 46) {
/* 284 */         makeCflowName(sbuf, expr.oprand1());
/* 285 */         sbuf.append('.');
/* 286 */         makeCflowName(sbuf, expr.oprand2());
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 291 */     throw new CompileError("bad $cflow");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParamListName(ASTList args) {
/* 298 */     if (this.paramTypeList != null && args != null && args
/* 299 */       .tail() == null) {
/* 300 */       ASTree left = args.head();
/* 301 */       return (left instanceof Member && ((Member)left)
/* 302 */         .get().equals(this.paramListName));
/*     */     } 
/*     */     
/* 305 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMethodArgsLength(ASTList args) {
/* 318 */     String pname = this.paramListName;
/* 319 */     int n = 0;
/* 320 */     while (args != null) {
/* 321 */       ASTree a = args.head();
/* 322 */       if (a instanceof Member && ((Member)a).get().equals(pname)) {
/* 323 */         if (this.paramTypeList != null) {
/* 324 */           n += this.paramTypeList.length;
/*     */         }
/*     */       } else {
/* 327 */         n++;
/*     */       } 
/* 329 */       args = args.tail();
/*     */     } 
/*     */     
/* 332 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public void atMethodArgs(ASTList args, int[] types, int[] dims, String[] cnames) throws CompileError {
/* 337 */     CtClass[] params = this.paramTypeList;
/* 338 */     String pname = this.paramListName;
/* 339 */     int i = 0;
/* 340 */     while (args != null) {
/* 341 */       ASTree a = args.head();
/* 342 */       if (a instanceof Member && ((Member)a).get().equals(pname)) {
/* 343 */         if (params != null) {
/* 344 */           int n = params.length;
/* 345 */           int regno = indexOfParam1();
/* 346 */           for (int k = 0; k < n; k++) {
/* 347 */             CtClass p = params[k];
/* 348 */             regno += this.bytecode.addLoad(regno, p);
/* 349 */             setType(p);
/* 350 */             types[i] = this.exprType;
/* 351 */             dims[i] = this.arrayDim;
/* 352 */             cnames[i] = this.className;
/* 353 */             i++;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 358 */         a.accept(this);
/* 359 */         types[i] = this.exprType;
/* 360 */         dims[i] = this.arrayDim;
/* 361 */         cnames[i] = this.className;
/* 362 */         i++;
/*     */       } 
/*     */       
/* 365 */       args = args.tail();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void compileInvokeSpecial(ASTree target, String classname, String methodname, String descriptor, ASTList args) throws CompileError {
/* 401 */     target.accept(this);
/* 402 */     int nargs = getMethodArgsLength(args);
/* 403 */     atMethodArgs(args, new int[nargs], new int[nargs], new String[nargs]);
/*     */     
/* 405 */     this.bytecode.addInvokespecial(classname, methodname, descriptor);
/* 406 */     setReturnType(descriptor, false, false);
/* 407 */     addNullIfVoid();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void atReturnStmnt(Stmnt st) throws CompileError {
/* 414 */     ASTree result = st.getLeft();
/* 415 */     if (result != null && this.returnType == CtClass.voidType) {
/* 416 */       compileExpr(result);
/* 417 */       if (is2word(this.exprType, this.arrayDim)) {
/* 418 */         this.bytecode.addOpcode(88);
/* 419 */       } else if (this.exprType != 344) {
/* 420 */         this.bytecode.addOpcode(87);
/*     */       } 
/* 422 */       result = null;
/*     */     } 
/*     */     
/* 425 */     atReturnStmnt2(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int recordReturnType(CtClass type, String castName, String resultName, SymbolTable tbl) throws CompileError {
/* 441 */     this.returnType = type;
/* 442 */     this.returnCastName = castName;
/* 443 */     this.returnVarName = resultName;
/* 444 */     if (resultName == null) {
/* 445 */       return -1;
/*     */     }
/* 447 */     int varNo = getMaxLocals();
/* 448 */     int locals = varNo + recordVar(type, resultName, varNo, tbl);
/* 449 */     setMaxLocals(locals);
/* 450 */     return varNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordType(CtClass t) {
/* 458 */     this.dollarType = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int recordParams(CtClass[] params, boolean isStatic, String prefix, String paramVarName, String paramsName, SymbolTable tbl) throws CompileError {
/* 471 */     return recordParams(params, isStatic, prefix, paramVarName, paramsName, !isStatic, 0, 
/* 472 */         getThisName(), tbl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int recordParams(CtClass[] params, boolean isStatic, String prefix, String paramVarName, String paramsName, boolean use0, int paramBase, String target, SymbolTable tbl) throws CompileError {
/* 502 */     this.paramTypeList = params;
/* 503 */     this.paramArrayName = paramVarName;
/* 504 */     this.paramListName = paramsName;
/* 505 */     this.paramVarBase = paramBase;
/* 506 */     this.useParam0 = use0;
/*     */     
/* 508 */     if (target != null) {
/* 509 */       this.param0Type = MemberResolver.jvmToJavaName(target);
/*     */     }
/* 511 */     this.inStaticMethod = isStatic;
/* 512 */     int varNo = paramBase;
/* 513 */     if (use0) {
/* 514 */       String varName = prefix + "0";
/*     */       
/* 516 */       Declarator decl = new Declarator(307, MemberResolver.javaToJvmName(target), 0, varNo++, new Symbol(varName));
/*     */       
/* 518 */       tbl.append(varName, decl);
/*     */     } 
/*     */     
/* 521 */     for (int i = 0; i < params.length; i++) {
/* 522 */       varNo += recordVar(params[i], prefix + (i + 1), varNo, tbl);
/*     */     }
/* 524 */     if (getMaxLocals() < varNo) {
/* 525 */       setMaxLocals(varNo);
/*     */     }
/* 527 */     return varNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int recordVariable(CtClass type, String varName, SymbolTable tbl) throws CompileError {
/* 539 */     if (varName == null) {
/* 540 */       return -1;
/*     */     }
/* 542 */     int varNo = getMaxLocals();
/* 543 */     int locals = varNo + recordVar(type, varName, varNo, tbl);
/* 544 */     setMaxLocals(locals);
/* 545 */     return varNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int recordVar(CtClass cc, String varName, int varNo, SymbolTable tbl) throws CompileError {
/* 552 */     if (cc == CtClass.voidType) {
/* 553 */       this.exprType = 307;
/* 554 */       this.arrayDim = 0;
/* 555 */       this.className = "java/lang/Object";
/*     */     } else {
/*     */       
/* 558 */       setType(cc);
/*     */     } 
/* 560 */     Declarator decl = new Declarator(this.exprType, this.className, this.arrayDim, varNo, new Symbol(varName));
/*     */ 
/*     */     
/* 563 */     tbl.append(varName, decl);
/* 564 */     return is2word(this.exprType, this.arrayDim) ? 2 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordVariable(String typeDesc, String varName, int varNo, SymbolTable tbl) throws CompileError {
/* 578 */     int dim = 0; char c;
/* 579 */     while ((c = typeDesc.charAt(dim)) == '[') {
/* 580 */       dim++;
/*     */     }
/* 582 */     int type = MemberResolver.descToType(c);
/* 583 */     String cname = null;
/* 584 */     if (type == 307) {
/* 585 */       if (dim == 0) {
/* 586 */         cname = typeDesc.substring(1, typeDesc.length() - 1);
/*     */       } else {
/* 588 */         cname = typeDesc.substring(dim + 1, typeDesc.length() - 1);
/*     */       } 
/*     */     }
/* 591 */     Declarator decl = new Declarator(type, cname, dim, varNo, new Symbol(varName));
/*     */     
/* 593 */     tbl.append(varName, decl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compileParameterList(Bytecode code, CtClass[] params, int regno) {
/* 607 */     if (params == null) {
/* 608 */       code.addIconst(0);
/* 609 */       code.addAnewarray("java.lang.Object");
/* 610 */       return 1;
/*     */     } 
/*     */     
/* 613 */     CtClass[] args = new CtClass[1];
/* 614 */     int n = params.length;
/* 615 */     code.addIconst(n);
/* 616 */     code.addAnewarray("java.lang.Object");
/* 617 */     for (int i = 0; i < n; i++) {
/* 618 */       code.addOpcode(89);
/* 619 */       code.addIconst(i);
/* 620 */       if (params[i].isPrimitive()) {
/* 621 */         CtPrimitiveType pt = (CtPrimitiveType)params[i];
/* 622 */         String wrapper = pt.getWrapperName();
/* 623 */         code.addNew(wrapper);
/* 624 */         code.addOpcode(89);
/* 625 */         int s = code.addLoad(regno, (CtClass)pt);
/* 626 */         regno += s;
/* 627 */         args[0] = (CtClass)pt;
/* 628 */         code.addInvokespecial(wrapper, "<init>", 
/* 629 */             Descriptor.ofMethod(CtClass.voidType, args));
/*     */       }
/*     */       else {
/*     */         
/* 633 */         code.addAload(regno);
/* 634 */         regno++;
/*     */       } 
/*     */       
/* 637 */       code.addOpcode(83);
/*     */     } 
/*     */     
/* 640 */     return 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compileUnwrapValue(CtClass type, Bytecode code) throws CompileError {
/* 647 */     if (type == CtClass.voidType) {
/* 648 */       addNullIfVoid();
/*     */       
/*     */       return;
/*     */     } 
/* 652 */     if (this.exprType == 344) {
/* 653 */       throw new CompileError("invalid type for " + this.returnCastName);
/*     */     }
/* 655 */     if (type instanceof CtPrimitiveType) {
/* 656 */       CtPrimitiveType pt = (CtPrimitiveType)type;
/*     */       
/* 658 */       String wrapper = pt.getWrapperName();
/* 659 */       code.addCheckcast(wrapper);
/* 660 */       code.addInvokevirtual(wrapper, pt.getGetMethodName(), pt
/* 661 */           .getGetMethodDescriptor());
/* 662 */       setType(type);
/*     */     } else {
/*     */       
/* 665 */       code.addCheckcast(type);
/* 666 */       setType(type);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(CtClass type) throws CompileError {
/* 674 */     setType(type, 0);
/*     */   }
/*     */   
/*     */   private void setType(CtClass type, int dim) throws CompileError {
/* 678 */     if (type.isPrimitive()) {
/* 679 */       CtPrimitiveType pt = (CtPrimitiveType)type;
/* 680 */       this.exprType = MemberResolver.descToType(pt.getDescriptor());
/* 681 */       this.arrayDim = dim;
/* 682 */       this.className = null;
/*     */     }
/* 684 */     else if (type.isArray()) {
/*     */       try {
/* 686 */         setType(type.getComponentType(), dim + 1);
/*     */       }
/* 688 */       catch (NotFoundException e) {
/* 689 */         throw new CompileError("undefined type: " + type.getName());
/*     */       } 
/*     */     } else {
/* 692 */       this.exprType = 307;
/* 693 */       this.arrayDim = dim;
/* 694 */       this.className = MemberResolver.javaToJvmName(type.getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doNumCast(CtClass type) throws CompileError {
/* 701 */     if (this.arrayDim == 0 && !isRefType(this.exprType))
/* 702 */       if (type instanceof CtPrimitiveType) {
/* 703 */         CtPrimitiveType pt = (CtPrimitiveType)type;
/* 704 */         atNumCastExpr(this.exprType, 
/* 705 */             MemberResolver.descToType(pt.getDescriptor()));
/*     */       } else {
/*     */         
/* 708 */         throw new CompileError("type mismatch");
/*     */       }  
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\compiler\JvstCodeGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */