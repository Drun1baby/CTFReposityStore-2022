/*    */ package javassist.compiler.ast;
/*    */ 
/*    */ import javassist.compiler.CompileError;
/*    */ import javassist.compiler.MemberResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallExpr
/*    */   extends Expr
/*    */ {
/*    */   private MemberResolver.Method method;
/*    */   
/*    */   private CallExpr(ASTree _head, ASTList _tail) {
/* 30 */     super(67, _head, _tail);
/* 31 */     this.method = null;
/*    */   }
/*    */   
/*    */   public void setMethod(MemberResolver.Method m) {
/* 35 */     this.method = m;
/*    */   }
/*    */   
/*    */   public MemberResolver.Method getMethod() {
/* 39 */     return this.method;
/*    */   }
/*    */   
/*    */   public static CallExpr makeCall(ASTree target, ASTree args) {
/* 43 */     return new CallExpr(target, new ASTList(args));
/*    */   }
/*    */   public void accept(Visitor v) throws CompileError {
/* 46 */     v.atCallExpr(this);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\compiler\ast\CallExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */