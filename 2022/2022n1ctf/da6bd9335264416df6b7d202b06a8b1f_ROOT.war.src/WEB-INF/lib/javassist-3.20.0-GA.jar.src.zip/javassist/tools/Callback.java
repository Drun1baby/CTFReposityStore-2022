/*     */ package javassist.tools;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.UUID;
/*     */ import javassist.CannotCompileException;
/*     */ import javassist.CtBehavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Callback
/*     */ {
/*  51 */   public static HashMap<String, Callback> callbacks = new HashMap<String, Callback>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String sourceCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Callback(String src) {
/*  63 */     String uuid = UUID.randomUUID().toString();
/*  64 */     callbacks.put(uuid, this);
/*  65 */     this.sourceCode = "((javassist.tools.Callback) javassist.tools.Callback.callbacks.get(\"" + uuid + "\")).result(new Object[]{" + src + "});";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void result(Object... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     return sourceCode();
/*     */   }
/*     */   
/*     */   public String sourceCode() {
/*  81 */     return this.sourceCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void insertBefore(CtBehavior behavior, Callback callback) throws CannotCompileException {
/*  94 */     behavior.insertBefore(callback.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void insertAfter(CtBehavior behavior, Callback callback) throws CannotCompileException {
/* 110 */     behavior.insertAfter(callback.toString(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void insertAfter(CtBehavior behavior, Callback callback, boolean asFinally) throws CannotCompileException {
/* 131 */     behavior.insertAfter(callback.toString(), asFinally);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int insertAt(CtBehavior behavior, Callback callback, int lineNum) throws CannotCompileException {
/* 150 */     return behavior.insertAt(lineNum, callback.toString());
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\Callback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */