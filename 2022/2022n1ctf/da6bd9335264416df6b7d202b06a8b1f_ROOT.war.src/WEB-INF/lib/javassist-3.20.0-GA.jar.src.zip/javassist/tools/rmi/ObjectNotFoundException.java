/*    */ package javassist.tools.rmi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectNotFoundException
/*    */   extends Exception
/*    */ {
/*    */   public ObjectNotFoundException(String name) {
/* 21 */     super(name + " is not exported");
/*    */   }
/*    */   
/*    */   public ObjectNotFoundException(String name, Exception e) {
/* 25 */     super(name + " because of " + e.toString());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\rmi\ObjectNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */