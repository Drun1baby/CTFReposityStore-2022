/*    */ package javassist.tools.rmi;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoteRef
/*    */   implements Serializable
/*    */ {
/*    */   public int oid;
/*    */   public String classname;
/*    */   
/*    */   public RemoteRef(int i) {
/* 28 */     this.oid = i;
/* 29 */     this.classname = null;
/*    */   }
/*    */   
/*    */   public RemoteRef(int i, String name) {
/* 33 */     this.oid = i;
/* 34 */     this.classname = name;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\rmi\RemoteRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */