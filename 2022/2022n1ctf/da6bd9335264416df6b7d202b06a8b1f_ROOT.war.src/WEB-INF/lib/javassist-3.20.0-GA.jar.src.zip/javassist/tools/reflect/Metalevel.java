package javassist.tools.reflect;

public interface Metalevel {
  ClassMetaobject _getClass();
  
  Metaobject _getMetaobject();
  
  void _setMetaobject(Metaobject paramMetaobject);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\reflect\Metalevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */