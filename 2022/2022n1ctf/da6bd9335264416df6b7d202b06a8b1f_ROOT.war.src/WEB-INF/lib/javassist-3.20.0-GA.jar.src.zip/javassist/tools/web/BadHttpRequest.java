/*    */ package javassist.tools.web;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadHttpRequest
/*    */   extends Exception
/*    */ {
/*    */   private Exception e;
/*    */   
/*    */   public BadHttpRequest() {
/* 25 */     this.e = null;
/*    */   } public BadHttpRequest(Exception _e) {
/* 27 */     this.e = _e;
/*    */   }
/*    */   public String toString() {
/* 30 */     if (this.e == null) {
/* 31 */       return super.toString();
/*    */     }
/* 33 */     return this.e.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\web\BadHttpRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */