/*    */ package javassist.tools.reflect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CannotCreateException
/*    */   extends Exception
/*    */ {
/*    */   public CannotCreateException(String s) {
/* 24 */     super(s);
/*    */   }
/*    */   
/*    */   public CannotCreateException(Exception e) {
/* 28 */     super("by " + e.toString());
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\javassist-3.20.0-GA.jar!\javassist\tools\reflect\CannotCreateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */