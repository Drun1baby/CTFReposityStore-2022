/*    */ package org.apache.log4j.or.sax;
/*    */ 
/*    */ import org.apache.log4j.or.ObjectRenderer;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributesRenderer
/*    */   implements ObjectRenderer
/*    */ {
/*    */   public String doRender(Object o) {
/* 40 */     if (o instanceof Attributes) {
/* 41 */       StringBuffer sbuf = new StringBuffer();
/* 42 */       Attributes a = (Attributes)o;
/* 43 */       int len = a.getLength();
/* 44 */       boolean first = true;
/* 45 */       for (int i = 0; i < len; i++) {
/* 46 */         if (first) {
/* 47 */           first = false;
/*    */         } else {
/* 49 */           sbuf.append(", ");
/*    */         } 
/* 51 */         sbuf.append(a.getQName(i));
/* 52 */         sbuf.append('=');
/* 53 */         sbuf.append(a.getValue(i));
/*    */       } 
/* 55 */       return sbuf.toString();
/*    */     } 
/* 57 */     return o.toString();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\or\sax\AttributesRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */