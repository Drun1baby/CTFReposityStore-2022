package org.apache.log4j.jmx;

import java.lang.reflect.Method;

class MethodUnion {
  Method readMethod;
  
  Method writeMethod;
  
  MethodUnion(Method paramMethod1, Method paramMethod2) {
    this.readMethod = paramMethod1;
    this.writeMethod = paramMethod2;
  }
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\jmx\MethodUnion.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */