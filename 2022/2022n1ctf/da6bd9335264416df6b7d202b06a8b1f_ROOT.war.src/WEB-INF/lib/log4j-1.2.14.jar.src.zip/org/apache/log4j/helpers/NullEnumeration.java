/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullEnumeration
/*    */   implements Enumeration
/*    */ {
/* 30 */   private static final NullEnumeration instance = new NullEnumeration();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static NullEnumeration getInstance() {
/* 37 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasMoreElements() {
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object nextElement() {
/* 47 */     throw new NoSuchElementException();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\helpers\NullEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */