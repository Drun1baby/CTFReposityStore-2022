package org.apache.log4j.spi;

import java.net.URL;

public interface Configurator {
  public static final String INHERITED = "inherited";
  
  public static final String NULL = "null";
  
  void doConfigure(URL paramURL, LoggerRepository paramLoggerRepository);
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\spi\Configurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */