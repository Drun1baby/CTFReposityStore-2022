/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.log4j.spi.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountingQuietWriter
/*    */   extends QuietWriter
/*    */ {
/*    */   protected long count;
/*    */   
/*    */   public CountingQuietWriter(Writer writer, ErrorHandler eh) {
/* 38 */     super(writer, eh);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(String string) {
/*    */     try {
/* 44 */       this.out.write(string);
/* 45 */       this.count += string.length();
/*    */     } catch (IOException e) {
/*    */       
/* 48 */       this.errorHandler.error("Write failure.", e, 1);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public long getCount() {
/* 54 */     return this.count;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCount(long count) {
/* 59 */     this.count = count;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\helpers\CountingQuietWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */