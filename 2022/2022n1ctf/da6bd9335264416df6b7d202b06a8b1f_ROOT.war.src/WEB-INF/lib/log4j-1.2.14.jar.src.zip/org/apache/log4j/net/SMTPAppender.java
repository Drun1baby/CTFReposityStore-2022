package org.apache.log4j.net;

import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.helpers.CyclicBuffer;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.helpers.OptionConverter;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.TriggeringEventEvaluator;

public class SMTPAppender extends AppenderSkeleton {
  private String to;
  
  private String cc;
  
  private String bcc;
  
  private String from;
  
  private String subject;
  
  private String smtpHost;
  
  private String smtpUsername;
  
  private String smtpPassword;
  
  private boolean smtpDebug = false;
  
  private int bufferSize = 512;
  
  private boolean locationInfo = false;
  
  protected CyclicBuffer cb = new CyclicBuffer(this.bufferSize);
  
  protected Message msg;
  
  protected TriggeringEventEvaluator evaluator;
  
  public SMTPAppender() {
    this(new DefaultEvaluator());
  }
  
  public SMTPAppender(TriggeringEventEvaluator paramTriggeringEventEvaluator) {
    this.evaluator = paramTriggeringEventEvaluator;
  }
  
  public void activateOptions() {
    Session session = createSession();
    this.msg = (Message)new MimeMessage(session);
    try {
      addressMessage(this.msg);
      if (this.subject != null)
        this.msg.setSubject(this.subject); 
    } catch (MessagingException messagingException) {
      LogLog.error("Could not activate SMTPAppender options.", (Throwable)messagingException);
    } 
  }
  
  protected void addressMessage(Message paramMessage) throws MessagingException {
    if (this.from != null) {
      paramMessage.setFrom((Address)getAddress(this.from));
    } else {
      paramMessage.setFrom();
    } 
    if (this.to != null && this.to.length() > 0)
      paramMessage.setRecipients(Message.RecipientType.TO, (Address[])parseAddress(this.to)); 
    if (this.cc != null && this.cc.length() > 0)
      paramMessage.setRecipients(Message.RecipientType.CC, (Address[])parseAddress(this.cc)); 
    if (this.bcc != null && this.bcc.length() > 0)
      paramMessage.setRecipients(Message.RecipientType.BCC, (Address[])parseAddress(this.bcc)); 
  }
  
  protected Session createSession() {
    Properties properties = null;
    try {
      properties = new Properties(System.getProperties());
    } catch (SecurityException securityException) {
      properties = new Properties();
    } 
    if (this.smtpHost != null)
      properties.put("mail.smtp.host", this.smtpHost); 
    Authenticator authenticator = null;
    if (this.smtpPassword != null && this.smtpUsername != null) {
      properties.put("mail.smtp.auth", "true");
      authenticator = new Authenticator(this) {
          private final SMTPAppender this$0;
          
          protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(this.this$0.smtpUsername, this.this$0.smtpPassword);
          }
        };
    } 
    Session session = Session.getInstance(properties, authenticator);
    if (this.smtpDebug)
      session.setDebug(this.smtpDebug); 
    return session;
  }
  
  public void append(LoggingEvent paramLoggingEvent) {
    if (!checkEntryConditions())
      return; 
    paramLoggingEvent.getThreadName();
    paramLoggingEvent.getNDC();
    paramLoggingEvent.getMDCCopy();
    if (this.locationInfo)
      paramLoggingEvent.getLocationInformation(); 
    this.cb.add(paramLoggingEvent);
    if (this.evaluator.isTriggeringEvent(paramLoggingEvent))
      sendBuffer(); 
  }
  
  protected boolean checkEntryConditions() {
    if (this.msg == null) {
      this.errorHandler.error("Message object not configured.");
      return false;
    } 
    if (this.evaluator == null) {
      this.errorHandler.error("No TriggeringEventEvaluator is set for appender [" + this.name + "].");
      return false;
    } 
    if (this.layout == null) {
      this.errorHandler.error("No layout set for appender named [" + this.name + "].");
      return false;
    } 
    return true;
  }
  
  public synchronized void close() {
    this.closed = true;
  }
  
  InternetAddress getAddress(String paramString) {
    try {
      return new InternetAddress(paramString);
    } catch (AddressException addressException) {
      this.errorHandler.error("Could not parse address [" + paramString + "].", (Exception)addressException, 6);
      return null;
    } 
  }
  
  InternetAddress[] parseAddress(String paramString) {
    try {
      return InternetAddress.parse(paramString, true);
    } catch (AddressException addressException) {
      this.errorHandler.error("Could not parse address [" + paramString + "].", (Exception)addressException, 6);
      return null;
    } 
  }
  
  public String getTo() {
    return this.to;
  }
  
  public boolean requiresLayout() {
    return true;
  }
  
  protected void sendBuffer() {
    try {
      MimeBodyPart mimeBodyPart = new MimeBodyPart();
      StringBuffer stringBuffer = new StringBuffer();
      String str = this.layout.getHeader();
      if (str != null)
        stringBuffer.append(str); 
      int i = this.cb.length();
      for (byte b = 0; b < i; b++) {
        LoggingEvent loggingEvent = this.cb.get();
        stringBuffer.append(this.layout.format(loggingEvent));
        if (this.layout.ignoresThrowable()) {
          String[] arrayOfString = loggingEvent.getThrowableStrRep();
          if (arrayOfString != null)
            for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
              stringBuffer.append(arrayOfString[b1]);
              stringBuffer.append(Layout.LINE_SEP);
            }  
        } 
      } 
      str = this.layout.getFooter();
      if (str != null)
        stringBuffer.append(str); 
      mimeBodyPart.setContent(stringBuffer.toString(), this.layout.getContentType());
      MimeMultipart mimeMultipart = new MimeMultipart();
      mimeMultipart.addBodyPart((BodyPart)mimeBodyPart);
      this.msg.setContent((Multipart)mimeMultipart);
      this.msg.setSentDate(new Date());
      Transport.send(this.msg);
    } catch (Exception exception) {
      LogLog.error("Error occured while sending e-mail notification.", exception);
    } 
  }
  
  public String getEvaluatorClass() {
    return (this.evaluator == null) ? null : this.evaluator.getClass().getName();
  }
  
  public String getFrom() {
    return this.from;
  }
  
  public String getSubject() {
    return this.subject;
  }
  
  public void setFrom(String paramString) {
    this.from = paramString;
  }
  
  public void setSubject(String paramString) {
    this.subject = paramString;
  }
  
  public void setBufferSize(int paramInt) {
    this.bufferSize = paramInt;
    this.cb.resize(paramInt);
  }
  
  public void setSMTPHost(String paramString) {
    this.smtpHost = paramString;
  }
  
  public String getSMTPHost() {
    return this.smtpHost;
  }
  
  public void setTo(String paramString) {
    this.to = paramString;
  }
  
  public int getBufferSize() {
    return this.bufferSize;
  }
  
  public void setEvaluatorClass(String paramString) {
    this.evaluator = (TriggeringEventEvaluator)OptionConverter.instantiateByClassName(paramString, TriggeringEventEvaluator.class, this.evaluator);
  }
  
  public void setLocationInfo(boolean paramBoolean) {
    this.locationInfo = paramBoolean;
  }
  
  public boolean getLocationInfo() {
    return this.locationInfo;
  }
  
  public void setCc(String paramString) {
    this.cc = paramString;
  }
  
  public String getCc() {
    return this.cc;
  }
  
  public void setBcc(String paramString) {
    this.bcc = paramString;
  }
  
  public String getBcc() {
    return this.bcc;
  }
  
  public void setSMTPPassword(String paramString) {
    this.smtpPassword = paramString;
  }
  
  public void setSMTPUsername(String paramString) {
    this.smtpUsername = paramString;
  }
  
  public void setSMTPDebug(boolean paramBoolean) {
    this.smtpDebug = paramBoolean;
  }
  
  public String getSMTPPassword() {
    return this.smtpPassword;
  }
  
  public String getSMTPUsername() {
    return this.smtpUsername;
  }
  
  public boolean getSMTPDebug() {
    return this.smtpDebug;
  }
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\net\SMTPAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */