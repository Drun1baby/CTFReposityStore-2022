/*    */ package org.apache.log4j.lf5.viewer;
/*    */ 
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogFactor5ErrorDialog
/*    */   extends LogFactor5Dialog
/*    */ {
/*    */   public LogFactor5ErrorDialog(JFrame jframe, String message) {
/* 49 */     super(jframe, "Error", true);
/*    */     
/* 51 */     JButton ok = new JButton("Ok");
/* 52 */     ok.addActionListener(new ActionListener(this) { private final LogFactor5ErrorDialog this$0;
/*    */           public void actionPerformed(ActionEvent e) {
/* 54 */             this.this$0.hide();
/*    */           } }
/*    */       );
/*    */     
/* 58 */     JPanel bottom = new JPanel();
/* 59 */     bottom.setLayout(new FlowLayout());
/* 60 */     bottom.add(ok);
/*    */     
/* 62 */     JPanel main = new JPanel();
/* 63 */     main.setLayout(new GridBagLayout());
/* 64 */     wrapStringOnPanel(message, main);
/*    */     
/* 66 */     getContentPane().add(main, "Center");
/* 67 */     getContentPane().add(bottom, "South");
/* 68 */     show();
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\lf5\viewer\LogFactor5ErrorDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */