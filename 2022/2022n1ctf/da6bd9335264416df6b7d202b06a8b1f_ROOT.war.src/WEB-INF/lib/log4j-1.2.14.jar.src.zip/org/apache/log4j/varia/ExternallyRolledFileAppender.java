/*    */ package org.apache.log4j.varia;
/*    */ 
/*    */ import org.apache.log4j.RollingFileAppender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExternallyRolledFileAppender
/*    */   extends RollingFileAppender
/*    */ {
/*    */   public static final String ROLL_OVER = "RollOver";
/*    */   public static final String OK = "OK";
/* 60 */   int port = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HUP hup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPort(int port) {
/* 76 */     this.port = port;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPort() {
/* 84 */     return this.port;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void activateOptions() {
/* 92 */     super.activateOptions();
/* 93 */     if (this.port != 0) {
/* 94 */       if (this.hup != null) {
/* 95 */         this.hup.interrupt();
/*    */       }
/* 97 */       this.hup = new HUP(this, this.port);
/* 98 */       this.hup.setDaemon(true);
/* 99 */       this.hup.start();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\varia\ExternallyRolledFileAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */