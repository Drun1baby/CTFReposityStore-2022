package org.apache.log4j.or.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.or.ObjectRenderer;

public class MessageRenderer implements ObjectRenderer {
  public String doRender(Object paramObject) {
    if (paramObject instanceof Message) {
      StringBuffer stringBuffer = new StringBuffer();
      Message message = (Message)paramObject;
      try {
        stringBuffer.append("DeliveryMode=");
        switch (message.getJMSDeliveryMode()) {
          case 1:
            stringBuffer.append("NON_PERSISTENT");
            break;
          case 2:
            stringBuffer.append("PERSISTENT");
            break;
          default:
            stringBuffer.append("UNKNOWN");
            break;
        } 
        stringBuffer.append(", CorrelationID=");
        stringBuffer.append(message.getJMSCorrelationID());
        stringBuffer.append(", Destination=");
        stringBuffer.append(message.getJMSDestination());
        stringBuffer.append(", Expiration=");
        stringBuffer.append(message.getJMSExpiration());
        stringBuffer.append(", MessageID=");
        stringBuffer.append(message.getJMSMessageID());
        stringBuffer.append(", Priority=");
        stringBuffer.append(message.getJMSPriority());
        stringBuffer.append(", Redelivered=");
        stringBuffer.append(message.getJMSRedelivered());
        stringBuffer.append(", ReplyTo=");
        stringBuffer.append(message.getJMSReplyTo());
        stringBuffer.append(", Timestamp=");
        stringBuffer.append(message.getJMSTimestamp());
        stringBuffer.append(", Type=");
        stringBuffer.append(message.getJMSType());
      } catch (JMSException jMSException) {
        LogLog.error("Could not parse Message.", (Throwable)jMSException);
      } 
      return stringBuffer.toString();
    } 
    return paramObject.toString();
  }
}


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\or\jms\MessageRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */