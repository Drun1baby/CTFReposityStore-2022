/*     */ package org.apache.log4j.varia;
/*     */ 
/*     */ import org.apache.log4j.helpers.OptionConverter;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringMatchFilter
/*     */   extends Filter
/*     */ {
/*     */   public static final String STRING_TO_MATCH_OPTION = "StringToMatch";
/*     */   public static final String ACCEPT_ON_MATCH_OPTION = "AcceptOnMatch";
/*     */   boolean acceptOnMatch = true;
/*     */   String stringToMatch;
/*     */   
/*     */   public String[] getOptionStrings() {
/*  62 */     return new String[] { "StringToMatch", "AcceptOnMatch" };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOption(String key, String value) {
/*  72 */     if (key.equalsIgnoreCase("StringToMatch")) {
/*  73 */       this.stringToMatch = value;
/*  74 */     } else if (key.equalsIgnoreCase("AcceptOnMatch")) {
/*  75 */       this.acceptOnMatch = OptionConverter.toBoolean(value, this.acceptOnMatch);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStringToMatch(String s) {
/*  81 */     this.stringToMatch = s;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringToMatch() {
/*  86 */     return this.stringToMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAcceptOnMatch(boolean acceptOnMatch) {
/*  91 */     this.acceptOnMatch = acceptOnMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAcceptOnMatch() {
/*  96 */     return this.acceptOnMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int decide(LoggingEvent event) {
/* 104 */     String msg = event.getRenderedMessage();
/*     */     
/* 106 */     if (msg == null || this.stringToMatch == null) {
/* 107 */       return 0;
/*     */     }
/*     */     
/* 110 */     if (msg.indexOf(this.stringToMatch) == -1) {
/* 111 */       return 0;
/*     */     }
/* 113 */     if (this.acceptOnMatch) {
/* 114 */       return 1;
/*     */     }
/* 116 */     return -1;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\varia\StringMatchFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */