/*    */ package org.apache.log4j.varia;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.apache.log4j.PropertyConfigurator;
/*    */ import org.apache.log4j.spi.Configurator;
/*    */ import org.apache.log4j.spi.LoggerRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReloadingPropertyConfigurator
/*    */   implements Configurator
/*    */ {
/* 27 */   PropertyConfigurator delegate = new PropertyConfigurator();
/*    */   
/*    */   public void doConfigure(URL url, LoggerRepository repository) {}
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\varia\ReloadingPropertyConfigurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */