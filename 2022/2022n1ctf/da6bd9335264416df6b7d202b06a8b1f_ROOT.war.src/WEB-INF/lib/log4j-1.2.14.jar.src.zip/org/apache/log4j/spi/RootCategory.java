/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ import org.apache.log4j.Category;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.helpers.LogLog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RootCategory
/*    */   extends Logger
/*    */ {
/*    */   public RootCategory(Level level) {
/* 35 */     super("root");
/* 36 */     setLevel(level);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Level getChainedLevel() {
/* 47 */     return ((Category)this).level;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setLevel(Level level) {
/* 58 */     if (level == null) {
/* 59 */       LogLog.error("You have tried to set a null level to root.", new Throwable());
/*    */     }
/*    */     else {
/*    */       
/* 63 */       ((Category)this).level = level;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setPriority(Level level) {
/* 70 */     setLevel(level);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\spi\RootCategory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */