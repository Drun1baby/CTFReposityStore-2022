/*    */ package org.apache.log4j.chainsaw;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExitAction
/*    */   extends AbstractAction
/*    */ {
/* 32 */   private static final Logger LOG = Logger.getLogger(ExitAction.class);
/*    */   
/* 34 */   public static final ExitAction INSTANCE = new ExitAction();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent aIgnore) {
/* 44 */     LOG.info("shutting down");
/* 45 */     System.exit(0);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\chainsaw\ExitAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */