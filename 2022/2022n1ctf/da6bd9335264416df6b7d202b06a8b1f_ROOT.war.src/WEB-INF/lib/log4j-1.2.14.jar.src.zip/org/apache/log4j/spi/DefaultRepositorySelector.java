/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultRepositorySelector
/*    */   implements RepositorySelector
/*    */ {
/*    */   final LoggerRepository repository;
/*    */   
/*    */   public DefaultRepositorySelector(LoggerRepository repository) {
/* 28 */     this.repository = repository;
/*    */   }
/*    */ 
/*    */   
/*    */   public LoggerRepository getLoggerRepository() {
/* 33 */     return this.repository;
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\spi\DefaultRepositorySelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */