/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.apache.log4j.spi.ErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyslogQuietWriter
/*    */   extends QuietWriter
/*    */ {
/*    */   int syslogFacility;
/*    */   int level;
/*    */   
/*    */   public SyslogQuietWriter(Writer writer, int syslogFacility, ErrorHandler eh) {
/* 37 */     super(writer, eh);
/* 38 */     this.syslogFacility = syslogFacility;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLevel(int level) {
/* 43 */     this.level = level;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSyslogFacility(int syslogFacility) {
/* 48 */     this.syslogFacility = syslogFacility;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(String string) {
/* 53 */     super.write("<" + (this.syslogFacility | this.level) + ">" + string);
/*    */   }
/*    */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\helpers\SyslogQuietWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */