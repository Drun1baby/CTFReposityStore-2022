/*     */ package org.apache.log4j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Priority
/*     */ {
/*     */   transient int level;
/*     */   transient String levelStr;
/*     */   transient int syslogEquivalent;
/*     */   public static final int OFF_INT = 2147483647;
/*     */   public static final int FATAL_INT = 50000;
/*     */   public static final int ERROR_INT = 40000;
/*     */   public static final int WARN_INT = 30000;
/*     */   public static final int INFO_INT = 20000;
/*     */   public static final int DEBUG_INT = 10000;
/*     */   public static final int ALL_INT = -2147483648;
/*  44 */   public static final Priority FATAL = new Level(50000, "FATAL", 0);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final Priority ERROR = new Level(40000, "ERROR", 3);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final Priority WARN = new Level(30000, "WARN", 4);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final Priority INFO = new Level(20000, "INFO", 6);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final Priority DEBUG = new Level(10000, "DEBUG", 7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Priority() {
/*  71 */     this.level = 10000;
/*  72 */     this.levelStr = "DEBUG";
/*  73 */     this.syslogEquivalent = 7;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Priority(int level, String levelStr, int syslogEquivalent) {
/*  81 */     this.level = level;
/*  82 */     this.levelStr = levelStr;
/*  83 */     this.syslogEquivalent = syslogEquivalent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  92 */     if (o instanceof Priority) {
/*  93 */       Priority r = (Priority)o;
/*  94 */       return (this.level == r.level);
/*     */     } 
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getSyslogEquivalent() {
/* 106 */     return this.syslogEquivalent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGreaterOrEqual(Priority r) {
/* 122 */     return (this.level >= r.level);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Priority[] getAllPossiblePriorities() {
/* 134 */     return new Priority[] { FATAL, ERROR, Level.WARN, INFO, DEBUG };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 145 */     return this.levelStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int toInt() {
/* 154 */     return this.level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Priority toPriority(String sArg) {
/* 163 */     return Level.toLevel(sArg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Priority toPriority(int val) {
/* 172 */     return toPriority(val, DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Priority toPriority(int val, Priority defaultPriority) {
/* 181 */     return Level.toLevel(val, (Level)defaultPriority);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Priority toPriority(String sArg, Priority defaultPriority) {
/* 190 */     return Level.toLevel(sArg, (Level)defaultPriority);
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\Priority.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */