/*     */ package org.apache.log4j.lf5.viewer;
/*     */ 
/*     */ import java.awt.Adjustable;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.table.TableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LF5SwingUtils
/*     */ {
/*     */   public static void selectRow(int row, JTable table, JScrollPane pane) {
/*  61 */     if (table == null || pane == null) {
/*     */       return;
/*     */     }
/*  64 */     if (!contains(row, table.getModel())) {
/*     */       return;
/*     */     }
/*  67 */     moveAdjustable(row * table.getRowHeight(), pane.getVerticalScrollBar());
/*  68 */     selectRow(row, table.getSelectionModel());
/*     */ 
/*     */ 
/*     */     
/*  72 */     repaintLater(table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void makeScrollBarTrack(Adjustable scrollBar) {
/*  80 */     if (scrollBar == null) {
/*     */       return;
/*     */     }
/*  83 */     scrollBar.addAdjustmentListener(new TrackingAdjustmentListener());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void makeVerticalScrollBarTrack(JScrollPane pane) {
/*  92 */     if (pane == null) {
/*     */       return;
/*     */     }
/*  95 */     makeScrollBarTrack(pane.getVerticalScrollBar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean contains(int row, TableModel model) {
/* 102 */     if (model == null) {
/* 103 */       return false;
/*     */     }
/* 105 */     if (row < 0) {
/* 106 */       return false;
/*     */     }
/* 108 */     if (row >= model.getRowCount()) {
/* 109 */       return false;
/*     */     }
/* 111 */     return true;
/*     */   }
/*     */   
/*     */   protected static void selectRow(int row, ListSelectionModel model) {
/* 115 */     if (model == null) {
/*     */       return;
/*     */     }
/* 118 */     model.setSelectionInterval(row, row);
/*     */   }
/*     */   
/*     */   protected static void moveAdjustable(int location, Adjustable scrollBar) {
/* 122 */     if (scrollBar == null) {
/*     */       return;
/*     */     }
/* 125 */     scrollBar.setValue(location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void repaintLater(JComponent component) {
/* 133 */     SwingUtilities.invokeLater(new Runnable(component) {
/*     */           public void run() {
/* 135 */             this.val$component.repaint();
/*     */           }
/*     */           
/*     */           private final JComponent val$component;
/*     */         });
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\lf5\viewer\LF5SwingUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */