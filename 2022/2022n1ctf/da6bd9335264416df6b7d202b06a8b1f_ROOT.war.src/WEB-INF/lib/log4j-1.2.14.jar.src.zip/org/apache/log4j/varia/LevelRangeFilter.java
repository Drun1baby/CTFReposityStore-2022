/*     */ package org.apache.log4j.varia;
/*     */ 
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Priority;
/*     */ import org.apache.log4j.spi.Filter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelRangeFilter
/*     */   extends Filter
/*     */ {
/*     */   boolean acceptOnMatch = false;
/*     */   Level levelMin;
/*     */   Level levelMax;
/*     */   
/*     */   public int decide(LoggingEvent event) {
/*  70 */     if (this.levelMin != null && 
/*  71 */       !event.getLevel().isGreaterOrEqual((Priority)this.levelMin))
/*     */     {
/*  73 */       return -1;
/*     */     }
/*     */ 
/*     */     
/*  77 */     if (this.levelMax != null && 
/*  78 */       event.getLevel().toInt() > this.levelMax.toInt())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  83 */       return -1;
/*     */     }
/*     */ 
/*     */     
/*  87 */     if (this.acceptOnMatch)
/*     */     {
/*     */       
/*  90 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*  94 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getLevelMax() {
/* 102 */     return this.levelMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getLevelMin() {
/* 110 */     return this.levelMin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAcceptOnMatch() {
/* 118 */     return this.acceptOnMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevelMax(Level levelMax) {
/* 126 */     this.levelMax = levelMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevelMin(Level levelMin) {
/* 134 */     this.levelMin = levelMin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAcceptOnMatch(boolean acceptOnMatch) {
/* 142 */     this.acceptOnMatch = acceptOnMatch;
/*     */   }
/*     */ }


/* Location:              E:\桌面\da6bd9335264416df6b7d202b06a8b1f_ROOT.war!\WEB-INF\lib\log4j-1.2.14.jar!\org\apache\log4j\varia\LevelRangeFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */