CREATE TABLE users(  
   NAME           TEXT    NOT NULL,  
   PASSWORD            TEXT     NOT NULL,
   ACTIVE  INT NOT NULL
);

