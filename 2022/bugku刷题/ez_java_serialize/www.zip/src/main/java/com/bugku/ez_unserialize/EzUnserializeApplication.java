package com.bugku.ez_unserialize;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EzUnserializeApplication {

    public static void main(String[] args) {
        SpringApplication.run(EzUnserializeApplication.class, args);
    }

}
