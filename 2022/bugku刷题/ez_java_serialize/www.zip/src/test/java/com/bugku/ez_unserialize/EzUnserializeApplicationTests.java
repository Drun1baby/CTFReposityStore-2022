package com.bugku.ez_unserialize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EzUnserializeApplicationTests {

    @Test
    void contextLoads() {
    }

}
